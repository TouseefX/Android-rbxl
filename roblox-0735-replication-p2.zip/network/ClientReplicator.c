// ClientReplicator -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 175 functions


// Address: 0x1066fe604 | Name: __ZN3RBX7Network16ClientReplicator15createStatsItemEv
RBX::Network::ClientReplicator *__fastcall RBX::Network::ClientReplicator::createStatsItem(
        RBX::Network::ClientReplicator *this,
        __int64 a2)
{
  RBX::EngineContext *v3; // rdi
  std::__shared_weak_count *v4; // r14
  _QWORD v6[2]; // [rsp+0h] [rbp-40h] BYREF
  __int128 v7; // [rsp+10h] [rbp-30h] BYREF
  std::__shared_weak_count *v8[4]; // [rsp+20h] [rbp-20h] BYREF

  RBX::shared_from<RBX::Network::ClientReplicator>(a1: v8, a2); /*0x1066fe616*/
  v6[0] = RBX::EngineContext::getThreadLocal(this: v3); /*0x1066fe624*/
  LODWORD(v6[1]) = 3164; /*0x1066fe627*/
  RBX::Creatable::createImpl<RBX::Network::ClientStatsItem,RBX::ForceConstructionInCreatable &,std::shared_ptr<RBX::Network::ClientReplicator>>( /*0x1066fe636*/
    a1: &v7,
    a2: v6,
    a3: v8);
  *(_OWORD *)this = v7; /*0x1066fe63f*/
  v7 = 0; /*0x1066fe645*/
  v4 = v8[1]; /*0x1066fe649*/
  if ( v8[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v8[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1066fe662*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v4 + 16LL))(a1: v4); /*0x1066fe66a*/
    std::__shared_weak_count::__release_weak(this: v4); /*0x1066fe670*/
  }
  return this; /*0x1066fe678*/
}

// Address: 0x1066fe70e | Name: __ZN3RBX7Network16ClientReplicatorC2ERNS_28ForceConstructionInCreatableENS0_10Replicator18ReplicatorPeerInfoEPNS0_14MegaReplicatorENSt3__110unique_ptrINS_11NetworkBase18ConnectionInternalENS8_14default_deleteISB_EEEE
__int64 __fastcall RBX::Network::ClientReplicator::ClientReplicator(RBX::Network::Replicator *this)
{
  unsigned __int64 v2; // rsi
  __int64 v3; // r14
  __int64 v4; // rdi
  int v5; // r12d
  __int64 v6; // rdi
  __int64 v7; // rdi
  __int64 v8; // rdi
  __int64 v9; // rdi
  int v10; // eax
  double v11; // xmm0_8
  __int64 v12; // rdx
  __int64 v13; // rcx
  void *v14; // rsi
  _QWORD *v15; // r14
  unsigned __int64 v16; // rsi
  __int64 v17; // rax
  __int64 v18; // rsi
  _DWORD v20[4]; // [rsp+38h] [rbp-58h] BYREF
  void *v21; // [rsp+48h] [rbp-48h]
  __int64 *v22; // [rsp+50h] [rbp-40h]
  char v23; // [rsp+5Fh] [rbp-31h]

  v23 = 1; /*0x1066fe733*/
  v20[0] = 0; /*0x1066fe73d*/
  RBX::Described<RBX::Network::ClientReplicator,RBX::Network::Replicator>::Described<RBX::ForceConstructionInCreatable &,RBX::Network::Replicator::ReplicatorPeerInfo &,bool,RBX::Network::MegaReplicator *&,std::unique_ptr<RBX::NetworkBase::ConnectionInternal>,RBX::Network::ReplicatorType>( /*0x1066fe744*/
    a1: this,
    a2: (__int64)v20);
  *(_QWORD *)this = off_10CAF05E0; /*0x1066fe75a*/
  *((_QWORD *)this + 25) = off_10CAF0C38; /*0x1066fe764*/
  *((_QWORD *)this + 26) = off_10CAF0C68; /*0x1066fe772*/
  *((_QWORD *)this + 27) = off_10CAF0CB0; /*0x1066fe77f*/
  *((_QWORD *)this + 2723) = 0x4010000000000000LL; /*0x1066fe790*/
  *((_BYTE *)this + 21792) = 0; /*0x1066fe797*/
  *((_QWORD *)this + 2725) = 16; /*0x1066fe79e*/
  *((_QWORD *)this + 2726) = 0; /*0x1066fe7a5*/
  *((_DWORD *)this + 5454) = 1065353216; /*0x1066fe7b2*/
  *((_OWORD *)this + 1364) = 0; /*0x1066fe7bd*/
  RBX::UnboundedCircularBuffer<rbx::implementation::timestamped_safe_queue_item<RBX::Network::PropSync::detail::PropertyKey>>::UnboundedCircularBuffer( /*0x1066fe7d1*/
    a1: (char *)this + 21840,
    a2: 8);
  *((_BYTE *)this + 21872) = 0; /*0x1066fe7d6*/
  *((_DWORD *)this + 5472) = 0; /*0x1066fe7dd*/
  *((_QWORD *)this + 2737) = 0x4010000000000000LL; /*0x1066fe7e4*/
  *((_BYTE *)this + 21904) = 0; /*0x1066fe7eb*/
  *((_QWORD *)this + 2739) = 16; /*0x1066fe7f2*/
  *((_QWORD *)this + 2740) = 0; /*0x1066fe7f9*/
  *((_DWORD *)this + 5482) = 1065353216; /*0x1066fe800*/
  *((_OWORD *)this + 1371) = 0; /*0x1066fe80b*/
  RBX::UnboundedCircularBuffer<rbx::implementation::timestamped_safe_queue_item<RBX::Network::Sync::AttributeKey const*>>::UnboundedCircularBuffer( /*0x1066fe81f*/
    a1: (char *)this + 21952,
    a2: 8);
  *((_BYTE *)this + 21984) = 0; /*0x1066fe824*/
  *((_DWORD *)this + 5500) = -1; /*0x1066fe82b*/
  *((_BYTE *)this + 22004) = 0; /*0x1066fe835*/
  v3 = operator new(a1: (RBX::Memory *)0x60, a2: v2); /*0x1066fe846*/
  RBX::Network::SecurityChannel::SecurityChannel(a1: v3, a2: 70); /*0x1066fe851*/
  *((_QWORD *)this + 2751) = v3; /*0x1066fe856*/
  v22 = (__int64 *)((char *)this + 22016); /*0x1066fe864*/
  *((_OWORD *)this + 1376) = 0; /*0x1066fe86c*/
  *((_OWORD *)this + 1377) = 0; /*0x1066fe874*/
  *((_OWORD *)this + 1378) = 0; /*0x1066fe87c*/
  *((_QWORD *)this + 2758) = 0; /*0x1066fe884*/
  *(_OWORD *)((char *)this + 22072) = xmmword_1099FD030; /*0x1066fe896*/
  *(_OWORD *)((char *)this + 22088) = 0x4039000000000000uLL; /*0x1066fe8a5*/
  *((_BYTE *)this + 22104) = 1; /*0x1066fe8ae*/
  *((_OWORD *)this + 1382) = xmmword_1099FD040; /*0x1066fe8bb*/
  *((_OWORD *)this + 1383) = 0x3FA999999999999AuLL; /*0x1066fe8ca*/
  *((_BYTE *)this + 22144) = 1; /*0x1066fe8d2*/
  LODWORD(v3) = DFInt::StreamingQuotaCalculationIntervalValue; /*0x1066fe8df*/
  *((double *)this + 2769) = RBX::Time::now<(RBX::Time::SampleMethod)1>(a1: v4); /*0x1066fe8ed*/
  *((double *)this + 2770) = (double)(int)v3; /*0x1066fe8f5*/
  *((_QWORD *)this + 2771) = 0; /*0x1066fe900*/
  *((_QWORD *)this + 2772) = 0x3FA999999999999ALL; /*0x1066fe911*/
  *(_OWORD *)((char *)this + 22184) = 0; /*0x1066fe91c*/
  *((_QWORD *)this + 2775) = 0; /*0x1066fe924*/
  *((_BYTE *)this + 22208) = 1; /*0x1066fe92b*/
  v5 = DFInt::StreamingQuotaCalculationIntervalValue; /*0x1066fe932*/
  *((double *)this + 2777) = RBX::Time::now<(RBX::Time::SampleMethod)1>(a1: v6); /*0x1066fe943*/
  *((double *)this + 2778) = (double)v5; /*0x1066fe94b*/
  *((_QWORD *)this + 2779) = 0; /*0x1066fe953*/
  *((_QWORD *)this + 2780) = 0x3FB999999999999ALL; /*0x1066fe964*/
  *((_DWORD *)this + 5562) = 0; /*0x1066fe96b*/
  *((_OWORD *)this + 1391) = 0; /*0x1066fe976*/
  *((_BYTE *)this + 22272) = 1; /*0x1066fe980*/
  *((_QWORD *)this + 2785) = 0x3FB999999999999ALL; /*0x1066fe986*/
  *((_WORD *)this + 11144) = 0; /*0x1066fe98d*/
  *(_OWORD *)((char *)this + 22296) = 0; /*0x1066fe995*/
  *((_BYTE *)this + 22312) = 1; /*0x1066fe99d*/
  *((_QWORD *)this + 2790) = 0x3FB999999999999ALL; /*0x1066fe9a3*/
  *((_DWORD *)this + 5582) = 0; /*0x1066fe9aa*/
  *((_OWORD *)this + 1396) = 0; /*0x1066fe9b1*/
  *((_BYTE *)this + 22352) = 1; /*0x1066fe9b9*/
  *((_QWORD *)this + 2795) = 0x3FB999999999999ALL; /*0x1066fe9bf*/
  *((_DWORD *)this + 5592) = 0; /*0x1066fe9c6*/
  *(_OWORD *)((char *)this + 22376) = 0; /*0x1066fe9cd*/
  *((_BYTE *)this + 22392) = 1; /*0x1066fe9d5*/
  *((_QWORD *)this + 2800) = 0x3FB999999999999ALL; /*0x1066fe9db*/
  *((_DWORD *)this + 5602) = 0; /*0x1066fe9e2*/
  *((_OWORD *)this + 1401) = 0; /*0x1066fe9e9*/
  *((_BYTE *)this + 22432) = 1; /*0x1066fe9f1*/
  *((_QWORD *)this + 2805) = 0x3FB999999999999ALL; /*0x1066fe9f7*/
  *((_DWORD *)this + 5612) = 0; /*0x1066fe9fe*/
  *(_OWORD *)((char *)this + 22456) = 0; /*0x1066fea05*/
  *((_BYTE *)this + 22472) = 1; /*0x1066fea0d*/
  *((_QWORD *)this + 2810) = 0x3FA999999999999ALL; /*0x1066fea13*/
  *((_DWORD *)this + 5622) = 0; /*0x1066fea1a*/
  *((_OWORD *)this + 1406) = 0; /*0x1066fea21*/
  *((_BYTE *)this + 22512) = 1; /*0x1066fea29*/
  *((_DWORD *)this + 5630) = 5; /*0x1066fea2f*/
  *((_WORD *)this + 11264) = 0; /*0x1066fea39*/
  *((_BYTE *)this + 22530) = 0; /*0x1066fea41*/
  *((_DWORD *)this + 5645) = 0; /*0x1066fea48*/
  *(_OWORD *)((char *)this + 22564) = 0; /*0x1066fea4f*/
  *(_OWORD *)((char *)this + 22548) = 0; /*0x1066fea57*/
  *(_OWORD *)((char *)this + 22532) = 0; /*0x1066fea5f*/
  *((_QWORD *)this + 2823) = 0x3FA999999999999ALL; /*0x1066fea67*/
  *((_OWORD *)this + 1412) = 0; /*0x1066fea6e*/
  *((_QWORD *)this + 2826) = 0; /*0x1066fea76*/
  *((_BYTE *)this + 22616) = 1; /*0x1066fea7d*/
  *(_OWORD *)((char *)this + 22636) = 0; /*0x1066fea83*/
  *((_OWORD *)this + 1414) = 0; /*0x1066fea8b*/
  *((_QWORD *)this + 2832) = 0x3FA999999999999ALL; /*0x1066fea93*/
  *(_OWORD *)((char *)this + 22664) = 0; /*0x1066fea9a*/
  *((_QWORD *)this + 2835) = 0; /*0x1066feaa2*/
  *((_BYTE *)this + 22688) = 1; /*0x1066feaa9*/
  *(_OWORD *)((char *)this + 22708) = 0; /*0x1066feaaf*/
  *(_OWORD *)((char *)this + 22696) = 0; /*0x1066feab7*/
  *((_QWORD *)this + 2841) = 0x3FA999999999999ALL; /*0x1066feabf*/
  *((_OWORD *)this + 1421) = 0; /*0x1066feac6*/
  *((_QWORD *)this + 2844) = 0; /*0x1066feace*/
  *((_BYTE *)this + 22760) = 1; /*0x1066fead5*/
  *(_OWORD *)((char *)this + 22780) = 0; /*0x1066feadb*/
  *((_OWORD *)this + 1423) = 0; /*0x1066feae3*/
  *((_QWORD *)this + 2850) = 0x3FA999999999999ALL; /*0x1066feaeb*/
  *((_QWORD *)this + 2853) = 0; /*0x1066feaf2*/
  *(_OWORD *)((char *)this + 22808) = 0; /*0x1066feaf9*/
  *((_BYTE *)this + 22832) = 1; /*0x1066feb01*/
  *(_OWORD *)((char *)this + 22852) = 0; /*0x1066feb07*/
  *(_OWORD *)((char *)this + 22840) = 0; /*0x1066feb0f*/
  *((double *)this + 2859) = RBX::Time::now<(RBX::Time::SampleMethod)1>(a1: v7); /*0x1066feb1c*/
  *((_QWORD *)this + 2860) = 0x3FF0000000000000LL; /*0x1066feb2e*/
  *((_QWORD *)this + 2861) = 0; /*0x1066feb35*/
  *((double *)this + 2862) = RBX::Time::now<(RBX::Time::SampleMethod)1>(a1: v8); /*0x1066feb45*/
  *((_QWORD *)this + 2863) = 0x3FF0000000000000LL; /*0x1066feb4d*/
  *((_QWORD *)this + 2864) = 0; /*0x1066feb54*/
  *((double *)this + 2865) = RBX::Time::now<(RBX::Time::SampleMethod)1>(a1: v9); /*0x1066feb64*/
  *((_QWORD *)this + 2866) = 0x3FF0000000000000LL; /*0x1066feb6c*/
  *(_OWORD *)((char *)this + 22936) = 0; /*0x1066feb77*/
  *(_OWORD *)((char *)this + 22952) = 0; /*0x1066feb7f*/
  *(_OWORD *)((char *)this + 22968) = 0; /*0x1066feb87*/
  *((_DWORD *)this + 5746) = 1065353216; /*0x1066feb8f*/
  RBX::Network::DeserializedItemToClusterItemDependencyResolver::DeserializedItemToClusterItemDependencyResolver(this: (RBX::Network::Replicator *)((char *)this + 22992)); /*0x1066feba3*/
  v10 = 0; /*0x1066feba8*/
  *((_DWORD *)this + 5768) = 0; /*0x1066febaa*/
  v11 = (double)DFInt::StreamingReportPerformanceStatsAverageLerpValueThousands / 1000.0; /*0x1066febbe*/
  *((double *)this + 2885) = v11; /*0x1066febc6*/
  *((_OWORD *)this + 1443) = 0; /*0x1066febd2*/
  *((_QWORD *)this + 2888) = 0; /*0x1066febda*/
  *((_BYTE *)this + 23112) = 1; /*0x1066febe3*/
  *((double *)this + 2890) = v11; /*0x1066febe9*/
  *(_OWORD *)((char *)this + 23128) = 0; /*0x1066febf1*/
  *((_QWORD *)this + 2893) = 0; /*0x1066febf9*/
  *((_BYTE *)this + 23152) = 1; /*0x1066fec00*/
  *((_QWORD *)this + 2895) = 0x3FA999999999999ALL; /*0x1066fec06*/
  *((_OWORD *)this + 1448) = 0; /*0x1066fec0d*/
  *((_QWORD *)this + 2898) = 0; /*0x1066fec15*/
  *((_BYTE *)this + 23192) = 1; /*0x1066fec1c*/
  *((double *)this + 2900) = v11; /*0x1066fec22*/
  *(_OWORD *)((char *)this + 23208) = 0; /*0x1066fec2a*/
  *((_QWORD *)this + 2903) = 0; /*0x1066fec32*/
  *((_BYTE *)this + 23232) = 1; /*0x1066fec39*/
  *((double *)this + 2905) = v11; /*0x1066fec3f*/
  *((_QWORD *)this + 2908) = 0; /*0x1066fec47*/
  *((_OWORD *)this + 1453) = 0; /*0x1066fec4e*/
  *((_BYTE *)this + 23272) = 1; /*0x1066fec56*/
  *((double *)this + 2910) = v11; /*0x1066fec5c*/
  *(_OWORD *)((char *)this + 23288) = 0; /*0x1066fec64*/
  *((_QWORD *)this + 2913) = 0; /*0x1066fec6c*/
  *((_BYTE *)this + 23312) = 1; /*0x1066fec73*/
  *((double *)this + 2915) = v11; /*0x1066fec79*/
  *((_OWORD *)this + 1458) = 0; /*0x1066fec81*/
  *((_QWORD *)this + 2918) = 0; /*0x1066fec89*/
  *((_BYTE *)this + 23352) = 1; /*0x1066fec90*/
  *((double *)this + 2920) = v11; /*0x1066fec96*/
  *(_OWORD *)((char *)this + 23368) = 0; /*0x1066fec9e*/
  *((_QWORD *)this + 2923) = 0; /*0x1066feca6*/
  *((_BYTE *)this + 23392) = 1; /*0x1066fecad*/
  *((_QWORD *)this + 2925) = 0x3FA999999999999ALL; /*0x1066fecb3*/
  *((_OWORD *)this + 1463) = 0; /*0x1066fecba*/
  *((_QWORD *)this + 2928) = 0; /*0x1066fecc2*/
  *((_BYTE *)this + 23432) = 1; /*0x1066fecc9*/
  *((_OWORD *)this + 1465) = 0; /*0x1066feccf*/
  *((_DWORD *)this + 5864) = 0; /*0x1066fecd7*/
  *((_QWORD *)this + 2939) = 0; /*0x1066fecdd*/
  *(_OWORD *)((char *)this + 23496) = 0; /*0x1066fece4*/
  *(_OWORD *)((char *)this + 23480) = 0; /*0x1066fecec*/
  *(_OWORD *)((char *)this + 23464) = 0; /*0x1066fecf4*/
  *((_QWORD *)this + 2940) = 0xBFF0000000000000LL; /*0x1066fed06*/
  *((_DWORD *)this + 5882) = 0; /*0x1066fed0d*/
  *((_WORD *)this + 11766) = -1; /*0x1066fed13*/
  if ( FFlag::g_flagsLoaded == 1 && DFFlag::StreamRegionInvalidDefaultValue == 1 ) /*0x1066fed31*/
  {
    *((_QWORD *)this + 2942) = 0x7FFFFFFF7FFFFFFFLL; /*0x1066fed3d*/
    v10 = 0x7FFFFFFF; /*0x1066fed44*/
  }
  else
  {
    *((_QWORD *)this + 2942) = 0; /*0x1066fed4b*/
  }
  *((_DWORD *)this + 5886) = v10; /*0x1066fed56*/
  *(_QWORD *)((char *)this + 23548) = 0; /*0x1066fed5c*/
  RBX::JitterMetric::JitterMetric(this: (RBX::Network::Replicator *)((char *)this + 23560)); /*0x1066fed75*/
  RBX::KllSketch::KllSketch(this: (RBX::Network::Replicator *)((char *)this + 23816), a2: RBX::KllSketch::kDefaultK); /*0x1066fed8e*/
  *((_QWORD *)this + 2982) = 0; /*0x1066fed95*/
  *((_QWORD *)this + 2986) = 0; /*0x1066fed9c*/
  *((_DWORD *)this + 5974) = 0; /*0x1066feda3*/
  *((_QWORD *)this + 2988) = 0; /*0x1066feda9*/
  *(_DWORD *)((char *)this + 23879) = 0; /*0x1066fedb7*/
  *((_QWORD *)this + 2984) = 0; /*0x1066fedbd*/
  RBX::Analytics::InfluxDb::Points::Points(a1: (char *)this + 23912, a2: 0xFFFFFFFFLL, a3: 0, a4: 0); /*0x1066fedd0*/
  *((_BYTE *)this + 24384) = 0; /*0x1066fedd5*/
  *(_OWORD *)((char *)this + 24392) = 0; /*0x1066fede0*/
  *(_OWORD *)((char *)this + 24408) = 0; /*0x1066fede8*/
  *((_DWORD *)this + 6106) = 1065353216; /*0x1066fedf0*/
  *((_OWORD *)this + 1527) = 0; /*0x1066fedfa*/
  *((_OWORD *)this + 1528) = 0; /*0x1066fee02*/
  *((_QWORD *)this + 3058) = 0; /*0x1066fee0a*/
  std::string::basic_string[abi:ne200100]<0>(a1: v20, a2: "ClientReplicator", a3: v12, a4: v13); /*0x1066fee20*/
  RBX::Instance::setName(a1: this, a2: v20); /*0x1066fee2c*/
  if ( (v20[0] & 1) != 0 ) /*0x1066fee35*/
    operator delete(a1: (RBX::Memory *)v21, a2: v14); /*0x1066fee3b*/
  v15 = (_QWORD *)operator new(a1: (RBX::Memory *)8, a2: (unsigned __int64)v14); /*0x1066fee4a*/
  *v15 = 0; /*0x1066fee4d*/
  v17 = operator new(a1: (RBX::Memory *)0x38, a2: v16); /*0x1066fee59*/
  *(_OWORD *)v17 = 0; /*0x1066fee62*/
  *(_QWORD *)(v17 + 16) = 0; /*0x1066fee68*/
  *(_QWORD *)(v17 + 24) = 112; /*0x1066fee6c*/
  *(_QWORD *)(v17 + 32) = 32; /*0x1066fee79*/
  *(_QWORD *)(v17 + 40) = 32; /*0x1066fee7d*/
  *(_QWORD *)(v17 + 48) = 0; /*0x1066fee81*/
  *v15 = v17; /*0x1066fee85*/
  v18 = *v22; /*0x1066fee8c*/
  *v22 = (__int64)v15; /*0x1066fee8f*/
  if ( v18 != 0 ) /*0x1066fee95*/
    std::default_delete<RBX::AutoMemPool>::operator()[abi:ne200100](); /*0x1066fee97*/
  *((_BYTE *)this + 15224) = 1; /*0x1066fee9c*/
  *((_BYTE *)this + 15550) = 0; /*0x1066feea3*/
  return RBX::Network::Replicator::addReplicatorState(this); /*0x1066feeb7*/
}

// Address: 0x1066ff21a | Name: __ZN3RBX7Network16ClientReplicatorC1ERNS_28ForceConstructionInCreatableENS0_10Replicator18ReplicatorPeerInfoEPNS0_14MegaReplicatorENSt3__110unique_ptrINS_11NetworkBase18ConnectionInternalENS8_14default_deleteISB_EEEE
__int64 __fastcall RBX::Network::ClientReplicator::ClientReplicator(RBX::Network::Replicator *a1)
{
  return RBX::Network::ClientReplicator::ClientReplicator(this: a1); /*0x1066ff21e*/
}

// Address: 0x1066ff224 | Name: __ZN3RBX7Network16ClientReplicatorD2Ev
void __fastcall RBX::Network::ClientReplicator::~ClientReplicator(RBX::Network::ClientReplicator *this)
{
  RBX::Network::ClientReplicator *v2; // rdi
  __int64 v3; // rax
  void *v4; // rsi
  __int64 v5; // rsi

  *(_QWORD *)this = off_10CAF05E0; /*0x1066ff238*/
  *((_QWORD *)this + 25) = off_10CAF0C38; /*0x1066ff242*/
  *((_QWORD *)this + 26) = off_10CAF0C68; /*0x1066ff250*/
  *((_QWORD *)this + 27) = off_10CAF0CB0; /*0x1066ff25d*/
  if ( *((_BYTE *)this + 22004) == 1 && *((_BYTE *)this + 18702) == 0 ) /*0x1066ff274*/
    rbx::signal<void ()(bool)>::invokeImpl<(rbx::SignalInvokePolicy)0>( /*0x1066ff284*/
      a1: (char *)this + 24448,
      a2: (char *)this + 10391);
  RBX::Network::ItemQueue::debugDump(this: (RBX::Network::ClientReplicator *)((char *)this + 14536)); /*0x1066ff290*/
  RBX::Network::ItemQueue::debugDump(this: (RBX::Network::ClientReplicator *)((char *)this + 14584)); /*0x1066ff29c*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 3058); /*0x1066ff2a8*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 3057); /*0x1066ff2b4*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 3056); /*0x1066ff2c0*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 3055); /*0x1066ff2cc*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 3054); /*0x1066ff2d8*/
  std::__hash_table<std::__hash_value_type<RBX::Instance const*,RBX::Guid>,std::__unordered_map_hasher<RBX::Instance const*,std::__hash_value_type<RBX::Instance const*,RBX::Guid>,std::hash<RBX::Instance const*>,std::equal_to<RBX::Instance const*>,true>,std::__unordered_map_equal<RBX::Instance const*,std::__hash_value_type<RBX::Instance const*,RBX::Guid>,std::equal_to<RBX::Instance const*>,std::hash<RBX::Instance const*>,true>,std::allocator<std::__hash_value_type<RBX::Instance const*,RBX::Guid>>>::~__hash_table(a1: (char *)this + 24392); /*0x1066ff2e4*/
  RBX::Analytics::InfluxDb::Points::~Points(this: (void **)this + 2989); /*0x1066ff2f0*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::Network::ClientReplicator *)((char *)this + 23904)); /*0x1066ff2fc*/
  v2 = *((RBX::Network::ClientReplicator **)this + 2982); /*0x1066ff308*/
  if ( v2 == (RBX::Network::ClientReplicator *)((char *)this + 23824) ) /*0x1066ff312*/
  {
    v3 = 32; /*0x1066ff320*/
    goto LABEL_8; /*0x1066ff320*/
  }
  v3 = 40; /*0x1066ff314*/
  if ( v2 != nullptr ) /*0x1066ff31c*/
LABEL_8:
    (*(void (__fastcall **)(RBX::Network::ClientReplicator *))(*(_QWORD *)v2 + v3))(a1: v2); /*0x1066ff325*/
  RBX::KllSketch::~KllSketch(this: (RBX::Network::ClientReplicator *)((char *)this + 23816)); /*0x1066ff32b*/
  if ( (*((_BYTE *)this + 23792) & 1) != 0 ) /*0x1066ff33e*/
    operator delete(a1: *((RBX::Memory **)this + 2976), a2: v4); /*0x1066ff347*/
  if ( (*((_BYTE *)this + 23768) & 1) != 0 ) /*0x1066ff353*/
    operator delete(a1: *((RBX::Memory **)this + 2973), a2: v4); /*0x1066ff35c*/
  if ( (*((_BYTE *)this + 23744) & 1) != 0 ) /*0x1066ff368*/
    operator delete(a1: *((RBX::Memory **)this + 2970), a2: v4); /*0x1066ff371*/
  RBX::UnboundedCircularBuffer<double>::~UnboundedCircularBuffer(a1: (char *)this + 23568); /*0x1066ff37d*/
  RBX::Network::DeserializedItemToClusterItemDependencyResolver::~DeserializedItemToClusterItemDependencyResolver(this: (RBX::Network::ClientReplicator *)((char *)this + 22992)); /*0x1066ff389*/
  std::__hash_table<std::__hash_value_type<std::string,int>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,int>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,int>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,int>>>::~__hash_table(a1: (char *)this + 22952); /*0x1066ff395*/
  std::shared_ptr<RBX::Network::InstanceObjectManager>::~shared_ptr[abi:ne200100](a1: (char *)this + 22056); /*0x1066ff3a1*/
  std::shared_ptr<RBX::Network::StreamingSolverV2>::~shared_ptr[abi:ne200100](a1: (char *)this + 22040); /*0x1066ff3ad*/
  std::shared_ptr<RBX::Network::ClientReplicator::GCJob>::~shared_ptr[abi:ne200100](a1: (char *)this + 22024); /*0x1066ff3b9*/
  v5 = *((_QWORD *)this + 2752); /*0x1066ff3be*/
  *((_QWORD *)this + 2752) = 0; /*0x1066ff3c5*/
  if ( v5 != 0 ) /*0x1066ff3d3*/
    std::default_delete<RBX::AutoMemPool>::operator()[abi:ne200100](a1: (char *)this + 22016); /*0x1066ff3dc*/
  std::unique_ptr<RBX::Network::SecurityChannel>::reset[abi:ne200100](a1: (char *)this + 22008, a2: 0); /*0x1066ff3ea*/
  RBX::UnboundedCircularBuffer<rbx::implementation::timestamped_safe_queue_item<RBX::Network::Sync::AttributeKey const*>>::~UnboundedCircularBuffer(a1: (char *)this + 21952); /*0x1066ff3f6*/
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::Network::Sync::AttributeKey const,RBX::Network::Sync::SlaveItem>>,RBX::Network::Sync::AttributeKey,RBX::Network::Sync::SlaveItem,boost::hash<RBX::Network::Sync::AttributeKey>,std::equal_to<RBX::Network::Sync::AttributeKey>>>::delete_buckets(a1: (__int64)this + 21904); /*0x1066ff402*/
  RBX::UnboundedCircularBuffer<rbx::implementation::timestamped_safe_queue_item<RBX::Network::PropSync::detail::PropertyKey>>::~UnboundedCircularBuffer(a1: (char *)this + 21840); /*0x1066ff40e*/
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::Network::PropSync::detail::PropertyKey const,RBX::Network::PropSync::detail::SlaveItem>>,RBX::Network::PropSync::detail::PropertyKey,RBX::Network::PropSync::detail::SlaveItem,boost::hash<RBX::Network::PropSync::detail::PropertyKey>,std::equal_to<RBX::Network::PropSync::detail::PropertyKey>>>::delete_buckets(a1: (__int64)this + 21792); /*0x1066ff41a*/
  RBX::Network::ClientReplicatorProp::~ClientReplicatorProp(this); /*0x1066ff422*/
  RBX::Network::Replicator::~Replicator(this); /*0x1066ff430*/
}

// Address: 0x1066ff442 | Name: __ZN3RBX7Network16ClientReplicatorD1Ev
void __fastcall RBX::Network::ClientReplicator::~ClientReplicator(RBX::Network::ClientReplicator *this)
{
  RBX::Network::ClientReplicator::~ClientReplicator(this); /*0x1066ff447*/
}

// Address: 0x1066ff44c | Name: __ZThn200_N3RBX7Network16ClientReplicatorD1Ev
void __fastcall `non-virtual thunk to'RBX::Network::ClientReplicator::~ClientReplicator(
        RBX::Network::ClientReplicator *this)
{
  RBX::Network::ClientReplicator::~ClientReplicator(this: (RBX::Network::ClientReplicator *)((char *)this - 200)); /*0x1066ff458*/
}

// Address: 0x1066ff45e | Name: __ZThn208_N3RBX7Network16ClientReplicatorD1Ev
void __fastcall `non-virtual thunk to'RBX::Network::ClientReplicator::~ClientReplicator(
        RBX::Network::ClientReplicator *this)
{
  RBX::Network::ClientReplicator::~ClientReplicator(this: (RBX::Network::ClientReplicator *)((char *)this - 208)); /*0x1066ff46a*/
}

// Address: 0x1066ff470 | Name: __ZThn216_N3RBX7Network16ClientReplicatorD1Ev
void __fastcall `non-virtual thunk to'RBX::Network::ClientReplicator::~ClientReplicator(
        RBX::Network::ClientReplicator *this)
{
  RBX::Network::ClientReplicator::~ClientReplicator(this: (RBX::Network::ClientReplicator *)((char *)this - 216)); /*0x1066ff47c*/
}

// Address: 0x1066ff482 | Name: __ZN3RBX7Network16ClientReplicatorD0Ev
void __fastcall RBX::Network::ClientReplicator::~ClientReplicator(RBX::Network::ClientReplicator *this)
{
  void *v2; // rsi

  RBX::Network::ClientReplicator::~ClientReplicator(this); /*0x1066ff48b*/
  operator delete(a1: this, a2: v2); /*0x1066ff499*/
}

// Address: 0x1066ff49e | Name: __ZThn200_N3RBX7Network16ClientReplicatorD0Ev
void __fastcall `non-virtual thunk to'RBX::Network::ClientReplicator::~ClientReplicator(
        RBX::Network::ClientReplicator *this)
{
  RBX::Memory *v1; // rbx
  void *v2; // rsi

  v1 = (RBX::Network::ClientReplicator *)((char *)this - 200); /*0x1066ff4a7*/
  RBX::Network::ClientReplicator::~ClientReplicator(this: (RBX::Network::ClientReplicator *)((char *)this - 200)); /*0x1066ff4b1*/
  operator delete(a1: v1, a2: v2); /*0x1066ff4bf*/
}

// Address: 0x1066ff4c4 | Name: __ZThn208_N3RBX7Network16ClientReplicatorD0Ev
void __fastcall `non-virtual thunk to'RBX::Network::ClientReplicator::~ClientReplicator(
        RBX::Network::ClientReplicator *this)
{
  RBX::Memory *v1; // rbx
  void *v2; // rsi

  v1 = (RBX::Network::ClientReplicator *)((char *)this - 208); /*0x1066ff4cd*/
  RBX::Network::ClientReplicator::~ClientReplicator(this: (RBX::Network::ClientReplicator *)((char *)this - 208)); /*0x1066ff4d7*/
  operator delete(a1: v1, a2: v2); /*0x1066ff4e5*/
}

// Address: 0x1066ff4ea | Name: __ZThn216_N3RBX7Network16ClientReplicatorD0Ev
void __fastcall `non-virtual thunk to'RBX::Network::ClientReplicator::~ClientReplicator(
        RBX::Network::ClientReplicator *this)
{
  RBX::Memory *v1; // rbx
  void *v2; // rsi

  v1 = (RBX::Network::ClientReplicator *)((char *)this - 216); /*0x1066ff4f3*/
  RBX::Network::ClientReplicator::~ClientReplicator(this: (RBX::Network::ClientReplicator *)((char *)this - 216)); /*0x1066ff4fd*/
  operator delete(a1: v1, a2: v2); /*0x1066ff50b*/
}

// Address: 0x1066ff510 | Name: __ZNK3RBX7Network16ClientReplicator16findTargetPlayerEv
__int64 __fastcall RBX::Network::ClientReplicator::findTargetPlayer(RBX::Network::ClientReplicator *this)
{
  __int64 v1; // rax

  v1 = *((_QWORD *)this + 1808); /*0x1066ff510*/
  if ( v1 != 0 ) /*0x1066ff51a*/
    return *(_QWORD *)(v1 + 288); /*0x1066ff520*/
  else
    return 0; /*0x1066ff529*/
}

// Address: 0x1066ff52c | Name: __ZN3RBX7Network16ClientReplicator17isLegalSendObjectEPKNS_6ObjectE
__int64 __fastcall RBX::Network::ClientReplicator::isLegalSendObject(
        RBX::Network::ClientReplicator *this,
        const RBX::Object *a2)
{
  const RBX::Object *v2; // rbx
  __int64 v4; // r15
  __int64 v5; // rax
  __int64 v6; // r15
  __int64 v7; // rax
  __int64 v8; // rsi
  __int64 v9; // rdx
  __int64 v10; // rdi
  __int128 v12; // [rsp+0h] [rbp-40h] BYREF
  __int64 v13; // [rsp+10h] [rbp-30h]
  __int128 *v14; // [rsp+20h] [rbp-20h] BYREF

  v2 = a2; /*0x1066ff539*/
  if ( a2 != nullptr /*0x1066ff567*/
    && (v4 = *((_QWORD *)a2 + 3),
        v5 = RBX::Reflection::Class_getDescriptorPtr<RBX::Message>(a1: this),
        *(unsigned __int16 *)(v4 + 440) - (unsigned int)*(unsigned __int16 *)(v5 + 440) <= *(unsigned __int16 *)(v5 + 442)) )
  {
    LODWORD(v2) = 0; /*0x1066ff5e3*/
  }
  else
  {
    v12 = 0; /*0x1066ff56c*/
    v13 = 0; /*0x1066ff570*/
    v6 = *((_QWORD *)v2 + 3); /*0x1066ff578*/
    v7 = RBX::Instance::classDescriptor(this); /*0x1066ff57c*/
    v9 = 0; /*0x1066ff581*/
    if ( v2 != nullptr ) /*0x1066ff586*/
    {
      v8 = *(unsigned __int16 *)(v7 + 440); /*0x1066ff590*/
      if ( *(unsigned __int16 *)(v6 + 440) - (unsigned int)v8 <= *(unsigned __int16 *)(v7 + 442) ) /*0x1066ff5a2*/
        v9 = *((_QWORD *)v2 + 13); /*0x1066ff5a4*/
    }
    v10 = *((_QWORD *)this + 1567); /*0x1066ff5a8*/
    if ( v10 != 0 /*0x1066ff5c9*/
      && (unsigned int)((__int64 (__fastcall *)(__int64, const RBX::Object *, __int64, __int128 *, _QWORD, _QWORD))RBX::Network::StrictNetworkFilter::filterNew)(
                         a1: v10,
                         a2: v2,
                         a3: v9,
                         a4: &v12,
                         a5: 0,
                         a6: 0) == 1 )
    {
      LODWORD(v2) = 0; /*0x1066ff5cb*/
    }
    else
    {
      LOBYTE(v2) = 1; /*0x1066ff5cf*/
    }
    v14 = &v12; /*0x1066ff5d9*/
    std::vector<RBX::Network::PropValuePair>::__destroy_vector::operator()[abi:ne200100](a1: &v14, a2: v8, a3: v9); /*0x1066ff5dc*/
  }
  return (unsigned int)v2; /*0x1066ff5e7*/
}

// Address: 0x1066ff610 | Name: __ZN3RBX7Network16ClientReplicator19isLegalSendPropertyEPNS_6ObjectERKNS_10Reflection18PropertyDescriptorE
__int64 __fastcall RBX::Network::ClientReplicator::isLegalSendProperty(
        RBX::Network::StrictNetworkFilter **this,
        RBX::Instance **a2,
        const RBX::Reflection::PropertyDescriptor *a3)
{
  RBX::Network::ClientReplicator *v4; // r14
  RBX::Network::StrictNetworkFilter *v5; // rdi
  int v6; // eax
  RBX::Instance *v7; // r15
  __int64 v8; // rax
  RBX::Instance *v9; // r15
  __int64 v10; // rax

  v4 = (RBX::Network::ClientReplicator *)this; /*0x1066ff61d*/
  v5 = *(this + 1567); /*0x1066ff620*/
  if ( v5 != nullptr ) /*0x1066ff634*/
  {
    if ( (const RBX::Reflection::PropertyDescriptor *)RBX::Instance::propParent != a3 ) /*0x1066ff639*/
    {
      v6 = RBX::Network::StrictNetworkFilter::filterChangedProperty(this: v5, (const RBX::Object *)a2, a3); /*0x1066ff63e*/
LABEL_4:
      LOBYTE(v4) = v6 == 0; /*0x1066ff643*/
      return (unsigned int)v4; /*0x1066ff649*/
    }
    if ( a2 != nullptr ) /*0x1066ff689*/
    {
      v9 = a2[3]; /*0x1066ff68b*/
      v10 = RBX::Instance::classDescriptor(this: v5); /*0x1066ff68f*/
      if ( *((unsigned __int16 *)v9 + 220) - (unsigned int)*(unsigned __int16 *)(v10 + 440) <= *(unsigned __int16 *)(v10 + 442) ) /*0x1066ff6ae*/
      {
        v6 = RBX::Network::StrictNetworkFilter::filterParent( /*0x1066ff6cf*/
               this: *((RBX::Network::StrictNetworkFilter **)v4 + 1567),
               (RBX::Instance *)a2,
               a3: a2[13]);
        goto LABEL_4; /*0x1066ff6d4*/
      }
    }
LABEL_12:
    LODWORD(v4) = 0; /*0x1066ff6b0*/
    return (unsigned int)v4; /*0x1066ff6b0*/
  }
  LOBYTE(v4) = 1; /*0x1066ff64b*/
  if ( (const RBX::Reflection::PropertyDescriptor *)RBX::Instance::propParent == a3 && a2 != nullptr ) /*0x1066ff656*/
  {
    v7 = a2[3]; /*0x1066ff658*/
    v8 = RBX::Reflection::Class_getDescriptorPtr<RBX::Player>(a1: 0); /*0x1066ff65c*/
    if ( *((unsigned __int16 *)v7 + 220) - (unsigned int)*(unsigned __int16 *)(v8 + 440) <= *(unsigned __int16 *)(v8 + 442) /*0x1066ff682*/
      && a2[13] != nullptr )
    {
      goto LABEL_12; /*0x1066ff682*/
    }
  }
  return (unsigned int)v4; /*0x1066ff6ba*/
}

// Address: 0x1066ff6da | Name: __ZN3RBX7Network16ClientReplicator20isLegalSendAttributeEv
__int64 __fastcall RBX::Network::ClientReplicator::isLegalSendAttribute(RBX::Network::ClientReplicator *this)
{
  RBX::Network::Replicator::getAttributeSynchronizationEnabled(this); /*0x1066ff6e3*/
  return (*(__int64 (__fastcall **)(RBX::Network::ClientReplicator *))(*(_QWORD *)this + 1032LL))(a1: this);
}

// Address: 0x1066ff6fa | Name: __ZN3RBX7Network16ClientReplicator16isLegalSendEventEPNS_6ObjectERKNS_10Reflection15EventDescriptorE
bool __fastcall RBX::Network::ClientReplicator::isLegalSendEvent(
        RBX::Network::ClientReplicator *this,
        RBX::Object *a2,
        const RBX::Reflection::EventDescriptor *a3)
{
  RBX::Network::StrictNetworkFilter *v3; // rdi

  v3 = *((RBX::Network::StrictNetworkFilter **)this + 1567); /*0x1066ff6fa*/
  return v3 == nullptr || (unsigned int)RBX::Network::StrictNetworkFilter::filterEvent(this: v3, a2, a3) != 1; /*0x1066ff717*/
}

// Address: 0x1066ff71c | Name: __ZN3RBX7Network16ClientReplicator12canSendItemsEv
char __fastcall RBX::Network::ClientReplicator::canSendItems(RBX::Network::ClientReplicator *this)
{
  return *((_BYTE *)this + 22004); /*0x1066ff726*/
}

// Address: 0x1066ff728 | Name: __ZNK3RBX7Network16ClientReplicator11isCloudEditEv
bool __fastcall RBX::Network::ClientReplicator::isCloudEdit(RBX::Network::ClientReplicator *this)
{
  RBX::Network::Client *v1; // rbx
  __int64 v2; // r14
  __int64 v3; // rax
  bool result; // al

  v1 = *((RBX::Network::Client **)this + 13); /*0x1066ff72f*/
  result = v1 != nullptr /*0x1066ff76b*/
        && (v2 = *((_QWORD *)v1 + 3),
            v3 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>(a1: this),
            *(unsigned __int16 *)(v2 + 440) - (unsigned int)*(unsigned __int16 *)(v3 + 440) <= *(unsigned __int16 *)(v3 + 442))
        && RBX::Network::Client::isCloudEdit(this: v1);
  return result; /*0x1066ff75f*/
}

// Address: 0x1066ff770 | Name: __ZNK3RBX7Network16ClientReplicator20acceptsStudioClientsEv
bool __fastcall RBX::Network::ClientReplicator::acceptsStudioClients(RBX::Network::ClientReplicator *this)
{
  RBX::Network::Client *v1; // rbx
  __int64 v2; // r14
  __int64 v3; // rax
  bool result; // al
  bool isCloudEdit; // cl

  v1 = *((RBX::Network::Client **)this + 13); /*0x1066ff777*/
  if ( v1 == nullptr ) /*0x1066ff77e*/
    return false; /*0x1066ff77e*/
  v2 = *((_QWORD *)v1 + 3); /*0x1066ff780*/
  v3 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>(a1: this); /*0x1066ff784*/
  if ( *(unsigned __int16 *)(v2 + 440) - (unsigned int)*(unsigned __int16 *)(v3 + 440) > *(unsigned __int16 *)(v3 + 442) ) /*0x1066ff7a3*/
    return false; /*0x1066ff7a5*/
  isCloudEdit = RBX::Network::Client::isCloudEdit(this: v1); /*0x1066ff7b4*/
  result = true; /*0x1066ff7b6*/
  if ( !isCloudEdit ) /*0x1066ff7ba*/
    return RBX::Network::Client::isCloudTest(this: v1); /*0x1066ff7c3*/
  return result; /*0x1066ff7a7*/
}

// Address: 0x1066ff7c8 | Name: __ZNK3RBX7Network16ClientReplicator11isCloudTestEv
bool __fastcall RBX::Network::ClientReplicator::isCloudTest(RBX::Network::ClientReplicator *this)
{
  RBX::Network::Client *v1; // rbx
  __int64 v2; // r14
  __int64 v3; // rax
  bool result; // al

  v1 = *((RBX::Network::Client **)this + 13); /*0x1066ff7cf*/
  result = v1 != nullptr /*0x1066ff80b*/
        && (v2 = *((_QWORD *)v1 + 3),
            v3 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>(a1: this),
            *(unsigned __int16 *)(v2 + 440) - (unsigned int)*(unsigned __int16 *)(v3 + 440) <= *(unsigned __int16 *)(v3 + 442))
        && RBX::Network::Client::isCloudTest(this: v1);
  return result; /*0x1066ff7ff*/
}

// Address: 0x1066ff810 | Name: __ZN3RBX7Network16ClientReplicator42sendAnalyticsForLocallyInitiatedDisconnectEi
void __fastcall RBX::Network::ClientReplicator::sendAnalyticsForLocallyInitiatedDisconnect(
        RBX::Network::ClientReplicator *this,
        unsigned int a2)
{
  RBX::Network::Client *v2; // rbx
  __int64 v4; // r15
  __int64 v5; // rax
  const char *LoadStateSuffix; // rax
  __int64 v7; // rdi
  _BYTE *v8; // rsi
  unsigned __int64 v9; // rdx
  const char *v10; // rsi
  char *v11; // rcx
  void *v12; // rsi
  _QWORD v13[2]; // [rsp+0h] [rbp-80h] BYREF
  void *v14; // [rsp+10h] [rbp-70h]
  __int64 v15; // [rsp+18h] [rbp-68h]
  const char *v16; // [rsp+20h] [rbp-60h]
  unsigned __int8 v17; // [rsp+38h] [rbp-48h] BYREF
  _BYTE v18[15]; // [rsp+39h] [rbp-47h] BYREF
  void *v19; // [rsp+48h] [rbp-38h]
  char v20; // [rsp+50h] [rbp-30h] BYREF
  char v21; // [rsp+51h] [rbp-2Fh] BYREF
  void *v22; // [rsp+60h] [rbp-20h]

  v2 = *((RBX::Network::Client **)this + 13); /*0x1066ff81d*/
  if ( v2 != nullptr ) /*0x1066ff824*/
  {
    v4 = *((_QWORD *)v2 + 3); /*0x1066ff82d*/
    v5 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>(a1: this); /*0x1066ff831*/
    if ( *(unsigned __int16 *)(v4 + 440) - (unsigned int)*(unsigned __int16 *)(v5 + 440) <= *(unsigned __int16 *)(v5 + 442) ) /*0x1066ff850*/
    {
      RBX::Network::Replicator::disconnectReasonToString(this: (RBX::Network::Replicator *)&v17, a2); /*0x1066ff85d*/
      LoadStateSuffix = RBX::Network::Client::getLoadStateSuffix(this: v2); /*0x1066ff865*/
      v7 = v17 >> 1; /*0x1066ff877*/
      v8 = v19; /*0x1066ff87d*/
      if ( (v17 & 1) != 0 ) /*0x1066ff881*/
        v7 = *(_QWORD *)&v18[7]; /*0x1066ff885*/
      else
        v8 = v18; /*0x1066ff881*/
      v13[0] = a2; /*0x1066ff88e*/
      v14 = v8; /*0x1066ff891*/
      v15 = v7; /*0x1066ff895*/
      v16 = LoadStateSuffix; /*0x1066ff899*/
      fmt::v8::vformat(a1: &v20, a2: "LocalDisconnect_{}_{}{}", 23, 3281); /*0x1066ff8b2*/
      RBX::Network::Client::getConnectedServer(this: (RBX::Network::Client *)v13, a2: (__int64)v2, a3: v9); /*0x1066ff8be*/
      if ( (v20 & 1) != 0 ) /*0x1066ff8c7*/
        v10 = (const char *)v22; /*0x1066ff8c9*/
      else
        v10 = &v21; /*0x1066ff8cf*/
      if ( (v13[0] & 1) != 0 ) /*0x1066ff8d7*/
        v11 = (char *)v14; /*0x1066ff8d9*/
      else
        v11 = (char *)v13 + 1; /*0x1066ff8df*/
      RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x1066ff8f7*/
        this: (RBX::Network::ConcurrentRakPeer **)v2,
        a2: v10,
        a3: 1u,
        a4: v11,
        a5: 4,
        a6: 1);
      if ( (v13[0] & 1) != 0 ) /*0x1066ff900*/
        operator delete(a1: (RBX::Memory *)v14, a2: v12); /*0x1066ff906*/
      if ( (v20 & 1) != 0 ) /*0x1066ff90f*/
        operator delete(a1: (RBX::Memory *)v22, a2: v12); /*0x1066ff915*/
      if ( (v17 & 1) != 0 ) /*0x1066ff91e*/
        operator delete(a1: (RBX::Memory *)v19, a2: v12); /*0x1066ff924*/
    }
  }
}

// Address: 0x1066ff976 | Name: __ZN3RBX7Network16ClientReplicator23onNewConnectionCallbackEv
__int64 __fastcall RBX::Network::ClientReplicator::onNewConnectionCallback(
        RBX::Network::ClientReplicator *this,
        char a2)
{
  RBX::TaskScheduler *v3; // rdi
  __int64 result; // rax
  RBX::Profiler *v5; // rdi
  int v6; // esi

  if ( FFlag::DebugClientDumpMicroprofileForJoins != 0 /*0x1066ff99a*/
    || (unsigned __int8)RBX::Analytics::InfluxDb::canSend(
                          this: (RBX::Analytics::InfluxDb *)(unsigned int)DFInt::ClientReportInitExpJobStatsHundredthPercent,
                          a2) != 0 )
  {
    RBX::Profiler::notifyActiveCapture(this: nullptr, a2); /*0x1066ff99e*/
  }
  result = RBX::TaskScheduler::cycle(this: v3); /*0x1066ff9a3*/
  *((_QWORD *)this + 2986) = result; /*0x1066ff9a8*/
  if ( FFlag::DebugClientDumpMicroprofileForJoins == 1 ) /*0x1066ff9b3*/
  {
    *((_DWORD *)this + 5974) = RBX::Profiler::getAggregateFrames(this: v5); /*0x1066ff9ba*/
    return RBX::Profiler::setAggregateFrames(this: nullptr, a2: v6); /*0x1066ff9c6*/
  }
  return result; /*0x1066ff9c2*/
}

// Address: 0x1066ff9d0 | Name: __ZN3RBX7Network16ClientReplicator11OnReceiveV2ENS0_14IncomingPacketE
__int64 __fastcall RBX::Network::ClientReplicator::OnReceiveV2(__int64 a1, RBX::Network::IncomingPacket *a2)
{
  unsigned int v4; // ebx
  RakNet::SystemAddress *RakNetPacket; // rax
  RBX::Memory *v6; // r12
  void *v7; // rsi
  unsigned int v8; // r12d
  int v9; // eax
  RakNet *v10; // rdi
  int v11; // esi
  unsigned __int8 *v12; // r12
  unsigned int v13; // eax
  int v14; // edx
  int v15; // ecx
  int v16; // r8d
  int v17; // r9d
  unsigned __int64 v18; // rsi
  RBX::Network::Item *v19; // r15
  __int64 v20; // r12
  RBX::TaskScheduler *v21; // rdi
  char v22; // al
  RBX::TaskScheduler *v23; // rdi
  __int64 v24; // xmm0_8
  __int128 v25; // xmm0
  char *v26; // rdi
  __int128 v27; // xmm0
  RBX::TaskScheduler *v28; // rdi
  RBX::Profiler *v29; // rdi
  int v30; // esi
  RBX::Security::SessionCrypto *v31; // rdi
  char v32; // r15
  char *v33; // r12
  __int64 v34; // rdx
  __int64 v35; // rcx
  bool v36; // zf
  const char *v37; // r15
  void *v38; // rsi
  std::__shared_weak_count *v39; // r12
  __int64 v40; // rdi
  __int64 v41; // r14
  __int64 v42; // r15
  __int64 v43; // rax
  __int64 v44; // rcx
  void *v45; // rsi
  __int64 v46; // rdx
  __int64 v47; // rcx
  __int64 v48; // rax
  __int64 v49; // rdx
  __int64 v50; // rcx
  void *v51; // rsi
  __int64 v52; // rdx
  __int64 v53; // rcx
  __int64 v54; // rdx
  __int64 v55; // rcx
  __int64 v56; // rcx
  unsigned __int64 v57; // rsi
  unsigned __int64 v58; // rax
  __int128 v59; // xmm0
  unsigned __int8 *v60; // r12
  unsigned int v61; // eax
  void *v62; // rsi
  void *v63; // rsi
  int v64; // r8d
  int v65; // r9d
  const char *v66; // rcx
  unsigned __int8 *v67; // r12
  unsigned int v68; // eax
  RBX::ClientSessionTracker::ClientSessionTrackerContext *v69; // rdi
  std::__shared_weak_count *v70; // r15
  volatile signed __int64 *v71; // r14
  unsigned __int8 *v72; // r12
  unsigned int v73; // eax
  int Int32; // r15d
  int v75; // r12d
  unsigned int PayloadLimit; // eax
  void *v77; // rsi
  __int128 v78; // xmm0
  void *v79; // rsi
  int v80; // r8d
  int v81; // r9d
  unsigned int v82; // ecx
  const char *v83; // rcx
  __int64 v84; // r14
  __int64 v85; // r15
  __int64 v86; // rdi
  __int64 v87; // rax
  __int64 v88; // rcx
  void *v89; // rsi
  __int64 v90; // rdx
  __int64 v91; // rcx
  __int64 v92; // rax
  __int64 v93; // rdx
  __int64 v94; // rcx
  void *v95; // rsi
  __int64 v96; // rdx
  __int64 v97; // rcx
  __int64 v98; // rdx
  __int64 v99; // rcx
  void *v100; // rsi
  void *v101; // rsi
  void *v102; // rsi
  __int64 Instance; // rax
  void *v104; // rsi
  std::__shared_weak_count *v105; // r14
  char *v106; // rdx
  const char *v107; // r8
  char *v108; // rdx
  char *v109; // rcx
  std::__shared_weak_count *v110; // rsi
  char *v111; // rdi
  __int64 v112; // rax
  void *v113; // rsi
  std::__shared_weak_count *v114; // r14
  __int64 v115; // r15
  unsigned __int8 LuaKickIncludesMetadata; // al
  tm *v117; // rax
  RBX::LogGuid *v118; // rdi
  void *v119; // rsi
  __int64 RBXLogPrefix; // rax
  __int64 v121; // r8
  __int64 v122; // r9
  __m128 v123; // xmm0
  __m128 v124; // xmm1
  __m128 v125; // xmm2
  __m128 v126; // xmm3
  __m128 v127; // xmm4
  __m128 v128; // xmm5
  __m128 v129; // xmm6
  __m128 v130; // xmm7
  void *v131; // rsi
  RBX::Memory *v132; // rdi
  std::__shared_weak_count *v133; // r14
  __int64 v134; // rax
  __int64 v135; // rax
  char v136; // r12
  FILE *v137; // rax
  FILE *v138; // r13
  MicroProfileRawFormat *v139; // rax
  MicroProfileRawFormat *v140; // r15
  char *v141; // rsi
  char *v142; // rdi
  size_t v143; // rsi
  void *v144; // rsi
  unsigned int v145; // esi
  char v147[40]; // [rsp+0h] [rbp-990h] BYREF
  time_t v148; // [rsp+28h] [rbp-968h] BYREF
  __int128 v149; // [rsp+30h] [rbp-960h] BYREF
  void *v150; // [rsp+40h] [rbp-950h]
  _QWORD v151[2]; // [rsp+48h] [rbp-948h] BYREF
  std::__shared_weak_count *v152[4]; // [rsp+58h] [rbp-938h] BYREF
  std::__shared_weak_count *v153; // [rsp+78h] [rbp-918h]
  _BYTE v154[16]; // [rsp+80h] [rbp-910h] BYREF
  void *v155; // [rsp+90h] [rbp-900h]
  _BYTE v156[16]; // [rsp+98h] [rbp-8F8h] BYREF
  void *v157; // [rsp+A8h] [rbp-8E8h]
  _BYTE v158[16]; // [rsp+B0h] [rbp-8E0h] BYREF
  void *v159; // [rsp+C0h] [rbp-8D0h]
  _BYTE v160[16]; // [rsp+C8h] [rbp-8C8h] BYREF
  void *v161; // [rsp+D8h] [rbp-8B8h]
  _BYTE v162[16]; // [rsp+E0h] [rbp-8B0h] BYREF
  void *v163; // [rsp+F0h] [rbp-8A0h]
  _BYTE v164[16]; // [rsp+F8h] [rbp-898h] BYREF
  void *v165; // [rsp+108h] [rbp-888h]
  _BYTE v166[16]; // [rsp+110h] [rbp-880h] BYREF
  void *v167; // [rsp+120h] [rbp-870h]
  _BYTE v168[16]; // [rsp+128h] [rbp-868h] BYREF
  void *v169; // [rsp+138h] [rbp-858h]
  std::__shared_weak_count *v170[2]; // [rsp+140h] [rbp-850h] BYREF
  _BYTE v171[8]; // [rsp+158h] [rbp-838h] BYREF
  _BYTE v172[16]; // [rsp+160h] [rbp-830h] BYREF
  __int128 v173; // [rsp+170h] [rbp-820h] BYREF
  void *v174; // [rsp+180h] [rbp-810h]
  __int128 v175; // [rsp+190h] [rbp-800h] BYREF
  void *v176; // [rsp+1A0h] [rbp-7F0h]
  __int128 v177; // [rsp+1B0h] [rbp-7E0h] BYREF
  void *v178; // [rsp+1C0h] [rbp-7D0h]
  __int128 v179; // [rsp+1D0h] [rbp-7C0h] BYREF
  void *v180; // [rsp+1E0h] [rbp-7B0h]
  unsigned int v181; // [rsp+1E8h] [rbp-7A8h] BYREF
  unsigned int v182; // [rsp+1ECh] [rbp-7A4h] BYREF
  __int128 v183; // [rsp+1F0h] [rbp-7A0h] BYREF
  RBX::LogGuid *v184; // [rsp+200h] [rbp-790h]
  char __src[16]; // [rsp+210h] [rbp-780h] BYREF
  char *v186[4]; // [rsp+220h] [rbp-770h]
  unsigned int v187; // [rsp+240h] [rbp-750h]
  unsigned int v188; // [rsp+248h] [rbp-748h]
  __int128 v189; // [rsp+250h] [rbp-740h] BYREF
  void *v190[2]; // [rsp+260h] [rbp-730h]
  int v191; // [rsp+270h] [rbp-720h]
  std::__shared_weak_count *v192[2]; // [rsp+290h] [rbp-700h] BYREF
  void *v193; // [rsp+2A0h] [rbp-6F0h]
  std::__shared_weak_count *v194[2]; // [rsp+2B0h] [rbp-6E0h] BYREF
  void *v195; // [rsp+2C0h] [rbp-6D0h]
  _QWORD v196[5]; // [rsp+2D0h] [rbp-6C0h] BYREF
  _BYTE v197[8]; // [rsp+2F8h] [rbp-698h] BYREF
  _BYTE v198[96]; // [rsp+300h] [rbp-690h] BYREF
  _QWORD v199[5]; // [rsp+360h] [rbp-630h] BYREF
  _BYTE v200[8]; // [rsp+388h] [rbp-608h] BYREF
  _BYTE v201[96]; // [rsp+390h] [rbp-600h] BYREF
  _QWORD v202[5]; // [rsp+3F0h] [rbp-5A0h] BYREF
  _BYTE v203[8]; // [rsp+418h] [rbp-578h] BYREF
  _BYTE v204[96]; // [rsp+420h] [rbp-570h] BYREF
  std::__shared_weak_count *v205[2]; // [rsp+480h] [rbp-510h] BYREF
  void *v206[2]; // [rsp+490h] [rbp-500h]
  __int128 v207; // [rsp+4A0h] [rbp-4F0h]
  __int128 v208; // [rsp+4B0h] [rbp-4E0h]
  _QWORD v209[5]; // [rsp+4C0h] [rbp-4D0h] BYREF
  _BYTE v210[8]; // [rsp+4E8h] [rbp-4A8h] BYREF
  char v211[96]; // [rsp+4F0h] [rbp-4A0h] BYREF
  char __dst[1040]; // [rsp+550h] [rbp-440h] BYREF

  v4 = RBX::Memory::setCurrentCategory( /*0x1066ffa06*/
         this: (RBX::Memory *)(unsigned int)RBX::Memory::NetworkReplicator,
         (unsigned int)a2);
  RBX::ProtectedString::ProtectedString(this: (RBX::ProtectedString *)v171); /*0x1066ffa0f*/
  if ( *(_BYTE *)(a1 + 10391) == 1 ) /*0x1066ffa1c*/
  {
    std::to_string(a1: (unsigned int)__src); /*0x1066ffa2c*/
    if ( (__src[0] & 1) != 0 ) /*0x1066ffa38*/
    {
      v6 = (RBX::Memory *)v186[0]; /*0x1066ffa78*/
      strcpy(__dst, __src: v186[0]); /*0x1066ffa89*/
      operator delete(a1: v6, a2: v7); /*0x1066ffa91*/
    }
    else
    {
      strcpy(__dst, __src: &__src[1]); /*0x1066ffa48*/
    }
  }
  else
  {
    RakNetPacket = (RakNet::SystemAddress *)RBX::Network::IncomingPacket::getRakNetPacket(this: a2); /*0x1066ffa52*/
    RakNet::SystemAddress::ToStringN(this: RakNetPacket, a2: true, a3: __dst, a4: 1025, a5: 124); /*0x1066ffa71*/
  }
  v8 = 0; /*0x1066ffa96*/
  v9 = (unsigned __int8)RBX::Network::IncomingPacket::operator[](a1: a2, a2: 0); /*0x1066ffaa3*/
  if ( (unsigned __int8)v9 <= 0x8Du ) /*0x1066ffaab*/
  {
    switch ( (unsigned __int8)v9 ) /*0x1066ffb6a*/
    {
      case 0xEu: /*0x1066ffb6a*/
        v209[4] = *((_QWORD *)a2 + 4); /*0x1066ffcd6*/
        v27 = *(_OWORD *)a2; /*0x1066ffcda*/
        *(_OWORD *)&v209[2] = *((_OWORD *)a2 + 1); /*0x1066ffce5*/
        *(_OWORD *)v209 = v27; /*0x1066ffcea*/
        std::__optional_move_base<RBX::RbxTransport::NetStream,false>::__optional_move_base[abi:ne200100]( /*0x1066ffcf6*/
          a1: v210,
          a2: (char *)a2 + 40);
        RBX::Network::Replicator::processAckPacketV2(a1, a2: v209); /*0x1066ffd05*/
        if ( v211[88] != 1 ) /*0x1066ffd11*/
          goto LABEL_220; /*0x1066ffd11*/
        v26 = v211; /*0x1066ffd17*/
        break;
      case 0x10u: /*0x1066ffb6a*/
        if ( FFlag::DebugClientDumpMicroprofileForJoins != 0 /*0x1066ffd3d*/
          || (unsigned __int8)RBX::Analytics::InfluxDb::canSend(
                                this: (RBX::Analytics::InfluxDb *)(unsigned int)DFInt::ClientReportInitExpJobStatsHundredthPercent,
                                a2: v11) != 0 )
        {
          RBX::Profiler::notifyActiveCapture(this: nullptr, a2: v11); /*0x1066ffd41*/
        }
        *(_QWORD *)(a1 + 23888) = RBX::TaskScheduler::cycle(this: v28); /*0x1066ffd4b*/
        if ( FFlag::DebugClientDumpMicroprofileForJoins == 1 ) /*0x1066ffd56*/
        {
          *(_DWORD *)(a1 + 23896) = RBX::Profiler::getAggregateFrames(this: v29); /*0x1066ffd5d*/
          RBX::Profiler::setAggregateFrames(this: nullptr, a2: v30); /*0x1066ffd66*/
        }
        v31 = *(RBX::Security::SessionCrypto **)(a1 + 14472); /*0x1066ffd6b*/
        v8 = 1; /*0x1066ffd72*/
        if ( v31 != nullptr ) /*0x1066ffd7b*/
          RBX::Security::SessionCrypto::resetKeyExchangeKeys(this: v31, a2: false); /*0x1066ffd83*/
        goto LABEL_220; /*0x1066ffd88*/
      case 0x83u: /*0x1066ffb6a*/
        if ( FFlag::ConnectViaConnectionInternal == 0 && *(_BYTE *)(a1 + 10391) == 0 ) /*0x1066ffb9e*/
        {
          if ( DFInt::ReportClientJoinRxStatsHundrethsPercentage != 0 ) /*0x1066ffba7*/
          {
            v20 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *(RBX::Network::ConcurrentRakPeer **)(a1 + 224)); /*0x1066ffbb5*/
            RakNet::AddressOrGUID::AddressOrGUID( /*0x1066ffbc6*/
              this: (RakNet::AddressOrGUID *)__src,
              a2: (const RakNet::SystemAddress *)(a1 + 240));
            if ( (*(unsigned __int8 (__fastcall **)(__int64, char *))(*(_QWORD *)v20 + 744LL))(a1: v20, a2: __src) != 0 ) /*0x1066ffbe1*/
            {
              ++*(_DWORD *)(a1 + 15656); /*0x1066ffbe3*/
              *(_DWORD *)(a1 + 15652) += RBX::Network::IncomingPacket::size(this: a2); /*0x1066ffbf2*/
            }
          }
          if ( *(_DWORD *)(a1 + 15596) == 0 ) /*0x1066ffc01*/
          {
            *(_DWORD *)(a1 + 15596) = RakNet::GetTimeMS(this: v10); /*0x1066ffc08*/
            *(_QWORD *)(a1 + 15600) = RBX::TaskScheduler::cycle(this: v21); /*0x1066ffc14*/
          }
        }
        v22 = FFlag::ConnectViaConnectionInternal; /*0x1066ffc1b*/
        if ( FFlag::ConnectViaConnectionInternal == 1 && *(_DWORD *)(a1 + 15596) == 0 ) /*0x1066ffc2b*/
        {
          *(_DWORD *)(a1 + 15596) = RakNet::GetTimeMS(this: v10); /*0x1066ffc32*/
          *(_QWORD *)(a1 + 15600) = RBX::TaskScheduler::cycle(this: v23); /*0x1066ffc3e*/
          v22 = FFlag::ConnectViaConnectionInternal; /*0x1066ffc45*/
        }
        if ( (v22 & 1) != 0 && *(double *)(a1 + 15608) == 0.0 ) /*0x1066ffc5e*/
        {
          RBX::Time::nowFast(this: v10); /*0x1066ffc62*/
          *(_QWORD *)(a1 + 15608) = v24; /*0x1066ffc67*/
        }
        v199[4] = *((_QWORD *)a2 + 4); /*0x1066ffc7b*/
        v25 = *(_OWORD *)a2; /*0x1066ffc7f*/
        *(_OWORD *)&v199[2] = *((_OWORD *)a2 + 1); /*0x1066ffc8a*/
        *(_OWORD *)v199 = v25; /*0x1066ffc8f*/
        std::__optional_move_base<RBX::RbxTransport::NetStream,false>::__optional_move_base[abi:ne200100]( /*0x1066ffc9b*/
          a1: v200,
          a2: (char *)a2 + 40);
        v8 = RBX::Network::Replicator::OnReceiveV2(a1, a2: v199); /*0x1066ffcaf*/
        if ( v201[88] != 1 ) /*0x1066ffcb9*/
          goto LABEL_220; /*0x1066ffcb9*/
        v26 = v201; /*0x1066ffcbf*/
        break;
      default:
LABEL_58:
        v196[4] = *((_QWORD *)a2 + 4); /*0x10670007b*/
        v59 = *(_OWORD *)a2; /*0x10670008a*/
        *(_OWORD *)&v196[2] = *((_OWORD *)a2 + 1); /*0x106700095*/
        *(_OWORD *)v196 = v59; /*0x10670009a*/
        std::__optional_move_base<RBX::RbxTransport::NetStream,false>::__optional_move_base[abi:ne200100]( /*0x1067000a6*/
          a1: v197,
          a2: (char *)a2 + 40);
        v8 = RBX::Network::Replicator::OnReceiveV2(a1, a2: v196); /*0x1067000ba*/
        if ( v198[88] != 1 ) /*0x1067000c4*/
          goto LABEL_220; /*0x1067000c4*/
        v26 = v198; /*0x1067000ca*/
        break;
    }
    RBX::RbxTransport::NetStreamBuffer::~NetStreamBuffer(this: (RBX::RbxTransport::NetStreamBuffer *)v26); /*0x1067000d1*/
    goto LABEL_220; /*0x1067000d6*/
  }
  switch ( v9 )
  {
    case 146:
      v12 = (unsigned __int8 *)RBX::Network::IncomingPacket::data(this: a2); /*0x1066ffad8*/
      v13 = RBX::Network::IncomingPacket::size(this: a2); /*0x1066ffade*/
      RBX::Network::NetworkStream::NetworkStream( /*0x1066ffaf1*/
        this: (RBX::Network::NetworkStream *)__src,
        a2: v12,
        a3: v13,
        a4: false);
      RBX::Network::NetworkStream::IgnoreBytes(this: (RBX::Network::NetworkStream *)__src, a2: 1u); /*0x1066ffb02*/
      if ( (unsigned __int8)RBX::Network::NetworkStream::readBool(this: (RBX::Network::NetworkStream *)__src) != 0 ) /*0x1066ffb15*/
      {
        RBX::CreatorLog::printf( /*0x1066ffb29*/
          a1: 1,
          a2: (unsigned int)"Waiting for server to authenticate the placeID before spawning...",
          a3: v14,
          a4: v15,
          a5: v16,
          a6: v17);
        v19 = (RBX::Network::Item *)operator new(a1: (RBX::Memory *)0x40, a2: v18); /*0x1066ffb38*/
        RBX::Network::Item::Item(this: v19, a2: (RBX::Network::Replicator *)a1); /*0x1066ffb41*/
        *(_QWORD *)v19 = off_10CAA7EA8; /*0x1066ffb54*/
        RBX::Network::ItemQueue::push_back(this: (RBX::Network::ItemQueue *)(a1 + 14536), a2: v19); /*0x1066ffb5d*/
      }
      else
      {
        RBX::CreatorLog::printf( /*0x106700527*/
          a1: 3,
          a2: (unsigned int)"Place ID verification failed.",
          a3: v14,
          a4: v15,
          a5: v16,
          a6: v17);
        v84 = *(_QWORD *)(a1 + 104); /*0x10670052c*/
        v85 = *(_QWORD *)(v84 + 24); /*0x106700530*/
        v87 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>(a1: v86); /*0x106700534*/
        v88 = *(unsigned __int16 *)(v85 + 440) - (unsigned int)*(unsigned __int16 *)(v87 + 440); /*0x106700548*/
        if ( (unsigned int)v88 > *(unsigned __int16 *)(v87 + 442) ) /*0x106700555*/
          v84 = 0; /*0x106700555*/
        std::string::basic_string[abi:ne200100]<0>(a1: &v189, a2: __dst, a3: 0, a4: v88); /*0x106700567*/
        RBX::Network::Client::requestDisconnectOnTransportFailure(a1: v84, a2: (__int64)&v189, a3: 0x107u); /*0x10670057b*/
        if ( (v189 & 1) != 0 ) /*0x106700587*/
          operator delete(a1: (RBX::Memory *)v190[0], a2: v89); /*0x106700590*/
        RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x1067005b7*/
          this: (RBX::Network::ConcurrentRakPeer **)v84,
          a2: "PlaceIdFailedVerification",
          a3: 1u,
          a4: __dst,
          a5: 3,
          a6: 1);
        *(_OWORD *)v190 = 0; /*0x1067005c0*/
        v189 = 0; /*0x1067005c8*/
        v191 = 1065353216; /*0x1067005d0*/
        std::string::basic_string[abi:ne200100]<0>(a1: v205, a2: "gameJoinFailureReason", a3: v90, a4: v91); /*0x1067005eb*/
        v194[0] = (std::__shared_weak_count *)v205; /*0x1067005f7*/
        v92 = std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x106700612*/
                a1: &v189,
                a2: v205,
                a3: std::piecewise_construct,
                a4: v194,
                a5: v192);
        std::string::assign(a1: v92 + 40, a2: "PlaceIdFailedVerification"); /*0x106700625*/
        if ( ((__int64)v205[0] & 1) != 0 ) /*0x106700631*/
          operator delete(a1: (RBX::Memory *)v206[0], a2: v95); /*0x10670063a*/
        std::string::basic_string[abi:ne200100]<0>(a1: v162, a2: "client", a3: v93, a4: v94); /*0x10670064d*/
        std::string::basic_string[abi:ne200100]<0>(a1: v164, a2: "report", a3: v96, a4: v97); /*0x106700660*/
        std::string::basic_string[abi:ne200100]<0>(a1: v166, a2: "GameJoinFailure", a3: v98, a4: v99); /*0x106700673*/
        std::unordered_map<std::string,std::string>::unordered_map(a1: v147, a2: &v189); /*0x106700686*/
        RBX::Analytics::EventIngest::setRBXEvent(a1: v162, a2: v164, a3: v166, a4: v147); /*0x1067006a7*/
        std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::~__hash_table(a1: v147); /*0x1067006b3*/
        if ( (v166[0] & 1) != 0 ) /*0x1067006bf*/
          operator delete(a1: (RBX::Memory *)v167, a2: v100); /*0x1067006c8*/
        if ( (v164[0] & 1) != 0 ) /*0x1067006d4*/
          operator delete(a1: (RBX::Memory *)v165, a2: v100); /*0x1067006dd*/
        if ( (v162[0] & 1) != 0 ) /*0x1067006e9*/
          operator delete(a1: (RBX::Memory *)v163, a2: v100); /*0x1067006f2*/
        std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::~__hash_table(a1: &v189); /*0x1067006fe*/
      }
      goto LABEL_219; /*0x1066ffb62*/
    case 147:
      v67 = (unsigned __int8 *)RBX::Network::IncomingPacket::data(this: a2); /*0x106700247*/
      v68 = RBX::Network::IncomingPacket::size(this: a2); /*0x10670024d*/
      RBX::Network::NetworkStream::NetworkStream( /*0x106700260*/
        this: (RBX::Network::NetworkStream *)__src,
        a2: v67,
        a3: v68,
        a4: false);
      RBX::Network::NetworkStream::IgnoreBytes(this: (RBX::Network::NetworkStream *)__src, a2: 1u); /*0x106700271*/
      RBX::Network::NetworkStream::IgnoreBytes(this: (RBX::Network::NetworkStream *)__src, a2: 1u); /*0x106700282*/
      if ( v188 < v187 ) /*0x106700293*/
      {
        (*(void (__fastcall **)(__int64, char *))(*(_QWORD *)a1 + 1368LL))(a1, a2: __src); /*0x1067002a6*/
        v70 = (std::__shared_weak_count *)RBX::ClientSessionTrackerKeys::RCCChannelName; /*0x1067002b3*/
        v71 = (volatile signed __int64 *)unk_10D511EA0; /*0x1067002b6*/
        v152[3] = (std::__shared_weak_count *)RBX::ClientSessionTrackerKeys::RCCChannelName; /*0x1067002ba*/
        v153 = (std::__shared_weak_count *)unk_10D511EA0; /*0x1067002c1*/
        if ( unk_10D511EA0 != 0 ) /*0x1067002cb*/
          _InterlockedIncrement64((volatile signed __int64 *)(unk_10D511EA0 + 8LL)); /*0x1067002cd*/
        if ( (SFString::RCCChannelName[0] & 1) != 0 ) /*0x1067002dc*/
        {
          std::string::__init_copy_ctor_external( /*0x1067007c6*/
            a1: &v179,
            a2: *(_QWORD *)&SFString::RCCChannelName[16],
            a3: *(_QWORD *)&SFString::RCCChannelName[8]);
        }
        else
        {
          v180 = *(void **)&SFString::RCCChannelName[16]; /*0x1067002e6*/
          v179 = *(_OWORD *)SFString::RCCChannelName; /*0x1067002f1*/
        }
        Instance = RBX::ClientSessionTracker::ClientSessionTrackerContext::getInstance(this: v69); /*0x1067007cb*/
        v205[0] = v70; /*0x1067007d0*/
        v205[1] = (std::__shared_weak_count *)v71; /*0x1067007d7*/
        if ( v71 != nullptr ) /*0x1067007e1*/
          _InterlockedIncrement64(v71 + 1); /*0x1067007e3*/
        v190[0] = v180; /*0x1067007f6*/
        v189 = v179; /*0x106700802*/
        v179 = 0; /*0x10670080a*/
        v180 = nullptr; /*0x106700812*/
        RBX::ClientSessionTracker::ClientSessionTrackerContext::updateClientSessionMetric<std::string,false>( /*0x106700829*/
          a1: Instance,
          a2: v205,
          a3: &v189,
          a4: 0);
        if ( (v189 & 1) != 0 ) /*0x106700835*/
          operator delete(a1: (RBX::Memory *)v190[0], a2: v104); /*0x10670083e*/
        v105 = v205[1]; /*0x106700843*/
        if ( v205[1] != nullptr /*0x10670085f*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v205[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v105 + 16LL))(a1: v105); /*0x106700867*/
          std::__shared_weak_count::__release_weak(this: v105); /*0x10670086d*/
        }
        if ( (v179 & 1) != 0 ) /*0x106700879*/
          operator delete(a1: (RBX::Memory *)v180, a2: v104); /*0x106700882*/
        if ( v153 != nullptr /*0x1067008a3*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v153 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v153 + 16LL))(a1: v153); /*0x1067008ab*/
          std::__shared_weak_count::__release_weak(this: v153); /*0x1067008b1*/
        }
      }
      RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)__src); /*0x1067008bd*/
      goto LABEL_126; /*0x1067008bd*/
    case 148:
    case 149:
    case 150:
    case 151:
    case 153:
    case 156:
    case 157:
    case 158:
    case 159:
    case 160:
    case 161:
      goto LABEL_58;
    case 152:
      v60 = (unsigned __int8 *)RBX::Network::IncomingPacket::data(this: a2); /*0x1067000e3*/
      v61 = RBX::Network::IncomingPacket::size(this: a2); /*0x1067000e9*/
      RBX::Network::NetworkStream::NetworkStream( /*0x1067000fc*/
        this: (RBX::Network::NetworkStream *)__src,
        a2: v60,
        a3: v61,
        a4: false);
      RBX::Network::NetworkStream::IgnoreBytes(this: (RBX::Network::NetworkStream *)__src, a2: 1u); /*0x10670010d*/
      v189 = 0; /*0x106700116*/
      v190[0] = nullptr; /*0x106700120*/
      v206[0] = nullptr; /*0x106700127*/
      *(_OWORD *)v205 = 0; /*0x10670012e*/
      if ( (unsigned __int8)RBX::Network::Replicator::getLuaKickIncludesMetadata(this: (RBX::Network::Replicator *)a1) != 0 )
      {
        RBX::Network::Replicator::getReadPayloadLimit(this: (RBX::Network::Replicator *)a1); /*0x106700149*/
        RBX::Network::NetworkStream::readString(this: (RBX::Network::NetworkStream *)v194, a2: (int)__src); /*0x10670016c*/
        if ( (v189 & 1) != 0 ) /*0x106700178*/
          operator delete(a1: (RBX::Memory *)v190[0], a2: v62); /*0x106700181*/
        v190[0] = v195; /*0x10670018d*/
        v189 = *(_OWORD *)v194; /*0x10670019c*/
        RBX::Network::Replicator::getReadPayloadLimit(this: (RBX::Network::Replicator *)a1); /*0x1067001a7*/
        RBX::Network::NetworkStream::readString(this: (RBX::Network::NetworkStream *)v194, a2: (int)__src); /*0x1067001ca*/
        if ( ((__int64)v205[0] & 1) != 0 ) /*0x1067001d6*/
          operator delete(a1: (RBX::Memory *)v206[0], a2: v63); /*0x1067001df*/
        v206[0] = v195; /*0x1067001eb*/
        *(_OWORD *)v205 = *(_OWORD *)v194; /*0x1067001fa*/
        if ( (unsigned __int8)FLog::Player >= 6u && BYTE1(FLog::Player) >= 3u )
        {
          if ( (v189 & 1) != 0 ) /*0x10670022d*/
            v66 = (const char *)v190[0]; /*0x106700233*/
          else
            v66 = (char *)&v189 + 1; /*0x106700965*/
          if ( ((__int64)v205[0] & 1) != 0 ) /*0x106700977*/
            v107 = (const char *)v206[0]; /*0x106700979*/
          else
            v107 = (char *)v205 + 1; /*0x106700982*/
          FLog::FastLog(
            a1: *(_QWORD *)&FLog::Player,
            a2: qword_10D7F3D78,
            a3: "[FLog::Player] Server Kick Message: %s; Metadata: %s",
            v66,
            v107);
        }
        if ( (v189 & 1) != 0 ) /*0x10670099f*/
          LODWORD(v108) = v190[0]; /*0x1067009a1*/
        else
          v108 = (char *)&v189 + 1; /*0x1067009aa*/
        if ( ((__int64)v205[0] & 1) != 0 ) /*0x1067009b8*/
          LODWORD(v109) = v206[0]; /*0x1067009ba*/
        else
          v109 = (char *)v205 + 1; /*0x1067009c3*/
        RBX::CreatorLog::printf(
          a1: 3,
          a2: (unsigned int)"Server Kick Message: %s; Metadata: %s",
          a3: (_DWORD)v108,
          a4: (_DWORD)v109,
          a5: v64,
          a6: v65);
      }
      else
      {
        RBX::Network::Replicator::getReadPayloadLimit(this: (RBX::Network::Replicator *)a1); /*0x10670048b*/
        RBX::Network::NetworkStream::readString(this: (RBX::Network::NetworkStream *)v194, a2: (int)__src); /*0x1067004a0*/
        if ( (v189 & 1) != 0 ) /*0x1067004ac*/
          operator delete(a1: (RBX::Memory *)v190[0], a2: v79); /*0x1067004b5*/
        v190[0] = v195; /*0x1067004c1*/
        v189 = *(_OWORD *)v194; /*0x1067004d0*/
        v82 = (unsigned int)FLog::Player >> 8; /*0x1067004e4*/
        LOBYTE(v82) = (unsigned __int8)FLog::Player < 6u || BYTE1(FLog::Player) < 3u; /*0x1067004f4*/
        if ( (_BYTE)v82 == 0 )
        {
          if ( (v189 & 1) != 0 ) /*0x106700507*/
            v83 = (const char *)v190[0]; /*0x10670050d*/
          else
            v83 = (char *)&v189 + 1; /*0x106700924*/
          FLog::FastLog(
            a1: *(_QWORD *)&FLog::Player,
            a2: qword_10D7F3D78,
            a3: "[FLog::Player] Server Kick Message: %s",
            v83);
        }
        if ( (v189 & 1) != 0 ) /*0x10670093e*/
          LODWORD(v106) = v190[0]; /*0x106700940*/
        else
          v106 = (char *)&v189 + 1; /*0x106700949*/
        RBX::CreatorLog::printf(
          a1: 3,
          a2: (unsigned int)"Server Kick Message: %s",
          a3: (_DWORD)v106,
          a4: v82,
          a5: v80,
          a6: v81);
      }
      *(_OWORD *)v194 = 0; /*0x1067009e1*/
      if ( (unsigned __int8)RBX::Network::Replicator::getLuaKickIncludesMetadata(this: (RBX::Network::Replicator *)a1) == 0 ) /*0x1067009f3*/
        goto LABEL_163; /*0x1067009f3*/
      if ( ((__int64)v205[0] & 1) != 0 ) /*0x106700a02*/
      {
        v110 = v205[1]; /*0x106700a16*/
        if ( v205[1] == nullptr ) /*0x106700a20*/
          goto LABEL_163; /*0x106700a20*/
      }
      else
      {
        if ( LOBYTE(v205[0]) == 0 ) /*0x106700a07*/
          goto LABEL_163; /*0x106700a07*/
        v110 = v205[1]; /*0x106700a0d*/
      }
      *(_OWORD *)v192 = 0; /*0x106700a2a*/
      if ( ((__int64)v205[0] & 1) != 0 ) /*0x106700a34*/
      {
        v111 = (char *)v206[0]; /*0x106700a36*/
      }
      else
      {
        v111 = (char *)v205 + 1; /*0x106700a41*/
        v110 = (std::__shared_weak_count *)(LOBYTE(v205[0]) >> 1); /*0x106700a48*/
      }
      if ( (unsigned __int8)RBX::WebParser::parseJSONTable(a1: v111, a2: v110, a3: v192, a4: 0, a5: 0) == 0
        && (unsigned __int8)FLog::Player >= 6u
        && (FLog::Player & 0xFE00) != 0 )
      {
        FLog::FastLogSafeFormatted<std::string &>(
          a1: FLog::Player,
          a2: qword_10D7F3D78,
          a3: 2,
          a4: (int)"[FLog::Player] Received invalid metadata JSON in kick event: {}",
          a5: 63,
          a6: (unsigned __int8 *)v205);
      }
      v175 = *(_OWORD *)v192; /*0x106700aaf*/
      if ( v192[1] != nullptr ) /*0x106700aba*/
        _InterlockedIncrement64((volatile signed __int64 *)v192[1] + 1); /*0x106700abc*/
      std::shared_ptr<RBX::Reflection::ValueTable>::operator=[abi:ne200100](a1: v194, a2: &v175); /*0x106700ad2*/
      std::shared_ptr<RBX::Reflection::ValueTable>::~shared_ptr[abi:ne200100](a1: (__int64)&v175); /*0x106700ada*/
      std::shared_ptr<RBX::Reflection::ValueTable const>::~shared_ptr[abi:ne200100](a1: (__int64)v192); /*0x106700ae6*/
LABEL_163:
      v112 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)a1 + 688LL))(a1); /*0x106700aeb*/
      if ( v112 != 0 ) /*0x106700afa*/
      {
        *(_OWORD *)v192 = *(_OWORD *)v194; /*0x106700b11*/
        *(_OWORD *)v194 = 0; /*0x106700b19*/
        rbx::signal<void ()(std::string,std::shared_ptr<RBX::Reflection::ValueTable const>)>::invokeImpl<(rbx::SignalInvokePolicy)0>( /*0x106700b2b*/
          a1: v112 + 2704,
          a2: &v189);
        v114 = v192[1]; /*0x106700b30*/
        if ( v192[1] != nullptr /*0x106700b50*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v192[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v114 + 16LL))(a1: v114); /*0x106700b5c*/
          std::__shared_weak_count::__release_weak(this: v114); /*0x106700b62*/
        }
      }
      else
      {
        v115 = RBX::ServiceProvider::find<RBX::GuiService>(a1); /*0x106700b74*/
        if ( v115 != 0 ) /*0x106700b7a*/
        {
          LuaKickIncludesMetadata = RBX::Network::Replicator::getLuaKickIncludesMetadata(this: (RBX::Network::Replicator *)a1); /*0x106700b83*/
          if ( ((v194[0] != nullptr) & LuaKickIncludesMetadata) == 1 ) /*0x106700b97*/
            RBX::GuiService::setErrorDetails(a1: v115, a2: v194); /*0x106700ba3*/
          if ( (v189 & 1) != 0 ) /*0x106700baf*/
          {
            std::string::__init_copy_ctor_external(a1: &v173, a2: v190[0], a3: *((_QWORD *)&v189 + 1)); /*0x106700cf2*/
          }
          else
          {
            v174 = v190[0]; /*0x106700bbc*/
            v173 = v189; /*0x106700bcb*/
          }
          RBX::GuiService::setErrorMessage(a1: v115, a2: &v173, a3: 267); /*0x106700d06*/
          if ( (v173 & 1) != 0 ) /*0x106700d12*/
            operator delete(a1: (RBX::Memory *)v174, a2: v113); /*0x106700d1b*/
        }
      }
      v133 = v194[1]; /*0x106700d20*/
      if ( v194[1] != nullptr /*0x106700d3c*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v194[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v133 + 16LL))(a1: v133); /*0x106700d44*/
        std::__shared_weak_count::__release_weak(this: v133); /*0x106700d4a*/
      }
      if ( ((__int64)v205[0] & 1) != 0 ) /*0x106700d56*/
        operator delete(a1: (RBX::Memory *)v206[0], a2: v113); /*0x106700d5f*/
      if ( (v189 & 1) != 0 ) /*0x106700d6b*/
        operator delete(a1: (RBX::Memory *)v190[0], a2: v113); /*0x106700d78*/
      goto LABEL_219; /*0x106700d7d*/
    case 154:
      if ( *(_BYTE *)(a1 + 18384) != 1 ) /*0x106700306*/
        break; /*0x106700306*/
      *(_BYTE *)(a1 + 18384) = 0; /*0x10670030c*/
      v72 = (unsigned __int8 *)RBX::Network::IncomingPacket::data(this: a2); /*0x10670031c*/
      v73 = RBX::Network::IncomingPacket::size(this: a2); /*0x106700322*/
      RBX::Network::NetworkStream::NetworkStream( /*0x106700335*/
        this: (RBX::Network::NetworkStream *)__src,
        a2: v72,
        a3: v73,
        a4: false);
      RBX::Network::NetworkStream::IgnoreBytes(this: (RBX::Network::NetworkStream *)__src, a2: 1u); /*0x106700346*/
      Int32 = RBX::Network::NetworkStream::readInt32(this: (RBX::Network::NetworkStream *)__src); /*0x106700357*/
      v75 = RBX::Network::NetworkStream::readInt32(this: (RBX::Network::NetworkStream *)__src); /*0x106700366*/
      RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)&v189); /*0x106700370*/
      RBX::Network::Replicator::decompressBitStream( /*0x106700385*/
        this: (RBX::Network::NetworkStream *)__src,
        a2: (RBX::Network::NetworkStream *)&v189,
        a3: 0);
      *(_OWORD *)v194 = 0; /*0x10670038e*/
      v195 = nullptr; /*0x106700396*/
      PayloadLimit = RBX::Network::Replicator::getReadPayloadLimit(this: (RBX::Network::Replicator *)a1); /*0x1067003a4*/
      RBX::Network::deserializeString(a1: v194, a2: &v189, a3: PayloadLimit); /*0x1067003b9*/
      if ( ((__int64)v194[0] & 1) != 0 ) /*0x1067003c7*/
      {
        if ( v194[1] != (std::__shared_weak_count *)v75 ) /*0x1067008d7*/
        {
LABEL_217:
          operator delete(a1: (RBX::Memory *)v195, a2: v77); /*0x106700ffc*/
          goto LABEL_218; /*0x106701003*/
        }
      }
      else if ( v75 != LOBYTE(v194[0]) >> 1 ) /*0x1067003d2*/
      {
        goto LABEL_218; /*0x1067003d2*/
      }
      *(_OWORD *)v192 = 0; /*0x1067008e1*/
      v193 = nullptr; /*0x1067008e9*/
      if ( DFFlag::ReplicatorClientRemoteProfilerDumpRefactor == 1 ) /*0x1067008fb*/
      {
        if ( (unsigned __int8)RBX::Network::ClientReplicator::stringToHtmlFileDumpToLogDirHelper(a1, a2: v192, a3: v194) == 0 ) /*0x106700919*/
          goto LABEL_214; /*0x106700919*/
        goto LABEL_209; /*0x106700919*/
      }
      v148 = time(a1: nullptr); /*0x106700be6*/
      v208 = 0; /*0x106700bed*/
      v207 = 0; /*0x106700bf5*/
      *(_OWORD *)v206 = 0; /*0x106700bfd*/
      *(_OWORD *)v205 = 0; /*0x106700c05*/
      v117 = localtime(a1: &v148); /*0x106700c0d*/
      strftime(a1: (char *)v205, a2: 0x40u, a3: "microprofile_%Y%m%d-%H%M%S.html", a4: v117); /*0x106700c28*/
      v175 = 0; /*0x106700c38*/
      v176 = nullptr; /*0x106700c3c*/
      RBX::getRBXLogGUID(a1: (__int64)&v175); /*0x106700c44*/
      RBX::FileSystem::getLogsDirectory(this: (RBX::FileSystem *)&v183); /*0x106700c50*/
      std::string::operator=(a1: v192, a2: &v183); /*0x106700c63*/
      if ( (v183 & 1) != 0 ) /*0x106700c6f*/
        operator delete(a1: v184, a2: v119); /*0x106700c78*/
      if ( DFFlag::UseVerboseLogPrefixEverywhere == 1 ) /*0x106700c87*/
      {
        RBXLogPrefix = RBX::LogGuid::getRBXLogPrefix(this: v118); /*0x106700c8d*/
        RBX::format( /*0x106700cac*/
          this: (RBX *)&v183,
          a2: "%s_%s",
          a3: RBXLogPrefix,
          a4: (__int64)v205,
          a5: v121,
          a6: v122,
          a7: v123,
          a8: v124,
          a9: v125,
          a10: v126,
          a11: v127,
          a12: v128,
          a13: v129,
          a14: v130,
          a15: v147[0]);
        boost::filesystem::path::operator/=(this: (boost::filesystem::path *)v192, a2: &v183); /*0x106700cbf*/
        if ( (v183 & 1) == 0 ) /*0x106700ccb*/
          goto LABEL_194; /*0x106700ccb*/
        v132 = v184; /*0x106700cd1*/
        goto LABEL_193; /*0x106700cd8*/
      }
      std::operator+<char>(a1: v168, a2: "log_", &v175); /*0x106700d97*/
      v134 = std::string::append(a1: v168, a2: "_"); /*0x106700daa*/
      v150 = *(void **)(v134 + 16); /*0x106700dba*/
      v149 = *(_OWORD *)v134; /*0x106700dc2*/
      *(_OWORD *)v134 = 0; /*0x106700dca*/
      *(_QWORD *)(v134 + 16) = 0; /*0x106700dce*/
      v135 = std::string::append(a1: &v149, a2: (const char *)v205); /*0x106700ddd*/
      v184 = *(RBX::LogGuid **)(v135 + 16); /*0x106700ded*/
      v183 = *(_OWORD *)v135; /*0x106700df5*/
      *(_OWORD *)v135 = 0; /*0x106700dfd*/
      *(_QWORD *)(v135 + 16) = 0; /*0x106700e01*/
      boost::filesystem::path::operator/=(this: (boost::filesystem::path *)v192, a2: &v183); /*0x106700e10*/
      if ( (v183 & 1) != 0 ) /*0x106700e1c*/
        operator delete(a1: v184, a2: v131); /*0x106700e25*/
      if ( (v149 & 1) != 0 ) /*0x106700e31*/
        operator delete(a1: (RBX::Memory *)v150, a2: v131); /*0x106700e3a*/
      if ( (v168[0] & 1) != 0 ) /*0x106700e46*/
      {
        v132 = (RBX::Memory *)v169; /*0x106700e48*/
LABEL_193:
        operator delete(a1: v132, a2: v131); /*0x106700e4f*/
      }
LABEL_194:
      LODWORD(v183) = 0; /*0x106700e54*/
      *((_QWORD *)&v183 + 1) = boost::system::system_category(); /*0x106700e68*/
      v136 = RBX::FileSystem::exists(a1: v192, a2: &v183); /*0x106700e7c*/
      if ( v136 != 0 ) /*0x106700e81*/
      {
        *(_BYTE *)(a1 + 18384) = 0; /*0x106700e83*/
      }
      else
      {
        v137 = (FILE *)RBX::FileSystem::openFileWrite( /*0x106700e97*/
                         this: (RBX::FileSystem *)v192,
                         a2: (const boost::filesystem::path *)v77);
        v138 = v137; /*0x106700e9c*/
        if ( v137 != nullptr ) /*0x106700ea2*/
        {
          if ( Int32 == 5 ) /*0x106700eac*/
          {
            v139 = (MicroProfileRawFormat *)operator new(a1: (RBX::Memory *)0xC0, a2: (unsigned __int64)v77); /*0x106700eb3*/
            v140 = v139; /*0x106700eb8*/
            if ( ((__int64)v194[0] & 1) != 0 ) /*0x106700ec2*/
              v141 = (char *)v195; /*0x106700ec4*/
            else
              v141 = (char *)v194 + 1; /*0x106700f0a*/
            MicroProfileRawFormat::MicroProfileRawFormat(this: v139, a2: v141); /*0x106700f14*/
            MicroProfileRawToHtml(a1: v140); /*0x106700f28*/
            fclose(a1: v138); /*0x106700f30*/
            MicroProfileRawFormat::~MicroProfileRawFormat(this: v140); /*0x106700f38*/
            operator delete(a1: v140, a2: v144); /*0x106700f40*/
          }
          else
          {
            if ( ((__int64)v194[0] & 1) != 0 ) /*0x106700ed8*/
            {
              v142 = (char *)v195; /*0x106700eda*/
              v143 = (size_t)v194[1]; /*0x106700ee1*/
            }
            else
            {
              v143 = LOBYTE(v194[0]) >> 1; /*0x106700eea*/
              v142 = (char *)v194 + 1; /*0x106700eec*/
            }
            fwrite(a1: v142, a2: v143, a3: 1u, a4: v137); /*0x106700efb*/
            fclose(a1: v138); /*0x106700f03*/
          }
        }
      }
      if ( (v175 & 1) != 0 ) /*0x106700f4c*/
        operator delete(a1: (RBX::Memory *)v176, a2: v77); /*0x106700f55*/
      if ( v136 == 0 ) /*0x106700f5d*/
      {
LABEL_209:
        if ( ((__int64)v192[0] & 1) != 0 ) /*0x106700f66*/
        {
          std::string::__init_copy_ctor_external(a1: &v177, a2: v193, a3: v192[1]); /*0x106700f9d*/
        }
        else
        {
          v178 = v193; /*0x106700f6f*/
          v177 = *(_OWORD *)v192; /*0x106700f7e*/
        }
        LOBYTE(v205[0]) = 1; /*0x106700fb3*/
        rbx::signal<void ()(bool,std::string)>::invokeImpl<(rbx::SignalInvokePolicy)0>( /*0x106700fc4*/
          a1: *((_QWORD *)RBX::Network::ClientReplicatorEvents::event_RCCProfilerDataComplete + 15) + a1,
          a2: v205,
          a3: &v177);
        if ( (v177 & 1) != 0 ) /*0x106700fd0*/
          operator delete(a1: (RBX::Memory *)v178, a2: v77); /*0x106700fd9*/
      }
LABEL_214:
      if ( ((__int64)v192[0] & 1) != 0 ) /*0x106700fe5*/
        operator delete(a1: (RBX::Memory *)v193, a2: v77); /*0x106700fee*/
      if ( ((__int64)v194[0] & 1) != 0 ) /*0x106700ffa*/
        goto LABEL_217; /*0x106700ffa*/
LABEL_218:
      RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)&v189); /*0x106701008*/
LABEL_219:
      RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)__src); /*0x106701014*/
      v8 = 0; /*0x106701020*/
      break; /*0x106701020*/
    case 155:
      if ( DFFlag::CLI169073 != 1 || (v8 = 1, (unsigned __int8)RBX::RunService::productIsStudio(this: v10) == 0) ) /*0x1067003f3*/
      {
        v202[4] = *((_QWORD *)a2 + 4); /*0x106700404*/
        v78 = *(_OWORD *)a2; /*0x106700408*/
        *(_OWORD *)&v202[2] = *((_OWORD *)a2 + 1); /*0x106700413*/
        *(_OWORD *)v202 = v78; /*0x106700418*/
        std::__optional_move_base<RBX::RbxTransport::NetStream,false>::__optional_move_base[abi:ne200100]( /*0x106700424*/
          a1: v203,
          a2: (char *)a2 + 40);
        RBX::Network::ClientReplicator::readDynLuaChallengeV2(a1, a2: v202, a3: &v182, a4: &v181, a5: v171); /*0x106700448*/
        if ( v204[88] == 1 ) /*0x106700454*/
          RBX::RbxTransport::NetStreamBuffer::~NetStreamBuffer(this: (RBX::RbxTransport::NetStreamBuffer *)v204); /*0x10670045d*/
        v8 = 1; /*0x106700468*/
        RBX::Network::ClientReplicator::computeAndSendDynLuaResponse( /*0x10670047e*/
          this: (RBX::Network::ClientReplicator *)a1,
          a2: v182,
          a3: v181,
          a4: (RBX::ProtectedString *)v171);
      }
      break; /*0x106700483*/
    case 162:
    case 163:
    case 164:
      break;
    default:
      if ( (unsigned __int8)v9 != 142 ) /*0x1066ffd92*/
        goto LABEL_58; /*0x1066ffd92*/
      *(_QWORD *)__src = __dst; /*0x1066ffda6*/
      fmt::v8::vformat(a1: &v189, a2: "Protocol mismatch from {}", 25, 12); /*0x1066ffdc1*/
      v32 = v189; /*0x1066ffdc6*/
      v33 = (char *)v190[0]; /*0x1066ffdcd*/
      *(_OWORD *)v170 = 0; /*0x1066ffdd8*/
      std::string::basic_string[abi:ne200100]<0>(a1: v154, a2: "", a3: v34, a4: v35); /*0x1066ffdee*/
      v36 = (v32 & 1) == 0; /*0x1066ffdf3*/
      v37 = (char *)&v189 + 1; /*0x1066ffdf7*/
      if ( v36 ) /*0x1066ffdfe*/
        v33 = (char *)&v189 + 1; /*0x1066ffdfe*/
      RBX::CreatorLog::print(a1: 4, a2: v33, a3: 4, a4: v170, a5: v154); /*0x1066ffe1d*/
      if ( (v154[0] & 1) != 0 ) /*0x1066ffe29*/
        operator delete(a1: (RBX::Memory *)v155, a2: v38); /*0x1066ffe32*/
      v39 = v170[1]; /*0x1066ffe37*/
      if ( v170[1] != nullptr /*0x1066ffe54*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v170[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v39 + 16LL))(a1: v39); /*0x1066ffe5d*/
        std::__shared_weak_count::__release_weak(this: v39); /*0x1066ffe63*/
      }
      v40 = FLog::Network; /*0x1066ffe6f*/
      if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x1066ffe81*/
      {
        if ( (v189 & 1) != 0 ) /*0x1066ffe93*/
          v37 = (const char *)v190[0]; /*0x1066ffe95*/
        FLog::FastLogS( /*0x1066ffea6*/
          this: (FLog *)FLog::Network,
          a2: qword_10D7BBAA8,
          a3: (unsigned __int64)"[FLog::Network] Protocol mismatch %s",
          a4: v37);
      }
      v41 = *(_QWORD *)(a1 + 104); /*0x1066ffeab*/
      v42 = *(_QWORD *)(v41 + 24); /*0x1066ffeaf*/
      v43 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>(a1: v40); /*0x1066ffeb3*/
      v44 = *(unsigned __int16 *)(v42 + 440) - (unsigned int)*(unsigned __int16 *)(v43 + 440); /*0x1066ffec7*/
      if ( (unsigned int)v44 > *(unsigned __int16 *)(v43 + 442) ) /*0x1066ffed4*/
        v41 = 0; /*0x1066ffed4*/
      std::string::basic_string[abi:ne200100]<0>(a1: __src, a2: __dst, a3: 0, a4: v44); /*0x1066ffee6*/
      RBX::Network::Client::requestDisconnectOnTransportFailure(a1: v41, a2: (__int64)__src, a3: 0x103u); /*0x1066ffefa*/
      if ( (__src[0] & 1) != 0 ) /*0x1066fff06*/
        operator delete(a1: (RBX::Memory *)v186[0], a2: v45); /*0x1066fff0f*/
      RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x1066fff36*/
        this: (RBX::Network::ConcurrentRakPeer **)v41,
        a2: "ProtocolMismatch",
        a3: 1u,
        a4: __dst,
        a5: 3,
        a6: 1);
      *(_OWORD *)v186 = 0; /*0x1066fff3f*/
      *(_OWORD *)__src = 0; /*0x1066fff47*/
      LODWORD(v186[2]) = 1065353216; /*0x1066fff4f*/
      std::string::basic_string[abi:ne200100]<0>(a1: v205, a2: "gameJoinFailureReason", a3: v46, a4: v47); /*0x1066fff6a*/
      v194[0] = (std::__shared_weak_count *)v205; /*0x1066fff76*/
      v48 = std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1066fff91*/
              a1: __src,
              a2: v205,
              a3: std::piecewise_construct,
              a4: v194,
              a5: v192);
      std::string::assign(a1: v48 + 40, a2: "ProtocolMistmatch"); /*0x1066fffa4*/
      if ( ((__int64)v205[0] & 1) != 0 ) /*0x1066fffb0*/
        operator delete(a1: (RBX::Memory *)v206[0], a2: v51); /*0x1066fffb9*/
      std::string::basic_string[abi:ne200100]<0>(a1: v156, a2: "client", a3: v49, a4: v50); /*0x1066fffcc*/
      std::string::basic_string[abi:ne200100]<0>(a1: v158, a2: "report", a3: v52, a4: v53); /*0x1066fffdf*/
      std::string::basic_string[abi:ne200100]<0>(a1: v160, a2: "GameJoinFailure", a3: v54, a4: v55); /*0x1066ffff2*/
      v56 = *(_QWORD *)__src; /*0x1066ffff7*/
      v57 = *(_QWORD *)&__src[8]; /*0x1066ffffe*/
      *(_OWORD *)__src = 0; /*0x106700009*/
      v151[0] = v56; /*0x106700011*/
      v151[1] = v57; /*0x106700018*/
      qmemcpy(v152, v186, 20); /*0x106700026*/
      if ( v186[1] != nullptr ) /*0x10670004e*/
      {
        v58 = *((_QWORD *)v186[0] + 1); /*0x106700062*/
        if ( ((v57 - 1) & v57) != 0 ) /*0x10670006d*/
        {
          if ( v58 >= v57 ) /*0x10670070b*/
            v58 %= v57; /*0x106700712*/
        }
        else
        {
          v58 &= v57 - 1; /*0x106700073*/
        }
        *(_QWORD *)(v56 + 8 * v58) = v152; /*0x106700715*/
        *(_OWORD *)v186 = 0; /*0x10670071d*/
      }
      RBX::Analytics::EventIngest::setRBXEvent(a1: v156, a2: v158, a3: v160, a4: v151); /*0x10670073d*/
      std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::~__hash_table(a1: v151); /*0x106700749*/
      if ( (v160[0] & 1) != 0 ) /*0x106700755*/
        operator delete(a1: (RBX::Memory *)v161, a2: v101); /*0x10670075e*/
      if ( (v158[0] & 1) != 0 ) /*0x10670076a*/
        operator delete(a1: (RBX::Memory *)v159, a2: v101); /*0x106700773*/
      if ( (v156[0] & 1) != 0 ) /*0x10670077f*/
        operator delete(a1: (RBX::Memory *)v157, a2: v101); /*0x106700788*/
      std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::~__hash_table(a1: __src); /*0x106700794*/
      if ( (v189 & 1) != 0 ) /*0x1067007a0*/
        operator delete(a1: (RBX::Memory *)v190[0], a2: v102); /*0x1067007ad*/
LABEL_126:
      v8 = 1; /*0x1067008c2*/
      break; /*0x1067008c8*/
  }
LABEL_220:
  RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: v172); /*0x106701023*/
  RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: v171); /*0x106701036*/
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v4, a2: v145); /*0x10670103d*/
  return v8; /*0x106701055*/
}

// Address: 0x106701568 | Name: __ZN3RBX7Network16ClientReplicator34stringToHtmlFileDumpToLogDirHelperERN5boost10filesystem4pathERKNSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEE
__int64 __fastcall RBX::Network::ClientReplicator::stringToHtmlFileDumpToLogDirHelper(
        __int64 a1,
        boost::filesystem::path *a2,
        unsigned __int8 *a3)
{
  tm *v6; // rax
  RBX::LogGuid *v7; // rdi
  void *v8; // rsi
  __int64 RBXLogPrefix; // rax
  __int64 v10; // r8
  __int64 v11; // r9
  __m128 v12; // xmm0
  __m128 v13; // xmm1
  __m128 v14; // xmm2
  __m128 v15; // xmm3
  __m128 v16; // xmm4
  __m128 v17; // xmm5
  __m128 v18; // xmm6
  __m128 v19; // xmm7
  void *v20; // rsi
  RBX::Memory *v21; // rdi
  __int64 v22; // rax
  __int64 v23; // rax
  const boost::filesystem::path *v24; // rsi
  unsigned int v25; // r12d
  FILE *v26; // rax
  FILE *v27; // r14
  unsigned int v28; // esi
  size_t v29; // rsi
  const void *v30; // rbx
  char v32; // [rsp+0h] [rbp-F0h]
  time_t v33; // [rsp+8h] [rbp-E8h] BYREF
  __int128 v34; // [rsp+10h] [rbp-E0h] BYREF
  void *v35; // [rsp+20h] [rbp-D0h]
  _BYTE v36[16]; // [rsp+28h] [rbp-C8h] BYREF
  void *v37; // [rsp+38h] [rbp-B8h]
  __int128 v38; // [rsp+40h] [rbp-B0h] BYREF
  void *v39; // [rsp+50h] [rbp-A0h]
  __int128 v40; // [rsp+60h] [rbp-90h] BYREF
  RBX::LogGuid *v41; // [rsp+70h] [rbp-80h]
  char v42[16]; // [rsp+80h] [rbp-70h] BYREF
  __int128 v43; // [rsp+90h] [rbp-60h]
  __int128 v44; // [rsp+A0h] [rbp-50h]
  __int128 v45; // [rsp+B0h] [rbp-40h]

  v33 = time(a1: nullptr); /*0x10670159f*/
  v45 = 0; /*0x1067015a5*/
  v44 = 0; /*0x1067015a9*/
  v43 = 0; /*0x1067015ad*/
  *(_OWORD *)v42 = 0; /*0x1067015b1*/
  v6 = localtime(a1: &v33); /*0x1067015b5*/
  strftime(a1: v42, a2: 0x40u, a3: "microprofile_%Y%m%d-%H%M%S.html", a4: v6); /*0x1067015cd*/
  v38 = 0; /*0x1067015dc*/
  v39 = nullptr; /*0x1067015df*/
  RBX::getRBXLogGUID(a1: (__int64)&v38); /*0x1067015e7*/
  RBX::FileSystem::getLogsDirectory(this: (RBX::FileSystem *)&v40); /*0x1067015f3*/
  std::string::operator=(a1: a2, a2: &v40); /*0x106701602*/
  if ( (v40 & 1) != 0 ) /*0x10670160e*/
    operator delete(a1: v41, a2: v8); /*0x106701614*/
  if ( DFFlag::UseVerboseLogPrefixEverywhere == 1 ) /*0x106701623*/
  {
    RBXLogPrefix = RBX::LogGuid::getRBXLogPrefix(this: v7); /*0x106701625*/
    RBX::format( /*0x106701641*/
      this: (RBX *)&v40,
      a2: "%s_%s",
      a3: RBXLogPrefix,
      a4: (__int64)v42,
      a5: v10,
      a6: v11,
      a7: v12,
      a8: v13,
      a9: v14,
      a10: v15,
      a11: v16,
      a12: v17,
      a13: v18,
      a14: v19,
      a15: v32);
    boost::filesystem::path::operator/=(this: a2, a2: &v40); /*0x106701650*/
    if ( (v40 & 1) == 0 ) /*0x10670165c*/
      goto LABEL_13; /*0x10670165c*/
    v21 = v41; /*0x106701662*/
    goto LABEL_12; /*0x106701666*/
  }
  std::operator+<char>(a1: v36, a2: "log_", &v38); /*0x106701680*/
  v22 = std::string::append(a1: v36, a2: "_"); /*0x106701693*/
  v35 = *(void **)(v22 + 16); /*0x1067016a3*/
  v34 = *(_OWORD *)v22; /*0x1067016aa*/
  *(_OWORD *)v22 = 0; /*0x1067016b0*/
  *(_QWORD *)(v22 + 16) = 0; /*0x1067016b3*/
  v23 = std::string::append(a1: &v34, a2: v42); /*0x1067016bf*/
  v41 = *(RBX::LogGuid **)(v23 + 16); /*0x1067016cf*/
  v40 = *(_OWORD *)v23; /*0x1067016d6*/
  *(_OWORD *)v23 = 0; /*0x1067016dc*/
  *(_QWORD *)(v23 + 16) = 0; /*0x1067016df*/
  boost::filesystem::path::operator/=(this: a2, a2: &v40); /*0x1067016ea*/
  if ( (v40 & 1) != 0 ) /*0x1067016f6*/
    operator delete(a1: v41, a2: v20); /*0x1067016fc*/
  if ( (v34 & 1) != 0 ) /*0x106701708*/
    operator delete(a1: (RBX::Memory *)v35, a2: v20); /*0x106701711*/
  if ( (v36[0] & 1) != 0 ) /*0x10670171d*/
  {
    v21 = (RBX::Memory *)v37; /*0x10670171f*/
LABEL_12:
    operator delete(a1: v21, a2: v20); /*0x106701726*/
  }
LABEL_13:
  LODWORD(v40) = 0; /*0x10670172b*/
  *((_QWORD *)&v40 + 1) = boost::system::system_category(); /*0x10670173f*/
  v25 = RBX::FileSystem::exists(a1: a2, a2: &v40); /*0x10670174f*/
  if ( (_BYTE)v25 != 0 ) /*0x106701754*/
  {
    *(_BYTE *)(a1 + 18384) = 0; /*0x106701756*/
  }
  else
  {
    v26 = (FILE *)RBX::FileSystem::openFileWrite(this: a2, a2: v24); /*0x106701763*/
    v27 = v26; /*0x106701768*/
    if ( v26 != nullptr ) /*0x10670176e*/
    {
      v28 = *a3; /*0x106701770*/
      if ( (v28 & 1) != 0 ) /*0x106701777*/
      {
        v29 = *((_QWORD *)a3 + 1); /*0x106701779*/
        v30 = *((const void **)a3 + 2); /*0x10670177d*/
      }
      else
      {
        v30 = a3 + 1; /*0x106701783*/
        v29 = v28 >> 1; /*0x106701786*/
      }
      fwrite(a1: v30, a2: v29, a3: 1u, a4: v26); /*0x106701793*/
      fclose(a1: v27); /*0x10670179b*/
    }
  }
  if ( (v38 & 1) != 0 ) /*0x1067017a7*/
    operator delete(a1: (RBX::Memory *)v39, a2: v24); /*0x1067017b0*/
  LOBYTE(v25) = v25 ^ 1; /*0x1067017c5*/
  return v25; /*0x1067017cc*/
}

// Address: 0x106701870 | Name: __ZN3RBX7Network16ClientReplicator21readDynLuaChallengeV2ENS0_14IncomingPacketERjS3_RNS_15ProtectedStringE
void __fastcall RBX::Network::ClientReplicator::readDynLuaChallengeV2(
        RBX::Network::Replicator *a1,
        RBX::Network::IncomingPacket *a2,
        _DWORD *a3,
        _DWORD *a4,
        __int64 a5)
{
  unsigned __int8 *v8; // rbx
  unsigned int v9; // eax
  int UInt32; // eax
  __int64 v11; // rdx
  __int64 v12; // rcx
  const char *v13; // rsi
  __int64 v14; // r8
  __int64 v15; // r9
  __m128 v16; // xmm0
  __m128 v17; // xmm1
  __m128 v18; // xmm2
  __m128 v19; // xmm3
  __m128 v20; // xmm4
  __m128 v21; // xmm5
  __m128 v22; // xmm6
  __m128 v23; // xmm7
  void *v24; // rsi
  char v25; // [rsp+0h] [rbp-B0h]
  char v26[64]; // [rsp+8h] [rbp-A8h] BYREF
  _BYTE v27[16]; // [rsp+48h] [rbp-68h] BYREF
  void *v28; // [rsp+58h] [rbp-58h]
  _BYTE v29[8]; // [rsp+60h] [rbp-50h] BYREF
  _BYTE v30[16]; // [rsp+68h] [rbp-48h] BYREF
  _DWORD *v31; // [rsp+78h] [rbp-38h]
  __int64 v32; // [rsp+80h] [rbp-30h]

  v32 = a5; /*0x106701884*/
  v31 = a4; /*0x106701888*/
  v8 = (unsigned __int8 *)RBX::Network::IncomingPacket::data(this: a2); /*0x10670189d*/
  v9 = RBX::Network::IncomingPacket::size(this: a2); /*0x1067018a3*/
  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)v26, a2: v8, a3: v9, a4: false); /*0x1067018b9*/
  RBX::Network::NetworkStream::IgnoreBytes(this: (RBX::Network::NetworkStream *)v26, a2: 1u); /*0x1067018c6*/
  *a3 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v26); /*0x1067018d7*/
  UInt32 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v26); /*0x1067018e2*/
  *v31 = UInt32; /*0x1067018eb*/
  RBX::Network::Replicator::getReadPayloadLimit(this: a1); /*0x1067018f0*/
  RBX::Network::NetworkStream::readString(this: (RBX::Network::NetworkStream *)v27, a2: (int)v26); /*0x106701902*/
  if ( RBX::Network::IncomingPacket::getRakNetPacket(this: a2) != 0 && *((_QWORD *)a1 + 1809) == 0 ) /*0x10670191d*/
    RBX::throw_runtime_error( /*0x106701981*/
      this: (RBX *)"Bytecode Auth Check missing or wrong version.",
      a2: v13,
      a3: v11,
      a4: v12,
      a5: v14,
      a6: v15,
      a7: v16,
      a8: v17,
      a9: v18,
      a10: v19,
      a11: v20,
      a12: v21,
      a13: v22,
      a14: v23,
      a15: v25);
  RBX::ProtectedString::fromBytecode(a1: v29, a2: v27); /*0x106701927*/
  RBX::ProtectedString::operator=(a1: v32, a2: (__int64)v29); /*0x106701934*/
  RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: v30); /*0x10670193d*/
  RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: v29); /*0x106701946*/
  if ( (v27[0] & 1) != 0 ) /*0x10670194f*/
    operator delete(a1: (RBX::Memory *)v28, a2: v24); /*0x106701955*/
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v26); /*0x106701961*/
}

// Address: 0x1067019ce | Name: __ZN3RBX7Network16ClientReplicator28computeAndSendDynLuaResponseEjjRNS_15ProtectedStringE
void __fastcall RBX::Network::ClientReplicator::computeAndSendDynLuaResponse(
        RBX::Network::ConcurrentRakPeer **this,
        int a2,
        int a3,
        RBX::ProtectedString *a4)
{
  __int64 v8; // rax
  __int64 v9; // r13
  _QWORD *v10; // r14
  __int64 v11; // rdi
  __int64 v12; // r14
  __int64 v13; // rdi
  __int64 v14; // rdi
  double *v15; // r12
  int v16; // r13d
  char v17; // r14
  double v18; // r13
  std::__shared_weak_count *v19; // r12
  RBX::Network *v20; // rdi
  unsigned __int64 v21; // rsi
  __int64 v22; // rbx
  __int64 v23; // r14
  std::__shared_weak_count *v24; // rbx
  __int64 v25; // r14
  _QWORD v26[8]; // [rsp+20h] [rbp-C0h] BYREF
  __int64 v27; // [rsp+60h] [rbp-80h] BYREF
  std::__shared_weak_count *v28; // [rsp+68h] [rbp-78h]
  double **v29; // [rsp+70h] [rbp-70h] BYREF
  std::__shared_weak_count *v30; // [rsp+78h] [rbp-68h]
  void **v31[6]; // [rsp+80h] [rbp-60h] BYREF
  int v32; // [rsp+B4h] [rbp-2Ch]

  v8 = RBX::ServiceProvider::find<RBX::ScriptContext>(a1: this); /*0x1067019ee*/
  if ( v8 != 0 ) /*0x1067019f6*/
  {
    v9 = v8; /*0x1067019fc*/
    std::vector<RBX::Reflection::Variant>::vector[abi:ne200100](a1: v26, a2: 2); /*0x106701a0b*/
    v32 = a3; /*0x106701a10*/
    *(double *)v31 = (double)a3; /*0x106701a1c*/
    v10 = (_QWORD *)v26[0]; /*0x106701a21*/
    *v10 = RBX::Reflection::Type::getSingleton<double>(a1: v11); /*0x106701a2d*/
    RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<double,(double *)0>(a1: v10 + 1, a2: v31); /*0x106701a3b*/
    *(double *)v31 = (double)a2; /*0x106701a4b*/
    v12 = v26[0]; /*0x106701a50*/
    *(_QWORD *)(v12 + 80) = RBX::Reflection::Type::getSingleton<double>(a1: v13); /*0x106701a5c*/
    RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<double,(double *)0>(a1: v12 + 88, a2: v31); /*0x106701a6b*/
    RBX::Security::Identity::Identity(a1: v31, a2: 2, a3: 0, a4: 0); /*0x106701a7d*/
    RBX::ScriptContext::callCallbackFromSource(a1: &v29, a2: v9, a3: v31, a4, a5: "challenge", a6: v26); /*0x106701aa1*/
    v15 = *v29; /*0x106701aaa*/
    v16 = 0; /*0x106701aad*/
    v17 = 1; /*0x106701ab0*/
    if ( *v29 != v29[1] ) /*0x106701ab7*/
    {
      v18 = *v15; /*0x106701ab9*/
      if ( RBX::Reflection::Type::getSingleton<double>(a1: v14) == *(_QWORD *)&v18 ) /*0x106701ac5*/
      {
        v16 = 0; /*0x106701ad2*/
        if ( *((_QWORD *)v15 + 1) != 0 ) /*0x106701ad8*/
        {
          v16 = (int)v15[2]; /*0x106701ada*/
          v17 = 0; /*0x106701ae1*/
        }
      }
      else
      {
        v16 = 0; /*0x106701ac7*/
      }
    }
    v19 = v30; /*0x106701ae4*/
    if ( v30 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v30 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106701afe*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v19 + 16LL))(a1: v19); /*0x106701b07*/
      std::__shared_weak_count::__release_weak(this: v19); /*0x106701b0d*/
    }
    v31[0] = (void **)v26; /*0x106701b16*/
    std::vector<RBX::Reflection::Variant>::__destroy_vector::operator()[abi:ne200100](a1: v31); /*0x106701b19*/
    if ( v17 == 0 ) /*0x106701b21*/
    {
      RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)v26); /*0x106701b31*/
      LOBYTE(v31[0]) = -101; /*0x106701b3a*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v26, a2: v31, a3: 1u); /*0x106701b45*/
      LODWORD(v31[0]) = v32; /*0x106701b51*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v26, a2: v31, a3: 4u); /*0x106701b5f*/
      LODWORD(v31[0]) = v16; /*0x106701b68*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v26, a2: v31, a3: 4u); /*0x106701b77*/
      if ( (unsigned __int8)RBX::Network::flagsSendsGoThroughConnection(this: v20) != 0 ) /*0x106701b83*/
      {
        v22 = (__int64)*(this + 35); /*0x106701b89*/
        v23 = operator new(a1: (RBX::Memory *)0x58, a2: v21); /*0x106701b9a*/
        *(_OWORD *)(v23 + 8) = 0; /*0x106701ba1*/
        *(_QWORD *)v23 = &off_10CAAE190; /*0x106701bad*/
        RBX::Network::NetworkStream::NetworkStream(a1: v23 + 24, a2: v26); /*0x106701bc1*/
        v27 = v23 + 24; /*0x106701bca*/
        v28 = (std::__shared_weak_count *)v23; /*0x106701bcd*/
        (*(void (__fastcall **)(__int64, __int64, __int64 *, _QWORD, _QWORD))(*(_QWORD *)v22 + 48LL))( /*0x106701be1*/
          a1: v22,
          a2: 1,
          a3: &v27,
          a4: 0,
          a5: 0);
        v24 = v28; /*0x106701be4*/
        if ( v28 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v28 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106701c01*/
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v24 + 16LL))(a1: v24); /*0x106701c09*/
          std::__shared_weak_count::__release_weak(this: v24); /*0x106701c0f*/
        }
      }
      else
      {
        v25 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *(this + 28)); /*0x106701c22*/
        RakNet::AddressOrGUID::AddressOrGUID( /*0x106701c33*/
          this: (RakNet::AddressOrGUID *)v31,
          a2: (const RakNet::SystemAddress *)(this + 30));
        (*(void (__fastcall **)(__int64, _QWORD *, __int64, __int64, _QWORD, void ***, _DWORD, _DWORD, _QWORD))(*(_QWORD *)v25 + 184LL))( /*0x106701c6f*/
          a1: v25,
          a2: v26,
          a3: 2,
          a4: 3,
          a5: 0,
          a6: v31,
          a7: 0,
          a8: 0,
          a9: 0);
      }
      RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v26); /*0x106701c78*/
    }
  }
}

// Address: 0x106701cf0 | Name: __ZNK3RBX7Network16ClientReplicator28getUnifiedJoinRxStatsEnabledEv
char __fastcall RBX::Network::ClientReplicator::getUnifiedJoinRxStatsEnabled(RBX::Network::ClientReplicator *this)
{
  return FFlag::ConnectViaConnectionInternal; /*0x106701cfd*/
}

// Address: 0x106701d00 | Name: __ZN3RBX7Network16ClientReplicator20OnReceive_deprecatedEPN6RakNet6PacketE
__int64 __fastcall RBX::Network::ClientReplicator::OnReceive_deprecated(
        RBX::Network::ClientReplicator *this,
        RakNet::SystemAddress *a2)
{
  unsigned int v4; // ebx
  RakNet *v5; // rdi
  unsigned __int8 *v6; // rsi
  unsigned int v7; // eax
  unsigned int v8; // r12d
  int v9; // edx
  int v10; // ecx
  int v11; // r8d
  int v12; // r9d
  unsigned __int64 v13; // rsi
  RBX::Network::Item *v14; // r15
  __int64 v15; // r12
  RBX::TaskScheduler *v16; // rdi
  RBX::TaskScheduler *v17; // rdi
  RBX::Profiler *v18; // rdi
  int v19; // esi
  RBX::Security::SessionCrypto *v20; // rdi
  __int64 v21; // rcx
  __int64 v22; // r8
  __int64 v23; // r9
  __m128 v24; // xmm0
  __m128 v25; // xmm1
  __m128 v26; // xmm2
  __m128 v27; // xmm3
  __m128 v28; // xmm4
  __m128 v29; // xmm5
  __m128 v30; // xmm6
  __m128 v31; // xmm7
  char *v32; // rdx
  void *v33; // rsi
  void *v34; // rsi
  int v35; // r8d
  int v36; // r9d
  const char *v37; // rcx
  int Int32; // r15d
  int v39; // r12d
  unsigned int PayloadLimit; // eax
  void *v41; // rsi
  void *v42; // rsi
  int v43; // r8d
  int v44; // r9d
  unsigned int v45; // ecx
  const char *v46; // rcx
  __int64 v47; // r14
  __int64 v48; // r12
  __int64 v49; // rdi
  __int64 v50; // rax
  void *v51; // rsi
  __int64 v52; // rdx
  __int64 v53; // rcx
  __int64 v54; // rax
  __int64 v55; // rdx
  __int64 v56; // rcx
  void *v57; // rsi
  __int64 v58; // rdx
  __int64 v59; // rcx
  __int64 v60; // rdx
  __int64 v61; // rcx
  void *v62; // rsi
  __m128i *v63; // rdi
  __int64 v64; // rdx
  __int64 v65; // rcx
  void *v66; // rsi
  char v67; // r12
  char *v68; // r13
  bool v69; // zf
  const char *v70; // r12
  void *v71; // rsi
  std::__shared_weak_count *v72; // r13
  __int64 v73; // rdi
  __int64 v74; // r14
  __int64 v75; // r12
  __int64 v76; // rax
  void *v77; // rsi
  __int64 v78; // rdx
  __int64 v79; // rcx
  __int64 v80; // rax
  __int64 v81; // rdx
  __int64 v82; // rcx
  void *v83; // rsi
  __int64 v84; // rdx
  __int64 v85; // rcx
  __int64 v86; // rdx
  __int64 v87; // rcx
  void *v88; // rsi
  void *v89; // rsi
  __int8 *v90; // rdx
  const char *v91; // r8
  __int8 *v92; // rdx
  char *v93; // rcx
  __int64 v94; // rsi
  char *v95; // rdi
  __int64 v96; // rax
  void *v97; // rsi
  std::__shared_weak_count *v98; // r14
  __int64 v99; // r15
  unsigned __int8 LuaKickIncludesMetadata; // al
  tm *v101; // rax
  RBX::LogGuid *v102; // rdi
  void *v103; // rsi
  __int64 RBXLogPrefix; // rax
  __int64 v105; // r8
  __int64 v106; // r9
  __m128 v107; // xmm0
  __m128 v108; // xmm1
  __m128 v109; // xmm2
  __m128 v110; // xmm3
  __m128 v111; // xmm4
  __m128 v112; // xmm5
  __m128 v113; // xmm6
  __m128 v114; // xmm7
  void *v115; // rsi
  RBX::Memory *v116; // rdi
  std::__shared_weak_count *v117; // r14
  __int64 v118; // rax
  __int64 v119; // rax
  char v120; // r12
  FILE *v121; // rax
  FILE *v122; // r13
  MicroProfileRawFormat *v123; // rax
  MicroProfileRawFormat *v124; // r15
  char *v125; // rsi
  char *v126; // rdi
  size_t v127; // rsi
  void *v128; // rsi
  unsigned int v129; // esi
  char v131; // [rsp+0h] [rbp-6F0h]
  _BYTE v132[40]; // [rsp+8h] [rbp-6E8h] BYREF
  _BYTE v133[40]; // [rsp+30h] [rbp-6C0h] BYREF
  time_t v134; // [rsp+58h] [rbp-698h] BYREF
  __m128i v135; // [rsp+60h] [rbp-690h] BYREF
  void *v136; // [rsp+70h] [rbp-680h]
  _BYTE v137[16]; // [rsp+80h] [rbp-670h] BYREF
  void *v138; // [rsp+90h] [rbp-660h]
  _BYTE v139[16]; // [rsp+98h] [rbp-658h] BYREF
  void *v140; // [rsp+A8h] [rbp-648h]
  _BYTE v141[16]; // [rsp+B0h] [rbp-640h] BYREF
  void *v142; // [rsp+C0h] [rbp-630h]
  _BYTE v143[16]; // [rsp+C8h] [rbp-628h] BYREF
  void *v144; // [rsp+D8h] [rbp-618h]
  _BYTE v145[16]; // [rsp+E0h] [rbp-610h] BYREF
  void *v146; // [rsp+F0h] [rbp-600h]
  _BYTE v147[16]; // [rsp+F8h] [rbp-5F8h] BYREF
  void *v148; // [rsp+108h] [rbp-5E8h]
  _BYTE v149[16]; // [rsp+110h] [rbp-5E0h] BYREF
  void *v150; // [rsp+120h] [rbp-5D0h]
  _BYTE v151[16]; // [rsp+128h] [rbp-5C8h] BYREF
  void *v152; // [rsp+138h] [rbp-5B8h]
  std::__shared_weak_count *v153[2]; // [rsp+140h] [rbp-5B0h] BYREF
  _BYTE v154[8]; // [rsp+158h] [rbp-598h] BYREF
  _BYTE v155[16]; // [rsp+160h] [rbp-590h] BYREF
  __m128i v156; // [rsp+170h] [rbp-580h] BYREF
  void *v157; // [rsp+180h] [rbp-570h]
  __m128i v158; // [rsp+190h] [rbp-560h] BYREF
  void *v159; // [rsp+1A0h] [rbp-550h]
  __m128i si128; // [rsp+1B0h] [rbp-540h] BYREF
  void *v161; // [rsp+1C0h] [rbp-530h]
  unsigned int v162; // [rsp+1C8h] [rbp-528h]
  unsigned int v163; // [rsp+1CCh] [rbp-524h]
  __m128i v164; // [rsp+1D0h] [rbp-520h] BYREF
  RBX::LogGuid *v165; // [rsp+1E0h] [rbp-510h]
  __m128i v166; // [rsp+1F0h] [rbp-500h] BYREF
  void *v167[2]; // [rsp+200h] [rbp-4F0h]
  int v168; // [rsp+210h] [rbp-4E0h]
  std::__shared_weak_count *v169[2]; // [rsp+230h] [rbp-4C0h] BYREF
  void *v170; // [rsp+240h] [rbp-4B0h]
  std::__shared_weak_count *v171[2]; // [rsp+250h] [rbp-4A0h] BYREF
  void *v172; // [rsp+260h] [rbp-490h]
  char v173[16]; // [rsp+270h] [rbp-480h] BYREF
  void *v174[2]; // [rsp+280h] [rbp-470h]
  __int128 v175; // [rsp+290h] [rbp-460h]
  __int128 v176; // [rsp+2A0h] [rbp-450h]
  char v177; // [rsp+2B0h] [rbp-440h] BYREF
  char v178; // [rsp+2B1h] [rbp-43Fh] BYREF
  void *v179; // [rsp+2C0h] [rbp-430h]
  unsigned int v180; // [rsp+2E0h] [rbp-410h]
  unsigned int v181; // [rsp+2E8h] [rbp-408h]

  v4 = RBX::Memory::setCurrentCategory( /*0x106701d36*/
         this: (RBX::Memory *)(unsigned int)RBX::Memory::NetworkReplicator,
         (unsigned int)a2);
  RBX::ProtectedString::ProtectedString(this: (RBX::ProtectedString *)v154); /*0x106701d3f*/
  v6 = *((unsigned __int8 **)a2 + 7); /*0x106701d44*/
  v7 = *v6; /*0x106701d48*/
  v8 = 0; /*0x106701d4b*/
  if ( v7 <= 0x8D )
  {
    if ( v7 == 14 ) /*0x106701dfe*/
    {
      RBX::Network::Replicator::processAckPacket_deprecated(a1: this, a2); /*0x106701eba*/
    }
    else if ( v7 == 16 ) /*0x106701e07*/
    {
      if ( FFlag::DebugClientDumpMicroprofileForJoins != 0 /*0x106701ede*/
        || (unsigned __int8)RBX::Analytics::InfluxDb::canSend(
                              this: (RBX::Analytics::InfluxDb *)(unsigned int)DFInt::ClientReportInitExpJobStatsHundredthPercent,
                              a2: (int)v6) != 0 )
      {
        RBX::Profiler::notifyActiveCapture(this: nullptr, a2: (bool)v6); /*0x106701ee2*/
      }
      *((_QWORD *)this + 2986) = RBX::TaskScheduler::cycle(this: v17); /*0x106701eec*/
      if ( FFlag::DebugClientDumpMicroprofileForJoins == 1 ) /*0x106701ef7*/
      {
        *((_DWORD *)this + 5974) = RBX::Profiler::getAggregateFrames(this: v18); /*0x106701efe*/
        RBX::Profiler::setAggregateFrames(this: nullptr, a2: v19); /*0x106701f07*/
      }
      v20 = *((RBX::Security::SessionCrypto **)this + 1809); /*0x106701f0c*/
      v8 = 1; /*0x106701f13*/
      if ( v20 != nullptr ) /*0x106701f1c*/
        RBX::Security::SessionCrypto::resetKeyExchangeKeys(this: v20, a2: false); /*0x106701f24*/
    }
    else
    {
      if ( v7 == 131 ) /*0x106701e12*/
      {
        if ( DFInt::ReportClientJoinRxStatsHundrethsPercentage != 0 ) /*0x106701e1f*/
        {
          v15 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)this + 28)); /*0x106701e2d*/
          RakNet::AddressOrGUID::AddressOrGUID( /*0x106701e3e*/
            this: (RakNet::AddressOrGUID *)&v177,
            a2: (RBX::Network::ClientReplicator *)((char *)this + 240));
          if ( (*(unsigned __int8 (__fastcall **)(__int64, char *))(*(_QWORD *)v15 + 744LL))(a1: v15, a2: &v177) != 0 ) /*0x106701e59*/
            *(_QWORD *)((char *)this + 15652) = _mm_add_epi32( /*0x106701e79*/
                                                  _mm_insert_epi32(_mm_cvtepi8_epi32(16843009), *((_DWORD *)a2 + 12), 0),
                                                  _mm_loadl_epi64((const __m128i *)((char *)this + 15652))).u64[0];
        }
        if ( *((_DWORD *)this + 3899) == 0 ) /*0x106701e8a*/
        {
          *((_DWORD *)this + 3899) = RakNet::GetTimeMS(this: v5); /*0x106701e91*/
          *((_QWORD *)this + 1950) = RBX::TaskScheduler::cycle(this: v16); /*0x106701e9d*/
        }
      }
LABEL_25:
      v8 = RBX::Network::Replicator::OnReceive_deprecated(this, a2); /*0x106701f67*/
    }
  }
  else
  {
    switch ( *v6 )
    {
      case 0x92u:
        RBX::Network::NetworkStream::NetworkStream( /*0x106701d85*/
          this: (RBX::Network::NetworkStream *)&v166,
          a2: v6,
          a3: *((_DWORD *)a2 + 12),
          a4: false);
        RBX::Network::NetworkStream::IgnoreBytes(this: (RBX::Network::NetworkStream *)&v166, a2: 1u); /*0x106701d96*/
        if ( (unsigned __int8)RBX::Network::NetworkStream::readBool(this: (RBX::Network::NetworkStream *)&v166) != 0 ) /*0x106701da9*/
        {
          RBX::CreatorLog::printf( /*0x106701dbd*/
            a1: 1,
            a2: (unsigned int)"Waiting for server to authenticate the placeID before spawning...",
            a3: v9,
            a4: v10,
            a5: v11,
            a6: v12);
          v14 = (RBX::Network::Item *)operator new(a1: (RBX::Memory *)0x40, a2: v13); /*0x106701dcc*/
          RBX::Network::Item::Item(this: v14, a2: this); /*0x106701dd5*/
          *(_QWORD *)v14 = off_10CAA7EA8; /*0x106701de8*/
          RBX::Network::ItemQueue::push_back(this: (RBX::Network::ClientReplicator *)((char *)this + 14536), a2: v14); /*0x106701df1*/
        }
        else
        {
          RBX::CreatorLog::printf( /*0x1067022fc*/
            a1: 3,
            a2: (unsigned int)"Place ID verification failed.",
            a3: v9,
            a4: v10,
            a5: v11,
            a6: v12);
          v47 = *((_QWORD *)this + 13); /*0x106702301*/
          v48 = *(_QWORD *)(v47 + 24); /*0x106702305*/
          v50 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>(a1: v49); /*0x106702309*/
          if ( *(unsigned __int16 *)(v48 + 440) - (unsigned int)*(unsigned __int16 *)(v50 + 440) > *(unsigned __int16 *)(v50 + 442) ) /*0x10670232b*/
            v47 = 0; /*0x10670232b*/
          RBX::Network::RakNetAddressToString(this: (RBX::Network *)&v177, a2, a3: true, a4: 124); /*0x106702343*/
          RBX::Network::Client::requestDisconnectOnTransportFailure(a1: v47, a2: (__int64)&v177, a3: 0x107u); /*0x106702357*/
          if ( (v177 & 1) != 0 ) /*0x106702363*/
            operator delete(a1: (RBX::Memory *)v179, a2: v51); /*0x10670236c*/
          RakNet::SystemAddress::ToStringN(this: a2, a2: true, a3: &v177, a4: 1025, a5: 124); /*0x10670238b*/
          RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x1067023b2*/
            this: (RBX::Network::ConcurrentRakPeer **)v47,
            a2: "PlaceIdFailedVerification",
            a3: 1u,
            a4: &v177,
            a5: 3,
            a6: 1);
          *(_OWORD *)v174 = 0; /*0x1067023bb*/
          *(_OWORD *)v173 = 0; /*0x1067023c3*/
          LODWORD(v175) = 1065353216; /*0x1067023cb*/
          std::string::basic_string[abi:ne200100]<0>(a1: v171, a2: "gameJoinFailureReason", a3: v52, a4: v53); /*0x1067023e6*/
          v169[0] = (std::__shared_weak_count *)v171; /*0x1067023f2*/
          v54 = std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x10670240d*/
                  a1: v173,
                  a2: v171,
                  a3: std::piecewise_construct,
                  a4: v169,
                  a5: &si128);
          std::string::assign(a1: v54 + 40, a2: "PlaceIdFailedVerification"); /*0x106702420*/
          if ( ((__int64)v171[0] & 1) != 0 ) /*0x10670242c*/
            operator delete(a1: (RBX::Memory *)v172, a2: v57); /*0x106702435*/
          std::string::basic_string[abi:ne200100]<0>(a1: v145, a2: "client", a3: v55, a4: v56); /*0x106702448*/
          std::string::basic_string[abi:ne200100]<0>(a1: v147, a2: "report", a3: v58, a4: v59); /*0x10670245b*/
          std::string::basic_string[abi:ne200100]<0>(a1: v149, a2: "GameJoinFailure", a3: v60, a4: v61); /*0x10670246e*/
          std::unordered_map<std::string,std::string>::unordered_map(a1: v133, a2: v173); /*0x106702481*/
          RBX::Analytics::EventIngest::setRBXEvent(a1: v145, a2: v147, a3: v149, a4: v133); /*0x1067024a2*/
          std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::~__hash_table(a1: v133); /*0x1067024ae*/
          if ( (v149[0] & 1) != 0 ) /*0x1067024ba*/
            operator delete(a1: (RBX::Memory *)v150, a2: v62); /*0x1067024c3*/
          if ( (v147[0] & 1) != 0 ) /*0x1067024cf*/
            operator delete(a1: (RBX::Memory *)v148, a2: v62); /*0x1067024d8*/
          if ( (v145[0] & 1) != 0 ) /*0x1067024e4*/
            operator delete(a1: (RBX::Memory *)v146, a2: v62); /*0x1067024ed*/
          std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::~__hash_table(a1: v173); /*0x1067024f9*/
        }
        v63 = &v166; /*0x1067024fe*/
        goto LABEL_185; /*0x106702505*/
      case 0x93u:
        RBX::Network::NetworkStream::NetworkStream( /*0x1067020d7*/
          this: (RBX::Network::NetworkStream *)&v177,
          a2: v6,
          a3: *((_DWORD *)a2 + 12),
          a4: false);
        RBX::Network::NetworkStream::IgnoreBytes(this: (RBX::Network::NetworkStream *)&v177, a2: 1u); /*0x1067020e8*/
        RBX::Network::NetworkStream::IgnoreBytes(this: (RBX::Network::NetworkStream *)&v177, a2: 1u); /*0x1067020f9*/
        if ( v181 < v180 ) /*0x10670210a*/
          (*(void (__fastcall **)(RBX::Network::ClientReplicator *, char *))(*(_QWORD *)this + 1368LL))( /*0x106702119*/
            a1: this,
            a2: &v177);
        RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)&v177); /*0x106702126*/
        goto LABEL_91; /*0x10670212b*/
      case 0x94u:
      case 0x95u:
      case 0x96u:
      case 0x97u:
      case 0x99u:
      case 0x9Cu:
      case 0x9Du:
      case 0x9Eu:
      case 0x9Fu:
      case 0xA0u:
      case 0xA1u:
        goto LABEL_25;
      case 0x98u:
        RBX::Network::NetworkStream::NetworkStream( /*0x106701f87*/
          this: (RBX::Network::NetworkStream *)&v177,
          a2: v6,
          a3: *((_DWORD *)a2 + 12),
          a4: false);
        RBX::Network::NetworkStream::IgnoreBytes(this: (RBX::Network::NetworkStream *)&v177, a2: 1u); /*0x106701f98*/
        v166 = 0; /*0x106701fa1*/
        v167[0] = nullptr; /*0x106701fab*/
        v174[0] = nullptr; /*0x106701fb2*/
        *(_OWORD *)v173 = 0; /*0x106701fb9*/
        if ( (unsigned __int8)RBX::Network::Replicator::getLuaKickIncludesMetadata(this) != 0 )
        {
          RBX::Network::Replicator::getReadPayloadLimit(this); /*0x106701fd4*/
          RBX::Network::NetworkStream::readString(this: (RBX::Network::NetworkStream *)v171, a2: (int)&v177); /*0x106701ff7*/
          if ( (v166.i8[0] & 1) != 0 ) /*0x106702003*/
            operator delete(a1: (RBX::Memory *)v167[0], a2: v33); /*0x10670200c*/
          v167[0] = v172; /*0x106702018*/
          v166 = _mm_loadu_si128((const __m128i *)v171); /*0x106702027*/
          RBX::Network::Replicator::getReadPayloadLimit(this); /*0x106702032*/
          RBX::Network::NetworkStream::readString(this: (RBX::Network::NetworkStream *)v171, a2: (int)&v177); /*0x106702055*/
          if ( (v173[0] & 1) != 0 ) /*0x106702061*/
            operator delete(a1: (RBX::Memory *)v174[0], a2: v34); /*0x10670206a*/
          v174[0] = v172; /*0x106702076*/
          *(__m128i *)v173 = _mm_loadu_si128((const __m128i *)v171); /*0x106702085*/
          if ( (unsigned __int8)FLog::Player >= 6u && BYTE1(FLog::Player) >= 3u )
          {
            if ( (v166.i8[0] & 1) != 0 ) /*0x1067020b8*/
              v37 = (const char *)v167[0]; /*0x1067020be*/
            else
              v37 = &v166.i8[1]; /*0x1067028d4*/
            if ( (v173[0] & 1) != 0 ) /*0x1067028e6*/
              v91 = (const char *)v174[0]; /*0x1067028e8*/
            else
              v91 = &v173[1]; /*0x1067028f1*/
            FLog::FastLog(
              a1: *(_QWORD *)&FLog::Player,
              a2: qword_10D7F3D78,
              a3: "[FLog::Player] Server Kick Message: %s; Metadata: %s",
              v37,
              v91);
          }
          if ( (v166.i8[0] & 1) != 0 ) /*0x10670290e*/
            LODWORD(v92) = v167[0]; /*0x106702910*/
          else
            v92 = &v166.i8[1]; /*0x106702919*/
          if ( (v173[0] & 1) != 0 ) /*0x106702927*/
            LODWORD(v93) = v174[0]; /*0x106702929*/
          else
            v93 = &v173[1]; /*0x106702932*/
          RBX::CreatorLog::printf(
            a1: 3,
            a2: (unsigned int)"Server Kick Message: %s; Metadata: %s",
            a3: (_DWORD)v92,
            a4: (_DWORD)v93,
            a5: v35,
            a6: v36);
        }
        else
        {
          RBX::Network::Replicator::getReadPayloadLimit(this); /*0x106702260*/
          RBX::Network::NetworkStream::readString(this: (RBX::Network::NetworkStream *)v171, a2: (int)&v177); /*0x106702275*/
          if ( (v166.i8[0] & 1) != 0 ) /*0x106702281*/
            operator delete(a1: (RBX::Memory *)v167[0], a2: v42); /*0x10670228a*/
          v167[0] = v172; /*0x106702296*/
          v166 = _mm_loadu_si128((const __m128i *)v171); /*0x1067022a5*/
          v45 = (unsigned int)FLog::Player >> 8; /*0x1067022b9*/
          LOBYTE(v45) = (unsigned __int8)FLog::Player < 6u || BYTE1(FLog::Player) < 3u; /*0x1067022c9*/
          if ( (_BYTE)v45 == 0 )
          {
            if ( (v166.i8[0] & 1) != 0 ) /*0x1067022dc*/
              v46 = (const char *)v167[0]; /*0x1067022e2*/
            else
              v46 = &v166.i8[1]; /*0x106702893*/
            FLog::FastLog(
              a1: *(_QWORD *)&FLog::Player,
              a2: qword_10D7F3D78,
              a3: "[FLog::Player] Server Kick Message: %s",
              v46);
          }
          if ( (v166.i8[0] & 1) != 0 ) /*0x1067028ad*/
            LODWORD(v90) = v167[0]; /*0x1067028af*/
          else
            v90 = &v166.i8[1]; /*0x1067028b8*/
          RBX::CreatorLog::printf(
            a1: 3,
            a2: (unsigned int)"Server Kick Message: %s",
            a3: (_DWORD)v90,
            a4: v45,
            a5: v43,
            a6: v44);
        }
        *(_OWORD *)v171 = 0; /*0x106702950*/
        if ( (unsigned __int8)RBX::Network::Replicator::getLuaKickIncludesMetadata(this) == 0 ) /*0x106702962*/
          goto LABEL_128; /*0x106702962*/
        if ( (v173[0] & 1) != 0 ) /*0x106702971*/
        {
          v94 = *(_QWORD *)&v173[8]; /*0x106702985*/
          if ( *(_QWORD *)&v173[8] == 0 ) /*0x10670298f*/
            goto LABEL_128; /*0x10670298f*/
        }
        else
        {
          if ( v173[0] == 0 ) /*0x106702976*/
            goto LABEL_128; /*0x106702976*/
          v94 = *(_QWORD *)&v173[8]; /*0x10670297c*/
        }
        *(_OWORD *)v169 = 0; /*0x106702999*/
        if ( (v173[0] & 1) != 0 ) /*0x1067029a3*/
        {
          v95 = (char *)v174[0]; /*0x1067029a5*/
        }
        else
        {
          v95 = &v173[1]; /*0x1067029b0*/
          v94 = (unsigned __int8)v173[0] >> 1; /*0x1067029b7*/
        }
        if ( (unsigned __int8)RBX::WebParser::parseJSONTable(a1: v95, a2: v94, a3: v169, a4: 0, a5: 0) == 0
          && (unsigned __int8)FLog::Player >= 6u
          && (FLog::Player & 0xFE00) != 0 )
        {
          FLog::FastLogSafeFormatted<std::string &>(
            a1: FLog::Player,
            a2: qword_10D7F3D78,
            a3: 2,
            a4: (int)"[FLog::Player] Received invalid metadata JSON in kick event: {}",
            a5: 63,
            a6: (unsigned __int8 *)v173);
        }
        si128 = _mm_load_si128((const __m128i *)v169); /*0x106702a1e*/
        if ( v169[1] != nullptr ) /*0x106702a29*/
          _InterlockedIncrement64((volatile signed __int64 *)v169[1] + 1); /*0x106702a2b*/
        std::shared_ptr<RBX::Reflection::ValueTable>::operator=[abi:ne200100](a1: v171, a2: &si128); /*0x106702a41*/
        std::shared_ptr<RBX::Reflection::ValueTable>::~shared_ptr[abi:ne200100](a1: (__int64)&si128); /*0x106702a49*/
        std::shared_ptr<RBX::Reflection::ValueTable const>::~shared_ptr[abi:ne200100](a1: (__int64)v169); /*0x106702a55*/
LABEL_128:
        v96 = (*(__int64 (__fastcall **)(RBX::Network::ClientReplicator *))(*(_QWORD *)this + 688LL))(a1: this); /*0x106702a5a*/
        if ( v96 != 0 ) /*0x106702a69*/
        {
          *(__m128i *)v169 = _mm_load_si128((const __m128i *)v171); /*0x106702a80*/
          *(_OWORD *)v171 = 0; /*0x106702a88*/
          rbx::signal<void ()(std::string,std::shared_ptr<RBX::Reflection::ValueTable const>)>::invokeImpl<(rbx::SignalInvokePolicy)0>( /*0x106702a9a*/
            a1: v96 + 2704,
            a2: &v166);
          v98 = v169[1]; /*0x106702a9f*/
          if ( v169[1] != nullptr /*0x106702abf*/
            && _InterlockedExchangeAdd64((volatile signed __int64 *)v169[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
          {
            (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v98 + 16LL))(a1: v98); /*0x106702acb*/
            std::__shared_weak_count::__release_weak(this: v98); /*0x106702ad1*/
          }
        }
        else
        {
          v99 = RBX::ServiceProvider::find<RBX::GuiService>(a1: this); /*0x106702ae3*/
          if ( v99 != 0 ) /*0x106702ae9*/
          {
            LuaKickIncludesMetadata = RBX::Network::Replicator::getLuaKickIncludesMetadata(this); /*0x106702af2*/
            if ( ((v171[0] != nullptr) & LuaKickIncludesMetadata) == 1 ) /*0x106702b06*/
              RBX::GuiService::setErrorDetails(a1: v99, a2: v171); /*0x106702b12*/
            if ( (v166.i8[0] & 1) != 0 ) /*0x106702b1e*/
            {
              std::string::__init_copy_ctor_external(a1: &v156, a2: v167[0], a3: v166.i64[1]); /*0x106702c61*/
            }
            else
            {
              v157 = v167[0]; /*0x106702b2b*/
              v156 = _mm_load_si128(&v166); /*0x106702b3a*/
            }
            RBX::GuiService::setErrorMessage(a1: v99, a2: &v156, a3: 267); /*0x106702c75*/
            if ( (v156.i8[0] & 1) != 0 ) /*0x106702c81*/
              operator delete(a1: (RBX::Memory *)v157, a2: v97); /*0x106702c8a*/
          }
        }
        v117 = v171[1]; /*0x106702c8f*/
        if ( v171[1] != nullptr /*0x106702cab*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v171[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v117 + 16LL))(a1: v117); /*0x106702cb3*/
          std::__shared_weak_count::__release_weak(this: v117); /*0x106702cb9*/
        }
        if ( (v173[0] & 1) != 0 ) /*0x106702cc5*/
          operator delete(a1: (RBX::Memory *)v174[0], a2: v97); /*0x106702cce*/
        if ( (v166.i8[0] & 1) != 0 ) /*0x106702cda*/
          operator delete(a1: (RBX::Memory *)v167[0], a2: v97); /*0x106702ce7*/
        goto LABEL_184; /*0x106702cec*/
      case 0x9Au:
        if ( *((_BYTE *)this + 18384) != 1 ) /*0x106702138*/
          break; /*0x106702138*/
        *((_BYTE *)this + 18384) = 0; /*0x10670213e*/
        RBX::Network::NetworkStream::NetworkStream( /*0x106702153*/
          this: (RBX::Network::NetworkStream *)&v177,
          a2: v6,
          a3: *((_DWORD *)a2 + 12),
          a4: false);
        RBX::Network::NetworkStream::IgnoreBytes(this: (RBX::Network::NetworkStream *)&v177, a2: 1u); /*0x106702164*/
        Int32 = RBX::Network::NetworkStream::readInt32(this: (RBX::Network::NetworkStream *)&v177); /*0x106702175*/
        v39 = RBX::Network::NetworkStream::readInt32(this: (RBX::Network::NetworkStream *)&v177); /*0x106702184*/
        RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)&v166); /*0x10670218e*/
        RBX::Network::Replicator::decompressBitStream( /*0x1067021a3*/
          this: (RBX::Network::NetworkStream *)&v177,
          a2: (RBX::Network::NetworkStream *)&v166,
          a3: 0);
        *(_OWORD *)v171 = 0; /*0x1067021ac*/
        v172 = nullptr; /*0x1067021b4*/
        PayloadLimit = RBX::Network::Replicator::getReadPayloadLimit(this); /*0x1067021c2*/
        RBX::Network::deserializeString(a1: v171, a2: &v166, a3: PayloadLimit); /*0x1067021d7*/
        if ( ((__int64)v171[0] & 1) != 0 ) /*0x1067021e5*/
        {
          if ( v171[1] != (std::__shared_weak_count *)v39 ) /*0x106702846*/
          {
LABEL_182:
            operator delete(a1: (RBX::Memory *)v172, a2: v41); /*0x106702f6b*/
            goto LABEL_183; /*0x106702f72*/
          }
        }
        else if ( v39 != LOBYTE(v171[0]) >> 1 ) /*0x1067021f0*/
        {
          goto LABEL_183; /*0x1067021f0*/
        }
        *(_OWORD *)v169 = 0; /*0x106702850*/
        v170 = nullptr; /*0x106702858*/
        if ( DFFlag::ReplicatorClientRemoteProfilerDumpRefactor == 1 ) /*0x10670286a*/
        {
          if ( (unsigned __int8)RBX::Network::ClientReplicator::stringToHtmlFileDumpToLogDirHelper( /*0x106702888*/
                                  a1: (__int64)this,
                                  a2: (boost::filesystem::path *)v169,
                                  a3: (unsigned __int8 *)v171) == 0 )
            goto LABEL_179; /*0x106702888*/
          goto LABEL_174; /*0x106702888*/
        }
        v134 = time(a1: nullptr); /*0x106702b55*/
        v176 = 0; /*0x106702b5c*/
        v175 = 0; /*0x106702b64*/
        *(_OWORD *)v174 = 0; /*0x106702b6c*/
        *(_OWORD *)v173 = 0; /*0x106702b74*/
        v101 = localtime(a1: &v134); /*0x106702b7c*/
        strftime(a1: v173, a2: 0x40u, a3: "microprofile_%Y%m%d-%H%M%S.html", a4: v101); /*0x106702b97*/
        si128 = 0; /*0x106702ba7*/
        v161 = nullptr; /*0x106702bab*/
        RBX::getRBXLogGUID(a1: (__int64)&si128); /*0x106702bb3*/
        RBX::FileSystem::getLogsDirectory(this: (RBX::FileSystem *)&v164); /*0x106702bbf*/
        std::string::operator=(a1: v169, a2: &v164); /*0x106702bd2*/
        if ( (v164.i8[0] & 1) != 0 ) /*0x106702bde*/
          operator delete(a1: v165, a2: v103); /*0x106702be7*/
        if ( DFFlag::UseVerboseLogPrefixEverywhere == 1 ) /*0x106702bf6*/
        {
          RBXLogPrefix = RBX::LogGuid::getRBXLogPrefix(this: v102); /*0x106702bfc*/
          RBX::format( /*0x106702c1b*/
            this: (RBX *)&v164,
            a2: "%s_%s",
            a3: RBXLogPrefix,
            a4: (__int64)v173,
            a5: v105,
            a6: v106,
            a7: v107,
            a8: v108,
            a9: v109,
            a10: v110,
            a11: v111,
            a12: v112,
            a13: v113,
            a14: v114,
            a15: v131);
          boost::filesystem::path::operator/=(this: (boost::filesystem::path *)v169, a2: (__int128 *)v164.i8); /*0x106702c2e*/
          if ( (v164.i8[0] & 1) == 0 ) /*0x106702c3a*/
            goto LABEL_159; /*0x106702c3a*/
          v116 = v165; /*0x106702c40*/
          goto LABEL_158; /*0x106702c47*/
        }
        std::operator+<char>(a1: v151, a2: "log_", &si128); /*0x106702d06*/
        v118 = std::string::append(a1: v151, a2: "_"); /*0x106702d19*/
        v136 = *(void **)(v118 + 16); /*0x106702d29*/
        v135 = _mm_loadu_si128((const __m128i *)v118); /*0x106702d31*/
        *(_OWORD *)v118 = 0; /*0x106702d39*/
        *(_QWORD *)(v118 + 16) = 0; /*0x106702d3d*/
        v119 = std::string::append(a1: &v135, a2: v173); /*0x106702d4c*/
        v165 = *(RBX::LogGuid **)(v119 + 16); /*0x106702d5c*/
        v164 = _mm_loadu_si128((const __m128i *)v119); /*0x106702d64*/
        *(_OWORD *)v119 = 0; /*0x106702d6c*/
        *(_QWORD *)(v119 + 16) = 0; /*0x106702d70*/
        boost::filesystem::path::operator/=(this: (boost::filesystem::path *)v169, a2: (__int128 *)v164.i8); /*0x106702d7f*/
        if ( (v164.i8[0] & 1) != 0 ) /*0x106702d8b*/
          operator delete(a1: v165, a2: v115); /*0x106702d94*/
        if ( (v135.i8[0] & 1) != 0 ) /*0x106702da0*/
          operator delete(a1: (RBX::Memory *)v136, a2: v115); /*0x106702da9*/
        if ( (v151[0] & 1) != 0 ) /*0x106702db5*/
        {
          v116 = (RBX::Memory *)v152; /*0x106702db7*/
LABEL_158:
          operator delete(a1: v116, a2: v115); /*0x106702dbe*/
        }
LABEL_159:
        v164.i32[0] = 0; /*0x106702dc3*/
        v164.i64[1] = (__int64)boost::system::system_category(); /*0x106702dd7*/
        v120 = RBX::FileSystem::exists(a1: v169, a2: &v164); /*0x106702deb*/
        if ( v120 != 0 ) /*0x106702df0*/
        {
          *((_BYTE *)this + 18384) = 0; /*0x106702df2*/
        }
        else
        {
          v121 = (FILE *)RBX::FileSystem::openFileWrite( /*0x106702e06*/
                           this: (RBX::FileSystem *)v169,
                           a2: (const boost::filesystem::path *)v41);
          v122 = v121; /*0x106702e0b*/
          if ( v121 != nullptr ) /*0x106702e11*/
          {
            if ( Int32 == 5 ) /*0x106702e1b*/
            {
              v123 = (MicroProfileRawFormat *)operator new(a1: (RBX::Memory *)0xC0, a2: (unsigned __int64)v41); /*0x106702e22*/
              v124 = v123; /*0x106702e27*/
              if ( ((__int64)v171[0] & 1) != 0 ) /*0x106702e31*/
                v125 = (char *)v172; /*0x106702e33*/
              else
                v125 = (char *)v171 + 1; /*0x106702e79*/
              MicroProfileRawFormat::MicroProfileRawFormat(this: v123, a2: v125); /*0x106702e83*/
              MicroProfileRawToHtml(a1: v124); /*0x106702e97*/
              fclose(a1: v122); /*0x106702e9f*/
              MicroProfileRawFormat::~MicroProfileRawFormat(this: v124); /*0x106702ea7*/
              operator delete(a1: v124, a2: v128); /*0x106702eaf*/
            }
            else
            {
              if ( ((__int64)v171[0] & 1) != 0 ) /*0x106702e47*/
              {
                v126 = (char *)v172; /*0x106702e49*/
                v127 = (size_t)v171[1]; /*0x106702e50*/
              }
              else
              {
                v127 = LOBYTE(v171[0]) >> 1; /*0x106702e59*/
                v126 = (char *)v171 + 1; /*0x106702e5b*/
              }
              fwrite(a1: v126, a2: v127, a3: 1u, a4: v121); /*0x106702e6a*/
              fclose(a1: v122); /*0x106702e72*/
            }
          }
        }
        if ( (si128.i8[0] & 1) != 0 ) /*0x106702ebb*/
          operator delete(a1: (RBX::Memory *)v161, a2: v41); /*0x106702ec4*/
        if ( v120 == 0 ) /*0x106702ecc*/
        {
LABEL_174:
          if ( ((__int64)v169[0] & 1) != 0 ) /*0x106702ed5*/
          {
            std::string::__init_copy_ctor_external(a1: &v158, a2: v170, a3: v169[1]); /*0x106702f0c*/
          }
          else
          {
            v159 = v170; /*0x106702ede*/
            v158 = _mm_load_si128((const __m128i *)v169); /*0x106702eed*/
          }
          v173[0] = 1; /*0x106702f22*/
          rbx::signal<void ()(bool,std::string)>::invokeImpl<(rbx::SignalInvokePolicy)0>( /*0x106702f33*/
            a1: (char *)this + *((_QWORD *)RBX::Network::ClientReplicatorEvents::event_RCCProfilerDataComplete + 15),
            a2: v173,
            a3: &v158);
          if ( (v158.i8[0] & 1) != 0 ) /*0x106702f3f*/
            operator delete(a1: (RBX::Memory *)v159, a2: v41); /*0x106702f48*/
        }
LABEL_179:
        if ( ((__int64)v169[0] & 1) != 0 ) /*0x106702f54*/
          operator delete(a1: (RBX::Memory *)v170, a2: v41); /*0x106702f5d*/
        if ( ((__int64)v171[0] & 1) != 0 ) /*0x106702f69*/
          goto LABEL_182; /*0x106702f69*/
LABEL_183:
        RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)&v166); /*0x106702f77*/
LABEL_184:
        v63 = (__m128i *)&v177; /*0x106702f83*/
LABEL_185:
        RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v63); /*0x106702f8a*/
        v8 = 0; /*0x106702f8f*/
        break; /*0x106702f8f*/
      case 0x9Bu:
        if ( DFFlag::CLI169073 != 1 || (v8 = 1, (unsigned __int8)RBX::RunService::productIsStudio(this: v5) == 0) ) /*0x106702211*/
        {
          RBX::Network::ClientReplicator::readDynLuaChallenge_deprecated(this); /*0x106702232*/
          v8 = 1; /*0x10670223d*/
          RBX::Network::ClientReplicator::computeAndSendDynLuaResponse( /*0x106702253*/
            (RBX::Network::ConcurrentRakPeer **)this,
            a2: v163,
            a3: v162,
            a4: (RBX::ProtectedString *)v154);
        }
        break; /*0x106702258*/
      case 0xA2u:
      case 0xA3u:
      case 0xA4u:
        break;
      default:
        if ( v7 != 142 ) /*0x106701f33*/
          goto LABEL_25; /*0x106701f33*/
        RBX::Network::RakNetAddressToString(this: (RBX::Network *)&v177, a2, a3: true, a4: 124); /*0x106701f49*/
        if ( (v177 & 1) != 0 ) /*0x106701f55*/
          v32 = (char *)v179; /*0x106701f5b*/
        else
          v32 = &v178; /*0x10670250a*/
        RBX::format( /*0x106702521*/
          this: (RBX *)v173,
          a2: "Protocol mismatch from %s",
          a3: (__int64)v32,
          a4: v21,
          a5: v22,
          a6: v23,
          a7: v24,
          a8: v25,
          a9: v26,
          a10: v27,
          a11: v28,
          a12: v29,
          a13: v30,
          a14: v31,
          a15: v131);
        if ( (v177 & 1) != 0 ) /*0x10670252d*/
          operator delete(a1: (RBX::Memory *)v179, a2: v66); /*0x106702536*/
        v67 = v173[0]; /*0x10670253b*/
        v68 = (char *)v174[0]; /*0x106702542*/
        *(_OWORD *)v153 = 0; /*0x10670254d*/
        std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "", a3: v64, a4: v65); /*0x106702563*/
        v69 = (v67 & 1) == 0; /*0x106702568*/
        v70 = &v173[1]; /*0x10670256c*/
        if ( v69 ) /*0x106702573*/
          v68 = &v173[1]; /*0x106702573*/
        RBX::CreatorLog::print(a1: 4, a2: v68, a3: 4, a4: v153, a5: v137); /*0x106702592*/
        if ( (v137[0] & 1) != 0 ) /*0x10670259e*/
          operator delete(a1: (RBX::Memory *)v138, a2: v71); /*0x1067025a7*/
        v72 = v153[1]; /*0x1067025ac*/
        if ( v153[1] != nullptr /*0x1067025c8*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v153[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v72 + 16LL))(a1: v72); /*0x1067025d1*/
          std::__shared_weak_count::__release_weak(this: v72); /*0x1067025d7*/
        }
        v73 = FLog::Network; /*0x1067025e3*/
        if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x1067025f5*/
        {
          if ( (v173[0] & 1) != 0 ) /*0x106702607*/
            v70 = (const char *)v174[0]; /*0x106702609*/
          FLog::FastLogS( /*0x10670261a*/
            this: (FLog *)FLog::Network,
            a2: qword_10D7BBAA8,
            a3: (unsigned __int64)"[FLog::Network] Protocol mismatch %s",
            a4: v70);
        }
        v74 = *((_QWORD *)this + 13); /*0x10670261f*/
        v75 = *(_QWORD *)(v74 + 24); /*0x106702623*/
        v76 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>(a1: v73); /*0x106702627*/
        if ( *(unsigned __int16 *)(v75 + 440) - (unsigned int)*(unsigned __int16 *)(v76 + 440) > *(unsigned __int16 *)(v76 + 442) ) /*0x106702649*/
          v74 = 0; /*0x106702649*/
        RBX::Network::RakNetAddressToString(this: (RBX::Network *)&v177, a2, a3: true, a4: 124); /*0x106702661*/
        RBX::Network::Client::requestDisconnectOnTransportFailure(a1: v74, a2: (__int64)&v177, a3: 0x103u); /*0x106702675*/
        if ( (v177 & 1) != 0 ) /*0x106702681*/
          operator delete(a1: (RBX::Memory *)v179, a2: v77); /*0x10670268a*/
        RakNet::SystemAddress::ToStringN(this: a2, a2: true, a3: &v177, a4: 1025, a5: 124); /*0x1067026a9*/
        RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x1067026d0*/
          this: (RBX::Network::ConcurrentRakPeer **)v74,
          a2: "ProtocolMismatch",
          a3: 1u,
          a4: &v177,
          a5: 3,
          a6: 1);
        *(_OWORD *)v167 = 0; /*0x1067026d9*/
        v166 = 0; /*0x1067026e1*/
        v168 = 1065353216; /*0x1067026e9*/
        std::string::basic_string[abi:ne200100]<0>(a1: v171, a2: "gameJoinFailureReason", a3: v78, a4: v79); /*0x106702704*/
        v169[0] = (std::__shared_weak_count *)v171; /*0x106702710*/
        v80 = std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x10670272b*/
                a1: &v166,
                a2: v171,
                a3: std::piecewise_construct,
                a4: v169,
                a5: &si128);
        std::string::assign(a1: v80 + 40, a2: "ProtocolMistmatch"); /*0x10670273e*/
        if ( ((__int64)v171[0] & 1) != 0 ) /*0x10670274a*/
          operator delete(a1: (RBX::Memory *)v172, a2: v83); /*0x106702753*/
        std::string::basic_string[abi:ne200100]<0>(a1: v139, a2: "client", a3: v81, a4: v82); /*0x106702766*/
        std::string::basic_string[abi:ne200100]<0>(a1: v141, a2: "report", a3: v84, a4: v85); /*0x106702779*/
        std::string::basic_string[abi:ne200100]<0>(a1: v143, a2: "GameJoinFailure", a3: v86, a4: v87); /*0x10670278c*/
        std::unordered_map<std::string,std::string>::unordered_map(a1: v132, a2: &v166); /*0x10670279f*/
        RBX::Analytics::EventIngest::setRBXEvent(a1: v139, a2: v141, a3: v143, a4: v132); /*0x1067027c0*/
        std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::~__hash_table(a1: v132); /*0x1067027cc*/
        if ( (v143[0] & 1) != 0 ) /*0x1067027d8*/
          operator delete(a1: (RBX::Memory *)v144, a2: v88); /*0x1067027e1*/
        if ( (v141[0] & 1) != 0 ) /*0x1067027ed*/
          operator delete(a1: (RBX::Memory *)v142, a2: v88); /*0x1067027f6*/
        if ( (v139[0] & 1) != 0 ) /*0x106702802*/
          operator delete(a1: (RBX::Memory *)v140, a2: v88); /*0x10670280b*/
        std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::~__hash_table(a1: &v166); /*0x106702817*/
        if ( (v173[0] & 1) != 0 ) /*0x106702823*/
          operator delete(a1: (RBX::Memory *)v174[0], a2: v89); /*0x10670282c*/
LABEL_91:
        v8 = 1; /*0x106702831*/
        break; /*0x106702837*/
    }
  }
  RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: v155); /*0x106702f92*/
  RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: v154); /*0x106702fa5*/
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v4, a2: v129); /*0x106702fac*/
  return v8; /*0x106702fc4*/
}

// Address: 0x106703454 | Name: __ZN3RBX7Network16ClientReplicator30readDynLuaChallenge_deprecatedEPN6RakNet6PacketERjS5_RNS_15ProtectedStringE
void __fastcall RBX::Network::ClientReplicator::readDynLuaChallenge_deprecated(
        RBX::Network::Replicator *this,
        __int64 a2,
        _DWORD *a3,
        _DWORD *a4,
        __int64 a5)
{
  __int64 v9; // rdx
  __int64 v10; // rcx
  const char *v11; // rsi
  __int64 v12; // r8
  __int64 v13; // r9
  __m128 v14; // xmm0
  __m128 v15; // xmm1
  __m128 v16; // xmm2
  __m128 v17; // xmm3
  __m128 v18; // xmm4
  __m128 v19; // xmm5
  __m128 v20; // xmm6
  __m128 v21; // xmm7
  void *v22; // rsi
  char v23; // [rsp+0h] [rbp-A0h]
  char v24[64]; // [rsp+8h] [rbp-98h] BYREF
  _BYTE v25[16]; // [rsp+48h] [rbp-58h] BYREF
  void *v26; // [rsp+58h] [rbp-48h]
  _BYTE v27[8]; // [rsp+60h] [rbp-40h] BYREF
  _BYTE v28[56]; // [rsp+68h] [rbp-38h] BYREF

  RBX::Network::NetworkStream::NetworkStream( /*0x106703487*/
    this: (RBX::Network::NetworkStream *)v24,
    a2: *(unsigned __int8 **)(a2 + 56),
    a3: *(_DWORD *)(a2 + 48),
    a4: false);
  RBX::Network::NetworkStream::IgnoreBytes(this: (RBX::Network::NetworkStream *)v24, a2: 1u); /*0x106703494*/
  *a3 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v24); /*0x1067034a5*/
  *a4 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v24); /*0x1067034b5*/
  RBX::Network::Replicator::getReadPayloadLimit(this); /*0x1067034bb*/
  RBX::Network::NetworkStream::readString(this: (RBX::Network::NetworkStream *)v25, a2: (int)v24); /*0x1067034cd*/
  if ( *((_QWORD *)this + 1809) == 0 ) /*0x1067034da*/
    RBX::throw_runtime_error( /*0x10670353a*/
      this: (RBX *)"Bytecode Auth Check missing or wrong version.",
      a2: v11,
      a3: v9,
      a4: v10,
      a5: v12,
      a6: v13,
      a7: v14,
      a8: v15,
      a9: v16,
      a10: v17,
      a11: v18,
      a12: v19,
      a13: v20,
      a14: v21,
      a15: v23);
  RBX::ProtectedString::fromBytecode(a1: v27, a2: v25); /*0x1067034e4*/
  RBX::ProtectedString::operator=(a1: a5, a2: (__int64)v27); /*0x1067034f0*/
  RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: v28); /*0x1067034f9*/
  RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: v27); /*0x106703502*/
  if ( (v25[0] & 1) != 0 ) /*0x10670350b*/
    operator delete(a1: (RBX::Memory *)v26, a2: v22); /*0x106703511*/
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v24); /*0x10670351d*/
}

// Address: 0x106703588 | Name: __ZN3RBX7Network16ClientReplicator25processPacketLimitReachedERKNS_5TimerILNS_4Time12SampleMethodE0EEE
char __fastcall RBX::Network::ClientReplicator::processPacketLimitReached(RBX::Network::Replicator *this, double *a2)
{
  if ( *((_BYTE *)this + 18702) == 0 /*0x1067035d2*/
    && (unsigned __int8)RBX::Network::Replicator::joinProcessingTimeLimitReached(this) != 0
    || DFFlag::ClientPacketLimiting == 1
    && *((_BYTE *)this + 18702) == 1
    && RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: this) - *a2 > *((double *)this + 1559) )
  {
    return 1; /*0x1067035d4*/
  }
  else
  {
    return RBX::Network::Replicator::processPacketLimitReached(a1: this, a2); /*0x1067035e5*/
  }
}

// Address: 0x1067035ea | Name: __ZN3RBX7Network16ClientReplicator15processPacketV2ERNS0_14IncomingPacketEm
__int64 __fastcall RBX::Network::ClientReplicator::processPacketV2(
        RBX::Network::ClientReplicator *this,
        RBX::Network::IncomingPacket *a2,
        unsigned __int64 a3)
{
  RBX::Network::IncomingPacket *v4; // r15
  unsigned __int8 v6; // al
  unsigned __int8 *v7; // rbx
  unsigned int v8; // eax
  const RBX::Network::NetworkSchema *v9; // rax
  unsigned __int8 *v10; // rbx
  unsigned int v11; // eax
  __int64 v12; // rbx
  RBX::Instance *v13; // rsi
  __int64 v14; // rax
  std::__shared_weak_count *v15; // rbx
  __int64 *v16; // rax
  __int64 v18; // rax
  std::__shared_weak_count *v19; // rbx
  std::__shared_weak_count *v20; // rbx
  RBX::Instance *v21; // rsi
  RBX::DataModel *v22; // rax
  RBX::Instance *v23; // rsi
  __int64 v24; // rdx
  __int64 v25; // rcx
  __int64 v26; // rbx
  const char *v27; // rsi
  void *v28; // rsi
  __int64 v29; // r8
  std::__shared_weak_count *v30; // rbx
  std::__shared_weak_count *v31; // rbx
  __int64 v32; // rax
  std::__shared_weak_count *v33; // rbx
  __int64 v34; // rax
  std::__shared_weak_count *v35; // rbx
  std::__shared_weak_count *v36; // r15
  __int64 v37; // rax
  std::__shared_weak_count *v38; // rbx
  char v39; // al
  __int64 v40; // rax
  __int64 v41; // r15
  __int64 v42; // rax
  __int64 v43; // rax
  RBX::Network::StrictNetworkFilter *v44; // rsi
  RBX::Network::StrictNetworkFilter *v45; // r12
  void *v46; // rsi
  std::__shared_weak_count *v47; // r12
  std::__shared_weak_count *v48; // r12
  __int64 v49; // rdi
  __int64 v50; // rax
  std::__shared_weak_count *v51; // rbx
  int v52; // esi
  __int64 v53; // r13
  __int64 v54; // r12
  unsigned int v55; // esi
  rbx::signals::slots_holder **v56; // r15
  unsigned __int64 v57; // rsi
  unsigned __int64 v58; // rbx
  rbx::signals::slots_holder *v59; // rax
  __int64 v60; // rax
  rbx::signals::slots_holder *v61; // rdi
  unsigned int v62; // esi
  std::__shared_weak_count *v63; // rdi
  char Bool; // r13
  char v65; // bl
  char v66; // r15
  const RBX::Instance *v67; // rsi
  RBX::ServiceProvider *ServiceProvider; // rax
  RBX::PermissionsService *v69; // r12
  const RBX::Instance *v70; // rsi
  RBX::ServiceProvider *v71; // rax
  RBX::Ads::AdService *v72; // rax
  char v73; // al
  RBX::Network::NetworkStream *v74; // rdx
  __int64 v75; // rdi
  unsigned int v76; // esi
  RBX::Instance *v77; // rsi
  __int64 v78; // rbx
  __int64 v79; // r15
  RBX::Network::NetworkSchema *SharedNetworkSchema; // rax
  char v81; // al
  RBX::Network::Client *v82; // rax
  unsigned __int8 v83; // al
  __int64 *v84; // rax
  unsigned __int8 v85; // cl
  __int64 *v86; // rax
  unsigned __int8 v87; // cl
  __int64 v88; // rax
  __int64 v89; // rax
  unsigned int v90; // ebx
  __int64 v91; // rax
  __int64 v92; // rdi
  __int64 v93; // rsi
  __int64 v94; // rax
  __int64 v95; // rdi
  _BYTE *EngineNetConfiguration; // rax
  std::__shared_weak_count *v97[2]; // [rsp+0h] [rbp-320h] BYREF
  void *v98; // [rsp+10h] [rbp-310h]
  _BYTE v99[536]; // [rsp+48h] [rbp-2D8h] BYREF
  unsigned int v100[16]; // [rsp+260h] [rbp-C0h] BYREF
  std::__shared_weak_count *v101[2]; // [rsp+2A0h] [rbp-80h] BYREF
  RBX::Network::IncomingPacket *v102; // [rsp+2B8h] [rbp-68h]
  RBX::Network::ClientReplicator *v103; // [rsp+2C0h] [rbp-60h] BYREF
  __int64 v104; // [rsp+2C8h] [rbp-58h] BYREF
  RBX::DataModel *v105; // [rsp+2D0h] [rbp-50h]
  RBX::Network::StrictNetworkFilter *v106; // [rsp+2D8h] [rbp-48h] BYREF
  std::__shared_weak_count *v107[2]; // [rsp+2E0h] [rbp-40h] BYREF
  RBX::Memory *v108; // [rsp+2F4h] [rbp-2Ch]

  v4 = a2; /*0x106703601*/
  v6 = RBX::Network::IncomingPacket::operator[](a1: a2, a2: 0); /*0x10670360c*/
  if ( v6 == 0x81 ) /*0x106703613*/
  {
    v10 = (unsigned __int8 *)RBX::Network::IncomingPacket::data(this: v4); /*0x1067036b5*/
    v102 = v4; /*0x1067036b8*/
    v11 = RBX::Network::IncomingPacket::size(this: v4); /*0x1067036bf*/
    RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)v100, a2: v10, a3: v11, a4: false); /*0x1067036d5*/
    RBX::Network::NetworkStream::IgnoreBytes(this: (RBX::Network::NetworkStream *)v100, a2: 1u); /*0x1067036e2*/
    v12 = *((_QWORD *)this + 1801); /*0x1067036e7*/
    v14 = RBX::DataModel::get(this, a2: v13); /*0x1067036f1*/
    RBX::shared_from<RBX::DataModel>(a1: v97, a2: v14); /*0x106703700*/
    RBX::Network::MegaReplicator::startMegaJobs(a1: v12, a2: v97); /*0x10670370f*/
    v15 = v97[1]; /*0x106703714*/
    if ( v97[1] != nullptr /*0x106703730*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v97[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v15 + 16LL))(a1: v15); /*0x106703738*/
      std::__shared_weak_count::__release_weak(this: v15); /*0x10670373e*/
    }
    if ( (*(unsigned __int8 (__fastcall **)(RBX::Network::ClientReplicator *))(*(_QWORD *)this + 1032LL))(a1: this) != 0 ) /*0x106703751*/
    {
LABEL_25:
      *((_BYTE *)this + 15544) = RBX::Network::NetworkStream::readBool(this: (RBX::Network::NetworkStream *)v100); /*0x10670389c*/
      v22 = (RBX::DataModel *)RBX::DataModel::get(this, a2: v21); /*0x1067038b2*/
      if ( v22 != nullptr && (unsigned __int8)RBX::DataModel::getShouldSetGlobalTelemetryInfo(this: v22) != 0 ) /*0x1067038c6*/
        RBX::Analytics::setStreamingEnabled(this: (RBX::Analytics *)*((unsigned __int8 *)this + 15544), a2: (bool)v23); /*0x1067038d0*/
      v26 = RBX::DataModel::get(this, a2: v23); /*0x1067038dd*/
      v104 = v26; /*0x1067038e0*/
      v27 = "disabled"; /*0x1067038eb*/
      if ( *((_BYTE *)this + 15544) != 0 ) /*0x1067038fa*/
        v27 = "enabled"; /*0x1067038fa*/
      std::string::basic_string[abi:ne200100]<0>(a1: v97, a2: v27, a3: v24, a4: v25); /*0x106703905*/
      RBX::DataModel::setContextAttribute(a1: v26, a2: 12, a3: v97); /*0x106703919*/
      if ( ((__int64)v97[0] & 1) != 0 ) /*0x106703925*/
        operator delete(a1: (RBX::Memory *)v98, a2: v28); /*0x10670392e*/
      if ( *((_BYTE *)this + 15544) == 1 ) /*0x10670393b*/
      {
        v107[0] = this; /*0x106703945*/
        v29 = *((_QWORD *)this + 1801); /*0x106703948*/
        LOBYTE(v103) = 0; /*0x106703953*/
        std::allocate_shared[abi:ne200100]<RBX::Network::InstanceObjectManager,std::allocator<RBX::Network::InstanceObjectManager>,RBX::DataModel *&,RBX::Network::ClientReplicator *,RBX::Network::MegaReplicator &,bool,0>( /*0x106703966*/
          a1: v97,
          a2: &v106,
          a3: &v104,
          a4: v107,
          a5: v29,
          a6: &v103);
        std::shared_ptr<RBX::Network::InstanceObjectManager>::operator=[abi:ne200100](a1: (char *)this + 22056, a2: v97); /*0x10670397f*/
        v30 = v97[1]; /*0x106703984*/
        if ( v97[1] != nullptr /*0x10670399d*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v97[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v30 + 16LL))(a1: v30); /*0x1067039a5*/
          std::__shared_weak_count::__release_weak(this: v30); /*0x1067039ab*/
        }
        LOBYTE(v106) = 0; /*0x1067039b0*/
        LOBYTE(v103) = (*(__int64 (__fastcall **)(RBX::Network::ClientReplicator *))(*(_QWORD *)this + 1032LL))(a1: this); /*0x1067039c4*/
        std::allocate_shared[abi:ne200100]<RBX::Network::StreamingSolverV2,std::allocator<RBX::Network::StreamingSolverV2>,RBX::DataModel *&,std::shared_ptr<RBX::Network::InstanceObjectManager> &,bool,bool,0>( /*0x1067039dd*/
          a1: v97,
          a2: v107,
          a3: &v104,
          a4: (char *)this + 22056,
          a5: &v106);
        std::shared_ptr<RBX::Network::StreamingSolverV2>::operator=[abi:ne200100](a1: (char *)this + 22040, a2: v97); /*0x1067039f6*/
        v31 = v97[1]; /*0x1067039fb*/
        if ( v97[1] != nullptr /*0x106703a14*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v97[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v31 + 16LL))(a1: v31); /*0x106703a1c*/
          std::__shared_weak_count::__release_weak(this: v31); /*0x106703a22*/
        }
        RBX::Network::MegaReplicator::setObjectManager(a1: *((_QWORD *)this + 1801), a2: (char *)this + 22056); /*0x106703a31*/
        RBX::Network::MegaReplicator::setStreamingSolverV2(a1: *((_QWORD *)this + 1801), a2: (char *)this + 22040); /*0x106703a40*/
        v32 = *((_QWORD *)this + 2758); /*0x106703a45*/
        *(_OWORD *)v97 = *(_OWORD *)((char *)this + 22056); /*0x106703a4d*/
        if ( v32 != 0 ) /*0x106703a57*/
          _InterlockedIncrement64((volatile signed __int64 *)(v32 + 8)); /*0x106703a59*/
        RBX::TaskScheduler::add(a1: v97); /*0x106703a65*/
        v33 = v97[1]; /*0x106703a6a*/
        if ( v97[1] != nullptr /*0x106703a86*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v97[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v33 + 16LL))(a1: v33); /*0x106703a8e*/
          std::__shared_weak_count::__release_weak(this: v33); /*0x106703a94*/
        }
        v34 = *((_QWORD *)this + 2756); /*0x106703a99*/
        *(_OWORD *)v97 = *(_OWORD *)((char *)this + 22040); /*0x106703aa3*/
        if ( v34 != 0 ) /*0x106703aad*/
          _InterlockedIncrement64((volatile signed __int64 *)(v34 + 8)); /*0x106703aaf*/
        RBX::TaskScheduler::add(a1: v97); /*0x106703abb*/
        v35 = v97[1]; /*0x106703ac0*/
        if ( v97[1] != nullptr /*0x106703adc*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v97[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v35 + 16LL))(a1: v35); /*0x106703ae4*/
          std::__shared_weak_count::__release_weak(this: v35); /*0x106703aea*/
        }
        std::allocate_shared[abi:ne200100]<RBX::Network::ClientReplicator::GCJob,std::allocator<RBX::Network::ClientReplicator::GCJob>,RBX::Network::ClientReplicator&,0>( /*0x106703afd*/
          a1: v97,
          a2: v107,
          a3: this);
        std::shared_ptr<RBX::Network::ClientReplicator::GCJob>::operator=[abi:ne200100]( /*0x106703b16*/
          a1: (char *)this + 22024,
          a2: v97);
        v36 = v97[1]; /*0x106703b1b*/
        if ( v97[1] != nullptr /*0x106703b34*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v97[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v36 + 16LL))(a1: v36); /*0x106703b3c*/
          std::__shared_weak_count::__release_weak(this: v36); /*0x106703b42*/
        }
        v37 = *((_QWORD *)this + 2754); /*0x106703b47*/
        *(_OWORD *)v97 = *(_OWORD *)((char *)this + 22024); /*0x106703b4e*/
        if ( v37 != 0 ) /*0x106703b58*/
          _InterlockedIncrement64((volatile signed __int64 *)(v37 + 8)); /*0x106703b5a*/
        RBX::TaskScheduler::add(a1: v97); /*0x106703b66*/
        v38 = v97[1]; /*0x106703b6b*/
        if ( v97[1] != nullptr /*0x106703b87*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v97[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v38 + 16LL))(a1: v38); /*0x106703b8f*/
          std::__shared_weak_count::__release_weak(this: v38); /*0x106703b95*/
        }
        v39 = *((_BYTE *)this + 15544); /*0x106703b9a*/
      }
      else
      {
        v39 = 0; /*0x106703ba3*/
      }
      RBX::Network::MegaReplicator::setIsStreamingEnabled( /*0x106703bb2*/
        this: *((RBX::Network::MegaReplicator **)this + 1801),
        a2: v39 & 1);
      if ( (unsigned __int8)RBX::Network::NetworkStream::readBool(this: (RBX::Network::NetworkStream *)v100) != 0 ) /*0x106703bc5*/
      {
        v40 = RBX::ServiceProvider::find<RBX::Network::Client>(a1: this); /*0x106703bce*/
        v41 = v40; /*0x106703bd3*/
        if ( v40 != 0 ) /*0x106703bd9*/
        {
          v103 = this; /*0x106703bdf*/
          v42 = *(_QWORD *)(v40 + 400); /*0x106703be3*/
          *(_OWORD *)v97 = *(_OWORD *)(v41 + 392); /*0x106703bf2*/
          if ( v42 != 0 ) /*0x106703bfc*/
            _InterlockedIncrement64((volatile signed __int64 *)(v42 + 8)); /*0x106703bfe*/
          v43 = *(_QWORD *)(v41 + 416); /*0x106703c03*/
          *(_OWORD *)v107 = *(_OWORD *)(v41 + 408); /*0x106703c12*/
          if ( v43 != 0 ) /*0x106703c19*/
            _InterlockedIncrement64((volatile signed __int64 *)(v43 + 8)); /*0x106703c1b*/
          std::make_unique[abi:ne200100]<RBX::Network::StrictNetworkFilter,RBX::Network::ClientReplicator *,std::shared_ptr<RBX::Network::NetworkFilterWhiteList>,std::shared_ptr<RBX::Network::NetworkFilterWhiteList>,0>( /*0x106703c33*/
            a1: &v106,
            a2: &v103,
            a3: v97,
            a4: v107);
          v44 = v106; /*0x106703c3f*/
          v106 = nullptr; /*0x106703c46*/
          std::unique_ptr<RBX::Network::StrictNetworkFilter>::reset[abi:ne200100](a1: (char *)this + 12536, a2: v44); /*0x106703c4d*/
          v45 = v106; /*0x106703c52*/
          v106 = nullptr; /*0x106703c56*/
          if ( v45 != nullptr ) /*0x106703c5d*/
          {
            RBX::Network::StrictNetworkFilter::~StrictNetworkFilter(this: v45); /*0x106703c62*/
            operator delete(a1: v45, a2: v46); /*0x106703c6a*/
          }
          v47 = v107[1]; /*0x106703c6f*/
          if ( v107[1] != nullptr /*0x106703c89*/
            && _InterlockedExchangeAdd64((volatile signed __int64 *)v107[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
          {
            (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v47 + 16LL))(a1: v47); /*0x106703c92*/
            std::__shared_weak_count::__release_weak(this: v47); /*0x106703c98*/
          }
          v48 = v97[1]; /*0x106703c9d*/
          if ( v97[1] != nullptr /*0x106703cba*/
            && _InterlockedExchangeAdd64((volatile signed __int64 *)v97[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
          {
            (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v48 + 16LL))(a1: v48); /*0x106703cc3*/
            std::__shared_weak_count::__release_weak(this: v48); /*0x106703cc9*/
          }
          if ( FFlag::NetworkFilterTelemetry == 1 ) /*0x106703cd8*/
          {
            v49 = *((_QWORD *)this + 1567); /*0x106703cda*/
            v50 = *(_QWORD *)(v41 + 384); /*0x106703cdd*/
            *(_OWORD *)v101 = *(_OWORD *)(v41 + 376); /*0x106703cec*/
            if ( v50 != 0 ) /*0x106703cf3*/
              _InterlockedIncrement64((volatile signed __int64 *)(v50 + 8)); /*0x106703cf5*/
            RBX::Network::StrictNetworkFilter::setGlobalStats(a1: v49, a2: v101); /*0x106703cfe*/
            v51 = v101[1]; /*0x106703d03*/
            if ( v101[1] != nullptr /*0x106703d1c*/
              && _InterlockedExchangeAdd64((volatile signed __int64 *)v101[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
            {
              (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v51 + 16LL))(a1: v51); /*0x106703d24*/
              std::__shared_weak_count::__release_weak(this: v51); /*0x106703d2a*/
            }
          }
        }
      }
      v105 = (RBX::DataModel *)RBX::ServiceProvider::find<RBX::Workspace>(a1: this); /*0x106703d37*/
      if ( ((v105 != nullptr) /*0x106703d55*/
          & (unsigned __int8)RBX::Analytics::InfluxDb::canSend(
                               this: (RBX::Analytics::InfluxDb *)(unsigned int)DFInt::StreamingJoinStatsHundredths,
                               a2: v52)) == 1 )
      {
        v53 = *((_QWORD *)this + 2753); /*0x106703d5b*/
        if ( v53 != 0 ) /*0x106703d65*/
        {
          v54 = *((_QWORD *)this + 2754); /*0x106703d6b*/
          if ( v54 != 0 ) /*0x106703d75*/
            _InterlockedIncrement64((volatile signed __int64 *)(v54 + 16)); /*0x106703d77*/
          rbx::signal<void ()(void)>::invokeImpl<(rbx::SignalInvokePolicy)0>(a1: (RBX::DataModel *)((char *)v105 + 1472)); /*0x106703d88*/
          LODWORD(v108) = RBX::Memory::setCurrentCategory( /*0x106703d9b*/
                            this: (RBX::Memory *)(unsigned int)RBX::Memory::InstanceSignal,
                            a2: v55);
          v56 = (rbx::signals::slots_holder **)((char *)v105 + 1464); /*0x106703da2*/
          rbx::lazyInitSlotsHolder(a1: (char *)v105 + 1464); /*0x106703dac*/
          v58 = rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x40, a2: v57); /*0x106703dbb*/
          *(_QWORD *)v58 = &_mh_execute_header; /*0x106703dc8*/
          *(_QWORD *)(v58 + 8) = rbx::signals::slot_with_functor<RBX::Network::ClientReplicator::processPacketV2(RBX::Network::IncomingPacket &,unsigned long)::$_0,std::shared_ptr<RBX::Player>>::do_call; /*0x106703dd2*/
          *(_OWORD *)(v58 + 16) = 0; /*0x106703dd9*/
          v59 = *v56; /*0x106703ddd*/
          *(_QWORD *)(v58 + 32) = *v56; /*0x106703de0*/
          if ( v59 != nullptr ) /*0x106703de7*/
          {
            _InterlockedIncrement((volatile signed __int32 *)v59 + 1); /*0x106703de9*/
            v60 = *(_QWORD *)(v58 + 24) | 4LL; /*0x106703df1*/
            v61 = *v56; /*0x106703df5*/
          }
          else
          {
            v60 = 4; /*0x106703dfa*/
            v61 = nullptr; /*0x106703dff*/
          }
          *(_QWORD *)(v58 + 24) = v60; /*0x106703e01*/
          *(_QWORD *)(v58 + 40) = rbx::signals::slot_with_functor<RBX::Network::ClientReplicator::processPacketV2(RBX::Network::IncomingPacket &,unsigned long)::$_0,std::shared_ptr<RBX::Player>>::do_dtor; /*0x106703e0c*/
          *(_QWORD *)(v58 + 48) = v53; /*0x106703e10*/
          *(_QWORD *)(v58 + 56) = v54; /*0x106703e14*/
          rbx::signals::slots_holder::insert(this: v61, a2: v58); /*0x106703e1e*/
          v97[0] = (std::__shared_weak_count *)v58; /*0x106703e23*/
          _InterlockedIncrement((volatile signed __int32 *)(v58 + 4)); /*0x106703e2a*/
          RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)v108, a2: v62); /*0x106703e31*/
          rbx::signals::scoped_connection::operator=(this: (RBX::Network::ClientReplicator *)((char *)this + 23904)); /*0x106703e44*/
          v63 = v97[0]; /*0x106703e49*/
          if ( v97[0] != nullptr && _InterlockedDecrement((volatile signed __int32 *)v97[0] + 1) == 0 ) /*0x106703e59*/
            rbx::signals::slot_base::operator delete(a1: v63); /*0x106703e5b*/
        }
      }
      Bool = RBX::Network::NetworkStream::readBool(this: (RBX::Network::NetworkStream *)v100); /*0x106703e6c*/
      v65 = RBX::Network::NetworkStream::readBool(this: (RBX::Network::NetworkStream *)v100); /*0x106703e7b*/
      v66 = RBX::Network::NetworkStream::readBool(this: (RBX::Network::NetworkStream *)v100); /*0x106703e89*/
      if ( (unsigned __int8)RBX::Network::Replicator::getIsOnDemandAdsCapabilityEnabled(this) != 0 ) /*0x106703e96*/
        LODWORD(v108) = RBX::Network::NetworkStream::readBool(this: (RBX::Network::NetworkStream *)v100); /*0x106703ea4*/
      else
        LODWORD(v108) = 0; /*0x106703ea9*/
      ServiceProvider = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(this, a2: v67); /*0x106703eb3*/
      if ( ServiceProvider != nullptr ) /*0x106703ebb*/
        v69 = (RBX::PermissionsService *)RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::PermissionsService>(this: ServiceProvider); /*0x106703ec5*/
      else
        v69 = nullptr; /*0x106703eca*/
      RBX::PermissionsService::setThirdPartyAssetAllowed(this: v69, a2: Bool); /*0x106703ed4*/
      RBX::PermissionsService::setThirdPartyPurchaseAllowed(this: v69, a2: v65); /*0x106703edf*/
      RBX::PermissionsService::setThirdPartyTeleportAllowed(this: v69, a2: v66); /*0x106703eeb*/
      if ( (unsigned __int8)RBX::Network::Replicator::getIsOnDemandAdsCapabilityEnabled(this) != 0 ) /*0x106703efa*/
      {
        RBX::PermissionsService::setOnDemandAdsAllowed(this: v69, a2: (bool)v108); /*0x106703f03*/
        if ( (_BYTE)v108 != 0 ) /*0x106703f0c*/
        {
          v71 = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(this, a2: v70); /*0x106703f11*/
          if ( v71 != nullptr ) /*0x106703f19*/
          {
            v72 = (RBX::Ads::AdService *)RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::Ads::AdService>(this: v71); /*0x106703f1e*/
            if ( v72 != nullptr ) /*0x106703f26*/
              RBX::Ads::AdService::handleOnDemandAdsEnabledAtClient(this: v72); /*0x106703f2b*/
          }
        }
      }
      v73 = RBX::Network::NetworkStream::readBool(this: (RBX::Network::NetworkStream *)v100); /*0x106703f37*/
      v75 = *((_QWORD *)this + 1808); /*0x106703f3c*/
      if ( v75 != 0 ) /*0x106703f46*/
        RBX::PlayersProp::setCharacterAutoSpawnProperty(this: (RBX::PlayersProp *)(v75 + 192), a2: v73); /*0x106703f52*/
      RBX::Network::deserializeUnsignedVarint(this: (RBX::Network *)v107, a2: v100, a3: v74); /*0x106703f62*/
      if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x106703f80*/
        FLog::FastLog( /*0x106703f95*/
          a1: FLog::Network,
          a2: qword_10D7BBAA8,
          a3: "[FLog::Network] Assigned peer id = %u",
          LODWORD(v107[0]));
      RBX::World::setLocalPeerId(this: *((RBX::World **)v105 + 118), a2: (int)v107[0]); /*0x106703fa8*/
      v76 = (unsigned int)v107[0]; /*0x106703fad*/
      *((_DWORD *)this + 48) = v107[0]; /*0x106703fb0*/
      RBX::Network::MegaReplicator::setReplicatingPeerId(this: *((RBX::Network::MegaReplicator **)this + 1801), a2: v76); /*0x106703fbe*/
      if ( FFlag::DebugHashTableMetrics != 0 /*0x106703fe9*/
        || (FFlag::SAuthWorkspaceFlagged & 1) != 0
        || FFlag::NextGenReplicatorEnabledRead == 1 )
      {
        v78 = *((_QWORD *)this + 1801); /*0x106703fef*/
        v79 = RBX::DataModel::get(this: v105, a2: v77); /*0x106703fff*/
        SharedNetworkSchema = (RBX::Network::NetworkSchema *)RBX::Network::MegaReplicator::getSharedNetworkSchema(this: *((RBX::Network::MegaReplicator **)this + 1801)); /*0x106704009*/
        v97[0] = *(std::__shared_weak_count **)RBX::Network::NetworkSchema::getEngineNetConfiguration(this: SharedNetworkSchema); /*0x106704020*/
        RBX::Network::MegaReplicator::initializeIsrManager(a1: v78, a2: v79); /*0x106704029*/
        v81 = FFlag::SAuthWorkspaceFlagged; /*0x10670402e*/
        if ( (((unsigned __int8)FFlag::SAuthWorkspaceFlagged | (unsigned __int8)FFlag::DebugHashTableMetrics) & 1) != 0 /*0x106704047*/
          || FFlag::NextGenReplicatorEnabledRead == 1 )
        {
          RBX::Network::InstanceReplication::RbxInstanceReplicatorManager::onConnectionReady( /*0x106704064*/
            a1: *(_QWORD *)(*((_QWORD *)this + 1801) + 920LL),
            a2: *(unsigned int *)(*((_QWORD *)this + 35) + 1408LL));
          v81 = FFlag::SAuthWorkspaceFlagged; /*0x106704069*/
        }
        if ( (v81 & 1) != 0 ) /*0x10670406f*/
        {
          v82 = (RBX::Network::Client *)RBX::ServiceProvider::find<RBX::Network::Client>(a1: this); /*0x106704074*/
          if ( v82 != nullptr ) /*0x10670407c*/
            RBX::Network::Client::hookToSAuthSignals(this: v82, a2: v77); /*0x106704081*/
        }
      }
      if ( (unsigned __int8)RBX::Analytics::InfluxDb::canSend( /*0x106704096*/
                              this: (RBX::Analytics::InfluxDb *)(unsigned int)DFInt::ISRUsageStatsTelemetryThrottle,
                              a2: (int)v77) == 0 )
        goto LABEL_137; /*0x106704096*/
      RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x1067040aa*/
        a1: (__int64)v97,
        a2: (__int64)&RBX::Telemetry::kISRUsageStats);
      if ( (unsigned __int8)RBX::Telemetry::RobloxTelemetryEvent::willThrottlePoints(this: (RBX::Telemetry::RobloxTelemetryEvent *)v97) != 0 ) /*0x1067040bd*/
      {
LABEL_136:
        RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v97); /*0x106704246*/
LABEL_137:
        *((_DWORD *)this + 4072) = v107[0]; /*0x106704259*/
        *((_BYTE *)this + 18703) = 1; /*0x106704263*/
        v90 = 0; /*0x106704272*/
        if ( FFlag::NetAssetSubsystem == 1 ) /*0x106704278*/
        {
          v91 = RBX::ServiceProvider::find<RBX::Network::Client>(a1: this); /*0x10670427d*/
          if ( v91 != 0 ) /*0x106704285*/
            v90 = *(_DWORD *)(v91 + 448); /*0x106704287*/
        }
        v92 = *((_QWORD *)this + 1400); /*0x10670428d*/
        v93 = *((unsigned int *)this + 4072); /*0x106704294*/
        if ( FFlag::NetAssetSubsystem == 1 ) /*0x10670429f*/
        {
          RBX::Network::LargeReplicator::setPeerId_subsystem(a1: v92, a2: v93, a3: v90); /*0x1067042a3*/
          v4 = v102; /*0x1067042a8*/
          *((_DWORD *)this + 49) = v90; /*0x1067042ac*/
        }
        else
        {
          RBX::Network::LargeReplicator::setPeerId_context(a1: v92, a2: v93); /*0x1067042b5*/
          v4 = v102; /*0x1067042ba*/
        }
        *((_DWORD *)this + 5500) = v107[0]; /*0x1067042c1*/
        v94 = RBX::ServiceProvider::find<RBX::Players>(a1: this); /*0x1067042cb*/
        if ( v94 != 0 ) /*0x1067042d3*/
          *(_DWORD *)(v94 + 1352) = *((_DWORD *)this + 5500); /*0x1067042dc*/
        RBX::Network::Replicator::schemaReadTopReplicationContainerStateFromStream( /*0x1067042f1*/
          this,
          a2: (RBX::Network::NetworkStream *)v100,
          a3: true);
        *((_QWORD *)this + 1948) = 2; /*0x1067042f6*/
        *((_BYTE *)this + 22004) = 1; /*0x106704301*/
        rbx::signal<void ()(void)>::invokeImpl<(rbx::SignalInvokePolicy)0>(a1: (RBX::Network::ClientReplicator *)((char *)this + 24432)); /*0x106704310*/
        v95 = *((_QWORD *)this + 1801); /*0x106704315*/
        ++*(_DWORD *)(v95 + 3244); /*0x10670431c*/
        *((_BYTE *)this + 18700) = 1; /*0x106704322*/
        if ( FFlag::InputReplicatorNonSAuth != 0 /*0x10670438d*/
          || (EngineNetConfiguration = (_BYTE *)RBX::Network::NetworkSchema::getEngineNetConfiguration(this: (RBX::Network::NetworkSchema *)(v95 + 1608)),
              FFlag::DebugHashTableMetrics != 0)
          || FFlag::SAuthWorkspaceFlagged == 1 && (*EngineNetConfiguration & 8) != 0 )
        {
          RBX::Network::Replicator::initializeInputReplicator(this); /*0x10670434c*/
        }
        RBX::Network::Replicator::enableDeserializePacketsJob(this); /*0x106704354*/
        RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v100); /*0x106704360*/
        return (unsigned int)RBX::Network::IncomingPacket::size(this: v4); /*0x106704360*/
      }
      v83 = 1; /*0x1067040ca*/
      if ( FFlag::DebugHashTableMetrics == 0 && (FFlag::SAuthWorkspaceFlagged & 1) == 0 ) /*0x1067040d8*/
        v83 = FFlag::NextGenReplicatorEnabledRead; /*0x1067040e1*/
      RBX::Telemetry::FieldsContainer::addField(a1: v99, a2: "ISRReadEnabled", a3: 14, a4: v83, a5: 1); /*0x1067040fb*/
      v84 = (__int64 *)RBX::Network::NetworkSchema::getEngineNetConfiguration(this: (RBX::Network::NetworkSchema *)(*((_QWORD *)this + 1801) + 1608LL)); /*0x10670410c*/
      v85 = 1; /*0x106704111*/
      if ( FFlag::DebugHashTableMetrics == 0 ) /*0x106704118*/
      {
        if ( FFlag::SAuthWorkspaceFlagged == 1 ) /*0x10670418a*/
        {
          v89 = *v84; /*0x10670418c*/
          if ( (v89 & 8) == 0 && FFlag::NextGenReplicatorEnabledWrite == 0 ) /*0x10670419d*/
            v85 = v89 & 1; /*0x1067041a5*/
        }
        else if ( FFlag::NextGenReplicatorEnabledRead == 1 ) /*0x1067041b6*/
        {
          v85 = FFlag::NextGenReplicatorEnabledWrite; /*0x1067041c3*/
        }
        else
        {
          v85 = 0; /*0x106704391*/
        }
      }
      RBX::Telemetry::FieldsContainer::addField(a1: v99, a2: "ISRWriteEnabled", a3: 15, a4: v85, a5: 1); /*0x106704132*/
      v86 = (__int64 *)RBX::Network::NetworkSchema::getEngineNetConfiguration(this: (RBX::Network::NetworkSchema *)(*((_QWORD *)this + 1801) + 1608LL)); /*0x106704143*/
      v87 = 1; /*0x106704148*/
      if ( FFlag::DebugHashTableMetrics == 0 ) /*0x10670414f*/
      {
        if ( FFlag::SAuthWorkspaceFlagged == 1 ) /*0x10670415a*/
        {
          v88 = *v86; /*0x10670415c*/
          if ( (v88 & 8) == 0 ) /*0x106704161*/
          {
            if ( FFlag::ISREnabledCanRemoveRtMessaging != 0 ) /*0x106704171*/
            {
              if ( FFlag::NextGenReplicatorEnabledWrite == 0 ) /*0x10670417d*/
                v87 = v88 & 1; /*0x106704181*/
              goto LABEL_135; /*0x106704183*/
            }
            goto LABEL_134; /*0x106704171*/
          }
        }
        else
        {
          if ( FFlag::ISREnabledCanRemoveRtMessaging != 1 || FFlag::NextGenReplicatorEnabledRead != 1 ) /*0x1067041e0*/
          {
LABEL_134:
            v87 = 0; /*0x1067041ed*/
            goto LABEL_135; /*0x1067041ed*/
          }
          v87 = FFlag::NextGenReplicatorEnabledWrite; /*0x1067041e9*/
        }
      }
LABEL_135:
      RBX::Telemetry::FieldsContainer::addField( /*0x1067041ef*/
        a1: v99,
        a2: "ISRLegacyMessagingServicesBlocked",
        a3: 33,
        a4: v87,
        a5: 1);
      RBX::Telemetry::FieldsContainer::addField( /*0x106704235*/
        a1: v99,
        a2: "ISRManagerInitialized",
        a3: 21,
        a4: *(_QWORD *)(*((_QWORD *)this + 1801) + 920LL) != 0,
        a5: 1);
      RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v97); /*0x106704241*/
      goto LABEL_136; /*0x106704241*/
    }
    v16 = (__int64 *)RBX::Network::NetworkSchema::getEngineNetConfiguration(this: (RBX::Network::NetworkSchema *)(*((_QWORD *)this + 1801) + 1608LL)); /*0x106703763*/
    if ( FFlag::DebugHashTableMetrics != 0 ) /*0x106703772*/
    {
LABEL_21:
      LOBYTE(v104) = 0; /*0x106703838*/
      std::allocate_shared[abi:ne200100]<RBX::Network::PhysicsReceiverS2,std::allocator<RBX::Network::PhysicsReceiverS2>,RBX::Network::ClientReplicator &,bool,0>( /*0x10670384d*/
        a1: v97,
        a2: v107,
        a3: this,
        a4: &v104);
      std::shared_ptr<RBX::Network::PhysicsReceiverS2>::operator=[abi:ne200100](a1: (char *)this + 18584, a2: v97); /*0x106703863*/
      v20 = v97[1]; /*0x106703868*/
      if ( v97[1] != nullptr /*0x106703881*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v97[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v20 + 16LL))(a1: v20); /*0x106703889*/
        std::__shared_weak_count::__release_weak(this: v20); /*0x10670388f*/
      }
      RBX::Network::Replicator::getOrCreatePhysicsTouchSerializer(this); /*0x106703897*/
      goto LABEL_25; /*0x106703897*/
    }
    if ( FFlag::SAuthWorkspaceFlagged == 1 ) /*0x1067037b0*/
    {
      v18 = *v16; /*0x1067037b2*/
      if ( (v18 & 8) != 0 || (v18 & 1) != 0 || FFlag::NextGenReplicatorEnabledWrite != 0 ) /*0x1067037c7*/
        goto LABEL_21; /*0x1067037c7*/
    }
    else if ( FFlag::NextGenReplicatorEnabledRead != 0 && FFlag::NextGenReplicatorEnabledWrite == 1 ) /*0x1067037e1*/
    {
      goto LABEL_21; /*0x1067037e1*/
    }
    std::allocate_shared[abi:ne200100]<RBX::Network::PhysicsSenderS2,std::allocator<RBX::Network::PhysicsSenderS2>,RBX::Network::ClientReplicator &,0>( /*0x1067037f1*/
      a1: v97,
      a2: v107,
      a3: this);
    std::shared_ptr<RBX::Network::PhysicsSenderS2>::operator=[abi:ne200100](a1: (char *)this + 18552, a2: v97); /*0x106703807*/
    v19 = v97[1]; /*0x10670380c*/
    if ( v97[1] != nullptr /*0x106703825*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v97[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v19 + 16LL))(a1: v19); /*0x10670382d*/
      std::__shared_weak_count::__release_weak(this: v19); /*0x106703833*/
    }
    goto LABEL_21; /*0x106703833*/
  }
  if ( v6 != 151 ) /*0x106703621*/
    return RBX::Network::Replicator::processPacketV2(this, a2: v4, a3); /*0x1067037a1*/
  RBX::Network::Replicator::addReplicatorState(this); /*0x10670362f*/
  v7 = (unsigned __int8 *)RBX::Network::IncomingPacket::data(this: v4); /*0x10670363c*/
  v8 = RBX::Network::IncomingPacket::size(this: v4); /*0x106703645*/
  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)v97, a2: v7, a3: v8, a4: false); /*0x10670365b*/
  RBX::Network::MegaReplicator::initializeSharedNetworkSchema( /*0x10670366d*/
    this: *((RBX::Network::MegaReplicator **)this + 1801),
    a2: this,
    a3: (RBX::Network::NetworkStream *)v97);
  v9 = (const RBX::Network::NetworkSchema *)RBX::Network::MegaReplicator::getSharedNetworkSchema(this: *((RBX::Network::MegaReplicator **)this + 1801)); /*0x106703679*/
  RBX::Network::TwoWayBandwidthMetrics::setSchema(this: (RBX::Network::ClientReplicator *)((char *)this + 288), a2: v9); /*0x106703688*/
  RBX::Network::LargeReplicator::schemaUpdated(this: *((RBX::Network::LargeReplicator **)this + 1400)); /*0x106703694*/
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v97); /*0x1067036a0*/
  return (unsigned int)RBX::Network::IncomingPacket::size(this: v4); /*0x106704371*/
}

// Address: 0x106704702 | Name: __ZN3RBX7Network16ClientReplicator24processPacket_deprecatedEPN6RakNet6PacketEm
__int64 __fastcall RBX::Network::ClientReplicator::processPacket_deprecated(RBX::DataModel *this, __int64 a2)
{
  unsigned __int8 *v4; // rsi
  int v5; // eax
  __int64 v6; // rbx
  unsigned __int8 *v7; // rsi
  const RBX::Network::NetworkSchema *v8; // rax
  RBX::Network::NetworkStream *v9; // rdi
  __int64 v10; // rbx
  RBX::Instance *v11; // rsi
  __int64 v12; // rax
  std::__shared_weak_count *v13; // rbx
  __int64 *v14; // rax
  unsigned __int64 v15; // rsi
  RBX::Network::PhysicsReceiverS2 *v16; // r15
  __int64 v18; // rax
  RBX::Network::PhysicsSenderS2 *v19; // r15
  unsigned __int64 v20; // rsi
  RBX::Instance *v21; // rsi
  RBX::DataModel *v22; // rax
  RBX::Instance *v23; // rsi
  __int64 v24; // rdx
  __int64 v25; // rcx
  __int64 v26; // rbx
  const char *v27; // rsi
  void *v28; // rsi
  __int64 v29; // r8
  std::__shared_weak_count *v30; // rbx
  std::__shared_weak_count *v31; // rbx
  __int64 v32; // rax
  std::__shared_weak_count *v33; // rbx
  __int64 v34; // rax
  unsigned __int64 v35; // rsi
  std::__shared_weak_count *v36; // rbx
  RBX::Network::ClientReplicator::GCJob *v37; // r15
  __int64 v38; // rax
  std::__shared_weak_count *v39; // rbx
  char v40; // al
  unsigned __int64 v41; // rsi
  __int64 v42; // r15
  __int64 v43; // r12
  __int64 v44; // rax
  __int64 v45; // rax
  std::__shared_weak_count *v46; // r12
  std::__shared_weak_count *v47; // r12
  __int64 v48; // rdi
  __int64 v49; // rax
  std::__shared_weak_count *v50; // rbx
  int v51; // esi
  __int64 v52; // r13
  __int64 v53; // r12
  unsigned int v54; // esi
  rbx::signals::slots_holder **v55; // r15
  unsigned __int64 v56; // rsi
  unsigned __int64 v57; // rbx
  rbx::signals::slots_holder *v58; // rax
  __int64 v59; // rax
  rbx::signals::slots_holder *v60; // rdi
  unsigned int v61; // esi
  std::__shared_weak_count *v62; // rdi
  char Bool; // r13
  char v64; // bl
  char v65; // r15
  const RBX::Instance *v66; // rsi
  RBX::ServiceProvider *ServiceProvider; // rax
  RBX::PermissionsService *v68; // r12
  const RBX::Instance *v69; // rsi
  RBX::ServiceProvider *v70; // rax
  RBX::Ads::AdService *v71; // rax
  char v72; // al
  RBX::Network::NetworkStream *v73; // rdx
  __int64 v74; // rdi
  unsigned int v75; // esi
  RBX::Instance *v76; // rsi
  __int64 v77; // rbx
  __int64 v78; // r15
  RBX::Network::NetworkSchema *SharedNetworkSchema; // rax
  unsigned __int8 v80; // al
  unsigned __int8 v81; // al
  unsigned __int8 v82; // al
  unsigned int v83; // ebx
  __int64 v84; // rax
  __int64 v85; // rdi
  __int64 v86; // rsi
  __int64 v87; // rax
  __int64 v88; // rdi
  _BYTE *EngineNetConfiguration; // rax
  std::__shared_weak_count *v90[2]; // [rsp+0h] [rbp-320h] BYREF
  void *v91; // [rsp+10h] [rbp-310h]
  _BYTE v92[536]; // [rsp+48h] [rbp-2D8h] BYREF
  unsigned int v93[16]; // [rsp+260h] [rbp-C0h] BYREF
  std::__shared_weak_count *v94[2]; // [rsp+2A0h] [rbp-80h] BYREF
  std::__shared_weak_count *v95[2]; // [rsp+2B0h] [rbp-70h] BYREF
  std::__shared_weak_count *v96[2]; // [rsp+2C0h] [rbp-60h] BYREF
  __int64 v97; // [rsp+2D0h] [rbp-50h]
  __int64 v98; // [rsp+2D8h] [rbp-48h] BYREF
  RBX::DataModel *v99; // [rsp+2E0h] [rbp-40h]
  RBX::Instance *v100; // [rsp+2E8h] [rbp-38h] BYREF
  unsigned int v101; // [rsp+2F0h] [rbp-30h]
  char v102; // [rsp+2F6h] [rbp-2Ah] BYREF
  _BYTE v103[41]; // [rsp+2F7h] [rbp-29h] BYREF

  v4 = *(unsigned __int8 **)(a2 + 56); /*0x10670471c*/
  v5 = *v4; /*0x106704720*/
  if ( v5 == 129 ) /*0x106704728*/
  {
    v97 = a2; /*0x1067047a6*/
    RBX::Network::NetworkStream::NetworkStream( /*0x1067047b9*/
      this: (RBX::Network::NetworkStream *)v93,
      a2: v4,
      a3: *(_DWORD *)(a2 + 48),
      a4: false);
    RBX::Network::NetworkStream::IgnoreBytes(this: (RBX::Network::NetworkStream *)v93, a2: 1u); /*0x1067047c6*/
    v10 = *((_QWORD *)this + 1801); /*0x1067047cb*/
    v12 = RBX::DataModel::get(this, a2: v11); /*0x1067047d5*/
    RBX::shared_from<RBX::DataModel>(a1: v90, a2: v12); /*0x1067047e4*/
    RBX::Network::MegaReplicator::startMegaJobs(a1: v10, a2: v90); /*0x1067047f3*/
    v13 = v90[1]; /*0x1067047f8*/
    if ( v90[1] != nullptr /*0x106704814*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v90[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v13 + 16LL))(a1: v13); /*0x10670481c*/
      std::__shared_weak_count::__release_weak(this: v13); /*0x106704822*/
    }
    if ( (*(unsigned __int8 (__fastcall **)(RBX::DataModel *))(*(_QWORD *)this + 1032LL))(a1: this) != 0 ) /*0x106704835*/
    {
LABEL_20:
      *((_BYTE *)this + 15544) = RBX::Network::NetworkStream::readBool(this: (RBX::Network::NetworkStream *)v93); /*0x10670491c*/
      v22 = (RBX::DataModel *)RBX::DataModel::get(this, a2: v21); /*0x106704932*/
      if ( v22 != nullptr && (unsigned __int8)RBX::DataModel::getShouldSetGlobalTelemetryInfo(this: v22) != 0 ) /*0x106704946*/
        RBX::Analytics::setStreamingEnabled(this: (RBX::Analytics *)*((unsigned __int8 *)this + 15544), a2: (bool)v23); /*0x106704950*/
      v26 = RBX::DataModel::get(this, a2: v23); /*0x10670495d*/
      v27 = "disabled"; /*0x106704967*/
      if ( *((_BYTE *)this + 15544) != 0 ) /*0x106704976*/
        v27 = "enabled"; /*0x106704976*/
      std::string::basic_string[abi:ne200100]<0>(a1: v90, a2: v27, a3: v24, a4: v25); /*0x106704981*/
      RBX::DataModel::setContextAttribute(a1: v26, a2: 12, a3: v90); /*0x106704995*/
      if ( ((__int64)v90[0] & 1) != 0 ) /*0x1067049a1*/
        operator delete(a1: (RBX::Memory *)v91, a2: v28); /*0x1067049aa*/
      if ( *((_BYTE *)this + 15544) == 1 ) /*0x1067049b7*/
      {
        v98 = RBX::DataModel::get(this, a2: (RBX::Instance *)v28); /*0x1067049c9*/
        v100 = this; /*0x1067049d0*/
        v29 = *((_QWORD *)this + 1801); /*0x1067049d3*/
        v102 = 0; /*0x1067049de*/
        std::allocate_shared[abi:ne200100]<RBX::Network::InstanceObjectManager,std::allocator<RBX::Network::InstanceObjectManager>,RBX::DataModel *&,RBX::Network::ClientReplicator *,RBX::Network::MegaReplicator &,bool,0>( /*0x1067049ed*/
          a1: v90,
          a2: v103,
          a3: &v98,
          a4: &v100,
          a5: v29,
          a6: &v102);
        std::shared_ptr<RBX::Network::InstanceObjectManager>::operator=[abi:ne200100](a1: (char *)this + 22056, a2: v90); /*0x106704a06*/
        v30 = v90[1]; /*0x106704a0b*/
        if ( v90[1] != nullptr /*0x106704a24*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v90[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v30 + 16LL))(a1: v30); /*0x106704a2c*/
          std::__shared_weak_count::__release_weak(this: v30); /*0x106704a32*/
        }
        v103[0] = 0; /*0x106704a37*/
        v102 = (*(__int64 (__fastcall **)(RBX::DataModel *))(*(_QWORD *)this + 1032LL))(a1: this); /*0x106704a4b*/
        std::allocate_shared[abi:ne200100]<RBX::Network::StreamingSolverV2,std::allocator<RBX::Network::StreamingSolverV2>,RBX::DataModel *&,std::shared_ptr<RBX::Network::InstanceObjectManager> &,bool,bool,0>( /*0x106704a64*/
          a1: v90,
          a2: &v100,
          a3: &v98,
          a4: (char *)this + 22056,
          a5: v103);
        std::shared_ptr<RBX::Network::StreamingSolverV2>::operator=[abi:ne200100](a1: (char *)this + 22040, a2: v90); /*0x106704a7d*/
        v31 = v90[1]; /*0x106704a82*/
        if ( v90[1] != nullptr /*0x106704a9b*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v90[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v31 + 16LL))(a1: v31); /*0x106704aa3*/
          std::__shared_weak_count::__release_weak(this: v31); /*0x106704aa9*/
        }
        RBX::Network::MegaReplicator::setObjectManager(a1: *((_QWORD *)this + 1801), a2: (char *)this + 22056); /*0x106704ab8*/
        RBX::Network::MegaReplicator::setStreamingSolverV2(a1: *((_QWORD *)this + 1801), a2: (char *)this + 22040); /*0x106704ac7*/
        v32 = *((_QWORD *)this + 2758); /*0x106704acc*/
        *(_OWORD *)v90 = *(_OWORD *)((char *)this + 22056); /*0x106704ad4*/
        if ( v32 != 0 ) /*0x106704ade*/
          _InterlockedIncrement64((volatile signed __int64 *)(v32 + 8)); /*0x106704ae0*/
        RBX::TaskScheduler::add(a1: v90); /*0x106704aec*/
        v33 = v90[1]; /*0x106704af1*/
        if ( v90[1] != nullptr /*0x106704b0d*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v90[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v33 + 16LL))(a1: v33); /*0x106704b15*/
          std::__shared_weak_count::__release_weak(this: v33); /*0x106704b1b*/
        }
        v34 = *((_QWORD *)this + 2756); /*0x106704b20*/
        *(_OWORD *)v90 = *(_OWORD *)((char *)this + 22040); /*0x106704b2a*/
        if ( v34 != 0 ) /*0x106704b34*/
          _InterlockedIncrement64((volatile signed __int64 *)(v34 + 8)); /*0x106704b36*/
        RBX::TaskScheduler::add(a1: v90); /*0x106704b42*/
        v36 = v90[1]; /*0x106704b47*/
        if ( v90[1] != nullptr /*0x106704b63*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v90[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v36 + 16LL))(a1: v36); /*0x106704b6b*/
          std::__shared_weak_count::__release_weak(this: v36); /*0x106704b71*/
        }
        v37 = (RBX::Network::ClientReplicator::GCJob *)operator new(a1: (RBX::Memory *)0x1090, a2: v35); /*0x106704b80*/
        RBX::Network::ClientReplicator::GCJob::GCJob(this: v37, a2: this); /*0x106704b89*/
        std::shared_ptr<RBX::Network::ClientReplicator::GCJob>::reset[abi:ne200100]<RBX::Network::ClientReplicator::GCJob,0>( /*0x106704b9b*/
          a1: (char *)this + 22024,
          a2: v37);
        v38 = *((_QWORD *)this + 2754); /*0x106704ba0*/
        *(_OWORD *)v90 = *(_OWORD *)((char *)this + 22024); /*0x106704ba7*/
        if ( v38 != 0 ) /*0x106704bb1*/
          _InterlockedIncrement64((volatile signed __int64 *)(v38 + 8)); /*0x106704bb3*/
        RBX::TaskScheduler::add(a1: v90); /*0x106704bbf*/
        v39 = v90[1]; /*0x106704bc4*/
        if ( v90[1] != nullptr /*0x106704be0*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v90[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v39 + 16LL))(a1: v39); /*0x106704be8*/
          std::__shared_weak_count::__release_weak(this: v39); /*0x106704bee*/
        }
        v40 = *((_BYTE *)this + 15544); /*0x106704bf3*/
      }
      else
      {
        v40 = 0; /*0x106704bfc*/
      }
      RBX::Network::MegaReplicator::setIsStreamingEnabled( /*0x106704c0b*/
        this: *((RBX::Network::MegaReplicator **)this + 1801),
        a2: v40 & 1);
      if ( (unsigned __int8)RBX::Network::NetworkStream::readBool(this: (RBX::Network::NetworkStream *)v93) != 0 ) /*0x106704c1e*/
      {
        v42 = RBX::ServiceProvider::find<RBX::Network::Client>(a1: this); /*0x106704c2c*/
        if ( v42 != 0 ) /*0x106704c32*/
        {
          v43 = operator new(a1: (RBX::Memory *)0x70, a2: v41); /*0x106704c42*/
          v44 = *(_QWORD *)(v42 + 400); /*0x106704c45*/
          *(_OWORD *)v94 = *(_OWORD *)(v42 + 392); /*0x106704c54*/
          if ( v44 != 0 ) /*0x106704c5b*/
            _InterlockedIncrement64((volatile signed __int64 *)(v44 + 8)); /*0x106704c5d*/
          v45 = *(_QWORD *)(v42 + 416); /*0x106704c62*/
          *(_OWORD *)v95 = *(_OWORD *)(v42 + 408); /*0x106704c71*/
          if ( v45 != 0 ) /*0x106704c78*/
            _InterlockedIncrement64((volatile signed __int64 *)(v45 + 8)); /*0x106704c7a*/
          RBX::Network::StrictNetworkFilter::StrictNetworkFilter(a1: v43, a2: this, a3: v94, a4: v95); /*0x106704c8d*/
          std::unique_ptr<RBX::Network::StrictNetworkFilter>::reset[abi:ne200100](a1: (char *)this + 12536, a2: v43); /*0x106704c9f*/
          v46 = v95[1]; /*0x106704ca4*/
          if ( v95[1] != nullptr /*0x106704cbe*/
            && _InterlockedExchangeAdd64((volatile signed __int64 *)v95[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
          {
            (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v46 + 16LL))(a1: v46); /*0x106704cc7*/
            std::__shared_weak_count::__release_weak(this: v46); /*0x106704ccd*/
          }
          v47 = v94[1]; /*0x106704cd2*/
          if ( v94[1] != nullptr /*0x106704cec*/
            && _InterlockedExchangeAdd64((volatile signed __int64 *)v94[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
          {
            (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v47 + 16LL))(a1: v47); /*0x106704cf5*/
            std::__shared_weak_count::__release_weak(this: v47); /*0x106704cfb*/
          }
          if ( FFlag::NetworkFilterTelemetry == 1 ) /*0x106704d0a*/
          {
            v48 = *((_QWORD *)this + 1567); /*0x106704d0c*/
            v49 = *(_QWORD *)(v42 + 384); /*0x106704d0f*/
            *(_OWORD *)v96 = *(_OWORD *)(v42 + 376); /*0x106704d1e*/
            if ( v49 != 0 ) /*0x106704d25*/
              _InterlockedIncrement64((volatile signed __int64 *)(v49 + 8)); /*0x106704d27*/
            RBX::Network::StrictNetworkFilter::setGlobalStats(a1: v48, a2: v96); /*0x106704d30*/
            v50 = v96[1]; /*0x106704d35*/
            if ( v96[1] != nullptr /*0x106704d4e*/
              && _InterlockedExchangeAdd64((volatile signed __int64 *)v96[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
            {
              (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v50 + 16LL))(a1: v50); /*0x106704d56*/
              std::__shared_weak_count::__release_weak(this: v50); /*0x106704d5c*/
            }
          }
        }
      }
      v99 = (RBX::DataModel *)RBX::ServiceProvider::find<RBX::Workspace>(a1: this); /*0x106704d69*/
      if ( ((v99 != nullptr) /*0x106704d87*/
          & (unsigned __int8)RBX::Analytics::InfluxDb::canSend(
                               this: (RBX::Analytics::InfluxDb *)(unsigned int)DFInt::StreamingJoinStatsHundredths,
                               a2: v51)) == 1 )
      {
        v52 = *((_QWORD *)this + 2753); /*0x106704d8d*/
        if ( v52 != 0 ) /*0x106704d97*/
        {
          v53 = *((_QWORD *)this + 2754); /*0x106704d9d*/
          if ( v53 != 0 ) /*0x106704da7*/
            _InterlockedIncrement64((volatile signed __int64 *)(v53 + 16)); /*0x106704da9*/
          rbx::signal<void ()(void)>::invokeImpl<(rbx::SignalInvokePolicy)0>(a1: (RBX::DataModel *)((char *)v99 + 1472)); /*0x106704dba*/
          v101 = RBX::Memory::setCurrentCategory( /*0x106704dcd*/
                   this: (RBX::Memory *)(unsigned int)RBX::Memory::InstanceSignal,
                   a2: v54);
          v55 = (rbx::signals::slots_holder **)((char *)v99 + 1464); /*0x106704dd4*/
          rbx::lazyInitSlotsHolder(a1: (char *)v99 + 1464); /*0x106704dde*/
          v57 = rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x40, a2: v56); /*0x106704ded*/
          *(_QWORD *)v57 = &_mh_execute_header; /*0x106704dfa*/
          *(_QWORD *)(v57 + 8) = rbx::signals::slot_with_functor<RBX::Network::ClientReplicator::processPacket_deprecated(RakNet::Packet *,unsigned long)::$_0,std::shared_ptr<RBX::Player>>::do_call; /*0x106704e04*/
          *(_OWORD *)(v57 + 16) = 0; /*0x106704e0b*/
          v58 = *v55; /*0x106704e0f*/
          *(_QWORD *)(v57 + 32) = *v55; /*0x106704e12*/
          if ( v58 != nullptr ) /*0x106704e19*/
          {
            _InterlockedIncrement((volatile signed __int32 *)v58 + 1); /*0x106704e1b*/
            v59 = *(_QWORD *)(v57 + 24) | 4LL; /*0x106704e23*/
            v60 = *v55; /*0x106704e27*/
          }
          else
          {
            v59 = 4; /*0x106704e2c*/
            v60 = nullptr; /*0x106704e31*/
          }
          *(_QWORD *)(v57 + 24) = v59; /*0x106704e33*/
          *(_QWORD *)(v57 + 40) = rbx::signals::slot_with_functor<RBX::Network::ClientReplicator::processPacket_deprecated(RakNet::Packet *,unsigned long)::$_0,std::shared_ptr<RBX::Player>>::do_dtor; /*0x106704e3e*/
          *(_QWORD *)(v57 + 48) = v52; /*0x106704e42*/
          *(_QWORD *)(v57 + 56) = v53; /*0x106704e46*/
          rbx::signals::slots_holder::insert(this: v60, a2: v57); /*0x106704e50*/
          v90[0] = (std::__shared_weak_count *)v57; /*0x106704e55*/
          _InterlockedIncrement((volatile signed __int32 *)(v57 + 4)); /*0x106704e5c*/
          RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v101, a2: v61); /*0x106704e63*/
          rbx::signals::scoped_connection::operator=(this: (RBX::DataModel *)((char *)this + 23904)); /*0x106704e76*/
          v62 = v90[0]; /*0x106704e7b*/
          if ( v90[0] != nullptr && _InterlockedDecrement((volatile signed __int32 *)v90[0] + 1) == 0 ) /*0x106704e8b*/
            rbx::signals::slot_base::operator delete(a1: v62); /*0x106704e8d*/
        }
      }
      Bool = RBX::Network::NetworkStream::readBool(this: (RBX::Network::NetworkStream *)v93); /*0x106704e9e*/
      v64 = RBX::Network::NetworkStream::readBool(this: (RBX::Network::NetworkStream *)v93); /*0x106704ead*/
      v65 = RBX::Network::NetworkStream::readBool(this: (RBX::Network::NetworkStream *)v93); /*0x106704ebb*/
      if ( (unsigned __int8)RBX::Network::Replicator::getIsOnDemandAdsCapabilityEnabled(this) != 0 ) /*0x106704ec8*/
        v101 = RBX::Network::NetworkStream::readBool(this: (RBX::Network::NetworkStream *)v93); /*0x106704ed6*/
      else
        v101 = 0; /*0x106704edb*/
      ServiceProvider = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(this, a2: v66); /*0x106704ee5*/
      if ( ServiceProvider != nullptr ) /*0x106704eed*/
        v68 = (RBX::PermissionsService *)RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::PermissionsService>(this: ServiceProvider); /*0x106704ef7*/
      else
        v68 = nullptr; /*0x106704efc*/
      RBX::PermissionsService::setThirdPartyAssetAllowed(this: v68, a2: Bool); /*0x106704f06*/
      RBX::PermissionsService::setThirdPartyPurchaseAllowed(this: v68, a2: v64); /*0x106704f11*/
      RBX::PermissionsService::setThirdPartyTeleportAllowed(this: v68, a2: v65); /*0x106704f1d*/
      if ( (unsigned __int8)RBX::Network::Replicator::getIsOnDemandAdsCapabilityEnabled(this) != 0 ) /*0x106704f2c*/
      {
        RBX::PermissionsService::setOnDemandAdsAllowed(this: v68, a2: v101); /*0x106704f35*/
        if ( (_BYTE)v101 != 0 ) /*0x106704f3e*/
        {
          v70 = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(this, a2: v69); /*0x106704f43*/
          if ( v70 != nullptr ) /*0x106704f4b*/
          {
            v71 = (RBX::Ads::AdService *)RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::Ads::AdService>(this: v70); /*0x106704f50*/
            if ( v71 != nullptr ) /*0x106704f58*/
              RBX::Ads::AdService::handleOnDemandAdsEnabledAtClient(this: v71); /*0x106704f5d*/
          }
        }
      }
      v72 = RBX::Network::NetworkStream::readBool(this: (RBX::Network::NetworkStream *)v93); /*0x106704f69*/
      v74 = *((_QWORD *)this + 1808); /*0x106704f6e*/
      if ( v74 != 0 ) /*0x106704f78*/
        RBX::PlayersProp::setCharacterAutoSpawnProperty(this: (RBX::PlayersProp *)(v74 + 192), a2: v72); /*0x106704f84*/
      RBX::Network::deserializeUnsignedVarint(this: (RBX::Network *)&v100, a2: v93, a3: v73); /*0x106704f94*/
      if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x106704fb2*/
        FLog::FastLog(a1: FLog::Network, a2: qword_10D7BBAA8, a3: "[FLog::Network] Assigned peer id = %u", (_DWORD)v100); /*0x106704fc7*/
      RBX::World::setLocalPeerId(this: *((RBX::World **)v99 + 118), a2: (int)v100); /*0x106704fda*/
      v75 = (unsigned int)v100; /*0x106704fdf*/
      *((_DWORD *)this + 48) = (_DWORD)v100; /*0x106704fe2*/
      RBX::Network::MegaReplicator::setReplicatingPeerId(this: *((RBX::Network::MegaReplicator **)this + 1801), a2: v75); /*0x106704ff0*/
      if ( FFlag::DebugHashTableMetrics != 0 /*0x10670501b*/
        || (FFlag::SAuthWorkspaceFlagged & 1) != 0
        || FFlag::NextGenReplicatorEnabledRead == 1 )
      {
        v77 = *((_QWORD *)this + 1801); /*0x10670501d*/
        v78 = RBX::DataModel::get(this: v99, a2: v76); /*0x10670502d*/
        SharedNetworkSchema = (RBX::Network::NetworkSchema *)RBX::Network::MegaReplicator::getSharedNetworkSchema(this: *((RBX::Network::MegaReplicator **)this + 1801)); /*0x106705037*/
        v90[0] = *(std::__shared_weak_count **)RBX::Network::NetworkSchema::getEngineNetConfiguration(this: SharedNetworkSchema); /*0x10670504e*/
        RBX::Network::MegaReplicator::initializeIsrManager(a1: v77, a2: v78); /*0x106705057*/
        if ( FFlag::DebugHashTableMetrics != 0 /*0x106705074*/
          || (FFlag::SAuthWorkspaceFlagged & 1) != 0
          || FFlag::NextGenReplicatorEnabledRead == 1 )
        {
          RBX::Network::InstanceReplication::RbxInstanceReplicatorManager::onConnectionReady( /*0x106705091*/
            a1: *(_QWORD *)(*((_QWORD *)this + 1801) + 920LL),
            a2: *(unsigned int *)(*((_QWORD *)this + 35) + 1408LL));
        }
      }
      if ( (unsigned __int8)RBX::Analytics::InfluxDb::canSend( /*0x1067050a6*/
                              this: (RBX::Analytics::InfluxDb *)(unsigned int)DFInt::ISRUsageStatsTelemetryThrottle,
                              a2: (int)v76) == 0 )
        goto LABEL_125; /*0x1067050a6*/
      RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x1067050ba*/
        a1: (__int64)v90,
        a2: (__int64)&RBX::Telemetry::kISRUsageStats);
      if ( (unsigned __int8)RBX::Telemetry::RobloxTelemetryEvent::willThrottlePoints(this: (RBX::Telemetry::RobloxTelemetryEvent *)v90) != 0 ) /*0x1067050cd*/
      {
LABEL_124:
        RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v90); /*0x10670526c*/
LABEL_125:
        *((_DWORD *)this + 4072) = (_DWORD)v100; /*0x10670527f*/
        v83 = 0; /*0x106705290*/
        if ( FFlag::NetAssetSubsystem == 1 ) /*0x106705296*/
        {
          v84 = RBX::ServiceProvider::find<RBX::Network::Client>(a1: this); /*0x10670529b*/
          if ( v84 != 0 ) /*0x1067052a3*/
            v83 = *(_DWORD *)(v84 + 448); /*0x1067052a5*/
        }
        v85 = *((_QWORD *)this + 1400); /*0x1067052ab*/
        v86 = *((unsigned int *)this + 4072); /*0x1067052b2*/
        if ( FFlag::NetAssetSubsystem == 1 ) /*0x1067052bd*/
        {
          RBX::Network::LargeReplicator::setPeerId_subsystem(a1: v85, a2: v86, a3: v83); /*0x1067052c1*/
          *((_DWORD *)this + 49) = v83; /*0x1067052c6*/
        }
        else
        {
          RBX::Network::LargeReplicator::setPeerId_context(a1: v85, a2: v86); /*0x1067052cf*/
        }
        *((_DWORD *)this + 5500) = (_DWORD)v100; /*0x1067052d7*/
        v87 = RBX::ServiceProvider::find<RBX::Players>(a1: this); /*0x1067052e1*/
        if ( v87 != 0 ) /*0x1067052e9*/
          *(_DWORD *)(v87 + 1352) = *((_DWORD *)this + 5500); /*0x1067052f2*/
        RBX::Network::Replicator::schemaReadTopReplicationContainerStateFromStream( /*0x106705307*/
          this,
          a2: (RBX::Network::NetworkStream *)v93,
          a3: true);
        *((_QWORD *)this + 1948) = 2; /*0x10670530c*/
        *((_BYTE *)this + 22004) = 1; /*0x106705317*/
        rbx::signal<void ()(void)>::invokeImpl<(rbx::SignalInvokePolicy)0>(a1: (RBX::DataModel *)((char *)this + 24432)); /*0x106705326*/
        v88 = *((_QWORD *)this + 1801); /*0x10670532b*/
        ++*(_DWORD *)(v88 + 3244); /*0x106705332*/
        *((_BYTE *)this + 18700) = 1; /*0x106705338*/
        if ( FFlag::InputReplicatorNonSAuth != 0 /*0x1067053a0*/
          || (EngineNetConfiguration = (_BYTE *)RBX::Network::NetworkSchema::getEngineNetConfiguration(this: (RBX::Network::NetworkSchema *)(v88 + 1608)),
              FFlag::DebugHashTableMetrics != 0)
          || FFlag::SAuthWorkspaceFlagged == 1 && (*EngineNetConfiguration & 8) != 0 )
        {
          RBX::Network::Replicator::initializeInputReplicator(this); /*0x106705362*/
        }
        RBX::Network::Replicator::enableDeserializePacketsJob(this); /*0x10670536a*/
        v9 = (RBX::Network::NetworkStream *)v93; /*0x10670536f*/
        goto LABEL_137; /*0x10670536f*/
      }
      v80 = 1; /*0x1067050da*/
      if ( FFlag::DebugHashTableMetrics == 0 && (FFlag::SAuthWorkspaceFlagged & 1) == 0 ) /*0x1067050e8*/
        v80 = FFlag::NextGenReplicatorEnabledRead; /*0x1067050f1*/
      RBX::Telemetry::FieldsContainer::addField(a1: v92, a2: "ISRReadEnabled", a3: 14, a4: v80, a5: 1); /*0x10670510b*/
      RBX::Network::NetworkSchema::getEngineNetConfigurationDynamic(this: (RBX::Network::NetworkSchema *)&v98); /*0x106705120*/
      v81 = 1; /*0x106705125*/
      if ( FFlag::DebugHashTableMetrics == 0 ) /*0x10670512c*/
      {
        if ( FFlag::SAuthWorkspaceFlagged == 1 ) /*0x1067051a9*/
        {
          if ( (v98 & 8) == 0 && FFlag::NextGenReplicatorEnabledWrite == 0 ) /*0x1067051c2*/
            v81 = v98 & 1; /*0x1067051cb*/
        }
        else if ( FFlag::NextGenReplicatorEnabledRead == 1 ) /*0x1067051dc*/
        {
          v81 = FFlag::NextGenReplicatorEnabledWrite; /*0x1067051e9*/
        }
        else
        {
          v81 = 0; /*0x1067053a4*/
        }
      }
      RBX::Telemetry::FieldsContainer::addField(a1: v92, a2: "ISRWriteEnabled", a3: 15, a4: v81, a5: 1); /*0x106705146*/
      RBX::Network::NetworkSchema::getEngineNetConfigurationDynamic(this: (RBX::Network::NetworkSchema *)&v98); /*0x10670515b*/
      v82 = 1; /*0x106705160*/
      if ( FFlag::DebugHashTableMetrics == 0 ) /*0x106705167*/
      {
        if ( FFlag::SAuthWorkspaceFlagged == 1 ) /*0x106705172*/
        {
          if ( (v98 & 8) == 0 ) /*0x10670517b*/
          {
            if ( FFlag::ISREnabledCanRemoveRtMessaging != 0 ) /*0x10670518b*/
            {
              if ( FFlag::NextGenReplicatorEnabledWrite == 0 ) /*0x10670519b*/
                v82 = v98 & 1; /*0x1067051a0*/
              goto LABEL_123; /*0x1067051a2*/
            }
            goto LABEL_122; /*0x10670518b*/
          }
        }
        else
        {
          if ( FFlag::ISREnabledCanRemoveRtMessaging != 1 || FFlag::NextGenReplicatorEnabledRead != 1 ) /*0x106705206*/
          {
LABEL_122:
            v82 = 0; /*0x106705213*/
            goto LABEL_123; /*0x106705213*/
          }
          v82 = FFlag::NextGenReplicatorEnabledWrite; /*0x10670520f*/
        }
      }
LABEL_123:
      RBX::Telemetry::FieldsContainer::addField( /*0x106705215*/
        a1: v92,
        a2: "ISRLegacyMessagingServicesBlocked",
        a3: 33,
        a4: v82,
        a5: 1);
      RBX::Telemetry::FieldsContainer::addField( /*0x10670525b*/
        a1: v92,
        a2: "ISRManagerInitialized",
        a3: 21,
        a4: *(_QWORD *)(*((_QWORD *)this + 1801) + 920LL) != 0,
        a5: 1);
      RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v90); /*0x106705267*/
      goto LABEL_124; /*0x106705267*/
    }
    v14 = (__int64 *)RBX::Network::NetworkSchema::getEngineNetConfiguration(this: (RBX::Network::NetworkSchema *)(*((_QWORD *)this + 1801) + 1608LL)); /*0x106704847*/
    if ( FFlag::DebugHashTableMetrics != 0 ) /*0x106704856*/
      goto LABEL_9; /*0x106704856*/
    if ( FFlag::SAuthWorkspaceFlagged == 1 ) /*0x106704891*/
    {
      v18 = *v14; /*0x106704893*/
      if ( (v18 & 8) != 0 || (v18 & 1) != 0 || FFlag::NextGenReplicatorEnabledWrite != 0 ) /*0x1067048a8*/
      {
LABEL_9:
        v16 = (RBX::Network::PhysicsReceiverS2 *)operator new(a1: (RBX::Memory *)0xE8, a2: v15); /*0x106704858*/
        RBX::Network::PhysicsReceiverS2::PhysicsReceiverS2(this: v16, a2: this, a3: false); /*0x10670486d*/
LABEL_19:
        std::shared_ptr<RBX::Network::PhysicsReceiverS2>::reset[abi:ne200100]<RBX::Network::PhysicsReceiverS2,0>( /*0x106704905*/
          a1: (char *)this + 18584,
          a2: v16);
        RBX::Network::Replicator::getOrCreatePhysicsTouchSerializer(this); /*0x106704917*/
        goto LABEL_20; /*0x106704917*/
      }
    }
    else if ( FFlag::NextGenReplicatorEnabledRead != 0 && FFlag::NextGenReplicatorEnabledWrite == 1 ) /*0x1067048c2*/
    {
      goto LABEL_9; /*0x1067048c2*/
    }
    v19 = (RBX::Network::PhysicsSenderS2 *)operator new(a1: (RBX::Memory *)0x148, a2: v15); /*0x1067048ce*/
    RBX::Network::PhysicsSenderS2::PhysicsSenderS2(this: v19, a2: this); /*0x1067048d7*/
    std::shared_ptr<RBX::Network::PhysicsSenderS2>::reset[abi:ne200100]<RBX::Network::PhysicsSenderS2,0>( /*0x1067048e6*/
      a1: (char *)this + 18552,
      a2: v19);
    v16 = (RBX::Network::PhysicsReceiverS2 *)operator new(a1: (RBX::Memory *)0xE8, a2: v20); /*0x1067048f5*/
    RBX::Network::PhysicsReceiverS2::PhysicsReceiverS2(this: v16, a2: this, a3: false); /*0x106704900*/
    goto LABEL_19; /*0x106704900*/
  }
  if ( v5 != 151 ) /*0x10670472f*/
    return RBX::Network::Replicator::processPacket_deprecated(this); /*0x106704882*/
  v6 = a2; /*0x10670473d*/
  RBX::Network::Replicator::addReplicatorState(this); /*0x106704740*/
  v7 = *(unsigned __int8 **)(v6 + 56); /*0x106704745*/
  v97 = v6; /*0x106704749*/
  RBX::Network::NetworkStream::NetworkStream( /*0x10670475c*/
    this: (RBX::Network::NetworkStream *)v90,
    a2: v7,
    a3: *(_DWORD *)(v6 + 48),
    a4: false);
  RBX::Network::MegaReplicator::initializeSharedNetworkSchema( /*0x10670476e*/
    this: *((RBX::Network::MegaReplicator **)this + 1801),
    a2: this,
    a3: (RBX::Network::NetworkStream *)v90);
  v8 = (const RBX::Network::NetworkSchema *)RBX::Network::MegaReplicator::getSharedNetworkSchema(this: *((RBX::Network::MegaReplicator **)this + 1801)); /*0x10670477a*/
  RBX::Network::TwoWayBandwidthMetrics::setSchema(this: (RBX::DataModel *)((char *)this + 288), a2: v8); /*0x106704789*/
  RBX::Network::LargeReplicator::schemaUpdated(this: *((RBX::Network::LargeReplicator **)this + 1400)); /*0x106704795*/
  v9 = (RBX::Network::NetworkStream *)v90; /*0x10670479a*/
LABEL_137:
  RBX::Network::NetworkStream::~NetworkStream(this: v9); /*0x106705376*/
  return *(unsigned int *)(v97 + 48); /*0x106705384*/
}

// Address: 0x10670565a | Name: __ZN3RBX7Network16ClientReplicator36onTerrainRegionChangedStreamingAwareERKNS_6Voxel26RegionEjNS_23DeferredTerrainContentsENS_23TerrainGridChangeSourceE
char __fastcall RBX::Network::ClientReplicator::onTerrainRegionChangedStreamingAware(
        __int64 a1,
        __int64 a2,
        int a3,
        unsigned __int8 a4,
        unsigned int a5)
{
  int v6; // eax
  RBX::Network::StrictNetworkFilter *v10; // rdi

  LOBYTE(v6) = a3 != 0; /*0x10670566a*/
  if ( a3 == 0 /*0x1067056a8*/
    && a5 != 2
    && (*(_BYTE *)(a1 + 14401) != 0
     || (v10 = *(RBX::Network::StrictNetworkFilter **)(a1 + 12536)) == nullptr
     || (v6 = RBX::Network::StrictNetworkFilter::filterTerrainCellChange(this: v10)) != 1) )
  {
    LOBYTE(v6) = RBX::Network::Replicator::onTerrainRegionChangedStreamingAware(a1, a2, a3: 0, a4, a5); /*0x1067056c1*/
  }
  return v6; /*0x106705678*/
}

// Address: 0x1067056c6 | Name: __ZThn208_N3RBX7Network16ClientReplicator36onTerrainRegionChangedStreamingAwareERKNS_6Voxel26RegionEjNS_23DeferredTerrainContentsENS_23TerrainGridChangeSourceE
char __fastcall `non-virtual thunk to'RBX::Network::ClientReplicator::onTerrainRegionChangedStreamingAware(
        __int64 a1,
        __int64 a2,
        int a3,
        unsigned __int8 a4,
        unsigned int a5)
{
  return RBX::Network::ClientReplicator::onTerrainRegionChangedStreamingAware(a1: a1 - 208, a2, a3, a4, a5); /*0x1067056d1*/
}

// Address: 0x1067056d8 | Name: __ZNK3RBX7Network16ClientReplicator13wantReplicateEPKNS_8InstanceE
__int64 __fastcall RBX::Network::ClientReplicator::wantReplicate(
        RBX::Network::ClientReplicator *this,
        const RBX::Instance *a2)
{
  unsigned int v2; // r14d
  const RBX::Instance *v3; // rbx
  bool v5; // r14
  char v6; // al
  __int64 v7; // rax
  __int64 v8; // rax

  v3 = a2; /*0x1067056e2*/
  v5 = *((_QWORD *)this + 1567) == 0; /*0x1067056f0*/
  v6 = RBX::Network::Replicator::wantReplicate(this, a2); /*0x1067056f4*/
  if ( v5 || (v6 & 1) == 0 ) /*0x106705700*/
  {
    LOBYTE(v2) = v6 & v5; /*0x106705705*/
  }
  else
  {
    v7 = (*(__int64 (__fastcall **)(RBX::Network::ClientReplicator *))(*(_QWORD *)this + 688LL))(a1: this); /*0x106705710*/
    LOBYTE(v2) = 1; /*0x106705716*/
    if ( v7 != 0 ) /*0x10670571c*/
    {
      v8 = RBX::Instance::findConstFirstChildOfType<RBX::PlayerGui>(a1: v7); /*0x106705721*/
      if ( v8 != 0 ) /*0x106705729*/
      {
        do /*0x106705737*/
          v3 = *((const RBX::Instance **)v3 + 13); /*0x10670572b*/
        while ( v3 != (const RBX::Instance *)v8 && v3 != nullptr ); /*0x106705737*/
        LOBYTE(v2) = v3 != (const RBX::Instance *)v8; /*0x10670573c*/
      }
    }
  }
  return v2; /*0x106705747*/
}

// Address: 0x10670574e | Name: __ZN3RBX7Network16ClientReplicator25preProcessReceivedPacketsEv
void __fastcall RBX::Network::ClientReplicator::preProcessReceivedPackets(RBX::Network::ClientReplicator *this)
{
  RBX::Analytics::InfluxDb::Points *v2; // r14
  __int64 v3; // rdx
  __int64 v4; // rcx
  __int64 v5; // rdx
  __int64 v6; // rcx
  void *v7; // rsi
  void *v8; // rsi
  __int128 v9; // [rsp+0h] [rbp-60h] BYREF
  __int64 v10; // [rsp+10h] [rbp-50h]
  double v11; // [rsp+20h] [rbp-40h]
  _QWORD v12[2]; // [rsp+28h] [rbp-38h] BYREF
  void *v13; // [rsp+38h] [rbp-28h]
  double v14; // [rsp+40h] [rbp-20h]

  if ( *((_BYTE *)this + 24384) == 1 ) /*0x106705762*/
  {
    v2 = (RBX::Network::ClientReplicator *)((char *)this + 23912); /*0x106705780*/
    v11 = (RBX::Time::now<(RBX::Time::SampleMethod)2>(a1: this) - *((double *)this + 1992)) * 1000.0; /*0x106705791*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: v2, a2: "AdjustedGameLoadTimeMs", a3: v11); /*0x106705796*/
    std::string::basic_string[abi:ne200100]<0>(a1: v12, a2: "ClientJoinRxStats", a3: v3, a4: v4); /*0x1067057a9*/
    RBX::Analytics::InfluxDb::Points::report( /*0x1067057bc*/
      a1: (char *)this + 23912,
      a2: v12,
      a3: *((unsigned int *)this + 3945),
      a4: 0);
    if ( (v12[0] & 1) != 0 ) /*0x1067057c5*/
      operator delete(a1: (RBX::Memory *)v13, a2: v7); /*0x1067057cb*/
    if ( *((_BYTE *)this + 18601) == 1 ) /*0x1067057d7*/
    {
      v9 = 0; /*0x1067057dd*/
      v10 = 0; /*0x1067057e2*/
      std::string::basic_string[abi:ne200100]<0>(a1: v12, a2: "AdjustedGameLoadTimeMs", a3: v5, a4: v6); /*0x1067057f5*/
      v14 = v11; /*0x106705803*/
      ((void (__fastcall *)(__int128 *))std::vector<std::pair<std::string,double>>::push_back[abi:ne200100])(a1: &v9); /*0x10670580c*/
      if ( (v12[0] & 1) != 0 ) /*0x106705815*/
        operator delete(a1: (RBX::Memory *)v13, a2: v8); /*0x10670581b*/
      RBX::Analytics::EphemeralCounter::bulkReportStats(a1: &v9, a2: 0); /*0x106705829*/
      v12[0] = &v9; /*0x106705832*/
      std::vector<std::pair<std::string,double>>::__destroy_vector::operator()[abi:ne200100](a1: v12); /*0x106705835*/
    }
    *((_BYTE *)this + 24384) = 0; /*0x10670583a*/
  }
}

// Address: 0x106705894 | Name: __ZN3RBX7Network16ClientReplicator26postProcessReceivedPacketsEv
__int64 __fastcall RBX::Network::ClientReplicator::postProcessReceivedPackets(
        RBX::Network::ClientReplicator *this,
        RBX::Instance *a2)
{
  RBX::Stats::PerformanceStatsItem *v3; // rax
  RBX::DataModel *v4; // rsi
  RBX::Stats::PerformanceStatsItem *v5; // rax
  RBX::Stats::PerformanceStatsItem *v6; // r14
  float v7; // xmm0_4
  float v8; // xmm0_4
  __int64 v9; // rax
  __int64 v10; // r14
  _BYTE v12[104]; // [rsp+0h] [rbp-B0h] BYREF
  double v13; // [rsp+68h] [rbp-48h]
  char v14; // [rsp+70h] [rbp-40h]

  *((_QWORD *)this + 1557) = *((_QWORD *)this + 1558); /*0x1067058ae*/
  v3 = (RBX::Stats::PerformanceStatsItem *)RBX::DataModel::get(this, a2); /*0x1067058b5*/
  v5 = (RBX::Stats::PerformanceStatsItem *)RBX::Stats::PerformanceStatsItem::getFromDataModel(this: v3, a2: v4); /*0x1067058bd*/
  if ( v5 != nullptr ) /*0x1067058c5*/
  {
    v6 = v5; /*0x1067058cb*/
    if ( DFFlag::RbxTransportNetworkBandwidthUI == 1 && *((_BYTE *)this + 10391) == 1 ) /*0x1067058de*/
    {
      RBX::Network::ClientReplicator::updateRbxTransportNetworkStatsInPerformanceUI(this, a2: false); /*0x1067058e5*/
    }
    else
    {
      v7 = *((double *)this + 374); /*0x1067058ec*/
      RBX::Stats::PerformanceStatsItem::setLatestNetwokReceived(this: v5, a2: v7); /*0x1067058f7*/
    }
    if ( *((_BYTE *)this + 10391) == 1 ) /*0x106705903*/
    {
      (*(void (__fastcall **)(_BYTE *))(**((_QWORD **)this + 35) + 192LL))(a1: v12); /*0x106705919*/
      if ( v14 != 0 ) /*0x106705924*/
        v8 = v13 * 1000.0; /*0x106705951*/
      else
        v8 = 0.0; /*0x106705926*/
    }
    else
    {
      v8 = 0.0; /*0x10670592b*/
      if ( *((_BYTE *)this + 6220) == 1 ) /*0x106705935*/
        v8 = (float)*((int *)this + 1554); /*0x10670593a*/
    }
    RBX::Stats::PerformanceStatsItem::setLatestPingTime(this: v6, a2: v8); /*0x106705958*/
    if ( FFlag::PerformanceControlEnableEnjoyabilityScoreInputs == 1 ) /*0x106705964*/
    {
      v9 = RBX::Subsystem<RBX::PerformanceControl::PerformanceControlSubsystemV3,true>::startup<RBX::SubsystemDefaultFactory<RBX::PerformanceControl::PerformanceControlSubsystemV3>>(); /*0x106705966*/
      if ( v9 != 0 ) /*0x10670596e*/
      {
        v10 = v9; /*0x106705970*/
        RBX::PerformanceControl::PerformanceControlSubsystemV3::setNetworkPingMs( /*0x10670597f*/
          this: *(RBX::PerformanceControl::PerformanceControlSubsystemV3 **)(v9 + 24),
          a2: *((double *)this + 512));
        (*(void (__fastcall **)(__int64))(*(_QWORD *)v10 + 16LL))(a1: v10); /*0x10670598a*/
      }
    }
  }
  return RBX::Network::CompletenessTrackerClient::propagate( /*0x1067059a1*/
           this: (RBX::Network::CompletenessTrackerClient *)(*((_QWORD *)this + 1801) + 2880LL),
           a2: this);
}

// Address: 0x1067059ce | Name: __ZN3RBX7Network16ClientReplicator45updateRbxTransportNetworkStatsInPerformanceUIEb
void __fastcall RBX::Network::ClientReplicator::updateRbxTransportNetworkStatsInPerformanceUI(
        RBX::Network::ClientReplicator *this,
        RBX::Instance *a2)
{
  bool v2; // bl
  RBX::Stats::PerformanceStatsItem *v4; // r15
  RBX::DataModel *v5; // rsi
  RBX::Stats::PerformanceStatsItem *v6; // rax
  float v7; // xmm0_4
  __int64 v8; // rax
  RBX::Stats::PerformanceStatsItem *v9; // r15
  RBX::Time *v10; // rdi
  char *v11; // rcx
  unsigned __int64 v12; // r12
  double *v13; // r14
  double v14; // xmm0_8
  double v15; // xmm2_8
  double v16; // xmm1_8
  __m128d v17; // xmm1
  float v18; // xmm0_4
  float v19; // xmm0_4
  double *v20; // r14
  _BYTE v21[16]; // [rsp+0h] [rbp-C0h] BYREF
  char v22; // [rsp+10h] [rbp-B0h] BYREF
  char v23; // [rsp+38h] [rbp-88h] BYREF
  double v24; // [rsp+98h] [rbp-28h]

  if ( *((_QWORD *)this + 35) != 0 ) /*0x1067059e8*/
  {
    v2 = (char)a2; /*0x1067059ee*/
    if ( DFFlag::RbxTransportBWFixDMGetAssert == 1 ) /*0x1067059fa*/
      v4 = *((RBX::Stats::PerformanceStatsItem **)this + 2315); /*0x1067059fc*/
    else
      v4 = (RBX::Stats::PerformanceStatsItem *)RBX::DataModel::get(this, a2); /*0x106705a0d*/
    if ( DFFlag::RbxTransportPopulateReplicatorBandwidthStats == 1 ) /*0x106705a1a*/
    {
      RBX::Network::Replicator::updateRbxTransportBandwidthRate(this, a2: v2); /*0x106705a22*/
      v6 = (RBX::Stats::PerformanceStatsItem *)RBX::Stats::PerformanceStatsItem::getFromDataModel(this: v4, a2: v5); /*0x106705a2a*/
      if ( v6 != nullptr ) /*0x106705a32*/
      {
        if ( v2 ) /*0x106705a3a*/
        {
          v7 = *((double *)this + 461); /*0x106705a40*/
          RBX::Stats::PerformanceStatsItem::setLatestNetwokSent(this: v6, a2: v7); /*0x106705a5b*/
        }
        else
        {
          v19 = *((double *)this + 374); /*0x106705b25*/
          RBX::Stats::PerformanceStatsItem::setLatestNetwokReceived(this: v6, a2: v19); /*0x106705b40*/
        }
      }
    }
    else
    {
      v8 = RBX::Stats::PerformanceStatsItem::getFromDataModel(this: v4, a2); /*0x106705a63*/
      if ( v8 == 0 ) /*0x106705a6b*/
        return; /*0x106705a6b*/
      v9 = (RBX::Stats::PerformanceStatsItem *)v8; /*0x106705a71*/
      (*(void (__fastcall **)(_BYTE *))(**((_QWORD **)this + 35) + 192LL))(a1: v21); /*0x106705a85*/
      v11 = &v22; /*0x106705a92*/
      if ( v2 ) /*0x106705a9b*/
        v11 = &v23; /*0x106705a9b*/
      v12 = *(_QWORD *)v11; /*0x106705a9f*/
      v13 = (double *)((char *)this + 64 * !v2 + 10392); /*0x106705aaf*/
      RBX::Time::nowFastSec(this: v10); /*0x106705ab6*/
      if ( *(_BYTE *)v13 != 0 ) /*0x106705abf*/
      {
        v15 = v14 - v13[2]; /*0x106705ac9*/
        v16 = 0.0; /*0x106705acf*/
        if ( v15 <= 0.0 ) /*0x106705ad7*/
          return; /*0x106705ad7*/
        if ( v12 >= *((_QWORD *)v13 + 1) ) /*0x106705ae4*/
        {
          v17 = _mm_sub_pd( /*0x106705af3*/
                  (__m128d)_mm_unpacklo_epi32((__m128i)(v12 - *((_QWORD *)v13 + 1)), (__m128i)xmmword_108F2F9A0),
                  (__m128d)xmmword_108F2F9B0);
          v16 = _mm_hadd_pd(v17, v17).f64[0] * 0.0009765625; /*0x106705aff*/
        }
        v24 = v14; /*0x106705b07*/
        v18 = v16 / v15; /*0x106705b13*/
        if ( v2 ) /*0x106705b1c*/
          RBX::Stats::PerformanceStatsItem::setLatestNetwokSent(this: v9, a2: v18); /*0x106705b1e*/
        else
          RBX::Stats::PerformanceStatsItem::setLatestNetwokReceived(this: v9, a2: v18); /*0x106705b53*/
        *((_QWORD *)v13 + 1) = v12; /*0x106705b58*/
        v20 = v13 + 2; /*0x106705b5c*/
        v14 = v24; /*0x106705b60*/
      }
      else
      {
        *(_BYTE *)v13 = 1; /*0x106705b45*/
        *((_QWORD *)v13 + 1) = v12; /*0x106705b49*/
        v20 = v13 + 2; /*0x106705b4d*/
      }
      *v20 = v14; /*0x106705b65*/
    }
  }
}

// Address: 0x106705b7a | Name: __ZN3RBX7Network16ClientReplicator21preProcessSendPacketsEv
__int64 __fastcall RBX::Network::ClientReplicator::preProcessSendPackets(RBX::Network::ClientReplicator *this)
{
  return RBX::Network::Replicator::queueCoalescedAnimationEvents(this); /*0x106705b7e*/
}

// Address: 0x106705b84 | Name: __ZN3RBX7Network16ClientReplicator22postProcessSentPacketsEv
void __fastcall RBX::Network::ClientReplicator::postProcessSentPackets(
        RBX::Network::ClientReplicator *this,
        RBX::Instance *a2)
{
  RBX::Stats::PerformanceStatsItem *Dangerous_DEPRECATED; // rax
  RBX::DataModel *v4; // rsi
  RBX::Stats::PerformanceStatsItem *v5; // rax
  float v6; // xmm0_4

  Dangerous_DEPRECATED = (RBX::Stats::PerformanceStatsItem *)RBX::DataModel::getDangerous_DEPRECATED(this, a2); /*0x106705b8d*/
  v5 = (RBX::Stats::PerformanceStatsItem *)RBX::Stats::PerformanceStatsItem::getFromDataModel( /*0x106705b95*/
                                             this: Dangerous_DEPRECATED,
                                             a2: v4);
  if ( v5 != nullptr ) /*0x106705b9d*/
  {
    if ( DFFlag::RbxTransportNetworkBandwidthUI == 1 && *((_BYTE *)this + 10391) == 1 ) /*0x106705baf*/
    {
      RBX::Network::ClientReplicator::updateRbxTransportNetworkStatsInPerformanceUI(this, a2: (RBX::Instance *)1); /*0x106705bbf*/
    }
    else
    {
      v6 = *((double *)this + 461); /*0x106705bc4*/
      RBX::Stats::PerformanceStatsItem::setLatestNetwokSent(this: v5, a2: v6); /*0x106705bd5*/
    }
  }
}

// Address: 0x106705be2 | Name: __ZN3RBX7Network16ClientReplicator27completenessClientPropagateEv
__int64 __fastcall RBX::Network::ClientReplicator::completenessClientPropagate(RBX::Network::ClientReplicator *this)
{
  return RBX::Network::CompletenessTrackerClient::propagate( /*0x106705bf5*/
           this: (RBX::Network::CompletenessTrackerClient *)(*((_QWORD *)this + 1801) + 2880LL),
           a2: this);
}

// Address: 0x106705bfc | Name: __ZN3RBX7Network16ClientReplicator9onSentTagENS0_11TagItemTypeE
void __fastcall RBX::Network::ClientReplicator::onSentTag(__int64 a1, int a2)
{
  if ( a2 == 14 ) /*0x106705c03*/
    *(_BYTE *)(a1 + 14888) = 0; /*0x106705c05*/
}

// Address: 0x106705c0e | Name: __ZN3RBX7Network16ClientReplicator15deserializeItemERNS0_13NetworkStreamENS0_4Item8ItemTypeE
_QWORD *__fastcall RBX::Network::ClientReplicator::deserializeItem(
        _QWORD *a1,
        RBX::Network::Replicator *a2,
        RBX::Network::NetworkStream *a3,
        unsigned int a4)
{
  __int64 v7; // r13
  int v8; // ebx
  _QWORD *v9; // r13
  unsigned int v10; // r15d
  int v11; // eax
  unsigned __int8 v13; // r8
  _QWORD v14[13]; // [rsp+0h] [rbp-A0h] BYREF
  _QWORD *v15; // [rsp+68h] [rbp-38h]
  _QWORD v16[6]; // [rsp+70h] [rbp-30h] BYREF

  v15 = a1; /*0x106705c28*/
  if ( (_BYTE)`guard variable for'RBX::Network::ClientReplicator::deserializeItem(RBX::Network::NetworkStream &,RBX::Network::Item::ItemType)::proftoken2093 == 0 /*0x106705f2a*/
    && __cxa_guard_acquire(a1: &`guard variable for'RBX::Network::ClientReplicator::deserializeItem(RBX::Network::NetworkStream &,RBX::Network::Item::ItemType)::proftoken2093) != 0 )
  {
    v14[0] = ""; /*0x106705f53*/
    RBX::Network::ClientReplicator::deserializeItem(RBX::Network::NetworkStream &,RBX::Network::Item::ItemType)::proftoken2093 = RBX::Profiler::getToken(this: (RBX::Profiler *)&aDflogRbxtransp_330[-348077], a2: &aLuaugcstartupw[-714025], a3: (const char *)0xFFFFFFFFLL, a4: 255, a5: v13); /*0x106705f77*/
    __cxa_guard_release(a1: &`guard variable for'RBX::Network::ClientReplicator::deserializeItem(RBX::Network::NetworkStream &,RBX::Network::Item::ItemType)::proftoken2093); /*0x106705f85*/
  }
  v7 = RBX::Network::ClientReplicator::deserializeItem(RBX::Network::NetworkStream &,RBX::Network::Item::ItemType)::proftoken2093; /*0x106705c3a*/
  *(_OWORD *)v14 = 0; /*0x106705c4b*/
  v14[3] = -1; /*0x106705c4e*/
  memset(&v14[4], 0, 52); /*0x106705c56*/
  *(_OWORD *)&v14[11] = 0; /*0x106705c69*/
  v14[2] = RBX::Network::ClientReplicator::deserializeItem(RBX::Network::NetworkStream &,RBX::Network::Item::ItemType)::proftoken2093; /*0x106705c6d*/
  RBX::Profiler::ActiveRegion::enter(this: (RBX::Profiler::ActiveRegion *)v14); /*0x106705c74*/
  v14[3] = RBX::Profiler::enterRegion(a1: v7, a2: -1, a3: 0); /*0x106705c8a*/
  v8 = *((_DWORD *)a3 + 14); /*0x106705c8e*/
  switch ( a4 ) /*0x106705ca9*/
  {
    case 9u: /*0x106705ca9*/
      v9 = v15; /*0x106705cb5*/
      RBX::Network::Replicator::RockyItem::read(this: (RBX::Network::Replicator::RockyItem *)v16, a2, a3); /*0x106705cb9*/
      break; /*0x106705cbe*/
    case 0xBu: /*0x106705ca9*/
      v9 = v15; /*0x106705da8*/
      RBX::Network::Replicator::JoinDataItem::read(this: (RBX::Network::Replicator::JoinDataItem *)v16, a2, a3); /*0x106705dac*/
      break; /*0x106705db1*/
    case 0xDu: /*0x106705ca9*/
      v9 = v15; /*0x106705d60*/
      RBX::Network::Replicator::StreamJob::StreamDataItem::read( /*0x106705d64*/
        this: (RBX::Network::Replicator::StreamJob::StreamDataItem *)v16,
        a2,
        a3);
      break; /*0x106705d69*/
    case 0x10u: /*0x106705ca9*/
      v9 = v15; /*0x106705e20*/
      RBX::Network::Replicator::TagItem::read(this: (RBX::Network::Replicator::TagItem *)v16, a2, a3); /*0x106705e24*/
      break; /*0x106705e29*/
    case 0x11u: /*0x106705ca9*/
      v9 = v15; /*0x106705e35*/
      RBX::Network::Replicator::StatsItem::read(this: (RBX::Network::Replicator::StatsItem *)v16, a2, a3); /*0x106705e39*/
      break; /*0x106705e3e*/
    case 0x14u: /*0x106705ca9*/
      v9 = v15; /*0x106705d78*/
      RBX::Network::StreamDataInfoItem::read(this: (RBX::Network::StreamDataInfoItem *)v16, a2, a3); /*0x106705d7c*/
      break; /*0x106705d81*/
    case 0x16u: /*0x106705ca9*/
      v9 = v15; /*0x106705dc0*/
      RBX::Network::Replicator::readJoinDataItemV2(this: (RBX::Network::Replicator *)v16, a2); /*0x106705dc4*/
      break; /*0x106705dc9*/
    case 0x18u: /*0x106705ca9*/
      v9 = v15; /*0x106705dd8*/
      RBX::Network::StreamPrefetchDataInfoItem::read(this: (RBX::Network::StreamPrefetchDataInfoItem *)v16, a2, a3); /*0x106705ddc*/
      break; /*0x106705de1*/
    case 0x19u: /*0x106705ca9*/
      v9 = v15; /*0x106705e5f*/
      RBX::Network::StreamPrefetchRequestItem::read(this: (RBX::Network::StreamPrefetchRequestItem *)v16, a2, a3); /*0x106705e63*/
      break; /*0x106705e68*/
    case 0x1Au: /*0x106705ca9*/
      v9 = v15; /*0x106705e4a*/
      RBX::Network::StreamReplicationFocusItem::read(this: (RBX::Network::StreamReplicationFocusItem *)v16, a2, a3); /*0x106705e4e*/
      break; /*0x106705e53*/
    case 0x1Bu: /*0x106705ca9*/
      v9 = v15; /*0x106705d18*/
      RBX::Network::SharedDestroyInstanceItem::read(this: (RBX::Network::SharedDestroyInstanceItem *)v16, a2, a3); /*0x106705d1c*/
      break; /*0x106705d21*/
    case 0x1Du: /*0x106705ca9*/
      v9 = v15; /*0x106705d90*/
      RBX::Network::StreamModelPersistentPlayerAddItem::read( /*0x106705d94*/
        this: (RBX::Network::StreamModelPersistentPlayerAddItem *)v16,
        a2,
        a3);
      break; /*0x106705d99*/
    case 0x1Eu: /*0x106705ca9*/
      v9 = v15; /*0x106705d30*/
      RBX::Network::StreamModelPersistentPlayerRemoveItem::read( /*0x106705d34*/
        this: (RBX::Network::StreamModelPersistentPlayerRemoveItem *)v16,
        a2,
        a3);
      break; /*0x106705d39*/
    case 0x1Fu: /*0x106705ca9*/
      v9 = v15; /*0x106705d00*/
      RBX::Network::Replicator::ClientQoSItem::read(this: (RBX::Network::Replicator::ClientQoSItem *)v16, a2, a3); /*0x106705d04*/
      break; /*0x106705d09*/
    case 0x20u: /*0x106705ca9*/
      v9 = v15; /*0x106705df0*/
      RBX::Network::ReplicatorData::readAndroidACChallenge(this: (RBX::Network::ReplicatorData *)v16, a2, a3); /*0x106705df4*/
      break; /*0x106705df9*/
    case 0x24u: /*0x106705ca9*/
      v9 = v15; /*0x106705e08*/
      RBX::Network::StreamReplicationFocusRemoveItem::read( /*0x106705e0c*/
        this: (RBX::Network::StreamReplicationFocusRemoveItem *)v16,
        a2,
        a3);
      break; /*0x106705e11*/
    case 0x25u: /*0x106705ca9*/
      v9 = v15; /*0x106705e89*/
      RBX::Network::Replicator::StreamJob::StreamPinDataItem::read( /*0x106705e8d*/
        this: (RBX::Network::Replicator::StreamJob::StreamPinDataItem *)v16,
        a2,
        a3);
      break; /*0x106705e92*/
    case 0x26u: /*0x106705ca9*/
      v9 = v15; /*0x106705e74*/
      RBX::Network::Replicator::InitialServerTimeItem::read( /*0x106705e78*/
        this: (RBX::Network::Replicator::InitialServerTimeItem *)v16,
        a2,
        a3);
      break; /*0x106705e7d*/
    case 0x27u: /*0x106705ca9*/
      v9 = v15; /*0x106705ce8*/
      RBX::Network::StreamReplicationFocusFrustumItem::read( /*0x106705cec*/
        this: (RBX::Network::StreamReplicationFocusFrustumItem *)v16,
        a2,
        a3);
      break; /*0x106705cf1*/
    case 0x28u: /*0x106705ca9*/
      v9 = v15; /*0x106705d48*/
      RBX::Network::StreamReplicationFocusFrustumRemoveItem::read( /*0x106705d4c*/
        this: (RBX::Network::StreamReplicationFocusFrustumRemoveItem *)v16,
        a2,
        a3);
      break; /*0x106705d51*/
    case 0x29u: /*0x106705ca9*/
      v9 = v15; /*0x106705e9e*/
      RBX::Network::InstanceIntentItem::read(this: (RBX::Network::InstanceIntentItem *)v16, a2, a3); /*0x106705ea2*/
      break; /*0x106705ea2*/
    default:
      v9 = v15; /*0x106705cd0*/
      RBX::Network::Replicator::deserializeItem(a1: v16, a2, a3, a4); /*0x106705cd4*/
      break; /*0x106705cd9*/
  }
  *v9 = v16[0]; /*0x106705eab*/
  if ( *RBX::Profiler::active != 0 ) /*0x106705ebd*/
  {
    v10 = a4 - 11; /*0x106705ebf*/
    if ( v10 <= 0x1D ) /*0x106705ec7*/
    {
      v11 = 839707237; /*0x106705ec9*/
      if ( _bittest(&v11, v10) ) /*0x106705ece*/
        RBX::Profiler::MicroProfileNetReplicaEvent( /*0x106705ef9*/
          a1: (unsigned int)(*((_DWORD *)a3 + 14) - v8),
          a2: 3,
          a3: 2,
          a4: byte_1099FD72E[v10],
          a5: -1);
    }
  }
  RBX::Profiler::Scope::~Scope(this: (RBX::Profiler::Scope *)v14); /*0x106705f05*/
  return v9; /*0x106705f0d*/
}

// Address: 0x10670608c | Name: __ZN3RBX7Network16ClientReplicator8readItemERNS0_13NetworkStreamENS0_4Item8ItemTypeEy
__int64 __fastcall RBX::Network::ClientReplicator::readItem(__int64 a1)
{
  *(_DWORD *)a1 = 1; /*0x106706093*/
  *(_QWORD *)(a1 + 8) = 0; /*0x106706099*/
  return a1; /*0x1067060a1*/
}

// Address: 0x1067060a4 | Name: __ZN3RBX7Network16ClientReplicator27setSharedStringSynchronizerEONSt3__110unique_ptrINS0_24SharedStringSynchronizerENS2_14default_deleteIS4_EEEE
__int64 __fastcall RBX::Network::ClientReplicator::setSharedStringSynchronizer(__int64 a1, __int64 *a2)
{
  __int64 v2; // rax

  v2 = *a2; /*0x1067060af*/
  *a2 = 0; /*0x1067060b2*/
  return std::unique_ptr<RBX::Network::SharedStringSynchronizer>::reset[abi:ne200100](a1: a1 + 15416, a2: v2); /*0x1067060bc*/
}

// Address: 0x1067060c2 | Name: __ZN3RBX7Network16ClientReplicator10processTagENS0_11TagItemTypeE
char *__fastcall RBX::Network::ClientReplicator::processTag(RBX::DataModel *this, int a2)
{
  int v2; // r14d
  RBX::DataModel *v3; // r13
  RBX::Preloaded *v4; // rax
  __int64 v5; // r15
  RBX::Time *v6; // rdi
  __int64 v7; // xmm0_8
  RakNet *v8; // rdi
  __int64 v9; // rdi
  void *v10; // rsi
  __int64 v11; // r15
  RBX::DataModel *v12; // r15
  __int64 v13; // rbx
  __int64 v14; // rax
  unsigned __int64 v15; // rdx
  RBX::Instance *v16; // rsi
  __int64 v17; // rax
  char *v18; // rcx
  RBX::ReplicatedFirst *v19; // rax
  __int64 v20; // rdi
  __int64 v21; // r15
  __int64 v22; // rbx
  __int64 v23; // rax
  RBX::Time *v24; // rdi
  double v25; // xmm0_8
  RBX::Instance *v26; // rsi
  RBX::Instance *v27; // rsi
  __int64 v28; // rax
  float v29; // xmm0_4
  __int64 v30; // rdi
  __int64 v31; // rax
  __int64 v32; // rax
  void *v33; // rdi
  RBX::Network::SharedStringSynchronizer *v34; // rdi
  RBX::Network::ClientReplicator::GCJob *v35; // rdi
  __int64 v36; // rax
  __int64 v37; // rcx
  __int64 v38; // rdx
  volatile signed __int64 *v39; // rcx
  std::__shared_weak_count *v40; // r15
  __int64 v41; // r15
  char *v42; // rdx
  std::__shared_weak_count *v43; // r15
  std::__shared_weak_count *v44; // r15
  RakNet *v45; // rdi
  RBX::CoreNetworkSettings *v46; // rdi
  __int64 v47; // rdx
  __int64 v48; // rcx
  __int64 v49; // rcx
  __int64 v50; // r8
  __int64 v51; // r9
  __m128 v52; // xmm0
  __m128 v53; // xmm1
  __m128 v54; // xmm2
  __m128 v55; // xmm3
  __m128 v56; // xmm4
  __m128 v57; // xmm5
  __m128 v58; // xmm6
  __m128 v59; // xmm7
  __int64 v60; // rbx
  __int64 i; // r14
  int v62; // r12d
  int v63; // r15d
  __int64 v64; // rcx
  __int64 v65; // r8
  __int64 v66; // r9
  __m128 v67; // xmm2
  __m128 v68; // xmm3
  __m128 v69; // xmm4
  __m128 v70; // xmm5
  __m128 v71; // xmm6
  __m128 v72; // xmm7
  __m128 v73; // xmm0
  char *v74; // rdx
  __m128 v75; // xmm1
  void *v76; // rsi
  double v77; // r14
  __int64 v78; // rbx
  __int64 v79; // rcx
  __int64 v80; // r14
  __int64 v81; // rdx
  __int64 v82; // rbx
  unsigned __int64 v83; // r13
  const void *v84; // rsi
  __int64 v85; // r13
  __int64 v86; // r12
  unsigned __int64 v87; // rdx
  unsigned __int64 v88; // rax
  __int64 v89; // rax
  __int64 v90; // rdx
  __int64 v91; // rdi
  __int64 v92; // rcx
  size_t v93; // rdx
  __int64 v94; // r15
  void *v95; // r12
  void *v96; // r15
  void *v97; // rsi
  RBX::Memory *v98; // rdi
  unsigned __int64 v99; // rax
  __int64 v100; // rax
  __int64 v101; // rdx
  int v102; // edx
  __int64 v103; // rcx
  __int64 v104; // r8
  __int64 v105; // r9
  __m128 v106; // xmm0
  __m128 v107; // xmm1
  __m128 v108; // xmm2
  __m128 v109; // xmm3
  __m128 v110; // xmm4
  __m128 v111; // xmm5
  __m128 v112; // xmm6
  __m128 v113; // xmm7
  unsigned int *v114; // rbx
  unsigned int *v115; // r14
  unsigned int v116; // r15d
  __int64 v117; // rdx
  __int64 v118; // rdx
  int v119; // ecx
  int v120; // r8d
  int v121; // r9d
  char *v122; // rdx
  void *v123; // rsi
  __int64 v124; // rbx
  __int64 v125; // rdi
  __int64 v126; // r14
  rbx::signals::scoped_connection *v127; // rbx
  rbx::signals::scoped_connection *v128; // r15
  char *result; // rax
  const char *v130; // rsi
  unsigned __int8 v131; // r8
  __int128 v132; // [rsp+0h] [rbp-120h] BYREF
  __int64 v133; // [rsp+10h] [rbp-110h]
  __int64 v134; // [rsp+18h] [rbp-108h]
  __int128 v135; // [rsp+20h] [rbp-100h]
  __int128 v136; // [rsp+30h] [rbp-F0h]
  __int128 v137; // [rsp+40h] [rbp-E0h]
  int v138; // [rsp+50h] [rbp-D0h]
  __int128 v139; // [rsp+58h] [rbp-C8h]
  char *v140; // [rsp+70h] [rbp-B0h]
  std::__shared_weak_count *v141; // [rsp+78h] [rbp-A8h]
  double v142; // [rsp+80h] [rbp-A0h]
  __int64 v143; // [rsp+88h] [rbp-98h] BYREF
  std::__shared_weak_count *v144; // [rsp+90h] [rbp-90h]
  int v145; // [rsp+9Ch] [rbp-84h]
  std::__shared_weak_count *v146[2]; // [rsp+A0h] [rbp-80h] BYREF
  void *v147; // [rsp+B0h] [rbp-70h]
  double v148; // [rsp+D8h] [rbp-48h]
  __int128 __src; // [rsp+E0h] [rbp-40h] BYREF
  void *v150; // [rsp+F0h] [rbp-30h] BYREF

  v2 = a2; /*0x1067060d6*/
  v3 = this; /*0x1067060d9*/
  switch ( a2 )
  {
    case 12:
      v19 = (RBX::ReplicatedFirst *)RBX::ServiceProvider::find<RBX::ReplicatedFirst>(a1: this); /*0x106706294*/
      if ( v19 != nullptr ) /*0x10670629c*/
        RBX::ReplicatedFirst::setAllInstancesHaveReplicated(this: v19); /*0x1067062a1*/
      *((_BYTE *)v3 + 18408) = 1; /*0x1067062a6*/
      v21 = *((_QWORD *)v3 + 13); /*0x1067062ae*/
      if ( v21 != 0 ) /*0x1067062b5*/
      {
        v22 = *(_QWORD *)(v21 + 24); /*0x1067062bb*/
        v23 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>(a1: v20); /*0x1067062bf*/
        if ( *(unsigned __int16 *)(v22 + 440) - (unsigned int)*(unsigned __int16 *)(v23 + 440) <= *(unsigned __int16 *)(v23 + 442) ) /*0x1067062dd*/
        {
          rbx::signal<void ()(RBX::StringLiteral const&)>::invokeImpl<(rbx::SignalInvokePolicy)0>( /*0x1067062f4*/
            a1: v21 + 4864,
            a2: &RBX::Analytics::kReplicatedFirstFinished);
          RBX::Network::Replicator::addReplicatorState(this: v3); /*0x106706301*/
        }
      }
      break;
    case 13:
      v145 = 13; /*0x106706113*/
      if ( (_BYTE)`guard variable for'RBX::Network::ClientReplicator::processTag(RBX::Network::TagItemType)::proftoken2278 == 0 /*0x106706b78*/
        && __cxa_guard_acquire(a1: &`guard variable for'RBX::Network::ClientReplicator::processTag(RBX::Network::TagItemType)::proftoken2278) != 0 )
      {
        *(_QWORD *)&v132 = "size experiment success"; /*0x106706ba1*/
        RBX::Network::ClientReplicator::processTag(RBX::Network::TagItemType)::proftoken2278 = RBX::Profiler::getToken( /*0x106706bc5*/
                                                                                                 this: (RBX::Profiler *)&aFlogErrorFaile_41[-1048461],
                                                                                                 a2: &aFlogLuaappexpe_21[-670374],
                                                                                                 a3: (const char *)0xFFFFFFFFLL,
                                                                                                 a4: 255,
                                                                                                 a5: v131);
        __cxa_guard_release(a1: &`guard variable for'RBX::Network::ClientReplicator::processTag(RBX::Network::TagItemType)::proftoken2278); /*0x106706bd3*/
      }
      v5 = RBX::Network::ClientReplicator::processTag(RBX::Network::TagItemType)::proftoken2278; /*0x106706128*/
      v132 = 0; /*0x10670613a*/
      v134 = -1; /*0x106706140*/
      v135 = 0; /*0x106706149*/
      v136 = 0; /*0x106706150*/
      v137 = 0; /*0x106706157*/
      v138 = 0; /*0x10670615e*/
      v139 = 0; /*0x106706167*/
      v133 = RBX::Network::ClientReplicator::processTag(RBX::Network::TagItemType)::proftoken2278; /*0x10670616e*/
      RBX::Profiler::ActiveRegion::enter(this: (RBX::Profiler::ActiveRegion *)&v132); /*0x106706176*/
      v134 = RBX::Profiler::enterRegion(a1: v5, a2: -1, a3: 0); /*0x10670618c*/
      RBX::Network::TwoWayBandwidthMetrics::onJoin(a1: (char *)v3 + 288, a2: 0); /*0x10670619a*/
      if ( FFlag::ConnectViaConnectionInternal == 1 && *((double *)v3 + 1952) == 0.0 ) /*0x1067061bc*/
      {
        RBX::Time::nowFast(this: v6); /*0x1067061c0*/
        *((_QWORD *)v3 + 1952) = v7; /*0x1067061c5*/
      }
      *((_QWORD *)v3 + 1997) = RBX::TaskScheduler::cycle(this: v6); /*0x1067061d3*/
      *((_DWORD *)v3 + 3996) = RakNet::GetTimeMS(this: v8); /*0x1067061df*/
      if ( *((_BYTE *)v3 + 10391) == 0 ) /*0x1067061ee*/
      {
        v11 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)v3 + 28)); /*0x1067061fc*/
        RakNet::AddressOrGUID::AddressOrGUID( /*0x10670620a*/
          this: (RakNet::AddressOrGUID *)v146,
          a2: (RBX::DataModel *)((char *)v3 + 240));
        (*(void (__fastcall **)(__int64, std::__shared_weak_count **, _QWORD))(*(_QWORD *)v11 + 752LL))( /*0x10670621b*/
          a1: v11,
          a2: v146,
          a3: 0);
      }
      v12 = *((RBX::DataModel **)v3 + 13); /*0x106706221*/
      if ( v12 != nullptr ) /*0x106706228*/
      {
        v13 = *((_QWORD *)v12 + 3); /*0x10670622e*/
        v14 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>(a1: v9); /*0x106706232*/
        v15 = *(unsigned __int16 *)(v14 + 440); /*0x10670623e*/
        if ( *(unsigned __int16 *)(v13 + 440) - (unsigned int)v15 <= *(unsigned __int16 *)(v14 + 442) ) /*0x106706250*/
        {
          RBX::Network::Client::getConnectedServer(this: (RBX::Network::Client *)v146, a2: (__int64)v12, a3: v15); /*0x10670625d*/
          v17 = RBX::DataModel::get(this: v12, a2: v16); /*0x106706265*/
          if ( v17 != 0 ) /*0x10670626d*/
            std::string::operator=(a1: v17 + 1800, a2: v146); /*0x10670627c*/
          if ( ((__int64)v146[0] & 1) != 0 ) /*0x106706285*/
            v18 = (char *)v147; /*0x10670628b*/
          else
            v18 = (char *)v146 + 1; /*0x10670630b*/
          RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x106706327*/
            this: (RBX::Network::ConcurrentRakPeer **)v12,
            a2: "FinishedReceivingInitialGameData",
            a3: 0,
            a4: v18,
            a5: 2,
            a6: 1);
          RBX::Network::Client::setJoinStateFinishedReceivingInitialGameData(this: v12); /*0x10670632f*/
          RBX::Time::nowFast(this: v24); /*0x106706334*/
          v148 = v25; /*0x106706339*/
          v142 = *(double *)(RBX::DataModel::get(this: v12, a2: v26) + 1776); /*0x10670634e*/
          v28 = RBX::DataModel::get(this: v12, a2: v27); /*0x106706359*/
          v29 = v148 - v142; /*0x10670636b*/
          *(float *)(v28 + 1792) = v29; /*0x10670636f*/
          rbx::signal<void ()(RBX::StringLiteral const&)>::invokeImpl<(rbx::SignalInvokePolicy)0>( /*0x106706388*/
            a1: (char *)v12 + 4864,
            a2: &RBX::Analytics::kTopReplicationContainerFinished);
          RBX::Network::Replicator::addReplicatorState(this: v3); /*0x106706395*/
          if ( ((__int64)v146[0] & 1) != 0 ) /*0x10670639e*/
            operator delete(a1: (RBX::Memory *)v147, a2: v10); /*0x1067063a4*/
        }
      }
      v30 = *((_QWORD *)v3 + 2753); /*0x1067063a9*/
      if ( v30 != 0 ) /*0x1067063b3*/
        RBX::Network::ClientReplicator::GCJob::recordJoinCheckpoint(a1: v30, a2: 0); /*0x1067063b7*/
      v31 = RBX::DataModel::get(this: v3, a2: (RBX::Instance *)v10); /*0x1067063bf*/
      if ( v31 != 0 ) /*0x1067063c7*/
        RBX::DataModel::gameDmIsLoaded( /*0x1067063df*/
          a1: v31,
          a2: (unsigned int)(*((_DWORD *)v3 + 3926) + *((_DWORD *)v3 + 3929)) | 0x100000000LL);
      *((_BYTE *)v3 + 15224) = 0; /*0x1067063e4*/
      v32 = (*(__int64 (__fastcall **)(RBX::DataModel *))(*(_QWORD *)v3 + 688LL))(a1: v3); /*0x1067063f3*/
      if ( v32 != 0 ) /*0x1067063fc*/
      {
        v146[0] = (std::__shared_weak_count *)RBX::Network::Replicator::onPlayerRemoving; /*0x106706409*/
        v146[1] = nullptr; /*0x10670640c*/
        v147 = v3; /*0x106706414*/
        rbx::signal<void ()(std::shared_ptr<RBX::Instance>,std::shared_ptr<RBX::Instance>)>::connect<std::__bind<void (RBX::Network::Replicator::*)(std::shared_ptr<RBX::Instance> const&,std::shared_ptr<RBX::Instance> const&),RBX::Network::ClientReplicator *,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>( /*0x106706423*/
          a1: &__src,
          a2: v32 + 96);
        rbx::signals::scoped_connection::operator=(this: (RBX::DataModel *)((char *)v3 + 12544)); /*0x106706433*/
        v33 = (void *)__src; /*0x106706438*/
        if ( (_QWORD)__src != 0 && _InterlockedDecrement((volatile signed __int32 *)(__src + 4)) == 0 ) /*0x106706445*/
          rbx::signals::slot_base::operator delete(a1: v33); /*0x106706447*/
      }
      rbx::signal<void ()(void)>::invokeImpl<(rbx::SignalInvokePolicy)0>(a1: (RBX::DataModel *)((char *)v3 + 24440)); /*0x106706453*/
      *((_BYTE *)v3 + 18702) = 1; /*0x106706458*/
      if ( *((_BYTE *)v3 + 10391) == 1 ) /*0x106706468*/
        (*(void (__fastcall **)(_QWORD))(**((_QWORD **)v3 + 35) + 88LL))(a1: *((_QWORD *)v3 + 35)); /*0x106706474*/
      RBX::Network::ClientReplicator::prepareJoinRxDataStats(this: v3); /*0x10670647a*/
      if ( (unsigned __int8)RBX::Network::Replicator::getSharedStringCachingEnabled(this: v3) != 0 ) /*0x106706489*/
      {
        v34 = *((RBX::Network::SharedStringSynchronizer **)v3 + 1927); /*0x10670648b*/
        if ( v34 != nullptr ) /*0x106706495*/
          RBX::Network::SharedStringSynchronizer::writeToPlaceIdTable(this: v34); /*0x106706497*/
      }
      v35 = *((RBX::Network::ClientReplicator::GCJob **)v3 + 2753); /*0x10670649c*/
      if ( v35 != nullptr ) /*0x1067064a6*/
      {
        RBX::Network::ClientReplicator::GCJob::setReadyToWork(this: v35); /*0x1067064ac*/
        v36 = (*(__int64 (__fastcall **)(RBX::DataModel *))(*(_QWORD *)v3 + 688LL))(a1: v3); /*0x1067064b8*/
        v37 = *((_QWORD *)v3 + 2753); /*0x1067064be*/
        v38 = v37 + 432; /*0x1067064c5*/
        if ( v37 == 0 ) /*0x1067064cf*/
          v38 = 0; /*0x1067064cf*/
        v143 = v38; /*0x1067064d3*/
        v39 = *((volatile signed __int64 **)v3 + 2754); /*0x1067064da*/
        v144 = (std::__shared_weak_count *)v39; /*0x1067064e1*/
        if ( v39 != nullptr ) /*0x1067064eb*/
          _InterlockedIncrement64(v39 + 1); /*0x1067064ed*/
        RBX::Player::setStreamingInterface(a1: v36, a2: &v143); /*0x1067064fc*/
        v40 = v144; /*0x106706501*/
        if ( v144 != nullptr /*0x10670651d*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v144 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v40 + 16LL))(a1: v40); /*0x106706525*/
          std::__shared_weak_count::__release_weak(this: v40); /*0x10670652b*/
        }
      }
      v41 = (*(__int64 (__fastcall **)(RBX::DataModel *))(*(_QWORD *)v3 + 688LL))(a1: v3); /*0x10670653d*/
      RBX::shared_from<RBX::Network::ClientReplicator>(a1: v146, a2: (__int64)v3); /*0x106706547*/
      v42 = (char *)v146[0] + 216; /*0x106706554*/
      if ( v146[0] == nullptr ) /*0x10670655e*/
        v42 = nullptr; /*0x10670655e*/
      v140 = v42; /*0x106706569*/
      v141 = v146[1]; /*0x10670656c*/
      *(_OWORD *)v146 = 0; /*0x106706574*/
      RBX::Player::setNetworkInterface(a1: v41); /*0x10670657c*/
      v43 = v141; /*0x106706581*/
      if ( v141 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v141 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10670659d*/
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v43 + 16LL))(a1: v43); /*0x1067065a5*/
        std::__shared_weak_count::__release_weak(this: v43); /*0x1067065ab*/
      }
      v44 = v146[1]; /*0x1067065b0*/
      if ( v146[1] != nullptr /*0x1067065c9*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v146[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v44 + 16LL))(a1: v44); /*0x1067065d1*/
        std::__shared_weak_count::__release_weak(this: v44); /*0x1067065d7*/
      }
      *(_BYTE *)((*(__int64 (__fastcall **)(RBX::DataModel *))(*(_QWORD *)v3 + 688LL))(a1: v3) + 4322) = 1; /*0x1067065e9*/
      *((_BYTE *)v3 + 15550) = (*(__int64 (__fastcall **)(RBX::DataModel *))(*(_QWORD *)v3 + 1048LL))(a1: v3) ^ 1; /*0x1067065ff*/
      *((_QWORD *)v3 + 854) = (unsigned int)RakNet::GetTimeMS(this: v45); /*0x10670660d*/
      if ( *(_BYTE *)(RBX::CoreNetworkSettings::singleton(this: v46) + 144) == 1 )
      {
        std::string::basic_string[abi:ne200100]<0>(a1: v146, a2: "\n === Join Completed ===\n", a3: v47, a4: v48); /*0x106706631*/
        RBX::append_format( /*0x10670664c*/
          a1: (unsigned __int8 *)v146,
          a2: "Top %d Instances by Size:\n",
          a3: (unsigned int)DFInt::ReplicatorJoinDiagnosticLargeInstancesToKeep,
          a4: v49,
          a5: v50,
          a6: v51,
          a7: v52,
          a8: v53,
          a9: v54,
          a10: v55,
          a11: v56,
          a12: v57,
          a13: v58,
          a14: v59,
          a15: v132);
        v60 = *((_QWORD *)v3 + 2002); /*0x106706651*/
        v148 = *(double *)&v3; /*0x106706658*/
        for ( i = *((_QWORD *)v3 + 2003); v60 != i; v60 += 24 ) /*0x106706666*/
        {
          v62 = *(_DWORD *)v60; /*0x106706670*/
          v63 = *(_DWORD *)(*(_QWORD *)&v148 + 15704LL); /*0x106706677*/
          (*(void (__fastcall **)(__int128 *))(**(_QWORD **)(v60 + 8) + 184LL))(a1: &__src); /*0x106706689*/
          v73 = 0; /*0x106706692*/
          v74 = (char *)&__src + 1; /*0x1067066a6*/
          if ( (__src & 1) != 0 ) /*0x1067066aa*/
            v74 = (char *)v150; /*0x1067066ac*/
          v75 = 0; /*0x1067066b3*/
          v75.f32[0] = (float)v63; /*0x1067066b6*/
          *(double *)v73.i64 = (float)((float)((float)v62 * 100.0) / (float)v63); /*0x1067066bf*/
          RBX::append_format( /*0x1067066cf*/
            a1: (unsigned __int8 *)v146,
            a2: "%.3f%% %s\n",
            a3: (__int64)v74,
            a4: v64,
            a5: v65,
            a6: v66,
            a7: v73,
            a8: v75,
            a9: v67,
            a10: v68,
            a11: v69,
            a12: v70,
            a13: v71,
            a14: v72,
            a15: v132);
          if ( (__src & 1) != 0 ) /*0x1067066d8*/
            operator delete(a1: (RBX::Memory *)v150, a2: v76); /*0x1067066de*/
        }
        __src = 0; /*0x1067066f4*/
        v150 = nullptr; /*0x1067066f8*/
        v77 = v148; /*0x106706700*/
        std::vector<std::pair<RBX::Reflection::ClassDescriptor const*,float>>::reserve( /*0x10670670b*/
          a1: &__src,
          a2: *(unsigned int *)(*(_QWORD *)&v148 + 16112LL));
        if ( *(_DWORD *)(*(_QWORD *)&v77 + 16112LL) == 0 ) /*0x106706718*/
          goto LABEL_87; /*0x106706718*/
        v78 = *(_QWORD *)(*(_QWORD *)&v77 + 16104LL); /*0x10670671e*/
        v79 = *(unsigned int *)(*(_QWORD *)&v77 + 16120LL); /*0x106706725*/
        v80 = v78; /*0x106706733*/
        if ( v79 != 0 ) /*0x106706739*/
        {
          v81 = 16 * v79; /*0x106706740*/
          v80 = v78; /*0x106706743*/
          while ( (*(_QWORD *)v80 | 0x1000LL) == 0xFFFFFFFFFFFFF000LL ) /*0x106706753*/
          {
            v80 += 16; /*0x106706755*/
            v81 -= 16; /*0x106706759*/
            if ( v81 == 0 ) /*0x10670675d*/
              goto LABEL_87; /*0x10670675d*/
          }
        }
        v82 = 16 * v79 + v78; /*0x106706764*/
        if ( v80 == v82 ) /*0x10670676a*/
        {
LABEL_87:
          v83 = *((_QWORD *)&__src + 1); /*0x1067068b6*/
        }
        else
        {
          v83 = *((_QWORD *)&__src + 1); /*0x10670677e*/
          do /*0x1067068ae*/
          {
            if ( v83 >= (unsigned __int64)v150 ) /*0x10670678e*/
            {
              v84 = (const void *)__src; /*0x1067067b2*/
              v85 = v83 - __src; /*0x1067067b6*/
              v86 = v85 >> 4; /*0x1067067bc*/
              v87 = (v85 >> 4) + 1; /*0x1067067c0*/
              if ( v87 > 0xFFFFFFFFFFFFFFFLL ) /*0x1067067c8*/
                std::vector<std::pair<RBX::Reflection::ClassDescriptor const*,float>>::__throw_length_error[abi:ne200100](a1: 0xFFFFFFFFFFFFFFFLL); /*0x106706b63*/
              v88 = ((__int64)v150 - (__int64)__src) >> 3; /*0x1067067d4*/
              if ( v88 <= v87 ) /*0x1067067db*/
                v88 = (v85 >> 4) + 1; /*0x1067067db*/
              if ( (char *)v150 - (unsigned __int64)__src >= (char *)0x7FFFFFFFFFFFFFF0LL ) /*0x1067067ec*/
                v88 = 0xFFFFFFFFFFFFFFFLL; /*0x1067067ec*/
              if ( v88 != 0 ) /*0x1067067f3*/
              {
                v89 = std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<RBX::Reflection::ClassDescriptor const*,float>>>( /*0x1067067fc*/
                        a1: &v150,
                        a2: v88);
                v91 = v90; /*0x106706801*/
                v84 = (const void *)__src; /*0x106706804*/
                v85 = *((_QWORD *)&__src + 1) - __src; /*0x10670680c*/
                v92 = (__int64)(*((_QWORD *)&__src + 1) - __src) >> 4; /*0x106706812*/
              }
              else
              {
                v92 = v85 >> 4; /*0x106706818*/
                v89 = 0; /*0x10670681b*/
                v91 = 0; /*0x10670681d*/
              }
              v93 = v85; /*0x10670681f*/
              v94 = v89 + 16 * v86; /*0x106706826*/
              v83 = v94 + 16; /*0x106706838*/
              *(_QWORD *)v94 = *(_QWORD *)v80; /*0x10670683c*/
              v95 = (void *)(v89 + 16 * v91); /*0x10670684f*/
              *(float *)(v94 + 8) = (float)*(int *)(v80 + 12); /*0x106706852*/
              v96 = (void *)(v94 - 16 * v92); /*0x10670685c*/
              memcpy(__dst: v96, __src: v84, __n: v93); /*0x106706862*/
              v98 = (RBX::Memory *)__src; /*0x106706867*/
              *(_QWORD *)&__src = v96; /*0x10670686b*/
              *((_QWORD *)&__src + 1) = v83; /*0x10670686f*/
              v150 = v95; /*0x106706873*/
              if ( v98 != nullptr ) /*0x10670687a*/
                operator delete(a1: v98, a2: v97); /*0x10670687c*/
            }
            else
            {
              *(_QWORD *)v83 = *(_QWORD *)v80; /*0x106706793*/
              *(float *)(v83 + 8) = (float)*(int *)(v80 + 12); /*0x1067067a3*/
              v83 += 16LL; /*0x1067067a9*/
            }
            *((_QWORD *)&__src + 1) = v83; /*0x106706890*/
            do /*0x1067068a9*/
              v80 += 16; /*0x106706894*/
            while ( v80 != v82 && (*(_QWORD *)v80 | 0x1000LL) == 0xFFFFFFFFFFFFF000LL ); /*0x1067068a9*/
          }
          while ( v80 != v82 ); /*0x1067068ae*/
        }
        _BitScanReverse64(&v99, (__int64)(v83 - __src) >> 4); /*0x1067068c8*/
        v100 = (2 * ((unsigned int)v99 ^ 0x3F)) ^ 0x7ELL; /*0x1067068d1*/
        v101 = 0; /*0x1067068d5*/
        if ( v83 != (_QWORD)__src ) /*0x1067068da*/
          v101 = v100; /*0x1067068da*/
        std::__introsort<std::_ClassicAlgPolicy,RBX::Network::ClientReplicator::processTag(RBX::Network::TagItemType)::$_0 &,std::pair<RBX::Reflection::ClassDescriptor const*,float> *,false>( /*0x1067068e6*/
          a1: __src,
          a2: v83,
          a3: v101,
          a4: 1);
        std::string::append(a1: v146, a2: "\nTransmission Size By Type (% of Instance Data):\n", v102); /*0x1067068f6*/
        *(double *)&v3 = v148; /*0x1067068fb*/
        v115 = *((unsigned int **)&__src + 1); /*0x106706903*/
        v114 = (unsigned int *)__src; /*0x106706903*/
        if ( (_QWORD)__src != *((_QWORD *)&__src + 1) ) /*0x10670690a*/
        {
          v116 = 0; /*0x106706910*/
          do /*0x106706981*/
          {
            v106 = (__m128)v114[2]; /*0x10670691e*/
            *(double *)v106.i64 = (float)((float)(v106.f32[0] * 100.0) / (float)*(int *)(*(_QWORD *)&v148 + 15704LL)); /*0x106706941*/
            v107 = (__m128)0x3FB999999999999AuLL; /*0x106706945*/
            if ( *(double *)v106.i64 >= 0.1 ) /*0x106706951*/
            {
              v117 = *(_QWORD *)(*(_QWORD *)v114 + 8LL); /*0x10670695b*/
              if ( (*(_BYTE *)v117 & 1) != 0 ) /*0x106706962*/
                v118 = *(_QWORD *)(v117 + 16); /*0x106706969*/
              else
                v118 = v117 + 1; /*0x106706964*/
              RBX::append_format( /*0x106706975*/
                a1: (unsigned __int8 *)v146,
                a2: "%.3f%% %s\n",
                a3: v118,
                a4: v103,
                a5: v104,
                a6: v105,
                a7: v106,
                a8: (__m128)0x3FB999999999999AuLL,
                a9: v108,
                a10: v109,
                a11: v110,
                a12: v111,
                a13: v112,
                a14: v113,
                a15: v132);
            }
            else
            {
              ++v116; /*0x106706953*/
            }
            v114 += 4; /*0x10670697a*/
          }
          while ( v114 != v115 ); /*0x106706981*/
          *(double *)&v3 = v148; /*0x106706986*/
          if ( v116 != 0 ) /*0x10670698a*/
            RBX::append_format( /*0x10670699c*/
              a1: (unsigned __int8 *)v146,
              a2: "[Skipped %d types with < 0.1%%]\n",
              a3: v116,
              a4: v103,
              a5: v104,
              a6: v105,
              a7: v106,
              a8: v107,
              a9: v108,
              a10: v109,
              a11: v110,
              a12: v111,
              a13: v112,
              a14: v113,
              a15: v132);
        }
        RBX::append_format(
          a1: (unsigned __int8 *)v146,
          a2: "\nTotal Transmitted Join Bytes (Instance + Terrain) : %u (%u + %u)",
          a3: (unsigned int)(*((_DWORD *)v3 + 3929) + *((_DWORD *)v3 + 3926)),
          a4: *((unsigned int *)v3 + 3926),
          a5: *((unsigned int *)v3 + 3929),
          a6: v105,
          a7: v106,
          a8: v107,
          a9: v108,
          a10: v109,
          a11: v110,
          a12: v111,
          a13: v112,
          a14: v113,
          a15: v132);
        if ( ((__int64)v146[0] & 1) != 0 ) /*0x1067069c9*/
          LODWORD(v122) = (_DWORD)v147; /*0x1067069cb*/
        else
          v122 = (char *)v146 + 1; /*0x1067069d1*/
        RBX::CreatorLog::printf(a1: 1, a2: (unsigned int)"%s", a3: (_DWORD)v122, a4: v119, a5: v120, a6: v121); /*0x1067069e3*/
        if ( (_QWORD)__src != 0 ) /*0x1067069ef*/
        {
          *((_QWORD *)&__src + 1) = __src; /*0x1067069f1*/
          operator delete(a1: (RBX::Memory *)__src, a2: v123); /*0x1067069f5*/
        }
        if ( ((__int64)v146[0] & 1) != 0 ) /*0x1067069fe*/
          operator delete(a1: (RBX::Memory *)v147, a2: v123); /*0x106706a04*/
      }
      RBX::DenseMapBase<RBX::DenseMap<RBX::Reflection::ClassDescriptor const*,RBX::Network::JoinRxStats::ClassSizeAndCount,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const*,void>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const*,RBX::Network::JoinRxStats::ClassSizeAndCount>>,RBX::Reflection::ClassDescriptor const*,RBX::Network::JoinRxStats::ClassSizeAndCount,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const*,void>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const*,RBX::Network::JoinRxStats::ClassSizeAndCount>>::clear( /*0x106706a15*/
        a1: (__int64)v3 + 16104,
        a2: 1);
      RBX::DenseMapBase<RBX::DenseMap<RBX::Reflection::ClassDescriptor const*,RBX::Network::JoinRxStats::ClassSizeAndCount,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const*,void>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const*,RBX::Network::JoinRxStats::ClassSizeAndCount>>,RBX::Reflection::ClassDescriptor const*,RBX::Network::JoinRxStats::ClassSizeAndCount,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const*,void>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const*,RBX::Network::JoinRxStats::ClassSizeAndCount>>::clear( /*0x106706a26*/
        a1: (__int64)v3 + 16128,
        a2: 1);
      v124 = *((_QWORD *)v3 + 2002); /*0x106706a2b*/
      v125 = *((_QWORD *)v3 + 2003); /*0x106706a32*/
      if ( v125 != v124 ) /*0x106706a3c*/
      {
        do /*0x106706a51*/
        {
          v126 = v125 - 24; /*0x106706a3e*/
          std::shared_ptr<RBX::Object>::~shared_ptr[abi:ne200100](a1: v125 - 16); /*0x106706a46*/
          v125 = v126; /*0x106706a4b*/
        }
        while ( v126 != v124 ); /*0x106706a51*/
      }
      *((_QWORD *)v3 + 2003) = v124; /*0x106706a53*/
      *((_BYTE *)v3 + 18409) = 1; /*0x106706a5a*/
      std::__hash_table<std::__hash_value_type<std::string,RBX::DenseMap<RBX::Reflection::ClassDescriptor const*,unsigned int,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const*,void>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const*,unsigned int>>>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::DenseMap<RBX::Reflection::ClassDescriptor const*,unsigned int,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const*,void>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const*,unsigned int>>>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::DenseMap<RBX::Reflection::ClassDescriptor const*,unsigned int,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const*,void>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const*,unsigned int>>>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::DenseMap<RBX::Reflection::ClassDescriptor const*,unsigned int,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const*,void>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const*,unsigned int>>>>>::clear(a1: (char *)v3 + 16152); /*0x106706a69*/
      RBX::DenseMapBase<RBX::DenseMap<RBX::Reflection::ClassDescriptor const*,unsigned int,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const*,void>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const*,unsigned int>>,RBX::Reflection::ClassDescriptor const*,unsigned int,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const*,void>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const*,unsigned int>>::clear( /*0x106706a7a*/
        a1: (__int64)v3 + 16192,
        a2: 1);
      v127 = *((rbx::signals::scoped_connection **)v3 + 2027); /*0x106706a7f*/
      v128 = *((rbx::signals::scoped_connection **)v3 + 2028); /*0x106706a86*/
      v2 = v145; /*0x106706a90*/
      while ( v128 != v127 ) /*0x106706a97*/
      {
        v128 = (rbx::signals::scoped_connection *)((char *)v128 - 8); /*0x106706a99*/
        rbx::signals::scoped_connection::~scoped_connection(this: v128); /*0x106706aa0*/
      }
      *((_QWORD *)v3 + 2028) = v127; /*0x106706aaa*/
      RBX::Profiler::Scope::~Scope(this: (RBX::Profiler::Scope *)&v132); /*0x106706ab8*/
      break;
    case 16:
      v4 = (RBX::Preloaded *)RBX::ServiceProvider::find<RBX::Preloaded>(a1: this); /*0x1067060f8*/
      if ( v4 != nullptr ) /*0x106706100*/
        RBX::Preloaded::setContentLoaded(this: v4); /*0x106706109*/
      break;
    default:
      break; /*0x1067060df*/
  }
  result = &FFlag::DebugClientDumpMicroprofileForJoins; /*0x106706abd*/
  if ( FFlag::DebugClientDumpMicroprofileForJoins != 0 ) /*0x106706ac7*/
  {
    if ( v2 != 13 ) /*0x106706acd*/
      return result; /*0x106706acd*/
  }
  else
  {
    result = (char *)RBX::Analytics::InfluxDb::canSend( /*0x106706ad7*/
                       this: (RBX::Analytics::InfluxDb *)(unsigned int)DFInt::ClientReportInitExpJobStatsHundredthPercent,
                       a2);
    if ( v2 != 13 || (_BYTE)result == 0 ) /*0x106706ae4*/
      return result; /*0x106706ae4*/
  }
  if ( (_BYTE)`guard variable for'RBX::Network::ClientReplicator::processTag(RBX::Network::TagItemType)::proflabeltoken == 0 /*0x106706b2b*/
    && __cxa_guard_acquire(a1: &`guard variable for'RBX::Network::ClientReplicator::processTag(RBX::Network::TagItemType)::proflabeltoken) != 0 )
  {
    *(_QWORD *)&v132 = "STUN binding success response"; /*0x106706b34*/
    RBX::Network::ClientReplicator::processTag(RBX::Network::TagItemType)::proflabeltoken = RBX::Profiler::getLabelToken( /*0x106706b4e*/
                                                                                              this: (RBX::Profiler *)&aSCannotFindCan[-735392],
                                                                                              a2: v130);
    __cxa_guard_release(a1: &`guard variable for'RBX::Network::ClientReplicator::processTag(RBX::Network::TagItemType)::proflabeltoken); /*0x106706b5c*/
  }
  RBX::Profiler::addLabel( /*0x106706afe*/
    a1: RBX::Network::ClientReplicator::processTag(RBX::Network::TagItemType)::proflabeltoken,
    a2: "GameLoaded");
  return (char *)RBX::Network::ClientReplicator::prepareDumpOrReportProfile(this: v3); /*0x106706b0b*/
}

// Address: 0x106706dba | Name: __ZN3RBX7Network16ClientReplicator22prepareJoinRxDataStatsEv
__int64 __fastcall RBX::Network::ClientReplicator::prepareJoinRxDataStats(RBX::Network::ClientReplicator *this)
{
  float *v1; // r14
  __int64 v2; // rbx
  RakNet *v3; // rdi
  __int64 v4; // rbx
  RBX::Network::Replicator *v5; // rbx
  __int64 v6; // rax
  char v7; // al
  const char *v8; // rdx
  __int64 v9; // rcx
  RBX::Time *v10; // rdi
  RBX::Network::Replicator *v11; // rbx
  double v12; // xmm0_8
  double v13; // xmm0_8
  int v14; // ebx
  double v15; // xmm0_8
  RBX::Network::Replicator *v16; // r14
  int v17; // eax
  double v18; // xmm0_8
  int v19; // eax
  RBX::Network::Replicator *v20; // rsi
  char BatchNetAssetJoinEnabled; // al
  unsigned int *v22; // rbx
  int v23; // eax
  unsigned int v24; // edx
  double v25; // xmm0_8
  int v26; // eax
  __m128d v27; // xmm0
  __m128 v28; // xmm0
  __m128i inserted; // xmm1
  __m128 v30; // xmm1
  __m128 v31; // xmm0
  unsigned int *v32; // rbx
  __int64 v33; // rdx
  __int64 v34; // r15
  unsigned __int64 v35; // rax
  unsigned __int8 *v36; // r13
  unsigned int v37; // r12d
  size_t v38; // r12
  RBX::Memory *v39; // r14
  const void *v40; // r13
  RBX::Memory *v41; // rsi
  __int64 v42; // rdx
  void *v43; // rsi
  unsigned __int8 *v44; // r13
  unsigned int v45; // r12d
  size_t v46; // r12
  RBX::Memory *v47; // r14
  const void *v48; // r13
  RBX::Memory *v49; // rsi
  __int64 v50; // rdx
  void *v51; // rsi
  int v52; // ebx
  int v53; // r14d
  int v54; // r8d
  int v55; // r9d
  char *v56; // rcx
  void *v57; // rsi
  void *v58; // rsi
  unsigned int *v59; // rbx
  __int64 v60; // rdx
  __int64 v61; // r15
  unsigned __int64 v62; // rax
  unsigned __int8 *v63; // r13
  unsigned int v64; // r12d
  size_t v65; // r12
  RBX::Memory *v66; // r14
  const void *v67; // r13
  RBX::Memory *v68; // rsi
  __int64 v69; // rdx
  void *v70; // rsi
  unsigned __int8 *v71; // r13
  unsigned int v72; // r12d
  size_t v73; // r12
  RBX::Memory *v74; // r14
  const void *v75; // r13
  RBX::Memory *v76; // rsi
  __int64 v77; // rdx
  void *v78; // rsi
  int v79; // ebx
  int v80; // r14d
  int v81; // r8d
  int v82; // r9d
  char *v83; // rcx
  void *v84; // rsi
  void *v85; // rsi
  int v86; // esi
  RBX::TaskScheduler *v87; // rdi
  int v88; // esi
  double v89; // r12
  int v90; // r14d
  unsigned int v91; // r8d
  __int64 v92; // rcx
  __int64 v93; // r8
  int v94; // ebx
  bool v95; // zf
  unsigned int *v96; // r13
  __int64 v97; // rcx
  __int64 v98; // r14
  __int64 v99; // r12
  unsigned __int64 v100; // rax
  unsigned __int8 *v101; // rsi
  unsigned int v102; // edx
  __int64 v103; // rdx
  unsigned __int8 *v104; // rsi
  _QWORD *v105; // rax
  unsigned int v106; // ecx
  unsigned int v107; // r13d
  size_t v108; // r13
  char *v109; // r12
  void *v110; // rsi
  char *v111; // rsi
  void *v112; // rsi
  double v113; // r12
  unsigned int v114; // r13d
  size_t v115; // r13
  char *v116; // r12
  char *v117; // rsi
  void *v118; // rsi
  double v119; // r12
  unsigned int *v120; // r13
  __int64 v121; // rdx
  __int64 v122; // r12
  int v123; // ebx
  unsigned __int64 v124; // rax
  bool v125; // r14
  unsigned __int8 *v126; // rsi
  unsigned int v127; // edx
  __int64 v128; // rdx
  unsigned __int8 *v129; // rsi
  unsigned int *i; // rax
  void *v131; // rsi
  __int64 v132; // rdx
  unsigned __int8 *v133; // rcx
  void *v134; // rsi
  __int64 v135; // rax
  void *v136; // rsi
  unsigned int *v137; // r15
  __int64 v138; // rdx
  __int64 v139; // r14
  unsigned __int8 *v140; // rsi
  unsigned int v141; // edx
  __int64 v142; // rdx
  unsigned __int8 *v143; // rsi
  void *v144; // rsi
  void *v145; // rsi
  __int64 v146; // rax
  RBX::Network::Replicator *v147; // r13
  unsigned __int64 v148; // rbx
  __m128d v149; // xmm1
  __m128d v150; // xmm1
  __m128d v151; // xmm0
  __m128d v152; // xmm2
  int v153; // r14d
  unsigned int v154; // edx
  int v155; // r15d
  int v156; // r12d
  signed int v157; // r15d
  signed int v158; // r14d
  signed int v159; // r12d
  __int64 v160; // rdx
  __int64 v161; // rcx
  __int64 v162; // rdx
  __int64 v163; // rcx
  __int64 v164; // r8
  __int64 v165; // r9
  void *v166; // rsi
  __int64 v167; // r12
  __int64 v168; // rbx
  __int64 v169; // r14
  __int64 v170; // r15
  __int64 v171; // r13
  unsigned __int64 v172; // r15
  unsigned __int64 v173; // r13
  unsigned __int64 v174; // r12
  int v175; // r14d
  __m128i v176; // xmm2
  __m128d v177; // xmm1
  __m128d v178; // xmm1
  __m128d v179; // xmm0
  double v180; // rbx
  __m128d v181; // xmm0
  __m128d v182; // xmm0
  __m128d v183; // xmm0
  __m128d v184; // xmm0
  __m128d v185; // xmm0
  __m128d v186; // xmm0
  __int64 v187; // rdx
  __int64 v188; // rcx
  __int64 v189; // rdx
  __int64 v190; // rcx
  __int64 v191; // r8
  __int64 v192; // r9
  void *v193; // rsi
  __int64 v194; // rdx
  __int64 v195; // rcx
  __int64 v196; // rdx
  __int64 v197; // rcx
  __int64 v198; // r8
  __int64 v199; // r9
  __int64 v200; // rdx
  __int64 v201; // rcx
  void *v202; // rsi
  int v203; // ebx
  __int64 v204; // rdx
  __int64 v205; // rcx
  __int64 v206; // r8
  __int64 v207; // r9
  void *v208; // rsi
  int v209; // ebx
  __int64 v210; // rdx
  __int64 v211; // rcx
  __int64 v212; // rdx
  __int64 v213; // rcx
  __int64 v214; // r8
  __int64 v215; // r9
  __int64 v216; // rdx
  __int64 v217; // rcx
  void *v218; // rsi
  int v219; // ebx
  __int64 v220; // rdx
  __int64 v221; // rcx
  __int64 v222; // r8
  __int64 v223; // r9
  __int64 v224; // rdx
  __int64 v225; // rcx
  void *v226; // rsi
  int v227; // ebx
  __int64 v228; // rdx
  __int64 v229; // rcx
  __int64 v230; // r8
  __int64 v231; // r9
  __int64 v232; // rdx
  __int64 v233; // rcx
  void *v234; // rsi
  int v235; // ebx
  __int64 v236; // rdx
  __int64 v237; // rcx
  __int64 v238; // r8
  __int64 v239; // r9
  void *v240; // rsi
  __int64 v241; // rdx
  unsigned __int8 *v242; // rcx
  unsigned __int64 v243; // rbx
  __int64 v244; // rdi
  RBX::Network::Replicator *v245; // r14
  double v246; // xmm0_8
  unsigned int v247; // r15d
  __m128d v248; // xmm0
  __m128d v249; // xmm0
  unsigned int v250; // r12d
  __int64 v251; // rax
  __int64 v252; // r8
  __int64 v253; // r9
  __int64 v254; // r15
  _QWORD *v255; // rbx
  int v256; // r14d
  __int64 v257; // rax
  unsigned int v258; // r13d
  unsigned int v259; // r12d
  __int64 v260; // rax
  __int64 v261; // rdx
  __int64 v262; // r8
  __int64 v263; // r9
  int v264; // ebx
  unsigned int v265; // ebx
  __int64 v266; // rax
  __int64 v267; // rax
  RBX::Network::Replicator *v268; // rcx
  RBX::Network::Replicator *v269; // rbx
  int v270; // ecx
  RBX::Network::Replicator *v271; // rsi
  int v272; // r8d
  int v273; // r9d
  char v274; // al
  RBX::Network::Replicator *v275; // rsi
  int v276; // r8d
  int v277; // r9d
  unsigned int v278; // ecx
  int v279; // edi
  unsigned int v280; // eax
  char v281; // al
  __int64 v282; // rdx
  int v283; // r8d
  int v284; // r9d
  unsigned int v285; // edi
  unsigned int v286; // eax
  char *v287; // rcx
  int v288; // edi
  unsigned int v289; // eax
  const char *v290; // rsi
  double v291; // rax
  void *v292; // rcx
  __int64 v293; // rdx
  __int64 v294; // r8
  __int64 v295; // r9
  void *v296; // rsi
  double v297; // xmm0_8
  __int64 v298; // rdx
  __int64 v299; // rcx
  __int64 v300; // r8
  __int64 v301; // r9
  void *v302; // rsi
  double v303; // rax
  void *v304; // rcx
  __int64 v305; // rdx
  __int64 v306; // r8
  __int64 v307; // r9
  void *v308; // rsi
  char v309; // al
  RBX::Memory *v310; // rcx
  double v311; // xmm0_8
  __int64 v312; // r8
  __int64 v313; // r9
  void *v314; // rsi
  char v315; // al
  RBX::Memory *v316; // rcx
  double v317; // xmm0_8
  __int64 v318; // r8
  __int64 v319; // r9
  void *v320; // rsi
  double v321; // xmm0_8
  __int64 v322; // rdx
  __int64 v323; // rcx
  __int64 v324; // r8
  __int64 v325; // r9
  void *v326; // rsi
  __int64 v327; // rdx
  __int64 v328; // rcx
  __int64 v329; // r8
  __int64 v330; // r9
  void *v331; // rsi
  __int64 v332; // rdx
  __int64 v333; // rcx
  __int64 v334; // r8
  __int64 v335; // r9
  void *v336; // rsi
  int v337; // eax
  __int64 v338; // rdx
  __int64 v339; // rcx
  __int64 v340; // r8
  __int64 v341; // r9
  void *v342; // rsi
  __int64 v343; // rdx
  __int64 v344; // rcx
  __int64 v345; // r8
  __int64 v346; // r9
  void *v347; // rsi
  __int64 v348; // rdx
  __int64 v349; // rcx
  __int64 v350; // r8
  __int64 v351; // r9
  __int64 v352; // rdx
  __int64 v353; // rcx
  void *v354; // rsi
  int v355; // ebx
  __int64 v356; // rdx
  __int64 v357; // rcx
  __int64 v358; // r8
  __int64 v359; // r9
  __int64 v360; // rdx
  __int64 v361; // rcx
  void *v362; // rsi
  __int64 v363; // rdx
  __int64 v364; // rcx
  __int64 v365; // r8
  __int64 v366; // r9
  __int64 v367; // rdx
  __int64 v368; // rcx
  void *v369; // rsi
  int v370; // ebx
  __int64 v371; // rdx
  __int64 v372; // rcx
  __int64 v373; // r8
  __int64 v374; // r9
  __int64 v375; // rdx
  __int64 v376; // rcx
  void *v377; // rsi
  int v378; // ebx
  __int64 v379; // rdx
  __int64 v380; // rcx
  __int64 v381; // r8
  __int64 v382; // r9
  __int64 v383; // rdx
  __int64 v384; // rcx
  void *v385; // rsi
  int v386; // ebx
  __int64 v387; // rdx
  __int64 v388; // rcx
  __int64 v389; // r8
  __int64 v390; // r9
  __int64 v391; // rdx
  __int64 v392; // rcx
  void *v393; // rsi
  __int64 v394; // rdx
  __int64 v395; // rcx
  __int64 v396; // r8
  __int64 v397; // r9
  __int64 v398; // rdx
  __int64 v399; // rcx
  void *v400; // rsi
  __int64 v401; // rdx
  __int64 v402; // rcx
  __int64 v403; // r8
  __int64 v404; // r9
  __int64 v405; // rdx
  __int64 v406; // rcx
  void *v407; // rsi
  __int64 v408; // rdx
  __int64 v409; // rcx
  __int64 v410; // r8
  __int64 v411; // r9
  __int64 v412; // rdx
  __int64 v413; // rcx
  void *v414; // rsi
  __int64 v415; // rdx
  __int64 v416; // rcx
  __int64 v417; // r8
  __int64 v418; // r9
  __int64 v419; // rdx
  __int64 v420; // rcx
  void *v421; // rsi
  __int64 v422; // rdx
  __int64 v423; // rcx
  __int64 v424; // r8
  __int64 v425; // r9
  __int64 v426; // rdx
  __int64 v427; // rcx
  void *v428; // rsi
  __int64 v429; // rdx
  __int64 v430; // rcx
  __int64 v431; // r8
  __int64 v432; // r9
  __int64 v433; // rdx
  __int64 v434; // rcx
  void *v435; // rsi
  __int64 v436; // rdx
  __int64 v437; // rcx
  __int64 v438; // r8
  __int64 v439; // r9
  __int64 v440; // rdx
  __int64 v441; // rcx
  void *v442; // rsi
  __int64 v443; // rdx
  __int64 v444; // rcx
  __int64 v445; // r8
  __int64 v446; // r9
  __int64 v447; // rdx
  __int64 v448; // rcx
  void *v449; // rsi
  __int64 v450; // rdx
  __int64 v451; // rcx
  __int64 v452; // r8
  __int64 v453; // r9
  __int64 v454; // rdx
  void *v455; // rsi
  __int64 v456; // rcx
  __int64 v457; // rdx
  __int64 v458; // r14
  double *v459; // r14
  int *v460; // rbx
  __int64 v461; // rdx
  __int64 v462; // rcx
  double *v463; // r14
  int *v464; // rbx
  __int64 v465; // r14
  RBX::Network::Replicator *v466; // r14
  void *v467; // rsi
  _DWORD v469[150]; // [rsp+20h] [rbp-950h] BYREF
  char v470; // [rsp+278h] [rbp-6F8h]
  __m128d v471; // [rsp+280h] [rbp-6F0h]
  __m128d v472; // [rsp+290h] [rbp-6E0h]
  __m128d v473; // [rsp+2A0h] [rbp-6D0h]
  __m128 v474; // [rsp+2B0h] [rbp-6C0h]
  __m128 v475; // [rsp+2C0h] [rbp-6B0h]
  __m128 v476; // [rsp+2D0h] [rbp-6A0h]
  _BYTE v477[40]; // [rsp+2E8h] [rbp-688h] BYREF
  _BYTE v478[40]; // [rsp+310h] [rbp-660h] BYREF
  __int64 v479; // [rsp+338h] [rbp-638h]
  __m128 v480; // [rsp+340h] [rbp-630h]
  __m128 v481; // [rsp+350h] [rbp-620h]
  __m128 v482; // [rsp+360h] [rbp-610h]
  unsigned int v483[2]; // [rsp+370h] [rbp-600h]
  unsigned int v484[2]; // [rsp+378h] [rbp-5F8h]
  unsigned int v485[2]; // [rsp+380h] [rbp-5F0h]
  unsigned int v486[2]; // [rsp+388h] [rbp-5E8h]
  double v487; // [rsp+390h] [rbp-5E0h]
  double v488; // [rsp+398h] [rbp-5D8h]
  __int64 v489; // [rsp+3A0h] [rbp-5D0h]
  unsigned __int64 v490; // [rsp+3A8h] [rbp-5C8h]
  unsigned __int64 v491; // [rsp+3B0h] [rbp-5C0h]
  unsigned __int64 v492; // [rsp+3B8h] [rbp-5B8h]
  unsigned __int64 v493; // [rsp+3C0h] [rbp-5B0h]
  RBX::Memory *v494; // [rsp+3C8h] [rbp-5A8h]
  __m128d v495; // [rsp+3D0h] [rbp-5A0h]
  unsigned int v496[4]; // [rsp+3E0h] [rbp-590h] BYREF
  __m128d v497; // [rsp+3F0h] [rbp-580h]
  double v498; // [rsp+408h] [rbp-568h]
  __int128 v499; // [rsp+410h] [rbp-560h] BYREF
  __int64 v500; // [rsp+420h] [rbp-550h]
  unsigned int v501; // [rsp+444h] [rbp-52Ch]
  unsigned int v502; // [rsp+448h] [rbp-528h]
  float v503; // [rsp+44Ch] [rbp-524h]
  double v504[2]; // [rsp+450h] [rbp-520h]
  unsigned int v505; // [rsp+460h] [rbp-510h]
  float v506; // [rsp+464h] [rbp-50Ch]
  void *__src; // [rsp+468h] [rbp-508h]
  unsigned int v508; // [rsp+474h] [rbp-4FCh]
  int v509[2]; // [rsp+478h] [rbp-4F8h]
  unsigned int v510[4]; // [rsp+480h] [rbp-4F0h] BYREF
  void *v511[2]; // [rsp+490h] [rbp-4E0h]
  int v512; // [rsp+4A0h] [rbp-4D0h]
  int v513[4]; // [rsp+4A8h] [rbp-4C8h] BYREF
  char *v514; // [rsp+4B8h] [rbp-4B8h]
  __m128d v515; // [rsp+4C0h] [rbp-4B0h]
  __int128 v516; // [rsp+4D0h] [rbp-4A0h] BYREF
  void *v517; // [rsp+4E0h] [rbp-490h]
  RBX::Network::Replicator *v518; // [rsp+4E8h] [rbp-488h]
  __int128 __dst; // [rsp+4F0h] [rbp-480h] BYREF
  RBX::Memory *v520; // [rsp+500h] [rbp-470h]
  double v521; // [rsp+508h] [rbp-468h]
  unsigned __int64 v522; // [rsp+510h] [rbp-460h]
  unsigned __int64 v523; // [rsp+518h] [rbp-458h]
  unsigned __int64 v524; // [rsp+520h] [rbp-450h]
  unsigned __int64 v525; // [rsp+530h] [rbp-440h]
  char v526; // [rsp+748h] [rbp-228h]
  _BYTE v527[15]; // [rsp+758h] [rbp-218h]
  void *v528[49]; // [rsp+768h] [rbp-208h] BYREF
  _DWORD v529[8]; // [rsp+8F0h] [rbp-80h] BYREF
  _QWORD v530[4]; // [rsp+910h] [rbp-60h] BYREF

  if ( FFlag::ConnectViaConnectionInternal == 0 && *((_BYTE *)this + 10391) != 0 ) /*0x106706def*/
    return __stack_chk_guard; /*0x106706def*/
  LOBYTE(v469[0]) = 0; /*0x106706df7*/
  v470 = 0; /*0x106706dfd*/
  v518 = this; /*0x106706e03*/
  RBX::Network::LargeReplicator::getIngressStats(this: (RBX::Network::LargeReplicator *)&__dst); /*0x106706e18*/
  *(_QWORD *)v486 = (unsigned int)__dst; /*0x106706e23*/
  *(_QWORD *)v484 = DWORD1(__dst); /*0x106706e30*/
  *(_QWORD *)v485 = DWORD2(__dst); /*0x106706e3d*/
  *(_QWORD *)v483 = HIDWORD(__dst); /*0x106706e4a*/
  v501 = HIDWORD(v520); /*0x106706e57*/
  v505 = HIDWORD(v521); /*0x106706e6f*/
  v502 = LODWORD(v521); /*0x106706e6f*/
  v508 = v522; /*0x106706e7b*/
  v1 = (float *)v518; /*0x106706e8b*/
  if ( FFlag::ConnectViaConnectionInternal == 0 && *((_BYTE *)v518 + 10391) == 0 ) /*0x106706e9c*/
  {
    v2 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)v518 + 28)); /*0x106706eaa*/
    RakNet::AddressOrGUID::AddressOrGUID( /*0x106706ebb*/
      this: (RakNet::AddressOrGUID *)&__dst,
      a2: (RBX::Network::Replicator *)((char *)v518 + 240));
    LODWORD(v2) = (*(__int64 (__fastcall **)(__int64, __int128 *))(*(_QWORD *)v2 + 760LL))(a1: v2, a2: &__dst); /*0x106706ed3*/
    *((float *)v518 + 3906) = (float)(*((_DWORD *)v518 + 3899) - v2); /*0x106706ee3*/
    v1[3907] = (float)(int)(RakNet::GetTimeMS(this: v3) - v2); /*0x106706efb*/
  }
  if ( (unsigned __int8)RBX::Network::Replicator::getSharedStringCachingEnabled(this: (RBX::Network::Replicator *)v1) != 0 ) /*0x106706f0e*/
    RBX::Network::SharedStringSynchronizer::addJoinTimeStats( /*0x106706f25*/
      this: *((RBX::Network::SharedStringSynchronizer **)v518 + 1927),
      a2: (RBX::Network::Replicator *)((char *)v518 + 15608));
  *(_OWORD *)v496 = 0; /*0x106706f2d*/
  if ( FFlag::ConnectViaConnectionInternal == 0 && *((_BYTE *)v518 + 10391) == 0 ) /*0x106706f4e*/
  {
    v4 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)v518 + 28)); /*0x106706f63*/
    RakNet::AddressOrGUID::AddressOrGUID( /*0x106706f7b*/
      this: (RakNet::AddressOrGUID *)&__dst,
      a2: (RBX::Network::Replicator *)((char *)v518 + 240));
    (*(void (__fastcall **)(__int64, __int128 *, unsigned int *))(*(_QWORD *)v4 + 336LL))(a1: v4, a2: &__dst, a3: v496); /*0x106706f94*/
  }
  RBX::Analytics::InfluxDb::Points::Points(a1: v528, a2: *((unsigned int *)v518 + 3945), a3: 0, a4: 0); /*0x106706fb2*/
  v5 = v518; /*0x106706fc1*/
  if ( FFlag::ConnectViaConnectionInternal == 0 ) /*0x106706fc8*/
  {
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x106706fe3*/
      this: (RBX::Analytics::InfluxDb::Points *)v528,
      a2: "deltaTimeBetweenJoinRequestAndFirstBlobArrivalInMs",
      a3: *((float *)v518 + 3906));
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x106707001*/
      this: (RBX::Analytics::InfluxDb::Points *)v528,
      a2: "deltaTimeBetweenJoinRequestAndJoinProcessingCompleteInMs",
      a3: *((float *)v5 + 3907));
  }
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670701f*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "joinDataReadTimeInMs",
    a3: *((float *)v5 + 3908));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670703d*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "joinDataProcessTimeInMs",
    a3: *((float *)v5 + 3911));
  if ( FFlag::ConnectViaConnectionInternal == 0 ) /*0x10670704c*/
  {
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x106707062*/
      this: (RBX::Analytics::InfluxDb::Points *)v528,
      a2: "totalBlobBytesRxDuringJoin",
      a3: *((_DWORD *)v5 + 3913));
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670707b*/
      this: (RBX::Analytics::InfluxDb::Points *)v528,
      a2: "totalBlobRxDuringJoin",
      a3: *((_DWORD *)v5 + 3914));
  }
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106707094*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "totalMetaBytesRxInJoin",
    a3: *((_DWORD *)v5 + 3915));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067070ad*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "totalWasteBytesRxInJoin",
    a3: *((_DWORD *)v5 + 3923));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067070c6*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "totalSharedStringBytesRxDuringJoin",
    a3: *((_DWORD *)v5 + 3916));
  if ( FFlag::ConnectViaConnectionInternal == 1 ) /*0x1067070d5*/
  {
    (*(void (__fastcall **)(__int128 *))(**((_QWORD **)v518 + 35) + 192LL))(a1: &__dst); /*0x1067070f3*/
    v6 = __dst; /*0x1067070f9*/
    v488 = *(double *)&__dst; /*0x106707100*/
    LOBYTE(v6) = BYTE8(__dst); /*0x106707107*/
    v489 = v6; /*0x10670710d*/
    v490 = *(_QWORD *)&v521; /*0x106707122*/
    v491 = v522; /*0x106707130*/
    v492 = v523; /*0x10670713e*/
    v493 = v524; /*0x10670714c*/
    v494 = v520; /*0x106707161*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x106707168*/
      this: (RBX::Analytics::InfluxDb::Points *)v528,
      a2: "totalRxBytes",
      a3: (unsigned __int64)v520);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x106707182*/
      this: (RBX::Analytics::InfluxDb::Points *)v528,
      a2: "totalRxPackets",
      a3: v490);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670719c*/
      this: (RBX::Analytics::InfluxDb::Points *)v528,
      a2: "totalRxDroppedPackets",
      a3: v491);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067071b6*/
      this: (RBX::Analytics::InfluxDb::Points *)v528,
      a2: "totalRxIgnoredBytes",
      a3: v492);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067071d0*/
      this: (RBX::Analytics::InfluxDb::Points *)v528,
      a2: "totalRxIgnoredPackets",
      a3: v493);
    v7 = (*(__int64 (__fastcall **)(_QWORD))(**((_QWORD **)v518 + 35) + 136LL))(a1: *((_QWORD *)v518 + 35)); /*0x1067071e6*/
    if ( v7 != 0 ) /*0x1067071f5*/
    {
      if ( v7 == 1 ) /*0x106707201*/
      {
        v8 = "RbxTransport"; /*0x106707207*/
        v9 = 12; /*0x10670720e*/
      }
      else
      {
        v8 = "Unknown"; /*0x1067072e7*/
        v9 = 7; /*0x1067072ee*/
      }
    }
    else
    {
      v8 = "RakNet"; /*0x1067072d9*/
      v9 = 6; /*0x1067072e0*/
    }
    RBX::Analytics::InfluxDb::Points::addPoint(a1: v528, a2: "connectionType", a3: v8, a4: v9); /*0x106707301*/
    v479 = *(_QWORD *)&v488 >> 8; /*0x10670730d*/
    if ( (v489 & 1) != 0 ) /*0x10670731b*/
    {
      v11 = v518; /*0x106707326*/
      v12 = *((double *)v518 + 1951); /*0x10670732d*/
      v515.f64[0] = v488; /*0x106707335*/
      *(float *)&v12 = (v12 - v488) * 1000.0; /*0x106707349*/
      *((_DWORD *)v518 + 3906) = LODWORD(v12); /*0x10670734d*/
      RBX::Time::nowFast(this: v10); /*0x106707355*/
      *(float *)&v13 = (v13 - v515.f64[0]) * 1000.0; /*0x10670736a*/
      *((_DWORD *)v11 + 3907) = LODWORD(v13); /*0x10670736e*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670738f*/
        this: (RBX::Analytics::InfluxDb::Points *)v528,
        a2: "deltaTimeBetweenJoinRequestAndFirstBlobArrivalInMs",
        a3: *((float *)v11 + 3906));
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067073ad*/
        this: (RBX::Analytics::InfluxDb::Points *)v528,
        a2: "deltaTimeBetweenJoinRequestAndJoinProcessingCompleteInMs",
        a3: *((float *)v11 + 3907));
      goto LABEL_25; /*0x1067073b2*/
    }
  }
  else
  {
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670722c*/
      this: (RBX::Analytics::InfluxDb::Points *)v528,
      a2: "totalRxBytes",
      a3: v496[0]);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x106707245*/
      this: (RBX::Analytics::InfluxDb::Points *)v528,
      a2: "totalRxPackets",
      a3: v496[1]);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670725e*/
      this: (RBX::Analytics::InfluxDb::Points *)v528,
      a2: "totalRxIgnoredBytes",
      a3: v496[2]);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x106707277*/
      this: (RBX::Analytics::InfluxDb::Points *)v528,
      a2: "totalRxIgnoredPackets",
      a3: v496[3]);
    v489 = 0; /*0x10670727c*/
    v493 = 0; /*0x106707287*/
    v492 = 0; /*0x106707292*/
    v491 = 0; /*0x10670729d*/
    v490 = 0; /*0x1067072a8*/
    v494 = nullptr; /*0x1067072b3*/
    v488 = 0.0; /*0x1067072be*/
    v479 = 0; /*0x1067072c9*/
  }
  v11 = v518; /*0x1067073b4*/
LABEL_25:
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067073bb*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "initialClusterDeserializationTimeMs",
    a3: *((double *)v11 + 1988));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067073f6*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "initialClusterProcessTimeMs",
    a3: *((float *)v518 + 3912));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106707418*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "totalDeserializationTimeMs",
    a3: *((double *)v518 + 1987));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670743a*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "packetProcessTimeCppMs",
    a3: *((double *)v518 + 1983));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670745c*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "packetProcessTimeScriptContextMs",
    a3: *((double *)v518 + 1984));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106707486*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "totalPacketProcessTimeMs",
    a3: *((double *)v518 + 1983) + *((double *)v518 + 1984));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067074a8*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "connectionAcceptedToGameLoadTimeMs",
    a3: *((double *)v518 + 1990));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067074ca*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "connectionAcceptedToFirstPacketProcessMs",
    a3: *((double *)v518 + 1991));
  v14 = *((_DWORD *)v518 + 3963) + (*((_BYTE *)v518 + 15729) & 1); /*0x1067074e2*/
  if ( v14 <= 0 ) /*0x1067074ea*/
    v15 = 0.0; /*0x106707504*/
  else
    v15 = (double)*((int *)v518 + 3964) / (double)v14; /*0x1067074fe*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106707515*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "avgJdiV2ProcessedPerFrame",
    a3: v15);
  v16 = v518; /*0x10670751a*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106707536*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "numJdiV2Processed",
    a3: *((_DWORD *)v518 + 3964));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670754b*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "numFramesWithJdiProcessing",
    a3: v14);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106707567*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "longestSingleFrameCppPartJdiV2",
    a3: *((double *)v16 + 1985));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106707583*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "longestSingleFrameScriptPartJdiV2",
    a3: *((double *)v16 + 1986));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670759e*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "streamingEnabled",
    a3: *((_BYTE *)v16 + 15544));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067075b8*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "deserializeReportGroup",
    a3: *((_DWORD *)v16 + 3946));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067075d2*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "processingReportGroup",
    a3: *((_DWORD *)v16 + 3947));
  v17 = *((_DWORD *)v16 + 3925); /*0x1067075d7*/
  if ( v17 != 0 ) /*0x1067075e0*/
    v18 = (float)((float)((float)(v17 - *((_DWORD *)v16 + 3924)) * 100.0) / (float)v17); /*0x106707607*/
  else
    v18 = 0.0; /*0x10670760d*/
  v498 = v18; /*0x106707611*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670762e*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "jdiv2TotalUncompressSharedStringSize",
    a3: *((_DWORD *)v16 + 3917));
  v19 = *((_DWORD *)v16 + 3917); /*0x106707633*/
  if ( v19 != 0 ) /*0x10670763c*/
  {
    v506 = (float)((float)*((int *)v16 + 3916) * 100.0) / (float)v19; /*0x106707663*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x106707680*/
      this: (RBX::Analytics::InfluxDb::Points *)v528,
      a2: "jdiv2SharedStringEffCompressionRatio",
      a3: v506);
  }
  else
  {
    v506 = 0.0; /*0x10670768a*/
  }
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067076a7*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "jdiv2TotalSharedStringCountInBlob",
    a3: *((_DWORD *)v16 + 3918));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067076c1*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "jdiv2TotalInstanceCountInBlob",
    a3: *((_DWORD *)v16 + 3925));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067076db*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "jdiv2TotalInvalidInstanceCountInBlob",
    a3: *((_DWORD *)v16 + 3924));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067076fa*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "jdiv2SharedStringDeserializationMs",
    a3: *((float *)v16 + 3909));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106707719*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "jdiv2InstanceDeserializationMs",
    a3: *((float *)v16 + 3910));
  BatchNetAssetJoinEnabled = RBX::Network::Replicator::getBatchNetAssetJoinEnabled(this: v16, a2: v20); /*0x106707721*/
  v503 = 0.0; /*0x106707729*/
  if ( BatchNetAssetJoinEnabled != 0 ) /*0x106707733*/
  {
    v22 = (unsigned int *)v518; /*0x106707739*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x106707759*/
      this: (RBX::Analytics::InfluxDb::Points *)v528,
      a2: "jdiv2BatchNetAssetDeserializationMs",
      a3: *((float *)v518 + 3922));
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x106707772*/
      this: (RBX::Analytics::InfluxDb::Points *)v528,
      a2: "jdiv2TotalBatchNetAssetCount",
      a3: v22[3921]);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670778b*/
      this: (RBX::Analytics::InfluxDb::Points *)v528,
      a2: "jdiv2TotalBatchNetAssetBytesRx",
      a3: v22[3919]);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067077a4*/
      this: (RBX::Analytics::InfluxDb::Points *)v528,
      a2: "jdiv2TotalBatchNetAssetBytesUncompressed",
      a3: v22[3920]);
    v23 = v22[3920]; /*0x1067077a9*/
    if ( v23 != 0 ) /*0x1067077b1*/
    {
      v503 = (float)((float)(int)v22[3919] * 100.0) / (float)v23; /*0x1067077d4*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067077f1*/
        this: (RBX::Analytics::InfluxDb::Points *)v528,
        a2: "jdiv2BatchNetAssetEffCompressionRatio",
        a3: v503);
    }
  }
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670780b*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "NumInlineNetAssets",
    a3: v483[0]);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106707825*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "NumTotalNetAsset",
    a3: v485[0]);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670783f*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "InlineNetAssetBytes",
    a3: v484[0]);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106707859*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "TotalNetAssetBytes",
    a3: v486[0]);
  v24 = v508; /*0x106707866*/
  if ( v505 != 0 ) /*0x10670786c*/
  {
    v24 = v508; /*0x106707886*/
    v25 = (float)((float)((float)(int)v508 * 100.0) / (float)(int)v505); /*0x106707898*/
  }
  else
  {
    v25 = 0.0; /*0x10670789e*/
  }
  v487 = v25; /*0x1067078a1*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067078b7*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "NetAssetCompressedBytes",
    a3: v24);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067078d0*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "NetAssetUncompressedBytes",
    a3: v505);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067078eb*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "NetAssetEffCompressionRatio",
    a3: v487);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106707904*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "NetAssetEstimatedRaw",
    a3: v501);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670791d*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "NetAssetEstimatedOptimized",
    a3: v502);
  v26 = *((_DWORD *)v518 + 3913); /*0x106707929*/
  v27 = 0; /*0x106707930*/
  v480 = 0; /*0x106707933*/
  if ( v26 != 0 ) /*0x10670793c*/
  {
    v28 = 0; /*0x10670794b*/
    v28.f32[0] = (float)v26; /*0x10670794e*/
    inserted = _mm_insert_epi32( /*0x106707978*/
                 _mm_insert_epi32(
                   _mm_insert_epi32(
                     _mm_cvtsi32_si128(v26 - (*((_DWORD *)v518 + 3923)
                                            + *((_DWORD *)v518 + 3916)
                                            + *((_DWORD *)v518 + 3915))),
                     *((_DWORD *)v518 + 3923),
                     1),
                   *((_DWORD *)v518 + 3915),
                   2),
                 *((_DWORD *)v518 + 3916),
                 3);
    v30 = _mm_div_ps( /*0x1067079b0*/
            _mm_mul_ps(
              _mm_add_ps(
                _mm_sub_ps(
                  (__m128)_mm_blend_epi16(_mm_srli_epi32(inserted, 0x10u), (__m128i)xmmword_10A4496F0, 170),
                  (__m128)xmmword_10A449700),
                (__m128)_mm_blend_epi16(_mm_load_si128((const __m128i *)&xmmword_10A4496E0), inserted, 85)),
              (__m128)xmmword_1099FD050),
            _mm_shuffle_ps(v28, v28, 0));
    v482 = (__m128)_mm_cvtps_pd(v30); /*0x1067079b6*/
    v27 = _mm_cvtps_pd(_mm_movehl_ps(v30, v30)); /*0x1067079c0*/
  }
  else
  {
    v482 = 0; /*0x1067079c5*/
  }
  v481 = (__m128)v27; /*0x1067079cc*/
  v31 = (__m128)*((unsigned int *)v518 + 3908); /*0x1067079d3*/
  if ( v31.f32[0] > 0.0 ) /*0x1067079e2*/
    v480 = (__m128)_mm_cvtps_pd( /*0x106707a04*/
                     _mm_div_ps(
                       _mm_mul_ps((__m128)*(unsigned __int64 *)((char *)v518 + 15636), (__m128)xmmword_108F52AA0),
                       _mm_moveldup_ps(v31)));
  v474 = _mm_movehl_ps(v481, v481); /*0x106707a23*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106707a2a*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "percentageBlobBytesSharedStrings",
    a3: *(double *)v474.i64);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106707a44*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "percentageBlobBytesMeta",
    a3: *(double *)v481.i64);
  v475 = _mm_movehl_ps(v482, v482); /*0x106707a61*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106707a68*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "percentageBlobBytesWaste",
    a3: *(double *)v475.i64);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106707a82*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "percentageBlobBytesInstance",
    a3: *(double *)v482.i64);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106707a9d*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "percentageUsefulInstancesCount",
    a3: v498);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106707ab7*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "percentageReadTimeForSS",
    a3: *(double *)v480.i64);
  v476 = _mm_movehl_ps(v480, v480); /*0x106707ad4*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106707adb*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "percentageReadTimeForMetaInstances",
    a3: *(double *)v476.i64);
  RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::WriterT( /*0x106707ae9*/
    a1: v477,
    a2: 0);
  RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::startObject(a1: v477); /*0x106707af5*/
  if ( *((_DWORD *)v518 + 4028) == 0 ) /*0x106707b08*/
    goto LABEL_87; /*0x106707b08*/
  v32 = *((unsigned int **)v518 + 2013); /*0x106707b22*/
  if ( *((_DWORD *)v518 + 4030) != 0 ) /*0x106707b28*/
  {
    v33 = 16LL * *((unsigned int *)v518 + 4030); /*0x106707b2f*/
    v32 = *((unsigned int **)v518 + 2013); /*0x106707b32*/
    while ( (*(_QWORD *)v32 | 0x1000LL) == 0xFFFFFFFFFFFFF000LL ) /*0x106707b42*/
    {
      v32 += 4; /*0x106707b44*/
      v33 -= 16; /*0x106707b48*/
      if ( v33 == 0 ) /*0x106707b4c*/
        goto LABEL_87; /*0x106707b4c*/
    }
  }
  v34 = 16LL * *((unsigned int *)v518 + 4030) + *((_QWORD *)v518 + 2013); /*0x106707b53*/
  if ( v32 == (unsigned int *)v34 ) /*0x106707b59*/
  {
LABEL_87:
    LODWORD(v515.f64[0]) = 0; /*0x106707d44*/
  }
  else
  {
    do /*0x106707d3c*/
    {
      v35 = RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::size(a1: v477); /*0x106707b66*/
      LOBYTE(v35) = v35 > DFInt::JoinInstanceTypeBreakdownJsonSizeLimit; /*0x106707b75*/
      LODWORD(v515.f64[0]) = v35; /*0x106707b78*/
      if ( (_BYTE)v35 ) /*0x106707b7e*/
        break; /*0x106707b7e*/
      v36 = *(unsigned __int8 **)(*(_QWORD *)v32 + 8LL); /*0x106707b87*/
      v37 = *v36; /*0x106707b8b*/
      if ( (v37 & 1) != 0 ) /*0x106707b94*/
        v38 = *((_QWORD *)v36 + 1); /*0x106707b96*/
      else
        v38 = v37 >> 1; /*0x106707b9c*/
      std::string::basic_string[abi:ne200100](a1: &__dst, a2: v38 + 6); /*0x106707bb2*/
      v39 = (RBX::Memory *)((char *)&__dst + 1); /*0x106707bbe*/
      if ( (__dst & 1) != 0 ) /*0x106707bc5*/
        v39 = v520; /*0x106707bc7*/
      if ( v38 != 0 ) /*0x106707bd1*/
      {
        if ( (*v36 & 1) != 0 ) /*0x106707bd8*/
          v40 = *((const void **)v36 + 2); /*0x106707bda*/
        else
          v40 = v36 + 1; /*0x106707be0*/
        memmove(__dst: v39, __src: v40, __len: v38); /*0x106707bec*/
      }
      strcpy((char *)v39 + v38, "_count"); /*0x106707bf9*/
      if ( (__dst & 1) != 0 ) /*0x106707c11*/
      {
        v41 = v520; /*0x106707c13*/
        v42 = *((_QWORD *)&__dst + 1); /*0x106707c1a*/
      }
      else
      {
        v42 = (unsigned __int8)__dst >> 1; /*0x106707c23*/
        v41 = (RBX::Memory *)((char *)&__dst + 1); /*0x106707c25*/
      }
      RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::int64Key( /*0x106707c36*/
        a1: v477,
        a2: v41,
        a3: v42,
        a4: v32[2]);
      if ( (__dst & 1) != 0 ) /*0x106707c42*/
        operator delete(a1: v520, a2: v43); /*0x106707c4b*/
      v44 = *(unsigned __int8 **)(*(_QWORD *)v32 + 8LL); /*0x106707c53*/
      v45 = *v44; /*0x106707c57*/
      if ( (v45 & 1) != 0 ) /*0x106707c60*/
        v46 = *((_QWORD *)v44 + 1); /*0x106707c62*/
      else
        v46 = v45 >> 1; /*0x106707c68*/
      std::string::basic_string[abi:ne200100](a1: &__dst, a2: v46 + 6); /*0x106707c7e*/
      v47 = (RBX::Memory *)((char *)&__dst + 1); /*0x106707c8a*/
      if ( (__dst & 1) != 0 ) /*0x106707c91*/
        v47 = v520; /*0x106707c93*/
      if ( v46 != 0 ) /*0x106707c9d*/
      {
        if ( (*v44 & 1) != 0 ) /*0x106707ca4*/
          v48 = *((const void **)v44 + 2); /*0x106707ca6*/
        else
          v48 = v44 + 1; /*0x106707cac*/
        memmove(__dst: v47, __src: v48, __len: v46); /*0x106707cb8*/
      }
      strcpy((char *)v47 + v46, "_bytes"); /*0x106707cc5*/
      if ( (__dst & 1) != 0 ) /*0x106707cdd*/
      {
        v49 = v520; /*0x106707cdf*/
        v50 = *((_QWORD *)&__dst + 1); /*0x106707ce6*/
      }
      else
      {
        v50 = (unsigned __int8)__dst >> 1; /*0x106707cef*/
        v49 = (RBX::Memory *)((char *)&__dst + 1); /*0x106707cf1*/
      }
      RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::int64Key( /*0x106707d08*/
        a1: v477,
        a2: v49,
        a3: v50,
        a4: v32[3]);
      if ( (__dst & 1) != 0 ) /*0x106707d14*/
        operator delete(a1: v520, a2: v51); /*0x106707d1d*/
      do /*0x106707d37*/
        v32 += 4; /*0x106707d22*/
      while ( v32 != (unsigned int *)v34 && (*(_QWORD *)v32 | 0x1000LL) == 0xFFFFFFFFFFFFF000LL ); /*0x106707d37*/
    }
    while ( v32 != (unsigned int *)v34 ); /*0x106707d3c*/
  }
  RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::endObject(a1: v477); /*0x106707d55*/
  v52 = DFLog::JoinInstanceTypeBreakdown; /*0x106707d5a*/
  if ( (unsigned __int8)DFLog::JoinInstanceTypeBreakdown >= 6u && BYTE1(DFLog::JoinInstanceTypeBreakdown) >= 3u )
  {
    v53 = qword_10D809B08; /*0x106707d75*/
    RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::str( /*0x106707d8a*/
      a1: &__dst,
      a2: v477);
    if ( (__dst & 1) != 0 ) /*0x106707d96*/
      LODWORD(v56) = (_DWORD)v520; /*0x106707d98*/
    else
      v56 = (char *)&__dst + 1; /*0x106707da1*/
    FLog::FastLogFormatted(
      a1: v52,
      a2: v53,
      a3: (unsigned int)"[DFLog::JoinInstanceTypeBreakdown] Join Blob Breakdown: %s",
      a4: (_DWORD)v56,
      a5: v54,
      a6: v55);
    if ( (__dst & 1) != 0 ) /*0x106707dc3*/
      operator delete(a1: v520, a2: v57); /*0x106707dcc*/
  }
  RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::str( /*0x106707ddf*/
    a1: &__dst,
    a2: v477);
  RBX::Analytics::InfluxDb::Points::addPoint(a1: v528, a2: "joinBlobInstanceTypeBreakdown", a3: &__dst); /*0x106707df9*/
  if ( (__dst & 1) != 0 ) /*0x106707e05*/
    operator delete(a1: v520, a2: v58); /*0x106707e0e*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106707e28*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "joinBlobBreakdownTruncated",
    a3: SLOBYTE(v515.f64[0]));
  RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::WriterT( /*0x106707e36*/
    a1: v478,
    a2: 0);
  RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::startObject(a1: v478); /*0x106707e42*/
  if ( *((_DWORD *)v518 + 4034) == 0 ) /*0x106707e55*/
    goto LABEL_138; /*0x106707e55*/
  v59 = *((unsigned int **)v518 + 2016); /*0x106707e6f*/
  if ( *((_DWORD *)v518 + 4036) != 0 ) /*0x106707e75*/
  {
    v60 = 16LL * *((unsigned int *)v518 + 4036); /*0x106707e7c*/
    v59 = *((unsigned int **)v518 + 2016); /*0x106707e7f*/
    while ( (*(_QWORD *)v59 | 0x1000LL) == 0xFFFFFFFFFFFFF000LL ) /*0x106707e8f*/
    {
      v59 += 4; /*0x106707e91*/
      v60 -= 16; /*0x106707e95*/
      if ( v60 == 0 ) /*0x106707e99*/
        goto LABEL_138; /*0x106707e99*/
    }
  }
  v61 = 16LL * *((unsigned int *)v518 + 4036) + *((_QWORD *)v518 + 2016); /*0x106707ea0*/
  if ( v59 == (unsigned int *)v61 ) /*0x106707ea6*/
  {
LABEL_138:
    LODWORD(v515.f64[0]) = 0; /*0x106708091*/
  }
  else
  {
    do /*0x106708089*/
    {
      v62 = RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::size(a1: v478); /*0x106707eb3*/
      LOBYTE(v62) = v62 > DFInt::JoinInstanceTypeBreakdownJsonSizeLimit; /*0x106707ec2*/
      LODWORD(v515.f64[0]) = v62; /*0x106707ec5*/
      if ( (_BYTE)v62 ) /*0x106707ecb*/
        break; /*0x106707ecb*/
      v63 = *(unsigned __int8 **)(*(_QWORD *)v59 + 8LL); /*0x106707ed4*/
      v64 = *v63; /*0x106707ed8*/
      if ( (v64 & 1) != 0 ) /*0x106707ee1*/
        v65 = *((_QWORD *)v63 + 1); /*0x106707ee3*/
      else
        v65 = v64 >> 1; /*0x106707ee9*/
      std::string::basic_string[abi:ne200100](a1: &__dst, a2: v65 + 6); /*0x106707eff*/
      v66 = (RBX::Memory *)((char *)&__dst + 1); /*0x106707f0b*/
      if ( (__dst & 1) != 0 ) /*0x106707f12*/
        v66 = v520; /*0x106707f14*/
      if ( v65 != 0 ) /*0x106707f1e*/
      {
        if ( (*v63 & 1) != 0 ) /*0x106707f25*/
          v67 = *((const void **)v63 + 2); /*0x106707f27*/
        else
          v67 = v63 + 1; /*0x106707f2d*/
        memmove(__dst: v66, __src: v67, __len: v65); /*0x106707f39*/
      }
      strcpy((char *)v66 + v65, "_count"); /*0x106707f46*/
      if ( (__dst & 1) != 0 ) /*0x106707f5e*/
      {
        v68 = v520; /*0x106707f60*/
        v69 = *((_QWORD *)&__dst + 1); /*0x106707f67*/
      }
      else
      {
        v69 = (unsigned __int8)__dst >> 1; /*0x106707f70*/
        v68 = (RBX::Memory *)((char *)&__dst + 1); /*0x106707f72*/
      }
      RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::int64Key( /*0x106707f83*/
        a1: v478,
        a2: v68,
        a3: v69,
        a4: v59[2]);
      if ( (__dst & 1) != 0 ) /*0x106707f8f*/
        operator delete(a1: v520, a2: v70); /*0x106707f98*/
      v71 = *(unsigned __int8 **)(*(_QWORD *)v59 + 8LL); /*0x106707fa0*/
      v72 = *v71; /*0x106707fa4*/
      if ( (v72 & 1) != 0 ) /*0x106707fad*/
        v73 = *((_QWORD *)v71 + 1); /*0x106707faf*/
      else
        v73 = v72 >> 1; /*0x106707fb5*/
      std::string::basic_string[abi:ne200100](a1: &__dst, a2: v73 + 6); /*0x106707fcb*/
      v74 = (RBX::Memory *)((char *)&__dst + 1); /*0x106707fd7*/
      if ( (__dst & 1) != 0 ) /*0x106707fde*/
        v74 = v520; /*0x106707fe0*/
      if ( v73 != 0 ) /*0x106707fea*/
      {
        if ( (*v71 & 1) != 0 ) /*0x106707ff1*/
          v75 = *((const void **)v71 + 2); /*0x106707ff3*/
        else
          v75 = v71 + 1; /*0x106707ff9*/
        memmove(__dst: v74, __src: v75, __len: v73); /*0x106708005*/
      }
      strcpy((char *)v74 + v73, "_bytes"); /*0x106708012*/
      if ( (__dst & 1) != 0 ) /*0x10670802a*/
      {
        v76 = v520; /*0x10670802c*/
        v77 = *((_QWORD *)&__dst + 1); /*0x106708033*/
      }
      else
      {
        v77 = (unsigned __int8)__dst >> 1; /*0x10670803c*/
        v76 = (RBX::Memory *)((char *)&__dst + 1); /*0x10670803e*/
      }
      RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::int64Key( /*0x106708055*/
        a1: v478,
        a2: v76,
        a3: v77,
        a4: v59[3]);
      if ( (__dst & 1) != 0 ) /*0x106708061*/
        operator delete(a1: v520, a2: v78); /*0x10670806a*/
      do /*0x106708084*/
        v59 += 4; /*0x10670806f*/
      while ( v59 != (unsigned int *)v61 && (*(_QWORD *)v59 | 0x1000LL) == 0xFFFFFFFFFFFFF000LL ); /*0x106708084*/
    }
    while ( v59 != (unsigned int *)v61 ); /*0x106708089*/
  }
  RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::endObject(a1: v478); /*0x1067080a2*/
  v79 = DFLog::JoinInstanceTypeBreakdown; /*0x1067080a7*/
  if ( (unsigned __int8)DFLog::JoinInstanceTypeBreakdown >= 6u && BYTE1(DFLog::JoinInstanceTypeBreakdown) >= 3u )
  {
    v80 = qword_10D809B08; /*0x1067080c2*/
    RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::str( /*0x1067080d7*/
      a1: &__dst,
      a2: v478);
    if ( (__dst & 1) != 0 ) /*0x1067080e3*/
      LODWORD(v83) = (_DWORD)v520; /*0x1067080e5*/
    else
      v83 = (char *)&__dst + 1; /*0x1067080ee*/
    FLog::FastLogFormatted(
      a1: v79,
      a2: v80,
      a3: (unsigned int)"[DFLog::JoinInstanceTypeBreakdown] Replicated First Breakdown: %s",
      a4: (_DWORD)v83,
      a5: v81,
      a6: v82);
    if ( (__dst & 1) != 0 ) /*0x106708110*/
      operator delete(a1: v520, a2: v84); /*0x106708119*/
  }
  RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::str( /*0x10670812c*/
    a1: &__dst,
    a2: v478);
  RBX::Analytics::InfluxDb::Points::addPoint(a1: v528, a2: "replicatedFirstInstanceTypeBreakdown", a3: &__dst); /*0x106708146*/
  if ( (__dst & 1) != 0 ) /*0x106708152*/
    operator delete(a1: v520, a2: v85); /*0x10670815b*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106708175*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "replicatedFirstBreakdownTruncated",
    a3: SLOBYTE(v515.f64[0]));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106708195*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "jdiv2TotalInstanceBytesRxInJoin",
    a3: *((_DWORD *)v518 + 3926));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067081b5*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "totalInstanceBytesRxInReplicatedFirst",
    a3: *((_DWORD *)v518 + 3928));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067081d5*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "totalInstancesInReplicatedFirst",
    a3: *((_DWORD *)v518 + 3927));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067081f5*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "terrainCompressedBytes",
    a3: *((_DWORD *)v518 + 3929));
  if ( (unsigned __int8)RBX::Analytics::InfluxDb::canSend(
                          this: (RBX::Analytics::InfluxDb *)(unsigned int)DFInt::ReportTopReplicationContainerAndAvatarStatsHundredths,
                          a2: v86) != 0 )
  {
    RBX::Analytics::InfluxDb::Points::Points(a1: &__dst, a2: 0xFFFFFFFFLL, a3: 0, a4: 0); /*0x106708220*/
    RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::WriterT( /*0x10670822e*/
      a1: v510,
      a2: 0);
    RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::startArray(a1: v510); /*0x10670823a*/
    v89 = *((double *)v518 + 2021); /*0x106708246*/
    if ( v89 == 0.0 ) /*0x106708250*/
    {
      LODWORD(v497.f64[0]) = 0; /*0x106708682*/
      v90 = 0; /*0x10670868c*/
    }
    else
    {
      *(_QWORD *)&v495.f64[0] = (char *)v518 + 16104; /*0x10670825c*/
      v90 = 0; /*0x106708263*/
      LODWORD(v497.f64[0]) = 0; /*0x106708273*/
      do /*0x10670867a*/
      {
        if ( (LOBYTE(v497.f64[0]) & 1) != 0 ) /*0x106708284*/
          break; /*0x106708284*/
        RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::startObject(a1: v510); /*0x106708291*/
        v91 = *(unsigned __int8 *)(*(_QWORD *)&v89 + 16LL); /*0x106708296*/
        v92 = *(_QWORD *)&v89 + 17LL; /*0x10670829c*/
        __src = (void *)(*(_QWORD *)&v89 + 17LL); /*0x1067082a5*/
        if ( (v91 & 1) != 0 ) /*0x1067082ac*/
        {
          v92 = *(_QWORD *)(*(_QWORD *)&v89 + 32LL); /*0x1067082ae*/
          v93 = *(_QWORD *)(*(_QWORD *)&v89 + 24LL); /*0x1067082b3*/
        }
        else
        {
          v93 = v91 >> 1; /*0x1067082ba*/
        }
        RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::stringKey( /*0x1067082d0*/
          a1: v510,
          a2: "container",
          a3: 9,
          a4: v92,
          a5: v93);
        RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::WriterT( /*0x1067082da*/
          a1: &v499,
          a2: 0);
        RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::startObject(a1: &v499); /*0x1067082e2*/
        v94 = 0; /*0x1067082e7*/
        v95 = *(_DWORD *)(*(_QWORD *)&v89 + 48LL) == 0; /*0x1067082e9*/
        v504[0] = 0.0; /*0x1067082f2*/
        v515.f64[0] = v89; /*0x1067082fa*/
        if ( !v95 ) /*0x106708301*/
        {
          v509[0] = v90; /*0x106708307*/
          v96 = *(unsigned int **)(*(_QWORD *)&v89 + 40LL); /*0x10670831f*/
          if ( *(_DWORD *)(*(_QWORD *)&v89 + 56LL) != 0 ) /*0x106708325*/
          {
            v97 = 16LL * *(unsigned int *)(*(_QWORD *)&v89 + 56LL); /*0x106708327*/
            v96 = *(unsigned int **)(*(_QWORD *)&v89 + 40LL); /*0x10670832a*/
            while ( (*(_QWORD *)v96 | 0x1000LL) == 0xFFFFFFFFFFFFF000LL ) /*0x10670833b*/
            {
              v96 += 4; /*0x10670833d*/
              v97 -= 16; /*0x106708341*/
              if ( v97 == 0 ) /*0x106708345*/
                goto LABEL_174; /*0x106708345*/
            }
          }
          v98 = 16LL * *(unsigned int *)(*(_QWORD *)&v89 + 56LL) + *(_QWORD *)(*(_QWORD *)&v89 + 40LL); /*0x10670834c*/
          if ( v96 != (unsigned int *)v98 ) /*0x106708352*/
          {
            LODWORD(v504[0]) = 0; /*0x10670835b*/
            v94 = 0; /*0x106708363*/
            while ( 1 ) /*0x106708371*/
            {
              v99 = RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::size(a1: v510); /*0x106708371*/
              v100 = v99 /*0x106708380*/
                   + RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::size(a1: &v499);
              if ( v100 > DFInt::TopReplicationContainerAndAvatarBreakdownJsonSizeLimit ) /*0x10670838d*/
                break; /*0x10670838d*/
              v101 = *(unsigned __int8 **)(*(_QWORD *)v96 + 8LL); /*0x106708397*/
              v102 = *v101; /*0x10670839b*/
              if ( (v102 & 1) != 0 ) /*0x1067083a1*/
              {
                v103 = *((_QWORD *)v101 + 1); /*0x1067083a3*/
                v104 = *((unsigned __int8 **)v101 + 2); /*0x1067083a7*/
              }
              else
              {
                v104 = v101 + 1; /*0x1067083ad*/
                v103 = v102 >> 1; /*0x1067083b0*/
              }
              RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::int64Key( /*0x1067083bd*/
                a1: &v499,
                a2: v104,
                a3: v103,
                a4: v96[2]);
              v94 += v96[2]; /*0x1067083c2*/
              v105 = RBX::DenseMapBase<RBX::DenseMap<RBX::Reflection::ClassDescriptor const*,RBX::Network::JoinRxStats::ClassSizeAndCount,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const*,void>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const*,RBX::Network::JoinRxStats::ClassSizeAndCount>>,RBX::Reflection::ClassDescriptor const*,RBX::Network::JoinRxStats::ClassSizeAndCount,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const*,void>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const*,RBX::Network::JoinRxStats::ClassSizeAndCount>>::FindAndConstruct( /*0x1067083d0*/
                       a1: *(__int64 *)&v495.f64[0],
                       a2: v96);
              v106 = *((_DWORD *)v105 + 2); /*0x1067083d5*/
              if ( v106 != 0 ) /*0x1067083da*/
                *(float *)v504 = *(float *)v504 /*0x106708407*/
                               + (float)((float)(int)v96[2] * (float)(int)(*((_DWORD *)v105 + 3) / v106));
              do /*0x106708425*/
                v96 += 4; /*0x10670840f*/
              while ( v96 != (unsigned int *)v98 && (*(_QWORD *)v96 | 0x1000LL) == 0xFFFFFFFFFFFFF000LL ); /*0x106708425*/
              if ( v96 == (unsigned int *)v98 ) /*0x10670842a*/
                goto LABEL_173; /*0x10670842a*/
            }
            LOBYTE(v100) = 1; /*0x106708432*/
            LODWORD(v497.f64[0]) = v100; /*0x106708434*/
LABEL_173:
            v504[0] = *(float *)v504; /*0x10670843a*/
          }
LABEL_174:
          v90 = v509[0]; /*0x10670844d*/
          v89 = v515.f64[0]; /*0x106708454*/
        }
        RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::endObject(a1: &v499); /*0x106708465*/
        RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::int64Key( /*0x106708480*/
          a1: v510,
          a2: "numInstances",
          a3: 12,
          a4: v94);
        RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::writerKey( /*0x10670849b*/
          a1: v510,
          a2: "instances",
          a3: 9,
          a4: &v499);
        RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::endObject(a1: v510); /*0x1067084a7*/
        v107 = *(unsigned __int8 *)(*(_QWORD *)&v89 + 16LL); /*0x1067084ac*/
        if ( (v107 & 1) != 0 ) /*0x1067084b6*/
          v108 = *(_QWORD *)(*(_QWORD *)&v89 + 24LL); /*0x1067084b8*/
        else
          v108 = v107 >> 1; /*0x1067084bf*/
        std::string::basic_string[abi:ne200100](a1: v513, a2: v108 + 14); /*0x1067084d4*/
        v109 = (char *)v513 + 1; /*0x1067084e0*/
        if ( (v513[0] & 1) != 0 ) /*0x1067084e7*/
          v109 = v514; /*0x1067084e9*/
        if ( v108 != 0 ) /*0x1067084f3*/
        {
          v110 = __src; /*0x106708500*/
          if ( (*(_BYTE *)(*(_QWORD *)&v515.f64[0] + 16LL) & 1) != 0 ) /*0x106708507*/
            v110 = *(void **)(*(_QWORD *)&v515.f64[0] + 32LL); /*0x106708510*/
          memmove(__dst: v109, __src: v110, __len: v108); /*0x10670851a*/
        }
        strcpy(&v109[v108], "_num_instances"); /*0x106708538*/
        v111 = (char *)v513 + 1; /*0x106708549*/
        if ( (v513[0] & 1) != 0 ) /*0x106708550*/
          v111 = v514; /*0x106708552*/
        RBX::Analytics::InfluxDb::Points::addPoint(this: (RBX::Analytics::InfluxDb::Points *)&__dst, a2: v111, a3: v94); /*0x106708562*/
        v113 = v515.f64[0]; /*0x106708567*/
        if ( (v513[0] & 1) != 0 ) /*0x106708575*/
          operator delete(a1: (RBX::Memory *)v514, a2: v112); /*0x10670857e*/
        v114 = *(unsigned __int8 *)(*(_QWORD *)&v113 + 16LL); /*0x106708583*/
        if ( (v114 & 1) != 0 ) /*0x10670858d*/
          v115 = *(_QWORD *)(*(_QWORD *)&v113 + 24LL); /*0x10670858f*/
        else
          v115 = v114 >> 1; /*0x106708596*/
        std::string::basic_string[abi:ne200100](a1: v513, a2: v115 + 12); /*0x1067085ab*/
        v116 = (char *)v513 + 1; /*0x1067085b7*/
        if ( (v513[0] & 1) != 0 ) /*0x1067085be*/
          v116 = v514; /*0x1067085c0*/
        if ( v115 != 0 ) /*0x1067085ca*/
        {
          if ( (*(_BYTE *)(*(_QWORD *)&v515.f64[0] + 16LL) & 1) != 0 ) /*0x1067085d7*/
            __src = *(void **)(*(_QWORD *)&v515.f64[0] + 32LL); /*0x1067085e4*/
          memmove(__dst: v116, __src, __len: v115); /*0x1067085f8*/
        }
        strcpy(&v116[v115], "_total_bytes"); /*0x106708607*/
        v117 = (char *)v513 + 1; /*0x106708621*/
        if ( (v513[0] & 1) != 0 ) /*0x106708628*/
          v117 = v514; /*0x10670862a*/
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x106708640*/
          this: (RBX::Analytics::InfluxDb::Points *)&__dst,
          a2: v117,
          a3: v504[0]);
        v119 = v515.f64[0]; /*0x106708645*/
        if ( (v513[0] & 1) != 0 ) /*0x10670865a*/
          operator delete(a1: (RBX::Memory *)v514, a2: v118); /*0x106708663*/
        v90 += v94; /*0x106708668*/
        RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::~WriterT(a1: &v499); /*0x10670866e*/
        v89 = **(double **)&v119; /*0x106708673*/
      }
      while ( v89 != 0.0 ); /*0x10670867a*/
    }
    RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::endArray(a1: v510); /*0x106708696*/
    RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::WriterT( /*0x1067086a4*/
      a1: &v499,
      a2: 0);
    RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::startObject(a1: &v499); /*0x1067086b0*/
    v95 = *((_DWORD *)v518 + 4050) == 0; /*0x1067086bc*/
    v509[0] = v90; /*0x1067086c3*/
    if ( v95 ) /*0x1067086ca*/
      goto LABEL_222; /*0x1067086ca*/
    v120 = *((unsigned int **)v518 + 2024); /*0x1067086e4*/
    if ( *((_DWORD *)v518 + 4052) != 0 ) /*0x1067086ea*/
    {
      v121 = 16LL * *((unsigned int *)v518 + 4052); /*0x1067086f1*/
      v120 = *((unsigned int **)v518 + 2024); /*0x1067086f4*/
      while ( (*(_QWORD *)v120 | 0x1000LL) == 0xFFFFFFFFFFFFF000LL ) /*0x106708705*/
      {
        v120 += 4; /*0x106708707*/
        v121 -= 16; /*0x10670870b*/
        if ( v121 == 0 ) /*0x10670870f*/
          goto LABEL_222; /*0x10670870f*/
      }
    }
    v122 = 16LL * *((unsigned int *)v518 + 4052) + *((_QWORD *)v518 + 2024); /*0x106708716*/
    if ( v120 == (unsigned int *)v122 ) /*0x10670871c*/
    {
LABEL_222:
      v123 = 0; /*0x10670879d*/
      v125 = false; /*0x10670879f*/
    }
    else
    {
      v123 = 0; /*0x10670871e*/
      do /*0x106708799*/
      {
        v124 = RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::size(a1: &v499); /*0x10670872d*/
        v125 = v124 > DFInt::TopReplicationContainerAndAvatarBreakdownJsonSizeLimit; /*0x10670873c*/
        if ( v124 > DFInt::TopReplicationContainerAndAvatarBreakdownJsonSizeLimit ) /*0x106708740*/
          break; /*0x106708740*/
        v126 = *(unsigned __int8 **)(*(_QWORD *)v120 + 8LL); /*0x106708746*/
        v127 = *v126; /*0x10670874a*/
        if ( (v127 & 1) != 0 ) /*0x106708750*/
        {
          v128 = *((_QWORD *)v126 + 1); /*0x106708752*/
          v129 = *((unsigned __int8 **)v126 + 2); /*0x106708756*/
        }
        else
        {
          v129 = v126 + 1; /*0x10670875c*/
          v128 = v127 >> 1; /*0x10670875f*/
        }
        RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::int64Key( /*0x10670876c*/
          a1: &v499,
          a2: v129,
          a3: v128,
          a4: v120[2]);
        for ( i = v120 + 4; i != (unsigned int *)v122 && (*(_QWORD *)i | 0x1000LL) == 0xFFFFFFFFFFFFF000LL; i += 4 ) /*0x106708771*/
          ; /*0x106708789*/
        v123 += v120[2]; /*0x10670878f*/
        v120 = i; /*0x106708793*/
      }
      while ( i != (unsigned int *)v122 ); /*0x106708799*/
    }
    RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::endObject(a1: &v499); /*0x1067087a9*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067087c2*/
      this: (RBX::Analytics::InfluxDb::Points *)&__dst,
      a2: "totalTopReplicationContainerInstances",
      a3: v509[0]);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067087df*/
      this: (RBX::Analytics::InfluxDb::Points *)&__dst,
      a2: "topReplicationContainerInstancesJsonTruncated",
      a3: LOBYTE(v497.f64[0]) & 1);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067087f4*/
      this: (RBX::Analytics::InfluxDb::Points *)&__dst,
      a2: "totalAvatarInstances",
      a3: v123);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670880b*/
      this: (RBX::Analytics::InfluxDb::Points *)&__dst,
      a2: "avatarInstancesJsonTruncated",
      a3: v125);
    RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::str( /*0x10670881e*/
      a1: v513,
      a2: &v499);
    RBX::Analytics::InfluxDb::Points::addPoint(a1: &__dst, a2: "avatarInstances", a3: v513); /*0x106708838*/
    if ( (v513[0] & 1) != 0 ) /*0x106708844*/
      operator delete(a1: (RBX::Memory *)v514, a2: v131); /*0x10670884d*/
    RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::str( /*0x106708860*/
      a1: v513,
      a2: v510);
    RBX::Analytics::InfluxDb::Points::addPoint(a1: &__dst, a2: "topReplicationContainerInstances", a3: v513); /*0x10670887a*/
    if ( (v513[0] & 1) != 0 ) /*0x106708886*/
      operator delete(a1: (RBX::Memory *)v514, a2: v134); /*0x10670888f*/
    if ( DFFlag::ClientNetworkTelemetryRCCChannelName == 1 )
    {
      v133 = SFString::RCCChannelName; /*0x10670889d*/
      v135 = (SFString::RCCChannelName[0] & 1) != 0
           ? *(_QWORD *)&SFString::RCCChannelName[8]
           : SFString::RCCChannelName[0] >> 1;
      if ( v135 != 0 ) /*0x1067088b6*/
        RBX::Analytics::InfluxDb::Points::addPoint(a1: &__dst, a2: "rccChannelName", a3: SFString::RCCChannelName); /*0x1067088cd*/
    }
    std::string::basic_string[abi:ne200100]<0>( /*0x1067088e0*/
      a1: v513,
      a2: "TopReplicationContainerAndAvatarStats",
      a3: v132,
      a4: v133);
    RBX::Analytics::InfluxDb::Points::report( /*0x1067088fe*/
      a1: &__dst,
      a2: v513,
      a3: (unsigned int)DFInt::ReportTopReplicationContainerAndAvatarStatsHundredths,
      a4: 0);
    if ( (v513[0] & 1) != 0 ) /*0x10670890a*/
      operator delete(a1: (RBX::Memory *)v514, a2: v136); /*0x106708913*/
    RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::~WriterT(a1: &v499); /*0x10670891f*/
    RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::~WriterT(a1: v510); /*0x10670892b*/
    RBX::Analytics::InfluxDb::Points::~Points(this: (void **)&__dst); /*0x106708937*/
  }
  if ( DFFlag::ReportSharedStringBreakdown == 1 /*0x106708960*/
    && (unsigned __int8)RBX::Analytics::InfluxDb::canSend(
                          this: (RBX::Analytics::InfluxDb *)*((unsigned int *)v518 + 3945),
                          a2: v88) != 0 )
  {
    RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::WriterT( /*0x10670896f*/
      a1: &__dst,
      a2: 0);
    RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::startObject(a1: &__dst); /*0x10670897b*/
    if ( *((_DWORD *)v518 + 4068) != 0 ) /*0x10670898e*/
    {
      v137 = *((unsigned int **)v518 + 2033); /*0x1067089af*/
      if ( *((_DWORD *)v518 + 4070) != 0 ) /*0x1067089b5*/
      {
        v138 = 16LL * *((unsigned int *)v518 + 4070); /*0x1067089bc*/
        v137 = *((unsigned int **)v518 + 2033); /*0x1067089bf*/
        while ( (*(_QWORD *)v137 | 0x1000LL) == 0xFFFFFFFFFFFFF000LL ) /*0x1067089cf*/
        {
          v137 += 4; /*0x1067089d1*/
          v138 -= 16; /*0x1067089d5*/
          if ( v138 == 0 ) /*0x1067089d9*/
            goto LABEL_252; /*0x1067089d9*/
        }
      }
      v139 = 16LL * *((unsigned int *)v518 + 4070) + *((_QWORD *)v518 + 2033); /*0x1067089dd*/
      while ( v137 != (unsigned int *)v139 ) /*0x1067089e3*/
      {
        v140 = *(unsigned __int8 **)(*(_QWORD *)v137 + 8LL); /*0x1067089f5*/
        v141 = *v140; /*0x1067089f9*/
        if ( (v141 & 1) != 0 ) /*0x1067089ff*/
        {
          v142 = *((_QWORD *)v140 + 1); /*0x106708a01*/
          v143 = *((unsigned __int8 **)v140 + 2); /*0x106708a05*/
        }
        else
        {
          v143 = v140 + 1; /*0x106708a0b*/
          v142 = v141 >> 1; /*0x106708a0e*/
        }
        RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::int64Key( /*0x106708a17*/
          a1: &__dst,
          a2: v143,
          a3: v142,
          a4: v137[2]);
        do /*0x106708a31*/
          v137 += 4; /*0x106708a1c*/
        while ( v137 != (unsigned int *)v139 && (*(_QWORD *)v137 | 0x1000LL) == 0xFFFFFFFFFFFFF000LL ); /*0x106708a31*/
      }
    }
LABEL_252:
    RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::endObject(a1: &__dst); /*0x106708a38*/
    RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::str( /*0x106708a52*/
      a1: v510,
      a2: &__dst);
    RBX::Analytics::InfluxDb::Points::addPoint(a1: v528, a2: "sharedStringBreakdown", a3: v510); /*0x106708a6c*/
    if ( (v510[0] & 1) != 0 ) /*0x106708a78*/
      operator delete(a1: (RBX::Memory *)v511[0], a2: v144); /*0x106708a81*/
    RBX::DenseMapBase<RBX::DenseMap<std::string const*,RBX::detail::DenseSetEmpty,RBX::DenseMapInfo<std::string const*,void>,RBX::detail::DenseSetPair<std::string const*>>,std::string const*,RBX::detail::DenseSetEmpty,RBX::DenseMapInfo<std::string const*,void>,RBX::detail::DenseSetPair<std::string const*>>::clear( /*0x106708a99*/
      a1: (__int64)v518 + 16240,
      a2: 1);
    RBX::DenseMap<RBX::Reflection::ClassDescriptor const*,unsigned int,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const*,void>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const*,unsigned int>>::shrink_and_clear( /*0x106708aac*/
      a1: (__int64)v518 + 16264,
      a2: v145);
    RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::~WriterT(a1: &__dst); /*0x106708ab8*/
  }
  v146 = RBX::TaskScheduler::cycle(this: v87); /*0x106708abd*/
  v147 = v518; /*0x106708ac2*/
  v148 = v146 - *((_QWORD *)v518 + 2986) + 1; /*0x106708ad3*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106708ae7*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "numFramesBetweenConnectionAcceptedAndGameLoadTime",
    a3: v148);
  v149 = _mm_sub_pd((__m128d)_mm_unpacklo_epi32((__m128i)v148, (__m128i)xmmword_108F2F9A0), (__m128d)xmmword_108F2F9B0); /*0x106708af9*/
  v150 = _mm_hadd_pd(v149, v149); /*0x106708b01*/
  v151.f64[0] = *((double *)v147 + 1990); /*0x106708b05*/
  v152 = _mm_cmplt_sd((__m128d)0LL, v151); /*0x106708b11*/
  v472 = v150; /*0x106708b1e*/
  v150.f64[0] = v150.f64[0] / (v151.f64[0] / 1000.0); /*0x106708b26*/
  v473 = _mm_or_pd(_mm_andn_pd(v152, (__m128d)0xBFF0000000000000LL), _mm_and_pd(v150, v152)); /*0x106708b4c*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106708b58*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "averageFpsDuringJoin",
    a3: v473.f64[0]);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106708b72*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "totalJdiv2CountRecvDuringJoin",
    a3: *((_DWORD *)v147 + 3931));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106708b8c*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "totalJdiv2BytesRecvDuringJoin",
    a3: *((_DWORD *)v147 + 3930));
  v499 = 0; /*0x106708b95*/
  v500 = 0; /*0x106708b9d*/
  LODWORD(v148) = *((_DWORD *)v147 + 3899); /*0x106708baf*/
  v153 = *((_DWORD *)v147 + 3988); /*0x106708bb6*/
  v154 = *((_DWORD *)v147 + 4002) - v148; /*0x106708bbd*/
  v155 = *((_DWORD *)v147 + 4003); /*0x106708bbf*/
  v156 = *((_DWORD *)v147 + 3992); /*0x106708bc6*/
  LODWORD(v147) = *((_DWORD *)v147 + 3996); /*0x106708bcd*/
  LODWORD(v495.f64[0]) = v154; /*0x106708be2*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106708be8*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "gameLoadProgressTimeMs.lastSharedStringArrival",
    a3: v154);
  v157 = v155 - v148; /*0x106708bed*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106708c01*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "gameLoadProgressTimeMs.sharedStringDeserializeComplete",
    a3: v157);
  v158 = v153 - v148; /*0x106708c19*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106708c1c*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "gameLoadProgressTimeMs.gameLoadTagArrival",
    a3: v158);
  v159 = v156 - v148; /*0x106708c21*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106708c35*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "gameLoadProgressTimeMs.gameLoadTagDeserialized",
    a3: v159);
  LODWORD(v147) = (_DWORD)v147 - v148; /*0x106708c3a*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106708c4e*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "gameLoadProgressTimeMs.gameLoadTagProcessed",
    a3: (unsigned int)v147);
  v515.f64[0] = (double)(int)v147; /*0x106708c71*/
  *(double *)v509 = (double)SLODWORD(v495.f64[0]) * 100.0 / (double)(int)v147; /*0x106708c8b*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106708c93*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "gameLoadProgressTimePercent.lastSharedStringArrival",
    a3: *(double *)v509);
  v497.f64[0] = (double)v157 * 100.0 / v515.f64[0]; /*0x106708cc1*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106708cc9*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "gameLoadProgressTimePercent.sharedStringDeserializeComplete",
    a3: v497.f64[0]);
  v504[0] = (double)v158; /*0x106708cd9*/
  *(double *)&__src = (double)v158 * 100.0 / v515.f64[0]; /*0x106708cff*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106708d07*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "gameLoadProgressTimePercent.gameLoadTagArrival",
    a3: *(double *)&__src);
  v515.f64[0] = (double)v159 * 100.0 / v515.f64[0]; /*0x106708d35*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106708d3d*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "gameLoadProgressTimePercent.gameLoadTagDeserialize",
    a3: v515.f64[0]);
  std::string::basic_string[abi:ne200100]<0>( /*0x106708d50*/
    a1: &__dst,
    a2: "ReplicatorGameLoadPercentTimeWhenJoinDataCompleteTransfer",
    a3: v160,
    a4: v161);
  v521 = *(double *)&__src; /*0x106708d64*/
  std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x106708d70*/
    a1: &v499,
    a2: &__dst,
    a3: v162,
    a4: v163,
    a5: v164,
    a6: v165);
  if ( (__dst & 1) != 0 ) /*0x106708d7c*/
    operator delete(a1: v520, a2: v166); /*0x106708d85*/
  if ( (unsigned __int8)DFLog::JoinDataRxStats >= 6u && BYTE1(DFLog::JoinDataRxStats) >= 3u ) /*0x106708d9f*/
    FLog::FastLogFormatted( /*0x106708deb*/
      a1: DFLog::JoinDataRxStats,
      a2: (_DWORD)qword_10D809AE0,
      a3: (unsigned int)"[DFLog::JoinDataRxStats] GameLoadProgressTime,lastSSArrive,%u,%f%%,SSDeserialized,%u,%f%%,gameLoadTa"
                    "gArrival,%u,%f%%,gameLoadTagDeserialize,%u,%f%%,gameLoadTagProcess,%u",
      a4: LODWORD(v495.f64[0]),
      a5: v157,
      a6: v158);
  v167 = *((_QWORD *)v518 + 1997); /*0x106708df7*/
  v168 = *((_QWORD *)v518 + 1950); /*0x106708dfe*/
  v169 = *((_QWORD *)v518 + 1993); /*0x106708e05*/
  v170 = *((_QWORD *)v518 + 2000); /*0x106708e16*/
  v171 = *((_QWORD *)v518 + 1995); /*0x106708e1d*/
  __src = (void *)(*((_QWORD *)v518 + 1999) - v168); /*0x106708e32*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106708e39*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "gameLoadProgressCycle.lastSharedStringArrival",
    a3: (unsigned __int64)__src);
  v172 = v170 - v168; /*0x106708e3e*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106708e52*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "gameLoadProgressCycle.lastSharedStringDeserialized",
    a3: v172);
  *(_QWORD *)v509 = v169 - v168; /*0x106708e68*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106708e72*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "gameLoadProgressCycle.gameLoadTagArrival",
    a3: v169 - v168);
  v173 = v171 - v168; /*0x106708e77*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106708e8b*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "gameLoadProgressCycle.gameLoadTagDeserialized",
    a3: v173);
  v174 = v167 - v168; /*0x106708e90*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106708ea4*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "gameLoadProgressCycle.gameLoadTagProcessed",
    a3: v174);
  v175 = (int)__src; /*0x106708ea9*/
  v176 = _mm_loadl_epi64((const __m128i *)&xmmword_108F2F9A0); /*0x106708eb5*/
  v177 = _mm_sub_pd((__m128d)_mm_unpacklo_epi32((__m128i)(unsigned __int64)__src, v176), (__m128d)xmmword_108F2F9B0); /*0x106708ec9*/
  v178 = _mm_hadd_pd(v177, v177); /*0x106708ecd*/
  v179 = _mm_sub_pd((__m128d)_mm_unpacklo_epi32((__m128i)v174, v176), (__m128d)xmmword_108F2F9B0); /*0x106708ee6*/
  v515 = _mm_hadd_pd(v179, v179); /*0x106708eee*/
  v178.f64[0] = v178.f64[0] * 100.0 / v515.f64[0]; /*0x106708ef6*/
  v497 = v178; /*0x106708f08*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106708f14*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "gameLoadProgressCyclePercent.lastSharedStringArrival",
    a3: v178.f64[0]);
  v180 = *(double *)v509; /*0x106708f19*/
  v181 = _mm_sub_pd((__m128d)_mm_unpacklo_epi32((__m128i)v172, (__m128i)xmmword_108F2F9A0), (__m128d)xmmword_108F2F9B0); /*0x106708f2d*/
  v182 = _mm_hadd_pd(v181, v181); /*0x106708f35*/
  v182.f64[0] = v182.f64[0] * 100.0 / v515.f64[0]; /*0x106708f41*/
  v471 = v182; /*0x106708f57*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106708f5f*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "gameLoadProgressCyclePercent.lastSharedStringDeserialized",
    a3: v182.f64[0]);
  v183 = _mm_sub_pd( /*0x106708f71*/
           (__m128d)_mm_unpacklo_epi32((__m128i)*(unsigned __int64 *)&v180, (__m128i)xmmword_108F2F9A0),
           (__m128d)xmmword_108F2F9B0);
  v184 = _mm_hadd_pd(v183, v183); /*0x106708f79*/
  v184.f64[0] = v184.f64[0] * 100.0 / v515.f64[0]; /*0x106708f85*/
  v495 = v184; /*0x106708f9b*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106708fa3*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "gameLoadProgressCyclePercent.gameLoadTagArrival",
    a3: v184.f64[0]);
  v185 = _mm_sub_pd((__m128d)_mm_unpacklo_epi32((__m128i)v173, (__m128i)xmmword_108F2F9A0), (__m128d)xmmword_108F2F9B0); /*0x106708fb5*/
  v186 = _mm_hadd_pd(v185, v185); /*0x106708fbd*/
  v186.f64[0] = v186.f64[0] * 100.0 / v515.f64[0]; /*0x106708fc9*/
  v515 = v186; /*0x106708fdf*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106708fe7*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "gameLoadProgressCyclePercent.gameLoadTagDeserialized",
    a3: v186.f64[0]);
  LOBYTE(v188) = (unsigned __int8)DFLog::JoinDataRxStats < 6u; /*0x106708ffc*/
  if ( (unsigned __int8)DFLog::JoinDataRxStats >= 6u && BYTE1(DFLog::JoinDataRxStats) >= 3u ) /*0x106709001*/
    FLog::FastLogFormatted( /*0x10670904a*/
      a1: DFLog::JoinDataRxStats,
      a2: (_DWORD)qword_10D809AE0,
      a3: (unsigned int)"[DFLog::JoinDataRxStats] GameLoadProgressCycle,lastSSArrive,%lu,%f%%,SSDeserialized,%lu,%f%%,gameLoa"
                    "dTagArrival,%lu,%f%%,gameLoadTagDeserialize,%lu,%f%%,gameLoadTagProcess,%lu",
      a4: v175,
      a5: v172,
      a6: LODWORD(v180));
  std::string::basic_string[abi:ne200100]<0>( /*0x10670905d*/
    a1: &__dst,
    a2: "ReplicatorGameLoadPercentCycleWhenJoinDataCompleteTransfer",
    a3: v187,
    a4: v188);
  v521 = v495.f64[0]; /*0x106709071*/
  std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10670907d*/
    a1: &v499,
    a2: &__dst,
    a3: v189,
    a4: v190,
    a5: v191,
    a6: v192);
  if ( (__dst & 1) != 0 ) /*0x106709089*/
    operator delete(a1: v520, a2: v193); /*0x106709092*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067090b4*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "totalPacketsDeserializationTimeUpToGameLoadTagMs",
    a3: *((double *)v518 + 1975));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067090d4*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "deserializedBytesByGameLoadTag",
    a3: *((_DWORD *)v518 + 3948));
  v515.f64[0] = *((double *)v518 + 1975); /*0x1067090e8*/
  std::string::basic_string[abi:ne200100]<0>( /*0x1067090fe*/
    a1: &__dst,
    a2: "ReplicatorDeserializeTimeUpToGameLoadTagMs",
    a3: v194,
    a4: v195);
  v521 = v515.f64[0]; /*0x106709112*/
  std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10670911e*/
    a1: &v499,
    a2: &__dst,
    a3: v196,
    a4: v197,
    a5: v198,
    a6: v199);
  if ( (__dst & 1) != 0 ) /*0x10670912a*/
    operator delete(a1: v520, a2: v202); /*0x106709133*/
  v203 = *((_DWORD *)v518 + 3948); /*0x10670913f*/
  std::string::basic_string[abi:ne200100]<0>( /*0x106709153*/
    a1: &__dst,
    a2: "ReplicatorBytesReceivedUpToGameLoadTag",
    a3: v200,
    a4: v201);
  v521 = (double)v203; /*0x106709169*/
  std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x106709175*/
    a1: &v499,
    a2: &__dst,
    a3: v204,
    a4: v205,
    a5: v206,
    a6: v207);
  if ( (__dst & 1) != 0 ) /*0x106709181*/
    operator delete(a1: v520, a2: v208); /*0x10670918a*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067091ba*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "gameJoinIngestSpeed.calculatedNetworkSpeed",
    a3: (double)*((int *)v518 + 3948) / v504[0]);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067091ea*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "gameJoinIngestSpeed.deserializeSpeed",
    a3: (double)*((int *)v518 + 3948) / *((double *)v518 + 1975));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670921a*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "gameJoinIngestSpeed.processCppSpeed",
    a3: (double)*((int *)v518 + 3948) / *((double *)v518 + 1983));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106709256*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "gameJoinIngestSpeed.processCppAndScriptSpeed",
    a3: (double)*((int *)v518 + 3948) / (*((double *)v518 + 1983) + *((double *)v518 + 1984)));
  v209 = *((_DWORD *)v518 + 3948); /*0x106709262*/
  std::string::basic_string[abi:ne200100]<0>( /*0x106709276*/
    a1: &__dst,
    a2: "ReplicatorCalculatedNetworkSpeedAtJoin",
    a3: v210,
    a4: v211);
  v521 = (double)v209 / v504[0]; /*0x106709294*/
  std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x1067092a0*/
    a1: &v499,
    a2: &__dst,
    a3: v212,
    a4: v213,
    a5: v214,
    a6: v215);
  if ( (__dst & 1) != 0 ) /*0x1067092ac*/
    operator delete(a1: v520, a2: v218); /*0x1067092b5*/
  v219 = *((_DWORD *)v518 + 3948); /*0x1067092c1*/
  v515.f64[0] = *((double *)v518 + 1975); /*0x1067092cf*/
  std::string::basic_string[abi:ne200100]<0>( /*0x1067092e5*/
    a1: &__dst,
    a2: "ReplicatorCalculatedDeserialiationSpeedAtJoin",
    a3: v216,
    a4: v217);
  v521 = (double)v219 / v515.f64[0]; /*0x106709303*/
  std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10670930f*/
    a1: &v499,
    a2: &__dst,
    a3: v220,
    a4: v221,
    a5: v222,
    a6: v223);
  if ( (__dst & 1) != 0 ) /*0x10670931b*/
    operator delete(a1: v520, a2: v226); /*0x106709324*/
  v227 = *((_DWORD *)v518 + 3948); /*0x106709330*/
  v515.f64[0] = *((double *)v518 + 1983); /*0x10670933e*/
  std::string::basic_string[abi:ne200100]<0>( /*0x106709354*/
    a1: &__dst,
    a2: "ReplicatorCalculatedProcessSpeedAtJoinCppOnly",
    a3: v224,
    a4: v225);
  v521 = (double)v227 / v515.f64[0]; /*0x106709372*/
  std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10670937e*/
    a1: &v499,
    a2: &__dst,
    a3: v228,
    a4: v229,
    a5: v230,
    a6: v231);
  if ( (__dst & 1) != 0 ) /*0x10670938a*/
    operator delete(a1: v520, a2: v234); /*0x106709393*/
  v235 = *((_DWORD *)v518 + 3948); /*0x10670939f*/
  v515.f64[0] = *((double *)v518 + 1983); /*0x1067093ad*/
  v504[0] = *((double *)v518 + 1984); /*0x1067093bd*/
  std::string::basic_string[abi:ne200100]<0>( /*0x1067093d3*/
    a1: &__dst,
    a2: "ReplicatorCalculatedProcessSpeedAtJoin",
    a3: v232,
    a4: v233);
  v521 = (double)v235 / (v515.f64[0] + v504[0]); /*0x1067093fd*/
  std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10670940c*/
    a1: &v499,
    a2: &__dst,
    a3: v236,
    a4: v237,
    a5: v238,
    a6: v239);
  if ( (__dst & 1) != 0 ) /*0x106709418*/
    operator delete(a1: v520, a2: v240); /*0x106709421*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106709447*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "gameLoadtagInfo.wallclockAllDataArrivalMs",
    a3: *((_DWORD *)v518 + 3988) - *((_DWORD *)v518 + 3899));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670946d*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "gameLoadtagInfo.wallclockDeserializeWaitMs",
    a3: *((_DWORD *)v518 + 3992) - *((_DWORD *)v518 + 3988));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106709493*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "gameLoadtagInfo.wallclockProcesssWaitMs",
    a3: *((_DWORD *)v518 + 3996) - *((_DWORD *)v518 + 3992));
  if ( (unsigned __int8)DFLog::JoinDataRxStats >= 6u && BYTE1(DFLog::JoinDataRxStats) >= 3u ) /*0x1067094ad*/
    FLog::FastLogFormatted( /*0x1067094eb*/
      a1: DFLog::JoinDataRxStats,
      a2: (_DWORD)qword_10D809AE0,
      a3: (unsigned int)"[DFLog::JoinDataRxStats] GameLoadTagProgressTime,TimeToArrive,%u,WaitForDeserialize,%u,WaitForProcess,%u",
      a4: *((_DWORD *)v518 + 3988) - *((_DWORD *)v518 + 3899),
      a5: *((_DWORD *)v518 + 3992) - *((_DWORD *)v518 + 3988),
      a6: *((_DWORD *)v518 + 3996) - *((_DWORD *)v518 + 3992));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106709513*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "gameLoadtagInfo.cyclesForAllTagArrival",
    a3: *((_QWORD *)v518 + 1993) - *((_QWORD *)v518 + 1950));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670953b*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "gameLoadtagInfo.cyclesWaitedToDeserialize",
    a3: *((_QWORD *)v518 + 1995) - *((_QWORD *)v518 + 1993));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106709563*/
    this: (RBX::Analytics::InfluxDb::Points *)v528,
    a2: "gameLoadtagInfo.cyclesWaitedToProcess",
    a3: *((_QWORD *)v518 + 1997) - *((_QWORD *)v518 + 1995));
  LOBYTE(v242) = (unsigned __int8)DFLog::JoinDataRxStats < 6u; /*0x106709578*/
  if ( (unsigned __int8)DFLog::JoinDataRxStats >= 6u && BYTE1(DFLog::JoinDataRxStats) >= 3u ) /*0x10670957d*/
    FLog::FastLogFormatted( /*0x1067095bd*/
      a1: DFLog::JoinDataRxStats,
      a2: (_DWORD)qword_10D809AE0,
      a3: (unsigned int)"[DFLog::JoinDataRxStats] GameLoadTagProgressCycle,CycleToArrive,%lu,WaitForDeserialize,%lu,WaitForProcess,%lu",
      a4: *((_QWORD *)v518 + 1993) - *((_DWORD *)v518 + 3900),
      a5: *((_QWORD *)v518 + 1995) - *((_QWORD *)v518 + 1993),
      a6: *((_DWORD *)v518 + 3994) - *((_QWORD *)v518 + 1995));
  if ( FFlag::ConnectViaConnectionInternal == 1 ) /*0x1067095cc*/
  {
    v243 = (unsigned int)(int)((*((double *)v518 + 1952) - *((double *)v518 + 1951)) * 1000.0); /*0x10670960d*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x106709621*/
      this: (RBX::Analytics::InfluxDb::Points *)v528,
      a2: "JoinDataDownloadTimeMs",
      a3: v243);
    if ( (v489 & 1) == 0 ) /*0x10670962d*/
      std::__throw_bad_optional_access[abi:ne200100](a1: v244); /*0x10670b0e4*/
    v245 = v518; /*0x10670964d*/
    v246 = *((double *)v518 + 1951); /*0x106709654*/
    *(_QWORD *)&v515.f64[0] = (v479 << 8) | LOBYTE(v488); /*0x10670965d*/
    v247 = (int)((v246 - v515.f64[0]) * 1000.0); /*0x106709671*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x106709687*/
      this: (RBX::Analytics::InfluxDb::Points *)v528,
      a2: "TimeToFirstJoinDataPacketArriveMs",
      a3: v247);
    v248 = _mm_sub_pd( /*0x1067096cf*/
             (__m128d)_mm_unpacklo_epi32((__m128i)(unsigned __int64)(8LL * (_QWORD)v494), (__m128i)xmmword_108F2F9A0),
             (__m128d)xmmword_108F2F9B0);
    v249 = _mm_hadd_pd(v248, v248); /*0x1067096d7*/
    v249.f64[0] = v249.f64[0] /*0x1067096e9*/
                / (double)(1000 * (int)fmax((*((double *)v245 + 1952) - *((double *)v245 + 1951)) * 1000.0, 1.0));
    *(__m128d *)v504 = v249; /*0x1067096fb*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x106709703*/
      this: (RBX::Analytics::InfluxDb::Points *)v528,
      a2: "JoinBandwidthMbps",
      a3: v249.f64[0]);
    v250 = (int)((*((double *)v245 + 1952) - v515.f64[0]) * 1000.0); /*0x106709721*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x106709737*/
      this: (RBX::Analytics::InfluxDb::Points *)v528,
      a2: "TotalTimeToLastJoinByte",
      a3: v250);
    RBX::Network::Replicator::reportTelemetryV2<unsigned long long>( /*0x106709750*/
      a1: v245,
      a2: &RBX::Telemetry::kJoinDataDownloadTimeMs,
      a3: v243,
      a4: v469);
    RBX::Network::Replicator::reportTelemetryV2<unsigned long long>( /*0x106709769*/
      a1: v245,
      a2: &RBX::Telemetry::kTimeToFirstJoinDataPacketArriveMs,
      a3: v247,
      a4: v469);
    RBX::Network::Replicator::reportTelemetryV2<double>( /*0x106709787*/
      a1: v245,
      a2: &RBX::Telemetry::kJoinBandwidthMbps,
      a3: v469,
      a4: v504[0]);
    RBX::Network::Replicator::reportTelemetryV2<unsigned long long>( /*0x1067097a0*/
      a1: v245,
      a2: &RBX::Telemetry::kTotalTimeToLastJoinByte,
      a3: v250,
      a4: v469);
  }
  else
  {
    v245 = v518; /*0x1067097aa*/
    if ( *((_BYTE *)v518 + 10391) == 0 ) /*0x1067097b9*/
    {
      *(_OWORD *)v511 = 0; /*0x1067097c3*/
      *(_OWORD *)v510 = 0; /*0x1067097cb*/
      v512 = 0; /*0x1067097d3*/
      v251 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)v518 + 28)); /*0x1067097e4*/
      if ( (*(unsigned __int8 (__fastcall **)(__int64, __int64, RBX::Network::Replicator *, _QWORD, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD, _DWORD))(*(_QWORD *)v251 + 696LL))( /*0x106709821*/
             a1: v251,
             a2: 0x200000,
             a3: v518,
             a4: *(_QWORD *)(*(_QWORD *)v251 + 696LL),
             a5: v252,
             a6: v253,
             a7: *((_QWORD *)v518 + 30),
             a8: *((_QWORD *)v518 + 31),
             a9: *((_QWORD *)v518 + 32),
             a10: *((_QWORD *)v518 + 33),
             a11: v469[0]) != 0 )
      {
        v254 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)v518 + 28)); /*0x10670983a*/
        v255 = (_QWORD *)((char *)v518 + 240); /*0x106709844*/
        RakNet::AddressOrGUID::AddressOrGUID( /*0x106709855*/
          this: (RakNet::AddressOrGUID *)&__dst,
          a2: (RBX::Network::Replicator *)((char *)v518 + 240));
        (*(void (__fastcall **)(__int64, __int128 *, unsigned int *))(*(_QWORD *)v254 + 344LL))( /*0x10670986e*/
          a1: v254,
          a2: &__dst,
          a3: v510);
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x106709888*/
          this: (RBX::Analytics::InfluxDb::Points *)v528,
          a2: "RakNetJoinRxBytes",
          a3: v510[0]);
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067098a1*/
          this: (RBX::Analytics::InfluxDb::Points *)v528,
          a2: "RakNetJoinRxPackets",
          a3: v510[1]);
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067098ba*/
          this: (RBX::Analytics::InfluxDb::Points *)v528,
          a2: "RakNetJoinRxIgnoredBytes",
          a3: (unsigned int)v511[0]);
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067098d3*/
          this: (RBX::Analytics::InfluxDb::Points *)v528,
          a2: "RakNetJoinRxIgnoredPackets",
          a3: HIDWORD(v511[0]));
        v256 = HIDWORD(v511[1]) - LODWORD(v511[1]); /*0x1067098df*/
        LODWORD(v254) = (HIDWORD(v511[1]) == LODWORD(v511[1])) + HIDWORD(v511[1]) - LODWORD(v511[1]); /*0x1067098ed*/
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x106709902*/
          this: (RBX::Analytics::InfluxDb::Points *)v528,
          a2: "RakNetJoinDataDownloadTimeMs",
          a3: v254);
        LODWORD(__dst) = 0; /*0x106709907*/
        v257 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)v518 + 28)); /*0x10670991f*/
        (*(void (__fastcall **)(__int64, __int128 *))(*(_QWORD *)v257 + 352LL))(a1: v257, a2: &__dst); /*0x106709931*/
        v258 = LODWORD(v511[1]) - __dst; /*0x10670993e*/
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x106709956*/
          this: (RBX::Analytics::InfluxDb::Points *)v528,
          a2: "RakNetTimeToFirstJoinDataPacketArriveMs",
          a3: LODWORD(v511[1]) - __dst);
        v515.f64[0] = (double)(8 * v510[0]) / (double)(1000 * (int)v254); /*0x106709987*/
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670998f*/
          this: (RBX::Analytics::InfluxDb::Points *)v528,
          a2: "RakNetJoinBandwidthMbps",
          a3: v515.f64[0]);
        v259 = HIDWORD(v511[1]) - __dst; /*0x10670999b*/
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067099b3*/
          this: (RBX::Analytics::InfluxDb::Points *)v528,
          a2: "RaknetTotalTimeToLastJoinByte",
          a3: HIDWORD(v511[1]) - __dst);
        RBX::Network::Replicator::reportTelemetryV2<unsigned long long>( /*0x1067099d0*/
          a1: v518,
          a2: &RBX::Telemetry::kRakNetTimeToFirstJoinDataPacketArriveMs,
          a3: v258,
          a4: v469);
        RBX::Network::Replicator::reportTelemetryV2<unsigned long long>( /*0x1067099ed*/
          a1: v518,
          a2: &RBX::Telemetry::kRakNetJoinDataDownloadTimeMs,
          a3: (unsigned int)v254,
          a4: v469);
        RBX::Network::Replicator::reportTelemetryV2<double>( /*0x106709a0f*/
          a1: v518,
          a2: &RBX::Telemetry::kRakNetJoinBandwidthMbps,
          a3: v469,
          a4: v515.f64[0]);
        RBX::Network::Replicator::reportTelemetryV2<unsigned long long>( /*0x106709a2c*/
          a1: v518,
          a2: &RBX::Telemetry::kRaknetTotalTimeToLastJoinByte,
          a3: v259,
          a4: v469);
        v260 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)v518 + 28)); /*0x106709a3f*/
        if ( (*(unsigned __int8 (__fastcall **)(__int64, __int64, __int64, _QWORD, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD))(*(_QWORD *)v260 + 696LL))( /*0x106709a6e*/
               a1: v260,
               a2: 0x800000,
               a3: v261,
               a4: *(_QWORD *)(*(_QWORD *)v260 + 696LL),
               a5: v262,
               a6: v263,
               a7: *v255,
               a8: v255[1],
               a9: v255[2],
               a10: v255[3]) != 0 )
        {
          RBX::Analytics::InfluxDb::Points::addPoint( /*0x106709a88*/
            this: (RBX::Analytics::InfluxDb::Points *)v528,
            a2: "RakNetJoinRxReBytes",
            a3: v510[2]);
          RBX::Analytics::InfluxDb::Points::addPoint( /*0x106709aa1*/
            this: (RBX::Analytics::InfluxDb::Points *)v528,
            a2: "RakNetJoinRxRePackets",
            a3: v510[3]);
          v264 = v512 - LODWORD(v511[1]); /*0x106709aae*/
          if ( v512 == 0 ) /*0x106709ab6*/
            v264 = v256; /*0x106709ab6*/
          v265 = (v264 == 0) + v264; /*0x106709abd*/
          RBX::Analytics::InfluxDb::Points::addPoint( /*0x106709ad0*/
            this: (RBX::Analytics::InfluxDb::Points *)v528,
            a2: "RakNetNonReTxJoinDataDownloadTimeMs",
            a3: v265);
          v515.f64[0] = (double)(8 * (v510[0] - v510[2])) / (double)(int)(1000 * v265); /*0x106709b0c*/
          RBX::Analytics::InfluxDb::Points::addPoint( /*0x106709b14*/
            this: (RBX::Analytics::InfluxDb::Points *)v528,
            a2: "RaknetEffectiveInitialBandwidthMbps",
            a3: v515.f64[0]);
          RBX::Network::Replicator::reportTelemetryV2<unsigned long long>( /*0x106709b30*/
            a1: v518,
            a2: &RBX::Telemetry::kRakNetNonReTxJoinDataDownloadTimeMs,
            a3: v265,
            a4: v469);
          RBX::Network::Replicator::reportTelemetryV2<double>( /*0x106709b52*/
            a1: v518,
            a2: &RBX::Telemetry::kRaknetEffectiveInitialBandwidthMbps,
            a3: v469,
            a4: v515.f64[0]);
        }
      }
      v245 = v518; /*0x106709b5e*/
    }
  }
  if ( *((_BYTE *)v245 + 18601) == 1 ) /*0x106709b74*/
    RBX::Analytics::EphemeralCounter::bulkReportStats(a1: &v499, a2: 0); /*0x106709b7f*/
  if ( *((_BYTE *)v518 + 15544) == 1 ) /*0x106709b92*/
  {
    v266 = RBX::ServiceProvider::find<RBX::Workspace>(a1: v518); /*0x106709b9b*/
    if ( v266 != 0 ) /*0x106709ba3*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x106709bb9*/
        this: (RBX::Analytics::InfluxDb::Points *)v528,
        a2: "ModelStreamingBehavior",
        a3: *(_DWORD *)(v266 + 1204));
  }
  if ( DFFlag::ClientNetworkTelemetryRCCChannelName == 1 )
  {
    v242 = SFString::RCCChannelName; /*0x106709bc7*/
    v267 = (SFString::RCCChannelName[0] & 1) != 0
         ? *(_QWORD *)&SFString::RCCChannelName[8]
         : SFString::RCCChannelName[0] >> 1;
    if ( v267 != 0 ) /*0x106709be0*/
      RBX::Analytics::InfluxDb::Points::addPoint(a1: v528, a2: "rccChannelName", a3: SFString::RCCChannelName); /*0x106709bf7*/
  }
  if ( v528 != (void **)((char *)v518 + 23912) ) /*0x106709c0d*/
    RBX::SmallDenseMap<std::string,std::string,8u,RBX::Analytics::InfluxDb::AnalyticsPointsDenseMapInfo,RBX::detail::DenseMapPair<std::string,std::string>>::copyFrom( /*0x106709c16*/
      a1: (__int64)v518 + 23912,
      a2: v528,
      a3: v241,
      a4: (__int64)v242);
  std::string::operator=(a1: (char *)v518 + 24304, a2: v529); /*0x106709c2d*/
  v268 = v518; /*0x106709c39*/
  *((_BYTE *)v518 + 24332) = v529[7]; /*0x106709c40*/
  *((_DWORD *)v268 + 6082) = v529[6]; /*0x106709c49*/
  std::string::operator=(a1: (char *)v268 + 24336, a2: v530); /*0x106709c56*/
  v269 = v518; /*0x106709c63*/
  *((_QWORD *)v518 + 3045) = v530[3]; /*0x106709c6a*/
  std::shared_ptr<RBX::Telemetry::IFieldsContainer>::operator=[abi:ne200100](a1: (char *)v269 + 24368); /*0x106709c78*/
  *((_BYTE *)v269 + 24384) = 1; /*0x106709c7d*/
  if ( (unsigned __int8)DFLog::JoinDataRxStats >= 6u && BYTE1(DFLog::JoinDataRxStats) >= 3u )
  {
    LOBYTE(v270) = (unsigned __int8)DFLog::JoinDataRxStats < 6u; /*0x106709c94*/
    FLog::FastLogFormatted(
      a1: DFLog::JoinDataRxStats,
      a2: (_DWORD)qword_10D809AE0,
      a3: (unsigned int)"[DFLog::JoinDataRxStats] Join Rx Times : deltaTimeBetweenJoinRequestAndFirstBlobArrival=%fms, deltaT"
                    "imeBetweenJoinRequestAndJoinProcessingComplete=%fms, joinDataReadTime=%fms, joinDataProcessTime=%fms",
      a4: v270,
      a5: v272,
      a6: v273);
  }
  v274 = RBX::Network::Replicator::getBatchNetAssetJoinEnabled(this: v518, a2: v271); /*0x106709ce9*/
  v278 = (unsigned int)DFLog::JoinDataRxStats >> 8; /*0x106709cf7*/
  LOBYTE(v278) = (unsigned __int8)DFLog::JoinDataRxStats >= 6u && BYTE1(DFLog::JoinDataRxStats) >= 3u; /*0x106709d07*/
  if ( v274 != 0 )
  {
    if ( (_BYTE)v278 != 0 )
      FLog::FastLogFormatted(
        a1: DFLog::JoinDataRxStats,
        a2: (_DWORD)qword_10D809AE0,
        a3: (unsigned int)"[DFLog::JoinDataRxStats] JoinData read breakdown : SharedStrings=%fms, Instance=%fms, BatchNetAssets=%fms",
        a4: v278,
        a5: v276,
        a6: v277);
  }
  else if ( (_BYTE)v278 != 0 )
  {
    FLog::FastLogFormatted(
      a1: DFLog::JoinDataRxStats,
      a2: (_DWORD)qword_10D809AE0,
      a3: (unsigned int)"[DFLog::JoinDataRxStats] JoinData read breakdown : SharedStrings=%fms, Instance=%fms",
      a4: v278,
      a5: v276,
      a6: v277);
  }
  v279 = DFLog::JoinDataRxStats; /*0x106709d86*/
  v280 = (unsigned int)DFLog::JoinDataRxStats >> 8; /*0x106709d8f*/
  if ( (unsigned __int8)DFLog::JoinDataRxStats >= 6u && BYTE1(DFLog::JoinDataRxStats) >= 3u )
  {
    FLog::FastLogFormatted(
      a1: DFLog::JoinDataRxStats,
      a2: (_DWORD)qword_10D809AE0,
      a3: (unsigned int)"[DFLog::JoinDataRxStats] JoinData count breakdown : SharedStrings=%u, TotalInstances=%u, WastedInsta"
                    "nces=%u, PercentageUseful=%f%%",
      a4: *((_DWORD *)v518 + 3918),
      a5: *((_DWORD *)v518 + 3925),
      a6: *((_DWORD *)v518 + 3924));
    v279 = DFLog::JoinDataRxStats; /*0x106709dda*/
    v280 = (unsigned int)DFLog::JoinDataRxStats >> 8; /*0x106709de3*/
  }
  if ( (unsigned __int8)v279 >= 6u && (unsigned __int8)v280 >= 3u )
  {
    LOBYTE(v278) = (unsigned __int8)v279 < 6u; /*0x106709dea*/
    FLog::FastLogFormatted(
      a1: v279,
      a2: (_DWORD)qword_10D809AE0,
      a3: (unsigned int)"[DFLog::JoinDataRxStats] JoinData byte breakdown percentage: percentageOfBytesInSS=%f%%, percentageO"
                    "fBytesMeta=%f%%, percentageOfBytesWaste=%f%%, percentageOfBytesInstancesUseful=%f%%",
      a4: v278,
      a5: v276,
      a6: v277);
    v279 = DFLog::JoinDataRxStats; /*0x106709e2b*/
    v280 = (unsigned int)DFLog::JoinDataRxStats >> 8; /*0x106709e34*/
  }
  if ( (unsigned __int8)v279 >= 6u && (unsigned __int8)v280 >= 3u )
  {
    LOBYTE(v278) = (unsigned __int8)v279 < 6u; /*0x106709e3b*/
    FLog::FastLogFormatted(
      a1: v279,
      a2: (_DWORD)qword_10D809AE0,
      a3: (unsigned int)"[DFLog::JoinDataRxStats] JoinData read time percentage : percentageReadTimeForSS=%f%%, percentageRea"
                    "dTimeForMetaInstances=%f%%",
      a4: v278,
      a5: v276,
      a6: v277);
    v279 = DFLog::JoinDataRxStats; /*0x106709e6c*/
    v280 = (unsigned int)DFLog::JoinDataRxStats >> 8; /*0x106709e75*/
  }
  if ( (unsigned __int8)v279 >= 6u && (unsigned __int8)v280 >= 3u )
    FLog::FastLogFormatted(
      a1: v279,
      a2: (_DWORD)qword_10D809AE0,
      a3: (unsigned int)"[DFLog::JoinDataRxStats] JoinData SharedString Compression: Compressed: %u -> Uncompressed -> %u, Co"
                    "mpressionRatio %f%%",
      a4: *((_DWORD *)v518 + 3916),
      a5: *((_DWORD *)v518 + 3917),
      a6: v277);
  v281 = RBX::Network::Replicator::getBatchNetAssetJoinEnabled(this: v518, a2: v275); /*0x106709ebd*/
  v285 = DFLog::JoinDataRxStats; /*0x106709ec2*/
  if ( v281 != 0 && (unsigned __int8)DFLog::JoinDataRxStats >= 6u && BYTE1(DFLog::JoinDataRxStats) >= 3u )
  {
    FLog::FastLogFormatted(
      a1: DFLog::JoinDataRxStats,
      a2: (_DWORD)qword_10D809AE0,
      a3: (unsigned int)"[DFLog::JoinDataRxStats] JoinData BatchNetAsset stats: Count=%u, CompressedBytes=%u, UncompressedByt"
                    "es=%u, CompressionRatio=%f%%",
      a4: *((_DWORD *)v518 + 3921),
      a5: *((_DWORD *)v518 + 3919),
      a6: *((_DWORD *)v518 + 3920));
    v285 = DFLog::JoinDataRxStats; /*0x106709f1d*/
  }
  v286 = v285 >> 8; /*0x106709f26*/
  if ( (unsigned __int8)v285 >= 6u && BYTE1(v285) >= 3u )
  {
    FLog::FastLogFormatted(
      a1: v285,
      a2: (_DWORD)qword_10D809AE0,
      a3: (unsigned int)"[DFLog::JoinDataRxStats] JoinData NetAsset Compression: Compressed: %u -> Uncompressed: %u, Compress"
                    "ionRatio %f%%, EstimatedRaw: %u, EstimatedOptimized: %u",
      a4: v508,
      a5: v505,
      a6: v501);
    v285 = DFLog::JoinDataRxStats; /*0x106709f73*/
    v286 = (unsigned int)DFLog::JoinDataRxStats >> 8; /*0x106709f7c*/
  }
  if ( (unsigned __int8)v285 >= 6u && (unsigned __int8)v286 >= 3u )
  {
    FLog::FastLogFormatted(
      a1: v285,
      a2: (_DWORD)qword_10D809AE0,
      a3: (unsigned int)"[DFLog::JoinDataRxStats] Join Rx Blob Stats : totalBlobBytesRxDuringJoin=%d, totalBlobRxDuringJoin=%"
                    "d, totalMetaBytesRxInJoin=%d, totalWasteBytesRxInJoin=%d, totalSharedStringBytesRxDuringJoin=%d",
      a4: *((_DWORD *)v518 + 3913),
      a5: *((_DWORD *)v518 + 3914),
      a6: *((_DWORD *)v518 + 3915));
    v285 = DFLog::JoinDataRxStats; /*0x106709fd2*/
    v286 = (unsigned int)DFLog::JoinDataRxStats >> 8; /*0x106709fdb*/
  }
  if ( (unsigned __int8)v285 >= 6u && (unsigned __int8)v286 >= 3u ) /*0x106709fe7*/
    FLog::FastLogFormatted( /*0x10670a01d*/
      a1: v285,
      a2: (_DWORD)qword_10D809AE0,
      a3: (unsigned int)"[DFLog::JoinDataRxStats] Inline NetAsset received count=%d, bytes received and processed=%d. Total N"
                    "etAsset received count=%d, bytes received and processed=%d",
      a4: v483[0],
      a5: v484[0],
      a6: v485[0]);
  v287 = &FFlag::ConnectViaConnectionInternal; /*0x10670a02e*/
  if ( FFlag::ConnectViaConnectionInternal == 1 )
  {
    if ( (unsigned __int8)DFLog::JoinDataRxStats >= 6u && BYTE1(DFLog::JoinDataRxStats) >= 5u )
    {
      *(_QWORD *)&__dst = v494; /*0x10670a060*/
      v520 = (RBX::Memory *)v490; /*0x10670a06e*/
      v522 = v492; /*0x10670a07c*/
      v524 = v493; /*0x10670a08a*/
      v525 = v491; /*0x10670a098*/
      *(_QWORD *)v510 = 279620; /*0x10670a09f*/
      *(_QWORD *)&v510[2] = &__dst; /*0x10670a0b1*/
      FLog::detail::FastLogSafeFormattedInternal(
        a1: DFLog::JoinDataRxStats,
        a2: (_DWORD)qword_10D809AE0,
        a3: 5,
        a4: (unsigned int)"[DFLog::JoinDataRxStats] Join Rx Packet Stats : totalRxBytes={}, totalRxPackets={}, totalRxIgnored"
                      "Bytes={}, totalRxIgnoredPackets={}, totalRxDroppedPackets={}",
        a5: 158,
        a6: 1,
        279620,
        &__dst);
    }
  }
  else if ( (unsigned __int8)DFLog::JoinDataRxStats >= 6u && BYTE1(DFLog::JoinDataRxStats) >= 3u )
  {
    FLog::FastLogFormatted(
      a1: DFLog::JoinDataRxStats,
      a2: (_DWORD)qword_10D809AE0,
      a3: (unsigned int)"[DFLog::JoinDataRxStats] Join Rx Packet Stats : totalRxBytes=%d, totalRxPackets=%d, totalRxIgnoredBy"
                    "tes=%d, totalRxIgnoredPackets=%d",
      a4: v496[0],
      a5: v496[1],
      a6: v496[3]);
  }
  v288 = DFLog::JoinDataRxStats; /*0x10670a11f*/
  v289 = (unsigned int)DFLog::JoinDataRxStats >> 8; /*0x10670a128*/
  if ( (unsigned __int8)DFLog::JoinDataRxStats >= 6u && BYTE1(DFLog::JoinDataRxStats) >= 3u )
  {
    LOBYTE(v287) = (unsigned __int8)DFLog::JoinDataRxStats < 6u; /*0x10670a12f*/
    FLog::FastLogFormatted(
      a1: DFLog::JoinDataRxStats,
      a2: (_DWORD)qword_10D809AE0,
      a3: (unsigned int)"[DFLog::JoinDataRxStats] Total Packet Deserialization Time : %f ms   Total Process Packet Time : %f ms",
      a4: (_DWORD)v287,
      a5: v283,
      a6: v284);
    v288 = DFLog::JoinDataRxStats; /*0x10670a16f*/
    v289 = (unsigned int)DFLog::JoinDataRxStats >> 8; /*0x10670a178*/
  }
  if ( (unsigned __int8)v288 >= 6u && (unsigned __int8)v289 >= 3u )
  {
    LOBYTE(v287) = (unsigned __int8)v288 < 6u; /*0x10670a17f*/
    FLog::FastLogFormatted(
      a1: v288,
      a2: (_DWORD)qword_10D809AE0,
      a3: (unsigned int)"[DFLog::JoinDataRxStats] Process Deserialization Time : Cluster : %f ms   Data : %f ms",
      a4: (_DWORD)v287,
      a5: v283,
      a6: v284);
    v288 = DFLog::JoinDataRxStats; /*0x10670a1b7*/
    v289 = (unsigned int)DFLog::JoinDataRxStats >> 8; /*0x10670a1c0*/
  }
  LOBYTE(v287) = (unsigned __int8)v288 < 6u; /*0x10670a1c7*/
  LOBYTE(v282) = (unsigned __int8)v288 < 6u || (unsigned __int8)v289 < 3u; /*0x10670a1cf*/
  if ( (_BYTE)v282 == 0 )
  {
    FLog::FastLogFormatted(
      a1: v288,
      a2: (_DWORD)qword_10D809AE0,
      a3: (unsigned int)"[DFLog::JoinDataRxStats] Process Packet Script Time : %f ms   ProcessPacket Cpp Time : %f ms",
      a4: (_DWORD)v287,
      a5: v283,
      a6: v284);
    v288 = DFLog::JoinDataRxStats; /*0x10670a1ff*/
    v289 = (unsigned int)DFLog::JoinDataRxStats >> 8; /*0x10670a208*/
  }
  if ( (unsigned __int8)v288 >= 6u && (unsigned __int8)v289 >= 3u )
  {
    FLog::FastLogFormatted(
      a1: v288,
      a2: (_DWORD)qword_10D809AE0,
      a3: (unsigned int)"[DFLog::JoinDataRxStats] Process Cluster Time : %f ms  Process Data Time : %f ms",
      a4: (_DWORD)v287,
      a5: v283,
      a6: v284);
    v288 = DFLog::JoinDataRxStats; /*0x10670a247*/
    v289 = (unsigned int)DFLog::JoinDataRxStats >> 8; /*0x10670a250*/
  }
  if ( (unsigned __int8)v288 >= 6u && (unsigned __int8)v289 >= 3u )
  {
    FLog::FastLogFormatted(
      a1: v288,
      a2: (_DWORD)qword_10D809AE0,
      a3: (unsigned int)"[DFLog::JoinDataRxStats] Total Time from connection accept to load : %f ms ",
      a4: (_DWORD)v287,
      a5: v283,
      a6: v284);
    v288 = DFLog::JoinDataRxStats; /*0x10670a281*/
    v289 = (unsigned int)DFLog::JoinDataRxStats >> 8; /*0x10670a28a*/
  }
  if ( (unsigned __int8)v288 >= 6u && (unsigned __int8)v289 >= 3u )
    FLog::FastLogFormatted(
      a1: v288,
      a2: (_DWORD)qword_10D809AE0,
      a3: (unsigned int)"[DFLog::JoinDataRxStats] Time from connection accept to first process packet : %f ms ",
      a4: (_DWORD)v287,
      a5: v283,
      a6: v284);
  if ( *((_BYTE *)v518 + 18601) == 1 ) /*0x10670a2c9*/
  {
    *(_OWORD *)v510 = 0; /*0x10670a2d2*/
    v511[0] = nullptr; /*0x10670a2d9*/
    v290 = "_NonStreamingEnabled"; /*0x10670a2eb*/
    if ( *((_BYTE *)v518 + 15544) != 0 ) /*0x10670a2f9*/
      v290 = "_StreamingEnabled"; /*0x10670a2f9*/
    std::string::basic_string[abi:ne200100]<0>(a1: v513, a2: v290, a3: v282, a4: v518); /*0x10670a304*/
    std::operator+<char>(a1: &v516, a2: "TotalPacketDeserializationTimeMsDuringJoin", v513); /*0x10670a31e*/
    v291 = *((double *)v518 + 1987); /*0x10670a32a*/
    v292 = v517; /*0x10670a331*/
    v520 = (RBX::Memory *)v517; /*0x10670a33f*/
    __dst = v516; /*0x10670a34b*/
    v516 = 0; /*0x10670a353*/
    v517 = nullptr; /*0x10670a35b*/
    v521 = v291; /*0x10670a366*/
    std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10670a371*/
      a1: v510,
      a2: &__dst,
      a3: v293,
      a4: v292,
      a5: v294,
      a6: v295);
    if ( (__dst & 1) != 0 ) /*0x10670a37d*/
      operator delete(a1: v520, a2: v296); /*0x10670a386*/
    if ( (v516 & 1) != 0 ) /*0x10670a392*/
      operator delete(a1: (RBX::Memory *)v517, a2: v296); /*0x10670a39b*/
    std::operator+<char>(a1: &v516, a2: "DataDeserializationTimeMsDuringJoin", v513); /*0x10670a3b5*/
    v297 = *((float *)v518 + 3908); /*0x10670a3c4*/
    v520 = (RBX::Memory *)v517; /*0x10670a3da*/
    __dst = v516; /*0x10670a3e5*/
    v516 = 0; /*0x10670a3eb*/
    v517 = nullptr; /*0x10670a3f2*/
    v521 = v297; /*0x10670a3fd*/
    std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10670a409*/
      a1: v510,
      a2: &__dst,
      a3: v298,
      a4: v299,
      a5: v300,
      a6: v301);
    if ( (__dst & 1) != 0 ) /*0x10670a415*/
      operator delete(a1: v520, a2: v302); /*0x10670a41e*/
    if ( (v516 & 1) != 0 ) /*0x10670a42a*/
      operator delete(a1: (RBX::Memory *)v517, a2: v302); /*0x10670a433*/
    std::operator+<char>(a1: &v516, a2: "ClusterDeserializationTimeMsDuringJoin", v513); /*0x10670a44d*/
    v303 = *((double *)v518 + 1988); /*0x10670a459*/
    v304 = v517; /*0x10670a460*/
    v520 = (RBX::Memory *)v517; /*0x10670a46e*/
    __dst = v516; /*0x10670a47a*/
    v516 = 0; /*0x10670a482*/
    v517 = nullptr; /*0x10670a48a*/
    v521 = v303; /*0x10670a495*/
    std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10670a4a0*/
      a1: v510,
      a2: &__dst,
      a3: v305,
      a4: v304,
      a5: v306,
      a6: v307);
    if ( (__dst & 1) != 0 ) /*0x10670a4ac*/
      operator delete(a1: v520, a2: v308); /*0x10670a4b5*/
    if ( (v516 & 1) != 0 ) /*0x10670a4c1*/
      operator delete(a1: (RBX::Memory *)v517, a2: v308); /*0x10670a4ca*/
    std::operator+<char>(a1: &v516, a2: "JdiProcessTimeMsDuringJoin", v513); /*0x10670a4e4*/
    v309 = v516; /*0x10670a4e9*/
    *(_QWORD *)&v527[7] = *((_QWORD *)&v516 + 1); /*0x10670a4f6*/
    *(_QWORD *)v527 = *(_QWORD *)((char *)&v516 + 1); /*0x10670a504*/
    v310 = (RBX::Memory *)v517; /*0x10670a50b*/
    v516 = 0; /*0x10670a516*/
    v517 = nullptr; /*0x10670a51e*/
    v311 = *((float *)v518 + 3911); /*0x10670a533*/
    LOBYTE(__dst) = v309; /*0x10670a542*/
    *((_QWORD *)&__dst + 1) = *(_QWORD *)&v527[7]; /*0x10670a552*/
    *(_QWORD *)((char *)&__dst + 1) = *(_QWORD *)v527; /*0x10670a556*/
    v520 = v310; /*0x10670a55a*/
    v521 = v311; /*0x10670a55e*/
    std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10670a56a*/
      a1: v510,
      a2: &__dst,
      a3: *(_QWORD *)&v527[7],
      a4: v310,
      a5: v312,
      a6: v313);
    if ( (__dst & 1) != 0 ) /*0x10670a576*/
      operator delete(a1: v520, a2: v314); /*0x10670a57f*/
    if ( (v516 & 1) != 0 ) /*0x10670a58b*/
      operator delete(a1: (RBX::Memory *)v517, a2: v314); /*0x10670a594*/
    std::operator+<char>(a1: &v516, a2: "ClusterProcessTimeMsDursingJoin", v513); /*0x10670a5ae*/
    v315 = v516; /*0x10670a5b3*/
    *(_QWORD *)&v527[7] = *((_QWORD *)&v516 + 1); /*0x10670a5c0*/
    *(_QWORD *)v527 = *(_QWORD *)((char *)&v516 + 1); /*0x10670a5ce*/
    v316 = (RBX::Memory *)v517; /*0x10670a5d5*/
    v516 = 0; /*0x10670a5df*/
    v517 = nullptr; /*0x10670a5e6*/
    v317 = *((float *)v518 + 3912); /*0x10670a5fb*/
    LOBYTE(__dst) = v315; /*0x10670a60a*/
    *((_QWORD *)&__dst + 1) = *(_QWORD *)&v527[7]; /*0x10670a61a*/
    *(_QWORD *)((char *)&__dst + 1) = *(_QWORD *)v527; /*0x10670a61e*/
    v520 = v316; /*0x10670a622*/
    v521 = v317; /*0x10670a626*/
    std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10670a632*/
      a1: v510,
      a2: &__dst,
      a3: *(_QWORD *)&v527[7],
      a4: v316,
      a5: v318,
      a6: v319);
    if ( (__dst & 1) != 0 ) /*0x10670a63e*/
      operator delete(a1: v520, a2: v320); /*0x10670a647*/
    if ( (v516 & 1) != 0 ) /*0x10670a653*/
      operator delete(a1: (RBX::Memory *)v517, a2: v320); /*0x10670a65c*/
    std::operator+<char>(a1: &v516, a2: "PacketProcessingTotalTimeMsJoin", v513); /*0x10670a676*/
    v321 = *((double *)v518 + 1984) + *((double *)v518 + 1983); /*0x10670a68a*/
    v520 = (RBX::Memory *)v517; /*0x10670a6a0*/
    __dst = v516; /*0x10670a6ac*/
    v516 = 0; /*0x10670a6b4*/
    v517 = nullptr; /*0x10670a6bc*/
    v521 = v321; /*0x10670a6c7*/
    std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10670a6d3*/
      a1: v510,
      a2: &__dst,
      a3: v322,
      a4: v323,
      a5: v324,
      a6: v325);
    if ( (__dst & 1) != 0 ) /*0x10670a6df*/
      operator delete(a1: v520, a2: v326); /*0x10670a6e8*/
    if ( (v516 & 1) != 0 ) /*0x10670a6f4*/
      operator delete(a1: (RBX::Memory *)v517, a2: v326); /*0x10670a6fd*/
    std::operator+<char>(a1: &v516, a2: "PacketProcessingCppTimeMsJoin", v513); /*0x10670a717*/
    v520 = (RBX::Memory *)v517; /*0x10670a72a*/
    __dst = v516; /*0x10670a735*/
    v516 = 0; /*0x10670a73b*/
    v517 = nullptr; /*0x10670a742*/
    v521 = *((double *)v518 + 1983); /*0x10670a75c*/
    std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10670a768*/
      a1: v510,
      a2: &__dst,
      a3: v327,
      a4: v328,
      a5: v329,
      a6: v330);
    if ( (__dst & 1) != 0 ) /*0x10670a774*/
      operator delete(a1: v520, a2: v331); /*0x10670a77d*/
    if ( (v516 & 1) != 0 ) /*0x10670a789*/
      operator delete(a1: (RBX::Memory *)v517, a2: v331); /*0x10670a792*/
    std::operator+<char>(a1: &v516, a2: "PacketProcessingScriptTimeMsJoin", v513); /*0x10670a7ac*/
    v520 = (RBX::Memory *)v517; /*0x10670a7bf*/
    __dst = v516; /*0x10670a7ca*/
    v516 = 0; /*0x10670a7d0*/
    v517 = nullptr; /*0x10670a7d7*/
    v521 = *((double *)v518 + 1984); /*0x10670a7f1*/
    std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10670a7fd*/
      a1: v510,
      a2: &__dst,
      a3: v332,
      a4: v333,
      a5: v334,
      a6: v335);
    if ( (__dst & 1) != 0 ) /*0x10670a809*/
      operator delete(a1: v520, a2: v336); /*0x10670a812*/
    if ( (v516 & 1) != 0 ) /*0x10670a81e*/
      operator delete(a1: (RBX::Memory *)v517, a2: v336); /*0x10670a827*/
    v337 = *((_DWORD *)v518 + 3963) + (*((_BYTE *)v518 + 15729) & 1); /*0x10670a83f*/
    if ( v337 <= 0 ) /*0x10670a847*/
      v515.f64[0] = 0.0; /*0x10670a86d*/
    else
      v515.f64[0] = (double)*((int *)v518 + 3964) / (double)v337; /*0x10670a85f*/
    std::operator+<char>(a1: &v516, a2: "avgJdiV2ProcessedPerFrame", v513); /*0x10670a88a*/
    v520 = (RBX::Memory *)v517; /*0x10670a89d*/
    __dst = v516; /*0x10670a8a8*/
    v516 = 0; /*0x10670a8ae*/
    v517 = nullptr; /*0x10670a8b5*/
    v521 = v515.f64[0]; /*0x10670a8c8*/
    std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10670a8d4*/
      a1: v510,
      a2: &__dst,
      a3: v338,
      a4: v339,
      a5: v340,
      a6: v341);
    if ( (__dst & 1) != 0 ) /*0x10670a8e0*/
      operator delete(a1: v520, a2: v342); /*0x10670a8e9*/
    if ( (v516 & 1) != 0 ) /*0x10670a8f5*/
      operator delete(a1: (RBX::Memory *)v517, a2: v342); /*0x10670a8fe*/
    std::operator+<char>(a1: &v516, a2: "longestSingleFrameCppPartJdiV2", v513); /*0x10670a918*/
    v520 = (RBX::Memory *)v517; /*0x10670a92b*/
    __dst = v516; /*0x10670a936*/
    v516 = 0; /*0x10670a93c*/
    v517 = nullptr; /*0x10670a943*/
    v521 = *((double *)v518 + 1985); /*0x10670a95d*/
    std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10670a969*/
      a1: v510,
      a2: &__dst,
      a3: v343,
      a4: v344,
      a5: v345,
      a6: v346);
    if ( (__dst & 1) != 0 ) /*0x10670a975*/
      operator delete(a1: v520, a2: v347); /*0x10670a97e*/
    if ( (v516 & 1) != 0 ) /*0x10670a98a*/
      operator delete(a1: (RBX::Memory *)v517, a2: v347); /*0x10670a993*/
    std::operator+<char>(a1: &v516, a2: "longestSingleFrameScriptPartJdiV2", v513); /*0x10670a9ad*/
    v520 = (RBX::Memory *)v517; /*0x10670a9c0*/
    __dst = v516; /*0x10670a9cb*/
    v516 = 0; /*0x10670a9d1*/
    v517 = nullptr; /*0x10670a9d8*/
    v521 = *((double *)v518 + 1986); /*0x10670a9f2*/
    std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10670a9fe*/
      a1: v510,
      a2: &__dst,
      a3: v348,
      a4: v349,
      a5: v350,
      a6: v351);
    if ( (__dst & 1) != 0 ) /*0x10670aa0a*/
      operator delete(a1: v520, a2: v354); /*0x10670aa13*/
    if ( (v516 & 1) != 0 ) /*0x10670aa1f*/
      operator delete(a1: (RBX::Memory *)v517, a2: v354); /*0x10670aa28*/
    v355 = *((_DWORD *)v518 + 3917); /*0x10670aa34*/
    std::string::basic_string[abi:ne200100]<0>( /*0x10670aa48*/
      a1: &__dst,
      a2: "jdiv2TotalUncompressSharedStringSize",
      a3: v352,
      a4: v353);
    v521 = (double)v355; /*0x10670aa5e*/
    std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10670aa6a*/
      a1: v510,
      a2: &__dst,
      a3: v356,
      a4: v357,
      a5: v358,
      a6: v359);
    if ( (__dst & 1) != 0 ) /*0x10670aa76*/
      operator delete(a1: v520, a2: v362); /*0x10670aa7f*/
    std::string::basic_string[abi:ne200100]<0>( /*0x10670aa92*/
      a1: &__dst,
      a2: "jdiv2SharedStringEffCompressionRatio",
      a3: v360,
      a4: v361);
    v521 = v506; /*0x10670aaa9*/
    std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10670aab5*/
      a1: v510,
      a2: &__dst,
      a3: v363,
      a4: v364,
      a5: v365,
      a6: v366);
    if ( (__dst & 1) != 0 ) /*0x10670aac1*/
      operator delete(a1: v520, a2: v369); /*0x10670aaca*/
    v370 = *((_DWORD *)v518 + 3918); /*0x10670aad6*/
    std::string::basic_string[abi:ne200100]<0>(a1: &__dst, a2: "jdiv2TotalSharedStringCountInBlob", a3: v367, a4: v368); /*0x10670aaea*/
    v521 = (double)v370; /*0x10670ab00*/
    std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10670ab0c*/
      a1: v510,
      a2: &__dst,
      a3: v371,
      a4: v372,
      a5: v373,
      a6: v374);
    if ( (__dst & 1) != 0 ) /*0x10670ab18*/
      operator delete(a1: v520, a2: v377); /*0x10670ab21*/
    v378 = *((_DWORD *)v518 + 3925); /*0x10670ab2d*/
    std::string::basic_string[abi:ne200100]<0>(a1: &__dst, a2: "jdiv2TotalInstanceCountInBlob", a3: v375, a4: v376); /*0x10670ab41*/
    v521 = (double)v378; /*0x10670ab57*/
    std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10670ab63*/
      a1: v510,
      a2: &__dst,
      a3: v379,
      a4: v380,
      a5: v381,
      a6: v382);
    if ( (__dst & 1) != 0 ) /*0x10670ab6f*/
      operator delete(a1: v520, a2: v385); /*0x10670ab78*/
    v386 = *((_DWORD *)v518 + 3924); /*0x10670ab84*/
    std::string::basic_string[abi:ne200100]<0>( /*0x10670ab98*/
      a1: &__dst,
      a2: "jdiv2TotalInvalidInstanceCountInBlob",
      a3: v383,
      a4: v384);
    v521 = (double)v386; /*0x10670abae*/
    std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10670abba*/
      a1: v510,
      a2: &__dst,
      a3: v387,
      a4: v388,
      a5: v389,
      a6: v390);
    if ( (__dst & 1) != 0 ) /*0x10670abc6*/
      operator delete(a1: v520, a2: v393); /*0x10670abcf*/
    std::string::basic_string[abi:ne200100]<0>(a1: &__dst, a2: "percentageBlobBytesSharedStrings", a3: v391, a4: v392); /*0x10670abe2*/
    v521 = *(double *)v474.i64; /*0x10670abf6*/
    std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10670ac02*/
      a1: v510,
      a2: &__dst,
      a3: v394,
      a4: v395,
      a5: v396,
      a6: v397);
    if ( (__dst & 1) != 0 ) /*0x10670ac0e*/
      operator delete(a1: v520, a2: v400); /*0x10670ac17*/
    std::string::basic_string[abi:ne200100]<0>(a1: &__dst, a2: "percentageBlobBytesMeta", a3: v398, a4: v399); /*0x10670ac2a*/
    v521 = *(double *)v481.i64; /*0x10670ac3e*/
    std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10670ac4a*/
      a1: v510,
      a2: &__dst,
      a3: v401,
      a4: v402,
      a5: v403,
      a6: v404);
    if ( (__dst & 1) != 0 ) /*0x10670ac56*/
      operator delete(a1: v520, a2: v407); /*0x10670ac5f*/
    std::string::basic_string[abi:ne200100]<0>(a1: &__dst, a2: "percentageBlobBytesWaste", a3: v405, a4: v406); /*0x10670ac72*/
    v521 = *(double *)v475.i64; /*0x10670ac86*/
    std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10670ac92*/
      a1: v510,
      a2: &__dst,
      a3: v408,
      a4: v409,
      a5: v410,
      a6: v411);
    if ( (__dst & 1) != 0 ) /*0x10670ac9e*/
      operator delete(a1: v520, a2: v414); /*0x10670aca7*/
    std::string::basic_string[abi:ne200100]<0>(a1: &__dst, a2: "percentageBlobBytesInstance", a3: v412, a4: v413); /*0x10670acba*/
    v521 = *(double *)v482.i64; /*0x10670acce*/
    std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10670acda*/
      a1: v510,
      a2: &__dst,
      a3: v415,
      a4: v416,
      a5: v417,
      a6: v418);
    if ( (__dst & 1) != 0 ) /*0x10670ace6*/
      operator delete(a1: v520, a2: v421); /*0x10670acef*/
    std::string::basic_string[abi:ne200100]<0>(a1: &__dst, a2: "percentageUsefulInstancesCount", a3: v419, a4: v420); /*0x10670ad02*/
    v521 = v498; /*0x10670ad16*/
    std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10670ad22*/
      a1: v510,
      a2: &__dst,
      a3: v422,
      a4: v423,
      a5: v424,
      a6: v425);
    if ( (__dst & 1) != 0 ) /*0x10670ad2e*/
      operator delete(a1: v520, a2: v428); /*0x10670ad37*/
    std::string::basic_string[abi:ne200100]<0>(a1: &__dst, a2: "percentageReadTimeForSS", a3: v426, a4: v427); /*0x10670ad4a*/
    v521 = *(double *)v480.i64; /*0x10670ad5e*/
    std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10670ad6a*/
      a1: v510,
      a2: &__dst,
      a3: v429,
      a4: v430,
      a5: v431,
      a6: v432);
    if ( (__dst & 1) != 0 ) /*0x10670ad76*/
      operator delete(a1: v520, a2: v435); /*0x10670ad7f*/
    std::string::basic_string[abi:ne200100]<0>(a1: &__dst, a2: "percentageReadTimeForMetaInstances", a3: v433, a4: v434); /*0x10670ad92*/
    v521 = *(double *)v476.i64; /*0x10670ada6*/
    std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10670adb2*/
      a1: v510,
      a2: &__dst,
      a3: v436,
      a4: v437,
      a5: v438,
      a6: v439);
    if ( (__dst & 1) != 0 ) /*0x10670adbe*/
      operator delete(a1: v520, a2: v442); /*0x10670adc7*/
    std::string::basic_string[abi:ne200100]<0>( /*0x10670adda*/
      a1: &__dst,
      a2: "numFramesBetweenConnectionAcceptedAndGameLoadTime",
      a3: v440,
      a4: v441);
    v521 = v472.f64[0]; /*0x10670adee*/
    std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10670adfa*/
      a1: v510,
      a2: &__dst,
      a3: v443,
      a4: v444,
      a5: v445,
      a6: v446);
    if ( (__dst & 1) != 0 ) /*0x10670ae06*/
      operator delete(a1: v520, a2: v449); /*0x10670ae0f*/
    std::string::basic_string[abi:ne200100]<0>(a1: &__dst, a2: "averageFpsDuringJoin", a3: v447, a4: v448); /*0x10670ae22*/
    v521 = v473.f64[0]; /*0x10670ae36*/
    std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10670ae42*/
      a1: v510,
      a2: &__dst,
      a3: v450,
      a4: v451,
      a5: v452,
      a6: v453);
    if ( (__dst & 1) != 0 ) /*0x10670ae4e*/
      operator delete(a1: v520, a2: v455); /*0x10670ae57*/
    v456 = *((unsigned int *)v518 + 3925); /*0x10670ae63*/
    if ( (_DWORD)v456 != 0 ) /*0x10670ae6b*/
    {
      v457 = *((_DWORD *)v518 + 3926) % (unsigned int)v456; /*0x10670ae75*/
      LODWORD(__dst) = *((_DWORD *)v518 + 3926) / (unsigned int)v456; /*0x10670ae77*/
      v458 = *(_QWORD *)&v510[2]; /*0x10670ae7d*/
      if ( (void *)*(_QWORD *)&v510[2] >= v511[0] ) /*0x10670ae8b*/
      {
        v459 = (double *)std::vector<std::pair<std::string,double>>::__emplace_back_slow_path<char const(&)[17],unsigned int>( /*0x10670aed9*/
                           a1: v510,
                           a2: "bytesPerInstance",
                           a3: &__dst);
      }
      else
      {
        std::string::basic_string[abi:ne200100]<0>(a1: *(_QWORD *)&v510[2], a2: "bytesPerInstance", a3: v457, a4: v456); /*0x10670ae97*/
        *(double *)(v458 + 24) = (double)(int)__dst; /*0x10670aeaa*/
        v459 = (double *)(v458 + 32); /*0x10670aeb0*/
      }
      *(_QWORD *)&v510[2] = v459; /*0x10670aedc*/
    }
    else
    {
      v459 = *(double **)&v510[2]; /*0x10670aeb6*/
    }
    v460 = (int *)((char *)v518 + 15724); /*0x10670aeea*/
    if ( v459 >= v511[0] ) /*0x10670aef8*/
    {
      v463 = (double *)std::vector<std::pair<std::string,double>>::__emplace_back_slow_path<char const(&)[23],unsigned int &>( /*0x10670af35*/
                         a1: v510,
                         a2: "numJdiv2RecvDuringJoin",
                         a3: (char *)v518 + 15724);
    }
    else
    {
      std::string::basic_string[abi:ne200100]<0>(a1: v459, a2: "numJdiv2RecvDuringJoin", a3: v454, a4: v456); /*0x10670af04*/
      v459[3] = (double)*v460; /*0x10670af13*/
      v463 = v459 + 4; /*0x10670af19*/
    }
    v464 = (int *)((char *)v518 + 15720); /*0x10670af3f*/
    *(_QWORD *)&v510[2] = v463; /*0x10670af46*/
    if ( v463 >= v511[0] ) /*0x10670af54*/
    {
      v465 = std::vector<std::pair<std::string,double>>::__emplace_back_slow_path<char const(&)[25],unsigned int &>( /*0x10670af91*/
               a1: v510,
               a2: "bytesJdiv2RecvDuringJoin",
               a3: (char *)v518 + 15720);
    }
    else
    {
      std::string::basic_string[abi:ne200100]<0>(a1: v463, a2: "bytesJdiv2RecvDuringJoin", a3: v461, a4: v462); /*0x10670af60*/
      v463[3] = (double)*v464; /*0x10670af6f*/
      v465 = (__int64)(v463 + 4); /*0x10670af75*/
    }
    *(_QWORD *)&v510[2] = v465; /*0x10670af9b*/
    RBX::Analytics::EphemeralCounter::bulkReportStats(a1: v510, a2: 0); /*0x10670afa4*/
    LOBYTE(__dst) = 0; /*0x10670afb2*/
    v526 = 0; /*0x10670afb4*/
    v466 = v518; /*0x10670afc1*/
    RBX::Network::Replicator::reportTelemetryV2<unsigned long long>( /*0x10670afd2*/
      a1: v518,
      a2: &RBX::Telemetry::kInlineNetAssetBytesJoin,
      a3: *(_QWORD *)v484,
      a4: &__dst);
    RBX::Network::Replicator::reportTelemetryV2<unsigned long long>( /*0x10670afef*/
      a1: v466,
      a2: &RBX::Telemetry::kTotalNetAssetBytesJoin,
      a3: *(_QWORD *)v486,
      a4: &__dst);
    RBX::Network::Replicator::reportTelemetryV2<unsigned long long>( /*0x10670b00c*/
      a1: v466,
      a2: &RBX::Telemetry::kInlineNetAssetsJoin,
      a3: *(_QWORD *)v483,
      a4: &__dst);
    RBX::Network::Replicator::reportTelemetryV2<unsigned long long>( /*0x10670b029*/
      a1: v466,
      a2: &RBX::Telemetry::kTotalNetAssetsJoin,
      a3: *(_QWORD *)v485,
      a4: &__dst);
    if ( v526 == 1 ) /*0x10670b035*/
      RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)&__dst); /*0x10670b045*/
    if ( (v513[0] & 1) != 0 ) /*0x10670b051*/
      operator delete(a1: (RBX::Memory *)v514, a2: v467); /*0x10670b05a*/
    *(_QWORD *)&__dst = v510; /*0x10670b066*/
    std::vector<std::pair<std::string,double>>::__destroy_vector::operator()[abi:ne200100](a1: &__dst); /*0x10670b069*/
  }
  *(_QWORD *)&__dst = &v499; /*0x10670b075*/
  std::vector<std::pair<std::string,double>>::__destroy_vector::operator()[abi:ne200100](a1: &__dst); /*0x10670b078*/
  RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::~WriterT(a1: v478); /*0x10670b084*/
  RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::~WriterT(a1: v477); /*0x10670b090*/
  RBX::Analytics::InfluxDb::Points::~Points(this: v528); /*0x10670b09c*/
  if ( v470 == 1 ) /*0x10670b0a8*/
    RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v469); /*0x10670b0b8*/
  return __stack_chk_guard; /*0x10670b0cd*/
}

// Address: 0x10670b798 | Name: __ZN3RBX7Network16ClientReplicator26prepareDumpOrReportProfileEv
__int64 __fastcall RBX::Network::ClientReplicator::prepareDumpOrReportProfile(
        RBX::Network::ClientReplicator *this,
        RBX::Instance *a2)
{
  __int64 v3; // rax
  __int64 v4; // r13
  int v5; // ebx
  __int64 v6; // rdx
  __int64 v7; // rcx
  unsigned __int64 v8; // rsi
  __int64 v9; // r15
  __int64 v10; // r14
  __int64 v11; // rdx
  __int64 v12; // rcx
  __int64 v13; // r15
  __int64 v14; // rax
  __int64 v15; // rax
  std::__shared_weak_count *v17[2]; // [rsp+10h] [rbp-440h] BYREF
  std::__shared_weak_count *v18[2]; // [rsp+20h] [rbp-430h]
  int v19; // [rsp+30h] [rbp-420h]
  void *v20[49]; // [rsp+38h] [rbp-418h] BYREF
  __int128 v21; // [rsp+1C0h] [rbp-290h] BYREF
  __int64 v22; // [rsp+1D0h] [rbp-280h]
  int v23; // [rsp+1D8h] [rbp-278h]
  char v24; // [rsp+1DCh] [rbp-274h]
  __int128 v25; // [rsp+1E0h] [rbp-270h] BYREF
  __int64 v26; // [rsp+1F0h] [rbp-260h]
  __int64 v27; // [rsp+1F8h] [rbp-258h]
  __int128 v28; // [rsp+200h] [rbp-250h]
  _BYTE v29[32]; // [rsp+210h] [rbp-240h] BYREF
  _BYTE *v30; // [rsp+230h] [rbp-220h]
  void *v31[51]; // [rsp+248h] [rbp-208h] BYREF
  __int64 v32; // [rsp+3E0h] [rbp-70h]
  int v33; // [rsp+3E8h] [rbp-68h]
  char v34; // [rsp+3ECh] [rbp-64h]
  __int128 v35; // [rsp+3F0h] [rbp-60h]
  __int64 v36; // [rsp+400h] [rbp-50h]
  __int64 v37; // [rsp+408h] [rbp-48h]
  __int128 v38; // [rsp+410h] [rbp-40h]

  v3 = RBX::DataModel::get(this, a2); /*0x10670b7bd*/
  v4 = RBX::ServiceProvider::create<RBX::TimerService>(a1: v3 + 464, a2: 0); /*0x10670b7d0*/
  RBX::weak_from<RBX::Network::ClientReplicator>(a1: v17, a2: (__int64)this); /*0x10670b7dd*/
  v5 = *((_DWORD *)this + 5974); /*0x10670b7e2*/
  RBX::Analytics::InfluxDb::Points::Points(a1: v31, a2: 0xFFFFFFFFLL, a3: 0, a4: 0); /*0x10670b7f9*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670b814*/
    this: (RBX::Analytics::InfluxDb::Points *)v31,
    a2: "streamingEnabled",
    a3: *((_BYTE *)this + 15544));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670b830*/
    this: (RBX::Analytics::InfluxDb::Points *)v31,
    a2: "deserializePacketsJob_total",
    a3: *((double *)this + 1987));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670b84a*/
    this: (RBX::Analytics::InfluxDb::Points *)v31,
    a2: "deserializeReportGroup",
    a3: *((_DWORD *)this + 3946));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670b864*/
    this: (RBX::Analytics::InfluxDb::Points *)v31,
    a2: "processingReportGroup",
    a3: *((_DWORD *)this + 3947));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670b880*/
    this: (RBX::Analytics::InfluxDb::Points *)v31,
    a2: "connectionAcceptedToGameLoadTime",
    a3: *((double *)this + 1990));
  *(_OWORD *)v18 = *(_OWORD *)v17; /*0x10670b894*/
  if ( v17[1] != nullptr ) /*0x10670b89f*/
    _InterlockedIncrement64((volatile signed __int64 *)v17[1] + 2); /*0x10670b8a1*/
  v19 = v5; /*0x10670b8ad*/
  RBX::SmallDenseMap<std::string,std::string,8u,RBX::Analytics::InfluxDb::AnalyticsPointsDenseMapInfo,RBX::detail::DenseMapPair<std::string,std::string>>::SmallDenseMap( /*0x10670b8b7*/
    a1: v20,
    a2: (__int64)v31,
    a3: v6,
    a4: v7);
  if ( ((__int64)v31[49] & 1) != 0 ) /*0x10670b8c7*/
  {
    std::string::__init_copy_ctor_external(a1: &v21, a2: v32, a3: v31[50]); /*0x10670b8e7*/
  }
  else
  {
    v22 = v32; /*0x10670b8d1*/
    v21 = *(_OWORD *)&v31[49]; /*0x10670b8d9*/
  }
  v24 = v34; /*0x10670b8f6*/
  v23 = v33; /*0x10670b8fe*/
  if ( (v35 & 1) != 0 ) /*0x10670b907*/
  {
    std::string::__init_copy_ctor_external(a1: &v25, a2: v36, a3: *((_QWORD *)&v35 + 1)); /*0x10670b92d*/
  }
  else
  {
    v26 = v36; /*0x10670b911*/
    v25 = v35; /*0x10670b91a*/
  }
  v27 = v37; /*0x10670b936*/
  v28 = v38; /*0x10670b946*/
  if ( *((_QWORD *)&v38 + 1) != 0 ) /*0x10670b951*/
    _InterlockedIncrement64((volatile signed __int64 *)(*((_QWORD *)&v38 + 1) + 8LL)); /*0x10670b953*/
  v30 = nullptr; /*0x10670b958*/
  v9 = operator new(a1: (RBX::Memory *)0x1F8, a2: v8); /*0x10670b96d*/
  v10 = v9; /*0x10670b977*/
  *(_QWORD *)v9 = &off_10CAA8C98; /*0x10670b981*/
  *(_OWORD *)(v9 + 8) = *(_OWORD *)v18; /*0x10670b98c*/
  *(_OWORD *)v18 = 0; /*0x10670b996*/
  *(_DWORD *)(v9 + 24) = v19; /*0x10670b9a4*/
  RBX::SmallDenseMap<std::string,std::string,8u,RBX::Analytics::InfluxDb::AnalyticsPointsDenseMapInfo,RBX::detail::DenseMapPair<std::string,std::string>>::SmallDenseMap( /*0x10670b9b6*/
    a1: (_BYTE *)(v9 + 32),
    a2: (__int64)v20,
    a3: v11,
    a4: v12);
  if ( (v21 & 1) != 0 ) /*0x10670b9c9*/
  {
    std::string::__init_copy_ctor_external(a1: v9 + 424, a2: v22, a3: *((_QWORD *)&v21 + 1)); /*0x10670b9f7*/
  }
  else
  {
    *(_QWORD *)(v9 + 440) = v22; /*0x10670b9d6*/
    *(_OWORD *)(v9 + 424) = v21; /*0x10670b9de*/
  }
  *(_BYTE *)(v9 + 452) = v24; /*0x10670ba06*/
  *(_DWORD *)(v9 + 448) = v23; /*0x10670ba0f*/
  v13 = v9 + 456; /*0x10670ba16*/
  if ( (v25 & 1) != 0 ) /*0x10670ba21*/
  {
    std::string::__init_copy_ctor_external(a1: v13, a2: v26, a3: *((_QWORD *)&v25 + 1)); /*0x10670ba4a*/
  }
  else
  {
    *(_QWORD *)(v13 + 16) = v26; /*0x10670ba28*/
    *(_OWORD *)v13 = v25; /*0x10670ba32*/
  }
  *(_QWORD *)(v10 + 480) = v27; /*0x10670ba56*/
  v14 = *((_QWORD *)&v28 + 1); /*0x10670ba5d*/
  *(_OWORD *)(v10 + 488) = v28; /*0x10670ba6b*/
  if ( v14 != 0 ) /*0x10670ba76*/
    _InterlockedIncrement64((volatile signed __int64 *)(v14 + 8)); /*0x10670ba78*/
  v30 = (_BYTE *)v10; /*0x10670ba84*/
  RBX::TimerService::delay(a1: v4, a2: v29, a3: (double)(DFInt::ClientDelayCaptureInitExpStatsMs / 1000)); /*0x10670bab4*/
  if ( v30 == v29 ) /*0x10670bac3*/
  {
    v15 = 32; /*0x10670bad1*/
    goto LABEL_23; /*0x10670bad1*/
  }
  v15 = 40; /*0x10670bac5*/
  if ( v30 != nullptr ) /*0x10670bacd*/
LABEL_23:
    (*(void (**)(void))(*(_QWORD *)v30 + v15))(); /*0x10670bad6*/
  RBX::Analytics::InfluxDb::Points::~Points(this: v20); /*0x10670badc*/
  if ( v18[1] != nullptr ) /*0x10670baf2*/
    std::__shared_weak_count::__release_weak(this: v18[1]); /*0x10670baf4*/
  RBX::Analytics::InfluxDb::Points::~Points(this: v31); /*0x10670bb00*/
  if ( v17[1] != nullptr ) /*0x10670bb0f*/
    std::__shared_weak_count::__release_weak(this: v17[1]); /*0x10670bb11*/
  return __stack_chk_guard; /*0x10670bb26*/
}

// Address: 0x10670bc28 | Name: __ZN3RBX7Network16ClientReplicator17onClientQoSReportEhRKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
void __fastcall RBX::Network::ClientReplicator::onClientQoSReport(_BYTE *a1, unsigned __int64 a2, __int128 *a3)
{
  char v4; // r15
  RBX::Network::Item *v6; // rbx
  void *v7; // rsi
  __int128 v8; // [rsp+0h] [rbp-40h] BYREF
  void *v9; // [rsp+10h] [rbp-30h]

  if ( a1[15549] == 1 ) /*0x10670bc3e*/
  {
    v4 = a2; /*0x10670bc43*/
    v6 = (RBX::Network::Item *)operator new(a1: (RBX::Memory *)0x60, a2); /*0x10670bc53*/
    if ( (*(_BYTE *)a3 & 1) != 0 ) /*0x10670bc5b*/
    {
      std::string::__init_copy_ctor_external(a1: &v8, a2: *((_QWORD *)a3 + 2), a3: *((_QWORD *)a3 + 1)); /*0x10670bc7f*/
    }
    else
    {
      v9 = *((void **)a3 + 2); /*0x10670bc62*/
      v8 = *a3; /*0x10670bc6b*/
    }
    RBX::Network::Replicator::ClientQoSItem::ClientQoSItem( /*0x10670bc95*/
      a1: (__int64)v6,
      a2: (RBX::Network::Replicator *)a1,
      a3: (__int64)&v8,
      a4: v4);
    RBX::Network::ItemQueue::push_back(this: (RBX::Network::ItemQueue *)(a1 + 14536), a2: v6); /*0x10670bcaa*/
    if ( (v8 & 1) != 0 ) /*0x10670bcb3*/
      operator delete(a1: (RBX::Memory *)v9, a2: v7); /*0x10670bcb9*/
  }
}

// Address: 0x10670be22 | Name: __ZN3RBX7Network16ClientReplicator25getAnalyticsPlaySessionIdEv
RBX::Network::ClientReplicator *__fastcall RBX::Network::ClientReplicator::getAnalyticsPlaySessionId(
        RBX::Network::ClientReplicator *this,
        __int64 a2,
        __int64 a3,
        __int64 a4)
{
  __int64 v5; // r14
  __int64 v6; // r15
  __int64 v7; // rax
  __int64 v9; // r14

  v5 = *(_QWORD *)(a2 + 104); /*0x10670be2f*/
  if ( v5 != 0 /*0x10670be5b*/
    && (v6 = *(_QWORD *)(v5 + 24),
        v7 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>(a1: this),
        a3 = *(unsigned __int16 *)(v7 + 440),
        (unsigned int)(a4 = *(unsigned __int16 *)(v6 + 440) - (unsigned int)a3) <= *(unsigned __int16 *)(v7 + 442)) )
  {
    if ( (*(_BYTE *)(v5 + 568) & 1) != 0 ) /*0x10670be82*/
    {
      std::string::__init_copy_ctor_external(a1: this, a2: *(_QWORD *)(v5 + 584), a3: *(_QWORD *)(v5 + 576)); /*0x10670bead*/
    }
    else
    {
      v9 = v5 + 568; /*0x10670be84*/
      *((_QWORD *)this + 2) = *(_QWORD *)(v9 + 16); /*0x10670be8f*/
      *(_OWORD *)this = *(_OWORD *)v9; /*0x10670be97*/
    }
  }
  else
  {
    std::string::basic_string[abi:ne200100]<0>(a1: this, a2: "", a3, a4); /*0x10670be67*/
  }
  return this; /*0x10670be73*/
}

// Address: 0x10670beb4 | Name: __ZN3RBX7Network16ClientReplicator24getNumPrefetchesAndResetEv
__int64 __fastcall RBX::Network::ClientReplicator::getNumPrefetchesAndReset(RBX::Network::ClientReplicator *this)
{
  __int64 result; // rax

  result = *((unsigned int *)this + 5864); /*0x10670beb8*/
  *((_DWORD *)this + 5864) = 0; /*0x10670bebe*/
  return result; /*0x10670bec8*/
}

// Address: 0x10670beca | Name: __ZN3RBX7Network16ClientReplicator17getNumGCsAndResetEv
__int64 __fastcall RBX::Network::ClientReplicator::getNumGCsAndReset(RBX::Network::ClientReplicator *this)
{
  __int64 result; // rax

  result = *((_QWORD *)this + 2933); /*0x10670bece*/
  *((_QWORD *)this + 2933) = 0; /*0x10670bed5*/
  return result; /*0x10670bee0*/
}

// Address: 0x10670bee2 | Name: __ZN3RBX7Network16ClientReplicator30getAvgPrefetchDistanceAndResetEv
__int64 __fastcall RBX::Network::ClientReplicator::getAvgPrefetchDistanceAndReset(RBX::Network::ClientReplicator *this)
{
  __int64 result; // rax

  result = *((unsigned int *)this + 5864); /*0x10670bee6*/
  *((_QWORD *)this + 2931) = 0; /*0x10670bf06*/
  return result; /*0x10670bf11*/
}

// Address: 0x10670bf14 | Name: __ZN3RBX7Network16ClientReplicator11readTagItemEPNS0_19DeserializedTagItemE
char *__fastcall RBX::Network::ClientReplicator::readTagItem(
        RBX::Network::ClientReplicator *this,
        RBX::Network::DeserializedTagItem *a2)
{
  return RBX::Network::ClientReplicator::processTag(this, a2: *((_DWORD *)a2 + 8)); /*0x10670bf1b*/
}

// Address: 0x10670bf22 | Name: __ZN3RBX7Network16ClientReplicator9readStatsERNS0_13NetworkStreamE
RBX::Network::ClientReplicator *__fastcall RBX::Network::ClientReplicator::readStats(
        RBX::Network::ClientReplicator *this,
        RBX::Network::NetworkStream *a2,
        RBX::Network::NetworkStream *a3)
{
  __int64 v4; // rax
  unsigned __int64 v5; // rsi
  __int64 v6; // rax
  unsigned __int64 v7; // rsi
  __int64 v8; // rax
  unsigned __int64 v9; // rsi
  __int64 v10; // rax
  unsigned __int64 v11; // rsi
  __int64 v12; // rax
  int Int32; // eax
  int v14; // xmm0_4
  int v15; // xmm0_4
  void *v16; // rsi
  void *v17; // rsi
  std::__shared_weak_count *v18; // rbx
  std::__shared_weak_count *v19; // rbx
  int v20; // xmm0_4
  int v21; // xmm0_4
  int v22; // xmm0_4
  unsigned __int64 v23; // rsi
  __int64 v24; // rax
  __int64 v25; // rbx
  __int64 v26; // rdi
  __int64 v27; // rsi
  __int64 v28; // rdi
  __int64 v29; // rsi
  __int64 v30; // rbx
  __int64 v31; // rdi
  __int64 v32; // rsi
  __int64 v33; // rbx
  std::__shared_weak_count *v34; // rbx
  std::__shared_weak_count *v35; // r14
  std::__shared_weak_count *v36; // r13
  void *v37; // rsi
  std::__shared_weak_count *v38; // rbx
  std::__shared_weak_count *v39; // rbx
  char Bool; // bl
  void *v41; // rsi
  std::__shared_weak_count *v42; // r14
  int v43; // xmm0_4
  unsigned __int64 v44; // rsi
  __int64 v45; // rax
  __int64 v46; // r13
  __int64 v47; // rdi
  __int64 v48; // rsi
  __int64 v49; // rdi
  __int64 v50; // r13
  std::__shared_weak_count *v51; // r13
  std::__shared_weak_count *v52; // r14
  std::__shared_weak_count *v53; // rbx
  void *v54; // rsi
  std::__shared_weak_count *v55; // r14
  std::__shared_weak_count *v56; // r14
  void *v57; // rsi
  char v58; // r13
  std::__shared_weak_count *v59; // r14
  int v60; // xmm0_4
  int v61; // xmm0_4
  int v62; // xmm0_4
  int v63; // xmm0_4
  unsigned __int64 v64; // rsi
  int v65; // xmm0_4
  char v66; // r14
  __int64 *EngineNetConfiguration; // rax
  char v68; // r14
  __int64 v69; // rax
  __int64 v70; // rbx
  void *v71; // rsi
  __int64 v72; // rbx
  void *v73; // rsi
  __int64 v74; // rbx
  void *v75; // rsi
  __int64 v76; // rbx
  void *v77; // rsi
  __int64 v78; // rbx
  void *v79; // rsi
  __int64 v80; // rbx
  __int128 v81; // xmm0
  void *v82; // rsi
  std::__shared_weak_count *v83; // rbx
  std::__shared_weak_count *v84; // rbx
  __int64 v85; // rbx
  __int128 v86; // xmm0
  void *v87; // rsi
  std::__shared_weak_count *v88; // rbx
  std::__shared_weak_count *v89; // rbx
  __int64 v90; // rbx
  __int128 v91; // xmm0
  void *v92; // rsi
  std::__shared_weak_count *v93; // rbx
  std::__shared_weak_count *v94; // rbx
  __int64 v95; // rbx
  __int128 v96; // xmm0
  __int64 v97; // rdx
  __int64 v98; // rcx
  __int64 v99; // rdi
  void *v100; // rsi
  std::__shared_weak_count *v101; // rbx
  std::__shared_weak_count *v102; // rbx
  __int64 v103; // rbx
  __int64 v104; // rdx
  __int64 v105; // rcx
  __int64 v106; // rdi
  void *v107; // rsi
  __int64 v108; // rbx
  void *v109; // rsi
  std::__shared_weak_count *v110; // rbx
  std::__shared_weak_count *v111; // rbx
  std::__shared_weak_count *v112; // rbx
  std::__shared_weak_count *v113; // rbx
  std::__shared_weak_count *v114; // rbx
  __int64 v116; // rax
  char v117[8]; // [rsp+0h] [rbp-240h] BYREF
  std::__shared_weak_count *v118; // [rsp+8h] [rbp-238h]
  std::__shared_weak_count *v119[2]; // [rsp+10h] [rbp-230h]
  std::__shared_weak_count *v120[2]; // [rsp+20h] [rbp-220h]
  std::__shared_weak_count *v121[2]; // [rsp+30h] [rbp-210h] BYREF
  std::__shared_weak_count *v122[2]; // [rsp+40h] [rbp-200h] BYREF
  std::__shared_weak_count *v123[2]; // [rsp+50h] [rbp-1F0h] BYREF
  std::__shared_weak_count *v124[2]; // [rsp+60h] [rbp-1E0h] BYREF
  __int128 v125; // [rsp+70h] [rbp-1D0h] BYREF
  void *v126; // [rsp+80h] [rbp-1C0h]
  __int128 v127; // [rsp+90h] [rbp-1B0h] BYREF
  void *v128; // [rsp+A0h] [rbp-1A0h]
  int v129; // [rsp+A8h] [rbp-198h] BYREF
  int v130; // [rsp+ACh] [rbp-194h]
  int v131; // [rsp+B0h] [rbp-190h]
  int v132; // [rsp+B4h] [rbp-18Ch]
  int v133; // [rsp+B8h] [rbp-188h]
  int v134; // [rsp+BCh] [rbp-184h]
  std::__shared_weak_count *v135[2]; // [rsp+C0h] [rbp-180h]
  RBX::Network::Replicator *v136; // [rsp+D0h] [rbp-170h]
  std::__shared_weak_count *v137; // [rsp+D8h] [rbp-168h] BYREF
  std::__shared_weak_count *v138; // [rsp+E0h] [rbp-160h]
  int v139; // [rsp+E8h] [rbp-158h] BYREF
  int v140; // [rsp+ECh] [rbp-154h] BYREF
  int v141; // [rsp+F0h] [rbp-150h]
  int v142; // [rsp+F4h] [rbp-14Ch]
  RBX::Network::ClientReplicator *v143; // [rsp+F8h] [rbp-148h]
  std::__shared_weak_count *v144[2]; // [rsp+100h] [rbp-140h] BYREF
  void *v145[8]; // [rsp+110h] [rbp-130h] BYREF
  _BYTE v146[24]; // [rsp+150h] [rbp-F0h] BYREF
  std::__shared_weak_count *v147; // [rsp+168h] [rbp-D8h] BYREF
  std::__shared_weak_count *v148; // [rsp+170h] [rbp-D0h]
  __int128 v149; // [rsp+1A8h] [rbp-98h] BYREF
  void *v150[2]; // [rsp+1B8h] [rbp-88h] BYREF
  __int64 v151; // [rsp+1C8h] [rbp-78h]
  _BYTE v152[64]; // [rsp+1D0h] [rbp-70h] BYREF

  v136 = a2; /*0x10670bf39*/
  v143 = this; /*0x10670bf40*/
  v4 = operator new(a1: (RBX::Memory *)0x28, (unsigned __int64)a2); /*0x10670bf5a*/
  *(_OWORD *)v4 = 0; /*0x10670bf62*/
  *(_OWORD *)(v4 + 16) = 0; /*0x10670bf65*/
  *(_QWORD *)(v4 + 32) = 0; /*0x10670bf69*/
  *(_DWORD *)(v4 + 32) = 1065353216; /*0x10670bf71*/
  std::shared_ptr<RBX::Reflection::ValueTable>::shared_ptr[abi:ne200100]<RBX::Reflection::ValueTable,0>( /*0x10670bf82*/
    a1: v121,
    a2: v4);
  v6 = operator new(a1: (RBX::Memory *)0x28, a2: v5); /*0x10670bf8c*/
  *(_OWORD *)(v6 + 16) = 0; /*0x10670bf94*/
  *(_OWORD *)v6 = 0; /*0x10670bf98*/
  *(_QWORD *)(v6 + 32) = 0; /*0x10670bf9b*/
  *(_DWORD *)(v6 + 32) = 1065353216; /*0x10670bfa3*/
  std::shared_ptr<RBX::Reflection::ValueTable>::shared_ptr[abi:ne200100]<RBX::Reflection::ValueTable,0>( /*0x10670bfb4*/
    a1: v122,
    a2: v6);
  v8 = operator new(a1: (RBX::Memory *)0x28, a2: v7); /*0x10670bfbe*/
  *(_OWORD *)(v8 + 16) = 0; /*0x10670bfc6*/
  *(_OWORD *)v8 = 0; /*0x10670bfca*/
  *(_QWORD *)(v8 + 32) = 0; /*0x10670bfcd*/
  *(_DWORD *)(v8 + 32) = 1065353216; /*0x10670bfd5*/
  std::shared_ptr<RBX::Reflection::ValueTable>::shared_ptr[abi:ne200100]<RBX::Reflection::ValueTable,0>( /*0x10670bfe6*/
    a1: v123,
    a2: v8);
  v10 = operator new(a1: (RBX::Memory *)0x28, a2: v9); /*0x10670bff0*/
  *(_OWORD *)(v10 + 16) = 0; /*0x10670bff8*/
  *(_OWORD *)v10 = 0; /*0x10670bffc*/
  *(_QWORD *)(v10 + 32) = 0; /*0x10670bfff*/
  *(_DWORD *)(v10 + 32) = 1065353216; /*0x10670c007*/
  std::shared_ptr<RBX::Reflection::ValueTable>::shared_ptr[abi:ne200100]<RBX::Reflection::ValueTable,0>( /*0x10670c018*/
    a1: v124,
    a2: v10);
  v12 = operator new(a1: (RBX::Memory *)0x28, a2: v11); /*0x10670c022*/
  *(_OWORD *)(v12 + 16) = 0; /*0x10670c02a*/
  *(_OWORD *)v12 = 0; /*0x10670c02e*/
  *(_QWORD *)(v12 + 32) = 0; /*0x10670c031*/
  *(_DWORD *)(v12 + 32) = 1065353216; /*0x10670c039*/
  std::shared_ptr<RBX::Reflection::ValueTable>::shared_ptr[abi:ne200100]<RBX::Reflection::ValueTable,0>( /*0x10670c04a*/
    a1: v117,
    a2: v12);
  v125 = 0; /*0x10670c052*/
  v126 = nullptr; /*0x10670c05b*/
  v128 = nullptr; /*0x10670c062*/
  v127 = 0; /*0x10670c069*/
  Int32 = RBX::Network::NetworkStream::readInt32(this: a3); /*0x10670c073*/
  if ( Int32 >= 9 ) /*0x10670c07b*/
  {
    RBX::Network::NetworkStream::readFloat(this: a3); /*0x10670c080*/
    v141 = v14; /*0x10670c085*/
    RBX::Network::NetworkStream::readFloat(this: a3); /*0x10670c090*/
    v142 = v15; /*0x10670c095*/
LABEL_4:
    RBX::Network::Replicator::StatsItem::readServerLuauHeapData( /*0x10670c0bb*/
      this: (RBX::Network::Replicator::StatsItem *)&v149,
      a2: v136,
      a3);
    if ( (v127 & 1) != 0 ) /*0x10670c0d8*/
      operator delete(a1: (RBX::Memory *)v128, a2: v16); /*0x10670c0e1*/
    v128 = v150[0]; /*0x10670c0ed*/
    v127 = v149; /*0x10670c0fb*/
    goto LABEL_7; /*0x10670c0fb*/
  }
  v141 = 0; /*0x10670c0a2*/
  v142 = 0; /*0x10670c0aa*/
  if ( Int32 == 8 ) /*0x10670c0b5*/
    goto LABEL_4; /*0x10670c0b5*/
  v142 = 0; /*0x10670d192*/
  v141 = 0; /*0x10670d19a*/
  if ( Int32 >= 7 ) /*0x10670d1a5*/
  {
LABEL_7:
    RBX::Network::Replicator::StatsItem::readServerScriptProfilingData( /*0x10670c102*/
      this: (RBX::Network::Replicator::StatsItem *)&v149,
      a2: v136,
      a3);
    if ( (v125 & 1) != 0 ) /*0x10670c11f*/
      operator delete(a1: (RBX::Memory *)v126, a2: v17); /*0x10670c128*/
    v126 = v150[0]; /*0x10670c134*/
    v125 = v149; /*0x10670c142*/
    goto LABEL_10; /*0x10670c142*/
  }
  v141 = 0; /*0x10670d1ab*/
  v142 = 0; /*0x10670d1b3*/
  if ( Int32 != 6 ) /*0x10670d1be*/
  {
    v142 = 0; /*0x10670d1c4*/
    v141 = 0; /*0x10670d1cc*/
    if ( Int32 < 3 ) /*0x10670d1d7*/
      goto LABEL_20; /*0x10670d1d7*/
    goto LABEL_15; /*0x10670d1d7*/
  }
LABEL_10:
  *(_OWORD *)v119 = *(_OWORD *)v124; /*0x10670c149*/
  if ( v124[1] != nullptr ) /*0x10670c161*/
    _InterlockedIncrement64((volatile signed __int64 *)v124[1] + 1); /*0x10670c163*/
  RBX::Network::Replicator::StatsItem::readServerMemoryStats(a1: (int)a3); /*0x10670c172*/
  v18 = v119[1]; /*0x10670c177*/
  if ( v119[1] != nullptr /*0x10670c193*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)v119[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v18 + 16LL))(a1: v18); /*0x10670c19b*/
    std::__shared_weak_count::__release_weak(this: v18); /*0x10670c1a1*/
  }
LABEL_15:
  *(_OWORD *)v120 = *(_OWORD *)v123; /*0x10670c1a6*/
  if ( v123[1] != nullptr ) /*0x10670c1be*/
    _InterlockedIncrement64((volatile signed __int64 *)v123[1] + 1); /*0x10670c1c0*/
  RBX::Network::Replicator::StatsItem::readDataStoreStats(this: a3); /*0x10670c1cf*/
  v19 = v120[1]; /*0x10670c1d4*/
  if ( v120[1] != nullptr /*0x10670c1f0*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)v120[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v19 + 16LL))(a1: v19); /*0x10670c1f8*/
    std::__shared_weak_count::__release_weak(this: v19); /*0x10670c1fe*/
  }
LABEL_20:
  if ( (unsigned __int8)RBX::Network::NetworkStream::readBool(this: a3) == 0 ) /*0x10670c20d*/
  {
    do /*0x10670c515*/
    {
      RBX::Network::Replicator::getReadPayloadLimit(this: v136); /*0x10670c228*/
      RBX::Network::NetworkStream::readString(this: (RBX::Network::NetworkStream *)v144, a2: (int)a3); /*0x10670c239*/
      RBX::Network::NetworkStream::readFloat(this: a3); /*0x10670c241*/
      v139 = v20; /*0x10670c246*/
      RBX::Network::NetworkStream::readFloat(this: a3); /*0x10670c251*/
      v140 = v21; /*0x10670c256*/
      RBX::Network::NetworkStream::readFloat(this: a3); /*0x10670c261*/
      v129 = v22; /*0x10670c266*/
      v24 = operator new(a1: (RBX::Memory *)0x18, a2: v23); /*0x10670c273*/
      *(_OWORD *)v24 = 0; /*0x10670c27b*/
      *(_QWORD *)(v24 + 16) = 0; /*0x10670c27e*/
      std::shared_ptr<std::vector<RBX::Reflection::Variant>>::shared_ptr[abi:ne200100]<std::vector<RBX::Reflection::Variant>,0>( /*0x10670c290*/
        a1: &v137,
        a2: v24);
      v25 = (__int64)v137; /*0x10670c295*/
      v149 = (unsigned __int64)RBX::Reflection::Type::getSingleton<float>(a1: v26, a2: v27); /*0x10670c2a1*/
      RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<float>(a1: (char *)&v149 + 8, a2: &v139); /*0x10670c2c1*/
      std::vector<RBX::Reflection::Variant>::push_back[abi:ne200100](a1: v25, a2: (__int64)&v149); /*0x10670c2cc*/
      if ( *((_QWORD *)&v149 + 1) != 0 ) /*0x10670c2db*/
        (*(void (__fastcall **)(void **))(*((_QWORD *)&v149 + 1) + 16LL))(a1: v150); /*0x10670c2e4*/
      v30 = (__int64)v137; /*0x10670c2e7*/
      v149 = (unsigned __int64)RBX::Reflection::Type::getSingleton<float>(a1: v28, a2: v29); /*0x10670c2f3*/
      RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<float>(a1: (char *)&v149 + 8, a2: &v140); /*0x10670c313*/
      std::vector<RBX::Reflection::Variant>::push_back[abi:ne200100](a1: v30, a2: (__int64)&v149); /*0x10670c31e*/
      if ( *((_QWORD *)&v149 + 1) != 0 ) /*0x10670c32d*/
        (*(void (__fastcall **)(void **))(*((_QWORD *)&v149 + 1) + 16LL))(a1: v150); /*0x10670c336*/
      v33 = (__int64)v137; /*0x10670c339*/
      v149 = (unsigned __int64)RBX::Reflection::Type::getSingleton<float>(a1: v31, a2: v32); /*0x10670c345*/
      RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<float>(a1: (char *)&v149 + 8, a2: &v129); /*0x10670c365*/
      std::vector<RBX::Reflection::Variant>::push_back[abi:ne200100](a1: v33, a2: (__int64)&v149); /*0x10670c370*/
      if ( *((_QWORD *)&v149 + 1) != 0 ) /*0x10670c37f*/
        (*(void (__fastcall **)(void **))(*((_QWORD *)&v149 + 1) + 16LL))(a1: v150); /*0x10670c388*/
      v34 = v121[0]; /*0x10670c38b*/
      v35 = v137; /*0x10670c392*/
      v36 = v138; /*0x10670c399*/
      v135[0] = v137; /*0x10670c3a0*/
      v135[1] = v138; /*0x10670c3a7*/
      if ( v138 != nullptr ) /*0x10670c3b1*/
        _InterlockedIncrement64((volatile signed __int64 *)v138 + 1); /*0x10670c3b3*/
      if ( ((__int64)v144[0] & 1) != 0 ) /*0x10670c3bf*/
      {
        std::string::__init_copy_ctor_external(a1: v146, a2: v145[0], a3: v144[1]); /*0x10670c3f0*/
      }
      else
      {
        *(void **)&v146[16] = v145[0]; /*0x10670c3c8*/
        *(_OWORD *)v146 = *(_OWORD *)v144; /*0x10670c3d6*/
      }
      v147 = v35; /*0x10670c3f5*/
      v148 = v36; /*0x10670c3fc*/
      *(_OWORD *)v135 = 0; /*0x10670c406*/
      std::pair<std::string const,RBX::Reflection::Variant>::pair[abi:ne200100]<std::string,std::shared_ptr<std::vector<RBX::Reflection::Variant> const>,0>( /*0x10670c41a*/
        a1: &v149,
        a2: v146);
      std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::pair<std::string const,RBX::Reflection::Variant>>( /*0x10670c428*/
        a1: v34,
        a2: &v149);
      if ( v151 != 0 ) /*0x10670c434*/
        (*(void (__fastcall **)(_BYTE *))(v151 + 16))(a1: v152); /*0x10670c43a*/
      if ( (v149 & 1) != 0 ) /*0x10670c444*/
        operator delete(a1: (RBX::Memory *)v150[0], a2: v37); /*0x10670c44d*/
      v38 = v148; /*0x10670c452*/
      if ( v148 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v148 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10670c46e*/
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v38 + 16LL))(a1: v38); /*0x10670c476*/
        std::__shared_weak_count::__release_weak(this: v38); /*0x10670c47c*/
      }
      if ( (v146[0] & 1) != 0 ) /*0x10670c488*/
        operator delete(a1: *(RBX::Memory **)&v146[16], a2: v37); /*0x10670c491*/
      v39 = v135[1]; /*0x10670c496*/
      if ( v135[1] != nullptr /*0x10670c4b2*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v135[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v39 + 16LL))(a1: v39); /*0x10670c4ba*/
        std::__shared_weak_count::__release_weak(this: v39); /*0x10670c4c0*/
      }
      Bool = RBX::Network::NetworkStream::readBool(this: a3); /*0x10670c4cd*/
      v42 = v138; /*0x10670c4cf*/
      if ( v138 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v138 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10670c4eb*/
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v42 + 16LL))(a1: v42); /*0x10670c4f3*/
        std::__shared_weak_count::__release_weak(this: v42); /*0x10670c4f9*/
      }
      if ( ((__int64)v144[0] & 1) != 0 ) /*0x10670c505*/
        operator delete(a1: (RBX::Memory *)v145[0], a2: v41); /*0x10670c50e*/
    }
    while ( Bool == 0 ); /*0x10670c515*/
  }
  if ( (unsigned __int8)RBX::Network::NetworkStream::readBool(this: a3) == 0 ) /*0x10670c525*/
  {
    do /*0x10670c7cb*/
    {
      RBX::Network::Replicator::getReadPayloadLimit(this: v136); /*0x10670c540*/
      RBX::Network::NetworkStream::readString(this: (RBX::Network::NetworkStream *)v144, a2: (int)a3); /*0x10670c551*/
      RBX::Network::NetworkStream::readFloat(this: a3); /*0x10670c559*/
      v139 = v43; /*0x10670c55e*/
      v140 = RBX::Network::NetworkStream::readInt32(this: a3); /*0x10670c56e*/
      v45 = operator new(a1: (RBX::Memory *)0x18, a2: v44); /*0x10670c579*/
      *(_OWORD *)v45 = 0; /*0x10670c581*/
      *(_QWORD *)(v45 + 16) = 0; /*0x10670c584*/
      std::shared_ptr<std::vector<RBX::Reflection::Variant>>::shared_ptr[abi:ne200100]<std::vector<RBX::Reflection::Variant>,0>( /*0x10670c596*/
        a1: &v137,
        a2: v45);
      v46 = (__int64)v137; /*0x10670c59b*/
      v149 = (unsigned __int64)RBX::Reflection::Type::getSingleton<float>(a1: v47, a2: v48); /*0x10670c5a7*/
      RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<float>(a1: (char *)&v149 + 8, a2: &v139); /*0x10670c5c7*/
      std::vector<RBX::Reflection::Variant>::push_back[abi:ne200100](a1: v46, a2: (__int64)&v149); /*0x10670c5d2*/
      if ( *((_QWORD *)&v149 + 1) != 0 ) /*0x10670c5e1*/
        (*(void (__fastcall **)(void **))(*((_QWORD *)&v149 + 1) + 16LL))(a1: v150); /*0x10670c5ea*/
      v50 = (__int64)v137; /*0x10670c5ed*/
      v149 = (unsigned __int64)RBX::Reflection::Type::getSingleton<int>(a1: v49); /*0x10670c5f9*/
      RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<int>(a1: (__int64 *)&v149 + 1, a2: &v140); /*0x10670c619*/
      std::vector<RBX::Reflection::Variant>::push_back[abi:ne200100](a1: v50, a2: (__int64)&v149); /*0x10670c624*/
      if ( *((_QWORD *)&v149 + 1) != 0 ) /*0x10670c633*/
        (*(void (__fastcall **)(void **))(*((_QWORD *)&v149 + 1) + 16LL))(a1: v150); /*0x10670c63c*/
      v51 = v122[0]; /*0x10670c63f*/
      v52 = v137; /*0x10670c646*/
      v53 = v138; /*0x10670c64d*/
      v135[0] = v137; /*0x10670c654*/
      v135[1] = v138; /*0x10670c65b*/
      if ( v138 != nullptr ) /*0x10670c665*/
        _InterlockedIncrement64((volatile signed __int64 *)v138 + 1); /*0x10670c667*/
      if ( ((__int64)v144[0] & 1) != 0 ) /*0x10670c673*/
      {
        std::string::__init_copy_ctor_external(a1: v146, a2: v145[0], a3: v144[1]); /*0x10670c6a4*/
      }
      else
      {
        *(void **)&v146[16] = v145[0]; /*0x10670c67c*/
        *(_OWORD *)v146 = *(_OWORD *)v144; /*0x10670c68a*/
      }
      v147 = v52; /*0x10670c6a9*/
      v148 = v53; /*0x10670c6b0*/
      *(_OWORD *)v135 = 0; /*0x10670c6ba*/
      std::pair<std::string const,RBX::Reflection::Variant>::pair[abi:ne200100]<std::string,std::shared_ptr<std::vector<RBX::Reflection::Variant> const>,0>( /*0x10670c6ce*/
        a1: &v149,
        a2: v146);
      std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::pair<std::string const,RBX::Reflection::Variant>>( /*0x10670c6dc*/
        a1: v51,
        a2: &v149);
      if ( v151 != 0 ) /*0x10670c6e8*/
        (*(void (__fastcall **)(_BYTE *))(v151 + 16))(a1: v152); /*0x10670c6ee*/
      if ( (v149 & 1) != 0 ) /*0x10670c6f8*/
        operator delete(a1: (RBX::Memory *)v150[0], a2: v54); /*0x10670c701*/
      v55 = v148; /*0x10670c706*/
      if ( v148 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v148 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10670c722*/
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v55 + 16LL))(a1: v55); /*0x10670c72a*/
        std::__shared_weak_count::__release_weak(this: v55); /*0x10670c730*/
      }
      if ( (v146[0] & 1) != 0 ) /*0x10670c73c*/
        operator delete(a1: *(RBX::Memory **)&v146[16], a2: v54); /*0x10670c745*/
      v56 = v135[1]; /*0x10670c74a*/
      if ( v135[1] != nullptr /*0x10670c766*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v135[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v56 + 16LL))(a1: v56); /*0x10670c76e*/
        std::__shared_weak_count::__release_weak(this: v56); /*0x10670c774*/
      }
      v58 = RBX::Network::NetworkStream::readBool(this: a3); /*0x10670c781*/
      v59 = v138; /*0x10670c784*/
      if ( v138 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v138 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10670c7a0*/
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v59 + 16LL))(a1: v59); /*0x10670c7a8*/
        std::__shared_weak_count::__release_weak(this: v59); /*0x10670c7ae*/
      }
      if ( ((__int64)v144[0] & 1) != 0 ) /*0x10670c7ba*/
        operator delete(a1: (RBX::Memory *)v145[0], a2: v57); /*0x10670c7c3*/
    }
    while ( v58 == 0 ); /*0x10670c7cb*/
  }
  RBX::Network::NetworkStream::readFloat(this: a3); /*0x10670c7d4*/
  v130 = v60; /*0x10670c7d9*/
  RBX::Network::NetworkStream::readFloat(this: a3); /*0x10670c7e4*/
  v133 = v61; /*0x10670c7e9*/
  RBX::Network::NetworkStream::readFloat(this: a3); /*0x10670c7f4*/
  v131 = v62; /*0x10670c7f9*/
  RBX::Network::NetworkStream::readFloat(this: a3); /*0x10670c804*/
  v134 = v63; /*0x10670c809*/
  RBX::Network::NetworkStream::readFloat(this: a3); /*0x10670c814*/
  v132 = v65; /*0x10670c819*/
  v66 = 1; /*0x10670c828*/
  if ( FFlag::ReplacePhysicsStatsWhenISREnabled == 1 ) /*0x10670c82e*/
  {
    EngineNetConfiguration = (__int64 *)RBX::Network::NetworkSchema::getEngineNetConfiguration(this: (RBX::Network::NetworkSchema *)(*((_QWORD *)v136 + 1801) + 1608LL)); /*0x10670c843*/
    v68 = 1; /*0x10670c84f*/
    if ( FFlag::DebugHashTableMetrics == 0 ) /*0x10670c855*/
    {
      if ( FFlag::SAuthWorkspaceFlagged == 1 ) /*0x10670d1ec*/
      {
        v116 = *EngineNetConfiguration; /*0x10670d1ee*/
        if ( (v116 & 8) == 0 && FFlag::NextGenReplicatorEnabledWrite == 0 ) /*0x10670d203*/
          v68 = v116 & 1; /*0x10670d20b*/
      }
      else if ( FFlag::NextGenReplicatorEnabledRead == 1 ) /*0x10670d21d*/
      {
        v68 = FFlag::NextGenReplicatorEnabledWrite; /*0x10670d226*/
      }
      else
      {
        v68 = 0; /*0x10670d22e*/
      }
    }
    v66 = v68 ^ 1; /*0x10670c85b*/
  }
  v69 = operator new(a1: (RBX::Memory *)0x28, a2: v64); /*0x10670c864*/
  *(_OWORD *)(v69 + 16) = 0; /*0x10670c86c*/
  *(_OWORD *)v69 = 0; /*0x10670c870*/
  *(_QWORD *)(v69 + 32) = 0; /*0x10670c873*/
  *(_DWORD *)(v69 + 32) = 1065353216; /*0x10670c87b*/
  std::shared_ptr<RBX::Reflection::ValueTable>::shared_ptr[abi:ne200100]<RBX::Reflection::ValueTable,0>( /*0x10670c88c*/
    a1: v143,
    a2: v69);
  v70 = *(_QWORD *)v143; /*0x10670c898*/
  *(_QWORD *)v146 = "Avg Data Ping ms"; /*0x10670c8a9*/
  *(_DWORD *)&v146[8] = v130; /*0x10670c8b4*/
  std::pair<std::string const,RBX::Reflection::Variant>::pair[abi:ne200100]<char const*,float,0>(a1: &v149); /*0x10670c8c0*/
  std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::pair<std::string const,RBX::Reflection::Variant>>( /*0x10670c8d2*/
    a1: v70,
    a2: &v149);
  if ( v151 != 0 ) /*0x10670c8de*/
    (*(void (__fastcall **)(_BYTE *))(v151 + 16))(a1: v152); /*0x10670c8e4*/
  if ( (v149 & 1) != 0 ) /*0x10670c8ee*/
    operator delete(a1: (RBX::Memory *)v150[0], a2: v71); /*0x10670c8f7*/
  v72 = *(_QWORD *)v143; /*0x10670c903*/
  if ( v66 != 0 ) /*0x10670c909*/
  {
    *(_QWORD *)v146 = "Avg Physics Sender Pkt/s"; /*0x10670c919*/
    *(_DWORD *)&v146[8] = v133; /*0x10670c924*/
    std::pair<std::string const,RBX::Reflection::Variant>::pair[abi:ne200100]<char const*,float,0>(a1: &v149); /*0x10670c930*/
    std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::pair<std::string const,RBX::Reflection::Variant>>( /*0x10670c942*/
      a1: v72,
      a2: &v149);
    if ( v151 == 0 ) /*0x10670c94e*/
      goto LABEL_90; /*0x10670c94e*/
  }
  else
  {
    *(_QWORD *)v146 = "Avg ISR Pkt/s"; /*0x10670c967*/
    *(_DWORD *)&v146[8] = v141; /*0x10670c972*/
    std::pair<std::string const,RBX::Reflection::Variant>::pair[abi:ne200100]<char const*,float,0>(a1: &v149); /*0x10670c97e*/
    std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::pair<std::string const,RBX::Reflection::Variant>>( /*0x10670c990*/
      a1: v72,
      a2: &v149);
    if ( v151 == 0 ) /*0x10670c99c*/
      goto LABEL_90; /*0x10670c99c*/
  }
  (*(void (__fastcall **)(_BYTE *))(v151 + 16))(a1: v152); /*0x10670c9a2*/
LABEL_90:
  if ( (v149 & 1) != 0 ) /*0x10670c9ac*/
    operator delete(a1: (RBX::Memory *)v150[0], a2: v73); /*0x10670c9b5*/
  v74 = *(_QWORD *)v143; /*0x10670c9c1*/
  *(_QWORD *)v146 = "Total Data KB/s"; /*0x10670c9d2*/
  *(_DWORD *)&v146[8] = v131; /*0x10670c9dd*/
  std::pair<std::string const,RBX::Reflection::Variant>::pair[abi:ne200100]<char const*,float,0>(a1: &v149); /*0x10670c9e9*/
  std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::pair<std::string const,RBX::Reflection::Variant>>( /*0x10670c9fb*/
    a1: v74,
    a2: &v149);
  if ( v151 != 0 ) /*0x10670ca07*/
    (*(void (__fastcall **)(_BYTE *))(v151 + 16))(a1: v152); /*0x10670ca0d*/
  if ( (v149 & 1) != 0 ) /*0x10670ca17*/
    operator delete(a1: (RBX::Memory *)v150[0], a2: v75); /*0x10670ca20*/
  v76 = *(_QWORD *)v143; /*0x10670ca2c*/
  if ( v66 != 0 ) /*0x10670ca32*/
  {
    *(_QWORD *)v146 = "Total Physics KB/s"; /*0x10670ca42*/
    *(_DWORD *)&v146[8] = v134; /*0x10670ca4d*/
    std::pair<std::string const,RBX::Reflection::Variant>::pair[abi:ne200100]<char const*,float,0>(a1: &v149); /*0x10670ca59*/
    std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::pair<std::string const,RBX::Reflection::Variant>>( /*0x10670ca6b*/
      a1: v76,
      a2: &v149);
    if ( v151 == 0 ) /*0x10670ca77*/
      goto LABEL_101; /*0x10670ca77*/
  }
  else
  {
    *(_QWORD *)v146 = "Total ISR KB/s"; /*0x10670ca90*/
    *(_DWORD *)&v146[8] = v142; /*0x10670ca9b*/
    std::pair<std::string const,RBX::Reflection::Variant>::pair[abi:ne200100]<char const*,float,0>(a1: &v149); /*0x10670caa7*/
    std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::pair<std::string const,RBX::Reflection::Variant>>( /*0x10670cab9*/
      a1: v76,
      a2: &v149);
    if ( v151 == 0 ) /*0x10670cac5*/
      goto LABEL_101; /*0x10670cac5*/
  }
  (*(void (__fastcall **)(_BYTE *))(v151 + 16))(a1: v152); /*0x10670cacb*/
LABEL_101:
  if ( (v149 & 1) != 0 ) /*0x10670cad5*/
    operator delete(a1: (RBX::Memory *)v150[0], a2: v77); /*0x10670cade*/
  v78 = *(_QWORD *)v143; /*0x10670caea*/
  *(_QWORD *)v146 = "Data Throughput ratio"; /*0x10670cafb*/
  *(_DWORD *)&v146[8] = v132; /*0x10670cb06*/
  std::pair<std::string const,RBX::Reflection::Variant>::pair[abi:ne200100]<char const*,float,0>(a1: &v149); /*0x10670cb12*/
  std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::pair<std::string const,RBX::Reflection::Variant>>( /*0x10670cb24*/
    a1: v78,
    a2: &v149);
  if ( v151 != 0 ) /*0x10670cb30*/
    (*(void (__fastcall **)(_BYTE *))(v151 + 16))(a1: v152); /*0x10670cb36*/
  if ( (v149 & 1) != 0 ) /*0x10670cb40*/
    operator delete(a1: (RBX::Memory *)v150[0], a2: v79); /*0x10670cb49*/
  v80 = *(_QWORD *)v143; /*0x10670cb55*/
  v81 = *(_OWORD *)v123; /*0x10670cb58*/
  if ( v123[1] != nullptr ) /*0x10670cb69*/
    _InterlockedIncrement64((volatile signed __int64 *)v123[1] + 1); /*0x10670cb6b*/
  *(_QWORD *)v146 = "DataStoreBudget"; /*0x10670cb7e*/
  *(_OWORD *)&v146[8] = v81; /*0x10670cb81*/
  *(_OWORD *)v144 = 0; /*0x10670cb88*/
  std::pair<std::string const,RBX::Reflection::Variant>::pair[abi:ne200100]<char const*,std::shared_ptr<RBX::Reflection::ValueTable const>,0>( /*0x10670cb96*/
    a1: &v149,
    a2: v146);
  std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::pair<std::string const,RBX::Reflection::Variant>>( /*0x10670cba8*/
    a1: v80,
    a2: &v149);
  if ( v151 != 0 ) /*0x10670cbb4*/
    (*(void (__fastcall **)(_BYTE *))(v151 + 16))(a1: v152); /*0x10670cbba*/
  if ( (v149 & 1) != 0 ) /*0x10670cbc4*/
    operator delete(a1: (RBX::Memory *)v150[0], a2: v82); /*0x10670cbcd*/
  v83 = *(std::__shared_weak_count **)&v146[16]; /*0x10670cbd2*/
  if ( *(_QWORD *)&v146[16] != 0 /*0x10670cbee*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*(_QWORD *)&v146[16] + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v83 + 16LL))(a1: v83); /*0x10670cbf6*/
    std::__shared_weak_count::__release_weak(this: v83); /*0x10670cbfc*/
  }
  v84 = v144[1]; /*0x10670cc01*/
  if ( v144[1] != nullptr /*0x10670cc1d*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)v144[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v84 + 16LL))(a1: v84); /*0x10670cc25*/
    std::__shared_weak_count::__release_weak(this: v84); /*0x10670cc2b*/
  }
  v85 = *(_QWORD *)v143; /*0x10670cc37*/
  v86 = *(_OWORD *)v121; /*0x10670cc3a*/
  if ( v121[1] != nullptr ) /*0x10670cc4b*/
    _InterlockedIncrement64((volatile signed __int64 *)v121[1] + 1); /*0x10670cc4d*/
  *(_QWORD *)v146 = "Jobs"; /*0x10670cc60*/
  *(_OWORD *)&v146[8] = v86; /*0x10670cc63*/
  *(_OWORD *)v144 = 0; /*0x10670cc6a*/
  std::pair<std::string const,RBX::Reflection::Variant>::pair[abi:ne200100]<char const*,std::shared_ptr<RBX::Reflection::ValueTable const>,0>( /*0x10670cc78*/
    a1: &v149,
    a2: v146);
  std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::pair<std::string const,RBX::Reflection::Variant>>( /*0x10670cc8a*/
    a1: v85,
    a2: &v149);
  if ( v151 != 0 ) /*0x10670cc96*/
    (*(void (__fastcall **)(_BYTE *))(v151 + 16))(a1: v152); /*0x10670cc9c*/
  if ( (v149 & 1) != 0 ) /*0x10670cca6*/
    operator delete(a1: (RBX::Memory *)v150[0], a2: v87); /*0x10670ccaf*/
  v88 = *(std::__shared_weak_count **)&v146[16]; /*0x10670ccb4*/
  if ( *(_QWORD *)&v146[16] != 0 /*0x10670ccd0*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*(_QWORD *)&v146[16] + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v88 + 16LL))(a1: v88); /*0x10670ccd8*/
    std::__shared_weak_count::__release_weak(this: v88); /*0x10670ccde*/
  }
  v89 = v144[1]; /*0x10670cce3*/
  if ( v144[1] != nullptr /*0x10670ccff*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)v144[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v89 + 16LL))(a1: v89); /*0x10670cd07*/
    std::__shared_weak_count::__release_weak(this: v89); /*0x10670cd0d*/
  }
  v90 = *(_QWORD *)v143; /*0x10670cd19*/
  v91 = *(_OWORD *)v122; /*0x10670cd1c*/
  if ( v122[1] != nullptr ) /*0x10670cd2d*/
    _InterlockedIncrement64((volatile signed __int64 *)v122[1] + 1); /*0x10670cd2f*/
  *(_QWORD *)v146 = "Scripts"; /*0x10670cd42*/
  *(_OWORD *)&v146[8] = v91; /*0x10670cd45*/
  *(_OWORD *)v144 = 0; /*0x10670cd4c*/
  std::pair<std::string const,RBX::Reflection::Variant>::pair[abi:ne200100]<char const*,std::shared_ptr<RBX::Reflection::ValueTable const>,0>( /*0x10670cd5a*/
    a1: &v149,
    a2: v146);
  std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::pair<std::string const,RBX::Reflection::Variant>>( /*0x10670cd6c*/
    a1: v90,
    a2: &v149);
  if ( v151 != 0 ) /*0x10670cd78*/
    (*(void (__fastcall **)(_BYTE *))(v151 + 16))(a1: v152); /*0x10670cd7e*/
  if ( (v149 & 1) != 0 ) /*0x10670cd88*/
    operator delete(a1: (RBX::Memory *)v150[0], a2: v92); /*0x10670cd91*/
  v93 = *(std::__shared_weak_count **)&v146[16]; /*0x10670cd96*/
  if ( *(_QWORD *)&v146[16] != 0 /*0x10670cdb2*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*(_QWORD *)&v146[16] + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v93 + 16LL))(a1: v93); /*0x10670cdba*/
    std::__shared_weak_count::__release_weak(this: v93); /*0x10670cdc0*/
  }
  v94 = v144[1]; /*0x10670cdc5*/
  if ( v144[1] != nullptr /*0x10670cde1*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)v144[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v94 + 16LL))(a1: v94); /*0x10670cde9*/
    std::__shared_weak_count::__release_weak(this: v94); /*0x10670cdef*/
  }
  v95 = *(_QWORD *)v143; /*0x10670cdfb*/
  v96 = *(_OWORD *)v124; /*0x10670cdfe*/
  if ( v124[1] != nullptr ) /*0x10670ce0f*/
    _InterlockedIncrement64((volatile signed __int64 *)v124[1] + 1); /*0x10670ce11*/
  *(_QWORD *)v146 = "ServerMemoryTree"; /*0x10670ce24*/
  *(_OWORD *)&v146[8] = v96; /*0x10670ce27*/
  *(_OWORD *)v144 = 0; /*0x10670ce2e*/
  std::pair<std::string const,RBX::Reflection::Variant>::pair[abi:ne200100]<char const*,std::shared_ptr<RBX::Reflection::ValueTable const>,0>( /*0x10670ce3c*/
    a1: &v149,
    a2: v146);
  std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::pair<std::string const,RBX::Reflection::Variant>>( /*0x10670ce4e*/
    a1: v95,
    a2: &v149);
  if ( v151 != 0 ) /*0x10670ce5a*/
    (*(void (__fastcall **)(_BYTE *))(v151 + 16))(a1: v152); /*0x10670ce60*/
  if ( (v149 & 1) != 0 ) /*0x10670ce6a*/
    operator delete(a1: (RBX::Memory *)v150[0], a2: v100); /*0x10670ce73*/
  v101 = *(std::__shared_weak_count **)&v146[16]; /*0x10670ce78*/
  if ( *(_QWORD *)&v146[16] != 0 /*0x10670ce94*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*(_QWORD *)&v146[16] + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v101 + 16LL))(a1: v101); /*0x10670ce9c*/
    std::__shared_weak_count::__release_weak(this: v101); /*0x10670cea2*/
  }
  v102 = v144[1]; /*0x10670cea7*/
  if ( v144[1] != nullptr /*0x10670cec3*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)v144[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v102 + 16LL))(a1: v102); /*0x10670cecb*/
    std::__shared_weak_count::__release_weak(this: v102); /*0x10670ced1*/
  }
  v103 = *(_QWORD *)v143; /*0x10670cedd*/
  v144[0] = (std::__shared_weak_count *)RBX::Reflection::Type::getSingleton<std::string>( /*0x10670ceec*/
                                          a1: v99,
                                          a2: v100,
                                          a3: v97,
                                          a4: v98);
  v144[1] = nullptr; /*0x10670cef0*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string>(a1: (__int64 **)&v144[1], a2: (__int64)&v125); /*0x10670cefe*/
  std::pair<char const*,RBX::Reflection::Variant>::pair[abi:ne200100]<char const(&)[26],RBX::Reflection::Variant,0>( /*0x10670cf18*/
    a1: v146,
    a2: "ServerScriptProfilingData",
    a3: v144);
  std::pair<std::string const,RBX::Reflection::Variant>::pair[abi:ne200100]<char const*,RBX::Reflection::Variant,0>( /*0x10670cf2b*/
    a1: &v149,
    a2: v146);
  std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::pair<std::string const,RBX::Reflection::Variant>>( /*0x10670cf3d*/
    a1: v103,
    a2: &v149);
  if ( v151 != 0 ) /*0x10670cf49*/
    (*(void (__fastcall **)(_BYTE *))(v151 + 16))(a1: v152); /*0x10670cf4f*/
  if ( (v149 & 1) != 0 ) /*0x10670cf59*/
    operator delete(a1: (RBX::Memory *)v150[0], a2: v107); /*0x10670cf62*/
  if ( *(_QWORD *)&v146[16] != 0 ) /*0x10670cf71*/
    (*(void (__fastcall **)(std::__shared_weak_count **))(*(_QWORD *)&v146[16] + 16LL))(a1: &v147); /*0x10670cf7a*/
  if ( v144[1] != nullptr ) /*0x10670cf87*/
    (*((void (__fastcall **)(void **))v144[1] + 2))(a1: v145); /*0x10670cf90*/
  v108 = *(_QWORD *)v143; /*0x10670cf9a*/
  v144[0] = (std::__shared_weak_count *)RBX::Reflection::Type::getSingleton<std::string>( /*0x10670cfa9*/
                                          a1: v106,
                                          a2: v107,
                                          a3: v104,
                                          a4: v105);
  v144[1] = nullptr; /*0x10670cfad*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string>(a1: (__int64 **)&v144[1], a2: (__int64)&v127); /*0x10670cfbb*/
  std::pair<char const*,RBX::Reflection::Variant>::pair[abi:ne200100]<char const(&)[19],RBX::Reflection::Variant,0>( /*0x10670cfd5*/
    a1: v146,
    a2: "ServerLuauHeapData",
    a3: v144);
  std::pair<std::string const,RBX::Reflection::Variant>::pair[abi:ne200100]<char const*,RBX::Reflection::Variant,0>( /*0x10670cfe8*/
    a1: &v149,
    a2: v146);
  std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::pair<std::string const,RBX::Reflection::Variant>>( /*0x10670cffa*/
    a1: v108,
    a2: &v149);
  if ( v151 != 0 ) /*0x10670d006*/
    (*(void (__fastcall **)(_BYTE *))(v151 + 16))(a1: v152); /*0x10670d00c*/
  if ( (v149 & 1) != 0 ) /*0x10670d016*/
    operator delete(a1: (RBX::Memory *)v150[0], a2: v109); /*0x10670d01f*/
  if ( *(_QWORD *)&v146[16] != 0 ) /*0x10670d02e*/
    (*(void (__fastcall **)(std::__shared_weak_count **))(*(_QWORD *)&v146[16] + 16LL))(a1: &v147); /*0x10670d037*/
  if ( v144[1] != nullptr ) /*0x10670d044*/
    (*((void (__fastcall **)(void **))v144[1] + 2))(a1: v145); /*0x10670d04d*/
  if ( (v127 & 1) != 0 ) /*0x10670d057*/
    operator delete(a1: (RBX::Memory *)v128, a2: v109); /*0x10670d060*/
  if ( (v125 & 1) != 0 ) /*0x10670d06c*/
    operator delete(a1: (RBX::Memory *)v126, a2: v109); /*0x10670d075*/
  v110 = v118; /*0x10670d07a*/
  if ( v118 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v118 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10670d096*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v110 + 16LL))(a1: v110); /*0x10670d09e*/
    std::__shared_weak_count::__release_weak(this: v110); /*0x10670d0a4*/
  }
  v111 = v124[1]; /*0x10670d0a9*/
  if ( v124[1] != nullptr /*0x10670d0c5*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)v124[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v111 + 16LL))(a1: v111); /*0x10670d0cd*/
    std::__shared_weak_count::__release_weak(this: v111); /*0x10670d0d3*/
  }
  v112 = v123[1]; /*0x10670d0d8*/
  if ( v123[1] != nullptr /*0x10670d0f4*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)v123[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v112 + 16LL))(a1: v112); /*0x10670d0fc*/
    std::__shared_weak_count::__release_weak(this: v112); /*0x10670d102*/
  }
  v113 = v122[1]; /*0x10670d107*/
  if ( v122[1] != nullptr /*0x10670d123*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)v122[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v113 + 16LL))(a1: v113); /*0x10670d12b*/
    std::__shared_weak_count::__release_weak(this: v113); /*0x10670d131*/
  }
  v114 = v121[1]; /*0x10670d136*/
  if ( v121[1] != nullptr /*0x10670d152*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)v121[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v114 + 16LL))(a1: v114); /*0x10670d15a*/
    std::__shared_weak_count::__release_weak(this: v114); /*0x10670d160*/
  }
  return v143; /*0x10670d180*/
}

// Address: 0x10670d74c | Name: __ZN3RBX7Network16ClientReplicator17readPmcConfigItemERNS0_13NetworkStreamERhRj
void __fastcall RBX::Network::ClientReplicator::readPmcConfigItem(
        RBX::Network::ClientReplicator *this,
        RBX::Network::NetworkStream *a2,
        unsigned __int8 *a3,
        unsigned int *a4)
{
  ; /*0x10670d74c*/
}

// Address: 0x10670d752 | Name: __ZN3RBX7Network16ClientReplicator25processStreamDataRegionIdENS_12StreamRegion23RegionIteratorSuccessorENS2_2IdE
void __fastcall RBX::Network::ClientReplicator::processStreamDataRegionId(
        __int64 a1,
        int a2,
        unsigned __int64 a3,
        int a4)
{
  int v4; // eax
  unsigned __int64 v5; // rcx
  RBX::Network::ClientReplicator::GCJob *v6; // rdi
  unsigned __int64 v7; // [rsp+0h] [rbp-10h] BYREF
  int v8; // [rsp+8h] [rbp-8h]

  v7 = a3; /*0x10670d75a*/
  v8 = a4; /*0x10670d75e*/
  switch ( a2 ) /*0x10670d776*/
  {
    case 1: /*0x10670d776*/
      v4 = *(_DWORD *)(a1 + 23544); /*0x10670d786*/
      v7 = *(unsigned int *)(a1 + 23536) | ((unsigned __int64)(unsigned int)(*(_DWORD *)(a1 + 23540) + 1) << 32); /*0x10670d793*/
      goto LABEL_6; /*0x10670d797*/
    case 2: /*0x10670d776*/
      v5 = *(_QWORD *)(a1 + 23536); /*0x10670d799*/
      v4 = *(_DWORD *)(a1 + 23544) + 1; /*0x10670d7a6*/
      goto LABEL_5; /*0x10670d7a8*/
    case 3: /*0x10670d776*/
      v4 = *(_DWORD *)(a1 + 23544); /*0x10670d7b8*/
      v5 = ((unsigned __int64)*(unsigned int *)(a1 + 23540) << 32) | (unsigned int)(*(_DWORD *)(a1 + 23536) + 1); /*0x10670d7c2*/
LABEL_5:
      v7 = v5; /*0x10670d7c5*/
LABEL_6:
      v8 = v4; /*0x10670d7c9*/
      goto LABEL_7; /*0x10670d7c9*/
    case 4: /*0x10670d776*/
      return;
    default:
LABEL_7:
      *(_DWORD *)(a1 + 23544) = v8; /*0x10670d7cc*/
      *(_QWORD *)(a1 + 23536) = v7; /*0x10670d7d9*/
      v6 = *(RBX::Network::ClientReplicator::GCJob **)(a1 + 22024); /*0x10670d7e0*/
      if ( v6 != nullptr ) /*0x10670d7ea*/
        RBX::Network::ClientReplicator::GCJob::insertRegion(this: v6, a2: (const RBX::StreamRegion::Id *)&v7, a3: true); /*0x10670d7f5*/
      return; /*0x10670d7fa*/
  }
}

// Address: 0x10670d810 | Name: __ZN3RBX7Network16ClientReplicator26processStreamDataRegionIdsERNS0_26DeserializedStreamDataItemE
void __fastcall RBX::Network::ClientReplicator::processStreamDataRegionIds(
        RBX::Network::ClientReplicator *this,
        RBX::Network::DeserializedStreamDataItem *a2)
{
  __int64 v2; // r12
  __int64 v4; // r13
  char *v5; // r15
  char v6; // si
  __int64 v7; // r12
  __int64 v8; // rbx
  int v9; // eax
  unsigned __int64 v10; // rcx
  __int64 v11; // rdi
  unsigned __int64 v12; // r8
  int v13; // edx
  int v14; // ecx
  RBX::Network::ClientReplicator::GCJob *v15; // rdi
  unsigned __int64 v17; // [rsp+8h] [rbp-38h] BYREF
  int v18; // [rsp+10h] [rbp-30h]

  v2 = *((unsigned int *)a2 + 14); /*0x10670d825*/
  if ( *((_DWORD *)a2 + 14) != 0 ) /*0x10670d82c*/
  {
    v4 = *((_QWORD *)a2 + 6); /*0x10670d839*/
    v5 = (char *)this + 23536; /*0x10670d83d*/
    v6 = FFlag::g_flagsLoaded; /*0x10670d84b*/
    v7 = 4 * v2; /*0x10670d84e*/
    v8 = 0; /*0x10670d852*/
    while ( 2 ) /*0x10670d864*/
    {
      if ( (v6 & 1) != 0 && DFFlag::StreamRegionInvalidDefaultValue == 1 ) /*0x10670d864*/
      {
        v17 = 0x7FFFFFFF7FFFFFFFLL; /*0x10670d870*/
        v9 = 0x7FFFFFFF; /*0x10670d874*/
      }
      else
      {
        v17 = 0; /*0x10670d87b*/
        v9 = 0; /*0x10670d883*/
      }
      v18 = v9; /*0x10670d885*/
      switch ( *(_DWORD *)(v4 + v8) ) /*0x10670d8a5*/
      {
        case 0: /*0x10670d8a5*/
          v10 = *((_QWORD *)a2 + 16); /*0x10670d8ab*/
          v11 = *((_QWORD *)a2 + 14); /*0x10670d8b2*/
          v12 = *((_QWORD *)a2 + 15); /*0x10670d8b6*/
          v18 = *(_DWORD *)(v11 + 12 * (v10 % v12) + 8); /*0x10670d8ca*/
          v17 = *(_QWORD *)(v11 + 12 * (v10 % v12)); /*0x10670d8d1*/
          *((_QWORD *)a2 + 16) = (v10 + 1) % v12; /*0x10670d8e0*/
          --*((_QWORD *)a2 + 17); /*0x10670d8e7*/
          goto LABEL_13; /*0x10670d8ee*/
        case 1: /*0x10670d8a5*/
          v13 = *((_DWORD *)this + 5886); /*0x10670d924*/
          v17 = *((unsigned int *)this + 5884) | ((unsigned __int64)(unsigned int)(*((_DWORD *)this + 5885) + 1) << 32); /*0x10670d932*/
          goto LABEL_11; /*0x10670d932*/
        case 2: /*0x10670d8a5*/
          v14 = *((_DWORD *)this + 5886) + 1; /*0x10670d949*/
          v17 = *((_QWORD *)this + 2942); /*0x10670d94b*/
          v18 = v14; /*0x10670d94f*/
          goto LABEL_13; /*0x10670d94f*/
        case 3: /*0x10670d8a5*/
          v13 = *((_DWORD *)this + 5886); /*0x10670d900*/
          v17 = ((unsigned __int64)*((unsigned int *)this + 5885) << 32) | (unsigned int)(*((_DWORD *)this + 5884) + 1); /*0x10670d90e*/
LABEL_11:
          v18 = v13; /*0x10670d936*/
          goto LABEL_13; /*0x10670d939*/
        case 4: /*0x10670d8a5*/
          goto LABEL_15;
        default:
LABEL_13:
          *((_DWORD *)v5 + 2) = v18; /*0x10670d952*/
          *(_QWORD *)v5 = v17; /*0x10670d95d*/
          v15 = *((RBX::Network::ClientReplicator::GCJob **)this + 2753); /*0x10670d960*/
          if ( v15 != nullptr ) /*0x10670d96a*/
          {
            RBX::Network::ClientReplicator::GCJob::insertRegion( /*0x10670d975*/
              this: v15,
              a2: (const RBX::StreamRegion::Id *)&v17,
              a3: true);
            v6 = FFlag::g_flagsLoaded; /*0x10670d981*/
          }
LABEL_15:
          v8 += 4; /*0x10670d984*/
          if ( v7 == v8 ) /*0x10670d98b*/
            return; /*0x10670d98b*/
          continue; /*0x10670d98b*/
      }
    }
  }
}

// Address: 0x10670d9b4 | Name: __ZN3RBX7Network16ClientReplicator19renderNetAssetDebugEPNS_5AdornE
void __fastcall RBX::Network::ClientReplicator::renderNetAssetDebug(RBX::Network::NetworkDebug **this, RBX::Adorn *a2)
{
  RBX::Network::NetworkDebug *v2; // rdi
  RBX::Network::LargeReplicatorReceiver *ReceiverFromLargeReplicator; // rbx
  __int64 v4; // r12
  unsigned __int64 v5; // r13
  const RBX::Object *Receiver; // rax
  RBX::Network::LargeReceiver **v7; // r12
  __int64 v8; // r15
  RBX::Network::LargeReceiver *v9; // rbx
  float v10; // xmm0_4
  RBX::Color3 *v11; // rdi
  __int64 v12; // rax
  __int16 v13; // cx
  char v14; // al
  _OWORD *v15; // r12
  _OWORD *v16; // r13
  __int64 v17; // rax
  RBX::Color3 *v18; // rdi
  unsigned int v19; // ecx
  __int64 v20; // rax
  const RBX::Color3 *v21; // r8
  unsigned __int8 v22; // r9
  __int64 v23; // rcx
  __int64 v24; // rbx
  __int64 v25; // rdx
  __int64 v26; // r12
  RBX::Color3 *v27; // rdi
  __int64 v28; // rax
  const RBX::Color3 *v29; // r8
  unsigned __int8 v30; // r9
  void *v31; // rsi
  __int128 *v32; // [rsp+0h] [rbp-F0h] BYREF
  __int128 v33; // [rsp+8h] [rbp-E8h] BYREF
  RBX::Network::LargeReceiver **v34; // [rsp+18h] [rbp-D8h]
  RBX::Network::LargeReceiver **v35; // [rsp+20h] [rbp-D0h]
  __int64 *v36; // [rsp+28h] [rbp-C8h]
  void *v37[2]; // [rsp+30h] [rbp-C0h] BYREF
  int v38; // [rsp+40h] [rbp-B0h]
  const RBX::Object *v39; // [rsp+50h] [rbp-A0h] BYREF
  __int16 v40; // [rsp+58h] [rbp-98h]
  RBX::Network *v41; // [rsp+68h] [rbp-88h]
  void *v42[2]; // [rsp+70h] [rbp-80h] BYREF
  __int64 v43; // [rsp+80h] [rbp-70h]
  int v44; // [rsp+90h] [rbp-60h] BYREF
  float v45; // [rsp+94h] [rbp-5Ch]
  RBX::Network::ClientReplicator *v46; // [rsp+98h] [rbp-58h]
  RBX::Adorn *v47[2]; // [rsp+A0h] [rbp-50h] BYREF
  unsigned __int64 v48; // [rsp+B8h] [rbp-38h] BYREF
  int v49; // [rsp+C0h] [rbp-30h]

  v41 = a2; /*0x10670d9c8*/
  v46 = (RBX::Network::ClientReplicator *)this; /*0x10670d9cf*/
  v2 = *(this + 1400); /*0x10670d9d3*/
  if ( v2 != nullptr ) /*0x10670d9dd*/
  {
    *(_OWORD *)v37 = 0; /*0x10670d9e6*/
    v38 = 0; /*0x10670d9ed*/
    *(_OWORD *)v42 = 0; /*0x10670d9f7*/
    v43 = 0; /*0x10670d9fb*/
    v33 = 0; /*0x10670da0a*/
    v32 = &v33; /*0x10670da0d*/
    ReceiverFromLargeReplicator = (RBX::Network::LargeReplicatorReceiver *)RBX::Network::NetworkDebug::getReceiverFromLargeReplicator( /*0x10670da16*/
                                                                             this: v2,
                                                                             a2);
    v4 = *((_QWORD *)ReceiverFromLargeReplicator + 629); /*0x10670da19*/
    if ( v4 != 0 ) /*0x10670da23*/
    {
      v5 = 0; /*0x10670da25*/
      do /*0x10670da69*/
      {
        Receiver = (const RBX::Object *)RBX::Network::LargeReplicatorReceiver::getReceiver( /*0x10670da3a*/
                                          this: ReceiverFromLargeReplicator,
                                          a2: v5);
        if ( *((_BYTE *)Receiver + 200) == 1 ) /*0x10670da46*/
        {
          v39 = Receiver; /*0x10670da48*/
          std::vector<RBX::Network::LargeReceiver const*>::push_back[abi:ne200100](a1: v42, a2: &v39); /*0x10670da55*/
          --v4; /*0x10670da5a*/
        }
        if ( v5 > 0x12 ) /*0x10670da61*/
          break; /*0x10670da61*/
        ++v5; /*0x10670da63*/
      }
      while ( v4 != 0 ); /*0x10670da69*/
    }
    v7 = (RBX::Network::LargeReceiver **)v42[0]; /*0x10670da6b*/
    v35 = (RBX::Network::LargeReceiver **)v42[1]; /*0x10670da73*/
    if ( v42[0] != v42[1] ) /*0x10670da7d*/
    {
      v8 = (__int64)v46 + 11080; /*0x10670da87*/
      v36 = (__int64 *)((char *)v46 + 11104); /*0x10670da94*/
      do /*0x10670dbe3*/
      {
        v9 = *v7; /*0x10670da9f*/
        RBX::Network::LargeReceiver::computeProgress(this: *v7); /*0x10670daa6*/
        v45 = v10; /*0x10670daab*/
        v12 = RBX::Color3::green(this: v11); /*0x10670dab0*/
        v34 = v7; /*0x10670dab5*/
        v49 = *(_DWORD *)(v12 + 8); /*0x10670dabf*/
        v48 = *(_QWORD *)v12; /*0x10670dac5*/
        v13 = *((_WORD *)v9 + 8); /*0x10670dacc*/
        v39 = *(const RBX::Object **)v9; /*0x10670dad0*/
        v40 = v13; /*0x10670dad7*/
        v14 = RBX::DenseMapBase<RBX::DenseMap<RBX::Network::NetAssetGroupId,std::vector<RBX::Network::LargeReplicatorBridgeState::Item>,RBX::DenseMapInfo<RBX::Network::NetAssetGroupId,void>,RBX::detail::DenseMapPair<RBX::Network::NetAssetGroupId,std::vector<RBX::Network::LargeReplicatorBridgeState::Item>>>,RBX::Network::NetAssetGroupId,std::vector<RBX::Network::LargeReplicatorBridgeState::Item>,RBX::DenseMapInfo<RBX::Network::NetAssetGroupId,void>,RBX::detail::DenseMapPair<RBX::Network::NetAssetGroupId,std::vector<RBX::Network::LargeReplicatorBridgeState::Item>>>::LookupBucketFor<RBX::Network::NetAssetGroupId>( /*0x10670daef*/
                a1: v36,
                a2: (__int64 *)&v39,
                a3: v47);
        if ( ((v47[0] != (RBX::Adorn *)(*((_QWORD *)v46 + 1388) + 40LL * *((unsigned int *)v46 + 2780))) /*0x10670db1b*/
            & (unsigned __int8)v14) == 1 )
        {
          v15 = *((_OWORD **)v47[0] + 2); /*0x10670db21*/
          v16 = *((_OWORD **)v47[0] + 3); /*0x10670db25*/
          while ( v15 != v16 ) /*0x10670db2c*/
          {
            *(_OWORD *)v47 = *v15; /*0x10670db37*/
            v17 = RBX::DenseMapBase<RBX::DenseMap<RBX::Network::LRBLookupItem,RBX::Network::LargeReplicatorBridgeState::NetAssetHandleRange,RBX::DenseMapInfo<RBX::Network::LRBLookupItem,void>,RBX::detail::DenseMapPair<RBX::Network::LRBLookupItem,RBX::Network::LargeReplicatorBridgeState::NetAssetHandleRange>>,RBX::Network::LRBLookupItem,RBX::Network::LargeReplicatorBridgeState::NetAssetHandleRange,RBX::DenseMapInfo<RBX::Network::LRBLookupItem,void>,RBX::detail::DenseMapPair<RBX::Network::LRBLookupItem,RBX::Network::LargeReplicatorBridgeState::NetAssetHandleRange>>::FindAndConstruct( /*0x10670db41*/
                    a1: v8,
                    a2: v47);
            v19 = *((_DWORD *)v9 + 2); /*0x10670db46*/
            if ( *(_DWORD *)(v17 + 32) <= v19 && v19 < *(_DWORD *)(v17 + 36) ) /*0x10670db51*/
            {
              v20 = RBX::Color3::yellow(this: v18); /*0x10670db53*/
              v49 = *(_DWORD *)(v20 + 8); /*0x10670db5b*/
              v48 = *(_QWORD *)v20; /*0x10670db61*/
            }
            std::__tree<RBX::Network::LRBLookupItem>::__emplace_unique_key_args<RBX::Network::LRBLookupItem,RBX::Network::LRBLookupItem&>( /*0x10670db72*/
              a1: &v32,
              a2: v47,
              a3: v47);
            v44 = 0; /*0x10670db77*/
            RBX::DenseMapBase<RBX::DenseMap<RBX::Object const*,unsigned char,RBX::DenseMapInfo<RBX::Object const*,void>,RBX::detail::DenseMapPair<RBX::Object const*,unsigned char>>,RBX::Object const*,unsigned char,RBX::DenseMapInfo<RBX::Object const*,void>,RBX::detail::DenseMapPair<RBX::Object const*,unsigned char>>::try_emplace<int>( /*0x10670db94*/
              a1: (__int64)&v39,
              a2: (__int64)v37,
              a3: &v47[1],
              a4: &v44);
            v21 = (const RBX::Color3 *)*((unsigned __int8 *)v39 + 8); /*0x10670dba0*/
            *((_BYTE *)v39 + 8) = (_BYTE)v21 + 1; /*0x10670dba9*/
            RBX::Network::drawInfo( /*0x10670dbc3*/
              this: v41,
              a2: v47[1],
              a3: *(const RBX::Object **)v9,
              a4: (unsigned __int64)&v48,
              a5: v21,
              a6: v45,
              a7: v22);
            v15 = (_OWORD *)((char *)v15 + 24); /*0x10670dbc8*/
          }
        }
        v7 = v34 + 1; /*0x10670dbd8*/
      }
      while ( v34 + 1 != v35 ); /*0x10670dbe3*/
    }
    if ( *((_DWORD *)v46 + 2772) != 0 ) /*0x10670dbf4*/
    {
      v23 = *((unsigned int *)v46 + 2774); /*0x10670dc01*/
      v24 = *((_QWORD *)v46 + 1385); /*0x10670dc07*/
      if ( *((_DWORD *)v46 + 2774) != 0 ) /*0x10670dc0d*/
      {
        v25 = 40 * v23; /*0x10670dc17*/
        v24 = *((_QWORD *)v46 + 1385); /*0x10670dc1b*/
        while ( *(_QWORD *)v24 == 0 && (*(_QWORD *)(v24 + 8) & 0xFFFFFFFFFFFFFFFELL) == 0 ) /*0x10670dc33*/
        {
          v24 += 40; /*0x10670dc35*/
          v25 -= 40; /*0x10670dc39*/
          if ( v25 == 0 ) /*0x10670dc3d*/
            goto LABEL_32; /*0x10670dc3d*/
        }
      }
      v26 = *((_QWORD *)v46 + 1385) + 40 * v23; /*0x10670dc48*/
      while ( v24 != v26 ) /*0x10670dc4f*/
      {
        if ( (__int128 *)std::__tree<RBX::Network::LRBLookupItem>::find<RBX::Network::LRBLookupItem>(a1: &v32, a2: v24) == &v33 ) /*0x10670dc79*/
        {
          v28 = RBX::Color3::red(this: v27); /*0x10670dc7b*/
          LODWORD(v47[1]) = *(_DWORD *)(v28 + 8); /*0x10670dc83*/
          v47[0] = *(RBX::Adorn **)v28; /*0x10670dc89*/
          LODWORD(v48) = 0; /*0x10670dc91*/
          RBX::DenseMapBase<RBX::DenseMap<RBX::Object const*,unsigned char,RBX::DenseMapInfo<RBX::Object const*,void>,RBX::detail::DenseMapPair<RBX::Object const*,unsigned char>>,RBX::Object const*,unsigned char,RBX::DenseMapInfo<RBX::Object const*,void>,RBX::detail::DenseMapPair<RBX::Object const*,unsigned char>>::try_emplace<int>( /*0x10670dca9*/
            a1: (__int64)&v39,
            a2: (__int64)v37,
            a3: (_QWORD *)(v24 + 8),
            a4: &v48);
          v29 = (const RBX::Color3 *)*((unsigned __int8 *)v39 + 8); /*0x10670dcb5*/
          *((_BYTE *)v39 + 8) = (_BYTE)v29 + 1; /*0x10670dcbe*/
          RBX::Network::drawInfo( /*0x10670dcd6*/
            this: v41,
            a2: *(RBX::Adorn **)(v24 + 8),
            a3: *(const RBX::Object **)(v24 + 24),
            a4: (unsigned __int64)v47,
            a5: v29,
            a6: 0.0,
            a7: v30);
        }
        do /*0x10670dcf7*/
          v24 += 40; /*0x10670dcdb*/
        while ( v24 != v26 && *(_QWORD *)v24 == 0 && (*(_QWORD *)(v24 + 8) & 0xFFFFFFFFFFFFFFFELL) == 0 ); /*0x10670dcf7*/
      }
    }
LABEL_32:
    std::__tree<RBX::Network::LRBLookupItem>::destroy(a1: &v32, a2: v33); /*0x10670dd02*/
    if ( v42[0] != nullptr ) /*0x10670dd19*/
    {
      v42[1] = v42[0]; /*0x10670dd1b*/
      operator delete(a1: (RBX::Memory *)v42[0], a2: v31); /*0x10670dd1f*/
    }
    operator delete(a1: (RBX::Memory *)v37[0], a2: v31); /*0x10670dd2b*/
  }
}

// Address: 0x10670e35a | Name: __ZThn216_N3RBX7Network16ClientReplicator19renderNetAssetDebugEPNS_5AdornE
void __fastcall `non-virtual thunk to'RBX::Network::ClientReplicator::renderNetAssetDebug(
        RBX::Network::NetworkDebug **this,
        RBX::Adorn *a2)
{
  RBX::Network::ClientReplicator::renderNetAssetDebug(this: this - 27, a2); /*0x10670e366*/
}

// Address: 0x10670e36c | Name: __ZN3RBX7Network16ClientReplicator25sampleStreamingStatisticsEv
__int64 __fastcall RBX::Network::ClientReplicator::sampleStreamingStatistics(RBX::Network::ClientReplicator *this)
{
  float v2; // xmm0_4
  RBX::TaskScheduler *v3; // rdi
  double v4; // xmm0_8
  char *v5; // rdi
  double v6; // xmm0_8
  __int64 result; // rax
  double v8; // [rsp+0h] [rbp-10h]

  RBX::RunningAverage<double,double>::sample(a1: (__int64)this + 23080, a2: *((double *)this + 2938)); /*0x10670e384*/
  if ( DFFlag::StreamingFrameTimeDistributionStats == 1 ) /*0x10670e390*/
  {
    v2 = *((double *)this + 2938); /*0x10670e39c*/
    RBX::KllSketch::update(this: (RBX::Network::ClientReplicator *)((char *)this + 23816), a2: v2); /*0x10670e3a4*/
  }
  RBX::RunningAverage<double,double>::sample(a1: (__int64)this + 23120, a2: *((double *)this + 2939)); /*0x10670e3b8*/
  RBX::TaskScheduler::getPreviousFrameTimeMsec(this: v3); /*0x10670e3bd*/
  v5 = (char *)this + 23200; /*0x10670e3c6*/
  if ( v4 <= 0.0 ) /*0x10670e3d5*/
  {
    RBX::RunningAverage<double,double>::sample(a1: (__int64)v5, a2: 0.0); /*0x10670e3fc*/
    v6 = 0.0; /*0x10670e401*/
  }
  else
  {
    v8 = v4; /*0x10670e3e3*/
    RBX::RunningAverage<double,double>::sample(a1: (__int64)v5, a2: *((double *)this + 2938) / v4); /*0x10670e3e8*/
    v6 = *((double *)this + 2939) / v8; /*0x10670e3f5*/
  }
  RBX::RunningAverage<double,double>::sample(a1: (__int64)this + 23240, a2: v6); /*0x10670e40c*/
  RBX::RunningAverage<double,double>::sample( /*0x10670e428*/
    a1: (__int64)this + 23160,
    a2: *((double *)this + 2938) - *((double *)this + 2939));
  result = RBX::JitterMetric::sample( /*0x10670e43c*/
             this: (RBX::Network::ClientReplicator *)((char *)this + 23560),
             a2: *((double *)this + 2936));
  *((_OWORD *)this + 1469) = *((_OWORD *)this + 1468); /*0x10670e448*/
  *((_OWORD *)this + 1468) = 0; /*0x10670e452*/
  return result; /*0x10670e45d*/
}

// Address: 0x10670e462 | Name: __ZN3RBX7Network16ClientReplicator22recordTerrainDataStatsEd
__int64 __fastcall RBX::Network::ClientReplicator::recordTerrainDataStats(
        RBX::Network::ClientReplicator *this,
        double a2)
{
  RBX::TotalCountTimeInterval<int,(RBX::Time::SampleMethod)1>::increment(a1: (char *)this + 22216, a2: 1); /*0x10670e47c*/
  RBX::RunningAverage<double,double>::sample(a1: (__int64)this + 22176, a2); /*0x10670e48d*/
  return RBX::TotalCountTimeInterval<double,(RBX::Time::SampleMethod)1>::increment(a1: (char *)this + 15192, a2); /*0x10670e4a5*/
}

// Address: 0x10670e4ae | Name: __ZN3RBX7Network16ClientReplicator18readStreamDataItemEPNS0_26DeserializedStreamDataItemE
void __fastcall RBX::Network::ClientReplicator::readStreamDataItem(
        __m128d *this,
        RBX::Network::DeserializedStreamDataItem *a2)
{
  int v4; // eax
  int v5; // r15d
  __int64 v6; // rdi
  double v7; // xmm0_8
  __int64 v8; // rdi
  __m128d v9; // xmm0
  __int64 v10; // rdi
  double v11; // xmm0_8
  RBX::Network::ClientReplicator::GCJob *v12; // rdi
  __int64 v13; // rax
  __int64 v14; // r12
  __int64 i; // r13
  __int64 v16; // rdi
  std::__shared_weak_count *v17; // r15
  __int64 v18; // [rsp+0h] [rbp-40h] BYREF
  std::__shared_weak_count *v19; // [rsp+8h] [rbp-38h]
  double v20; // [rsp+10h] [rbp-30h]

  v20 = RBX::Time::now<(RBX::Time::SampleMethod)2>(a1: this); /*0x10670e4ca*/
  RBX::Network::ClientReplicator::processStreamDataRegionIds((RBX::Network::ClientReplicator *)this, a2); /*0x10670e4d5*/
  if ( *((_QWORD *)a2 + 4) != 0 ) /*0x10670e4e1*/
  {
    v4 = (*(__int64 (__fastcall **)(__m128d *))(*(_QWORD *)&this->f64[0] + 1376LL))(a1: this); /*0x10670e4ed*/
    *((_DWORD *)this + 5969) += v4; /*0x10670e4f3*/
    if ( v4 > 0 ) /*0x10670e4fb*/
    {
      v5 = v4; /*0x10670e501*/
      RBX::TotalCountTimeInterval<int,(RBX::Time::SampleMethod)1>::increment(a1: (char *)this + 22152, a2: 1); /*0x10670e510*/
      RBX::RunningAverage<double,double>::sample(a1: (__int64)this + 22072, a2: (double)v5); /*0x10670e524*/
      v7 = RBX::Time::now<(RBX::Time::SampleMethod)2>(a1: v6); /*0x10670e530*/
      RBX::RunningAverage<double,double>::sample(a1: (__int64)(this + 1382), a2: v7 - v20); /*0x10670e53d*/
      *((float *)this + 5868) = *((float *)a2 + 4) + *((float *)this + 5868); /*0x10670e550*/
      v9.f64[0] = (RBX::Time::now<(RBX::Time::SampleMethod)2>(a1: v8) - v20) * 1000.0; /*0x10670e562*/
      *(this + 1468) = _mm_add_pd(_mm_movedup_pd(v9), *(this + 1468)); /*0x10670e576*/
      v11 = RBX::Time::now<(RBX::Time::SampleMethod)2>(a1: v10); /*0x10670e585*/
      RBX::TotalCountTimeInterval<double,(RBX::Time::SampleMethod)1>::increment(a1: (char *)this + 15160, a2: v11 - v20); /*0x10670e592*/
      v12 = *((RBX::Network::ClientReplicator::GCJob **)this + 2753); /*0x10670e597*/
      if ( v12 != nullptr ) /*0x10670e5a1*/
        RBX::Network::ClientReplicator::GCJob::recordReadStreamDataItem(this: v12, a2: v5); /*0x10670e5a6*/
      if ( *((_QWORD *)this + 2982) != 0 ) /*0x10670e5b3*/
      {
        v13 = *((_QWORD *)a2 + 4); /*0x10670e5b5*/
        v14 = *(_QWORD *)(v13 + 32); /*0x10670e5b9*/
        for ( i = *(_QWORD *)(v13 + 40); v14 != i; v14 += 216 ) /*0x10670e5c4*/
        {
          RBX::Reflection::DescribedBase::fastSharedDynamicCast<RBX::Instance,RBX::Object>(a1: &v18, a2: v14 + 112); /*0x10670e5d2*/
          if ( v18 != 0 ) /*0x10670e5dc*/
          {
            v16 = *((_QWORD *)this + 2982); /*0x10670e5de*/
            if ( v16 == 0 ) /*0x10670e5e8*/
              std::__throw_bad_function_call[abi:ne200100](a1: 0); /*0x10670e63a*/
            (*(void (__fastcall **)(__int64, __int64 *))(*(_QWORD *)v16 + 48LL))(a1: v16, a2: &v18); /*0x10670e5f0*/
          }
          v17 = v19; /*0x10670e5f3*/
          if ( v19 != nullptr /*0x10670e60c*/
            && _InterlockedExchangeAdd64((volatile signed __int64 *)v19 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
          {
            (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v17 + 16LL))(a1: v17); /*0x10670e614*/
            std::__shared_weak_count::__release_weak(this: v17); /*0x10670e61a*/
          }
        }
      }
    }
  }
}

// Address: 0x10670e658 | Name: __ZN3RBX7Network16ClientReplicator21readStreamPinDataItemEPNS0_29DeserializedStreamPinDataItemE
void __fastcall RBX::Network::ClientReplicator::readStreamPinDataItem(
        __m128d *this,
        RBX::Network::DeserializedStreamPinDataItem *a2)
{
  char v4; // al
  __int64 v5; // rdi
  __int64 v6; // rdi
  __int64 v7; // rdi
  __int64 v8; // rax

  RBX::Network::ClientReplicator::readStreamDataItem(this, a2); /*0x10670e669*/
  if ( FFlag::StrPinAPI == 1 ) /*0x10670e67a*/
  {
    if ( *((_QWORD *)a2 + 18) == 0 ) /*0x10670e688*/
      return; /*0x10670e688*/
    v4 = *((_BYTE *)a2 + 164); /*0x10670e695*/
    if ( DFFlag::StreamingDedupRetransmittedPinsWithPending == 1 ) /*0x10670e6a2*/
    {
      if ( v4 != 0 ) /*0x10670e6a6*/
      {
        v5 = *((_QWORD *)this + 2757); /*0x10670e6a8*/
        if ( v5 != 0 /*0x10670e6c4*/
          && (unsigned __int8)RBX::Network::InstanceObjectManager::hasPinForInstanceAndDepthIncludingPending(
                                a1: v5,
                                a2: (char *)a2 + 144,
                                a3: *((unsigned int *)a2 + 40)) != 0 )
        {
          return; /*0x10670e6c4*/
        }
      }
    }
    else if ( v4 != 0 ) /*0x10670e6cd*/
    {
      v6 = *((_QWORD *)this + 2757); /*0x10670e6cf*/
      if ( v6 != 0 /*0x10670e6eb*/
        && (int)RBX::Network::InstanceObjectManager::getPinCountForInstanceAndDepth(
                  a1: v6,
                  a2: (char *)a2 + 144,
                  a3: *((unsigned int *)a2 + 40)) > 0 )
      {
        return; /*0x10670e6eb*/
      }
    }
    v7 = *((_QWORD *)this + 2757); /*0x10670e6ed*/
    if ( v7 != 0 && *((_QWORD *)a2 + 18) != 0 ) /*0x10670e6fd*/
      RBX::Network::InstanceObjectManager::clientPinInstanceToDepth( /*0x10670e70a*/
        a1: v7,
        a2: (char *)a2 + 144,
        a3: *((unsigned int *)a2 + 40),
        a4: 0);
  }
  if ( FFlag::StrPinAPI == 1 && *((_QWORD *)a2 + 18) != 0 ) /*0x10670e71e*/
  {
    v8 = (*(__int64 (__fastcall **)(__m128d *))(*(_QWORD *)&this->f64[0] + 688LL))(a1: this); /*0x10670e726*/
    if ( v8 != 0 ) /*0x10670e72f*/
      RBX::Player::fireStreamingPinCompleteEvent(a1: v8, a2: (char *)a2 + 144); /*0x10670e746*/
  }
}

// Address: 0x10670e754 | Name: __ZN3RBX7Network16ClientReplicator22readStreamDataInfoItemEPNS0_30DeserializedStreamDataInfoItemE
void __fastcall RBX::Network::ClientReplicator::readStreamDataInfoItem(
        RBX::Network::ClientReplicator::GCJob **this,
        RBX::Network::DeserializedStreamDataInfoItem *a2)
{
  char v4; // al
  int v5; // r15d
  bool v6; // cl
  _BYTE *v7; // rax
  _BYTE *v8; // rax
  __int64 v9; // rdx
  void *v10; // rsi
  __int64 v11; // rdx
  _QWORD v12[8]; // [rsp+10h] [rbp-A0h] BYREF
  __int64 v13; // [rsp+50h] [rbp-60h]
  _QWORD *v14; // [rsp+58h] [rbp-58h]
  __int64 v15; // [rsp+60h] [rbp-50h]
  char v16; // [rsp+68h] [rbp-48h] BYREF
  _BYTE v17[15]; // [rsp+69h] [rbp-47h] BYREF
  void *v18; // [rsp+78h] [rbp-38h]
  int v19[11]; // [rsp+84h] [rbp-2Ch] BYREF

  if ( *(this + 2753) != nullptr )
  {
    if ( (unsigned __int8)RBX::Network::Replicator::getGarbageCollectionVersionCapability((RBX::Network::Replicator *)this) == 0 ) /*0x10670e783*/
    {
      RBX::Network::ClientReplicator::GCJob::setServerStreamingMetadata( /*0x10670e81c*/
        this: *(this + 2753),
        a2: (RBX::Network::DeserializedStreamDataInfoItem *)((char *)a2 + 32),
        a3: (int *)a2 + 11);
      return; /*0x10670e81c*/
    }
    v19[0] = *((_DWORD *)a2 + 11); /*0x10670e78e*/
    v4 = RBX::Network::ClientReplicator::GCJob::modifyRadiusBasedOnVersion( /*0x10670e7a4*/
           this: *(this + 2753),
           a2: (RBX::Network::DeserializedStreamDataInfoItem *)((char *)a2 + 32),
           a3: *((_DWORD *)a2 + 12),
           a4: v19);
    v5 = DFLog::ShipsInNightGarbageCollection; /*0x10670e7a9*/
    v6 = (unsigned __int8)DFLog::ShipsInNightGarbageCollection >= 6u /*0x10670e7c3*/
      && BYTE1(DFLog::ShipsInNightGarbageCollection) >= 5u;
    if ( v4 != 0 )
    {
      if ( v6 )
      {
        v15 = qword_10D809950; /*0x10670e7d8*/
        RBX::StreamRegion::Id::asString(this: (RBX::StreamRegion::Id *)&v16); /*0x10670e7e6*/
        if ( (v16 & 1) != 0 ) /*0x10670e7f0*/
          v7 = v18; /*0x10670e7f2*/
        else
          v7 = v17; /*0x10670e850*/
        v9 = *((unsigned int *)a2 + 12); /*0x10670e859*/
        v12[2] = *((unsigned int *)a2 + 11); /*0x10670e86b*/
        v12[4] = v9; /*0x10670e86f*/
        v12[6] = (unsigned int)v19[0]; /*0x10670e873*/
        v13 = 4636; /*0x10670e877*/
        v14 = v12; /*0x10670e87f*/
        FLog::detail::FastLogSafeFormattedInternal(
          a1: v5,
          a2: v15,
          a3: 5,
          a4: (unsigned int)"[DFLog::ShipsInNightGarbageCollection] INFO REDUCE ==> Region: {}, radius {} at version {} was r"
                        "educed to radius {} because it is marked as GCed",
          a5: 144,
          a6: 1,
          4636,
          v12,
          v7);
LABEL_15:
        if ( (v16 & 1) != 0 ) /*0x10670e90b*/
          operator delete(a1: (RBX::Memory *)v18, a2: v10); /*0x10670e911*/
      }
    }
    else if ( v6 )
    {
      v15 = qword_10D809950; /*0x10670e830*/
      RBX::StreamRegion::Id::asString(this: (RBX::StreamRegion::Id *)&v16); /*0x10670e83e*/
      if ( (v16 & 1) != 0 ) /*0x10670e848*/
        v8 = v18; /*0x10670e84a*/
      else
        v8 = v17; /*0x10670e8b1*/
      v11 = *((unsigned int *)a2 + 12); /*0x10670e8b8*/
      v12[2] = (unsigned int)v19[0]; /*0x10670e8c7*/
      v12[4] = v11; /*0x10670e8cb*/
      v13 = 540; /*0x10670e8cf*/
      v14 = v12; /*0x10670e8d7*/
      FLog::detail::FastLogSafeFormattedInternal(
        a1: v5,
        a2: v15,
        a3: 5,
        a4: (unsigned int)"[DFLog::ShipsInNightGarbageCollection] INFO ==> Region: {}, Radius {} at version {}",
        a5: 83,
        a6: 1,
        540,
        v12,
        v8);
      goto LABEL_15; /*0x10670e902*/
    }
    if ( v19[0] >= 0 ) /*0x10670e91a*/
      RBX::Network::ClientReplicator::GCJob::setServerStreamingMetadata( /*0x10670e92a*/
        this: *(this + 2753),
        a2: (RBX::Network::DeserializedStreamDataInfoItem *)((char *)a2 + 32),
        a3: v19);
  }
}

// Address: 0x10670e95e | Name: __ZN3RBX7Network16ClientReplicator30readStreamPrefetchDataInfoItemEPNS0_38DeserializedStreamPrefetchDataInfoItemE
__int64 __fastcall RBX::Network::ClientReplicator::readStreamPrefetchDataInfoItem(
        RBX::Network::ClientReplicator *this,
        RBX::Network::DeserializedStreamPrefetchDataInfoItem *a2)
{
  RBX::Network::ClientReplicator::GCJob *v2; // rdi
  __int64 result; // rax

  v2 = *((RBX::Network::ClientReplicator::GCJob **)this + 2753); /*0x10670e962*/
  if ( v2 != nullptr ) /*0x10670e96c*/
    return RBX::Network::ClientReplicator::GCJob::setServerStreamingPrefetchMetadata( /*0x10670e97d*/
             this: v2,
             a2: (RBX::Network::DeserializedStreamPrefetchDataInfoItem *)((char *)a2 + 32),
             a3: *((_DWORD *)a2 + 11),
             a4: *((_BYTE *)a2 + 48));
  return result; /*0x10670e97c*/
}

// Address: 0x10670e984 | Name: __ZN3RBX7Network16ClientReplicator29readStreamPrefetchRequestItemEPNS0_37DeserializedStreamPrefetchRequestItemE
__int64 __fastcall RBX::Network::ClientReplicator::readStreamPrefetchRequestItem(
        RBX::Network::ClientReplicator *this,
        RBX::Network::DeserializedStreamPrefetchRequestItem *a2,
        __int64 a3,
        __int64 a4,
        int a5,
        int a6)
{
  RBX::Network::ClientReplicator::GCJob *v7; // rdi
  __int64 result; // rax

  v7 = *((RBX::Network::ClientReplicator::GCJob **)this + 2753); /*0x10670e98e*/
  if ( v7 != nullptr ) /*0x10670e998*/
  {
    if ( (unsigned __int8)DFLog::StreamPrefetch >= 6u && BYTE1(DFLog::StreamPrefetch) >= 3u ) /*0x10670e9b5*/
    {
      FLog::FastLogFormatted( /*0x10670e9cd*/
        a1: DFLog::StreamPrefetch,
        a2: qword_10D810558,
        a3: (unsigned int)"[DFLog::StreamPrefetch] Server Prefetch Request",
        a4: (unsigned int)&DFLog::StreamPrefetch,
        a5,
        a6);
      v7 = *((RBX::Network::ClientReplicator::GCJob **)this + 2753); /*0x10670e9d2*/
    }
    return RBX::Network::ClientReplicator::GCJob::setStartedPrefetch( /*0x10670e9e9*/
             this: v7,
             a2: (RBX::Network::DeserializedStreamPrefetchRequestItem *)((char *)a2 + 32),
             a3: *((_DWORD *)a2 + 14),
             a4: *((double *)a2 + 6));
  }
  return result; /*0x10670e9e5*/
}

// Address: 0x10670e9f4 | Name: __ZN3RBX7Network16ClientReplicator30readStreamReplicationFocusItemERNS0_38DeserializedStreamReplicationFocusItemE
__int64 __fastcall RBX::Network::ClientReplicator::readStreamReplicationFocusItem(
        RBX::Network::ClientReplicator *this,
        RBX::Network::DeserializedStreamReplicationFocusItem *a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6)
{
  __int64 v7; // rdi
  __int64 v9; // rdx
  __int64 result; // rax
  _QWORD v11[8]; // [rsp+20h] [rbp-40h] BYREF

  v7 = *((_QWORD *)this + 2753); /*0x10670ea02*/
  if ( v7 != 0 )
  {
    if ( (unsigned __int8)DFLog::StreamMRF >= 6u && BYTE1(DFLog::StreamMRF) >= 5u )
    {
      v9 = *((unsigned int *)a2 + 12); /*0x10670ea3c*/
      v11[0] = *((unsigned int *)a2 + 8); /*0x10670ea43*/
      v11[2] = v9; /*0x10670ea46*/
      v11[4] = 18; /*0x10670ea4a*/
      v11[5] = v11; /*0x10670ea52*/
      FLog::detail::FastLogSafeFormattedInternal(
        a1: DFLog::StreamMRF,
        a2: qword_10D811338,
        a3: 5,
        a4: (unsigned int)"[DFLog::StreamMRF] Server Replication Focus Request: focusId={} completedRadius={}",
        a5: 82,
        a6: 1,
        18,
        v11);
      v7 = *((_QWORD *)this + 2753); /*0x10670ea7e*/
    }
    return RBX::Network::ClientReplicator::GCJob::setReplicationFocus( /*0x10670eaac*/
             a1: v7,
             a2: *((unsigned int *)a2 + 8),
             a3: (char *)a2 + 36,
             a4: *((unsigned int *)a2 + 12),
             a5,
             a6,
             a7: *(_QWORD *)((char *)a2 + 52),
             a8: *(_QWORD *)((char *)a2 + 60),
             a9: *((_DWORD *)a2 + 17));
  }
  return result; /*0x10670eab1*/
}

// Address: 0x10670eaba | Name: __ZN3RBX7Network16ClientReplicator36readStreamReplicationFocusRemoveItemERNS0_44DeserializedStreamReplicationFocusRemoveItemE
RBX::Network::ClientReplicator::GCJob *__fastcall RBX::Network::ClientReplicator::readStreamReplicationFocusRemoveItem(
        RBX::Network::ClientReplicator *this,
        RBX::Network::DeserializedStreamReplicationFocusRemoveItem *a2)
{
  RBX::Network::ClientReplicator::GCJob *result; // rax
  _QWORD v5[7]; // [rsp+10h] [rbp-38h] BYREF

  result = *((RBX::Network::ClientReplicator::GCJob **)this + 2753); /*0x10670eaba*/
  if ( result != nullptr ) /*0x10670eac4*/
  {
    if ( (unsigned __int8)DFLog::StreamMRF >= 6u && BYTE1(DFLog::StreamMRF) >= 5u ) /*0x10670eaf5*/
    {
      v5[2] = 0; /*0x10670eb01*/
      v5[3] = v5; /*0x10670eb0d*/
      FLog::detail::FastLogSafeFormattedInternal( /*0x10670eb31*/
        a1: DFLog::StreamMRF,
        a2: qword_10D811338,
        a3: 5,
        a4: (unsigned int)"[DFLog::StreamMRF] Server Replication Focus Removal",
        a5: 51,
        a6: 1,
        0,
        v5);
      result = *((RBX::Network::ClientReplicator::GCJob **)this + 2753); /*0x10670eb36*/
    }
    return (RBX::Network::ClientReplicator::GCJob *)RBX::Network::ClientReplicator::GCJob::queuePendingRemoveReplicationFocus( /*0x10670eb43*/
                                                      this: result,
                                                      a2: *((_DWORD *)a2 + 8));
  }
  return result; /*0x10670eb50*/
}

// Address: 0x10670eb52 | Name: __ZN3RBX7Network16ClientReplicator37readStreamReplicationFocusFrustumItemERNS0_45DeserializedStreamReplicationFocusFrustumItemE
__int64 __fastcall RBX::Network::ClientReplicator::readStreamReplicationFocusFrustumItem(
        RBX::Network::ClientReplicator::GCJob **this,
        RBX::Network::DeserializedStreamReplicationFocusFrustumItem *a2)
{
  __int64 result; // rax
  __int64 v5; // rdx
  __int64 v6; // rcx
  const char *v7; // rsi
  __int64 v8; // r8
  __int64 v9; // r9
  __m128 v10; // xmm0
  __m128 v11; // xmm1
  __m128 v12; // xmm2
  __m128 v13; // xmm3
  __m128 v14; // xmm4
  __m128 v15; // xmm5
  __m128 v16; // xmm6
  __m128 v17; // xmm7
  RBX::Network::ClientReplicator::GCJob *v18; // rax
  char v19; // [rsp+0h] [rbp-40h]
  _QWORD v20[6]; // [rsp+10h] [rbp-30h] BYREF

  result = RBX::Network::Replicator::getAutomaticFrustumStreamingEnabled((RBX::Network::Replicator *)this); /*0x10670eb63*/
  if ( (_BYTE)result != 0 )
  {
    v18 = *(this + 2753); /*0x10670eb70*/
    if ( v18 == nullptr ) /*0x10670eb7a*/
      RBX::throw_runtime_error( /*0x10670ec0c*/
        this: (RBX *)"gcJob can not respond to frustum streaming focus request.",
        a2: v7,
        a3: v5,
        a4: v6,
        a5: v8,
        a6: v9,
        a7: v10,
        a8: v11,
        a9: v12,
        a10: v13,
        a11: v14,
        a12: v15,
        a13: v16,
        a14: v17,
        a15: v19);
    if ( (unsigned __int8)DFLog::StreamMRF >= 6u && BYTE1(DFLog::StreamMRF) >= 5u )
    {
      v20[0] = *((unsigned int *)a2 + 8); /*0x10670ebad*/
      v20[2] = 2; /*0x10670ebb0*/
      v20[3] = v20; /*0x10670ebb8*/
      FLog::detail::FastLogSafeFormattedInternal(
        a1: DFLog::StreamMRF,
        a2: qword_10D811338,
        a3: 5,
        a4: (unsigned int)"[DFLog::StreamMRF] Server Replication Frustum Focus Request: {}",
        a5: 63,
        a6: 1,
        2,
        v20,
        v20[0]);
      v18 = *(this + 2753); /*0x10670ebe1*/
    }
    return RBX::Network::ClientReplicator::GCJob::updateProgressFrustum( /*0x10670ebf5*/
             this: v18,
             a2: *((_DWORD *)a2 + 8),
             a3: (RBX::Network::DeserializedStreamReplicationFocusFrustumItem *)((char *)a2 + 36));
  }
  return result; /*0x10670ebfa*/
}

// Address: 0x10670ec12 | Name: __ZN3RBX7Network16ClientReplicator43readStreamReplicationFocusFrustumRemoveItemERNS0_51DeserializedStreamReplicationFocusFrustumRemoveItemE
__int64 __fastcall RBX::Network::ClientReplicator::readStreamReplicationFocusFrustumRemoveItem(
        RBX::Network::ClientReplicator::GCJob **this,
        RBX::Network::DeserializedStreamReplicationFocusFrustumRemoveItem *a2)
{
  __int64 result; // rax
  __int64 v5; // rdx
  __int64 v6; // rcx
  const char *v7; // rsi
  __int64 v8; // r8
  __int64 v9; // r9
  __m128 v10; // xmm0
  __m128 v11; // xmm1
  __m128 v12; // xmm2
  __m128 v13; // xmm3
  __m128 v14; // xmm4
  __m128 v15; // xmm5
  __m128 v16; // xmm6
  __m128 v17; // xmm7
  RBX::Network::ClientReplicator::GCJob *v18; // rax
  char v19; // [rsp+0h] [rbp-40h]
  _BYTE v20[16]; // [rsp+10h] [rbp-30h] BYREF
  __int64 v21; // [rsp+20h] [rbp-20h]
  _BYTE *v22; // [rsp+28h] [rbp-18h]

  result = RBX::Network::Replicator::getAutomaticFrustumStreamingEnabled((RBX::Network::Replicator *)this); /*0x10670ec23*/
  if ( (_BYTE)result != 0 ) /*0x10670ec2a*/
  {
    v18 = *(this + 2753); /*0x10670ec2c*/
    if ( v18 == nullptr ) /*0x10670ec36*/
      RBX::throw_runtime_error( /*0x10670ecb7*/
        this: (RBX *)"gcJob can not respond to frustum streaming remove focus request.",
        a2: v7,
        a3: v5,
        a4: v6,
        a5: v8,
        a6: v9,
        a7: v10,
        a8: v11,
        a9: v12,
        a10: v13,
        a11: v14,
        a12: v15,
        a13: v16,
        a14: v17,
        a15: v19);
    if ( (unsigned __int8)DFLog::StreamMRF >= 6u && BYTE1(DFLog::StreamMRF) >= 5u ) /*0x10670ec52*/
    {
      v21 = 0; /*0x10670ec5e*/
      v22 = v20; /*0x10670ec6a*/
      FLog::detail::FastLogSafeFormattedInternal( /*0x10670ec8e*/
        a1: DFLog::StreamMRF,
        a2: qword_10D811338,
        a3: 5,
        a4: (unsigned int)"[DFLog::StreamMRF] Server Replication Focus Frustum Removal",
        a5: 59,
        a6: 1,
        0,
        v20);
      v18 = *(this + 2753); /*0x10670ec93*/
    }
    return RBX::Network::ClientReplicator::GCJob::queuePendingRemoveReplicationFocus(this: v18, a2: *((_DWORD *)a2 + 8)); /*0x10670eca0*/
  }
  return result; /*0x10670eca5*/
}

// Address: 0x10670ecbc | Name: __ZN3RBX7Network16ClientReplicator38readStreamModelPersistentPlayerAddItemEPNS0_46DeserializedStreamModelPersistentPlayerAddItemE
__int64 __fastcall RBX::Network::ClientReplicator::readStreamModelPersistentPlayerAddItem(
        RBX::Network::ClientReplicator *this,
        RBX::Network::DeserializedStreamModelPersistentPlayerAddItem *a2)
{
  RBX::Network::StreamingSolverV2 *v2; // rdi
  __int64 result; // rax

  v2 = *((RBX::Network::StreamingSolverV2 **)this + 2755); /*0x10670ecc0*/
  if ( v2 != nullptr ) /*0x10670ecca*/
    return RBX::Network::StreamingSolverV2::clientPersistentPerPlayerModelChanged( /*0x10670ecd6*/
             this: v2,
             a2: (RBX::Network::DeserializedStreamModelPersistentPlayerAddItem *)((char *)a2 + 32),
             a3: true);
  return result; /*0x10670ecd5*/
}

// Address: 0x10670ecde | Name: __ZN3RBX7Network16ClientReplicator41readStreamModelPersistentPlayerRemoveItemEPNS0_49DeserializedStreamModelPersistentPlayerRemoveItemE
__int64 __fastcall RBX::Network::ClientReplicator::readStreamModelPersistentPlayerRemoveItem(
        RBX::Network::ClientReplicator *this,
        RBX::Network::DeserializedStreamModelPersistentPlayerRemoveItem *a2)
{
  RBX::Network::StreamingSolverV2 *v2; // rdi
  __int64 result; // rax

  v2 = *((RBX::Network::StreamingSolverV2 **)this + 2755); /*0x10670ece2*/
  if ( v2 != nullptr ) /*0x10670ecec*/
    return RBX::Network::StreamingSolverV2::clientPersistentPerPlayerModelChanged( /*0x10670ecf5*/
             this: v2,
             a2: (RBX::Network::DeserializedStreamModelPersistentPlayerRemoveItem *)((char *)a2 + 32),
             a3: false);
  return result; /*0x10670ecf4*/
}

// Address: 0x10670ecfc | Name: __ZN3RBX7Network16ClientReplicator22readInstanceIntentItemEPNS0_30DeserializedInstanceIntentItemE
void __fastcall RBX::Network::ClientReplicator::readInstanceIntentItem(
        RBX::Network::ClientReplicator *this,
        RBX::Network::DeserializedInstanceIntentItem *a2)
{
  __int64 v2; // r14
  __int64 i; // r15
  RBX::Instance *v5; // rdi
  __int64 v6; // r12
  __int64 v7; // r13
  __int64 v8; // rax
  std::__shared_weak_count *v9; // r13
  __int64 v10; // [rsp+8h] [rbp-38h] BYREF
  std::__shared_weak_count *v11; // [rsp+10h] [rbp-30h]

  v2 = *((_QWORD *)a2 + 4); /*0x10670ed0d*/
  for ( i = *((_QWORD *)a2 + 5); v2 != i; v2 += 12 ) /*0x10670ed18*/
  {
    RBX::GuidItem<RBX::Object>::Registry::getByGuid(a1: &v10, a2: *((_QWORD *)this + 22)); /*0x10670ed2f*/
    v6 = v10; /*0x10670ed34*/
    if ( v10 != 0 ) /*0x10670ed3b*/
    {
      v7 = *(_QWORD *)(v10 + 24); /*0x10670ed3d*/
      v8 = RBX::Instance::classDescriptor(this: v5); /*0x10670ed42*/
      if ( *(unsigned __int16 *)(v7 + 440) - (unsigned int)*(unsigned __int16 *)(v8 + 440) > *(unsigned __int16 *)(v8 + 442) ) /*0x10670ed66*/
        v6 = 0; /*0x10670ed66*/
    }
    else
    {
      v6 = 0; /*0x10670ed6c*/
    }
    v9 = v11; /*0x10670ed6f*/
    if ( v11 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v11 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10670ed88*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v9 + 16LL))(a1: v9); /*0x10670ed91*/
      std::__shared_weak_count::__release_weak(this: v9); /*0x10670ed97*/
    }
    if ( v6 != 0 ) /*0x10670ed9f*/
      RBX::CollectionService::onTagRuleChanging(a1: *((_QWORD *)this + 2316), a2: v6, a3: *(unsigned __int8 *)(v2 + 8)); /*0x10670edb0*/
  }
}

// Address: 0x10670ede8 | Name: __ZN3RBX7Network16ClientReplicator23checkDistributedReceiveEPNS_8BasePartE
bool __fastcall RBX::Network::ClientReplicator::checkDistributedReceive(
        RBX::Network::ClientReplicator *this,
        RBX::BasePart *a2)
{
  return (unsigned int)RBX::BasePartProp::getNetworkOwner(this: (RBX::BasePart *)((char *)a2 + 184)) != *((_DWORD *)this + 5500); /*0x10670ee0a*/
}

// Address: 0x10670ee0e | Name: __ZN3RBX7Network16ClientReplicator18requestServerStatsEb
void __fastcall RBX::Network::ClientReplicator::requestServerStats(RBX::Network::ClientReplicator *this, char a2)
{
  __int64 v4; // rdx
  __int64 v5; // rcx
  const char *v6; // rsi
  __int64 v7; // r8
  __int64 v8; // r9
  __m128 v9; // xmm0
  __m128 v10; // xmm1
  __m128 v11; // xmm2
  __m128 v12; // xmm3
  __m128 v13; // xmm4
  __m128 v14; // xmm5
  __m128 v15; // xmm6
  __m128 v16; // xmm7
  RBX::Network *v17; // rdi
  unsigned __int64 v18; // rsi
  __int64 v19; // rbx
  __int64 v20; // r14
  std::__shared_weak_count *v21; // rbx
  __int64 v22; // r14
  char v23; // [rsp+0h] [rbp-B0h]
  _BYTE v24[64]; // [rsp+18h] [rbp-98h] BYREF
  _DWORD v25[12]; // [rsp+58h] [rbp-58h] BYREF
  __int64 v26; // [rsp+88h] [rbp-28h] BYREF
  std::__shared_weak_count *v27; // [rsp+90h] [rbp-20h]

  if ( (unsigned __int8)RBX::Network::flagsSendsGoThroughConnection(this) != 0 ) /*0x10670ee2b*/
  {
    if ( *((_QWORD *)this + 35) == 0 ) /*0x10670ee35*/
      goto LABEL_3; /*0x10670ee35*/
  }
  else if ( *((_QWORD *)this + 28) == 0 ) /*0x10670ee4d*/
  {
LABEL_3:
    RBX::throw_runtime_error( /*0x10670ee37*/
      this: (RBX *)"not connected to a server",
      a2: v6,
      a3: v4,
      a4: v5,
      a5: v7,
      a6: v8,
      a7: v9,
      a8: v10,
      a9: v11,
      a10: v12,
      a11: v13,
      a12: v14,
      a13: v15,
      a14: v16,
      a15: v23);
  }
  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)v24); /*0x10670ee59*/
  LOBYTE(v25[0]) = -106; /*0x10670ee62*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v24, a2: v25, a3: 1u); /*0x10670ee6d*/
  LOBYTE(v25[0]) = a2; /*0x10670ee76*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v24, a2: v25, a3: 1u); /*0x10670ee85*/
  if ( a2 != 0 ) /*0x10670ee8d*/
  {
    if ( FFlag::ReplacePhysicsStatsWhenISREnabled == 1 ) /*0x10670ee99*/
      v25[0] = 9; /*0x10670ee9f*/
    else
      v25[0] = 8; /*0x10670eebc*/
    RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v24, a2: v25, a3: 4u); /*0x10670eeb1*/
  }
  if ( (unsigned __int8)RBX::Network::flagsSendsGoThroughConnection(this: v17) != 0 ) /*0x10670eeda*/
  {
    v19 = *((_QWORD *)this + 35); /*0x10670eee0*/
    v20 = operator new(a1: (RBX::Memory *)0x58, a2: v18); /*0x10670eef1*/
    *(_OWORD *)(v20 + 8) = 0; /*0x10670eef7*/
    *(_QWORD *)v20 = &off_10CAAE190; /*0x10670ef02*/
    RBX::Network::NetworkStream::NetworkStream(a1: v20 + 24, a2: v24); /*0x10670ef16*/
    v26 = v20 + 24; /*0x10670ef1f*/
    v27 = (std::__shared_weak_count *)v20; /*0x10670ef22*/
    (*(void (__fastcall **)(__int64, __int64, __int64 *, _QWORD, _QWORD))(*(_QWORD *)v19 + 48LL))( /*0x10670ef36*/
      a1: v19,
      a2: 1,
      a3: &v26,
      a4: 0,
      a5: 0);
    v21 = v27; /*0x10670ef39*/
    if ( v27 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v27 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10670ef56*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v21 + 16LL))(a1: v21); /*0x10670ef5e*/
      std::__shared_weak_count::__release_weak(this: v21); /*0x10670ef64*/
    }
  }
  else
  {
    v22 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)this + 28)); /*0x10670ef77*/
    RakNet::AddressOrGUID::AddressOrGUID( /*0x10670ef88*/
      this: (RakNet::AddressOrGUID *)v25,
      a2: (RBX::Network::ClientReplicator *)((char *)this + 240));
    (*(void (__fastcall **)(__int64, _BYTE *, __int64, __int64, _QWORD, _DWORD *, _DWORD, _DWORD, _QWORD))(*(_QWORD *)v22 + 184LL))( /*0x10670efc4*/
      a1: v22,
      a2: v24,
      a3: 2,
      a4: 3,
      a5: 0,
      a6: v25,
      a7: 0,
      a8: 0,
      a9: 0);
  }
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v24); /*0x10670efcd*/
}

// Address: 0x10670f006 | Name: __ZN3RBX7Network16ClientReplicator19requestProfilerDataEii
void __fastcall RBX::Network::ClientReplicator::requestProfilerData(
        RBX::Network::ClientReplicator *this,
        int a2,
        int a3)
{
  __int64 v6; // rdx
  __int64 v7; // rcx
  const char *v8; // rsi
  __int64 v9; // r8
  __int64 v10; // r9
  __m128 v11; // xmm0
  __m128 v12; // xmm1
  __m128 v13; // xmm2
  __m128 v14; // xmm3
  __m128 v15; // xmm4
  __m128 v16; // xmm5
  __m128 v17; // xmm6
  __m128 v18; // xmm7
  char v19; // r13
  RBX::Network *v20; // rdi
  unsigned __int64 v21; // rsi
  __int64 v22; // rbx
  __int64 v23; // r14
  std::__shared_weak_count *v24; // rbx
  __int64 v25; // r14
  char v26; // [rsp+0h] [rbp-C0h]
  _BYTE v27[64]; // [rsp+18h] [rbp-A8h] BYREF
  _DWORD v28[12]; // [rsp+58h] [rbp-68h] BYREF
  __int64 v29; // [rsp+88h] [rbp-38h] BYREF
  std::__shared_weak_count *v30; // [rsp+90h] [rbp-30h]

  if ( (unsigned __int8)RBX::Network::flagsSendsGoThroughConnection(this) != 0 ) /*0x10670f02a*/
  {
    if ( *((_QWORD *)this + 35) == 0 ) /*0x10670f034*/
      goto LABEL_3; /*0x10670f034*/
  }
  else if ( *((_QWORD *)this + 28) == 0 ) /*0x10670f04c*/
  {
LABEL_3:
    RBX::throw_runtime_error( /*0x10670f036*/
      this: (RBX *)"not connected to a server",
      a2: v8,
      a3: v6,
      a4: v7,
      a5: v9,
      a6: v10,
      a7: v11,
      a8: v12,
      a9: v13,
      a10: v14,
      a11: v15,
      a12: v16,
      a13: v17,
      a14: v18,
      a15: v26);
  }
  if ( *((_BYTE *)this + 18384) == 0 ) /*0x10670f055*/
  {
    *((_BYTE *)this + 18384) = 1; /*0x10670f05b*/
    v19 = DFFlag::DebugRemoteRequestEnableAllTimerGroups; /*0x10670f062*/
    RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)v27); /*0x10670f073*/
    LOBYTE(v28[0]) = -103; /*0x10670f07c*/
    RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v27, a2: v28, a3: 1u); /*0x10670f087*/
    v28[0] = 2; /*0x10670f090*/
    RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v27, a2: v28, a3: 4u); /*0x10670f0a2*/
    if ( a2 <= 0 ) /*0x10670f0aa*/
      a2 = DFInt::DebugClientSvrProfilerFramesOverride; /*0x10670f0ac*/
    v28[0] = a2; /*0x10670f0b7*/
    RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v27, a2: v28, a3: 4u); /*0x10670f0c6*/
    if ( a3 <= 0 ) /*0x10670f0ce*/
      a3 = DFInt::DebugClientSvrProfilerCaptTimeOverride; /*0x10670f0d0*/
    v28[0] = a3; /*0x10670f0db*/
    RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v27, a2: v28, a3: 4u); /*0x10670f0ea*/
    LOBYTE(v28[0]) = v19; /*0x10670f0f3*/
    RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v27, a2: v28, a3: 1u); /*0x10670f102*/
    if ( (unsigned __int8)RBX::Network::flagsSendsGoThroughConnection(this: v20) != 0 ) /*0x10670f10e*/
    {
      v22 = *((_QWORD *)this + 35); /*0x10670f114*/
      v23 = operator new(a1: (RBX::Memory *)0x58, a2: v21); /*0x10670f125*/
      *(_OWORD *)(v23 + 8) = 0; /*0x10670f12b*/
      *(_QWORD *)v23 = &off_10CAAE190; /*0x10670f136*/
      RBX::Network::NetworkStream::NetworkStream(a1: v23 + 24, a2: v27); /*0x10670f14a*/
      v29 = v23 + 24; /*0x10670f153*/
      v30 = (std::__shared_weak_count *)v23; /*0x10670f156*/
      (*(void (__fastcall **)(__int64, __int64, __int64 *, _QWORD, _QWORD))(*(_QWORD *)v22 + 48LL))( /*0x10670f16a*/
        a1: v22,
        a2: 1,
        a3: &v29,
        a4: 0,
        a5: 0);
      v24 = v30; /*0x10670f16d*/
      if ( v30 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v30 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10670f18a*/
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v24 + 16LL))(a1: v24); /*0x10670f192*/
        std::__shared_weak_count::__release_weak(this: v24); /*0x10670f198*/
      }
    }
    else
    {
      v25 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)this + 28)); /*0x10670f1ab*/
      RakNet::AddressOrGUID::AddressOrGUID( /*0x10670f1bc*/
        this: (RakNet::AddressOrGUID *)v28,
        a2: (RBX::Network::ClientReplicator *)((char *)this + 240));
      (*(void (__fastcall **)(__int64, _BYTE *, __int64, __int64, _QWORD, _DWORD *, _DWORD, _DWORD, _QWORD))(*(_QWORD *)v25 + 184LL))( /*0x10670f1f8*/
        a1: v25,
        a2: v27,
        a3: 2,
        a4: 3,
        a5: 0,
        a6: v28,
        a7: 0,
        a8: 0,
        a9: 0);
    }
    RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v27); /*0x10670f201*/
  }
}

// Address: 0x10670f23e | Name: __ZN3RBX7Network16ClientReplicator33hasEnoughMemoryToReceiveInstancesEv
bool __fastcall RBX::Network::ClientReplicator::hasEnoughMemoryToReceiveInstances(RBX::Network::ClientReplicator *this)
{
  return *(_BYTE *)(*((_QWORD *)this + 2753) + 836LL) == 0 && *((_DWORD *)this + 5630) >= 5; /*0x10670f260*/
}

// Address: 0x10670f262 | Name: __ZN3RBX7Network16ClientReplicator6needGCEv
bool __fastcall RBX::Network::ClientReplicator::needGC(RBX::Network::ClientReplicator::GCJob **this)
{
  char v2; // cl
  bool result; // al

  v2 = RBX::Network::ClientReplicator::GCJob::pendingGC(this: *(this + 2753)); /*0x10670f277*/
  result = true; /*0x10670f279*/
  if ( v2 == 0 ) /*0x10670f27d*/
    return *((_DWORD *)this + 5630) < 3; /*0x10670f286*/
  return result; /*0x10670f28d*/
}

// Address: 0x10670f290 | Name: __ZN3RBX7Network16ClientReplicator23canUpdateClientCapacityEv
bool __fastcall RBX::Network::ClientReplicator::canUpdateClientCapacity(RBX::Network::ClientReplicator *this)
{
  double v2; // xmm0_8
  double v3; // xmm1_8

  RBX::Time::nowFastSec(this); /*0x10670f299*/
  v3 = v2 - *((double *)this + 2940); /*0x10670f2a2*/
  if ( v3 > 0.125 ) /*0x10670f2b2*/
    *((double *)this + 2940) = v2; /*0x10670f2b4*/
  return v3 > 0.125; /*0x10670f2cb*/
}

// Address: 0x10670f2ce | Name: __ZN3RBX7Network16ClientReplicator17updateMemoryStatsEv
void __fastcall RBX::Network::ClientReplicator::updateMemoryStats(RBX::Network::ClientReplicator *this)
{
  RBX::CoreNetworkSettings *v2; // r14
  RBX::CoreNetworkSettings *v3; // rdi
  RBX::CoreNetworkSettings *v4; // rax
  RBX::CoreNetworkSettings *v5; // rdi
  __int64 v6; // rax
  unsigned __int64 v7; // rsi
  unsigned int v8; // eax
  int v9; // esi
  RBX::Time *v10; // rdi
  __int64 v11; // rax
  char v12; // al
  char v13; // al
  _BYTE *v14; // r12
  _BYTE *v15; // r14
  char v16; // r15
  __int64 v17; // rax
  unsigned __int64 v18; // rsi
  char v19; // cl
  char v20; // r13
  __int64 v21; // xmm0_8
  __int64 v22; // rax
  __int64 v23; // rax
  unsigned __int8 v24; // r8
  _QWORD v25[18]; // [rsp+0h] [rbp-90h] BYREF

  if ( (_BYTE)`guard variable for'RBX::Network::ClientReplicator::updateMemoryStats(void)::proftoken3995 == 0 /*0x10670f4e4*/
    && __cxa_guard_acquire(a1: &`guard variable for'RBX::Network::ClientReplicator::updateMemoryStats(void)::proftoken3995) != 0 )
  {
    v25[0] = "sControlChannel"; /*0x10670f50d*/
    RBX::Network::ClientReplicator::updateMemoryStats(void)::proftoken3995 = (RBX::CoreNetworkSettings *)RBX::Profiler::getToken(this: (RBX::Profiler *)&aAttemptingToSt_0[-511406], a2: &aNewscriptedita_18[-932433], a3: (const char *)0xFFFFFFFFLL, a4: 255, a5: v24); /*0x10670f531*/
    __cxa_guard_release(a1: &`guard variable for'RBX::Network::ClientReplicator::updateMemoryStats(void)::proftoken3995); /*0x10670f53f*/
  }
  v2 = RBX::Network::ClientReplicator::updateMemoryStats(void)::proftoken3995; /*0x10670f2f0*/
  *(_OWORD *)v25 = 0; /*0x10670f301*/
  v25[3] = -1; /*0x10670f305*/
  memset(&v25[4], 0, 52); /*0x10670f30d*/
  *(_OWORD *)&v25[11] = 0; /*0x10670f324*/
  v25[2] = RBX::Network::ClientReplicator::updateMemoryStats(void)::proftoken3995; /*0x10670f329*/
  RBX::Profiler::ActiveRegion::enter(this: (RBX::Profiler::ActiveRegion *)v25); /*0x10670f330*/
  v25[3] = RBX::Profiler::enterRegion(a1: v2, a2: -1, a3: 0); /*0x10670f346*/
  v4 = (RBX::CoreNetworkSettings *)RBX::CoreNetworkSettings::singleton(this: v3); /*0x10670f34a*/
  RBX::CoreNetworkSettings::updateClientMemoryEmulation(this: v4); /*0x10670f352*/
  if ( DFFlag::TrackingGcStats != 1 ) /*0x10670f35e*/
  {
    v17 = RBX::CoreNetworkSettings::singleton(this: v5); /*0x10670f3d7*/
    *((_DWORD *)this + 5630) = RBX::MemoryStats::slowCheckMemoryLevel( /*0x10670f3ec*/
                                 this: (RBX::MemoryStats *)((__int64)*(int *)(v17 + 148) << 20),
                                 a2: v18);
    goto LABEL_9; /*0x10670f3ec*/
  }
  v6 = RBX::CoreNetworkSettings::singleton(this: v5); /*0x10670f360*/
  v8 = RBX::MemoryStats::slowCheckMemoryLevel(this: (RBX::MemoryStats *)((__int64)*(int *)(v6 + 148) << 20), a2: v7); /*0x10670f370*/
  *((_DWORD *)this + 5630) = v8; /*0x10670f375*/
  RBX::RunningAverage<int,double>::sample(a1: (char *)this + 22480, a2: v8); /*0x10670f384*/
  if ( (unsigned __int8)RBX::Analytics::InfluxDb::canSend( /*0x10670f396*/
                          this: (RBX::Analytics::InfluxDb *)(unsigned int)DFInt::TrackingGcStatsHundredths,
                          a2: v9) != 0 )
  {
    v11 = *((_QWORD *)this + 2753); /*0x10670f398*/
    if ( v11 != 0 && (v12 = *(_BYTE *)(v11 + 836), *((_BYTE *)this + 22530) != v12) ) /*0x10670f3b0*/
    {
      *((_BYTE *)this + 22530) = v12; /*0x10670f40d*/
      v14 = (char *)this + 22528; /*0x10670f413*/
      v15 = (char *)this + 22529; /*0x10670f41a*/
      v19 = *((_BYTE *)this + 22529); /*0x10670f421*/
      v13 = *((_DWORD *)this + 5630) == 0; /*0x10670f42e*/
      v16 = 1; /*0x10670f431*/
      v20 = 1; /*0x10670f434*/
      if ( v19 == v13 ) /*0x10670f439*/
      {
LABEL_12:
        if ( *((_BYTE *)this + 22530) != 0 || v19 != 0 ) /*0x10670f451*/
        {
          RBX::Time::nowFast(this: v10); /*0x10670f453*/
          if ( *v14 == 0 ) /*0x10670f45d*/
          {
            *((_BYTE *)this + 22528) = 1; /*0x10670f45f*/
            v22 = *((_QWORD *)this + 2753); /*0x10670f466*/
            if ( v22 != 0 ) /*0x10670f470*/
              v23 = *(_QWORD *)(v22 + 792); /*0x10670f472*/
            else
              v23 = 0; /*0x10670f488*/
            *((_QWORD *)this + 2818) = v23; /*0x10670f48a*/
            *((_QWORD *)this + 2819) = v23; /*0x10670f491*/
            *((_QWORD *)this + 2820) = v21; /*0x10670f498*/
          }
          if ( v20 != 0 && *((_BYTE *)this + 22530) == 1 ) /*0x10670f4ac*/
            *((_QWORD *)this + 2822) = v21; /*0x10670f4ae*/
          if ( v16 == 0 && *v15 == 1 ) /*0x10670f4c3*/
            *((_QWORD *)this + 2821) = v21; /*0x10670f4c9*/
        }
        else
        {
          RBX::Network::ClientReplicator::reportGCStatsAndReset(this); /*0x10670f47e*/
        }
        goto LABEL_9; /*0x10670f4d1*/
      }
    }
    else
    {
      v13 = *((_DWORD *)this + 5630) == 0; /*0x10670f3b9*/
      if ( *((_BYTE *)this + 22529) == v13 ) /*0x10670f3c2*/
        goto LABEL_9; /*0x10670f3c2*/
      v14 = (char *)this + 22528; /*0x10670f3c4*/
      v15 = (char *)this + 22529; /*0x10670f3cb*/
      v16 = 0; /*0x10670f3d2*/
    }
    v20 = v16; /*0x10670f43b*/
    *v15 = v13; /*0x10670f43e*/
    v16 = 0; /*0x10670f441*/
    v19 = v13; /*0x10670f444*/
    goto LABEL_12; /*0x10670f444*/
  }
LABEL_9:
  RBX::Profiler::Scope::~Scope(this: (RBX::Profiler::Scope *)v25); /*0x10670f3f2*/
}

// Address: 0x10670f576 | Name: __ZN3RBX7Network16ClientReplicator21reportGCStatsAndResetEv
__int64 __fastcall RBX::Network::ClientReplicator::reportGCStatsAndReset(RBX::Network::ClientReplicator *this)
{
  RBX::Time *v2; // rdi
  double v3; // xmm0_8
  __m128d v4; // xmm2
  int v5; // eax
  double v6; // xmm0_8
  int v7; // eax
  double v8; // xmm0_8
  int v9; // eax
  double v10; // xmm0_8
  int v11; // eax
  double v12; // xmm0_8
  __int64 v13; // rax
  __int64 v14; // rdx
  unsigned __int8 *v15; // rcx
  __int64 v16; // rax
  void *v17; // rsi
  double v19; // [rsp+0h] [rbp-220h]
  _BYTE v20[16]; // [rsp+18h] [rbp-208h] BYREF
  void *v21; // [rsp+28h] [rbp-1F8h]
  void *v22[59]; // [rsp+30h] [rbp-1F0h] BYREF

  RBX::Analytics::InfluxDb::Points::Points(a1: v22, a2: 0xFFFFFFFFLL, a3: 0, a4: 0); /*0x10670f5a5*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670f5bf*/
    this: (RBX::Analytics::InfluxDb::Points *)v22,
    a2: "underMemoryPressure",
    a3: *((_BYTE *)this + 22529));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670f5d9*/
    this: (RBX::Analytics::InfluxDb::Points *)v22,
    a2: "underEmergencyGc",
    a3: *((_BYTE *)this + 22530));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670f5f2*/
    this: (RBX::Analytics::InfluxDb::Points *)v22,
    a2: "lastMemoryLevel",
    a3: *((_DWORD *)this + 5630));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670f60b*/
    this: (RBX::Analytics::InfluxDb::Points *)v22,
    a2: "numGCsAfterMemoryPressure",
    a3: *((_DWORD *)this + 5633));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670f624*/
    this: (RBX::Analytics::InfluxDb::Points *)v22,
    a2: "numRegionsGCAfterMemoryPressure",
    a3: *((_DWORD *)this + 5634));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670f63d*/
    this: (RBX::Analytics::InfluxDb::Points *)v22,
    a2: "numInstancesGCAfterMemoryPressure",
    a3: *((_DWORD *)this + 5635));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670f657*/
    this: (RBX::Analytics::InfluxDb::Points *)v22,
    a2: "radiusStartMemoryPressure",
    a3: *((_QWORD *)this + 2818));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670f671*/
    this: (RBX::Analytics::InfluxDb::Points *)v22,
    a2: "radiusLatest",
    a3: *((_QWORD *)this + 2819));
  RBX::Time::nowFast(this: v2); /*0x10670f676*/
  v19 = v3; /*0x10670f683*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670f69d*/
    this: (RBX::Analytics::InfluxDb::Points *)v22,
    a2: "timeGcTracked",
    a3: v3 - *((double *)this + 2820));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670f6d1*/
    this: (RBX::Analytics::InfluxDb::Points *)v22,
    a2: "timeUnderMemoryPressure",
    a3: COERCE_DOUBLE(
      ~*(__int64 *)&_mm_cmpeq_sd((__m128d)*((unsigned __int64 *)this + 2821), (__m128d)0LL).f64[0]
    & COERCE_UNSIGNED_INT64(v19 - *((double *)this + 2821))));
  v4.f64[0] = *((double *)this + 2822); /*0x10670f6d6*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670f705*/
    this: (RBX::Analytics::InfluxDb::Points *)v22,
    a2: "timeUnderEmergencyGC",
    a3: COERCE_DOUBLE(~*(__int64 *)&_mm_cmpeq_sd((__m128d)0LL, v4).f64[0] & COERCE_UNSIGNED_INT64(v19 - v4.f64[0])));
  v5 = *((_DWORD *)this + 5662); /*0x10670f70a*/
  v6 = 0.0; /*0x10670f710*/
  if ( v5 != 0 ) /*0x10670f716*/
    v6 = *((double *)this + 2830) / (double)v5; /*0x10670f728*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670f73a*/
    this: (RBX::Analytics::InfluxDb::Points *)v22,
    a2: "instanceQuotaMemoryPressureAvg",
    a3: v6);
  v7 = *((_DWORD *)this + 5680); /*0x10670f73f*/
  v8 = 0.0; /*0x10670f745*/
  if ( v7 != 0 ) /*0x10670f74b*/
    v8 = *((double *)this + 2839) / (double)v7; /*0x10670f75d*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670f76f*/
    this: (RBX::Analytics::InfluxDb::Points *)v22,
    a2: "deletionRateMemoryPressureAvg",
    a3: v8);
  v9 = *((_DWORD *)this + 5698); /*0x10670f774*/
  v10 = 0.0; /*0x10670f77a*/
  if ( v9 != 0 ) /*0x10670f780*/
    v10 = *((double *)this + 2848) / (double)v9; /*0x10670f792*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670f7a4*/
    this: (RBX::Analytics::InfluxDb::Points *)v22,
    a2: "improvedInstanceQuotaMemoryPressureAvg",
    a3: v10);
  v11 = *((_DWORD *)this + 5716); /*0x10670f7a9*/
  v12 = 0.0; /*0x10670f7af*/
  if ( v11 != 0 ) /*0x10670f7b5*/
    v12 = *((double *)this + 2857) / (double)v11; /*0x10670f7c7*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670f7d9*/
    this: (RBX::Analytics::InfluxDb::Points *)v22,
    a2: "improvedDeletionRateMemoryPressureAvg",
    a3: v12);
  v13 = RBX::ServiceProvider::find<RBX::Workspace>(a1: this); /*0x10670f7e1*/
  if ( v13 != 0 ) /*0x10670f7e9*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x10670f7ff*/
      this: (RBX::Analytics::InfluxDb::Points *)v22,
      a2: "ModelStreamingBehavior",
      a3: *(_DWORD *)(v13 + 1204));
  if ( DFFlag::ClientNetworkTelemetryRCCChannelName == 1 )
  {
    v15 = SFString::RCCChannelName; /*0x10670f80d*/
    v16 = (SFString::RCCChannelName[0] & 1) != 0
        ? *(_QWORD *)&SFString::RCCChannelName[8]
        : SFString::RCCChannelName[0] >> 1;
    if ( v16 != 0 ) /*0x10670f826*/
      RBX::Analytics::InfluxDb::Points::addPoint(a1: v22, a2: "rccChannelName", a3: SFString::RCCChannelName); /*0x10670f83d*/
  }
  std::string::basic_string[abi:ne200100]<0>(a1: v20, a2: "TrackingGcStats", a3: v14, a4: v15); /*0x10670f850*/
  RBX::Analytics::InfluxDb::Points::report(a1: v22, a2: v20, a3: (unsigned int)DFInt::TrackingGcStatsHundredths, a4: 0); /*0x10670f86b*/
  if ( (v20[0] & 1) != 0 ) /*0x10670f87e*/
    operator delete(a1: (RBX::Memory *)v21, a2: v17); /*0x10670f887*/
  *((_WORD *)this + 11264) = 0; /*0x10670f88c*/
  *((_BYTE *)this + 22530) = 0; /*0x10670f895*/
  *((_OWORD *)this + 1412) = 0; /*0x10670f8a0*/
  *((_QWORD *)this + 2826) = 0; /*0x10670f8aa*/
  *(_OWORD *)((char *)this + 22564) = 0; /*0x10670f8b1*/
  *(_OWORD *)((char *)this + 22548) = 0; /*0x10670f8b7*/
  *(_OWORD *)((char *)this + 22532) = 0; /*0x10670f8bd*/
  *((_DWORD *)this + 5645) = 0; /*0x10670f8c2*/
  *((_BYTE *)this + 22616) = 1; /*0x10670f8cc*/
  *((_OWORD *)this + 1414) = 0; /*0x10670f8d2*/
  *(_OWORD *)((char *)this + 22636) = 0; /*0x10670f8da*/
  *(_OWORD *)((char *)this + 22664) = 0; /*0x10670f8e2*/
  *((_QWORD *)this + 2835) = 0; /*0x10670f8ea*/
  *((_BYTE *)this + 22688) = 1; /*0x10670f8f1*/
  *(_OWORD *)((char *)this + 22696) = 0; /*0x10670f8f7*/
  *(_OWORD *)((char *)this + 22708) = 0; /*0x10670f8ff*/
  *((_OWORD *)this + 1421) = 0; /*0x10670f907*/
  *((_QWORD *)this + 2844) = 0; /*0x10670f90f*/
  *((_BYTE *)this + 22760) = 1; /*0x10670f916*/
  *((_OWORD *)this + 1423) = 0; /*0x10670f91c*/
  *(_OWORD *)((char *)this + 22780) = 0; /*0x10670f924*/
  *(_OWORD *)((char *)this + 22808) = 0; /*0x10670f92c*/
  *((_QWORD *)this + 2853) = 0; /*0x10670f934*/
  *((_BYTE *)this + 22832) = 1; /*0x10670f93b*/
  *(_OWORD *)((char *)this + 22852) = 0; /*0x10670f941*/
  *(_OWORD *)((char *)this + 22840) = 0; /*0x10670f949*/
  RBX::Analytics::InfluxDb::Points::~Points(this: v22); /*0x10670f958*/
  return __stack_chk_guard; /*0x10670f96d*/
}

// Address: 0x10670f9c8 | Name: __ZNK3RBX7Network16ClientReplicator35getCurrentStreamedInDistanceInStudsEv
__int64 __fastcall RBX::Network::ClientReplicator::getCurrentStreamedInDistanceInStuds(
        RBX::Network::ClientReplicator *this)
{
  __int64 v1; // rax

  v1 = *((_QWORD *)this + 2753); /*0x10670f9c8*/
  if ( v1 != 0 ) /*0x10670f9d2*/
    return *(_QWORD *)(v1 + 792); /*0x10670f9d8*/
  else
    return 0; /*0x10670f9e1*/
}

// Address: 0x10670f9e4 | Name: __ZN3RBX7Network16ClientReplicator21requireGarbageCollectEv
__int64 __fastcall RBX::Network::ClientReplicator::requireGarbageCollect(RBX::Network::ClientReplicator *this)
{
  RBX::Network::ClientReplicator::GCJob *v1; // rdi
  __int64 result; // rax

  v1 = *((RBX::Network::ClientReplicator::GCJob **)this + 2753); /*0x10670f9e8*/
  if ( v1 != nullptr ) /*0x10670f9f2*/
    return RBX::Network::ClientReplicator::GCJob::triggerEmergencyGC(this: v1); /*0x10670f9f5*/
  return result; /*0x10670f9f4*/
}

// Address: 0x10670f9fc | Name: __ZN3RBX7Network16ClientReplicator20updateClientCapacityEv
void __fastcall RBX::Network::ClientReplicator::updateClientCapacity(RBX::Network::ClientReplicator *this)
{
  unsigned __int8 v2; // r15
  RBX::Network::ClientReplicator::GCJob *v3; // rdi
  unsigned __int8 isGCRequested; // r14
  RBX::MemoryStats *v5; // rdi
  double v6; // xmm0_8
  __int64 v7; // rax
  int *v8; // r14
  __int64 v9; // r14
  __int64 v10; // r15
  int v11; // r12d
  int v12; // r13d
  RBX::MemoryStats *v13; // rdi
  int v14; // eax
  __int128 v15; // xmm0
  int FullInterval; // r15d
  __int64 v17; // rax
  __int64 v18; // rax
  __int64 v19; // rdi
  double v20; // xmm1_8
  __int128 v21; // xmm0
  int *v22; // r12
  int v23; // r15d
  unsigned int v24; // r14d
  int v25; // eax
  __m128 v26; // xmm1
  __int64 v27; // r15
  __int64 v28; // rax
  float v29; // xmm0_4
  __int64 v30; // rdi
  double v31; // xmm0_8
  int v32; // eax
  int v33; // esi
  __m128d v34; // xmm0
  __m128 v35; // xmm2
  double v36; // xmm0_8
  __m128 v37; // xmm1
  double v38; // xmm2_8
  __m128 v39; // xmm0
  __m128 v40; // xmm1
  __m128 v41; // xmm4
  char v42; // al
  float v43; // xmm0_4
  const char *v44; // rsi
  __m128 v45; // xmm3
  __m128i v46; // xmm0
  int v47; // eax
  int isStreamingTunableEnabled; // eax
  __int64 v49; // rdi
  RBX::Network::ClientReplicator::GCJob *v50; // rdi
  int v51; // r15d
  int v52; // eax
  float v53; // xmm0_4
  int v54; // ecx
  const char *v55; // rsi
  int v56; // eax
  __int64 v57; // rdi
  int v58; // r13d
  double v59; // xmm0_8
  int v60; // r12d
  int v61; // r15d
  int v62; // r12d
  int v63; // r14d
  char v64; // al
  int *v65; // rax
  float v66; // xmm0_4
  int v67; // edx
  char v68; // al
  RBX::Network::ClientReplicator::GCJob *v69; // rdi
  char updated; // al
  char v71; // r15
  __int16 MaxRegionDistance; // ax
  bool v73; // r14
  unsigned int v74; // r12d
  RBX::Time *v75; // rdi
  double v76; // xmm0_8
  double v77; // xmm2_8
  int v78; // eax
  unsigned int v79; // r12d
  RBX::CoreNetworkSettings *v80; // rdi
  int v81; // r14d
  int v82; // eax
  int v83; // r8d
  int v84; // r9d
  unsigned __int64 v85; // rsi
  int v86; // eax
  __int64 v87; // r13
  __int64 v88; // r15
  char v89; // r14
  unsigned __int16 v90; // r14
  int v91; // eax
  __int64 v92; // rax
  __int16 v93; // ax
  void *v94; // rsi
  __int128 *v95; // [rsp+8h] [rbp-C8h] BYREF
  double v96; // [rsp+10h] [rbp-C0h]
  double v97; // [rsp+18h] [rbp-B8h]
  __m128 v98; // [rsp+20h] [rbp-B0h]
  __m128 v99; // [rsp+30h] [rbp-A0h]
  __int128 v100; // [rsp+40h] [rbp-90h] BYREF
  void *v101; // [rsp+50h] [rbp-80h]
  double v102[3]; // [rsp+60h] [rbp-70h]
  float v103; // [rsp+7Ch] [rbp-54h]
  double v104; // [rsp+80h] [rbp-50h]
  char v105; // [rsp+8Fh] [rbp-41h] BYREF
  __m128 inserted; // [rsp+90h] [rbp-40h]
  int v107; // [rsp+A0h] [rbp-30h]
  int v108; // [rsp+A4h] [rbp-2Ch]

  v2 = *((_BYTE *)this + 23881); /*0x10670fa13*/
  v3 = *((RBX::Network::ClientReplicator::GCJob **)this + 2753); /*0x10670fa1a*/
  if ( v3 != nullptr ) /*0x10670fa24*/
    isGCRequested = RBX::Network::ClientReplicator::GCJob::isGCRequested(this: v3); /*0x10670fa2b*/
  else
    isGCRequested = 0; /*0x10670fa30*/
  *((_BYTE *)this + 23881) = isGCRequested; /*0x10670fa33*/
  RBX::Time::nowFastSec(this: v3); /*0x10670fa3a*/
  if ( v6 - *((double *)this + 2940) <= 0.125 ) /*0x10670fa53*/
  {
    if ( (isGCRequested & (v2 ^ 1)) == 0 && *((_BYTE *)this + 23882) != 1 ) /*0x10670fa6f*/
      return; /*0x10670fa6f*/
  }
  else
  {
    *((double *)this + 2940) = v6; /*0x10670fa55*/
  }
  v7 = *((_QWORD *)this + 2753); /*0x10670fa75*/
  if ( *(_BYTE *)(v7 + 836) != 0 || *((int *)this + 5630) <= 4 )
  {
    if ( *((_BYTE *)this + 23880) == 0 )
    {
      v9 = DFLog::PartStreamingRequests; /*0x10670fb07*/
      if ( (unsigned __int8)DFLog::PartStreamingRequests >= 6u && BYTE1(DFLog::PartStreamingRequests) >= 3u )
      {
        v10 = qword_10D809998; /*0x10670fb24*/
        v11 = RBX::MemoryStats::freeMemoryBytes(this: v5); /*0x10670fb30*/
        v12 = FInt::StreamingCriticalLowMemWatermarkMB << 20; /*0x10670fb3d*/
        v14 = RBX::MemoryStats::freeMemoryBytes(this: v13); /*0x10670fb41*/
        FLog::FastLog(
          a1: v9,
          a2: v10,
          a3: "[DFLog::PartStreamingRequests] Not enough memory to request more parts: %u free, %u additional required",
          v11,
          v12 - v14);
      }
      *((_BYTE *)this + 23880) = 1; /*0x10670fb64*/
      v107 = *((_DWORD *)this + 5882); /*0x10670fb71*/
      v100 = 0; /*0x10670fb7f*/
      v101 = nullptr; /*0x10670fb83*/
      *((_DWORD *)this + 5882) = 0; /*0x10670fb8b*/
      std::string::assign(a1: &v100, a2: "QuotaNotEnoughMemoryFirstLowCount"); /*0x10670fb9c*/
      v8 = (int *)((char *)this + 23528); /*0x10670fba1*/
      LODWORD(v104) = 0; /*0x10670fbac*/
      v99.i32[0] = -1; /*0x10670fbb1*/
      v108 = 0; /*0x10670fbbb*/
      goto LABEL_89; /*0x10670fbc2*/
    }
    v108 = 0; /*0x10670faa5*/
  }
  else
  {
    *((_BYTE *)this + 23880) = 0; /*0x10670fa8e*/
    LOBYTE(v7) = 1; /*0x10670fa95*/
    v108 = v7; /*0x10670fa97*/
  }
  v8 = (int *)((char *)this + 23528); /*0x10670faac*/
  v107 = *((_DWORD *)this + 5882); /*0x10670fab9*/
  v100 = 0; /*0x10670fac0*/
  v101 = nullptr; /*0x10670fac8*/
  if ( *((_BYTE *)this + 22144) != 0 ) /*0x10670fad7*/
  {
    *v8 = DFInt::ClientInstanceQuotaInitial; /*0x10670fae3*/
    LODWORD(v104) = 0; /*0x10670faea*/
    std::string::assign(a1: &v100, a2: "QuotaInitialValueCount"); /*0x10670fafd*/
    goto LABEL_57; /*0x10670fb02*/
  }
  v104 = *((double *)this + 2766) / *((double *)this + 2761); /*0x10670fbd7*/
  *(_OWORD *)v102 = 0; /*0x10670fbe0*/
  if ( *((_BYTE *)this + 22208) == 0 ) /*0x10670fbec*/
  {
    v15 = 0; /*0x10670fbee*/
    *(float *)&v15 = *((double *)this + 2774); /*0x10670fbf1*/
    *(_OWORD *)v102 = v15; /*0x10670fbf9*/
    if ( DFFlag::StreamQuotaIncludeClusterTime == 1 ) /*0x10670fc04*/
    {
      FullInterval = RBX::TotalCountTimeInterval<int,(RBX::Time::SampleMethod)1>::sampleLastFullInterval(a1: (char *)this + 22216); /*0x10670fc12*/
      if ( FullInterval > 0 ) /*0x10670fc17*/
      {
        v17 = RBX::ServiceProvider::find<RBX::Workspace>(a1: this); /*0x10670fc1c*/
        if ( v17 != 0 ) /*0x10670fc24*/
        {
          v18 = *(_QWORD *)(v17 + 944); /*0x10670fc26*/
          if ( v18 != 0 ) /*0x10670fc30*/
          {
            v19 = *(_QWORD *)(v18 + 2056); /*0x10670fc32*/
            if ( v19 != 0 ) /*0x10670fc3c*/
            {
              v20 = *(float *)v102 /*0x10670fc5e*/
                  + RBX::TotalCountTimeInterval<double,(RBX::Time::SampleMethod)1>::sampleLastFullInterval(a1: v19 + 2792)
                  / (double)FullInterval;
              v21 = 0; /*0x10670fc62*/
              *(float *)&v21 = v20; /*0x10670fc65*/
              *(_OWORD *)v102 = v21; /*0x10670fc69*/
            }
          }
        }
      }
    }
  }
  v22 = (int *)((char *)this + 23528); /*0x10670fc6d*/
  v23 = RBX::TotalCountTimeInterval<int,(RBX::Time::SampleMethod)1>::sampleLastFullInterval(a1: (char *)this + 15080); /*0x10670fc7c*/
  if ( v23 <= 0 ) /*0x10670fc81*/
  {
    inserted = 0; /*0x10670fcc5*/
  }
  else
  {
    v24 = RBX::TotalCountTimeInterval<int,(RBX::Time::SampleMethod)1>::sampleLastFullInterval(a1: (char *)this + 22152); /*0x10670fc8f*/
    v25 = RBX::TotalCountTimeInterval<int,(RBX::Time::SampleMethod)1>::sampleLastFullInterval(a1: (char *)this + 22216); /*0x10670fc99*/
    v26 = 0; /*0x10670fca9*/
    v26.f32[0] = (float)v23; /*0x10670fcac*/
    inserted = _mm_div_ps(_mm_cvtepi32_ps(_mm_insert_epi32(_mm_cvtsi32_si128(v24), v25, 1)), _mm_moveldup_ps(v26)); /*0x10670fcbb*/
  }
  v99.i64[0] = *((_QWORD *)this + 2761); /*0x10670fcd2*/
  v27 = RBX::Network::Replicator::incomingPacketsCount(this); /*0x10670fce2*/
  v28 = RBX::Network::Replicator::incomingPacketsCount(this); /*0x10670fce8*/
  v8 = (int *)((char *)this + 23528); /*0x10670fced*/
  if ( v28 < 0 ) /*0x10670fcf3*/
    v29 = (float)(int)(((unsigned __int64)v28 >> 1) | v28 & 1) + (float)(int)(((unsigned __int64)v28 >> 1) | v28 & 1); /*0x10670fd13*/
  else
    v29 = (float)(int)v28; /*0x10670fcf8*/
  v103 = v29; /*0x10670fd17*/
  RBX::RunningAverage<float,double>::sample(a1: (char *)this + 22320, a2: *(double *)inserted.i64); /*0x10670fd27*/
  v98 = _mm_movehdup_ps(inserted); /*0x10670fd38*/
  RBX::RunningAverage<float,double>::sample(a1: (char *)this + 22360, a2: *(double *)v98.i64); /*0x10670fd3f*/
  v31 = RBX::Time::now<(RBX::Time::SampleMethod)1>(a1: v30); /*0x10670fd44*/
  v32 = 0; /*0x10670fd60*/
  if ( *((double *)this + 1886) >= v31 - *((double *)this + 1885) ) /*0x10670fd66*/
    v32 = *((_DWORD *)this + 3774); /*0x10670fd68*/
  v33 = 1; /*0x10670fd7a*/
  if ( DFInt::StreamingQuotaCalculationIntervalValue >= 2 ) /*0x10670fd7f*/
    v33 = DFInt::StreamingQuotaCalculationIntervalValue; /*0x10670fd7f*/
  RBX::RunningAverage<int,double>::sample(a1: (char *)this + 22440, a2: (unsigned int)(v32 / v33)); /*0x10670fd87*/
  v34 = _mm_sub_pd( /*0x10670fd99*/
          (__m128d)_mm_unpacklo_epi32((__m128i)(unsigned __int64)v27, (__m128i)xmmword_108F2F9A0),
          (__m128d)xmmword_108F2F9B0);
  v35 = 0; /*0x10670fdc0*/
  v35.f32[0] = v104; /*0x10670fdc3*/
  *(float *)v34.f64 = inserted.f32[0] * (*(double *)v99.i64 * _mm_hadd_pd(v34, v34).f64[0]); /*0x10670fdc8*/
  *(float *)&v104 = *(float *)v34.f64 * v35.f32[0]; /*0x10670fdd0*/
  if ( (inserted.f32[0] <= 0.0 || v35.f32[0] == 0.0) && (v98.f32[0] <= 0.0 || *(float *)v102 == 0.0) ) /*0x10670fdfb*/
  {
    if ( *v22 >= DFInt::ClientInstanceQuotaInitial ) /*0x10670ffa9*/
    {
      v44 = "QuotaUnchangedNoData"; /*0x10670ffb7*/
    }
    else
    {
      *v22 = DFInt::ClientInstanceQuotaInitial; /*0x10670ffab*/
      v44 = "QuotaNoProcessTimeValuesCount"; /*0x10670ffae*/
    }
  }
  else
  {
    v99 = v35; /*0x10670fe03*/
    if ( RBX::TotalCountTimeInterval<double,(RBX::Time::SampleMethod)1>::sampleLastFullInterval(a1: (char *)this + 15128) > 0.0 ) /*0x10670fe20*/
    {
      inserted.i64[0] = RBX::TotalCountTimeInterval<double,(RBX::Time::SampleMethod)1>::sampleLastFullInterval(a1: (char *)this + 15160); /*0x10670fe32*/
      v96 = RBX::TotalCountTimeInterval<double,(RBX::Time::SampleMethod)1>::sampleLastFullInterval(a1: (char *)this + 15128); /*0x10670fe3f*/
      v97 = RBX::TotalCountTimeInterval<double,(RBX::Time::SampleMethod)1>::sampleLastFullInterval(a1: (char *)this + 15192); /*0x10670fe53*/
      v36 = RBX::TotalCountTimeInterval<double,(RBX::Time::SampleMethod)1>::sampleLastFullInterval(a1: (char *)this + 15128); /*0x10670fe5e*/
      v37 = 0; /*0x10670fe88*/
      v37.f32[0] = fmin(1.0, fmax(0.0, *(double *)inserted.i64 / v96)); /*0x10670fe8b*/
      v38 = fmin(1.0, fmax(0.0, v97 / v36)); /*0x10670fea3*/
      v39 = 0; /*0x10670fea7*/
      v39.f32[0] = v38; /*0x10670feaa*/
      inserted = _mm_insert_ps(v37, v39, 16); /*0x10670feb4*/
    }
    v40 = (__m128)0x3E800000u; /*0x10670fec9*/
    v41 = (__m128)0x3E800000u; /*0x10670fed1*/
    v41.f32[0] = (float)(0.25 - *(float *)&v104) - (float)((float)(v98.f32[0] * v103) * *(float *)v102); /*0x10670fed9*/
    if ( DFFlag::StreamQuotaScaleInterval != 0 /*0x10670ff2b*/
      || DFFlag::StreamQuotaScaleIntervalTC == 1
      && (v98 = v41,
          v42 = (*(__int64 (__fastcall **)(RBX::Network::ClientReplicator *))(*(_QWORD *)this + 1032LL))(a1: this),
          v41 = v98,
          v40 = (__m128)0x3E800000u,
          v42 != 0) )
    {
      v40.f32[0] = fminf(v40.f32[0], fmaxf(0.0, v41.f32[0])) * 4.0; /*0x10670fef1*/
      v41 = v40; /*0x10670fef9*/
    }
    v43 = (float)DFInt::StreamQuotaMinDataPercent / 100.0; /*0x10670ff38*/
    if ( inserted.f32[0] > v43 || _mm_movehdup_ps(inserted).f32[0] > v43 ) /*0x10670ff50*/
    {
      v45 = _mm_insert_ps(v99, (__m128)LODWORD(v102[0]), 16); /*0x10670ff62*/
      v46 = (__m128i)_mm_and_ps( /*0x10670ff7e*/
                       _mm_cmpneq_ps((__m128)0LL, v45),
                       (__m128)_mm_cvttps_epi32(_mm_div_ps(_mm_mul_ps(inserted, _mm_moveldup_ps(v41)), v45)));
      *v22 = _mm_cvtsi128_si32(_mm_hadd_epi32(v46, v46)); /*0x10670ff86*/
      v44 = "QuotaFractionProcessTimeCount"; /*0x10670ff8b*/
    }
    else
    {
      v44 = "QuotaUnchangedNoData"; /*0x10670ff52*/
    }
  }
  std::string::assign(a1: &v100, a2: v44); /*0x10670ffc5*/
  if ( *v22 <= 0 ) /*0x10670ffcf*/
  {
    v47 = 1; /*0x10670ffdd*/
    goto LABEL_56; /*0x10670ffdd*/
  }
  v47 = DFInt::ClientInstanceQuotaCap; /*0x10670ffd1*/
  if ( *v22 > DFInt::ClientInstanceQuotaCap ) /*0x10670ffd9*/
LABEL_56:
    *v22 = v47; /*0x10670ffe2*/
LABEL_57:
  isStreamingTunableEnabled = RBX::Network::ClientReplicator::GCJob::isStreamingTunableEnabled(this: *((RBX::Network::ClientReplicator::GCJob **)this + 2753)); /*0x10670ffe5*/
  if ( (_BYTE)isStreamingTunableEnabled != 0 ) /*0x10670fff3*/
  {
    v50 = *((RBX::Network::ClientReplicator::GCJob **)this + 2753); /*0x10670fff9*/
    v99.i32[0] = -1; /*0x106710000*/
    if ( v50 != nullptr && (unsigned __int8)RBX::Network::ClientReplicator::GCJob::isGCRequested(this: v50) != 0 ) /*0x10671001a*/
    {
      v51 = RBX::TotalCountTimeInterval<int,(RBX::Time::SampleMethod)1>::sampleLastFullInterval(a1: (char *)this + 22920); /*0x10671002c*/
      v52 = RBX::TotalCountTimeInterval<int,(RBX::Time::SampleMethod)1>::sampleLastFullInterval(a1: (char *)this + 22872); /*0x106710036*/
      v53 = (float)DFInt::GCReducesQuotaCriticalPercent / 100.0; /*0x106710046*/
      v54 = 0; /*0x10671004e*/
      v55 = "QuotaNotEnoughMemoryDeletionTooSlowCount"; /*0x106710056*/
      if ( v53 > 0.0 ) /*0x10671005d*/
      {
        v56 = v51 + v52; /*0x10671005f*/
        if ( v56 > DFInt::GCMinimumDeletionRateForNonZeroClientInstanceQuota ) /*0x106710068*/
        {
          v54 = (int)(float)(v53 * (float)v56); /*0x106710075*/
          if ( *v8 < v54 ) /*0x10671007e*/
            v54 = *v8; /*0x10671007e*/
          v55 = "QuotaNotEnoughMemoryDeletionQuotaCount"; /*0x106710081*/
        }
      }
      *v8 = v54; /*0x106710088*/
      std::string::assign(a1: &v100, a2: v55); /*0x106710092*/
    }
  }
  else
  {
    v99.i32[0] = -1; /*0x10671009c*/
    if ( (_BYTE)v108 != 0 ) /*0x1067100aa*/
    {
      LOBYTE(isStreamingTunableEnabled) = 1; /*0x1067100ac*/
      v108 = isStreamingTunableEnabled; /*0x1067100ae*/
    }
    else
    {
      v58 = 0; /*0x1067100cb*/
      if ( *((double *)this + 2863) >= RBX::Time::now<(RBX::Time::SampleMethod)1>(a1: v49) - *((double *)this + 2862) ) /*0x1067100d2*/
        v58 = *((_DWORD *)this + 5728); /*0x1067100d4*/
      v59 = RBX::Time::now<(RBX::Time::SampleMethod)1>(a1: v57); /*0x1067100db*/
      inserted.i64[0] = (__int64)v8; /*0x1067100e0*/
      v60 = 0; /*0x1067100f4*/
      if ( *((double *)this + 2860) >= v59 - *((double *)this + 2859) ) /*0x1067100fb*/
        v60 = *((_DWORD *)this + 5722); /*0x1067100fd*/
      v61 = RBX::TotalCountTimeInterval<int,(RBX::Time::SampleMethod)1>::sampleLastFullInterval(a1: (char *)this + 22920); /*0x106710110*/
      v62 = v58 + v60; /*0x106710122*/
      v63 = v61 /*0x106710125*/
          + RBX::TotalCountTimeInterval<int,(RBX::Time::SampleMethod)1>::sampleLastFullInterval(a1: (char *)this + 22872);
      v64 = DFFlag::TrackingGcStats; /*0x106710128*/
      if ( DFFlag::TrackingGcStats == 1 && *((_BYTE *)this + 22528) == 1 ) /*0x106710139*/
      {
        RBX::Metrics::Stat<double,double>::addValue(a1: (char *)this + 22656, a2: (double)v62); /*0x10671014a*/
        RBX::Metrics::Stat<double,double>::addValue(a1: (char *)this + 22800, a2: (double)v63); /*0x10671015e*/
        v64 = DFFlag::TrackingGcStats; /*0x106710163*/
      }
      if ( (v64 & 1) != 0 && *((_BYTE *)this + 22528) == 1 ) /*0x106710174*/
      {
        RBX::Metrics::Stat<double,double>::addValue(a1: (char *)this + 22656, a2: (double)v62); /*0x106710185*/
        RBX::Metrics::Stat<double,double>::addValue(a1: (char *)this + 22800, a2: (double)v63); /*0x106710199*/
      }
      if ( (unsigned __int8)RBX::Network::ClientReplicator::GCJob::pendingGC(this: *((RBX::Network::ClientReplicator::GCJob **)this /*0x1067101ac*/
                                                                                   + 2753)) != 0 )
      {
        v65 = &DFInt::GCReducesQuotaCriticalPercent; /*0x1067101ae*/
      }
      else
      {
        v65 = &DFInt::GCReducesQuotaPercent; /*0x1067101c5*/
        if ( *((int *)this + 5630) < 3 ) /*0x1067101cc*/
          v65 = &DFInt::GCReducesQuotaCriticalPercent; /*0x1067101cc*/
      }
      v66 = (float)*v65 / 100.0; /*0x1067101d7*/
      if ( v66 <= 0.0 || v63 <= DFInt::GCMinimumDeletionRateForNonZeroClientInstanceQuota ) /*0x1067101ef*/
      {
        *(_DWORD *)inserted.i64[0] = 0; /*0x10671022d*/
        std::string::assign(a1: &v100, a2: "QuotaNotEnoughMemoryDeletionTooSlowCount"); /*0x106710241*/
      }
      else
      {
        v67 = (int)(float)(v66 * (float)v63); /*0x1067101fd*/
        if ( *(_DWORD *)inserted.i64[0] < v67 ) /*0x106710209*/
          v67 = *(_DWORD *)inserted.i64[0]; /*0x106710209*/
        v99.i32[0] = v67; /*0x10671020c*/
        *(_DWORD *)inserted.i64[0] = v67; /*0x106710212*/
        std::string::assign(a1: &v100, a2: "QuotaNotEnoughMemoryDeletionQuotaCount"); /*0x106710222*/
      }
      v108 = 0; /*0x106710246*/
      v8 = (int *)inserted.i64[0]; /*0x10671024d*/
    }
  }
LABEL_89:
  v68 = RBX::Network::ClientReplicator::GCJob::isStreamingTunableEnabled(this: *((RBX::Network::ClientReplicator::GCJob **)this /*0x106710251*/
                                                                               + 2753));
  v69 = *((RBX::Network::ClientReplicator::GCJob **)this + 2753); /*0x10671025d*/
  if ( v68 != 0 ) /*0x106710266*/
    updated = RBX::Network::ClientReplicator::GCJob::updateGcRegionDistanceTunable(this: v69); /*0x106710268*/
  else
    updated = RBX::Network::ClientReplicator::GCJob::updateMaxRegionDistance(this: v69); /*0x10671026f*/
  v71 = updated; /*0x106710274*/
  MaxRegionDistance = RBX::Network::ClientReplicator::GCJob::getMaxRegionDistance(this: *((RBX::Network::ClientReplicator::GCJob **)this /*0x10671027e*/
                                                                                        + 2753));
  inserted.i64[0] = (__int64)v8; /*0x106710283*/
  v73 = MaxRegionDistance != *((_WORD *)this + 11766); /*0x10671028e*/
  v74 = (unsigned __int8)DFFlag::EnableTunableClientReplicatorStatsForSessionTracking; /*0x1067102a1*/
  RBX::Network::ClientReplicator::GCJob::updateStreamingTunableMetric( /*0x1067102b8*/
    a1: *((_QWORD *)this + 2753),
    a2: "AvgIncomingPacketsProcessedPerSec",
    a3: 33,
    a4: (unsigned __int8)DFFlag::EnableTunableClientReplicatorStatsForSessionTracking,
    a5: *((double *)this + 2807));
  RBX::Network::ClientReplicator::GCJob::updateStreamingTunableMetric( /*0x1067102db*/
    a1: *((_QWORD *)this + 2753),
    a2: "AvgInstanceQuota",
    a3: 16,
    a4: v74,
    a5: *((double *)this + 2782));
  RBX::Network::ClientReplicator::GCJob::updateStreamingTunableMetric( /*0x1067102ff*/
    a1: *((_QWORD *)this + 2753),
    a2: "AvgStreamedInRadius",
    a3: 19,
    a4: (unsigned int)(int)*((double *)this + 2912),
    a5: v74);
  RBX::Network::ClientReplicator::GCJob::updateStreamingTunableMetric( /*0x106710323*/
    a1: *((_QWORD *)this + 2753),
    a2: "AvgNumStreamedInRegions",
    a3: 23,
    a4: (unsigned int)(int)*((double *)this + 2927),
    a5: v74);
  RBX::Network::ClientReplicator::GCJob::updateStreamingTunableMetric( /*0x106710346*/
    a1: *((_QWORD *)this + 2753),
    a2: "StreamingWorkTime",
    a3: 17,
    a4: v74,
    a5: *((double *)this + 2887));
  RBX::Network::ClientReplicator::GCJob::updateStreamingTunableMetric( /*0x106710369*/
    a1: *((_QWORD *)this + 2753),
    a2: "StreamingDataReadTime",
    a3: 21,
    a4: v74,
    a5: *((double *)this + 2892));
  RBX::Network::ClientReplicator::GCJob::updateStreamingTunableMetric( /*0x10671038c*/
    a1: *((_QWORD *)this + 2753),
    a2: "StreamingGCTime",
    a3: 15,
    a4: v74,
    a5: *((double *)this + 2897));
  RBX::Network::ClientReplicator::GCJob::updateStreamingTunableMetric( /*0x1067103b0*/
    a1: *((_QWORD *)this + 2753),
    a2: "NumRegionsOutsideCurrentRadius",
    a3: 30,
    a4: (unsigned int)(int)*((double *)this + 2917),
    a5: 0);
  RBX::Network::ClientReplicator::GCJob::updateStreamingTunableMetric( /*0x1067103d3*/
    a1: *((_QWORD *)this + 2753),
    a2: "StreamingWorkPercentageOfFrame",
    a3: 30,
    a4: v74,
    a5: *((double *)this + 2902));
  RBX::Network::ClientReplicator::GCJob::updateStreamingTunableMetric( /*0x1067103f6*/
    a1: *((_QWORD *)this + 2753),
    a2: "StreamingTargetRadiusPortion",
    a3: 28,
    a4: v74,
    a5: *((double *)this + 2922));
  RBX::Time::nowFastSec(this: v75); /*0x1067103fb*/
  v77 = v76 - *((double *)this + 2935); /*0x106710404*/
  v98.i32[0] = *((_DWORD *)this + 5868); /*0x106710414*/
  v78 = *((_DWORD *)this + 5869); /*0x10671041c*/
  v102[0] = v77; /*0x10671042a*/
  *((double *)this + 2935) = v76; /*0x106710433*/
  *((_QWORD *)this + 2934) = 0; /*0x10671043b*/
  RBX::Network::ClientReplicator::GCJob::updateStreamingTunableMetric( /*0x10671045f*/
    a1: *((_QWORD *)this + 2753),
    a2: "StreamingSendRate",
    a3: 17,
    a4: 0,
    a5: (double)v78 / v77);
  RBX::Network::ClientReplicator::GCJob::updateStreamingTunableMetric( /*0x106710489*/
    a1: *((_QWORD *)this + 2753),
    a2: "StreamingRecvRate",
    a3: 17,
    a4: 0,
    a5: v98.f32[0] / v102[0]);
  v79 = *(_DWORD *)inserted.i64[0] - v107; /*0x10671049d*/
  if ( (v73 | v71 & 1 | (*(_DWORD *)inserted.i64[0] != v107)) != 0 ) /*0x1067104a9*/
  {
    if ( *(_DWORD *)inserted.i64[0] == v107 ) /*0x1067104b1*/
    {
      ++*((_DWORD *)this + 5737); /*0x1067104ca*/
    }
    else
    {
      ++*((_DWORD *)this + 5736); /*0x1067104b3*/
      RBX::RunningAverage<int,double>::sample(a1: (char *)this + 22400, a2: v79); /*0x1067104c3*/
    }
    *((_WORD *)this + 11766) = RBX::Network::ClientReplicator::GCJob::getMaxRegionDistance(this: *((RBX::Network::ClientReplicator::GCJob **)this /*0x1067104dc*/
                                                                                                 + 2753));
    if ( *(_BYTE *)(RBX::CoreNetworkSettings::singleton(this: v80) + 146) == 1 ) /*0x1067104ef*/
    {
      v81 = *((_DWORD *)this + 5882); /*0x1067104f1*/
      v82 = RBX::Network::Replicator::incomingPacketsCount(this); /*0x1067104fb*/
      RBX::CreatorLog::printf( /*0x10671052b*/
        a1: 1,
        a2: (unsigned int)"clientInstanceQuota %d, packet in queue %d, predictedTotalInstanceProcessTime %f, avgStreamDataRea"
                      "dTime %f, avgInstancesPerStreamData %f",
        a3: v81,
        a4: v82,
        a5: v83,
        a6: v84);
    }
    if ( (unsigned __int8)RBX::Network::ClientReplicator::GCJob::isStreamingTunableEnabled(this: *((RBX::Network::ClientReplicator::GCJob **)this /*0x10671053e*/
                                                                                                 + 2753)) != 0 )
    {
      v108 = RBX::Network::ClientReplicator::GCJob::isGCRequested(this: *((RBX::Network::ClientReplicator::GCJob **)this /*0x10671054c*/
                                                                        + 2753));
    }
    else
    {
      v86 = v108; /*0x106710551*/
      LOBYTE(v86) = v108 ^ 1; /*0x106710554*/
      v108 = v86; /*0x106710556*/
    }
    if ( FFlag::SupportGcRegionQuotaSource == 1 ) /*0x106710563*/
    {
      v87 = *((_QWORD *)this + 2753); /*0x106710569*/
      v88 = operator new(a1: (RBX::Memory *)0x50, a2: v85); /*0x10671057a*/
      LOWORD(v107) = RBX::Network::ClientReplicator::GCJob::getMaxRegionDistance(this: (RBX::Network::ClientReplicator::GCJob *)v87); /*0x106710585*/
      v89 = *(_BYTE *)(v87 + 824); /*0x106710589*/
      LOBYTE(v102[0]) = *(_BYTE *)(v87 + 825); /*0x106710597*/
      LODWORD(v87) = *(_DWORD *)(v87 + 828); /*0x10671059a*/
      RBX::Network::Item::Item(this: (RBX::Network::Item *)v88, a2: this); /*0x1067105a7*/
      *(_QWORD *)v88 = off_10CAA7F40; /*0x1067105ba*/
      *(_BYTE *)(v88 + 64) = v108; /*0x1067105c0*/
      *(_DWORD *)(v88 + 68) = v79; /*0x1067105c4*/
      *(_WORD *)(v88 + 72) = v107; /*0x1067105cc*/
      *(_BYTE *)(v88 + 74) = v89; /*0x1067105d1*/
      *(_BYTE *)(v88 + 75) = LOBYTE(v102[0]); /*0x1067105d8*/
      *(_DWORD *)(v88 + 76) = v87; /*0x1067105dc*/
    }
    else
    {
      v88 = operator new(a1: (RBX::Memory *)0x50, a2: v85); /*0x1067105f4*/
      v90 = RBX::Network::ClientReplicator::GCJob::getMaxRegionDistance(this: *((RBX::Network::ClientReplicator::GCJob **)this /*0x106710603*/
                                                                              + 2753));
      RBX::Network::Item::Item(this: (RBX::Network::Item *)v88, a2: this); /*0x10671060c*/
      *(_QWORD *)v88 = off_10CAA7F40; /*0x10671061f*/
      *(_BYTE *)(v88 + 64) = v108; /*0x106710625*/
      *(_DWORD *)(v88 + 68) = v79; /*0x106710629*/
      *(_DWORD *)(v88 + 72) = v90; /*0x10671062d*/
      *(_DWORD *)(v88 + 76) = 0; /*0x106710639*/
    }
    RBX::Network::ItemQueue::push_back( /*0x1067105e3*/
      this: (RBX::Network::ClientReplicator *)((char *)this + 14536),
      a2: (RBX::Network::Item *)v88);
  }
  *((_DWORD *)this + 5969) = 0; /*0x106710650*/
  RBX::RunningAverage<int,double>::sample(a1: (char *)this + 22240, a2: *((unsigned int *)this + 5882)); /*0x106710660*/
  if ( DFFlag::TrackingGcStats == 1 && *((_BYTE *)this + 22528) == 1 ) /*0x106710675*/
  {
    RBX::Metrics::Stat<double,double>::addValue(a1: (char *)this + 22584, a2: (double)*((int *)this + 5882)); /*0x106710689*/
    v91 = v99.i32[0]; /*0x106710695*/
    if ( v99.i32[0] == -1 ) /*0x10671069e*/
      v91 = *(_DWORD *)inserted.i64[0]; /*0x1067106a4*/
    RBX::Metrics::Stat<double,double>::addValue(a1: (char *)this + 22728, a2: (double)v91); /*0x1067106ad*/
  }
  v95 = &v100; /*0x1067106c7*/
  v92 = std::__hash_table<std::__hash_value_type<std::string,int>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,int>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,int>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,int>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<>>( /*0x1067106d5*/
          a1: (char *)this + 22952,
          a2: &v100,
          a3: std::piecewise_construct,
          a4: &v95,
          a5: &v105);
  ++*(_DWORD *)(v92 + 40); /*0x1067106da*/
  v93 = RBX::Network::ClientReplicator::GCJob::getMaxRegionDistance(this: *((RBX::Network::ClientReplicator::GCJob **)this /*0x1067106e4*/
                                                                          + 2753));
  RBX::RunningAverage<short,double>::sample(a1: (char *)this + 22280, a2: (unsigned int)v93); /*0x1067106f3*/
  *((_BYTE *)this + 23882) = 0; /*0x1067106f8*/
  if ( (v100 & 1) != 0 ) /*0x106710706*/
    operator delete(a1: (RBX::Memory *)v101, a2: v94); /*0x10671070c*/
}

// Address: 0x106710868 | Name: __ZN3RBX7Network16ClientReplicator32getStreamingSendRecvRateAndResetERdS2_
__int64 __fastcall RBX::Network::ClientReplicator::getStreamingSendRecvRateAndReset(
        RBX::Network::ClientReplicator *this,
        double *a2,
        double *a3)
{
  double v6; // xmm0_8
  __int64 result; // rax

  RBX::Time::nowFastSec(this); /*0x10671087b*/
  *a3 = *((float *)this + 5868) / (v6 - *((double *)this + 2935)); /*0x10671089a*/
  result = *((unsigned int *)this + 5869); /*0x10671089e*/
  *a2 = (double)(int)result / (v6 - *((double *)this + 2935)); /*0x1067108be*/
  *((double *)this + 2935) = v6; /*0x1067108c3*/
  *((_QWORD *)this + 2934) = 0; /*0x1067108cc*/
  return result; /*0x1067108db*/
}

// Address: 0x106710942 | Name: __ZN3RBX7Network16ClientReplicator11dataOutStepEi
__int64 __fastcall RBX::Network::ClientReplicator::dataOutStep(RBX::Network::ClientReplicator *this, unsigned int a2)
{
  unsigned int v4; // ebx
  unsigned int v5; // r14d
  unsigned int v6; // esi

  v4 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)RBX::Memory::NetworkReplicator, a2); /*0x106710960*/
  RBX::Network::PropSync::detail::Base<RBX::Network::PropSync::detail::SlaveItem>::expireItems(a1: (char *)this + 21784); /*0x106710969*/
  if ( (unsigned __int8)RBX::Network::Replicator::getAttributeSynchronizationEnabled(this) != 0 ) /*0x106710978*/
    RBX::Network::Sync::Base<RBX::Network::Sync::SlaveItem,RBX::Network::Sync::AttributeKey>::expireItems(a1: (__int64)this + 21896); /*0x106710981*/
  v5 = RBX::Network::Replicator::dataOutStep(this, a2); /*0x106710991*/
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v4, a2: v6); /*0x106710996*/
  return v5; /*0x1067109a2*/
}

// Address: 0x106710a32 | Name: __ZN3RBX7Network16ClientReplicator21testSetSyncExpirationEd
__int64 __fastcall RBX::Network::ClientReplicator::testSetSyncExpiration(
        RBX::Network::ClientReplicator *this,
        double a2)
{
  __int64 result; // rax

  result = RBX::Network::Replicator::getAttributeSynchronizationEnabled(this); /*0x106710a40*/
  if ( (_BYTE)result != 0 ) /*0x106710a4c*/
    *((double *)this + 2737) = a2; /*0x106710a4e*/
  *((double *)this + 2723) = a2; /*0x106710a56*/
  return result; /*0x106710a62*/
}

// Address: 0x106710a66 | Name: __ZN3RBX7Network16ClientReplicator23testClearSyncExpirationEv
void __fastcall RBX::Network::ClientReplicator::testClearSyncExpiration(RBX::Network::ClientReplicator *this)
{
  rbx::timestamped_safe_queue<RBX::Network::PropSync::detail::PropertyKey>::clear(a1: (char *)this + 21840); /*0x106710a76*/
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::Network::PropSync::detail::PropertyKey const,RBX::Network::PropSync::detail::SlaveItem>>,RBX::Network::PropSync::detail::PropertyKey,RBX::Network::PropSync::detail::SlaveItem,boost::hash<RBX::Network::PropSync::detail::PropertyKey>,std::equal_to<RBX::Network::PropSync::detail::PropertyKey>>>::clear(a1: (_QWORD *)this + 2724); /*0x106710a82*/
  rbx::timestamped_safe_queue<RBX::Network::Sync::AttributeKey const*>::clear(a1: (char *)this + 21952); /*0x106710a8e*/
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::Network::Sync::AttributeKey const,RBX::Network::Sync::SlaveItem>>,RBX::Network::Sync::AttributeKey,RBX::Network::Sync::SlaveItem,boost::hash<RBX::Network::Sync::AttributeKey>,std::equal_to<RBX::Network::Sync::AttributeKey>>>::clear(a1: (_QWORD *)this + 2738); /*0x106710aa3*/
}

// Address: 0x106710aa8 | Name: __ZN3RBX7Network16ClientReplicator23readChangedPropertyItemEPNS0_30DeserializedChangePropertyItemENS_8PropertyE
char *__fastcall RBX::Network::ClientReplicator::readChangedPropertyItem(
        RBX::Network::Replicator *this,
        __int64 a2,
        __int128 *a3)
{
  RBX::ModelInstance **v6; // r12
  __int64 v7; // rdi
  __int64 v8; // rax
  __int64 v9; // rdi
  __int64 *v10; // rsi
  __int16 v11; // cx
  __int16 v12; // dx
  void *v13; // rax
  RBX::ModelInstance *v14; // r12
  __int64 v15; // r13
  __int64 v16; // rax
  RBX::ModelInstance *v17; // rsi
  RBX::Network::InstanceObjectManager *v18; // rdi
  __int64 v19; // r13
  __int64 v20; // r12
  __int64 v21; // rax
  unsigned __int64 v22; // rsi
  __int64 ***v23; // rcx
  __int64 **v24; // rdi
  __int64 **v25; // r12
  __int64 v26; // r13
  __int64 v27; // rdx
  __int64 v28; // rcx
  const char *v29; // rsi
  __int64 v30; // r8
  __int64 v31; // r9
  __m128 v32; // xmm0
  __m128 v33; // xmm1
  __m128 v34; // xmm2
  __m128 v35; // xmm3
  __m128 v36; // xmm4
  __m128 v37; // xmm5
  __m128 v38; // xmm6
  __m128 v39; // xmm7
  __int64 v40; // r13
  __int64 v41; // rdi
  char *result; // rax
  __int64 ***v43; // r12
  __int64 *v44; // rax
  RBX::Network::Item *v45; // r12
  std::__shared_weak_count *v46; // r12
  std::__shared_weak_count *v47; // r12
  char v48; // [rsp+0h] [rbp-70h]
  __int128 v49; // [rsp+10h] [rbp-60h] BYREF
  __int128 v50; // [rsp+20h] [rbp-50h] BYREF
  __int128 v51; // [rsp+30h] [rbp-40h] BYREF

  v6 = (RBX::ModelInstance **)(a2 + 48); /*0x106710ac9*/
  RBX::Network::PropSync::Slave::slaveOnReceivedPropertyChanged( /*0x106710adc*/
    this: (RBX::Network::Replicator *)((char *)this + 21784),
    a2: *(const RBX::Object **)(a2 + 48),
    a3: *(unsigned __int16 *)(a2 + 72),
    a4: *(_BYTE *)(a2 + 192));
  v7 = *((_QWORD *)this + 1560) + 112LL; /*0x106710af0*/
  *(_QWORD *)&v51 = *(_QWORD *)(*(_QWORD *)(a2 + 48) + 24LL); /*0x106710af8*/
  v8 = RBX::detail::DenseHashTable<RBX::Reflection::ClassDescriptor const*,std::pair<RBX::Reflection::ClassDescriptor const*,unsigned short>,std::pair<RBX::Reflection::ClassDescriptor const* const,unsigned short>,RBX::detail::ItemInterfaceMap<RBX::Reflection::ClassDescriptor const*,unsigned short>,RBX::Hash<RBX::Reflection::ClassDescriptor const*>,std::equal_to<RBX::Reflection::ClassDescriptor const*>>::find(a1: v7); /*0x106710afb*/
  if ( v8 == 0 ) /*0x106710b03*/
  {
    if ( *((_BYTE *)this + 15544) != 0 ) /*0x106710b40*/
    {
      v13 = *(void **)a3; /*0x106710b46*/
      if ( *(_QWORD *)a3 != RBX::Instance::propParent ) /*0x106710b53*/
        goto LABEL_8; /*0x106710b53*/
      goto LABEL_19; /*0x106710b53*/
    }
LABEL_35:
    v51 = *a3; /*0x106710d73*/
    return (char *)RBX::Network::Replicator::readChangedPropertyItem(this, a2); /*0x106710d84*/
  }
  v11 = *(_WORD *)(v8 + 8); /*0x106710b05*/
  v12 = *(_WORD *)(a2 + 72); /*0x106710b09*/
  if ( *((_BYTE *)this + 15544) == 0 ) /*0x106710b15*/
  {
    if ( v11 == v12 ) /*0x106710bc2*/
    {
LABEL_15:
      v19 = *((_QWORD *)a3 + 1); /*0x106710bc8*/
      if ( v19 != 0 ) /*0x106710bcf*/
      {
        v20 = *(_QWORD *)(v19 + 24); /*0x106710bd5*/
        v21 = RBX::Reflection::Class_getDescriptorPtr<RBX::BasePart>(a1: v9, a2: v10); /*0x106710bd9*/
        if ( *(unsigned __int16 *)(v20 + 440) - (unsigned int)*(unsigned __int16 *)(v21 + 440) <= *(unsigned __int16 *)(v21 + 442) ) /*0x106710bf9*/
        {
          v23 = *((__int64 ****)this + 2752); /*0x106710bff*/
          v24 = *v23; /*0x106710c06*/
          v25 = (__int64 **)**v23; /*0x106710c09*/
          if ( v25 != nullptr ) /*0x106710c0f*/
          {
            *v24 = *v25; /*0x106710c19*/
          }
          else
          {
            v43 = *((__int64 ****)this + 2752); /*0x106710cad*/
            v44 = boost::pool<RBX::TrackedAllocator>::malloc_need_resize(a1: v24, a2: v22); /*0x106710cb0*/
            v23 = v43; /*0x106710cb5*/
            v25 = (__int64 **)v44; /*0x106710cb8*/
          }
          *v25 = (__int64 *)v23; /*0x106710cbf*/
          v45 = (RBX::Network::Item *)(v25 + 1); /*0x106710cc3*/
          RBX::shared_from<RBX::BasePart const>(a1: &v50, a2: v19); /*0x106710cce*/
          RBX::Network::CFrameAcknowledgementItem::CFrameAcknowledgementItem( /*0x106710cf0*/
            a1: (__int64)v45,
            a2: this,
            a3: &v50,
            a4: *(_WORD *)(a2 + 72),
            a5: (*((_QWORD *)this + 1945) & 0x200000000LL) != 0);
          RBX::Network::ItemQueue::push_back(this: (RBX::Network::Replicator *)((char *)this + 14536), a2: v45); /*0x106710cff*/
          v46 = *((std::__shared_weak_count **)&v50 + 1); /*0x106710d04*/
          if ( *((_QWORD *)&v50 + 1) != 0 /*0x106710d1e*/
            && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v50 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
          {
            (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v46 + 16LL))(a1: v46); /*0x106710d27*/
            std::__shared_weak_count::__release_weak(this: v46); /*0x106710d2d*/
          }
        }
      }
      goto LABEL_35; /*0x106710d32*/
    }
    goto LABEL_35; /*0x106710bc2*/
  }
  v13 = *(void **)a3; /*0x106710b1b*/
  v10 = &RBX::Instance::propParent; /*0x106710b1e*/
  if ( *(_QWORD *)a3 != RBX::Instance::propParent ) /*0x106710b28*/
  {
    if ( v11 == v12 ) /*0x106710b31*/
      goto LABEL_15; /*0x106710b31*/
LABEL_8:
    if ( v13 == RBX::ModelProperties::prop_ModelStreamingMode ) /*0x106710b63*/
    {
      v14 = *v6; /*0x106710b69*/
      v15 = *((_QWORD *)v14 + 3); /*0x106710b6d*/
      v16 = RBX::Reflection::Class_getDescriptorPtr<RBX::ModelInstance>(a1: v9); /*0x106710b72*/
      v17 = nullptr; /*0x106710b8f*/
      if ( *(unsigned __int16 *)(v15 + 440) - (unsigned int)*(unsigned __int16 *)(v16 + 440) <= *(unsigned __int16 *)(v16 + 442) ) /*0x106710b93*/
        v17 = v14; /*0x106710b93*/
      v18 = *((RBX::Network::InstanceObjectManager **)this + 2757); /*0x106710b97*/
      if ( v18 != nullptr && v17 != nullptr ) /*0x106710baa*/
        RBX::Network::InstanceObjectManager::onModelStreamingModeChanged(this: v18, a2: v17, a3: true); /*0x106710bb5*/
    }
    goto LABEL_35; /*0x106710bba*/
  }
LABEL_19:
  if ( *((_QWORD *)this + 2753) == 0 ) /*0x106710c29*/
    goto LABEL_35; /*0x106710c29*/
  if ( *v6 == nullptr ) /*0x106710c34*/
    goto LABEL_35; /*0x106710c34*/
  v26 = *(_QWORD *)(a2 + 104); /*0x106710c3a*/
  if ( v26 != RBX::Reflection::Type::getSingleton<void>(a1: v9, a2: v10) ) /*0x106710c46*/
    goto LABEL_35; /*0x106710c46*/
  RBX::Reflection::DescribedBase::fastSharedDynamicCast<RBX::Instance,RBX::Object>(a1: &v51, a2: v6); /*0x106710c56*/
  v40 = v51; /*0x106710c5b*/
  if ( (_QWORD)v51 != 0 ) /*0x106710c62*/
  {
    v41 = *((_QWORD *)this + 2753); /*0x106710c68*/
    v49 = v51; /*0x106710c6f*/
    if ( *((_QWORD *)&v51 + 1) != 0 ) /*0x106710c7e*/
      _InterlockedIncrement64((volatile signed __int64 *)(*((_QWORD *)&v51 + 1) + 8LL)); /*0x106710c80*/
    RBX::Network::ClientReplicator::GCJob::notifyServerGcingInstanceAndDescendants(a1: v41, a2: &v49); /*0x106710c89*/
    std::shared_ptr<RBX::Instance>::~shared_ptr[abi:ne200100](a1: &v49); /*0x106710c92*/
    result = (char *)RBX::Network::ClientReplicator::streamOutInstance(this, a2: (RBX::Instance *)v51, a3: true); /*0x106710ca3*/
  }
  else
  {
    result = &DFFlag::ThrowOnNonInstanceObjectParent; /*0x106710d34*/
    if ( DFFlag::ThrowOnNonInstanceObjectParent == 1 ) /*0x106710d3e*/
      RBX::throw_runtime_error( /*0x106710da1*/
        this: (RBX *)"Invalid Object for Instance.Parent change.",
        a2: v29,
        a3: v27,
        a4: v28,
        a5: v30,
        a6: v31,
        a7: v32,
        a8: v33,
        a9: v34,
        a10: v35,
        a11: v36,
        a12: v37,
        a13: v38,
        a14: v39,
        a15: v48);
  }
  v47 = *((std::__shared_weak_count **)&v51 + 1); /*0x106710d40*/
  if ( *((_QWORD *)&v51 + 1) != 0 ) /*0x106710d47*/
  {
    result = (char *)_InterlockedExchangeAdd64( /*0x106710d50*/
                       (volatile signed __int64 *)(*((_QWORD *)&v51 + 1) + 8LL),
                       0xFFFFFFFFFFFFFFFFLL);
    if ( result == nullptr ) /*0x106710d5a*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v47 + 16LL))(a1: v47); /*0x106710d63*/
      result = (char *)std::__shared_weak_count::__release_weak(this: v47); /*0x106710d69*/
    }
  }
  if ( v40 == 0 ) /*0x106710d71*/
    goto LABEL_35; /*0x106710d71*/
  return result; /*0x106710d89*/
}

// Address: 0x106710ebc | Name: __ZN3RBX7Network16ClientReplicator17streamOutInstanceEPNS_8InstanceEb
__int64 __fastcall RBX::Network::ClientReplicator::streamOutInstance(
        RBX::Network::ClientReplicator *this,
        RBX::Instance *a2,
        int a3)
{
  char v6; // r12
  std::__shared_weak_count *v7; // r13
  __int64 v8; // r13
  __int64 v9; // rdi
  __int64 v10; // rsi
  unsigned int v11; // eax
  __int64 v12; // r15
  __int64 v13; // rax
  const RBX::Guid *v14; // rsi
  __int64 v15; // r13
  __int64 result; // rax
  __int64 v17; // r15
  RBX::Joint *v18; // r12
  const RBX::Joint *v19; // rsi
  __int64 JointOwner; // rax
  RBX::JointInstance *v21; // rcx
  RBX::JointInstance *v22; // rax
  const RBX::Joint *v23; // rsi
  __int64 v24; // rax
  RBX::Constraints::Constraint *v25; // rcx
  RBX::Constraints::Constraint *v26; // rax
  __int64 v27; // rax
  RBX::Constraints::WeldConstraint *v28; // rcx
  RBX::Constraints::WeldConstraint *v29; // rax
  __int64 v30; // rax
  __int64 v31; // r15
  __int128 v32; // [rsp+0h] [rbp-50h] BYREF
  RBX::Instance *v33; // [rsp+10h] [rbp-40h]
  __int64 v34; // [rsp+18h] [rbp-38h]
  int v35; // [rsp+24h] [rbp-2Ch]

  RBX::shared_from<RBX::Instance>(a1: &v32, (__int64)a2); /*0x106710edd*/
  v6 = RBX::Network::Replicator::disconnectReplicationData(a1: this); /*0x106710eed*/
  v7 = *((std::__shared_weak_count **)&v32 + 1); /*0x106710ef0*/
  if ( *((_QWORD *)&v32 + 1) != 0 /*0x106710f09*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v32 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(a1: v7); /*0x106710f12*/
    std::__shared_weak_count::__release_weak(this: v7); /*0x106710f18*/
  }
  v8 = *((_QWORD *)a2 + 6); /*0x106710f1d*/
  RBX::TotalCountTimeInterval<int,(RBX::Time::SampleMethod)1>::increment(a1: (char *)this + 22896, a2: 1); /*0x106710f2d*/
  if ( v6 != 0 ) /*0x106710f35*/
  {
    v11 = RBX::Instance::countDescendantsOfType<RBX::Instance>(a1: a2); /*0x106710f41*/
    RBX::TotalCountTimeInterval<int,(RBX::Time::SampleMethod)1>::increment(a1: (char *)this + 22920, a2: v11); /*0x106710f4b*/
  }
  v35 = a3; /*0x106710f50*/
  if ( FFlag::DifferentiateStreamedOut == 1 ) /*0x106710f5e*/
    RBX::setIsStreamedOutFlag(this: a2, a2: (RBX::Instance *)1); /*0x106710f68*/
  v12 = *((_QWORD *)a2 + 3); /*0x106710f6d*/
  v13 = RBX::Reflection::Class_getDescriptorPtr<RBX::BasePart>(a1: v9, a2: v10); /*0x106710f71*/
  if ( *(unsigned __int16 *)(v12 + 440) - (unsigned int)*(unsigned __int16 *)(v13 + 440) > *(unsigned __int16 *)(v13 + 442) ) /*0x106710f90*/
    goto LABEL_40; /*0x106710f90*/
  v34 = v8; /*0x106710f96*/
  v15 = *((_QWORD *)a2 + 47); /*0x106710f9a*/
  result = *(_QWORD *)(v15 + 384); /*0x106710fa1*/
  if ( (int)((unsigned __int64)(*(_QWORD *)(v15 + 392) - result) >> 3) > 0 ) /*0x106710fb8*/
  {
    v17 = 0; /*0x106710fbe*/
    do /*0x1067110c7*/
    {
      v18 = *(RBX::Joint **)(result + 8 * v17); /*0x106710fc1*/
      if ( RBX::Joint::isJointInstanceOwned(this: v18, a2: v14) ) /*0x106710fc8*/
      {
        JointOwner = RBX::Joint::getJointOwner(this: v18); /*0x106710fd4*/
        v21 = (RBX::JointInstance *)(JointOwner - 224); /*0x106710fd9*/
        if ( JointOwner == 0 ) /*0x106710fe3*/
          v21 = nullptr; /*0x106710fe3*/
        v22 = v21; /*0x106710fe7*/
        do /*0x106710ff6*/
          v22 = *((RBX::JointInstance **)v22 + 13); /*0x106710fea*/
        while ( v22 != a2 && v22 != nullptr ); /*0x106710ff6*/
        if ( v22 != a2 ) /*0x106710ffb*/
          RBX::Network::ClientReplicator::streamOutPartJointInstanceHelper(this, a2: v14, a3: a2, a4: v21); /*0x106711007*/
      }
      else if ( !RBX::Joint::isDragDetectorOwned(this: v18, a2: v19) ) /*0x106711014*/
      {
        if ( (unsigned __int8)RBX::Joint::isConstraintOwned(this: v18, a2: v14) != 0 ) /*0x10671102b*/
        {
          v24 = RBX::Joint::getJointOwner(this: v18); /*0x106711030*/
          v25 = (RBX::Constraints::Constraint *)(v24 - 192); /*0x106711035*/
          if ( v24 == 0 ) /*0x10671103f*/
            v25 = nullptr; /*0x10671103f*/
          v26 = v25; /*0x106711043*/
          do /*0x106711052*/
            v26 = *((RBX::Constraints::Constraint **)v26 + 13); /*0x106711046*/
          while ( v26 != a2 && v26 != nullptr ); /*0x106711052*/
          if ( v26 != a2 ) /*0x106711057*/
            RBX::Network::ClientReplicator::streamOutPartConstraintHelper(this, a2: v14, a3: a2, a4: v25); /*0x10671105f*/
        }
        else if ( RBX::Joint::isWeldConstraintOwned(this: v18, a2: v23) ) /*0x106711069*/
        {
          v27 = RBX::Joint::getJointOwner(this: v18); /*0x106711075*/
          v28 = (RBX::Constraints::WeldConstraint *)(v27 - 224); /*0x10671107a*/
          if ( v27 == 0 ) /*0x106711084*/
            v28 = nullptr; /*0x106711084*/
          v29 = v28; /*0x106711088*/
          do /*0x106711097*/
            v29 = *((RBX::Constraints::WeldConstraint **)v29 + 13); /*0x10671108b*/
          while ( v29 != a2 && v29 != nullptr ); /*0x106711097*/
          if ( v29 != a2 ) /*0x10671109c*/
            RBX::Network::ClientReplicator::streamOutPartWeldConstraintHelper(this, a2: v14, a3: a2, a4: v28); /*0x1067110a4*/
        }
      }
      ++v17; /*0x1067110a9*/
      result = *(_QWORD *)(v15 + 384); /*0x1067110ac*/
    }
    while ( v17 < (int)((unsigned __int64)(*(_QWORD *)(v15 + 392) - result) >> 3) ); /*0x1067110c7*/
  }
  if ( (_BYTE)v35 != 0 ) /*0x1067110d1*/
  {
    v30 = RBX::ServiceProvider::find<RBX::JointsService>(a1: this); /*0x1067110d6*/
    if ( v30 != 0 ) /*0x1067110e2*/
    {
      *(_QWORD *)&v32 = this; /*0x1067110e8*/
      *((_QWORD *)&v32 + 1) = v34; /*0x1067110eb*/
      v33 = a2; /*0x1067110ef*/
      ((void (__fastcall *)(__int64))RBX::Instance::visitDescendants<RBX::Network::ClientReplicator::streamOutInstance(RBX::Instance*,bool)::$_0>)(a1: v30); /*0x1067110f6*/
    }
LABEL_40:
    v31 = *((_QWORD *)this + 181); /*0x1067110fb*/
    *((_QWORD *)this + 181) = a2; /*0x106711102*/
    result = RBX::Instance::setParent(this: a2, a2: nullptr); /*0x10671110e*/
    *((_QWORD *)this + 181) = v31; /*0x106711113*/
  }
  return result; /*0x10671111a*/
}

// Address: 0x1067111c2 | Name: __ZN3RBX7Network16ClientReplicator28serializePropertyVersionInfoERNS0_13NetworkStreamEPKNS_6ObjectEtPKNS_10Reflection18PropertyDescriptorE
__int64 __fastcall RBX::Network::ClientReplicator::serializePropertyVersionInfo(
        RBX::Network::ClientReplicator *this,
        RBX::Network::NetworkStream *a2,
        const RBX::Object *a3,
        unsigned int a4,
        const RBX::Reflection::PropertyDescriptor *a5)
{
  int v6; // r14d
  __int64 result; // rax
  RBX::Network::NetworkStream *v8; // rdx
  unsigned int v9; // [rsp+8h] [rbp-18h] BYREF
  bool v10; // [rsp+Fh] [rbp-11h] BYREF

  v9 = 0; /*0x1067111d4*/
  v6 = RBX::Network::PropSync::Slave::slaveOnPropertySend( /*0x1067111f1*/
         this: (RBX::Network::ClientReplicator *)((char *)this + 21784),
         a2: a3,
         a3: a4,
         a4: (int *)&v9);
  v10 = v6 != 1; /*0x1067111fb*/
  result = RBX::Network::NetworkStream::writeBytes(this: a2, a2: &v10, a3: 1u); /*0x106711206*/
  if ( v6 != 1 ) /*0x10671120f*/
    return RBX::Network::serializeSignedVarint(this: (RBX::Network *)v9, (int)a2, a3: v8); /*0x106711217*/
  return result; /*0x10671121c*/
}

// Address: 0x1067112b0 | Name: __ZN3RBX7Network16ClientReplicator30deserializePropertyVersionInfoERNS0_13NetworkStreamERNS0_17ChangeVersionInfoE
__int64 __fastcall RBX::Network::ClientReplicator::deserializePropertyVersionInfo(
        __int64 a1,
        RBX::Network::NetworkStream *a2,
        _BYTE *a3)
{
  __int64 result; // rax

  result = RBX::Network::NetworkStream::readBool(this: a2); /*0x1067112bc*/
  *a3 = result; /*0x1067112c1*/
  return result; /*0x1067112c7*/
}

// Address: 0x1067112ca | Name: __ZN3RBX7Network16ClientReplicator25writeAttributeVersionInfoERNS0_13NetworkStreamEPKNS_8InstanceERKNSt3__112basic_stringIcNS7_11char_traitsIcEENS7_9allocatorIcEEEE
__int64 __fastcall RBX::Network::ClientReplicator::writeAttributeVersionInfo(
        unsigned __int8 *a1,
        RBX::Network::NetworkStream *a2,
        __int64 a3,
        __int128 *a4)
{
  __int64 result; // rax
  __int64 v9; // rax
  __int64 node; // rax
  void *v11; // rsi
  unsigned int v12; // r14d
  char v13; // r15
  RBX::Network::NetworkStream *v14; // rdx
  __int128 v15; // [rsp+0h] [rbp-60h] BYREF
  void *v16; // [rsp+10h] [rbp-50h]
  __int64 v17; // [rsp+18h] [rbp-48h]
  __int128 v18; // [rsp+20h] [rbp-40h] BYREF
  void *v19; // [rsp+30h] [rbp-30h]

  result = RBX::Network::Replicator::getAttributeSynchronizationEnabled(this: (RBX::Network::Replicator *)a1); /*0x1067112e5*/
  if ( (_BYTE)result != 0 ) /*0x1067112ec*/
  {
    result = (*(__int64 (__fastcall **)(unsigned __int8 *))(*(_QWORD *)a1 + 1032LL))(a1); /*0x1067112f8*/
    if ( (_BYTE)result != 0 ) /*0x106711300*/
    {
      if ( (*(_BYTE *)a4 & 1) != 0 ) /*0x10671130b*/
      {
        std::string::__init_copy_ctor_external(a1: &v18, a2: *((_QWORD *)a4 + 2), a3: *((_QWORD *)a4 + 1)); /*0x10671132f*/
      }
      else
      {
        v19 = *((void **)a4 + 2); /*0x106711312*/
        v18 = *a4; /*0x10671131b*/
      }
      v16 = v19; /*0x106711338*/
      v15 = v18; /*0x106711340*/
      v18 = 0; /*0x106711347*/
      v19 = nullptr; /*0x10671134b*/
      if ( a3 != 0 ) /*0x106711356*/
        v9 = *(_QWORD *)(a3 + 48); /*0x106711358*/
      else
        v9 = 0xFFFFFFFFLL; /*0x10671135e*/
      v17 = v9; /*0x106711363*/
      node = boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::Network::Sync::AttributeKey const,RBX::Network::Sync::SlaveItem>>,RBX::Network::Sync::AttributeKey,RBX::Network::Sync::SlaveItem,boost::hash<RBX::Network::Sync::AttributeKey>,std::equal_to<RBX::Network::Sync::AttributeKey>>>::find_node( /*0x106711375*/
               a1: a1 + 21904,
               a2: (__int64)&v15);
      v12 = 0; /*0x10671137a*/
      if ( node != 0 ) /*0x106711380*/
      {
        v13 = 0; /*0x106711386*/
        if ( *(_BYTE *)(node + 52) == 0 ) /*0x10671138c*/
        {
          *(_BYTE *)(node + 52) = 1; /*0x10671138e*/
          v12 = *(_DWORD *)(node + 48); /*0x106711392*/
          v13 = 1; /*0x106711396*/
        }
      }
      else
      {
        v13 = 0; /*0x10671139b*/
      }
      if ( (v15 & 1) != 0 ) /*0x1067113a2*/
        operator delete(a1: (RBX::Memory *)v16, a2: v11); /*0x1067113a8*/
      if ( (v18 & 1) != 0 ) /*0x1067113b1*/
        operator delete(a1: (RBX::Memory *)v19, a2: v11); /*0x1067113b7*/
      LOBYTE(v15) = v13; /*0x1067113c0*/
      result = RBX::Network::NetworkStream::writeBytes(this: a2, a2: &v15, a3: 1u); /*0x1067113cb*/
      if ( v13 != 0 ) /*0x1067113d3*/
        return RBX::Network::serializeSignedVarint(this: (RBX::Network *)v12, (int)a2, a3: v14); /*0x1067113db*/
    }
  }
  return result; /*0x1067113e0*/
}

// Address: 0x106711410 | Name: __ZN3RBX7Network16ClientReplicator24readAttributeVersionInfoERNS0_13NetworkStreamERNS0_17ChangeVersionInfoE
__int64 __fastcall RBX::Network::ClientReplicator::readAttributeVersionInfo(
        RBX::Network::Replicator *a1,
        RBX::Network::NetworkStream *a2,
        _BYTE *a3)
{
  __int64 result; // rax

  result = RBX::Network::Replicator::getAttributeSynchronizationEnabled(this: a1); /*0x106711423*/
  if ( (_BYTE)result != 0 ) /*0x10671142a*/
  {
    result = (*(__int64 (__fastcall **)(RBX::Network::Replicator *))(*(_QWORD *)a1 + 1032LL))(a1); /*0x106711432*/
    if ( (_BYTE)result != 0 ) /*0x10671143a*/
    {
      result = RBX::Network::NetworkStream::readBool(this: a2); /*0x10671143f*/
      *a3 = result; /*0x106711444*/
    }
  }
  return result; /*0x10671144a*/
}

// Address: 0x106711452 | Name: __ZN3RBX7Network16ClientReplicator24readChangedAttributeItemEPNS0_31DeserializedChangeAttributeItemE
__int64 __fastcall RBX::Network::ClientReplicator::readChangedAttributeItem(
        RBX::Network::ClientReplicator *this,
        RBX::Network::DeserializedChangeAttributeItem *a2)
{
  __int64 result; // rax
  __int64 v5; // r15
  void *v6; // rsi
  __int128 v7; // [rsp+0h] [rbp-50h] BYREF
  void *v8; // [rsp+10h] [rbp-40h]
  __int64 v9; // [rsp+18h] [rbp-38h]
  __int128 v10; // [rsp+20h] [rbp-30h] BYREF
  void *v11; // [rsp+30h] [rbp-20h]

  if ( (unsigned __int8)RBX::Network::Replicator::getAttributeSynchronizationEnabled(this) != 0 ) /*0x10671146c*/
  {
    result = (*(__int64 (__fastcall **)(RBX::Network::ClientReplicator *))(*(_QWORD *)this + 1032LL))(a1: this); /*0x106711478*/
    if ( (_BYTE)result != 0 ) /*0x106711480*/
    {
      v5 = *((_QWORD *)a2 + 5); /*0x106711486*/
      if ( v5 == 0 ) /*0x10671148d*/
        return result; /*0x10671148d*/
      if ( (*((_BYTE *)a2 + 56) & 1) != 0 ) /*0x106711497*/
      {
        std::string::__init_copy_ctor_external(a1: &v10, a2: *((_QWORD *)a2 + 9), a3: *((_QWORD *)a2 + 8)); /*0x1067114ba*/
      }
      else
      {
        v11 = *((void **)a2 + 9); /*0x1067114a1*/
        v10 = *(_OWORD *)((char *)a2 + 56); /*0x1067114a8*/
      }
      v8 = v11; /*0x1067114c7*/
      v7 = v10; /*0x1067114cf*/
      v10 = 0; /*0x1067114d5*/
      v11 = nullptr; /*0x1067114d9*/
      v9 = *(_QWORD *)(v5 + 48); /*0x1067114e5*/
      RBX::Network::Sync::Slave<RBX::Network::Sync::AttributeKey>::slaveOnReceivedChanged( /*0x1067114f7*/
        a1: (char *)this + 21896,
        a2: &v7,
        a3: *((unsigned __int8 *)a2 + 160));
      if ( (v7 & 1) != 0 ) /*0x106711500*/
        operator delete(a1: (RBX::Memory *)v8, a2: v6); /*0x106711506*/
      if ( (v10 & 1) != 0 ) /*0x10671150f*/
        operator delete(a1: (RBX::Memory *)v11, a2: v6); /*0x106711515*/
    }
  }
  return RBX::Network::Replicator::readChangedAttributeItem(this, a2); /*0x106711525*/
}

// Address: 0x1067115ba | Name: __ZNK3RBX7Network16ClientReplicator33isLimitedByOutgoingBandwidthLimitEv
char __fastcall RBX::Network::ClientReplicator::isLimitedByOutgoingBandwidthLimit(RBX::Network::ClientReplicator *this)
{
  __int64 RakNetStats; // rax

  RakNetStats = RBX::Network::Replicator::getRakNetStats(this); /*0x1067115be*/
  if ( RakNetStats != 0 ) /*0x1067115c6*/
    return *(_BYTE *)(RakNetStats + 344); /*0x1067115c8*/
  else
    return 1; /*0x1067115d0*/
}

// Address: 0x1067115d4 | Name: __ZNK3RBX7Network16ClientReplicator24isDuplicateOfLocalPlayerERKNS_6PlayerE
bool __fastcall RBX::Network::ClientReplicator::isDuplicateOfLocalPlayer(
        RBX::Network::ClientReplicator *this,
        const RBX::Player *a2)
{
  __int64 UserID; // rbx
  __int64 v4; // rax
  __int64 v5; // rax

  if ( FFlag::MigrateUserIdAccessors == 1 ) /*0x1067115ec*/
    UserID = *((_QWORD *)a2 + 26); /*0x1067115ee*/
  else
    UserID = RBX::PlayerProp::getUserID(this: (const RBX::Player *)((char *)a2 + 176)); /*0x106711606*/
  v4 = (*(__int64 (__fastcall **)(RBX::Network::ClientReplicator *))(*(_QWORD *)this + 688LL))(a1: this); /*0x10671160f*/
  if ( v4 == 0 || UserID == 0 ) /*0x10671161e*/
    return false; /*0x106711637*/
  if ( FFlag::MigrateUserIdAccessors == 1 ) /*0x10671162c*/
    v5 = *(_QWORD *)(v4 + 208); /*0x10671162e*/
  else
    v5 = RBX::PlayerProp::getUserID(this: (RBX::PlayerProp *)(v4 + 176)); /*0x106711644*/
  return UserID == v5; /*0x106711653*/
}

// Address: 0x10671165a | Name: __ZN3RBX7Network16ClientReplicator31filterReplicatorChangedPropertyEPNS_6ObjectERKNS_10Reflection18PropertyDescriptorE
__int64 __fastcall RBX::Network::ClientReplicator::filterReplicatorChangedProperty(
        RBX::Network::ClientReplicator *this,
        RBX::Object *a2,
        const RBX::Reflection::PropertyDescriptor *a3)
{
  __int64 result; // rax
  __int64 v6; // rdi
  __int64 v7; // r14
  __int64 v8; // rax

  result = RBX::Network::Replicator::filterReplicatorChangedProperty(this, a2, a3); /*0x106711667*/
  if ( (*((_BYTE *)this + 15544) & ((_DWORD)result == 0)) == 1 ) /*0x10671167b*/
  {
    v7 = *((_QWORD *)a2 + 3); /*0x10671167d*/
    v8 = RBX::Reflection::Class_getDescriptorPtr<RBX::Humanoid>(a1: v6); /*0x106711681*/
    return a2 != nullptr /*0x1067116bb*/
        && *(unsigned __int16 *)(v7 + 440) - (unsigned int)*(unsigned __int16 *)(v8 + 440) <= *(unsigned __int16 *)(v8 + 442)
        && RBX::Humanoid::getTorsoSlow(this: a2) == 0;
  }
  return result; /*0x1067116b6*/
}

// Address: 0x1067116c2 | Name: __ZN3RBX7Network16ClientReplicator20filterReceivedParentEPNS_8InstanceES3_
__int64 __fastcall RBX::Network::ClientReplicator::filterReceivedParent(
        RBX::Network::ClientReplicator *this,
        RBX::Instance *a2,
        RBX::Instance *a3,
        int a4,
        int a5,
        int a6)
{
  __int64 result; // rax

  result = 0; /*0x1067116c2*/
  if ( (*((_BYTE *)a2 + 170) & 1) != 0 ) /*0x1067116cb*/
  {
    RBX::CreatorLog::printf(a1: 2, a2: (unsigned int)"trying to set locked parent!", (_DWORD)a3, a4, a5, a6); /*0x1067116df*/
    return 1; /*0x1067116e4*/
  }
  return result; /*0x1067116ea*/
}

// Address: 0x1067116f4 | Name: __ZN3RBX7Network16ClientReplicator17onServiceProviderEPNS_15ServiceProviderES3_
__int64 __fastcall RBX::Network::ClientReplicator::onServiceProvider(
        std::__shared_weak_count **this,
        RBX::ServiceProvider *a2,
        RBX::ServiceProvider *a3)
{
  volatile signed __int64 *v6; // rax
  std::__shared_weak_count *v7; // r13
  __int64 v8; // rax
  std::__shared_weak_count *v9; // r12
  __int64 v10; // r12
  char *v11; // rdx
  std::__shared_weak_count *v12; // r12
  volatile signed __int64 *v13; // rax
  std::__shared_weak_count *v14; // r12
  __int64 v15; // rdi
  std::__shared_weak_count *v16; // r13
  volatile signed __int64 *v17; // rax
  std::__shared_weak_count *v18; // r12
  __int64 v19; // rdi
  std::__shared_weak_count *v20; // r13
  __int64 v21; // rax
  __int64 v22; // r12
  unsigned int v23; // r13d
  __int64 ClusterQueueSize; // rax
  __int64 v25; // r8
  __int64 v26; // r9
  __m128 v27; // xmm1
  __m128 v28; // xmm2
  __m128 v29; // xmm3
  __m128 v30; // xmm4
  __m128 v31; // xmm5
  __m128 v32; // xmm6
  __m128 v33; // xmm7
  __int64 v34; // rcx
  __m128 v35; // xmm0
  __int64 UserID; // rdx
  __int64 v37; // rdx
  __int64 v38; // rcx
  __int64 v39; // rax
  void *v40; // rsi
  __int64 v41; // r12
  __int64 v42; // rax
  __int64 v43; // rcx
  __int64 v44; // r8
  __int64 v45; // r9
  __m128 v46; // xmm0
  __m128 v47; // xmm1
  __m128 v48; // xmm2
  __m128 v49; // xmm3
  __m128 v50; // xmm4
  __m128 v51; // xmm5
  __m128 v52; // xmm6
  __m128 v53; // xmm7
  __int64 v54; // rdx
  __int64 v55; // rcx
  __int64 v56; // rax
  void *v57; // rsi
  __int64 v58; // r12
  void *v59; // rsi
  __int64 v60; // rdx
  __int64 v61; // rcx
  __int64 v62; // rax
  __int64 v63; // rcx
  void *v64; // rsi
  __int64 v65; // r8
  __int64 v66; // r9
  __m128 v67; // xmm1
  __m128 v68; // xmm2
  __m128 v69; // xmm3
  __m128 v70; // xmm4
  __m128 v71; // xmm5
  __m128 v72; // xmm6
  __m128 v73; // xmm7
  __int64 v74; // r12
  __m128 v75; // xmm0
  void *v76; // rsi
  __int64 v77; // rdx
  __int64 v78; // rcx
  __int64 v79; // rax
  __int64 v80; // rdx
  __int64 v81; // rcx
  void *v82; // rsi
  __int64 v83; // r12
  void *v84; // rsi
  __int64 v85; // rdx
  __int64 v86; // rcx
  __int64 v87; // rdx
  __int64 v88; // rcx
  void *v89; // rsi
  std::__shared_weak_count *v90; // rax
  int DisconnectReason; // eax
  unsigned int v92; // eax
  void *v93; // rsi
  int v94; // esi
  __int64 result; // rax
  __int64 v96; // rdi
  RBX::Instance *v97; // rsi
  __int64 v98; // r8
  __int64 v99; // r9
  __m128 v100; // xmm0
  __m128 v101; // xmm1
  __m128 v102; // xmm2
  __m128 v103; // xmm3
  __m128 v104; // xmm4
  __m128 v105; // xmm5
  __m128 v106; // xmm6
  __m128 v107; // xmm7
  __int64 v108; // rax
  RBX::Network::Client *v109; // rbx
  __int64 v110; // r14
  __int64 v111; // rax
  unsigned int v112; // ecx
  int v113; // r15d
  __int64 v114; // rax
  __int64 v115; // rcx
  __int64 v116; // rdx
  __int64 v117; // rcx
  int PairIntValue; // r14d
  __int64 v119; // rax
  __int64 v120; // rcx
  __int64 v121; // rdx
  __int64 v122; // rcx
  int v123; // r14d
  __int64 v124; // rax
  int v125; // r13d
  __int64 v126; // rax
  __int64 v127; // rdx
  __int64 v128; // rcx
  unsigned int v129; // r14d
  void *v130; // r12
  __int64 v131; // r15
  void *v132; // rsi
  int v133; // r14d
  __int64 v134; // r14
  __int64 v135; // r15
  __int64 v136; // rdx
  unsigned int v137; // r15d
  void *v138; // r12
  void *v139; // rsi
  int v140; // r14d
  double v141; // xmm0_8
  char v142; // [rsp+0h] [rbp-160h]
  char v143; // [rsp+0h] [rbp-160h]
  char v144; // [rsp+0h] [rbp-160h]
  _QWORD v145[6]; // [rsp+8h] [rbp-158h] BYREF
  std::__shared_weak_count *v146; // [rsp+38h] [rbp-128h]
  __int128 v147; // [rsp+40h] [rbp-120h] BYREF
  _BYTE v148[16]; // [rsp+50h] [rbp-110h] BYREF
  void *v149; // [rsp+60h] [rbp-100h]
  _BYTE v150[16]; // [rsp+68h] [rbp-F8h] BYREF
  void *v151; // [rsp+78h] [rbp-E8h]
  _BYTE v152[16]; // [rsp+80h] [rbp-E0h] BYREF
  void *v153; // [rsp+90h] [rbp-D0h]
  _BYTE v154[16]; // [rsp+98h] [rbp-C8h] BYREF
  void *v155; // [rsp+A8h] [rbp-B8h]
  int v156[4]; // [rsp+B0h] [rbp-B0h] BYREF
  void *v157; // [rsp+C0h] [rbp-A0h]
  _BYTE *v158; // [rsp+C8h] [rbp-98h] BYREF
  __int64 v159; // [rsp+D0h] [rbp-90h]
  _BYTE v160[16]; // [rsp+D8h] [rbp-88h] BYREF
  void *v161; // [rsp+E8h] [rbp-78h]
  std::__shared_weak_count *v162[2]; // [rsp+F0h] [rbp-70h] BYREF
  void *v163[2]; // [rsp+100h] [rbp-60h]
  int v164; // [rsp+110h] [rbp-50h]
  __m128 v165; // [rsp+118h] [rbp-48h] BYREF
  void *v166; // [rsp+128h] [rbp-38h]
  _BYTE v167[41]; // [rsp+137h] [rbp-29h] BYREF

  if ( *(this + 2753) != nullptr ) /*0x10671171b*/
  {
    v162[0] = *(this + 2753); /*0x106711721*/
    v6 = (volatile signed __int64 *)*(this + 2754); /*0x106711725*/
    v162[1] = (std::__shared_weak_count *)v6; /*0x10671172c*/
    if ( v6 != nullptr ) /*0x106711733*/
      _InterlockedIncrement64(v6 + 1); /*0x106711735*/
    RBX::TaskScheduler::remove(a1: v162); /*0x10671173e*/
    v7 = v162[1]; /*0x10671174a*/
    if ( v162[1] != nullptr /*0x106711763*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v162[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(a1: v7); /*0x10671176c*/
      std::__shared_weak_count::__release_weak(this: v7); /*0x106711772*/
    }
    std::shared_ptr<RBX::Network::ClientReplicator::GCJob>::reset[abi:ne200100](a1: this + 2753); /*0x10671177a*/
    v8 = (*((__int64 (__fastcall **)(std::__shared_weak_count **))*this + 86))(a1: this); /*0x106711785*/
    if ( v8 != 0 ) /*0x10671178e*/
    {
      v147 = 0; /*0x10671179b*/
      RBX::Player::setStreamingInterface(a1: v8, a2: &v147); /*0x1067117a2*/
      v9 = *((std::__shared_weak_count **)&v147 + 1); /*0x1067117a7*/
      if ( *((_QWORD *)&v147 + 1) != 0 /*0x1067117c4*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v147 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v9 + 16LL))(a1: v9); /*0x1067117cd*/
        std::__shared_weak_count::__release_weak(this: v9); /*0x1067117d3*/
      }
    }
  }
  if ( (*((__int64 (__fastcall **)(std::__shared_weak_count **))*this + 86))(a1: this) != 0 ) /*0x1067117e7*/
  {
    v10 = (*((__int64 (__fastcall **)(std::__shared_weak_count **))*this + 86))(a1: this); /*0x1067117f9*/
    RBX::shared_from<RBX::Network::ClientReplicator>(a1: v162, a2: (__int64)this); /*0x106711806*/
    v11 = (char *)v162[0] + 216; /*0x106711813*/
    if ( v162[0] == nullptr ) /*0x10671181d*/
      v11 = nullptr; /*0x10671181d*/
    v145[5] = v11; /*0x106711828*/
    v146 = v162[1]; /*0x10671182b*/
    *(_OWORD *)v162 = 0; /*0x106711833*/
    RBX::Player::setNetworkInterface(a1: v10); /*0x10671183c*/
    if ( v146 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v146 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10671185e*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v146 + 16LL))(a1: v146); /*0x106711867*/
      std::__shared_weak_count::__release_weak(this: v146); /*0x10671186d*/
    }
    v12 = v162[1]; /*0x106711872*/
    if ( v162[1] != nullptr /*0x10671188c*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v162[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v12 + 16LL))(a1: v12); /*0x106711895*/
      std::__shared_weak_count::__release_weak(this: v12); /*0x10671189b*/
    }
  }
  if ( *(this + 2755) != nullptr ) /*0x1067118aa*/
  {
    v162[0] = *(this + 2755); /*0x1067118b0*/
    v13 = (volatile signed __int64 *)*(this + 2756); /*0x1067118b4*/
    v162[1] = (std::__shared_weak_count *)v13; /*0x1067118bb*/
    if ( v13 != nullptr ) /*0x1067118c2*/
      _InterlockedIncrement64(v13 + 1); /*0x1067118c4*/
    RBX::TaskScheduler::remove(a1: v162); /*0x1067118cd*/
    v14 = v162[1]; /*0x1067118d2*/
    if ( v162[1] != nullptr /*0x1067118ec*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v162[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v14 + 16LL))(a1: v14); /*0x1067118f5*/
      std::__shared_weak_count::__release_weak(this: v14); /*0x1067118fb*/
    }
    v15 = (__int64)*(this + 1801); /*0x106711900*/
    *(_OWORD *)v162 = 0; /*0x10671190f*/
    RBX::Network::MegaReplicator::setStreamingSolverV2(a1: v15, a2: v162); /*0x106711913*/
    v16 = v162[1]; /*0x10671191f*/
    if ( v162[1] != nullptr /*0x106711938*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v162[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v16 + 16LL))(a1: v16); /*0x106711941*/
      std::__shared_weak_count::__release_weak(this: v16); /*0x106711947*/
    }
    std::shared_ptr<RBX::Network::StreamingSolverV2>::reset[abi:ne200100](a1: this + 2755); /*0x10671194f*/
  }
  if ( *(this + 2757) != nullptr ) /*0x10671195e*/
  {
    v162[0] = *(this + 2757); /*0x106711964*/
    v17 = (volatile signed __int64 *)*(this + 2758); /*0x106711968*/
    v162[1] = (std::__shared_weak_count *)v17; /*0x10671196f*/
    if ( v17 != nullptr ) /*0x106711976*/
      _InterlockedIncrement64(v17 + 1); /*0x106711978*/
    RBX::TaskScheduler::remove(a1: v162); /*0x106711981*/
    v18 = v162[1]; /*0x106711986*/
    if ( v162[1] != nullptr /*0x1067119a0*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v162[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v18 + 16LL))(a1: v18); /*0x1067119a9*/
      std::__shared_weak_count::__release_weak(this: v18); /*0x1067119af*/
    }
    v19 = (__int64)*(this + 1801); /*0x1067119b4*/
    *(_OWORD *)v162 = 0; /*0x1067119c3*/
    RBX::Network::MegaReplicator::setObjectManager(a1: v19, a2: v162); /*0x1067119c7*/
    v20 = v162[1]; /*0x1067119d3*/
    if ( v162[1] != nullptr /*0x1067119ec*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v162[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v20 + 16LL))(a1: v20); /*0x1067119f5*/
      std::__shared_weak_count::__release_weak(this: v20); /*0x1067119fb*/
    }
    std::shared_ptr<RBX::Network::InstanceObjectManager>::reset[abi:ne200100](a1: this + 2757); /*0x106711a03*/
  }
  if ( a3 == nullptr ) /*0x106711a0b*/
  {
    if ( DFFlag::ReportTeamCreateReplicatorShutdownMetrics == 1 /*0x106711a2c*/
      && (*((unsigned __int8 (__fastcall **)(std::__shared_weak_count **))*this + 129))(a1: this) != 0 )
    {
      v21 = (*((__int64 (__fastcall **)(std::__shared_weak_count **))*this + 86))(a1: this); /*0x106711a38*/
      if ( v21 != 0 ) /*0x106711a41*/
      {
        v22 = v21; /*0x106711a47*/
        v23 = RBX::Network::ItemQueue::size(this: (RBX::Network::ItemQueue *)(this + 1817)); /*0x106711a56*/
        ClusterQueueSize = RBX::Network::Replicator::getClusterQueueSize((RBX::Network::Replicator *)this); /*0x106711a5c*/
        LOBYTE(v34) = (int)v23 > 0 || (int)ClusterQueueSize > 0; /*0x106711a6c*/
        if ( (_BYTE)v34 == 1 ) /*0x106711a71*/
        {
          v159 = ClusterQueueSize; /*0x106711a77*/
          v35 = 0; /*0x106711a7e*/
          *(_OWORD *)v163 = 0; /*0x106711a82*/
          *(_OWORD *)v162 = 0; /*0x106711a87*/
          v164 = 1065353216; /*0x106711a8c*/
          if ( FFlag::MigrateUserIdAccessors == 1 ) /*0x106711a9d*/
            UserID = *(_QWORD *)(v22 + 208); /*0x106711a9f*/
          else
            UserID = RBX::PlayerProp::getUserID(this: (RBX::PlayerProp *)(v22 + 176)); /*0x106711ab8*/
          RBX::format( /*0x106711ac8*/
            this: (RBX *)&v165,
            a2: "%lld",
            a3: UserID,
            a4: v34,
            a5: v25,
            a6: v26,
            a7: v35,
            a8: v27,
            a9: v28,
            a10: v29,
            a11: v30,
            a12: v31,
            a13: v32,
            a14: v33,
            a15: v142);
          std::string::basic_string[abi:ne200100]<0>(a1: v160, a2: "userId", a3: v37, a4: v38); /*0x106711ade*/
          v158 = v160; /*0x106711aea*/
          v39 = std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x106711aff*/
                  a1: v162,
                  a2: v160,
                  a3: std::piecewise_construct,
                  a4: &v158,
                  a5: v167);
          v41 = v39 + 40; /*0x106711b07*/
          if ( (*(_BYTE *)(v39 + 40) & 1) != 0 ) /*0x106711b0f*/
            operator delete(a1: *(RBX::Memory **)(v39 + 56), a2: v40); /*0x106711b15*/
          *(_QWORD *)(v41 + 16) = v166; /*0x106711b1e*/
          *(__m128 *)v41 = v165; /*0x106711b28*/
          v165.i16[0] = 0; /*0x106711b2e*/
          if ( (v160[0] & 1) != 0 ) /*0x106711b3b*/
          {
            operator delete(a1: (RBX::Memory *)v161, a2: v40); /*0x106711b41*/
            if ( (v165.i8[0] & 1) != 0 ) /*0x106711b4a*/
              operator delete(a1: (RBX::Memory *)v166, a2: v40); /*0x106711b50*/
          }
          v42 = RBX::DataModel::get((RBX::DataModel *)this, a2: (RBX::Instance *)v40); /*0x106711b58*/
          if ( v42 != 0 ) /*0x106711b60*/
          {
            RBX::format( /*0x106711b7a*/
              this: (RBX *)&v165,
              a2: "%lld",
              a3: *(_QWORD *)(v42 + 840),
              a4: v43,
              a5: v44,
              a6: v45,
              a7: v46,
              a8: v47,
              a9: v48,
              a10: v49,
              a11: v50,
              a12: v51,
              a13: v52,
              a14: v53,
              a15: v143);
            std::string::basic_string[abi:ne200100]<0>(a1: v160, a2: "placeId", a3: v54, a4: v55); /*0x106711b90*/
            v158 = v160; /*0x106711b9c*/
            v56 = std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x106711bb1*/
                    a1: v162,
                    a2: v160,
                    a3: std::piecewise_construct,
                    a4: &v158,
                    a5: v167);
            v58 = v56 + 40; /*0x106711bb9*/
            if ( (*(_BYTE *)(v56 + 40) & 1) != 0 ) /*0x106711bc1*/
              operator delete(a1: *(RBX::Memory **)(v56 + 56), a2: v57); /*0x106711bc7*/
            *(_QWORD *)(v58 + 16) = v166; /*0x106711bd0*/
            v46 = v165; /*0x106711bd5*/
            *(__m128 *)v58 = v165; /*0x106711bda*/
            v165.i16[0] = 0; /*0x106711be0*/
            if ( (v160[0] & 1) != 0 ) /*0x106711bed*/
            {
              operator delete(a1: (RBX::Memory *)v161, a2: v57); /*0x106711bf3*/
              if ( (v165.i8[0] & 1) != 0 ) /*0x106711bfc*/
                operator delete(a1: (RBX::Memory *)v166, a2: v59); /*0x106711c02*/
            }
          }
          RBX::format( /*0x106711c17*/
            this: (RBX *)&v165,
            a2: "%d",
            a3: v23,
            a4: v43,
            a5: v44,
            a6: v45,
            a7: v46,
            a8: v47,
            a9: v48,
            a10: v49,
            a11: v50,
            a12: v51,
            a13: v52,
            a14: v53,
            a15: v143);
          std::string::basic_string[abi:ne200100]<0>(a1: v160, a2: "pendingItems", a3: v60, a4: v61); /*0x106711c2d*/
          v158 = v160; /*0x106711c39*/
          v62 = std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x106711c4e*/
                  a1: v162,
                  a2: v160,
                  a3: std::piecewise_construct,
                  a4: &v158,
                  a5: v167);
          v74 = v62 + 40; /*0x106711c56*/
          if ( (*(_BYTE *)(v62 + 40) & 1) != 0 ) /*0x106711c5e*/
            operator delete(a1: *(RBX::Memory **)(v62 + 56), a2: v64); /*0x106711c64*/
          *(_QWORD *)(v74 + 16) = v166; /*0x106711c6d*/
          v75 = v165; /*0x106711c72*/
          *(__m128 *)v74 = v165; /*0x106711c77*/
          v165.i16[0] = 0; /*0x106711c7d*/
          if ( (v160[0] & 1) != 0 ) /*0x106711c8a*/
          {
            operator delete(a1: (RBX::Memory *)v161, a2: v64); /*0x106711c90*/
            if ( (v165.i8[0] & 1) != 0 ) /*0x106711c99*/
              operator delete(a1: (RBX::Memory *)v166, a2: v76); /*0x106711c9f*/
          }
          RBX::format( /*0x106711cb8*/
            this: (RBX *)&v165,
            a2: "%d",
            a3: v159,
            a4: v63,
            a5: v65,
            a6: v66,
            a7: v75,
            a8: v67,
            a9: v68,
            a10: v69,
            a11: v70,
            a12: v71,
            a13: v72,
            a14: v73,
            a15: v144);
          std::string::basic_string[abi:ne200100]<0>(a1: v160, a2: "pendingClusterDeltas", a3: v77, a4: v78); /*0x106711cce*/
          v158 = v160; /*0x106711cda*/
          v79 = std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x106711cef*/
                  a1: v162,
                  a2: v160,
                  a3: std::piecewise_construct,
                  a4: &v158,
                  a5: v167);
          v83 = v79 + 40; /*0x106711cf7*/
          if ( (*(_BYTE *)(v79 + 40) & 1) != 0 ) /*0x106711cff*/
            operator delete(a1: *(RBX::Memory **)(v79 + 56), a2: v82); /*0x106711d05*/
          *(_QWORD *)(v83 + 16) = v166; /*0x106711d0e*/
          *(__m128 *)v83 = v165; /*0x106711d18*/
          v165.i16[0] = 0; /*0x106711d1e*/
          if ( (v160[0] & 1) != 0 ) /*0x106711d2b*/
          {
            operator delete(a1: (RBX::Memory *)v161, a2: v82); /*0x106711d31*/
            if ( (v165.i8[0] & 1) != 0 ) /*0x106711d3a*/
              operator delete(a1: (RBX::Memory *)v166, a2: v84); /*0x106711d40*/
          }
          std::string::basic_string[abi:ne200100]<0>(a1: v148, a2: "studio", a3: v80, a4: v81); /*0x106711d53*/
          std::string::basic_string[abi:ne200100]<0>(a1: v150, a2: "TeamCreate", a3: v85, a4: v86); /*0x106711d66*/
          std::string::basic_string[abi:ne200100]<0>(a1: v152, a2: "ReplicationPending", a3: v87, a4: v88); /*0x106711d79*/
          std::unordered_map<std::string,std::string>::unordered_map(a1: v145, a2: v162); /*0x106711d89*/
          RBX::Analytics::EventIngest::setRBXEvent(a1: v148, a2: v150, a3: v152, a4: v145); /*0x106711daa*/
          std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::~__hash_table(a1: v145); /*0x106711db6*/
          if ( (v152[0] & 1) != 0 ) /*0x106711dc2*/
            operator delete(a1: (RBX::Memory *)v153, a2: v89); /*0x106711dcb*/
          if ( (v150[0] & 1) != 0 ) /*0x106711dd7*/
            operator delete(a1: (RBX::Memory *)v151, a2: v89); /*0x106711de0*/
          if ( (v148[0] & 1) != 0 ) /*0x106711dec*/
            operator delete(a1: (RBX::Memory *)v149, a2: v89); /*0x106711df5*/
          std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::~__hash_table(a1: v162); /*0x106711dfe*/
        }
      }
    }
    if ( (unsigned int)RBX::Network::Replicator::getDisconnectReason((RBX::Network::Replicator *)this) == 0 ) /*0x106711e0d*/
      RBX::Network::Replicator::safeSetDisconnectReason((RBX::Network::Replicator *)this, a2: 1u); /*0x106711e17*/
    RBX::Network::RakNetAddressToString( /*0x106711e34*/
      this: (RBX::Network *)v162,
      a2: (const RakNet::SystemAddress *)(this + 30),
      a3: true,
      a4: 124);
    if ( ((__int64)v162[0] & 1) != 0 ) /*0x106711e40*/
      v90 = v162[1]; /*0x106711e42*/
    else
      v90 = (std::__shared_weak_count *)(LOBYTE(v162[0]) >> 1); /*0x106711e48*/
    if ( v90 == nullptr ) /*0x106711e4d*/
      std::string::assign(a1: v162, a2: "server"); /*0x106711e5a*/
    v157 = v163[0]; /*0x106711e63*/
    *(_OWORD *)v156 = *(_OWORD *)v162; /*0x106711e6f*/
    *(_OWORD *)v162 = 0; /*0x106711e7b*/
    v163[0] = nullptr; /*0x106711e80*/
    DisconnectReason = RBX::Network::Replicator::getDisconnectReason((RBX::Network::Replicator *)this); /*0x106711e8b*/
    RBX::Network::Replicator::disconnectReasonToString(this: (RBX::Network::Replicator *)v154, a2: DisconnectReason); /*0x106711e99*/
    v92 = RBX::Network::Replicator::getDisconnectReason((RBX::Network::Replicator *)this); /*0x106711ea1*/
    RBX::Network::Replicator::sendDisconnectionSignal(a1: this, a2: v156, a3: 0, a4: v154, a5: v92); /*0x106711ebc*/
    if ( (v154[0] & 1) != 0 ) /*0x106711ec8*/
      operator delete(a1: (RBX::Memory *)v155, a2: v93); /*0x106711ed1*/
    if ( (v156[0] & 1) != 0 ) /*0x106711edd*/
      operator delete(a1: (RBX::Memory *)v157, a2: v93); /*0x106711ee6*/
    if ( ((__int64)v162[0] & 1) != 0 ) /*0x106711eef*/
      operator delete(a1: (RBX::Memory *)v163[0], a2: v93); /*0x106711ef5*/
  }
  RBX::Network::MegaReplicator::removeMegaJobs(this: *(this + 1801)); /*0x106711f01*/
  if ( (unsigned __int8)RBX::Analytics::InfluxDb::canSend( /*0x106711f16*/
                          this: (RBX::Analytics::InfluxDb *)(unsigned int)DFInt::StreamingJoinStatsHundredths,
                          a2: v94) != 0 )
    rbx::signals::connection::disconnect(this: (rbx::signals::connection *)(this + 2988)); /*0x106711f1f*/
  result = RBX::Network::Replicator::onServiceProvider((RBX::Network::Replicator *)this, a2, a3); /*0x106711f2d*/
  if ( a3 != nullptr ) /*0x106711f35*/
  {
    if ( (DFString::ClientJoinRxConfigPerDC & 1) != 0 ) /*0x106711f40*/
      v108 = qword_10D809BA8; /*0x106711f42*/
    else
      v108 = (unsigned __int8)DFString::ClientJoinRxConfigPerDC >> 1; /*0x106711f90*/
    v113 = DFInt::ReportClientJoinRxStatsHundrethsPercentage; /*0x106711f92*/
    if ( v108 != 0 ) /*0x106711f9c*/
    {
      v114 = RBX::DataModel::get((RBX::DataModel *)this, a2: v97); /*0x106711fa1*/
      if ( v114 != 0 ) /*0x106711fa9*/
      {
        RBX::format( /*0x106711fbe*/
          this: (RBX *)v162,
          a2: "%d",
          a3: *(unsigned int *)(v114 + 2184),
          a4: v115,
          a5: v98,
          a6: v99,
          a7: v100,
          a8: v101,
          a9: v102,
          a10: v103,
          a11: v104,
          a12: v105,
          a13: v106,
          a14: v107,
          a15: v142);
        std::string::basic_string[abi:ne200100]<0>(a1: &v165, a2: ",", a3: v116, a4: v117); /*0x106711fce*/
        PairIntValue = RBX::Network::getPairIntValue(a1: v162, a2: &DFString::ClientJoinRxConfigPerDC, a3: &v165); /*0x106711fe7*/
        if ( (v165.i8[0] & 1) != 0 ) /*0x106711fee*/
          operator delete(a1: (RBX::Memory *)v166, a2: v97); /*0x106711ff4*/
        if ( ((__int64)v162[0] & 1) != 0 ) /*0x106711ffd*/
          operator delete(a1: (RBX::Memory *)v163[0], a2: v97); /*0x106712003*/
        if ( PairIntValue != -1 ) /*0x10671200c*/
          v113 = PairIntValue; /*0x10671200c*/
      }
    }
    if ( (DFString::ClientJoinRxConfigUserIdPer100 & 1) != 0 ) /*0x106712019*/
      v119 = qword_10D809B90; /*0x10671201b*/
    else
      v119 = DFString::ClientJoinRxConfigUserIdPer100 >> 1; /*0x106712024*/
    if ( v119 != 0 ) /*0x106712033*/
    {
      v120 = (unsigned int)((__int64)*(this + 2700) % 100); /*0x106712059*/
      RBX::format( /*0x10671206a*/
        this: (RBX *)v162,
        a2: "%d",
        a3: (unsigned int)v120,
        a4: v120,
        a5: v98,
        a6: v99,
        a7: v100,
        a8: v101,
        a9: v102,
        a10: v103,
        a11: v104,
        a12: v105,
        a13: v106,
        a14: v107,
        a15: v142);
      std::string::basic_string[abi:ne200100]<0>(a1: &v165, a2: ",", a3: v121, a4: v122); /*0x10671207a*/
      v123 = RBX::Network::getPairIntValue(a1: v162, a2: &DFString::ClientJoinRxConfigUserIdPer100, a3: &v165); /*0x106712093*/
      if ( (v165.i8[0] & 1) != 0 ) /*0x10671209a*/
        operator delete(a1: (RBX::Memory *)v166, a2: v97); /*0x1067120a0*/
      if ( ((__int64)v162[0] & 1) != 0 ) /*0x1067120a9*/
        operator delete(a1: (RBX::Memory *)v163[0], a2: v97); /*0x1067120af*/
      if ( v123 != -1 ) /*0x1067120b8*/
        v113 = v123; /*0x1067120b8*/
    }
    *((_DWORD *)this + 3945) = v113; /*0x1067120bc*/
    if ( (DFString::CliNetIngressLimiterReportingConfigPerDC & 1) != 0 ) /*0x1067120cc*/
      v124 = qword_10D809B60; /*0x1067120ce*/
    else
      v124 = (unsigned __int8)DFString::CliNetIngressLimiterReportingConfigPerDC >> 1; /*0x1067120d7*/
    v125 = DFInt::CliNetIngressLimiterReportingPer100K; /*0x1067120d9*/
    if ( v124 != 0 ) /*0x1067120e3*/
    {
      v126 = RBX::DataModel::get((RBX::DataModel *)this, a2: v97); /*0x1067120ec*/
      if ( v126 != 0 ) /*0x1067120f4*/
      {
        v129 = *(_DWORD *)(v126 + 2184); /*0x1067120fa*/
        LODWORD(v159) = v125; /*0x10671210d*/
        if ( (DFString::CliNetIngressLimiterReportingConfigPerDC & 1) != 0 ) /*0x106712114*/
        {
          v130 = (void *)qword_10D809B68; /*0x106712116*/
          v131 = qword_10D809B60; /*0x10671211d*/
        }
        else
        {
          v131 = (unsigned __int8)DFString::CliNetIngressLimiterReportingConfigPerDC >> 1; /*0x106712126*/
          v130 = &unk_10D809B59; /*0x106712129*/
        }
        std::string::basic_string[abi:ne200100]<0>(a1: v162, a2: ",", a3: v127, a4: v128); /*0x10671213e*/
        v133 = RBX::Network::getPairIntValue(a1: v129, a2: v130, a3: v131, a4: v162); /*0x106712154*/
        v125 = v159; /*0x106712165*/
        if ( ((__int64)v162[0] & 1) != 0 ) /*0x10671216c*/
          operator delete(a1: (RBX::Memory *)v163[0], a2: v132); /*0x106712172*/
        if ( v133 != -1 ) /*0x10671217b*/
          v125 = v133; /*0x10671217b*/
      }
    }
    if ( (DFString::CliNetIngressLimiterReportingConfigUserIdPer100K & 1) != 0 ) /*0x106712189*/
      v134 = qword_10D809B48; /*0x10671218b*/
    else
      v134 = (unsigned __int8)DFString::CliNetIngressLimiterReportingConfigUserIdPer100K >> 1; /*0x106712197*/
    if ( v134 != 0 ) /*0x10671219d*/
    {
      v135 = (__int64)*(this + 2700); /*0x1067121a3*/
      v136 = (unsigned int)(v135 / 100); /*0x1067121be*/
      v137 = v135 % 100; /*0x1067121c3*/
      LODWORD(v159) = v125; /*0x1067121c9*/
      if ( (DFString::CliNetIngressLimiterReportingConfigUserIdPer100K & 1) != 0 ) /*0x1067121d0*/
        v138 = (void *)qword_10D809B50; /*0x1067121d2*/
      else
        v138 = &unk_10D809B41; /*0x1067121db*/
      std::string::basic_string[abi:ne200100]<0>( /*0x1067121f0*/
        a1: v162,
        a2: ",",
        a3: v136,
        a4: (unsigned __int8)DFString::CliNetIngressLimiterReportingConfigUserIdPer100K);
      v140 = RBX::Network::getPairIntValue(a1: v137, a2: v138, a3: v134, a4: v162); /*0x106712206*/
      v125 = v159; /*0x10671220d*/
      if ( ((__int64)v162[0] & 1) != 0 ) /*0x106712214*/
        operator delete(a1: (RBX::Memory *)v163[0], a2: v139); /*0x10671221a*/
      if ( v140 != -1 ) /*0x106712223*/
        v125 = v140; /*0x106712223*/
    }
    *((_DWORD *)this + 4655) = v125; /*0x106712227*/
    result = RBX::Network::Replicator::useConfigurablePropSync((RBX::Network::Replicator *)this); /*0x106712231*/
    if ( (_BYTE)result != 0 ) /*0x106712238*/
    {
      v141 = (double)DFInt::ClientPropSyncExpiryTeamCreateTimeSec; /*0x10671223d*/
      *((double *)this + 2723) = (double)DFInt::ClientPropSyncExpiryTeamCreateTimeSec; /*0x106712245*/
      *((double *)this + 2737) = v141; /*0x10671224d*/
    }
  }
  else
  {
    v109 = *(this + 13); /*0x106711f4b*/
    if ( v109 != nullptr ) /*0x106711f52*/
    {
      v110 = *((_QWORD *)v109 + 3); /*0x106711f58*/
      v111 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>(a1: v96); /*0x106711f5c*/
      v112 = *(unsigned __int16 *)(v110 + 440) - *(unsigned __int16 *)(v111 + 440); /*0x106711f70*/
      result = *(unsigned __int16 *)(v111 + 442); /*0x106711f72*/
      if ( v112 <= (unsigned int)result ) /*0x106711f7b*/
        return (__int64)RBX::Network::Client::setClientReplicator(this: v109, a2: nullptr); /*0x106711f86*/
    }
  }
  return result; /*0x106712255*/
}

// Address: 0x10671242c | Name: __ZNK3RBX7Network16ClientReplicator21canUseProtocolVersionEi
bool __fastcall RBX::Network::ClientReplicator::canUseProtocolVersion(RBX::Network::ClientReplicator *this, int a2)
{
  return a2 < 37; /*0x106712436*/
}

// Address: 0x106712438 | Name: __ZN3RBX7Network16ClientReplicator18deserializeSFFlagsERNS0_13NetworkStreamE
void __fastcall RBX::Network::ClientReplicator::deserializeSFFlags(
        RBX::Network::ClientReplicator *this,
        RBX::Network::NetworkStream *a2)
{
  int UInt16; // eax
  FLog *v3; // rdi
  int v4; // r15d
  RakNet::RakString *v5; // r14
  RakNet::RakString *v6; // r12
  RBX::Network::NetworkStream *v7; // r14
  __int64 v8; // rdx
  __int64 v9; // rcx
  __int64 v10; // rdx
  __int64 v11; // rcx
  void *v12; // rsi
  RBX::DataModel *v13; // rbx
  RBX::Instance *v14; // rsi
  RBX::DataModel *v15; // rax
  RBX::DataModel *v16; // r14
  RBX *v17; // rdi
  __int64 v18; // rax
  __int64 v19; // rbx
  char isStudioStreamingEnabled; // al
  __int64 v21; // rdx
  const char *v22; // rsi
  void *v23; // rsi
  __m128 v24; // [rsp+0h] [rbp-80h] BYREF
  void *v25; // [rsp+10h] [rbp-70h]
  RBX::Network::NetworkStream *v26; // [rsp+18h] [rbp-68h]
  __int64 v27; // [rsp+20h] [rbp-60h]
  __int64 v28; // [rsp+28h] [rbp-58h] BYREF
  __int64 v29; // [rsp+30h] [rbp-50h] BYREF
  RBX::DataModel *v30; // [rsp+38h] [rbp-48h]
  __m128 v31; // [rsp+40h] [rbp-40h] BYREF
  void *v32; // [rsp+50h] [rbp-30h]

  v30 = this; /*0x106712449*/
  v26 = a2; /*0x10671244d*/
  UInt16 = RBX::Network::NetworkStream::readUInt16(this: a2); /*0x106712454*/
  if ( (_WORD)UInt16 != 0 ) /*0x10671245c*/
  {
    v4 = UInt16; /*0x106712462*/
    v27 = (__int64)v30 + 12496; /*0x10671246f*/
    v5 = (RakNet::RakString *)&v29; /*0x106712477*/
    do /*0x106712529*/
    {
      RakNet::RakString::RakString(this: (RakNet::RakString *)&v28); /*0x10671247e*/
      v6 = v5; /*0x106712483*/
      RakNet::RakString::RakString(this: v5); /*0x106712489*/
      v7 = v26; /*0x10671248e*/
      RBX::Network::Serializer<RakNet::RakString>::deserialize(this: v26, a2: (RakNet::RakString *)&v28); /*0x10671249b*/
      RBX::Network::Serializer<RakNet::RakString>::deserialize(this: v7, a2: v6); /*0x1067124a6*/
      std::string::basic_string[abi:ne200100]<0>(a1: &v31, a2: *(_QWORD *)(v28 + 32), a3: v8, a4: v9); /*0x1067124b7*/
      std::string::basic_string[abi:ne200100]<0>(a1: &v24, a2: *(_QWORD *)(v29 + 32), a3: v10, a4: v11); /*0x1067124cb*/
      FLog::SetValueFromServer(a1: &v31, a2: &v24); /*0x1067124da*/
      std::__hash_table<std::string,std::hash<std::string>,std::equal_to<std::string>,std::allocator<std::string>>::__emplace_unique_key_args<std::string,std::string const&>( /*0x1067124e9*/
        a1: v27,
        a2: (unsigned __int8 *)&v31,
        a3: (__int64)&v31);
      if ( (v24.i8[0] & 1) != 0 ) /*0x1067124f2*/
        operator delete(a1: (RBX::Memory *)v25, a2: v12); /*0x1067124f8*/
      if ( (v31.i8[0] & 1) != 0 ) /*0x106712501*/
        operator delete(a1: (RBX::Memory *)v32, a2: v12); /*0x106712507*/
      --v4; /*0x10671250c*/
      v5 = v6; /*0x10671250f*/
      RakNet::RakString::~RakString(this: v6); /*0x106712515*/
      RakNet::RakString::~RakString(this: (RakNet::RakString *)&v28); /*0x10671251d*/
    }
    while ( (_WORD)v4 != 0 ); /*0x106712529*/
  }
  v13 = v30; /*0x10671252f*/
  *((_BYTE *)v30 + 12488) = 1; /*0x106712533*/
  FLog::SetSynchronizedVariablesState(this: v3); /*0x10671253a*/
  v15 = (RBX::DataModel *)RBX::DataModel::get(this: v13, a2: v14); /*0x106712542*/
  if ( v15 != nullptr ) /*0x10671254a*/
  {
    v16 = v15; /*0x10671254c*/
    RBX::DataModel::setIsSFFlagsLoaded(this: v15, a2: true); /*0x106712557*/
    v18 = RBX::crashReportInstance(this: v17); /*0x10671255c*/
    if ( v18 != 0 ) /*0x106712564*/
    {
      v19 = v18; /*0x106712566*/
      isStudioStreamingEnabled = RBX::DataModel::isStudioStreamingEnabled(this: v16); /*0x10671256c*/
      v22 = "false"; /*0x106712578*/
      if ( isStudioStreamingEnabled != 0 ) /*0x106712581*/
        v22 = "true"; /*0x106712581*/
      std::string::basic_string[abi:ne200100]<0>(a1: &v31, a2: v22, a3: v21, a4: "true"); /*0x10671258c*/
      RBX::CrashReportProtocolCore::setAttribute(a1: v19, a2: 171, a3: &v31); /*0x10671259c*/
      if ( (v31.i8[0] & 1) != 0 ) /*0x1067125a5*/
        operator delete(a1: (RBX::Memory *)v32, a2: v23); /*0x1067125ab*/
    }
  }
}

// Address: 0x106712620 | Name: __ZN3RBX7Network16ClientReplicator32streamOutPartJointInstanceHelperERKNS_4GuidEPNS_8BasePartEPNS_13JointInstanceE
RBX::BasePart *__fastcall RBX::Network::ClientReplicator::streamOutPartJointInstanceHelper(
        RBX::Network::ClientReplicator *this,
        const RBX::Guid *a2,
        RBX::BasePart *a3,
        RBX::JointInstance *a4)
{
  RBX::JointInstanceProp *v7; // r12
  RBX::BasePart *result; // rax
  __int64 *v9; // rax
  __int64 v10; // rdi
  __int64 v11; // r15

  v7 = (RBX::JointInstance *)((char *)a4 + 176); /*0x106712634*/
  if ( (RBX::BasePart *)RBX::JointInstanceProp::getPart0(this: (RBX::JointInstance *)((char *)a4 + 176)) == a3 ) /*0x106712646*/
  {
    v9 = (__int64 *)&RBX::JointInstanceProperties::prop_Part0; /*0x10671265e*/
  }
  else
  {
    result = (RBX::BasePart *)RBX::JointInstanceProp::getPart1(this: v7); /*0x10671264b*/
    if ( result != a3 ) /*0x106712653*/
      return result; /*0x106712653*/
    v9 = (__int64 *)&RBX::JointInstanceProperties::prop_Part1; /*0x106712655*/
  }
  v10 = *v9; /*0x106712665*/
  v11 = *((_QWORD *)this + 181); /*0x106712668*/
  *((_QWORD *)this + 181) = a4; /*0x10671266f*/
  result = (RBX::BasePart *)(*(__int64 (__fastcall **)(__int64, RBX::JointInstance *, _QWORD))(*(_QWORD *)v10 + 272LL))( /*0x10671267e*/
                              a1: v10,
                              a2: a4,
                              a3: 0);
  *((_QWORD *)this + 181) = v11; /*0x106712684*/
  return result; /*0x10671268b*/
}

// Address: 0x1067126a4 | Name: __ZN3RBX7Network16ClientReplicator33streamOutPartWeldConstraintHelperERKNS_4GuidEPNS_8BasePartEPNS_11Constraints14WeldConstraintE
RBX::BasePart *__fastcall RBX::Network::ClientReplicator::streamOutPartWeldConstraintHelper(
        RBX::Network::ClientReplicator *this,
        const RBX::Guid *a2,
        RBX::BasePart *a3,
        RBX::Constraints::WeldConstraint *a4)
{
  RBX::Constraints::WeldConstraintProp *v7; // r12
  RBX::BasePart *result; // rax
  __int64 *v9; // rax
  __int64 v10; // rdi
  __int64 v11; // r15

  v7 = (RBX::Constraints::WeldConstraint *)((char *)a4 + 176); /*0x1067126b8*/
  if ( (RBX::BasePart *)RBX::Constraints::WeldConstraintProp::getPart0(this: (RBX::Constraints::WeldConstraint *)((char *)a4 + 176)) == a3 ) /*0x1067126ca*/
  {
    v9 = (__int64 *)&RBX::Constraints::WeldConstraintProperties::prop_Part0Internal; /*0x1067126e2*/
  }
  else
  {
    result = (RBX::BasePart *)RBX::Constraints::WeldConstraintProp::getPart1(this: v7); /*0x1067126cf*/
    if ( result != a3 ) /*0x1067126d7*/
      return result; /*0x1067126d7*/
    v9 = (__int64 *)&RBX::Constraints::WeldConstraintProperties::prop_Part1Internal; /*0x1067126d9*/
  }
  v10 = *v9; /*0x1067126e9*/
  v11 = *((_QWORD *)this + 181); /*0x1067126ec*/
  *((_QWORD *)this + 181) = a4; /*0x1067126f3*/
  result = (RBX::BasePart *)(*(__int64 (__fastcall **)(__int64, RBX::Constraints::WeldConstraint *, _QWORD))(*(_QWORD *)v10 + 272LL))( /*0x106712702*/
                              a1: v10,
                              a2: a4,
                              a3: 0);
  *((_QWORD *)this + 181) = v11; /*0x106712708*/
  return result; /*0x10671270f*/
}

// Address: 0x106712728 | Name: __ZN3RBX7Network16ClientReplicator29streamOutPartConstraintHelperERKNS_4GuidEPNS_8BasePartEPNS_11Constraints10ConstraintE
RBX::Attachment *__fastcall RBX::Network::ClientReplicator::streamOutPartConstraintHelper(
        RBX::Network::ClientReplicator *this,
        const RBX::Guid *a2,
        RBX::BasePart *a3,
        RBX::Constraints::Constraint *a4)
{
  RBX::Constraints::ConstraintProp *v7; // r12
  RBX::Attachment *Attachment0; // rax
  RBX::Attachment *result; // rax
  __int64 *v10; // rax
  __int64 v11; // r15
  __int64 v12; // r13
  __int64 v13; // r12

  v7 = (RBX::Constraints::Constraint *)((char *)a4 + 176); /*0x10671273f*/
  Attachment0 = (RBX::Attachment *)RBX::Constraints::ConstraintProp::getAttachment0(this: (RBX::Constraints::Constraint *)((char *)a4 + 176)); /*0x106712749*/
  if ( Attachment0 != nullptr && (RBX::BasePart *)RBX::Attachment::findPartAncestor(this: Attachment0) == a3 ) /*0x10671275e*/
  {
    v10 = (__int64 *)&RBX::Constraints::ConstraintProperties::prop_Attachment0; /*0x106712787*/
    goto LABEL_7; /*0x106712787*/
  }
  result = (RBX::Attachment *)RBX::Constraints::ConstraintProp::getAttachment1(this: v7); /*0x106712763*/
  if ( result != nullptr ) /*0x10671276b*/
  {
    result = (RBX::Attachment *)RBX::Attachment::findPartAncestor(this: result); /*0x106712774*/
    if ( result == a3 ) /*0x10671277c*/
    {
      v10 = (__int64 *)&RBX::Constraints::ConstraintProperties::prop_Attachment1; /*0x10671277e*/
LABEL_7:
      v11 = *v10; /*0x10671278e*/
      v12 = *((_QWORD *)this + 181); /*0x106712791*/
      *((_QWORD *)this + 181) = a4; /*0x106712798*/
      v13 = (*(__int64 (__fastcall **)(__int64, RBX::Constraints::Constraint *))(*(_QWORD *)v11 + 264LL))( /*0x1067127ae*/
              a1: v11,
              a2: a4);
      (*(void (__fastcall **)(RBX::Network::ClientReplicator *, _QWORD, __int64))(*(_QWORD *)this + 864LL))( /*0x1067127c0*/
        a1: this,
        a2: *(_QWORD *)(v13 + 48),
        a3: 1);
      (*(void (__fastcall **)(__int64, RBX::Constraints::Constraint *, _QWORD))(*(_QWORD *)v11 + 272LL))( /*0x1067127d1*/
        a1: v11,
        a2: a4,
        a3: 0);
      result = (RBX::Attachment *)(*(__int64 (__fastcall **)(RBX::Network::ClientReplicator *, _QWORD, _QWORD))(*(_QWORD *)this + 864LL))( /*0x1067127e4*/
                                    a1: this,
                                    a2: *(_QWORD *)(v13 + 48),
                                    a3: 0);
      *((_QWORD *)this + 181) = v12; /*0x1067127ea*/
    }
  }
  return result; /*0x1067127f5*/
}

// Address: 0x106712810 | Name: __ZN3RBX7Network16ClientReplicator24streamOutAutoJointHelperERKNSt3__16vectorINS2_10shared_ptrINS_8BasePartEEENS2_9allocatorIS6_EEEERKNS4_INS_8InstanceEEE
void __fastcall RBX::Network::ClientReplicator::streamOutAutoJointHelper(
        _QWORD *a1,
        __int64 **a2,
        __int64 *a3,
        __int64 a4)
{
  __int64 v4; // rbx
  __int64 v7; // r14
  __int64 v8; // rax
  _QWORD *v9; // r12
  __int64 *v10; // r14
  __int64 *v11; // r15
  __int64 v12; // rax
  __int64 v13; // rcx
  _UNKNOWN **v14; // rdx
  _QWORD *v15; // rdi
  _QWORD *v16; // r12
  __int64 v17; // r13
  __int64 v18; // rax
  _QWORD *v19; // rdi
  __int128 v20; // [rsp+8h] [rbp-48h]
  __int64 v21; // [rsp+18h] [rbp-38h]
  _QWORD *v22; // [rsp+20h] [rbp-30h]

  v4 = *a3; /*0x106712821*/
  if ( *a3 != 0 ) /*0x106712827*/
  {
    v7 = *(_QWORD *)(v4 + 24); /*0x106712833*/
    v8 = RBX::Reflection::Class_getDescriptorPtr<RBX::JointInstance>(a1, a2, a3, a4); /*0x106712837*/
    if ( *(unsigned __int16 *)(v7 + 440) - (unsigned int)*(unsigned __int16 *)(v8 + 440) <= *(unsigned __int16 *)(v8 + 442) ) /*0x106712856*/
    {
      v22 = a1; /*0x10671285c*/
      v9 = a1; /*0x106712875*/
      *(_QWORD *)&v20 = RBX::JointInstanceProp::getPart0(this: (RBX::JointInstanceProp *)(v4 + 176)); /*0x10671287e*/
      *((_QWORD *)&v20 + 1) = RBX::JointInstanceProp::getPart1(this: (RBX::JointInstanceProp *)(v4 + 176)); /*0x106712882*/
      if ( v20 != 0 ) /*0x106712889*/
      {
        v10 = *a2; /*0x10671288f*/
        v11 = a2[1]; /*0x106712893*/
        while ( v10 != v11 ) /*0x10671289a*/
        {
          v12 = *v10; /*0x1067128a0*/
          if ( *v10 != 0 ) /*0x1067128a6*/
          {
            v13 = v20; /*0x1067128b0*/
            v14 = &RBX::JointInstanceProperties::prop_Part0; /*0x1067128b3*/
            if ( (_QWORD)v20 == v12 /*0x1067128d0*/
              || (v13 = *((_QWORD *)&v20 + 1),
                  v14 = &RBX::JointInstanceProperties::prop_Part1,
                  *((_QWORD *)&v20 + 1) == v12) )
            {
              v15 = v9; /*0x1067128d2*/
              v16 = *v14; /*0x1067128d5*/
              v17 = *(_QWORD *)(v13 + 48); /*0x1067128d8*/
              v21 = v15[181]; /*0x1067128e3*/
              v15[181] = v4; /*0x1067128e7*/
              (*(void (__fastcall **)(_QWORD *, __int64, __int64))(*v15 + 864LL))(a1: v15, a2: v17, a3: 1); /*0x1067128f9*/
              v18 = *v16; /*0x1067128ff*/
              v19 = v16; /*0x106712903*/
              v9 = v22; /*0x10671290b*/
              (*(void (__fastcall **)(_QWORD *, __int64, _QWORD))(v18 + 272))(a1: v19, a2: v4, a3: 0); /*0x10671290f*/
              (*(void (__fastcall **)(_QWORD *, __int64, _QWORD))(*v9 + 864LL))(a1: v9, a2: v17, a3: 0); /*0x106712921*/
              v22[181] = v21; /*0x10671292b*/
            }
          }
          v10 += 2; /*0x106712933*/
        }
      }
    }
  }
}

// Address: 0x106712984 | Name: __ZNK3RBX7Network16ClientReplicator22containsHighLODTerrainERKNS_12StreamRegion2IdE
__int64 __fastcall RBX::Network::ClientReplicator::containsHighLODTerrain(
        RBX::Network::ClientReplicator *this,
        const RBX::StreamRegion::Id *a2)
{
  return (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)(*((_QWORD *)this + 1570) + 568LL) + 152LL))(a1: *(_QWORD *)(*((_QWORD *)this + 1570) + 568LL)); /*0x1067129e3*/
}

// Address: 0x1067129ea | Name: __ZN3RBX7Network16ClientReplicator16streamOutTerrainERKNS_12StreamRegion2IdENS_6Voxel214FragmentGcModeE
void __fastcall RBX::Network::ClientReplicator::streamOutTerrain(RBX::Network::Replicator *this, _DWORD *a2, int a3)
{
  __int64 v4; // r12
  int v5; // r15d
  int v6; // r13d
  __int64 v7; // rdi
  char v8; // cl
  __int64 v9; // r14
  unsigned __int8 IsHLODTerrainGridEnabled; // al
  _QWORD v11[3]; // [rsp+0h] [rbp-70h] BYREF
  __int64 v12; // [rsp+18h] [rbp-58h] BYREF
  int v13; // [rsp+20h] [rbp-50h]
  __int64 v14; // [rsp+24h] [rbp-4Ch]
  int v15; // [rsp+2Ch] [rbp-44h]
  __int64 v16; // [rsp+30h] [rbp-40h]
  int v17; // [rsp+3Ch] [rbp-34h]
  int v18; // [rsp+40h] [rbp-30h]
  char v19; // [rsp+47h] [rbp-29h]

  if ( *((_QWORD *)this + 1570) != 0 ) /*0x106712a03*/
  {
    v17 = a3; /*0x106712a0c*/
    v19 = *((_BYTE *)this + 14401); /*0x106712a15*/
    *((_BYTE *)this + 14401) = 1; /*0x106712a18*/
    v4 = (unsigned int)(16 * *a2); /*0x106712a25*/
    v5 = 16 * a2[1]; /*0x106712a2c*/
    v6 = 16 * a2[2]; /*0x106712a34*/
    v12 = v4 + ((unsigned __int64)(unsigned int)a2[1] << 36); /*0x106712a3f*/
    v13 = v6; /*0x106712a43*/
    v16 = (unsigned int)(v4 + 16); /*0x106712a5b*/
    v14 = v16 + ((unsigned __int64)(unsigned int)(v5 + 16) << 32); /*0x106712a62*/
    v18 = v6 + 16; /*0x106712a66*/
    v15 = v6 + 16; /*0x106712a69*/
    if ( (unsigned __int8)RBX::Network::Replicator::isTerrainGridNew(this) != 0 /*0x106712a93*/
      && FFlag::DebugDisableVoxelGridPaletteCompression == 0
      && (unsigned __int8)RBX::Network::Replicator::getIsHLODTerrainGridEnabled(this) != 0 )
    {
      v7 = *(_QWORD *)(*((_QWORD *)this + 1570) + 568LL); /*0x106712a9c*/
      v8 = 0; /*0x106712aaa*/
      if ( FFlag::VoxelGridLeanDM != 0 ) /*0x106712aaf*/
        v8 = FInt::TerrainFinestWriteLevel; /*0x106712ab8*/
      v11[0] = ((unsigned __int64)(unsigned int)(v5 << v8) << 32) | (unsigned int)((_DWORD)v4 << v8); /*0x106712ae3*/
      LODWORD(v11[1]) = v6 << v8; /*0x106712ae6*/
      *(_QWORD *)((char *)&v11[1] + 4) = ((unsigned __int64)(unsigned int)((v5 + 16) << v8) << 32) /*0x106712aea*/
                                       | (unsigned int)((_DWORD)v16 << v8);
      HIDWORD(v11[2]) = v18 << v8; /*0x106712aee*/
      ((void (__fastcall *)(__int64, _QWORD *, __int64, _QWORD, _QWORD))RBX::Voxel2::Grid_NEW::eraseHigherResolutionAndFragment)( /*0x106712b02*/
        a1: v7,
        a2: v11,
        a3: 1,
        a4: (unsigned __int8)FFlag::StudioFixStreamingTerrainDelete,
        a5: (unsigned __int8)v17);
    }
    else
    {
      v9 = *(_QWORD *)(*((_QWORD *)this + 1570) + 568LL); /*0x106712b10*/
      IsHLODTerrainGridEnabled = RBX::Network::Replicator::getIsHLODTerrainGridEnabled(this); /*0x106712b1a*/
      (*(void (__fastcall **)(__int64, __int64 *, _QWORD, _QWORD))(*(_QWORD *)v9 + 144LL))( /*0x106712b3c*/
        a1: v9,
        a2: &v12,
        a3: 2 * (IsHLODTerrainGridEnabled ^ 1u) + 1,
        a4: (unsigned __int8)FFlag::StudioFixStreamingTerrainDelete);
    }
    RBX::TotalCountTimeInterval<int,(RBX::Time::SampleMethod)1>::increment(a1: (char *)this + 22872, a2: 1); /*0x106712b4e*/
    *((_BYTE *)this + 14401) = v19; /*0x106712b56*/
  }
}

// Address: 0x106712c72 | Name: __ZN3RBX7Network16ClientReplicator12getTunableIdEv
__int64 __fastcall RBX::Network::ClientReplicator::getTunableId(RBX::Network::ClientReplicator *this)
{
  RBX::Network::ClientReplicator::GCJob *v1; // rdi

  v1 = *((RBX::Network::ClientReplicator::GCJob **)this + 2753); /*0x106712c72*/
  if ( v1 != nullptr ) /*0x106712c7c*/
    return RBX::Network::ClientReplicator::GCJob::getTunableId(this: v1) & 0xFFFFFFFFFFLL; /*0x106712c94*/
  else
    return 0; /*0x106712c99*/
}

// Address: 0x106712c9c | Name: __ZN3RBX7Network16ClientReplicator20overrideTunableValueEi
__int64 __fastcall RBX::Network::ClientReplicator::overrideTunableValue(RBX::Network::ClientReplicator *this, int a2)
{
  RBX::Network::ClientReplicator::GCJob *v2; // rdi
  __int64 result; // rax

  v2 = *((RBX::Network::ClientReplicator::GCJob **)this + 2753); /*0x106712ca0*/
  if ( v2 != nullptr ) /*0x106712caa*/
    return RBX::Network::ClientReplicator::GCJob::overrideTunableValue(this: v2, a2); /*0x106712cad*/
  return result; /*0x106712cac*/
}

// Address: 0x106712cb4 | Name: __ZNK3RBX7Network16ClientReplicator13getGCDistanceEv
int __fastcall RBX::Network::ClientReplicator::getGCDistance(RBX::Network::ClientReplicator *this)
{
  __int64 v1; // rax

  v1 = *((_QWORD *)this + 2753); /*0x106712cb4*/
  if ( v1 != 0 ) /*0x106712cbe*/
    LOWORD(v1) = *(_WORD *)(v1 + 820); /*0x106712cc4*/
  else
    LOWORD(v1) = 0; /*0x106712cce*/
  LODWORD(v1) = (__int16)v1; /*0x106712cd0*/
  return v1; /*0x106712cd1*/
}

// Address: 0x106712cd2 | Name: __ZNK3RBX7Network16ClientReplicator13isStreamedOutENSt3__110shared_ptrINS_8InstanceEEE
char __fastcall RBX::Network::ClientReplicator::isStreamedOut(
        __m128 a1,
        __m128 a2,
        __m128 a3,
        __m128 a4,
        __m128 a5,
        __m128 a6,
        __m128 a7,
        __m128 a8,
        __int64 a9,
        const char *a10,
        __int64 a11,
        __int64 a12,
        __int64 a13,
        __int64 a14)
{
  char v14; // bp

  if ( FFlag::DifferentiateStreamedOut == 0 ) /*0x106712cdc*/
    RBX::throw_runtime_error( /*0x106712cf3*/
      this: (RBX *)"FFlagDifferentiateStreamedOut is not enabled",
      a2: a10,
      a3: a11,
      a4: a12,
      a5: a13,
      a6: a14,
      a7: a1,
      a8: a2,
      a9: a3,
      a10: a4,
      a11: a5,
      a12: a6,
      a13: a7,
      a14: a8,
      a15: v14);
  return RBX::isStreamedOutOnOurClient(this: *(RBX **)a10, a2: (const RBX::Instance *)a10);
}

// Address: 0x106712cf8 | Name: __ZN3RBX7Network16ClientReplicator22replicatorOnChildAddedERKNSt3__110shared_ptrINS_8InstanceEEE
__int64 __fastcall RBX::Network::ClientReplicator::replicatorOnChildAdded(
        RBX::Network::Replicator *a1,
        const RBX::Object **a2)
{
  __int64 v4; // rdx
  __int64 v5; // rsi
  const RBX::Object *v6; // r15
  std::__shared_weak_count *v7; // r15
  __int64 v8; // rax
  RBX::Network::InstanceObjectManager *v9; // rdi
  std::__shared_weak_count *v11[2]; // [rsp+0h] [rbp-80h] BYREF
  const RBX::Object *v12; // [rsp+10h] [rbp-70h] BYREF
  char v13; // [rsp+1Fh] [rbp-61h] BYREF
  _QWORD v14[4]; // [rsp+20h] [rbp-60h] BYREF
  _QWORD *v15; // [rsp+40h] [rbp-40h]

  v13 = RBX::Network::Replicator::isReplicationContainer(this: a1, a2: *a2) ^ 1; /*0x106712d27*/
  if ( v13 != 0 ) /*0x106712d2a*/
    return __stack_chk_guard; /*0x106712d2a*/
  v6 = *a2; /*0x106712d30*/
  v14[0] = off_10CAA8C18; /*0x106712d3e*/
  v14[1] = a1; /*0x106712d42*/
  v14[2] = &v13; /*0x106712d4a*/
  v15 = v14; /*0x106712d4e*/
  do /*0x106712d7b*/
  {
    v6 = *((const RBX::Object **)v6 + 13); /*0x106712d56*/
    if ( v6 == nullptr ) /*0x106712d5d*/
    {
      *(_OWORD *)v11 = 0; /*0x106712dba*/
      goto LABEL_10; /*0x106712dba*/
    }
    v12 = v6; /*0x106712d5f*/
    if ( v15 == nullptr ) /*0x106712d6a*/
      std::__throw_bad_function_call[abi:ne200100](a1: 0); /*0x106712e17*/
  }
  while ( (*(unsigned __int8 (__fastcall **)(_QWORD *, const RBX::Object **))(*v15 + 48LL))(a1: v15, a2: &v12) == 0 ); /*0x106712d7b*/
  RBX::shared_from<RBX::Instance>(a1: v11, a2: (__int64)v6); /*0x106712d84*/
  v7 = v11[1]; /*0x106712d89*/
  if ( v11[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v11[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106712da2*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(a1: v7); /*0x106712daa*/
    std::__shared_weak_count::__release_weak(this: v7); /*0x106712db0*/
  }
LABEL_10:
  if ( v15 == v14 ) /*0x106712dc5*/
  {
    v8 = 32; /*0x106712dd3*/
  }
  else
  {
    v8 = 40; /*0x106712dc7*/
    if ( v15 == nullptr ) /*0x106712dcf*/
      goto LABEL_15; /*0x106712dcf*/
  }
  (*(void (__fastcall **)(_QWORD *, __int64, __int64))(*v15 + v8))(a1: v15, a2: v5, a3: v4); /*0x106712ddb*/
LABEL_15:
  if ( (v13 & 1) == 0 ) /*0x106712de2*/
  {
    v9 = *((RBX::Network::InstanceObjectManager **)a1 + 2757); /*0x106712de4*/
    if ( v9 != nullptr ) /*0x106712dee*/
      RBX::Network::InstanceObjectManager::onChildAdded(this: v9); /*0x106712df3*/
  }
  return __stack_chk_guard; /*0x106712e08*/
}

// Address: 0x106712e54 | Name: __ZN3RBX7Network16ClientReplicator24replicatorOnChildRemovedERKNSt3__110shared_ptrINS_8InstanceEEES7_
__int64 __fastcall RBX::Network::ClientReplicator::replicatorOnChildRemoved(__int64 a1)
{
  RBX::Network::InstanceObjectManager *v1; // rdi
  __int64 result; // rax

  v1 = *(RBX::Network::InstanceObjectManager **)(a1 + 22056); /*0x106712e58*/
  if ( v1 != nullptr ) /*0x106712e62*/
    return RBX::Network::InstanceObjectManager::onChildRemoved(this: v1); /*0x106712e65*/
  return result; /*0x106712e64*/
}

// Address: 0x106712e6c | Name: __ZN3RBX7Network16ClientReplicator22updateReplicatedParentEPNS_8InstanceES3_S3_b
RBX::Instance *__fastcall RBX::Network::ClientReplicator::updateReplicatedParent(
        RBX::Network::ClientReplicator *this,
        RBX::Instance *a2,
        RBX::Instance *a3,
        RBX::Instance *a4,
        unsigned __int8 a5)
{
  RBX::Instance *result; // rax
  char *v8; // rbx
  unsigned __int64 v9; // rax
  __int64 v10; // r15
  RBX::Instance **v11; // [rsp+8h] [rbp-38h] BYREF
  RBX::Instance *v12; // [rsp+10h] [rbp-30h] BYREF
  _BYTE v13[33]; // [rsp+1Fh] [rbp-21h] BYREF

  v12 = a2; /*0x106712e82*/
  if ( ((a5 ^ 1) & (a3 != nullptr)) == 0 ) /*0x106712e8f*/
    return (RBX::Instance *)RBX::Network::ClientReplicator::resetReplicatedParentDataForInstance(this, a2); /*0x106712ea0*/
  v8 = (char *)this + 24392; /*0x106712eab*/
  result = (RBX::Instance *)std::__hash_table<std::__hash_value_type<RBX::Instance const*,RBX::Guid>,std::__unordered_map_hasher<RBX::Instance const*,std::__hash_value_type<RBX::Instance const*,RBX::Guid>,std::hash<RBX::Instance const*>,std::equal_to<RBX::Instance const*>,true>,std::__unordered_map_equal<RBX::Instance const*,std::__hash_value_type<RBX::Instance const*,RBX::Guid>,std::equal_to<RBX::Instance const*>,std::hash<RBX::Instance const*>,true>,std::allocator<std::__hash_value_type<RBX::Instance const*,RBX::Guid>>>::find<RBX::Instance const*>( /*0x106712ebc*/
                              a1: (char *)this + 24392,
                              a2: &v12);
  if ( result != nullptr ) /*0x106712ec4*/
  {
    if ( *((_QWORD *)result + 3) == *((_QWORD *)a3 + 6) ) /*0x106712ed5*/
    {
      std::__hash_table<std::__hash_value_type<RBX::Instance const*,RBX::Guid>,std::__unordered_map_hasher<RBX::Instance const*,std::__hash_value_type<RBX::Instance const*,RBX::Guid>,std::hash<RBX::Instance const*>,std::equal_to<RBX::Instance const*>,true>,std::__unordered_map_equal<RBX::Instance const*,std::__hash_value_type<RBX::Instance const*,RBX::Guid>,std::equal_to<RBX::Instance const*>,std::hash<RBX::Instance const*>,true>,std::allocator<std::__hash_value_type<RBX::Instance const*,RBX::Guid>>>::erase( /*0x106712ee2*/
        a1: v8,
        a2: result);
      result = v12; /*0x106712ee7*/
      *((_DWORD *)v12 + 36) &= ~0x40000000u; /*0x106712eeb*/
    }
  }
  else
  {
    if ( a4 != nullptr ) /*0x106712efa*/
    {
      v9 = *((_QWORD *)a4 + 6) & 0xFFFFFFFF00000000LL; /*0x106712f0a*/
      v10 = (unsigned int)*((_QWORD *)a4 + 6); /*0x106712f0d*/
    }
    else
    {
      v10 = 0xFFFFFFFFLL; /*0x106712f12*/
      v9 = 0; /*0x106712f18*/
    }
    v11 = &v12; /*0x106712f21*/
    *(_QWORD *)(std::__hash_table<std::__hash_value_type<RBX::Instance const*,RBX::Guid>,std::__unordered_map_hasher<RBX::Instance const*,std::__hash_value_type<RBX::Instance const*,RBX::Guid>,std::hash<RBX::Instance const*>,std::equal_to<RBX::Instance const*>,true>,std::__unordered_map_equal<RBX::Instance const*,std::__hash_value_type<RBX::Instance const*,RBX::Guid>,std::equal_to<RBX::Instance const*>,std::hash<RBX::Instance const*>,true>,std::allocator<std::__hash_value_type<RBX::Instance const*,RBX::Guid>>>::__emplace_unique_key_args<RBX::Instance const*,std::piecewise_construct_t const&,std::tuple<RBX::Instance const* const&>,std::tuple<>>( /*0x106712f3a*/
                  a1: v8,
                  a2: &v12,
                  a3: std::piecewise_construct,
                  a4: &v11,
                  a5: v13)
              + 24) = v9 | v10;
    result = v12; /*0x106712f3e*/
    *((_DWORD *)v12 + 36) |= 0x40000000u; /*0x106712f42*/
  }
  return result; /*0x106712e94*/
}

// Address: 0x106712f5a | Name: __ZN3RBX7Network16ClientReplicator36resetReplicatedParentDataForInstanceEPNS_8InstanceE
void __fastcall RBX::Network::ClientReplicator::resetReplicatedParentDataForInstance(
        RBX::Network::ClientReplicator *this,
        RBX::Instance *a2)
{
  char *v2; // rbx
  __int64 v3; // rax
  RBX::Instance *v4; // [rsp+0h] [rbp-10h] BYREF

  v4 = a2; /*0x106712f60*/
  if ( (*((_BYTE *)a2 + 147) & 0x40) != 0 ) /*0x106712f6b*/
  {
    v2 = (char *)this + 24392; /*0x106712f70*/
    v3 = std::__hash_table<std::__hash_value_type<RBX::Instance const*,RBX::Guid>,std::__unordered_map_hasher<RBX::Instance const*,std::__hash_value_type<RBX::Instance const*,RBX::Guid>,std::hash<RBX::Instance const*>,std::equal_to<RBX::Instance const*>,true>,std::__unordered_map_equal<RBX::Instance const*,std::__hash_value_type<RBX::Instance const*,RBX::Guid>,std::equal_to<RBX::Instance const*>,std::hash<RBX::Instance const*>,true>,std::allocator<std::__hash_value_type<RBX::Instance const*,RBX::Guid>>>::find<RBX::Instance const*>( /*0x106712f7e*/
           a1: (char *)this + 24392,
           a2: &v4);
    if ( v3 != 0 ) /*0x106712f86*/
      std::__hash_table<std::__hash_value_type<RBX::Instance const*,RBX::Guid>,std::__unordered_map_hasher<RBX::Instance const*,std::__hash_value_type<RBX::Instance const*,RBX::Guid>,std::hash<RBX::Instance const*>,std::equal_to<RBX::Instance const*>,true>,std::__unordered_map_equal<RBX::Instance const*,std::__hash_value_type<RBX::Instance const*,RBX::Guid>,std::equal_to<RBX::Instance const*>,std::hash<RBX::Instance const*>,true>,std::allocator<std::__hash_value_type<RBX::Instance const*,RBX::Guid>>>::erase( /*0x106712f8e*/
        a1: v2,
        a2: v3);
    *((_DWORD *)v4 + 36) &= ~0x40000000u; /*0x106712f97*/
  }
}

// Address: 0x106712fa8 | Name: __ZNK3RBX7Network16ClientReplicator19getReplicatedParentEPNS_8InstanceE
__int64 __fastcall RBX::Network::ClientReplicator::getReplicatedParent(
        RBX::Network::ClientReplicator *this,
        RBX::Instance *a2)
{
  RBX::Instance *v3; // rdi
  __int64 v4; // rbx
  __int64 v5; // r14
  __int64 v6; // rax
  std::__shared_weak_count *v8; // r14
  __int64 v9; // [rsp+8h] [rbp-28h] BYREF
  std::__shared_weak_count *v10; // [rsp+10h] [rbp-20h]
  RBX::Instance *v11; // [rsp+18h] [rbp-18h] BYREF

  v11 = a2; /*0x106712fb3*/
  if ( (*((_BYTE *)a2 + 147) & 0x40) == 0 ) /*0x106712fbe*/
    return *((_QWORD *)a2 + 13); /*0x106712fbe*/
  if ( std::__hash_table<std::__hash_value_type<RBX::Instance const*,RBX::Guid>,std::__unordered_map_hasher<RBX::Instance const*,std::__hash_value_type<RBX::Instance const*,RBX::Guid>,std::hash<RBX::Instance const*>,std::equal_to<RBX::Instance const*>,true>,std::__unordered_map_equal<RBX::Instance const*,std::__hash_value_type<RBX::Instance const*,RBX::Guid>,std::equal_to<RBX::Instance const*>,std::hash<RBX::Instance const*>,true>,std::allocator<std::__hash_value_type<RBX::Instance const*,RBX::Guid>>>::find<RBX::Instance const*>( /*0x106712fd6*/
         a1: (char *)this + 24392,
         a2: &v11) == 0 )
  {
    a2 = v11; /*0x106713025*/
    return *((_QWORD *)a2 + 13); /*0x106713029*/
  }
  RBX::GuidItem<RBX::Object>::Registry::getByGuid(a1: &v9, a2: *((_QWORD *)this + 22)); /*0x106712fed*/
  v4 = v9; /*0x106712ff2*/
  if ( v9 != 0 ) /*0x106712ff8*/
  {
    v5 = *(_QWORD *)(v9 + 24); /*0x106712ffa*/
    v6 = RBX::Instance::classDescriptor(this: v3); /*0x106712ffe*/
    if ( *(unsigned __int16 *)(v5 + 440) - (unsigned int)*(unsigned __int16 *)(v6 + 440) > *(unsigned __int16 *)(v6 + 442) ) /*0x10671301f*/
      v4 = 0; /*0x10671301f*/
  }
  else
  {
    v4 = 0; /*0x106713039*/
  }
  v8 = v10; /*0x10671303b*/
  if ( v10 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v10 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106713054*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(a1: v8); /*0x10671305c*/
    std::__shared_weak_count::__release_weak(this: v8); /*0x106713062*/
  }
  return v4; /*0x106713030*/
}

// Address: 0x10671307e | Name: __ZN3RBX7Network16ClientReplicator30completenessHandleParentChangeEPNS_8InstanceES3_S3_
__int64 __fastcall RBX::Network::ClientReplicator::completenessHandleParentChange(
        RBX::Network::MegaReplicator **this,
        RBX::Instance *a2,
        RBX::Instance *a3,
        RBX::Instance *a4)
{
  __int64 result; // rax
  int v9; // r8d

  result = *((unsigned int *)a2 + 36); /*0x106713099*/
  if ( (result & 0x40000000) != 0 ) /*0x1067130a3*/
  {
    a3 = (RBX::Instance *)(*((__int64 (__fastcall **)(RBX::Network::MegaReplicator **, RBX::Instance *))*this + 113))( /*0x1067130b4*/
                            a1: this,
                            a2);
    result = *((unsigned int *)a2 + 36); /*0x1067130b7*/
  }
  if ( a4 == nullptr || (int)result < 0 ) /*0x1067130c4*/
  {
    result = RBX::Network::MegaReplicator::completenessClientChildRemoved(this: *(this + 1801), a2, a3); /*0x1067130d3*/
    if ( a4 == nullptr ) /*0x1067130db*/
      result = RBX::Instance::visitDescendants<RBX::Network::ClientReplicator::completenessHandleParentChange(RBX::Instance*,RBX::Instance*,RBX::Instance*)::$_0>(a1: a2); /*0x1067130e7*/
  }
  v9 = *((_DWORD *)a2 + 36); /*0x1067130ec*/
  if ( (v9 & 0x20000000) != 0 ) /*0x1067130f8*/
  {
    result = (__int64)RBX::Network::ClientReplicator::updateReplicatedParent( /*0x10671310a*/
                        (RBX::Network::ClientReplicator *)this,
                        a2,
                        a3: a4,
                        a4: a3,
                        a5: v9 < 0);
    v9 = *((_DWORD *)a2 + 36); /*0x10671310f*/
  }
  if ( v9 < 0 ) /*0x106713119*/
  {
    result = RBX::Network::MegaReplicator::completenessClientChildAdded(this: *(this + 1801), a2, a3: a4); /*0x106713128*/
    v9 = *((_DWORD *)a2 + 36); /*0x10671312d*/
  }
  *((_DWORD *)a2 + 36) = v9 & 0x7FFFFFFF; /*0x10671313b*/
  return result; /*0x106713142*/
}

// Address: 0x1067132a8 | Name: __ZN3RBX7Network16ClientReplicator24recordRegionRemovalStatsEjj
__int64 __fastcall RBX::Network::ClientReplicator::recordRegionRemovalStats(
        RBX::Network::ClientReplicator *this,
        unsigned int a2,
        int a3)
{
  __int64 result; // rax

  result = *((unsigned int *)this + 5888); /*0x1067132ac*/
  if ( (unsigned int)result > a2 ) /*0x1067132b4*/
    a2 = *((_DWORD *)this + 5888); /*0x1067132b4*/
  *((_DWORD *)this + 5888) = a2; /*0x1067132b7*/
  ++*((_DWORD *)this + 5887); /*0x1067132bd*/
  *((_DWORD *)this + 5869) += a3; /*0x1067132c3*/
  return result; /*0x1067132c9*/
}

// Address: 0x1067132cc | Name: __ZNK3RBX7Network16ClientReplicator21getNumStreamedRegionsEv
__int64 __fastcall RBX::Network::ClientReplicator::getNumStreamedRegions(RBX::Network::ClientReplicator *this)
{
  RBX::Network::ClientReplicator::GCJob *v1; // rdi

  v1 = *((RBX::Network::ClientReplicator::GCJob **)this + 2753); /*0x1067132d0*/
  if ( v1 != nullptr ) /*0x1067132da*/
    return RBX::Network::ClientReplicator::GCJob::getNumRegions(this: v1); /*0x1067132dd*/
  else
    return 0; /*0x1067132e2*/
}

// Address: 0x1067132e6 | Name: __ZNK3RBX7Network16ClientReplicator16getNumPrefetchesEv
__int64 __fastcall RBX::Network::ClientReplicator::getNumPrefetches(RBX::Network::ClientReplicator *this)
{
  __int64 v1; // rax

  v1 = *((_QWORD *)this + 2753); /*0x1067132e6*/
  if ( v1 != 0 ) /*0x1067132f0*/
    return *(unsigned int *)(v1 + 1448); /*0x1067132f6*/
  else
    return 0; /*0x1067132fe*/
}

// Address: 0x106713302 | Name: __ZNK3RBX7Network16ClientReplicator21getNumReplicationFociEv
__int64 __fastcall RBX::Network::ClientReplicator::getNumReplicationFoci(RBX::Network::ClientReplicator *this)
{
  __int64 v1; // rax

  v1 = *((_QWORD *)this + 2753); /*0x106713302*/
  if ( v1 != 0 ) /*0x10671330c*/
    return *(unsigned int *)(v1 + 1584); /*0x106713312*/
  else
    return 0; /*0x10671331a*/
}

// Address: 0x10671331e | Name: __ZNK3RBX7Network16ClientReplicator23getTargetPlayerPositionEv
double __fastcall RBX::Network::ClientReplicator::getTargetPlayerPosition(
        RBX::Network::ClientReplicator *this,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6)
{
  RBX::Player *v6; // rax
  __int128 v8; // [rsp+0h] [rbp-40h] BYREF
  double v9; // [rsp+24h] [rbp-1Ch]
  int v10; // [rsp+2Ch] [rbp-14h]

  v9 = 0.0; /*0x10671333e*/
  v10 = 0; /*0x106713346*/
  v6 = (RBX::Player *)(*(__int64 (__fastcall **)(RBX::Network::ClientReplicator *, __int64, __int64, __int64, __int64, __int64, __int64, _QWORD, __int64, _QWORD, __int64))(*(_QWORD *)this + 688LL))( /*0x106713350*/
                        a1: this,
                        a2,
                        a3,
                        a4,
                        a5,
                        a6,
                        a7: 1065353216,
                        a8: 0,
                        a9: 1065353216,
                        a10: 0,
                        a11: 1065353216);
  if ( v6 == nullptr ) /*0x106713359*/
    return 0.0; /*0x106713376*/
  RBX::Player::getReplicationFocusCFrame2(this: v6, a2: (RBX::CoordinateFrame *)&v8); /*0x106713365*/
  return v9; /*0x10671337c*/
}

// Address: 0x106713384 | Name: __ZNK3RBX7Network16ClientReplicator22getOutsideStreamedAreaEv
char __fastcall RBX::Network::ClientReplicator::getOutsideStreamedArea(RBX::Network::ClientReplicator *this)
{
  __int64 v1; // rax

  v1 = *((_QWORD *)this + 2753); /*0x106713384*/
  if ( v1 != 0 ) /*0x10671338e*/
    return *(_BYTE *)(v1 + 536); /*0x106713394*/
  else
    return 0; /*0x10671339c*/
}

// Address: 0x1067133a0 | Name: __ZNK3RBX7Network16ClientReplicator24testHasPendingGCRemovalsEv
__int64 __fastcall RBX::Network::ClientReplicator::testHasPendingGCRemovals(RBX::Network::ClientReplicator *this)
{
  unsigned int v1; // ebx
  __int64 v3; // rax
  RBX::Network::StreamingSolverV2 *v4; // rdi
  RBX::Network::StreamingSolverV2 *v5; // rdi

  v3 = *((_QWORD *)this + 2753); /*0x1067133aa*/
  if ( v3 == 0 || (LOBYTE(v1) = 1, *(_QWORD *)(v3 + 3296) == *(_QWORD *)(v3 + 3304)) ) /*0x1067133c6*/
  {
    v4 = *((RBX::Network::StreamingSolverV2 **)this + 2755); /*0x1067133c8*/
    if ( v4 == nullptr ) /*0x1067133d2*/
      return 0; /*0x1067133d2*/
    LOBYTE(v1) = 1; /*0x1067133d9*/
    if ( (unsigned __int8)RBX::Network::StreamingSolverV2::testHasPendingGCWork(this: v4) == 0 ) /*0x1067133dd*/
    {
      v5 = *((RBX::Network::StreamingSolverV2 **)this + 2755); /*0x1067133df*/
      if ( v5 == nullptr || (unsigned __int8)RBX::Network::StreamingSolverV2::testIsIdle(this: v5) != 0 ) /*0x1067133f2*/
        return 0; /*0x1067133f4*/
    }
  }
  return v1; /*0x1067133f8*/
}

// Address: 0x1067133fe | Name: __ZNK3RBX7Network16ClientReplicator19getGCTargetDistanceERKNS_12StreamRegion2IdE
__int64 __fastcall RBX::Network::ClientReplicator::getGCTargetDistance(
        RBX::Network::ClientReplicator *this,
        const RBX::StreamRegion::Id *a2)
{
  RBX::Network::ClientReplicator::GCJob *v2; // rdi

  v2 = *((RBX::Network::ClientReplicator::GCJob **)this + 2753); /*0x106713402*/
  if ( v2 != nullptr ) /*0x10671340c*/
    return RBX::Network::ClientReplicator::GCJob::getGCTargetDistance(this: v2, a2); /*0x10671340f*/
  else
    return 0; /*0x106713414*/
}

// Address: 0x106713418 | Name: __ZNK3RBX7Network16ClientReplicator26testGetGCMaxRegionDistanceEv
__int64 __fastcall RBX::Network::ClientReplicator::testGetGCMaxRegionDistance(RBX::Network::ClientReplicator *this)
{
  RBX::Network::ClientReplicator::GCJob *v1; // rdi

  v1 = *((RBX::Network::ClientReplicator::GCJob **)this + 2753); /*0x10671341c*/
  if ( v1 != nullptr ) /*0x106713426*/
    return RBX::Network::ClientReplicator::GCJob::getMaxRegionDistance(this: v1); /*0x106713429*/
  else
    return 0; /*0x10671342e*/
}

// Address: 0x106713432 | Name: __ZNK3RBX7Network16ClientReplicator33testGCJobHasRegionsBeyondDistanceERKNS_12StreamRegion2IdEi
__int64 __fastcall RBX::Network::ClientReplicator::testGCJobHasRegionsBeyondDistance(
        RBX::Network::ClientReplicator *this,
        const RBX::StreamRegion::Id *a2,
        int a3)
{
  RBX::Network::ClientReplicator::GCJob *v3; // rdi

  v3 = *((RBX::Network::ClientReplicator::GCJob **)this + 2753); /*0x106713436*/
  if ( v3 != nullptr ) /*0x106713440*/
    return RBX::Network::ClientReplicator::GCJob::testHasRegionsBeyondDistance(this: v3, a2, a3); /*0x106713443*/
  else
    return 0; /*0x106713448*/
}

// Address: 0x10671344c | Name: __ZNK3RBX7Network16ClientReplicator27getServerStreamCenterRegionEv
unsigned __int64 __fastcall RBX::Network::ClientReplicator::getServerStreamCenterRegion(
        RBX::Network::ClientReplicator *this)
{
  RBX::Network::ClientReplicator::GCJob *v1; // rdi
  __int64 LastKnownServerRegionId; // rax
  unsigned __int64 v3; // rax
  __int64 v4; // rcx

  v1 = *((RBX::Network::ClientReplicator::GCJob **)this + 2753); /*0x10671344c*/
  if ( v1 != nullptr ) /*0x106713456*/
  {
    LastKnownServerRegionId = RBX::Network::ClientReplicator::GCJob::getLastKnownServerRegionId(this: v1); /*0x10671345c*/
    LODWORD(v4) = LastKnownServerRegionId; /*0x106713461*/
    v3 = LastKnownServerRegionId & 0xFFFFFFFF00000000LL; /*0x10671346e*/
    v4 = (unsigned int)v4; /*0x106713471*/
  }
  else if ( FFlag::g_flagsLoaded == 1 && DFFlag::StreamRegionInvalidDefaultValue != 0 ) /*0x10671348c*/
  {
    v4 = 0x7FFFFFFF; /*0x10671348e*/
    v3 = 0x7FFFFFFF00000000LL; /*0x106713493*/
  }
  else
  {
    v3 = 0; /*0x1067134a6*/
    v4 = 0; /*0x1067134a8*/
  }
  return v4 | v3; /*0x1067134ad*/
}

// Address: 0x1067134ae | Name: __ZNK3RBX7Network16ClientReplicator24getStreamingPauseEnabledEv
char __fastcall RBX::Network::ClientReplicator::getStreamingPauseEnabled(RBX::Network::ClientReplicator *this)
{
  __int64 v1; // rax

  v1 = *((_QWORD *)this + 2753); /*0x1067134ae*/
  if ( v1 != 0 ) /*0x1067134b8*/
    return *(_BYTE *)(v1 + 541); /*0x1067134be*/
  else
    return 0; /*0x1067134c6*/
}

// Address: 0x1067134ca | Name: __ZNK3RBX7Network16ClientReplicator16getObjectManagerEv
__int64 __fastcall RBX::Network::ClientReplicator::getObjectManager(RBX::Network::ClientReplicator *this)
{
  return *((_QWORD *)this + 2757); /*0x1067134d5*/
}

// Address: 0x1067134d8 | Name: __ZNK3RBX7Network16ClientReplicator20getStreamingSolverV2Ev
__int64 __fastcall RBX::Network::ClientReplicator::getStreamingSolverV2(RBX::Network::ClientReplicator *this)
{
  return *((_QWORD *)this + 2755); /*0x1067134e3*/
}

// Address: 0x1067134e6 | Name: __ZNK3RBX7Network16ClientReplicator33testGetNumMultipleReplicationFociEv
__int64 __fastcall RBX::Network::ClientReplicator::testGetNumMultipleReplicationFoci(
        RBX::Network::ClientReplicator *this)
{
  RBX::Network::ClientReplicator::GCJob *v1; // rdi

  v1 = *((RBX::Network::ClientReplicator::GCJob **)this + 2753); /*0x1067134ea*/
  if ( v1 != nullptr ) /*0x1067134f4*/
    return RBX::Network::ClientReplicator::GCJob::testGetNumMultipleReplicationFoci(this: v1); /*0x1067134f7*/
  else
    return 0; /*0x1067134fc*/
}

// Address: 0x106713500 | Name: __ZNK3RBX7Network16ClientReplicator45testGetMultipleReplicationFociRadiusInRegionsEj
__int64 __fastcall RBX::Network::ClientReplicator::testGetMultipleReplicationFociRadiusInRegions(
        RBX::Network::ClientReplicator *this,
        unsigned int a2)
{
  RBX::Network::ClientReplicator::GCJob *v2; // rdi

  v2 = *((RBX::Network::ClientReplicator::GCJob **)this + 2753); /*0x106713504*/
  if ( v2 != nullptr ) /*0x10671350e*/
    return RBX::Network::ClientReplicator::GCJob::testGetMultipleReplicationFociRadiusInRegions(this: v2, a2); /*0x106713511*/
  else
    return 0; /*0x106713516*/
}

// Address: 0x10671351a | Name: __ZNK3RBX7Network16ClientReplicator25testGetAllFociDebugStringEv
RBX::Network::ClientReplicator *__fastcall RBX::Network::ClientReplicator::testGetAllFociDebugString(
        RBX::Network::ClientReplicator *this,
        __int64 a2,
        __int64 a3,
        __int64 a4)
{
  if ( *(_QWORD *)(a2 + 22024) != 0 ) /*0x10671352d*/
    RBX::Network::ClientReplicator::GCJob::testGetAllFociDebugString(this); /*0x106713532*/
  else
    std::string::basic_string[abi:ne200100]<0>(a1: this, a2: "(no gcJob)", a3, a4); /*0x106713543*/
  return this; /*0x10671354f*/
}

// Address: 0x106713552 | Name: __ZN3RBX7Network16ClientReplicator32debugSetStreamedInstanceCallbackENSt3__18functionIFvRKNS2_10shared_ptrINS_8InstanceEEEEEE
__int64 __fastcall RBX::Network::ClientReplicator::debugSetStreamedInstanceCallback(__int64 a1)
{
  return std::__function::__value_func<void ()(std::shared_ptr<RBX::Instance> const&)>::operator=[abi:ne200100](a1: a1 + 23824); /*0x106713562*/
}

// Address: 0x10671356c | Name: __ZN3RBX7Network16ClientReplicator24isProtectedStringEnabledEv
char __fastcall RBX::Network::ClientReplicator::isProtectedStringEnabled(RBX::Network::ClientReplicator *this)
{
  return 1; /*0x106713572*/
}

// Address: 0x106713574 | Name: __ZN3RBX7Network16ClientReplicator26schemaGetBytecodeForSourceERKNS_15ProtectedStringE
RBX::Network::ClientReplicator *__fastcall RBX::Network::ClientReplicator::schemaGetBytecodeForSource(
        RBX::Network::ClientReplicator *this,
        const RBX::ProtectedString *a2)
{
  RBX::Flyweight<RBX::SharedString::Data,void,true>::Flyweight(a1: this, a2: (char *)a2 + 8); /*0x106713581*/
  return this; /*0x10671358d*/
}

// Address: 0x106713590 | Name: __ZNK3RBX7Network16ClientReplicator25reportProtectedStringHackEv
void __fastcall RBX::Network::ClientReplicator::reportProtectedStringHack(RBX::Network::ClientReplicator *this)
{
  ; /*0x106713590*/
}

// Address: 0x106713596 | Name: __ZN3RBX7Network16ClientReplicator29performUnrelatedSecurityTasksEv
__int64 __fastcall RBX::Network::ClientReplicator::performUnrelatedSecurityTasks(RBX::Network::ClientReplicator *this)
{
  return RBX::Humanoid::checkConstNamesModified(this); /*0x10671359a*/
}

// Address: 0x1067135a0 | Name: __ZN3RBX7Network16ClientReplicator29shouldRateLimitTxRemoteEventsEPKNS_6ObjectERKNS_10Reflection15EventDescriptorERKNSt3__16vectorINS5_7VariantENS9_9allocatorISB_EEEE
__int64 __fastcall RBX::Network::ClientReplicator::shouldRateLimitTxRemoteEvents(
        __int64 a1,
        const RBX::Object *a2,
        const RBX::Reflection::EventDescriptor *a3)
{
  if ( RBX::Network::Replicator::rateLimitChecks(this: (RBX::Network::Replicator *)a1, a2, a3) != 0 ) /*0x1067135b1*/
    RBX::LeakyBucket::checkAdd(this: (RBX::LeakyBucket *)(a1 + 12152), a2: 1.0); /*0x1067135c5*/
  return 0; /*0x1067135d0*/
}

// Address: 0x1067135d4 | Name: __ZNK3RBX7Network16ClientReplicator26testDoesServerSendPropertyERKNS_10Reflection15ClassDescriptorERKNS2_18PropertyDescriptorE
bool __fastcall RBX::Network::ClientReplicator::testDoesServerSendProperty(
        RBX::Network::ClientReplicator *this,
        const RBX::Reflection::ClassDescriptor *a2,
        const RBX::Reflection::PropertyDescriptor *a3)
{
  __int64 v4; // rax
  __int64 v5; // rcx
  unsigned __int64 v6; // rax
  __int64 v7; // rdx
  __int64 v8; // rdi

  v4 = RBX::detail::DenseHashTable<RBX::Reflection::ClassDescriptor const*,std::pair<RBX::Reflection::ClassDescriptor const*,unsigned short>,std::pair<RBX::Reflection::ClassDescriptor const* const,unsigned short>,RBX::detail::ItemInterfaceMap<RBX::Reflection::ClassDescriptor const*,unsigned short>,RBX::Hash<RBX::Reflection::ClassDescriptor const*>,std::equal_to<RBX::Reflection::ClassDescriptor const*>>::find(a1: *((_QWORD *)this + 1560) + 64LL); /*0x1067135fa*/
  if ( v4 == 0 ) /*0x106713602*/
    return false; /*0x10671365d*/
  v5 = *((_QWORD *)this + 1560); /*0x106713604*/
  v6 = *(unsigned __int16 *)(v4 + 8); /*0x10671360b*/
  v7 = *(_QWORD *)(v5 + 184); /*0x10671360f*/
  v8 = 0; /*0x10671363c*/
  if ( 0xD37A6F4DE9BD37A7LL * ((*(_QWORD *)(v5 + 192) - v7) >> 3) > v6 ) /*0x106713641*/
    v8 = v7 + 184 * v6; /*0x106713641*/
  return RBX::detail::DenseHashTable<RBX::Reflection::PropertyDescriptor const*,std::pair<RBX::Reflection::PropertyDescriptor const*,unsigned short>,std::pair<RBX::Reflection::PropertyDescriptor const* const,unsigned short>,RBX::detail::ItemInterfaceMap<RBX::Reflection::PropertyDescriptor const*,unsigned short>,RBX::Hash<RBX::Reflection::PropertyDescriptor const*>,std::equal_to<RBX::Reflection::PropertyDescriptor const*>>::find(a1: v8 + 16) != 0; /*0x10671365f*/
}

// Address: 0x106713668 | Name: __ZN3RBX7Network16ClientReplicator25preserveForwardRefsToGuidENS_4GuidEb
__int64 __fastcall RBX::Network::ClientReplicator::preserveForwardRefsToGuid(__int64 a1)
{
  return RBX::Network::MegaReplicator::preserveForwardRefsToGuid(a1: *(_QWORD *)(a1 + 14408)); /*0x106713673*/
}

// Address: 0x10671367a | Name: __ZN3RBX7Network16ClientReplicator16debugDumpProfileEi
__int64 __fastcall RBX::Network::ClientReplicator::debugDumpProfile(
        RBX::Network::ClientReplicator *this,
        unsigned int a2)
{
  void *v4; // rsi
  _QWORD v6[3]; // [rsp+0h] [rbp-160h] BYREF
  __int64 (__fastcall **v7)(); // [rsp+18h] [rbp-148h] BYREF
  _BYTE v8[72]; // [rsp+20h] [rbp-140h] BYREF
  void *v9; // [rsp+68h] [rbp-F8h]
  __int64 (__fastcall **v10)(); // [rsp+80h] [rbp-E0h] BYREF
  unsigned __int8 v11[16]; // [rsp+118h] [rbp-48h] BYREF
  void *v12; // [rsp+128h] [rbp-38h]
  __int128 v13; // [rsp+130h] [rbp-30h] BYREF
  void *v14; // [rsp+140h] [rbp-20h]

  std::basic_stringstream<char,std::char_traits<char>,std::allocator<char>>::basic_stringstream[abi:ne200100](a1: v6); /*0x10671369a*/
  RBX::Profiler::dumpProfilerDataToStringStream(a1: v6, a2); /*0x1067136a5*/
  v13 = 0; /*0x1067136ad*/
  v14 = nullptr; /*0x1067136b1*/
  std::stringbuf::str(a1: v11, a2: &v7); /*0x1067136c4*/
  RBX::Network::ClientReplicator::stringToHtmlFileDumpToLogDirHelper( /*0x1067136d4*/
    a1: (__int64)this,
    a2: (boost::filesystem::path *)&v13,
    a3: v11);
  if ( (v11[0] & 1) != 0 ) /*0x1067136dd*/
    operator delete(a1: (RBX::Memory *)v12, a2: v4); /*0x1067136e3*/
  if ( (v13 & 1) != 0 ) /*0x1067136ec*/
    operator delete(a1: (RBX::Memory *)v14, a2: v4); /*0x1067136f2*/
  v6[0] = &off_10C798D68; /*0x106713709*/
  v10 = off_10C798DB8; /*0x106713711*/
  v6[2] = off_10C798D90; /*0x106713718*/
  v7 = &off_10C799250; /*0x106713727*/
  if ( (v8[56] & 1) != 0 ) /*0x10671372f*/
    operator delete(a1: (RBX::Memory *)v9, a2: v4); /*0x106713738*/
  v7 = (__int64 (__fastcall **)())((char *)&`vtable for'std::streambuf + 16); /*0x10671374f*/
  std::locale::~locale(this: (std::locale *)v8); /*0x106713753*/
  std::iostream::~iostream(a1: v6, a2: off_10C799178); /*0x10671376a*/
  return std::ios::~ios(a1: &v10); /*0x106713777*/
}

// Address: 0x106713874 | Name: __ZZN3RBX7Network16ClientReplicator26prepareDumpOrReportProfileEvEN3$_0D1Ev
void __fastcall RBX::Network::ClientReplicator::prepareDumpOrReportProfile(void)::$_0::~$_0(__int64 a1)
{
  std::__shared_weak_count *v2; // rdi

  RBX::Analytics::InfluxDb::Points::~Points(this: (void **)(a1 + 24)); /*0x106713881*/
  v2 = *(std::__shared_weak_count **)(a1 + 8); /*0x106713886*/
  if ( v2 != nullptr ) /*0x106713891*/
    std::__shared_weak_count::__release_weak(this: v2); /*0x106713895*/
}

// Address: 0x10671389e | Name: __ZN3RBX7Network16ClientReplicator44getAndReportJobsStatsReportInCaptureIntervalERNS_9Analytics8InfluxDb6PointsE
void __fastcall RBX::Network::ClientReplicator::getAndReportJobsStatsReportInCaptureInterval(
        RBX::Network::ClientReplicator *this,
        RBX::Analytics::InfluxDb::Points *a2)
{
  __int64 v3; // rbx
  unsigned __int8 *v4; // r15
  float v5; // xmm0_4
  unsigned int v6; // r13d
  size_t v7; // r13
  char *v8; // rbx
  const void *v9; // rsi
  char *v10; // rsi
  void *v11; // rsi
  unsigned int v12; // r13d
  size_t v13; // r13
  char *v14; // rbx
  const void *v15; // rsi
  char *v16; // rsi
  void *v17; // rsi
  unsigned int v18; // r13d
  size_t v19; // r13
  char *v20; // rbx
  const void *v21; // rsi
  char *v22; // rsi
  void *v23; // rsi
  unsigned int v24; // r13d
  size_t v25; // r13
  char *v26; // rbx
  const void *v27; // rsi
  char *v28; // rsi
  void *v29; // rsi
  double v30; // xmm0_8
  __int64 v31; // rdx
  unsigned __int8 *v32; // rcx
  __int64 v33; // rax
  void *v34; // rsi
  unsigned __int8 v35; // r8
  _QWORD v36[14]; // [rsp+0h] [rbp-E0h] BYREF
  int v37; // [rsp+74h] [rbp-6Ch] BYREF
  unsigned __int8 *v38; // [rsp+78h] [rbp-68h]
  __int128 v39; // [rsp+80h] [rbp-60h] BYREF
  __int64 v40; // [rsp+90h] [rbp-50h]
  float v41; // [rsp+98h] [rbp-48h]
  _QWORD v42[2]; // [rsp+A0h] [rbp-40h] BYREF
  char *v43; // [rsp+B0h] [rbp-30h]

  if ( (_BYTE)`guard variable for'RBX::Network::ClientReplicator::getAndReportJobsStatsReportInCaptureInterval(RBX::Analytics::InfluxDb::Points &)::proftoken5524 == 0
    && __cxa_guard_acquire(a1: &`guard variable for'RBX::Network::ClientReplicator::getAndReportJobsStatsReportInCaptureInterval(RBX::Analytics::InfluxDb::Points &)::proftoken5524) != 0 )
  {
    v36[0] = "queueInstancesForBlobbing(blob) : requeueing instances from %p to %p";
    RBX::Network::ClientReplicator::getAndReportJobsStatsReportInCaptureInterval(RBX::Analytics::InfluxDb::Points &)::proftoken5524 = RBX::Profiler::getToken(this: (RBX::Profiler *)&aGroupTypesAreN[-171254], a2: &aDflogReplicati_33[-49163], a3: (const char *)0xFFFFFFFFLL, a4: 255, a5: v35); /*0x106713cc4*/
    __cxa_guard_release(a1: &`guard variable for'RBX::Network::ClientReplicator::getAndReportJobsStatsReportInCaptureInterval(RBX::Analytics::InfluxDb::Points &)::proftoken5524); /*0x106713cd2*/
  }
  v3 = RBX::Network::ClientReplicator::getAndReportJobsStatsReportInCaptureInterval(RBX::Analytics::InfluxDb::Points &)::proftoken5524; /*0x1067138c3*/
  *(_OWORD *)v36 = 0; /*0x1067138d4*/
  v36[3] = -1; /*0x1067138d8*/
  memset(&v36[4], 0, 52); /*0x1067138e0*/
  *(_OWORD *)&v36[11] = 0; /*0x1067138f6*/
  v36[2] = RBX::Network::ClientReplicator::getAndReportJobsStatsReportInCaptureInterval(RBX::Analytics::InfluxDb::Points &)::proftoken5524; /*0x1067138fb*/
  RBX::Profiler::ActiveRegion::enter(this: (RBX::Profiler::ActiveRegion *)v36); /*0x106713902*/
  v36[3] = RBX::Profiler::enterRegion(a1: v3, a2: -1, a3: 0); /*0x106713918*/
  v39 = 0; /*0x106713923*/
  v40 = 0; /*0x106713926*/
  v37 = 0; /*0x106713932*/
  RBX::Profiler::dumpProfilerJobsTimers(a1: &v39, a2: &v37); /*0x106713935*/
  v38 = *((unsigned __int8 **)&v39 + 1); /*0x106713942*/
  v4 = (unsigned __int8 *)v39; /*0x106713942*/
  if ( (_QWORD)v39 == *((_QWORD *)&v39 + 1) ) /*0x106713949*/
  {
    v30 = 0.0; /*0x106713bbc*/
  }
  else
  {
    v5 = 0.0; /*0x10671394f*/
    do /*0x106713bb0*/
    {
      v6 = *v4; /*0x106713956*/
      v41 = v5; /*0x10671395e*/
      if ( (v6 & 1) != 0 ) /*0x106713963*/
        v7 = *((_QWORD *)v4 + 1); /*0x106713965*/
      else
        v7 = v6 >> 1; /*0x10671396b*/
      std::string::basic_string[abi:ne200100](a1: v42, a2: v7 + 4); /*0x106713979*/
      v8 = (char *)v42 + 1; /*0x106713982*/
      if ( (v42[0] & 1) != 0 ) /*0x106713986*/
        v8 = v43; /*0x106713988*/
      if ( v7 != 0 ) /*0x10671398f*/
      {
        if ( (*v4 & 1) != 0 ) /*0x106713995*/
          v9 = *((const void **)v4 + 2); /*0x106713997*/
        else
          v9 = v4 + 1; /*0x10671399d*/
        memmove(__dst: v8, __src: v9, __len: v7); /*0x1067139a7*/
      }
      strcpy(&v8[v7], "_avg"); /*0x1067139ac*/
      v10 = (char *)v42 + 1; /*0x1067139be*/
      if ( (v42[0] & 1) != 0 ) /*0x1067139c2*/
        v10 = v43; /*0x1067139c4*/
      RBX::Analytics::InfluxDb::Points::addPoint(this, a2: v10, a3: *((float *)v4 + 6)); /*0x1067139d4*/
      if ( (v42[0] & 1) != 0 ) /*0x1067139dd*/
        operator delete(a1: (RBX::Memory *)v43, a2: v11); /*0x1067139e3*/
      v12 = *v4; /*0x1067139e8*/
      if ( (v12 & 1) != 0 ) /*0x1067139f0*/
        v13 = *((_QWORD *)v4 + 1); /*0x1067139f2*/
      else
        v13 = v12 >> 1; /*0x1067139f8*/
      std::string::basic_string[abi:ne200100](a1: v42, a2: v13 + 4); /*0x106713a06*/
      v14 = (char *)v42 + 1; /*0x106713a0f*/
      if ( (v42[0] & 1) != 0 ) /*0x106713a13*/
        v14 = v43; /*0x106713a15*/
      if ( v13 != 0 ) /*0x106713a1c*/
      {
        if ( (*v4 & 1) != 0 ) /*0x106713a22*/
          v15 = *((const void **)v4 + 2); /*0x106713a24*/
        else
          v15 = v4 + 1; /*0x106713a2a*/
        memmove(__dst: v14, __src: v15, __len: v13); /*0x106713a34*/
      }
      strcpy(&v14[v13], "_max"); /*0x106713a39*/
      v16 = (char *)v42 + 1; /*0x106713a4b*/
      if ( (v42[0] & 1) != 0 ) /*0x106713a4f*/
        v16 = v43; /*0x106713a51*/
      RBX::Analytics::InfluxDb::Points::addPoint(this, a2: v16, a3: *((float *)v4 + 7)); /*0x106713a61*/
      if ( (v42[0] & 1) != 0 ) /*0x106713a6a*/
        operator delete(a1: (RBX::Memory *)v43, a2: v17); /*0x106713a70*/
      v18 = *v4; /*0x106713a75*/
      if ( (v18 & 1) != 0 ) /*0x106713a7d*/
        v19 = *((_QWORD *)v4 + 1); /*0x106713a7f*/
      else
        v19 = v18 >> 1; /*0x106713a85*/
      std::string::basic_string[abi:ne200100](a1: v42, a2: v19 + 8); /*0x106713a93*/
      v20 = (char *)v42 + 1; /*0x106713a9c*/
      if ( (v42[0] & 1) != 0 ) /*0x106713aa0*/
        v20 = v43; /*0x106713aa2*/
      if ( v19 != 0 ) /*0x106713aa9*/
      {
        if ( (*v4 & 1) != 0 ) /*0x106713aaf*/
          v21 = *((const void **)v4 + 2); /*0x106713ab1*/
        else
          v21 = v4 + 1; /*0x106713ab7*/
        memmove(__dst: v20, __src: v21, __len: v19); /*0x106713ac1*/
      }
      strcpy(&v20[v19], "_callAvg"); /*0x106713ad0*/
      v22 = (char *)v42 + 1; /*0x106713ade*/
      if ( (v42[0] & 1) != 0 ) /*0x106713ae2*/
        v22 = v43; /*0x106713ae4*/
      RBX::Analytics::InfluxDb::Points::addPoint(this, a2: v22, a3: *((float *)v4 + 8)); /*0x106713af4*/
      if ( (v42[0] & 1) != 0 ) /*0x106713afd*/
        operator delete(a1: (RBX::Memory *)v43, a2: v23); /*0x106713b03*/
      v24 = *v4; /*0x106713b08*/
      if ( (v24 & 1) != 0 ) /*0x106713b10*/
        v25 = *((_QWORD *)v4 + 1); /*0x106713b12*/
      else
        v25 = v24 >> 1; /*0x106713b18*/
      std::string::basic_string[abi:ne200100](a1: v42, a2: v25 + 6); /*0x106713b26*/
      v26 = (char *)v42 + 1; /*0x106713b2f*/
      if ( (v42[0] & 1) != 0 ) /*0x106713b33*/
        v26 = v43; /*0x106713b35*/
      if ( v25 != 0 ) /*0x106713b3c*/
      {
        if ( (*v4 & 1) != 0 ) /*0x106713b42*/
          v27 = *((const void **)v4 + 2); /*0x106713b44*/
        else
          v27 = v4 + 1; /*0x106713b4a*/
        memmove(__dst: v26, __src: v27, __len: v25); /*0x106713b54*/
      }
      strcpy(&v26[v25], "_total"); /*0x106713b61*/
      v28 = (char *)v42 + 1; /*0x106713b73*/
      if ( (v42[0] & 1) != 0 ) /*0x106713b77*/
        v28 = v43; /*0x106713b79*/
      RBX::Analytics::InfluxDb::Points::addPoint(this, a2: v28, a3: *((float *)v4 + 9)); /*0x106713b89*/
      if ( (v42[0] & 1) != 0 ) /*0x106713b92*/
        operator delete(a1: (RBX::Memory *)v43, a2: v29); /*0x106713b98*/
      v5 = v41 + *((float *)v4 + 9); /*0x106713ba2*/
      v4 += 40; /*0x106713ba8*/
    }
    while ( v4 != v38 ); /*0x106713bb0*/
    v30 = v5; /*0x106713bb6*/
  }
  RBX::Analytics::InfluxDb::Points::addPoint(this, a2: "DmJobTotal", a3: v30); /*0x106713bc9*/
  if ( DFFlag::ClientNetworkTelemetryRCCChannelName == 1 )
  {
    v32 = SFString::RCCChannelName; /*0x106713bd7*/
    v33 = (SFString::RCCChannelName[0] & 1) != 0
        ? *(_QWORD *)&SFString::RCCChannelName[8]
        : SFString::RCCChannelName[0] >> 1;
    if ( v33 != 0 ) /*0x106713bf0*/
      RBX::Analytics::InfluxDb::Points::addPoint(a1: this, a2: "rccChannelName", a3: SFString::RCCChannelName); /*0x106713c03*/
  }
  std::string::basic_string[abi:ne200100]<0>(a1: v42, a2: "JobTimerDuringInitialExperience", a3: v31, a4: v32); /*0x106713c13*/
  RBX::Analytics::InfluxDb::Points::report( /*0x106713c27*/
    a1: this,
    a2: v42,
    a3: (unsigned int)DFInt::ClientReportInitExpJobStatsHundredthPercent,
    a4: 0);
  if ( (v42[0] & 1) != 0 ) /*0x106713c30*/
    operator delete(a1: (RBX::Memory *)v43, a2: v34); /*0x106713c36*/
  v42[0] = &v39; /*0x106713c43*/
  std::vector<MicroProfileTimerStat>::__destroy_vector::operator()[abi:ne200100](); /*0x106713c46*/
  RBX::Profiler::Scope::~Scope(this: (RBX::Profiler::Scope *)v36); /*0x106713c52*/
}

// Address: 0x106713d3c | Name: __ZN3RBX7Network16ClientReplicator25isReplicatedFirstFinishedEv
char __fastcall RBX::Network::ClientReplicator::isReplicatedFirstFinished(RBX::Network::ClientReplicator *this)
{
  return *((_BYTE *)this + 18408); /*0x106713d46*/
}

// Address: 0x106713d48 | Name: __ZN3RBX7Network16ClientReplicator20doSecurityChannelJobEv
__int64 __fastcall RBX::Network::ClientReplicator::doSecurityChannelJob(RBX::Network::ClientReplicator *this)
{
  RBX::Network::SecurityChannel *v1; // rdi
  __int64 result; // rax

  v1 = *((RBX::Network::SecurityChannel **)this + 2751); /*0x106713d4c*/
  if ( v1 != nullptr ) /*0x106713d56*/
    return RBX::Network::SecurityChannel::clearExpiredItems(this: v1); /*0x106713d59*/
  return result; /*0x106713d58*/
}

// Address: 0x106713d60 | Name: __ZN3RBX7Network16ClientReplicator29addInstanceQuotaStatsAndResetERNS_9Analytics8InfluxDb6PointsE
__int64 __fastcall RBX::Network::ClientReplicator::addInstanceQuotaStatsAndReset(
        RBX::Network::ClientReplicator *this,
        RBX::Analytics::InfluxDb::Points *a2)
{
  __int64 *i; // r15
  const char *v5; // rsi
  __int64 result; // rax

  RBX::Analytics::InfluxDb::Points::addPoint(this: a2, a2: "AvgInstanceQuota", a3: *((double *)this + 2782)); /*0x106713d82*/
  RBX::Analytics::InfluxDb::Points::addPoint(this: a2, a2: "CountInstanceQuotaChanged", a3: *((_DWORD *)this + 5736)); /*0x106713d97*/
  RBX::Analytics::InfluxDb::Points::addPoint(this: a2, a2: "AvgMaxRegionDistance", a3: *((double *)this + 2787)); /*0x106713dae*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106713dc3*/
    this: a2,
    a2: "CountMaxRegionDistanceChanged",
    a3: *((_DWORD *)this + 5737));
  RBX::Analytics::InfluxDb::Points::addPoint(this: a2, a2: "AvgStreamDataReadTime", a3: *((double *)this + 2766)); /*0x106713dda*/
  RBX::Analytics::InfluxDb::Points::addPoint(this: a2, a2: "AvgInstancesPerStreamData", a3: *((double *)this + 2761)); /*0x106713df1*/
  RBX::Analytics::InfluxDb::Points::addPoint(this: a2, a2: "AvgTerrainDataReadTime", a3: *((double *)this + 2774)); /*0x106713e08*/
  RBX::Analytics::InfluxDb::Points::addPoint(this: a2, a2: "AvgFractionStreamData", a3: *((double *)this + 2792)); /*0x106713e1f*/
  RBX::Analytics::InfluxDb::Points::addPoint(this: a2, a2: "AvgFractionTerrainData", a3: *((double *)this + 2797)); /*0x106713e36*/
  RBX::Analytics::InfluxDb::Points::addPoint(this: a2, a2: "AvgInstanceQuotaDiff", a3: *((double *)this + 2802)); /*0x106713e4d*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106713e64*/
    this: a2,
    a2: "AvgIncomingPacketsProcessedPerSec",
    a3: *((double *)this + 2807));
  for ( i = *((__int64 **)this + 2871); i != nullptr; i = (__int64 *)*i ) /*0x106713e69*/
  {
    if ( (i[2] & 1) != 0 ) /*0x106713e7a*/
      v5 = (const char *)i[4]; /*0x106713e82*/
    else
      v5 = (char *)i + 17; /*0x106713e7c*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: a2, a2: v5, a3: *((_DWORD *)i + 10)); /*0x106713e8d*/
  }
  result = std::__hash_table<std::__hash_value_type<std::string,int>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,int>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,int>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,int>>>::clear(a1: (char *)this + 22952); /*0x106713e9e*/
  *((_QWORD *)this + 2868) = 0; /*0x106713ea3*/
  return result; /*0x106713eb2*/
}

// Address: 0x106713eba | Name: __ZN3RBX7Network16ClientReplicator21fetchStreamingMetricsERNSt3__113unordered_mapINS2_12basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS2_6vectorIdNS7_IdEEEENS2_4hashIS9_EENS2_8equal_toIS9_EENS7_INS2_4pairIKS9_SC_EEEEEE
void __fastcall RBX::Network::ClientReplicator::fetchStreamingMetrics(double *a1, __int64 a2, __int64 a3, __int64 a4)
{
  __int64 v6; // rax
  __int64 v7; // rdx
  __int64 v8; // rcx
  void *v9; // rsi
  __int64 v10; // rax
  __int64 v11; // rdx
  __int64 v12; // rcx
  void *v13; // rsi
  __int64 v14; // rax
  __int64 v15; // rdx
  __int64 v16; // rcx
  void *v17; // rsi
  __int64 v18; // rax
  __int64 v19; // rdx
  __int64 v20; // rcx
  void *v21; // rsi
  __int64 v22; // rax
  void *v23; // rsi
  _BYTE v24[16]; // [rsp+0h] [rbp-40h] BYREF
  void *v25; // [rsp+10h] [rbp-30h]
  double v26; // [rsp+18h] [rbp-28h] BYREF
  _BYTE v27[25]; // [rsp+27h] [rbp-19h] BYREF

  std::string::basic_string[abi:ne200100]<0>(a1: v24, a2: "AvgInstanceQuota", a3, a4); /*0x106713edb*/
  v26 = COERCE_DOUBLE(v24); /*0x106713ee4*/
  v6 = std::__hash_table<std::__hash_value_type<std::string,std::vector<double>>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::vector<double>>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::vector<double>>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::vector<double>>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x106713ef8*/
         a1: a2,
         a2: v24,
         a3: std::piecewise_construct,
         a4: &v26,
         a5: v27);
  v26 = a1[2782]; /*0x106713f0d*/
  std::vector<double>::push_back[abi:ne200100](a1: v6 + 40, a2: &v26); /*0x106713f14*/
  if ( (v24[0] & 1) != 0 ) /*0x106713f1d*/
    operator delete(a1: (RBX::Memory *)v25, a2: v9); /*0x106713f23*/
  std::string::basic_string[abi:ne200100]<0>(a1: v24, a2: "AvgStreamedInRadius", a3: v7, a4: v8); /*0x106713f32*/
  v26 = COERCE_DOUBLE(v24); /*0x106713f3b*/
  v10 = std::__hash_table<std::__hash_value_type<std::string,std::vector<double>>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::vector<double>>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::vector<double>>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::vector<double>>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x106713f4f*/
          a1: a2,
          a2: v24,
          a3: std::piecewise_construct,
          a4: &v26,
          a5: v27);
  v26 = (double)(int)a1[2912]; /*0x106713f6d*/
  std::vector<double>::push_back[abi:ne200100](a1: v10 + 40, a2: &v26); /*0x106713f74*/
  if ( (v24[0] & 1) != 0 ) /*0x106713f7d*/
    operator delete(a1: (RBX::Memory *)v25, a2: v13); /*0x106713f83*/
  std::string::basic_string[abi:ne200100]<0>(a1: v24, a2: "AvgIncomingPacketsProcessedPerSec", a3: v11, a4: v12); /*0x106713f92*/
  v26 = COERCE_DOUBLE(v24); /*0x106713f9b*/
  v14 = std::__hash_table<std::__hash_value_type<std::string,std::vector<double>>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::vector<double>>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::vector<double>>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::vector<double>>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x106713faf*/
          a1: a2,
          a2: v24,
          a3: std::piecewise_construct,
          a4: &v26,
          a5: v27);
  v26 = a1[2807]; /*0x106713fc4*/
  std::vector<double>::push_back[abi:ne200100](a1: v14 + 40, a2: &v26); /*0x106713fcb*/
  if ( (v24[0] & 1) != 0 ) /*0x106713fd4*/
    operator delete(a1: (RBX::Memory *)v25, a2: v17); /*0x106713fda*/
  std::string::basic_string[abi:ne200100]<0>(a1: v24, a2: "AvgStreamingFrameTime", a3: v15, a4: v16); /*0x106713fe9*/
  v26 = COERCE_DOUBLE(v24); /*0x106713ff2*/
  v18 = std::__hash_table<std::__hash_value_type<std::string,std::vector<double>>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::vector<double>>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::vector<double>>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::vector<double>>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x106714006*/
          a1: a2,
          a2: v24,
          a3: std::piecewise_construct,
          a4: &v26,
          a5: v27);
  v26 = a1[2887]; /*0x10671401b*/
  std::vector<double>::push_back[abi:ne200100](a1: v18 + 40, a2: &v26); /*0x106714022*/
  if ( (v24[0] & 1) != 0 ) /*0x10671402b*/
    operator delete(a1: (RBX::Memory *)v25, a2: v21); /*0x106714031*/
  std::string::basic_string[abi:ne200100]<0>(a1: v24, a2: "AvgStreamedInRegions", a3: v19, a4: v20); /*0x106714040*/
  v26 = COERCE_DOUBLE(v24); /*0x106714049*/
  v22 = std::__hash_table<std::__hash_value_type<std::string,std::vector<double>>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::vector<double>>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::vector<double>>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::vector<double>>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x10671405d*/
          a1: a2,
          a2: v24,
          a3: std::piecewise_construct,
          a4: &v26,
          a5: v27);
  v26 = (double)(int)a1[2927]; /*0x10671407b*/
  std::vector<double>::push_back[abi:ne200100](a1: v22 + 40, a2: &v26); /*0x106714082*/
  if ( (v24[0] & 1) != 0 ) /*0x10671408b*/
    operator delete(a1: (RBX::Memory *)v25, a2: v23); /*0x106714091*/
}

// Address: 0x1067140ce | Name: __ZN3RBX7Network16ClientReplicator45getAndResetMaxGuidsAndTotalRegionRemovalItemsEv
__int64 __fastcall RBX::Network::ClientReplicator::getAndResetMaxGuidsAndTotalRegionRemovalItems(
        RBX::Network::ClientReplicator *this)
{
  __int64 v1; // rax
  __int64 v2; // rcx

  v1 = *((unsigned int *)this + 5887); /*0x1067140d2*/
  v2 = *((unsigned int *)this + 5888); /*0x1067140d8*/
  *(_QWORD *)((char *)this + 23548) = 0; /*0x1067140de*/
  return v2 | (v1 << 32); /*0x1067140f0*/
}

// Address: 0x1067140f2 | Name: __ZN3RBX7Network16ClientReplicator32setPrePauseProcessingHealthStatsERNS1_21ProcessingHealthStatsE
__int64 *__fastcall RBX::Network::ClientReplicator::setPrePauseProcessingHealthStats(__int64 a1, __int64 a2)
{
  float v4; // xmm0_4
  float v5; // xmm0_4
  RBX::Network::ConcurrentRakPeer *v6; // rdi
  double v7; // xmm0_8
  __int64 v8; // rax
  __int64 v9; // rax

  *(_DWORD *)a2 = (int)*(double *)(a1 + 22256); /*0x106714107*/
  v4 = *(double *)(a1 + 22456); /*0x106714109*/
  *(float *)(a2 + 4) = 1.0 / v4; /*0x10671411d*/
  *(_QWORD *)(a2 + 8) = *(_QWORD *)(a1 + 22128); /*0x10671412a*/
  v5 = *(double *)(a1 + 22336); /*0x106714132*/
  *(float *)(a2 + 16) = v5; /*0x10671413a*/
  *(_DWORD *)(a2 + 20) = RBX::Network::Replicator::incomingPacketsCount(this: (RBX::Network::Replicator *)a1); /*0x106714144*/
  *(_DWORD *)(a2 + 24) = (int)*(double *)(a1 + 22496); /*0x106714150*/
  *(_DWORD *)(a2 + 28) = RBX::TotalCountTimeInterval<int,(RBX::Time::SampleMethod)1>::sampleLastFullInterval(a1: a1 + 15104); /*0x10671415f*/
  v6 = *(RBX::Network::ConcurrentRakPeer **)(a1 + 224); /*0x106714162*/
  v7 = -1.0; /*0x106714169*/
  if ( v6 != nullptr ) /*0x106714174*/
  {
    v8 = RBX::Network::ConcurrentRakPeer::rawPeer(this: v6); /*0x106714176*/
    v7 = -1.0; /*0x10671417b*/
    if ( v8 != 0 ) /*0x106714186*/
    {
      v9 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *(RBX::Network::ConcurrentRakPeer **)(a1 + 224)); /*0x10671418f*/
      v7 = (*(double (__fastcall **)(__int64))(*(_QWORD *)v9 + 640LL))(a1: v9); /*0x10671419a*/
    }
  }
  *(double *)(a2 + 32) = v7; /*0x1067141a0*/
  *(_QWORD *)(a2 + 40) = RBX::Analytics::usableHttpBandwidthMbps; /*0x1067141b0*/
  return &RBX::Analytics::usableHttpBandwidthMbps; /*0x1067141b5*/
}

// Address: 0x1067141ba | Name: __ZN3RBX7Network16ClientReplicator31addStreamingJitterStatsAndResetERNS_9Analytics8InfluxDb6PointsE
__int64 __fastcall RBX::Network::ClientReplicator::addStreamingJitterStatsAndReset(
        RBX::Network::ClientReplicator *this,
        RBX::Analytics::InfluxDb::Points *a2)
{
  return RBX::JitterMetric::recordStatsToPointsAndReset( /*0x1067141c5*/
           this: (RBX::Network::ClientReplicator *)((char *)this + 23560),
           a2);
}

// Address: 0x1067141cc | Name: __ZN3RBX7Network16ClientReplicator36addInstanceQuotaStatsToEventAndResetERNS_9Telemetry20RobloxTelemetryEventE
__int64 __fastcall RBX::Network::ClientReplicator::addInstanceQuotaStatsToEventAndReset(
        RBX::Network::ClientReplicator *this,
        RBX::Telemetry::RobloxTelemetryEvent *a2)
{
  char *v4; // r14
  __int64 *i; // r12
  const char *v6; // r15
  size_t v7; // rdx
  __int64 result; // rax

  v4 = (char *)a2 + 72; /*0x1067141dd*/
  (*(void (__fastcall **)(char *, const char *, __int64, __int64, double))(*((_QWORD *)a2 + 9) + 16LL))( /*0x106714201*/
    a1: (char *)a2 + 72,
    a2: "AvgInstanceQuota",
    a3: 16,
    a4: 1,
    a5: *((double *)this + 2782));
  (**((void (__fastcall ***)(char *, const char *, __int64, _QWORD, __int64))a2 + 9))( /*0x106714224*/
    a1: v4,
    a2: "CountInstanceQuotaChanged",
    a3: 25,
    a4: *((int *)this + 5736),
    a5: 1);
  (*(void (__fastcall **)(char *, const char *, __int64, __int64, double))(*((_QWORD *)a2 + 9) + 16LL))( /*0x106714246*/
    a1: v4,
    a2: "AvgMaxRegionDistance",
    a3: 20,
    a4: 1,
    a5: *((double *)this + 2787));
  (**((void (__fastcall ***)(char *, const char *, __int64, _QWORD, __int64))a2 + 9))( /*0x106714269*/
    a1: v4,
    a2: "CountMaxRegionDistanceChanged",
    a3: 29,
    a4: *((int *)this + 5737),
    a5: 1);
  (*(void (__fastcall **)(char *, const char *, __int64, __int64, double))(*((_QWORD *)a2 + 9) + 16LL))( /*0x10671428b*/
    a1: v4,
    a2: "AvgStreamDataReadTime",
    a3: 21,
    a4: 1,
    a5: *((double *)this + 2766));
  (*(void (__fastcall **)(char *, const char *, __int64, __int64, double))(*((_QWORD *)a2 + 9) + 16LL))( /*0x1067142ae*/
    a1: v4,
    a2: "AvgInstancesPerStreamData",
    a3: 25,
    a4: 1,
    a5: *((double *)this + 2761));
  (*(void (__fastcall **)(char *, const char *, __int64, __int64, double))(*((_QWORD *)a2 + 9) + 16LL))( /*0x1067142d1*/
    a1: v4,
    a2: "AvgTerrainDataReadTime",
    a3: 22,
    a4: 1,
    a5: *((double *)this + 2774));
  (*(void (__fastcall **)(char *, const char *, __int64, __int64, double))(*((_QWORD *)a2 + 9) + 16LL))( /*0x1067142f4*/
    a1: v4,
    a2: "AvgFractionStreamData",
    a3: 21,
    a4: 1,
    a5: *((double *)this + 2792));
  (*(void (__fastcall **)(char *, const char *, __int64, __int64, double))(*((_QWORD *)a2 + 9) + 16LL))( /*0x106714317*/
    a1: v4,
    a2: "AvgFractionTerrainData",
    a3: 22,
    a4: 1,
    a5: *((double *)this + 2797));
  (*(void (__fastcall **)(char *, const char *, __int64, __int64, double))(*((_QWORD *)a2 + 9) + 16LL))( /*0x10671433a*/
    a1: v4,
    a2: "AvgInstanceQuotaDiff",
    a3: 20,
    a4: 1,
    a5: *((double *)this + 2802));
  (*(void (__fastcall **)(char *, const char *, __int64, __int64, double))(*((_QWORD *)a2 + 9) + 16LL))( /*0x10671435d*/
    a1: v4,
    a2: "AvgIncomingPacketsProcessedPerSec",
    a3: 33,
    a4: 1,
    a5: *((double *)this + 2807));
  for ( i = *((__int64 **)this + 2871); i != nullptr; i = (__int64 *)*i ) /*0x106714360*/
  {
    if ( (i[2] & 1) == 0 ) /*0x106714372*/
    {
      v6 = (char *)i + 17; /*0x106714374*/
LABEL_6:
      v7 = strlen(__s: v6); /*0x106714385*/
      goto LABEL_7; /*0x10671438d*/
    }
    v6 = (const char *)i[4]; /*0x10671437b*/
    if ( v6 != nullptr ) /*0x106714383*/
      goto LABEL_6; /*0x106714383*/
    v6 = nullptr; /*0x1067143ac*/
    v7 = 0; /*0x1067143af*/
LABEL_7:
    (**(void (__fastcall ***)(char *, const char *, size_t, _QWORD, __int64))v4)( /*0x106714390*/
      a1: v4,
      a2: v6,
      a3: v7,
      a4: *((int *)i + 10),
      a5: 1);
  }
  result = std::__hash_table<std::__hash_value_type<std::string,int>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,int>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,int>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,int>>>::clear(a1: (char *)this + 22952); /*0x1067143ba*/
  *((_QWORD *)this + 2868) = 0; /*0x1067143bf*/
  return result; /*0x1067143ca*/
}

// Address: 0x1067143d4 | Name: __ZN3RBX7Network16ClientReplicator38addStreamingJitterStatsToEventAndResetERNS_9Telemetry20RobloxTelemetryEventE
__int64 __fastcall RBX::Network::ClientReplicator::addStreamingJitterStatsToEventAndReset(
        RBX::Network::ClientReplicator *this,
        RBX::Telemetry::RobloxTelemetryEvent *a2)
{
  return RBX::JitterMetric::recordStatsToEventAndReset<RBX::Telemetry::RobloxTelemetryEvent>( /*0x1067143df*/
           a1: (char *)this + 23560,
           a2);
}

// Address: 0x1067145c4 | Name: __ZN3RBX7Network16ClientReplicator41addStreamingFrameTimeDistributionAndResetERNS_9Analytics8InfluxDb6PointsE
__int64 __fastcall RBX::Network::ClientReplicator::addStreamingFrameTimeDistributionAndReset(
        RBX::Network::ClientReplicator *this,
        RBX::Analytics::InfluxDb::Points *a2)
{
  RBX::KllSketch *v3; // rbx
  __int64 result; // rax
  float v5; // xmm0_4
  float v6; // xmm0_4
  float v7; // xmm0_4
  float v8; // xmm0_4
  float v9; // xmm0_4
  float v10; // xmm0_4

  v3 = (RBX::Network::ClientReplicator *)((char *)this + 23816); /*0x1067145d1*/
  result = RBX::KllSketch::isEmpty(this: (RBX::Network::ClientReplicator *)((char *)this + 23816)); /*0x1067145db*/
  if ( (_BYTE)result == 0 ) /*0x1067145e2*/
  {
    RBX::KllSketch::getMaxItem(this: v3); /*0x1067145ec*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: a2, a2: "StreamingWorkTimeMax", a3: v5); /*0x1067145ff*/
    RBX::KllSketch::getMinItem(this: v3); /*0x106714607*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: a2, a2: "StreamingWorkTimeMin", a3: v6); /*0x10671461a*/
    RBX::KllSketch::getQuantile(this: v3, a2: 0.5, a3: true); /*0x10671462f*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: a2, a2: "StreamingWorkTimeP50", a3: v7); /*0x106714642*/
    RBX::KllSketch::getQuantile(this: v3, a2: 0.75, a3: true); /*0x106714657*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: a2, a2: "StreamingWorkTimeP75", a3: v8); /*0x10671466a*/
    RBX::KllSketch::getQuantile(this: v3, a2: 0.95, a3: true); /*0x10671467f*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: a2, a2: "StreamingWorkTimeP95", a3: v9); /*0x106714692*/
    RBX::KllSketch::getQuantile(this: v3, a2: 0.99, a3: true); /*0x1067146a7*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: a2, a2: "StreamingWorkTimeP99", a3: v10); /*0x1067146ba*/
    return RBX::KllSketch::reset(this: v3); /*0x1067146c6*/
  }
  return result; /*0x1067145e4*/
}

// Address: 0x1067146cc | Name: __ZN3RBX7Network16ClientReplicator48addStreamingFrameTimeDistributionToEventAndResetERNS_9Telemetry20RobloxTelemetryEventE
__int64 __fastcall RBX::Network::ClientReplicator::addStreamingFrameTimeDistributionToEventAndReset(
        RBX::Network::ClientReplicator *this,
        RBX::Telemetry::RobloxTelemetryEvent *a2)
{
  RBX::KllSketch *v3; // rbx
  __int64 result; // rax
  float v5; // xmm0_4
  float v6; // xmm0_4
  float v7; // xmm0_4
  float v8; // xmm0_4
  float v9; // xmm0_4
  float v10; // xmm0_4

  v3 = (RBX::Network::ClientReplicator *)((char *)this + 23816); /*0x1067146dc*/
  result = RBX::KllSketch::isEmpty(this: (RBX::Network::ClientReplicator *)((char *)this + 23816)); /*0x1067146e6*/
  if ( (_BYTE)result == 0 ) /*0x1067146ed*/
  {
    RBX::KllSketch::getMaxItem(this: v3); /*0x106714701*/
    (*(void (__fastcall **)(char *, const char *, __int64, __int64, double))(*((_QWORD *)a2 + 9) + 16LL))( /*0x106714722*/
      a1: (char *)a2 + 72,
      a2: "StreamingWorkTimeMax",
      a3: 20,
      a4: 1,
      a5: v5);
    RBX::KllSketch::getMinItem(this: v3); /*0x106714728*/
    (*(void (__fastcall **)(char *, const char *, __int64, __int64, double))(*((_QWORD *)a2 + 9) + 16LL))( /*0x106714749*/
      a1: (char *)a2 + 72,
      a2: "StreamingWorkTimeMin",
      a3: 20,
      a4: 1,
      a5: v6);
    RBX::KllSketch::getQuantile(this: v3, a2: 0.5, a3: true); /*0x10671475c*/
    (*(void (__fastcall **)(char *, const char *, __int64, __int64, double))(*((_QWORD *)a2 + 9) + 16LL))( /*0x10671477d*/
      a1: (char *)a2 + 72,
      a2: "StreamingWorkTimeP50",
      a3: 20,
      a4: 1,
      a5: v7);
    RBX::KllSketch::getQuantile(this: v3, a2: 0.75, a3: true); /*0x106714790*/
    (*(void (__fastcall **)(char *, const char *, __int64, __int64, double))(*((_QWORD *)a2 + 9) + 16LL))( /*0x1067147b1*/
      a1: (char *)a2 + 72,
      a2: "StreamingWorkTimeP75",
      a3: 20,
      a4: 1,
      a5: v8);
    RBX::KllSketch::getQuantile(this: v3, a2: 0.95, a3: true); /*0x1067147c4*/
    (*(void (__fastcall **)(char *, const char *, __int64, __int64, double))(*((_QWORD *)a2 + 9) + 16LL))( /*0x1067147e5*/
      a1: (char *)a2 + 72,
      a2: "StreamingWorkTimeP95",
      a3: 20,
      a4: 1,
      a5: v9);
    RBX::KllSketch::getQuantile(this: v3, a2: 0.99, a3: true); /*0x1067147f8*/
    (*(void (__fastcall **)(char *, const char *, __int64, __int64, double))(*((_QWORD *)a2 + 9) + 16LL))( /*0x106714819*/
      a1: (char *)a2 + 72,
      a2: "StreamingWorkTimeP99",
      a3: 20,
      a4: 1,
      a5: v10);
    return RBX::KllSketch::reset(this: v3); /*0x106714829*/
  }
  return result; /*0x1067146f3*/
}

// Address: 0x10671482e | Name: __ZN3RBX7Network16ClientReplicator43sendPropertyChangeForUndoForStudioStreamingERKNSt3__110shared_ptrINS_8InstanceEEERKNS_10Reflection18PropertyDescriptorERKNS8_7VariantE
__int64 __fastcall RBX::Network::ClientReplicator::sendPropertyChangeForUndoForStudioStreaming(
        _QWORD *a1,
        _QWORD *a2,
        RBX::Network::ObjectRefEdge *a3,
        __int64 a4)
{
  __int64 result; // rax
  __int64 v9; // rdi
  __int64 v10; // rax
  __int64 v11; // rcx
  unsigned __int64 v12; // rax
  __int64 v13; // rdx
  __int64 v14; // rdi
  __int64 v15; // rcx
  unsigned __int64 v16; // rax
  __int64 v17; // rdx
  const RBX::Reflection::PropertyDescriptor *v18; // rsi
  __int64 v19; // r13
  unsigned __int64 v20; // r12
  unsigned __int64 v21; // rsi
  __int64 **v22; // rdi
  __int64 *v23; // r13
  __int64 **v24; // rdi
  __int64 *v25; // r12
  RBX::Network::Item *v26; // r12
  __int64 v27; // rax
  std::__shared_weak_count *v28; // rbx
  RBX::Network::ItemQueue *v29; // rdi
  __int64 v30; // rax
  std::__shared_weak_count *v31; // r14
  std::__shared_weak_count *v32[2]; // [rsp+10h] [rbp-70h] BYREF
  std::__shared_weak_count *v33[2]; // [rsp+20h] [rbp-60h] BYREF
  RBX::Network::ObjectRefEdge *v34; // [rsp+30h] [rbp-50h]
  __int64 v35; // [rsp+38h] [rbp-48h]
  unsigned __int64 v36; // [rsp+40h] [rbp-40h]
  RBX::Network::ItemQueue *v37; // [rsp+48h] [rbp-38h]
  __int64 ***v38; // [rsp+50h] [rbp-30h]

  result = RBX::Network::Replicator::canReplicateProperty(a1: 1, a2: a3, a3: 0); /*0x106714855*/
  if ( (_BYTE)result != 0 ) /*0x10671485c*/
  {
    (*(void (__fastcall **)(RBX::Network::ObjectRefEdge *, _QWORD, __int64))(*(_QWORD *)a3 + 152LL))( /*0x10671486e*/
      a1: a3,
      a2: *a2,
      a3: a4);
    v9 = a1[1560] + 64LL; /*0x106714882*/
    v34 = *(RBX::Network::ObjectRefEdge **)(*a2 + 24LL); /*0x10671488a*/
    v10 = RBX::detail::DenseHashTable<RBX::Reflection::ClassDescriptor const*,std::pair<RBX::Reflection::ClassDescriptor const*,unsigned short>,std::pair<RBX::Reflection::ClassDescriptor const* const,unsigned short>,RBX::detail::ItemInterfaceMap<RBX::Reflection::ClassDescriptor const*,unsigned short>,RBX::Hash<RBX::Reflection::ClassDescriptor const*>,std::equal_to<RBX::Reflection::ClassDescriptor const*>>::find(a1: v9); /*0x106714891*/
    v11 = a1[1560]; /*0x106714896*/
    v12 = *(unsigned __int16 *)(v10 + 8); /*0x10671489d*/
    v13 = *(_QWORD *)(v11 + 184); /*0x1067148a1*/
    v14 = 0; /*0x1067148ce*/
    if ( 0xD37A6F4DE9BD37A7LL * ((*(_QWORD *)(v11 + 192) - v13) >> 3) > v12 ) /*0x1067148d3*/
      v14 = v13 + 184 * v12; /*0x1067148d3*/
    v34 = a3; /*0x1067148db*/
    result = RBX::detail::DenseHashTable<RBX::Reflection::PropertyDescriptor const*,std::pair<RBX::Reflection::PropertyDescriptor const*,unsigned short>,std::pair<RBX::Reflection::PropertyDescriptor const* const,unsigned short>,RBX::detail::ItemInterfaceMap<RBX::Reflection::PropertyDescriptor const*,unsigned short>,RBX::Hash<RBX::Reflection::PropertyDescriptor const*>,std::equal_to<RBX::Reflection::PropertyDescriptor const*>>::find(a1: v14 + 16); /*0x1067148e3*/
    if ( result != 0 ) /*0x1067148eb*/
    {
      v15 = a1[1560]; /*0x1067148f1*/
      v16 = *(unsigned __int16 *)(result + 8); /*0x1067148f8*/
      v17 = *(_QWORD *)(v15 + 208); /*0x1067148fc*/
      v18 = (const RBX::Reflection::PropertyDescriptor *)(v17 + (unsigned int)(32 * v16)); /*0x106714916*/
      v19 = 0; /*0x106714919*/
      if ( (*(_QWORD *)(v15 + 216) - v17) >> 5 > v16 ) /*0x10671491f*/
        v19 = v17 + (unsigned int)(32 * v16); /*0x10671491f*/
      if ( DFFlag::UseObjectRefEdgeForUndoRefProperty == 1 ) /*0x10671492a*/
      {
        if ( (unsigned __int8)RBX::Network::ObjectRefEdge::isRefType(this: a3, a2: v18) == 0 ) /*0x106714936*/
          goto LABEL_9; /*0x106714936*/
      }
      else if ( *(_BYTE *)(*((_QWORD *)a3 + 13) + 55LL) != 1 ) /*0x10671499b*/
      {
LABEL_9:
        v35 = v19; /*0x106714938*/
        v20 = a1[1948]; /*0x10671493c*/
        v37 = (RBX::Network::ItemQueue *)(a1 + 1817); /*0x10671494a*/
        if ( (unsigned __int8)RBX::Network::ItemQueue::empty(this: (RBX::Network::ItemQueue *)(a1 + 1817)) == 0 ) /*0x106714955*/
        {
          v20 = *(_QWORD *)(a1[1818] + 24LL); /*0x10671495e*/
          if ( a1[1948] < v20 ) /*0x10671496c*/
            v20 = a1[1948]; /*0x10671496c*/
        }
        v38 = (__int64 ***)a1[1477]; /*0x106714977*/
        v22 = *v38; /*0x10671497b*/
        v23 = **v38; /*0x10671497e*/
        v36 = v20; /*0x106714984*/
        if ( v23 != nullptr ) /*0x106714988*/
          *v22 = (__int64 *)*v23; /*0x10671498e*/
        else
          v23 = boost::pool<RBX::TrackedAllocator>::malloc_need_resize(a1: v22, a2: v21); /*0x1067149c8*/
        *v23 = (__int64)v38; /*0x1067149cf*/
        v26 = (RBX::Network::Item *)(v23 + 1); /*0x1067149d3*/
        v27 = a2[1]; /*0x1067149d7*/
        *(_OWORD *)v33 = *(_OWORD *)a2; /*0x1067149df*/
        if ( v27 != 0 ) /*0x1067149e6*/
          _InterlockedIncrement64((volatile signed __int64 *)(v27 + 8)); /*0x1067149e8*/
        RBX::Network::Replicator::ChangePropertyItem::ChangePropertyItem( /*0x106714a15*/
          a1: (__int64)(v23 + 1),
          a2: (RBX::Network::Replicator *)a1,
          (__int64)a3,
          a4: v35,
          a5: v33,
          a6: v36,
          a7: *(_DWORD *)(a1[1801] + 3072LL));
        v28 = v33[1]; /*0x106714a1a*/
        if ( v33[1] != nullptr /*0x106714a33*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v33[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v28 + 16LL))(a1: v28); /*0x106714a3b*/
          std::__shared_weak_count::__release_weak(this: v28); /*0x106714a41*/
        }
        *((_BYTE *)v23 + 109) = 1; /*0x106714a46*/
        v29 = v37; /*0x106714a4b*/
        return RBX::Network::ItemQueue::push_back(this: v29, a2: v26); /*0x106714acc*/
      }
      v38 = (__int64 ***)a1[1482]; /*0x1067149a4*/
      v24 = *v38; /*0x1067149a8*/
      v25 = **v38; /*0x1067149ab*/
      if ( v25 != nullptr ) /*0x1067149b1*/
        *v24 = (__int64 *)*v25; /*0x1067149bb*/
      else
        v25 = boost::pool<RBX::TrackedAllocator>::malloc_need_resize(a1: v24, a2: (unsigned __int64)v18); /*0x106714a56*/
      *v25 = (__int64)v38; /*0x106714a5d*/
      v26 = (RBX::Network::Item *)(v25 + 1); /*0x106714a61*/
      v30 = a2[1]; /*0x106714a65*/
      *(_OWORD *)v32 = *(_OWORD *)a2; /*0x106714a6d*/
      if ( v30 != 0 ) /*0x106714a74*/
        _InterlockedIncrement64((volatile signed __int64 *)(v30 + 8)); /*0x106714a76*/
      RBX::Network::Replicator::ReferencePropertyChangedItem::ReferencePropertyChangedItem( /*0x106714a8e*/
        a1: v26,
        a2: a1,
        a3,
        a4: v19,
        a5: v32);
      v31 = v32[1]; /*0x106714a93*/
      if ( v32[1] != nullptr /*0x106714aac*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v32[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v31 + 16LL))(a1: v31); /*0x106714ab4*/
        std::__shared_weak_count::__release_weak(this: v31); /*0x106714aba*/
      }
      v29 = (RBX::Network::ItemQueue *)(a1 + 1817); /*0x106714ac6*/
      return RBX::Network::ItemQueue::push_back(this: v29, a2: v26); /*0x106714ac6*/
    }
  }
  return result; /*0x106714ad1*/
}

// Address: 0x106714b06 | Name: __ZN3RBX7Network16ClientReplicator19reportSampledBwDataEv
__int64 __fastcall RBX::Network::ClientReplicator::reportSampledBwData(RBX::Network::ClientReplicator *this)
{
  double v2; // xmm0_8
  __int128 v3; // xmm0
  double v4; // xmm0_8
  double v5; // xmm0_8
  double v6; // xmm0_8
  double v7; // xmm0_8
  __int64 i; // r15
  char *v9; // rsi
  __int64 v10; // rdx
  void *v11; // rsi
  __int64 *EngineNetConfiguration; // rax
  __int64 v13; // rax
  double v14; // xmm0_8
  __int64 v15; // xmm0_8
  double v16; // xmm0_8
  double v17; // xmm0_8
  double v18; // xmm0_8
  __int64 v19; // rdi
  double v20; // xmm0_8
  __int128 v21; // xmm0
  RBX::Network::ClientReplicator *v22; // xmm0_8
  double v23; // xmm0_8
  double v24; // xmm0_8
  double v25; // xmm0_8
  __m128d v26; // xmm2
  __int64 v27; // rdx
  unsigned __int8 *v28; // rcx
  __int64 v29; // rax
  void *v30; // rsi
  void *v32[14]; // [rsp+0h] [rbp-390h] BYREF
  __int64 Name; // [rsp+70h] [rbp-320h] BYREF
  double v34; // [rsp+80h] [rbp-310h]
  double v35; // [rsp+88h] [rbp-308h]
  double v36; // [rsp+90h] [rbp-300h]
  unsigned __int8 v37; // [rsp+98h] [rbp-2F8h] BYREF
  char v38; // [rsp+99h] [rbp-2F7h] BYREF
  __int64 v39; // [rsp+A0h] [rbp-2F0h]
  void *v40; // [rsp+A8h] [rbp-2E8h]
  __int128 v41; // [rsp+B0h] [rbp-2E0h]
  unsigned __int64 v42[3]; // [rsp+C0h] [rbp-2D0h]
  RBX::Network::ClientReplicator *v43; // [rsp+D8h] [rbp-2B8h]
  double v44; // [rsp+E0h] [rbp-2B0h]
  double v45; // [rsp+E8h] [rbp-2A8h]
  double v46; // [rsp+F0h] [rbp-2A0h]
  double v47; // [rsp+F8h] [rbp-298h]
  double v48; // [rsp+100h] [rbp-290h]
  void *v49[9]; // [rsp+108h] [rbp-288h] BYREF
  _BYTE v50[528]; // [rsp+150h] [rbp-240h] BYREF

  if ( (unsigned __int8)RBX::Network::flagsSendsGoThroughConnection(this) != 0 ) /*0x106714b32*/
  {
    RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x106714b46*/
      a1: (__int64)v49,
      a2: (__int64)&RBX::Telemetry::kClientSamplePlayerBandwidthStats);
    if ( (unsigned __int8)RBX::Telemetry::RobloxTelemetryEvent::willThrottlePoints(this: (RBX::Telemetry::RobloxTelemetryEvent *)v49) == 0 ) /*0x106714b59*/
    {
LABEL_30:
      RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v49); /*0x1067151d6*/
      return __stack_chk_guard; /*0x1067151e4*/
    }
    RBX::NetworkBase::ConnectionInternal::getChannelBandwidthRateToReport(this: (RBX::NetworkBase::ConnectionInternal *)v32); /*0x106714b6d*/
    RBX::Network::TimeIntervalMeter::getRatePerSecondAndReset(this: (RBX::Network::ClientReplicator *)((char *)this + 9936)); /*0x106714b79*/
    v47 = v2; /*0x106714b7e*/
    RBX::Network::TimeIntervalMeter::getRatePerSecondAndReset(this: (RBX::Network::ClientReplicator *)((char *)this + 9968)); /*0x106714b8d*/
    v41 = v3; /*0x106714b92*/
    RBX::Network::TimeIntervalMeter::getRatePerSecondAndReset(this: (RBX::Network::ClientReplicator *)((char *)this + 9952)); /*0x106714ba1*/
    v46 = v4; /*0x106714ba6*/
    RBX::Network::TimeIntervalMeter::getRatePerSecondAndReset(this: (RBX::Network::ClientReplicator *)((char *)this + 9984)); /*0x106714bb5*/
    v44 = v5; /*0x106714bba*/
    RBX::Network::TimeIntervalMeter::getRatePerSecondAndReset(this: (RBX::Network::ClientReplicator *)((char *)this + 10016)); /*0x106714bc9*/
    v45 = v6; /*0x106714bce*/
    v43 = this; /*0x106714bd6*/
    RBX::Network::TimeIntervalMeter::getRatePerSecondAndReset(this: (RBX::Network::ClientReplicator *)((char *)this + 10000)); /*0x106714be4*/
    *(double *)v42 = v7; /*0x106714be9*/
    v48 = 0.0; /*0x106714bfc*/
    for ( i = 0; i != 14; ++i ) /*0x106714c04*/
    {
      v48 = v48 + *(double *)&v32[i]; /*0x106714c2e*/
      Name = RBX::NetworkBase::getName(a1: (unsigned int)i); /*0x106714c3e*/
      fmt::v8::vformat(a1: &v37, a2: "Client_SamplePlayer_{}_Egress_BytesPerSec", 41, 12, &Name); /*0x106714c58*/
      if ( (v37 & 1) != 0 ) /*0x106714c67*/
      {
        v9 = (char *)v40; /*0x106714c69*/
        v10 = v39; /*0x106714c70*/
      }
      else
      {
        v10 = v37 >> 1; /*0x106714c79*/
        v9 = &v38; /*0x106714c7b*/
      }
      RBX::Telemetry::FieldsContainer::addField(a1: v50, a2: v9, a3: v10, a4: 1, a5: *(double *)&v32[i]); /*0x106714c94*/
      if ( (v37 & 1) != 0 ) /*0x106714ca0*/
        operator delete(a1: (RBX::Memory *)v40, a2: v11); /*0x106714ca9*/
    }
    RBX::Telemetry::FieldsContainer::addField( /*0x106714cd7*/
      a1: v50,
      a2: "Client_SamplePlayer_Facs_AppPacketBytesSendPerSec",
      a3: 49,
      a4: 1,
      a5: v47);
    RBX::Telemetry::FieldsContainer::addField( /*0x106714cf8*/
      a1: v50,
      a2: "Client_SamplePlayer_Facs_CountPerSec",
      a3: 36,
      a4: 1,
      a5: v46);
    RBX::Telemetry::FieldsContainer::addField( /*0x106714d3a*/
      a1: v50,
      a2: "Client_SamplePlayer_Facs_Bandwidth_Percentage",
      a3: 45,
      a4: 1,
      a5: COERCE_DOUBLE(
        COERCE_UNSIGNED_INT64(_mm_cmplt_sd((__m128d)0LL, (__m128d)*(unsigned __int64 *)&v48).f64[0])
      & COERCE_UNSIGNED_INT64(v47 / v48 * 100.0)));
    RBX::Telemetry::FieldsContainer::addField( /*0x106714d5b*/
      a1: v50,
      a2: "Client_SamplePlayer_Egress_BytesPerSec",
      a3: 38,
      a4: 1,
      a5: v48);
    EngineNetConfiguration = (__int64 *)RBX::Network::NetworkSchema::getEngineNetConfiguration(this: (RBX::Network::NetworkSchema *)(*((_QWORD *)v43 + 1801) + 1608LL)); /*0x106714d73*/
    if ( FFlag::DebugHashTableMetrics == 0 ) /*0x106714d82*/
    {
      if ( FFlag::SAuthWorkspaceFlagged == 1 ) /*0x106714d92*/
      {
        v13 = *EngineNetConfiguration; /*0x106714d98*/
        if ( (v13 & 8) != 0 || (v13 & 1) != 0 ) /*0x106714da5*/
          goto LABEL_29; /*0x106714da5*/
      }
      else if ( FFlag::NextGenReplicatorEnabledRead == 0 ) /*0x1067150cd*/
      {
LABEL_28:
        RBX::Telemetry::FieldsContainer::addField( /*0x1067150db*/
          a1: v50,
          a2: "Client_SamplePlayer_Physics_SendBytesPerSec",
          a3: 43,
          a4: 1,
          a5: *(double *)&v32[6] - v47);
        goto LABEL_29; /*0x1067150ff*/
      }
      if ( FFlag::NextGenReplicatorEnabledWrite == 0 ) /*0x1067150d9*/
        goto LABEL_28; /*0x1067150d9*/
    }
LABEL_29:
    RBX::Telemetry::FieldsContainer::addField( /*0x106715104*/
      a1: v50,
      a2: "Client_SamplePlayer_Facs_AppPacketsBytesRecvPerSec",
      a3: 50,
      a4: 1,
      a5: *(double *)&v41);
    RBX::Telemetry::FieldsContainer::addField( /*0x106715141*/
      a1: v50,
      a2: "Client_SamplePlayer_Facs_RecvCountPerSec",
      a3: 40,
      a4: 1,
      a5: v44);
    RBX::Telemetry::FieldsContainer::addField( /*0x106715162*/
      a1: v50,
      a2: "Client_SamplePlayer_Facs_RevOutOfOrderPerSec",
      a3: 44,
      a4: 1,
      a5: v45);
    RBX::Telemetry::FieldsContainer::addField( /*0x1067151a4*/
      a1: v50,
      a2: "Client_SamplePlayer_Facs_IngressBwPercent",
      a3: 41,
      a4: 1,
      a5: COERCE_DOUBLE(
        COERCE_UNSIGNED_INT64(_mm_cmplt_sd((__m128d)0LL, (__m128d)v42[0]).f64[0])
      & COERCE_UNSIGNED_INT64(*(double *)&v41 / *(double *)v42 * 100.0)));
    RBX::Telemetry::FieldsContainer::addField( /*0x1067151c5*/
      a1: v50,
      a2: "Client_SamplePlayer_Ingress_BytesPerSec",
      a3: 39,
      a4: 1,
      a5: *(double *)v42);
    RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v49); /*0x1067151d1*/
    goto LABEL_30; /*0x1067151d1*/
  }
  RBX::Network::TimeIntervalMeter::getRatePerSecondAndReset(this: (RBX::Network::ClientReplicator *)((char *)this + 9872)); /*0x106714db7*/
  v47 = v14; /*0x106714dbc*/
  RBX::Network::TimeIntervalMeter::getRatePerSecondAndReset(this: (RBX::Network::ClientReplicator *)((char *)this + 9904)); /*0x106714dcb*/
  *(_QWORD *)&v41 = v15; /*0x106714dd0*/
  RBX::Network::TimeIntervalMeter::getRatePerSecondAndReset(this: (RBX::Network::ClientReplicator *)((char *)this + 9920)); /*0x106714ddf*/
  v44 = v16; /*0x106714de4*/
  RBX::Network::TimeIntervalMeter::getRatePerSecondAndReset(this: (RBX::Network::ClientReplicator *)((char *)this + 9888)); /*0x106714df3*/
  v45 = v17; /*0x106714df8*/
  RBX::Network::TimeIntervalMeter::getRatePerSecondAndReset(this: (RBX::Network::ClientReplicator *)((char *)this + 9936)); /*0x106714e07*/
  v48 = v18; /*0x106714e0c*/
  v19 = *((_QWORD *)this + 28); /*0x106714e14*/
  v20 = 0.0; /*0x106714e1b*/
  if ( v19 != 0 ) /*0x106714e22*/
    RBX::Network::TimeIntervalMeter::getRatePerSecondAndReset(this: (RBX::Network::TimeIntervalMeter *)(v19 + 56)); /*0x106714e28*/
  v34 = v20; /*0x106714e2d*/
  RBX::Network::TimeIntervalMeter::getRatePerSecondAndReset(this: (RBX::Network::ClientReplicator *)((char *)this + 9968)); /*0x106714e3c*/
  *(_OWORD *)v42 = v21; /*0x106714e41*/
  RBX::Network::TimeIntervalMeter::getRatePerSecondAndReset(this: (RBX::Network::ClientReplicator *)((char *)this + 9952)); /*0x106714e50*/
  v43 = v22; /*0x106714e55*/
  RBX::Network::TimeIntervalMeter::getRatePerSecondAndReset(this: (RBX::Network::ClientReplicator *)((char *)this + 9984)); /*0x106714e64*/
  v35 = v23; /*0x106714e69*/
  RBX::Network::TimeIntervalMeter::getRatePerSecondAndReset(this: (RBX::Network::ClientReplicator *)((char *)this + 10016)); /*0x106714e78*/
  v36 = v24; /*0x106714e7d*/
  RBX::Network::TimeIntervalMeter::getRatePerSecondAndReset(this: (RBX::Network::ClientReplicator *)((char *)this + 10000)); /*0x106714e8f*/
  v46 = v25; /*0x106714e94*/
  RBX::Analytics::InfluxDb::Points::Points(a1: v49, a2: 0xFFFFFFFFLL, a3: 0, a4: 0); /*0x106714eac*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106714ec7*/
    this: (RBX::Analytics::InfluxDb::Points *)v49,
    a2: "Client_SamplePlayer_Facs_AppPacketBytesSendPerSec",
    a3: v48);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106714ee2*/
    this: (RBX::Analytics::InfluxDb::Points *)v49,
    a2: "Client_SamplePlayer_Facs_CountPerSec",
    a3: *(double *)&v43);
  v47 = v47 + *(double *)&v41 + v44 + v45 + v34; /*0x106714f27*/
  v26.f64[0] = v47; /*0x106714f07*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106714f46*/
    this: (RBX::Analytics::InfluxDb::Points *)v49,
    a2: "Client_SamplePlayer_Facs_Bandwidth_Percentage",
    a3: COERCE_DOUBLE(COERCE_UNSIGNED_INT64(_mm_cmplt_sd((__m128d)0LL, v26).f64[0]) & COERCE_UNSIGNED_INT64(v48 / v47 * 100.0)));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106714f61*/
    this: (RBX::Analytics::InfluxDb::Points *)v49,
    a2: "Client_SamplePlayer_Egress_BytesPerSec",
    a3: v47);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106714f84*/
    this: (RBX::Analytics::InfluxDb::Points *)v49,
    a2: "Client_SamplePlayer_Physics_SendBytesPerSec",
    a3: *(double *)&v41 - v48);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106714f9f*/
    this: (RBX::Analytics::InfluxDb::Points *)v49,
    a2: "Client_SamplePlayer_Facs_AppPacketsBytesRecvPerSec",
    a3: *(double *)v42);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106714fba*/
    this: (RBX::Analytics::InfluxDb::Points *)v49,
    a2: "Client_SamplePlayer_Facs_RecvCountPerSec",
    a3: v35);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106714fd5*/
    this: (RBX::Analytics::InfluxDb::Points *)v49,
    a2: "Client_SamplePlayer_Facs_RevOutOfOrderPerSec",
    a3: v36);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106715011*/
    this: (RBX::Analytics::InfluxDb::Points *)v49,
    a2: "Client_SamplePlayer_Facs_IngressBwPercent",
    a3: COERCE_DOUBLE(
      COERCE_UNSIGNED_INT64(_mm_cmplt_sd((__m128d)0LL, (__m128d)*(unsigned __int64 *)&v46).f64[0])
    & COERCE_UNSIGNED_INT64(*(double *)v42 / v46 * 100.0)));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10671502c*/
    this: (RBX::Analytics::InfluxDb::Points *)v49,
    a2: "Client_SamplePlayer_Ingress_BytesPerSec",
    a3: v46);
  if ( DFFlag::ClientNetworkTelemetryRCCChannelName == 1 )
  {
    v28 = SFString::RCCChannelName; /*0x10671503a*/
    v29 = (SFString::RCCChannelName[0] & 1) != 0
        ? *(_QWORD *)&SFString::RCCChannelName[8]
        : SFString::RCCChannelName[0] >> 1;
    if ( v29 != 0 ) /*0x106715053*/
      RBX::Analytics::InfluxDb::Points::addPoint(a1: v49, a2: "rccChannelName", a3: SFString::RCCChannelName); /*0x10671506a*/
  }
  std::string::basic_string[abi:ne200100]<0>(a1: v32, a2: "ClientSamplePlayerBandwidthStats", a3: v27, a4: v28); /*0x10671507d*/
  RBX::Analytics::InfluxDb::Points::report( /*0x106715098*/
    a1: v49,
    a2: v32,
    a3: (unsigned int)DFInt::ClientStatsWithFacsBWPerHundPercent,
    a4: 0);
  if ( ((__int64)v32[0] & 1) != 0 ) /*0x1067150a4*/
    operator delete(a1: (RBX::Memory *)v32[2], a2: v30); /*0x1067150ad*/
  RBX::Analytics::InfluxDb::Points::~Points(this: v49); /*0x1067150b9*/
  return __stack_chk_guard; /*0x1067151f9*/
}

// Address: 0x10671528c | Name: __ZN3RBX7Network16ClientReplicator26sendReplicatorCloseStatsExERNS_9Telemetry20RobloxTelemetryEventE
__int64 __fastcall RBX::Network::ClientReplicator::sendReplicatorCloseStatsEx(
        RBX::Network::ClientReplicator *this,
        RBX::Telemetry::RobloxTelemetryEvent *a2)
{
  double v4; // xmm0_8
  char *v5; // rbx
  RBX::Time *v6; // rdi
  __int64 v7; // rax
  RBX::TaskScheduler *v8; // rdi
  double v10; // [rsp+0h] [rbp-20h]

  RBX::Time::nowFast(this); /*0x10671529c*/
  v10 = v4 - *((double *)this + 1992); /*0x1067152aa*/
  v5 = (char *)a2 + 72; /*0x1067152af*/
  v7 = RBX::Time::epochTime(this: v6); /*0x1067152b3*/
  (**((void (__fastcall ***)(char *, const char *, __int64, __int64, __int64))a2 + 9))( /*0x1067152d4*/
    a1: (char *)a2 + 72,
    a2: "started",
    a3: 7,
    a4: v7,
    a5: 1);
  (*(void (__fastcall **)(char *, const char *, __int64, __int64, double))(*((_QWORD *)a2 + 9) + 16LL))( /*0x1067152f4*/
    a1: (char *)a2 + 72,
    a2: "sessionTime",
    a3: 11,
    a4: 1,
    a5: v10);
  if ( v10 > 0.0 ) /*0x106715304*/
    _mm_sub_pd( /*0x10671531f*/
      (__m128d)_mm_unpacklo_epi32(
                 (__m128i)(unsigned __int64)(RBX::TaskScheduler::cycle(this: v8) - *((_QWORD *)this + 2330)),
                 (__m128i)xmmword_108F2F9A0),
      (__m128d)xmmword_108F2F9B0);
  (*(void (__fastcall **)(char *, const char *, __int64, __int64))(*(_QWORD *)v5 + 16LL))( /*0x106715347*/
    a1: (char *)a2 + 72,
    a2: "heartbeatFps",
    a3: 12,
    a4: 1);
  (*(void (__fastcall **)(char *, const char *, __int64, _QWORD, __int64))(*(_QWORD *)v5 + 40LL))( /*0x10671536a*/
    a1: (char *)a2 + 72,
    a2: "joinCompleteTag",
    a3: 15,
    a4: *((unsigned __int8 *)this + 18701),
    a5: 1);
  (*(void (__fastcall **)(char *, const char *, __int64, _QWORD, __int64))(*(_QWORD *)v5 + 40LL))( /*0x10671538d*/
    a1: (char *)a2 + 72,
    a2: "replicatedFirst",
    a3: 15,
    a4: *((unsigned __int8 *)this + 18408),
    a5: 1);
  (**(void (__fastcall ***)(char *, const char *, __int64, _QWORD, __int64))v5)( /*0x1067153af*/
    a1: (char *)a2 + 72,
    a2: "joinRxBytes",
    a3: 11,
    a4: *((unsigned int *)this + 3913),
    a5: 1);
  return (**(__int64 (__fastcall ***)(char *, const char *, __int64, _QWORD, __int64))v5)( /*0x1067153d8*/
           a1: (char *)a2 + 72,
           a2: "joinRxIgnoreBytes",
           a3: 17,
           a4: *((unsigned int *)this + 3925),
           a5: 1);
}

// Address: 0x1067153e0 | Name: __ZN3RBX7Network16ClientReplicator27trySendMaxBandwidthToServerEv
void __fastcall RBX::Network::ClientReplicator::trySendMaxBandwidthToServer(RBX::Network::ConcurrentRakPeer **this)
{
  __int64 v2; // rax
  int v3; // eax
  int v4; // r14d
  RBX::Player *v5; // rax

  if ( *((_BYTE *)this + 10391) == 0 ) /*0x1067153ee*/
  {
    v2 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *(this + 28)); /*0x1067153fe*/
    v3 = (int)((*(double (__fastcall **)(__int64))(*(_QWORD *)v2 + 640LL))(a1: v2) * 125000.0); /*0x106715417*/
    if ( v3 > 0 ) /*0x10671541d*/
    {
      v4 = v3; /*0x106715431*/
      if ( DFInt::LargeDataSenderMaxBandwidthBps < v3 ) /*0x106715434*/
        v4 = DFInt::LargeDataSenderMaxBandwidthBps; /*0x106715434*/
      if ( DFInt::LargeDataSenderMinBandwidthBps > v3 ) /*0x10671543c*/
        v4 = DFInt::LargeDataSenderMinBandwidthBps; /*0x10671543c*/
      if ( v4 > *((_DWORD *)this + 4680) || *((_DWORD *)this + 4680) > DFInt::LargeDataSenderMaxBandwidthBps ) /*0x10671544e*/
      {
        *((_DWORD *)this + 4680) = v4; /*0x106715457*/
        v5 = (RBX::Player *)(*((__int64 (__fastcall **)(RBX::Network::ConcurrentRakPeer **))*this + 86))(a1: this); /*0x106715464*/
        if ( v5 != nullptr ) /*0x10671546d*/
          RBX::Player::sendMaxClientBandwidthBps(this: v5, a2: v4); /*0x106715479*/
      }
    }
  }
}

// Address: 0x1067158f2 | Name: __ZZN3RBX7Network16ClientReplicator11OnReceiveV2ENS0_14IncomingPacketEEN3$_08__invokeEPvmPKc
size_t __fastcall RBX::Network::ClientReplicator::OnReceiveV2(RBX::Network::IncomingPacket)::$_0::__invoke(
        FILE *a1,
        size_t a2,
        void *a3)
{
  return fwrite(a1: a3, a2: 1u, a3: a2, a4: a1); /*0x106715907*/
}

// Address: 0x10671590e | Name: __ZZN3RBX7Network16ClientReplicator20OnReceive_deprecatedEPN6RakNet6PacketEEN3$_08__invokeEPvmPKc
size_t __fastcall RBX::Network::ClientReplicator::OnReceive_deprecated(RakNet::Packet *)::$_0::__invoke(
        FILE *a1,
        size_t a2,
        void *a3)
{
  return fwrite(a1: a3, a2: 1u, a3: a2, a4: a1); /*0x106715923*/
}

// Address: 0x10671d64a | Name: __ZZN3RBX7Network16ClientReplicator26prepareDumpOrReportProfileEvEN3$_0C1ERKS2_
__int64 __fastcall RBX::Network::ClientReplicator::prepareDumpOrReportProfile(void)::$_0::$_0(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4)
{
  __int64 v6; // rax
  _OWORD *v7; // rdi
  __int64 result; // rax

  v6 = *(_QWORD *)(a2 + 8); /*0x10671d65b*/
  *(_OWORD *)a1 = *(_OWORD *)a2; /*0x10671d662*/
  if ( v6 != 0 ) /*0x10671d668*/
    _InterlockedIncrement64((volatile signed __int64 *)(v6 + 16)); /*0x10671d66a*/
  *(_DWORD *)(a1 + 16) = *(_DWORD *)(a2 + 16); /*0x10671d673*/
  RBX::SmallDenseMap<std::string,std::string,8u,RBX::Analytics::InfluxDb::AnalyticsPointsDenseMapInfo,RBX::detail::DenseMapPair<std::string,std::string>>::SmallDenseMap( /*0x10671d681*/
    a1: (_BYTE *)(a1 + 24),
    a2: a2 + 24,
    a3,
    a4);
  if ( (*(_BYTE *)(a2 + 416) & 1) != 0 ) /*0x10671d697*/
  {
    std::string::__init_copy_ctor_external(a1: a1 + 416, a2: *(_QWORD *)(a2 + 432), a3: *(_QWORD *)(a2 + 424)); /*0x10671d6c0*/
  }
  else
  {
    *(_QWORD *)(a1 + 432) = *(_QWORD *)(a2 + 432); /*0x10671d6a0*/
    *(_OWORD *)(a1 + 416) = *(_OWORD *)(a2 + 416); /*0x10671d6a8*/
  }
  *(_DWORD *)(a1 + 440) = *(_DWORD *)(a2 + 440); /*0x10671d6cc*/
  *(_BYTE *)(a1 + 444) = *(_BYTE *)(a2 + 444); /*0x10671d6d9*/
  v7 = (_OWORD *)(a1 + 448); /*0x10671d6e4*/
  if ( (*(_BYTE *)(a2 + 448) & 1) != 0 ) /*0x10671d6f0*/
  {
    std::string::__init_copy_ctor_external(a1: v7, a2: *(_QWORD *)(a2 + 464), a3: *(_QWORD *)(a2 + 456)); /*0x10671d713*/
  }
  else
  {
    *(_QWORD *)(a1 + 464) = *(_QWORD *)(a2 + 464); /*0x10671d6f9*/
    *v7 = *(_OWORD *)(a2 + 448); /*0x10671d700*/
  }
  *(_QWORD *)(a1 + 472) = *(_QWORD *)(a2 + 472); /*0x10671d71f*/
  result = *(_QWORD *)(a2 + 488); /*0x10671d726*/
  *(_OWORD *)(a1 + 480) = *(_OWORD *)(a2 + 480); /*0x10671d735*/
  if ( result != 0 ) /*0x10671d73f*/
    _InterlockedIncrement64((volatile signed __int64 *)(result + 8)); /*0x10671d741*/
  return result; /*0x10671d746*/
}

// Address: 0x106d6bd56 | Name: __ZNK3RBX7Network16ClientReplicator13getAsInternalENS_10Reflection11InterfaceIdE
__int64 RBX::Network::ClientReplicator::getAsInternal()
{
  return 0; /*0x106d6bd5c*/
}

// Address: 0x106d6bd5e | Name: __ZN3RBX7Network16ClientReplicator35writeAllPropertiesForChangeTrackingEPNS_23DataModelChangeTracking13ChangeTrackerENS2_12DeltaTypeTagE
__int64 RBX::Network::ClientReplicator::writeAllPropertiesForChangeTracking()
{
  return RBX::Network::Replicator::writeAllPropertiesForChangeTracking(); /*0x106d6bd62*/
}

// Address: 0x106d6bf56 | Name: __ZNK3RBX7Network16ClientReplicator16getTargetAddressEv
__int64 __fastcall RBX::Network::ClientReplicator::getTargetAddress(RBX::Network::ClientReplicator *this)
{
  return *((unsigned int *)this + 5500); /*0x106d6bf60*/
}

// Address: 0x106d6bf62 | Name: __ZNK3RBX7Network16ClientReplicator15getRemotePlayerEv
__int64 __fastcall RBX::Network::ClientReplicator::getRemotePlayer(RBX::Network::ClientReplicator *this)
{
  return 0; /*0x106d6bf68*/
}

// Address: 0x106d8548e | Name: __ZN3RBX7Network16ClientReplicator13handleRequestERKNS0_14ReplicatorDataEi
void __fastcall RBX::Network::ClientReplicator::handleRequest(
        RBX::Network::ClientReplicator *this,
        const RBX::Network::ReplicatorData *a2)
{
  ; /*0x106d8548e*/
}

// Address: 0x106d86726 | Name: __ZN3RBX7Network16ClientReplicator20handleRequestGenericERNS0_14ReplicatorDataEj
__int64 __fastcall RBX::Network::ClientReplicator::handleRequestGeneric(
        RBX::Network::ClientReplicator *this,
        RBX::Network::ReplicatorData *a2,
        unsigned int a3)
{
  __int64 v4; // rax
  std::__shared_weak_count *v5; // r13
  std::__shared_weak_count *v6; // rbx
  __int64 v7; // r14
  __int64 v8; // r12
  __int64 v9; // r15
  unsigned __int64 v10; // rdx
  __int64 Aligned; // rax
  __int64 v12; // rdx
  __int64 v13; // r8
  __int64 v14; // r9
  void *v15; // rsi
  __int64 result; // rax
  _QWORD v17[4]; // [rsp+0h] [rbp-B0h] BYREF
  __int128 v18; // [rsp+20h] [rbp-90h]
  unsigned int v19; // [rsp+30h] [rbp-80h]
  __int128 v20; // [rsp+38h] [rbp-78h] BYREF
  __int64 v21; // [rsp+48h] [rbp-68h]
  __int64 v22; // [rsp+50h] [rbp-60h]
  __int64 v23; // [rsp+58h] [rbp-58h]
  std::__shared_weak_count *v24[2]; // [rsp+60h] [rbp-50h] BYREF
  unsigned int v25; // [rsp+7Ch] [rbp-34h]
  __int64 v26; // [rsp+80h] [rbp-30h]

  v26 = *((_QWORD *)a2 + 5); /*0x106d86741*/
  v22 = *((_QWORD *)a2 + 6); /*0x106d86749*/
  v23 = *((_QWORD *)a2 + 7); /*0x106d86751*/
  *(_OWORD *)((char *)a2 + 40) = 0; /*0x106d86758*/
  *((_QWORD *)a2 + 7) = 0; /*0x106d8675c*/
  v4 = RBX::DataModel::get(this, a2); /*0x106d86764*/
  RBX::weak_from<RBX::DataModel>(a1: v24, a2: v4); /*0x106d86770*/
  v5 = v24[0]; /*0x106d86775*/
  v6 = v24[1]; /*0x106d86779*/
  *(_OWORD *)v24 = 0; /*0x106d8678e*/
  v19 = a3; /*0x106d86792*/
  v25 = a3; /*0x106d86796*/
  v7 = v26; /*0x106d8679a*/
  v8 = v22; /*0x106d867a2*/
  v9 = v23; /*0x106d867aa*/
  Aligned = RBX::Memory::allocateAligned(this: (RBX::Memory *)0x30, a2: 8u, a3: v10); /*0x106d867c7*/
  v17[0] = Aligned; /*0x106d867d7*/
  v17[1] = 48; /*0x106d867da*/
  v17[2] = 8; /*0x106d867e2*/
  *(_QWORD *)Aligned = v5; /*0x106d867ea*/
  *(_QWORD *)(Aligned + 8) = v6; /*0x106d867ed*/
  v18 = 0; /*0x106d867f4*/
  v12 = v25; /*0x106d867f8*/
  *(_DWORD *)(Aligned + 16) = v25; /*0x106d867fb*/
  *(_QWORD *)(Aligned + 24) = v7; /*0x106d867fe*/
  *(_QWORD *)(Aligned + 32) = v8; /*0x106d86802*/
  *(_QWORD *)(Aligned + 40) = v9; /*0x106d86806*/
  v20 = 0; /*0x106d8680a*/
  v21 = 0; /*0x106d8680d*/
  v17[3] = (char *)RBX::unique_function<void ()(void),24ul,8ul,true>::unique_function<RBX::Network::ClientReplicator::handleRequestGeneric(RBX::Network::ReplicatorData &,unsigned int)::$_0>(RBX::Network::ClientReplicator::handleRequestGeneric(RBX::Network::ReplicatorData &,unsigned int)::$_0)::Callbacks /*0x106d8681c*/
         + 4;
  RBX::TaskScheduler::submitAsyncTask(a1: v17, a2: 0, a3: v12, a4: &v20, a5: v13, a6: v14); /*0x106d86822*/
  result = RBX::unique_function<void ()(void),24ul,8ul,true>::~unique_function(a1: (__int64)v17, a2: v15); /*0x106d8682e*/
  if ( v24[1] != nullptr ) /*0x106d8683a*/
    return std::__shared_weak_count::__release_weak(this: v24[1]); /*0x106d8683c*/
  return result; /*0x106d86841*/
}

// Address: 0x106d8689e | Name: __ZZN3RBX7Network16ClientReplicator20handleRequestGenericERNS0_14ReplicatorDataEjEN3$_0D1Ev
void __fastcall RBX::Network::ClientReplicator::handleRequestGeneric(RBX::Network::ReplicatorData &,unsigned int)::$_0::~$_0(
        _QWORD *a1,
        void *a2)
{
  RBX::Memory *v3; // rdi
  std::__shared_weak_count *v4; // rdi

  v3 = (RBX::Memory *)a1[3]; /*0x106d868a7*/
  if ( v3 != nullptr ) /*0x106d868ae*/
  {
    a1[4] = v3; /*0x106d868b0*/
    operator delete(a1: v3, a2); /*0x106d868b4*/
  }
  v4 = (std::__shared_weak_count *)a1[1]; /*0x106d868b9*/
  if ( v4 != nullptr ) /*0x106d868c4*/
    std::__shared_weak_count::__release_weak(this: v4); /*0x106d868c8*/
}

// Address: 0x1087603b4 | Name: __ZN3RBX7Network16ClientReplicator25writeAttributeVersionInfoERNS0_13NetworkStreamEPKNS_8InstanceERKNSt3__112basic_stringIcNS7_11char_traitsIcEENS7_9allocatorIcEEEE.cold.1
void __fastcall RBX::Network::ClientReplicator::writeAttributeVersionInfo(__int64 a1, void *a2)
{
  if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x1087603b7*/
    operator delete(a1: *(RBX::Memory **)(a1 + 16), a2); /*0x1087603c1*/
}

// Address: 0x1087603c8 | Name: __ZN3RBX7Network16ClientReplicator24readChangedAttributeItemEPNS0_31DeserializedChangeAttributeItemE.cold.1
void __fastcall RBX::Network::ClientReplicator::readChangedAttributeItem(
        RBX::Memory **this,
        RBX::Network::DeserializedChangeAttributeItem *a2)
{
  if ( (*(_BYTE *)this & 1) != 0 ) /*0x1087603cb*/
    operator delete(a1: *(this + 2), a2); /*0x1087603d5*/
}

// END ClientReplicator part 1/1, 175 functions
