// Replicator -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 70 functions, part 2 of 2


// Address: 0x1068588be | Name: __ZN3RBX7Network10Replicator22isLegalReceivePropertyEPNS_6ObjectERKNS_10Reflection18PropertyDescriptorE
char __fastcall RBX::Network::Replicator::isLegalReceiveProperty(
        RBX::Network::Replicator *this,
        RBX::Object *a2,
        const RBX::Reflection::PropertyDescriptor *a3)
{
  return 1; /*0x1068588c4*/
}

// Address: 0x1068588c6 | Name: __ZN3RBX7Network10Replicator40reportVariantCountRateReportLimitReachedEv
__int64 __fastcall RBX::Network::Replicator::reportVariantCountRateReportLimitReached(
        RBX::Network::Replicator *this,
        int a2)
{
  float v3; // xmm0_4
  __int64 v4; // rdx
  __int64 v5; // rcx
  _BYTE v7[16]; // [rsp+0h] [rbp-200h] BYREF
  void *v8; // [rsp+10h] [rbp-1F0h]
  void *v9[59]; // [rsp+18h] [rbp-1E8h] BYREF

  if ( (unsigned __int8)RBX::Analytics::InfluxDb::canSend( /*0x1068588f0*/
                          this: (RBX::Analytics::InfluxDb *)(unsigned int)DFInt::ReplicatorVariantSpeedReportPerHundredthPercentage,
                          a2) != 0 )
  {
    RBX::Analytics::InfluxDb::Points::Points( /*0x106858907*/
      a1: v9,
      a2: (unsigned int)DFInt::ReplicatorVariantSpeedReportPerHundredthPercentage,
      a3: 0,
      a4: 0);
    RBX::LeakyBucket::getLevel(this: (RBX::Network::Replicator *)((char *)this + 12376)); /*0x106858916*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: (RBX::Analytics::InfluxDb::Points *)v9, a2: "Rate", a3: v3); /*0x10685892d*/
    std::string::basic_string[abi:ne200100]<0>(a1: v7, a2: "ReadVariantCountSpeedExceededReport", a3: v4, a4: v5); /*0x106858940*/
    RBX::Analytics::InfluxDb::Points::report( /*0x10685895b*/
      a1: v9,
      a2: v7,
      a3: (unsigned int)DFInt::ReplicatorVariantSpeedReportPerHundredthPercentage,
      a4: 0);
    if ( (v7[0] & 1) != 0 ) /*0x106858967*/
      operator delete(a1: v8); /*0x106858970*/
    RBX::Analytics::InfluxDb::Points::~Points(this: v9); /*0x10685897c*/
  }
  return __stack_chk_guard; /*0x106858991*/
}

// Address: 0x1068589da | Name: __ZN3RBX7Network10Replicator38reportVariantCountRateKickLimitReachedEv
__int64 __fastcall RBX::Network::Replicator::reportVariantCountRateKickLimitReached(
        RBX::Network::Replicator *this,
        int a2)
{
  float v3; // xmm0_4
  __int64 v4; // rdx
  __int64 v5; // rcx
  _BYTE v7[16]; // [rsp+0h] [rbp-200h] BYREF
  void *v8; // [rsp+10h] [rbp-1F0h]
  void *v9[59]; // [rsp+18h] [rbp-1E8h] BYREF

  if ( (unsigned __int8)RBX::Analytics::InfluxDb::canSend( /*0x106858a04*/
                          this: (RBX::Analytics::InfluxDb *)(unsigned int)DFInt::ReplicatorVariantSpeedKickReportPerHundredthPercentage,
                          a2) != 0 )
  {
    RBX::Analytics::InfluxDb::Points::Points( /*0x106858a1b*/
      a1: v9,
      a2: (unsigned int)DFInt::ReplicatorVariantSpeedKickReportPerHundredthPercentage,
      a3: 0,
      a4: 0);
    RBX::LeakyBucket::getLevel(this: (RBX::Network::Replicator *)((char *)this + 12320)); /*0x106858a2a*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: (RBX::Analytics::InfluxDb::Points *)v9, a2: "Rate", a3: v3); /*0x106858a41*/
    std::string::basic_string[abi:ne200100]<0>(a1: v7, a2: "ReadVariantCountSpeedExceededKicked", a3: v4, a4: v5); /*0x106858a54*/
    RBX::Analytics::InfluxDb::Points::report( /*0x106858a6f*/
      a1: v9,
      a2: v7,
      a3: (unsigned int)DFInt::ReplicatorVariantSpeedKickReportPerHundredthPercentage,
      a4: 0);
    if ( (v7[0] & 1) != 0 ) /*0x106858a7b*/
      operator delete(a1: v8); /*0x106858a84*/
    RBX::Analytics::InfluxDb::Points::~Points(this: v9); /*0x106858a90*/
  }
  return __stack_chk_guard; /*0x106858aa5*/
}

// Address: 0x106858aec | Name: __ZNK3RBX7Network10Replicator23useConfigurablePropSyncEv
__int64 __fastcall RBX::Network::Replicator::useConfigurablePropSync(RBX::Network::Replicator *this)
{
  return (*(__int64 (__fastcall **)(RBX::Network::Replicator *))(*(_QWORD *)this + 1032LL))(a1: this);
}

// Address: 0x106858afa | Name: __ZN3RBX7Network10Replicator40accumulateAndCheckVariantRecvSpeedBucketERNS0_36ReplicationVariantSizeLimitsMetaDataE
__int64 __fastcall RBX::Network::Replicator::accumulateAndCheckVariantRecvSpeedBucket(
        RBX::Network::Replicator *this,
        __int64 a2)
{
  int v4; // esi
  __int64 result; // rax
  int v6; // esi
  char *exception; // rbx
  __int128 v8; // [rsp+0h] [rbp-30h] BYREF
  __int64 v9; // [rsp+10h] [rbp-20h]

  if ( (unsigned __int8)RBX::LeakyBucket::checkAdd( /*0x106858b21*/
                          this: (RBX::Network::Replicator *)((char *)this + 12376),
                          a2: (float)*(int *)(a2 + 4)) == 0 )
    RBX::Network::Replicator::reportVariantCountRateReportLimitReached(this, a2: v4); /*0x106858b26*/
  result = RBX::LeakyBucket::checkAdd( /*0x106858b3e*/
             this: (RBX::Network::Replicator *)((char *)this + 12320),
             a2: (float)*(int *)(a2 + 4));
  if ( (_BYTE)result == 0 )
  {
    result = RBX::Network::Replicator::reportVariantCountRateKickLimitReached(this, a2: v6); /*0x106858b4a*/
    if ( DFFlag::ReplicatorKickRecvVariantSpeed == 1 )
    {
      exception = (char *)__cxa_allocate_exception(thrown_size: 0x20u); /*0x106858b6b*/
      RBX::format(this: (RBX *)&v8, a2: "Replicator receive variant: Variant speed exceeded limit!");
      *(_QWORD *)exception = off_10CAA98E0; /*0x106858b87*/
      *((_QWORD *)exception + 3) = v9; /*0x106858b8e*/
      *(_OWORD *)(exception + 8) = v8; /*0x106858b96*/
      v8 = 0; /*0x106858b9d*/
      v9 = 0; /*0x106858ba1*/
      __cxa_throw( /*0x106858bba*/
        a1: exception,
        lptinfo: (struct type_info *)&`typeinfo for'RBX::network_stream_exception,
        a3: RBX::network_stream_exception::~network_stream_exception);
    }
  }
  return result; /*0x106858b58*/
}

// Address: 0x106858be8 | Name: __ZN3RBX7Network10Replicator35incrementFacsIngressOutOfOrderCountEv
void __fastcall RBX::Network::Replicator::incrementFacsIngressOutOfOrderCount(RBX::Network::Replicator *this)
{
  ++*((_QWORD *)this + 2680); /*0x106858bec*/
  ++*((_QWORD *)this + 1252); /*0x106858bf3*/
}

// Address: 0x106858bfc | Name: __ZNK3RBX7Network10Replicator28getFacsReplicationCapabilityEv
__int64 __fastcall RBX::Network::Replicator::getFacsReplicationCapability(RBX::Network::Replicator *this)
{
  RBX::AvatarChatService *v2; // rax
  unsigned int v3; // ebx
  RBX::AvatarChatService *v4; // r15
  __int64 v5; // rax
  __int64 v6; // r15
  std::__shared_weak_count *v7; // r12
  int v8; // edx
  int v9; // eax
  int v10; // edi
  unsigned int v11; // ecx
  _BYTE v13[8]; // [rsp+0h] [rbp-30h] BYREF
  std::__shared_weak_count *v14; // [rsp+8h] [rbp-28h]

  v2 = (RBX::AvatarChatService *)RBX::ServiceProvider::find<RBX::AvatarChatService>(); /*0x106858c0e*/
  if ( *((_BYTE *)this + 11265) == 1 ) /*0x106858c1b*/
  {
    return 2 * (unsigned int)*((unsigned __int8 *)this + 11264); /*0x106858c25*/
  }
  else
  {
    v4 = v2; /*0x106858c2c*/
    v3 = 0; /*0x106858c2f*/
    if ( v2 != nullptr /*0x106858c59*/
      && (unsigned __int8)RBX::AvatarChatService::isPlaceEnabled(this: v2) != 0
      && (*(__int64 (__fastcall **)(RBX::Network::Replicator *))(*(_QWORD *)this + 688LL))(a1: this) != 0 )
    {
      v5 = (*(__int64 (__fastcall **)(RBX::Network::Replicator *))(*(_QWORD *)this + 688LL))(a1: this); /*0x106858c65*/
      RBX::shared_from<RBX::Player>(a1: v13, a2: v5); /*0x106858c75*/
      v6 = RBX::AvatarChatService::pollClientFeatures(this: v4); /*0x106858c85*/
      v7 = v14; /*0x106858c88*/
      if ( v14 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v14 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106858ca2*/
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(a1: v7); /*0x106858cab*/
        std::__shared_weak_count::__release_weak(this: v7); /*0x106858cb1*/
      }
      if ( (v6 & 0x100000000LL) != 0 ) /*0x106858cbb*/
      {
        v8 = *((_DWORD *)this + 69); /*0x106858cbd*/
        v9 = 80; /*0x106858cc7*/
        v10 = 160; /*0x106858cd1*/
        if ( v8 == 1 ) /*0x106858cd6*/
          v10 = 80; /*0x106858cd6*/
        v11 = 2; /*0x106858cd9*/
        if ( ((unsigned int)v6 & v10) != 0 ) /*0x106858ce1*/
          return v11; /*0x106858ce1*/
        if ( v8 == 1 ) /*0x106858ce6*/
          v9 = 160; /*0x106858ce6*/
        v11 = 1; /*0x106858ce9*/
        if ( ((unsigned int)v6 & v9) != 0 ) /*0x106858cf1*/
          return v11; /*0x106858cf3*/
      }
    }
  }
  return v3; /*0x106858cf7*/
}

// Address: 0x106858d38 | Name: __ZNK3RBX7Network10Replicator15canSendFacsDataEv
bool __fastcall RBX::Network::Replicator::canSendFacsData(RBX::Network::Replicator *this)
{
  return (unsigned int)RBX::Network::Replicator::getFacsReplicationCapability(this) == 2; /*0x106858d47*/
}

// Address: 0x106858d4a | Name: __ZN3RBX7Network10Replicator17getLatencyMetricsEv
__int64 __fastcall RBX::Network::Replicator::getLatencyMetrics(RBX::Network::Replicator *this)
{
  RBX::Network::Server *v1; // rax

  v1 = (RBX::Network::Server *)(*(__int64 (__fastcall **)(RBX::Network::Replicator *))(*(_QWORD *)this + 1352LL))(a1: this); /*0x106858d51*/
  return RBX::Network::Server::getLatencyMetrics(this: v1); /*0x106858d5a*/
}

// Address: 0x106858d60 | Name: __ZNK3RBX7Network10Replicator27isInServerAuthoritativeModeEv
bool __fastcall RBX::Network::Replicator::isInServerAuthoritativeMode(RBX::Network::Replicator *this)
{
  _BYTE *EngineNetConfiguration; // rcx
  bool result; // al

  EngineNetConfiguration = (_BYTE *)RBX::Network::NetworkSchema::getEngineNetConfiguration(this: (RBX::Network::NetworkSchema *)(*((_QWORD *)this + 1801) + 1608LL)); /*0x106858d78*/
  result = true; /*0x106858d82*/
  if ( FFlag::DebugHashTableMetrics == 0 ) /*0x106858d87*/
    return FFlag::SAuthWorkspaceFlagged == 1 && (*EngineNetConfiguration & 8) != 0; /*0x106858d99*/
  return result; /*0x106858da0*/
}

// Address: 0x106858da2 | Name: __ZNK3RBX7Network10Replicator35updateAndReturnBandwidthEstimateBpsEv
__int64 __fastcall RBX::Network::Replicator::updateAndReturnBandwidthEstimateBps(RBX::Network::Replicator *this)
{
  (*(void (__fastcall **)(_QWORD))(**((_QWORD **)this + 35) + 200LL))(a1: *((_QWORD *)this + 35)); /*0x106858db5*/
  return *(_QWORD *)(*((_QWORD *)this + 35) + 1400LL); /*0x106858dcd*/
}

// Address: 0x10685951a | Name: __ZN3RBX7Network10Replicator17fireAndForgetSendENS0_11NetAssetRefE
void __fastcall RBX::Network::Replicator::fireAndForgetSend(__int64 a1)
{
  __int64 v1; // rbx
  _BYTE v2[64]; // [rsp+0h] [rbp-40h] BYREF

  v1 = *(_QWORD *)(a1 + 11200); /*0x106859525*/
  RBX::Network::NetAssetRef::NetAssetRef(a1: v2); /*0x106859533*/
  RBX::Network::LargeReplicator::fireAndForgetSend(a1: v1, a2: v2); /*0x10685953e*/
  RBX::Network::NetAssetRef::~NetAssetRef(this: (RBX::Network::NetAssetRef *)v2); /*0x106859547*/
}

// Address: 0x10685956a | Name: __ZThn216_N3RBX7Network10Replicator17fireAndForgetSendENS0_11NetAssetRefE
void __fastcall `non-virtual thunk to'RBX::Network::Replicator::fireAndForgetSend(__int64 a1)
{
  RBX::Network::Replicator::fireAndForgetSend(a1: a1 - 216); /*0x106859576*/
}

// Address: 0x10685957c | Name: __ZNK3RBX7Network10Replicator27getDebugIdleTimeoutDisabledEv
bool __fastcall RBX::Network::Replicator::getDebugIdleTimeoutDisabled(RBX::Network::Replicator *this)
{
  return (*((_BYTE *)this + 15561) & 4) != 0; /*0x10685958b*/
}

// Address: 0x106859680 | Name: __ZN3RBX7Network10Replicator26cacheConvexDecompHolderRefENS0_11NetAssetRefE
void __fastcall RBX::Network::Replicator::cacheConvexDecompHolderRef(__int64 a1, __int64 a2)
{
  __int16 v4; // r15
  char v5; // r14
  unsigned __int8 isValid; // al
  __int64 v7; // rcx
  const RBX::ConvexDecompHolder *v8; // r14
  unsigned __int8 *Contents; // rax
  unsigned int v10; // ecx
  unsigned __int64 v11; // rcx
  RBX::Network::SharedStringSynchronizer *v12; // rbx
  unsigned __int64 v13; // rax
  std::__shared_weak_count *v14; // rbx
  _BYTE v15[48]; // [rsp+8h] [rbp-58h] BYREF
  __int64 v16; // [rsp+38h] [rbp-28h]
  std::__shared_weak_count *v17; // [rsp+40h] [rbp-20h]

  if ( (~*(_QWORD *)(a1 + 15560) & 0x100020000000LL) != 0 ) /*0x1068596a4*/
    return; /*0x1068596a4*/
  if ( *(_DWORD *)(a1 + 276) != 0 ) /*0x1068596b4*/
    return; /*0x1068596b4*/
  if ( *(_BYTE *)(a1 + 18409) != 0 ) /*0x1068596c1*/
    return; /*0x1068596c1*/
  v4 = *(_WORD *)(a2 + 32); /*0x1068596ca*/
  if ( v4 != (unsigned __int16)RBX::Network::getNetAssetType<RBX::ConvexDecompHolder>() ) /*0x1068596d8*/
    return; /*0x1068596d8*/
  RBX::Network::NetAssetTypeRef<RBX::ConvexDecompHolder>::NetAssetTypeRef(a1: v15, a2); /*0x1068596e8*/
  v5 = FFlag::NetAssetClonePendingFix; /*0x1068596f4*/
  isValid = RBX::Network::NetAssetRef::isValid(this: (RBX::Network::NetAssetRef *)v15); /*0x1068596fa*/
  if ( (isValid & (unsigned __int8)v5) == 1 )
  {
    v7 = v16; /*0x106859709*/
    if ( v16 == 0 ) /*0x106859710*/
      goto LABEL_15; /*0x106859710*/
LABEL_9:
    v8 = *(const RBX::ConvexDecompHolder **)(v7 + 8); /*0x10685972b*/
    if ( v8 != nullptr )
    {
      Contents = (unsigned __int8 *)RBX::SharedString::getContents(this: *(RBX::SharedString **)(v7 + 8)); /*0x106859737*/
      v10 = *Contents; /*0x10685973c*/
      v11 = (v10 & 1) != 0 ? *((_QWORD *)Contents + 1) : v10 >> 1;
      if ( v11 >= DFInt::MinSizeToCacheSharedStringBytes ) /*0x106859756*/
      {
        v12 = *(RBX::Network::SharedStringSynchronizer **)(a1 + 15416); /*0x106859758*/
        v13 = RBX::ConvexDecompHolder::hash(this: *(RBX::ConvexDecompHolder **)(v16 + 8)); /*0x106859767*/
        RBX::Network::SharedStringSynchronizer::writeConvexDecompHolderToInstanceDataTable(this: v12, a2: v8, a3: v13); /*0x106859775*/
      }
    }
    goto LABEL_15; /*0x106859775*/
  }
  v7 = v16; /*0x106859716*/
  if ( (((isValid & 1) == 0 || v16 == 0) | v5 & 1) == 0 ) /*0x106859729*/
    goto LABEL_9; /*0x106859729*/
LABEL_15:
  v14 = v17; /*0x10685977a*/
  if ( v17 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v17 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106859793*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v14 + 16LL))(a1: v14); /*0x10685979b*/
    std::__shared_weak_count::__release_weak(this: v14); /*0x1068597a1*/
  }
  RBX::Network::NetAssetRef::~NetAssetRef(this: (RBX::Network::NetAssetRef *)v15); /*0x1068597aa*/
}

// Address: 0x1068597da | Name: __ZN3RBX7Network10Replicator31loadConvexDecompHolderFromCacheERNS0_14NetAssetHandleEPNS0_15NetAssetManagerE
void __fastcall RBX::Network::Replicator::loadConvexDecompHolderFromCache(
        __int64 a1,
        __int64 a2,
        RBX::Network::NetAssetManager *a3)
{
  __int64 TypeManager; // rax
  __int64 v6; // r14
  RBX::Network::SharedStringSynchronizer *v7; // r12
  unsigned __int64 HashFromNetAssetId; // rax
  RBX::SharedString **ConvexDecompHolderFromCache; // rax
  RBX::SharedString *v10; // r12
  unsigned __int8 *Contents; // rax
  unsigned int v12; // ecx
  unsigned __int64 v13; // rcx
  RBX::Network::SharedStringSynchronizer *v14; // r13
  unsigned __int64 v15; // rax
  void *v16; // r14
  std::__shared_weak_count *v17; // rbx
  _BYTE v18[56]; // [rsp+0h] [rbp-70h] BYREF
  std::__shared_weak_count *v19; // [rsp+38h] [rbp-38h]
  void *v20; // [rsp+40h] [rbp-30h] BYREF

  TypeManager = RBX::Network::NetAssetManager::getTypeManager(this: a3, a2: *(_WORD *)(a2 + 16)); /*0x1068597f8*/
  if ( TypeManager != 0 ) /*0x106859800*/
  {
    v6 = TypeManager; /*0x106859806*/
    if ( (unsigned __int8)RBX::Network::NetAssetManagerForType::assetExists(a1: TypeManager) == 0 ) /*0x106859816*/
    {
      v7 = *(RBX::Network::SharedStringSynchronizer **)(a1 + 15416); /*0x10685981c*/
      HashFromNetAssetId = RBX::Network::getHashFromNetAssetId(a1: a2); /*0x106859826*/
      ConvexDecompHolderFromCache = (RBX::SharedString **)RBX::Network::SharedStringSynchronizer::getConvexDecompHolderFromCache( /*0x106859831*/
                                                            this: v7,
                                                            a2: HashFromNetAssetId);
      v10 = *ConvexDecompHolderFromCache; /*0x106859836*/
      *ConvexDecompHolderFromCache = nullptr; /*0x106859839*/
      Contents = (unsigned __int8 *)RBX::SharedString::getContents(this: v10); /*0x106859843*/
      v12 = *Contents; /*0x106859848*/
      if ( (v12 & 1) != 0 ) /*0x10685984e*/
        v13 = *((_QWORD *)Contents + 1); /*0x106859850*/
      else
        v13 = v12 >> 1; /*0x106859856*/
      if ( v13 >= DFInt::MinSizeToCacheSharedStringBytes ) /*0x106859862*/
      {
        v14 = *(RBX::Network::SharedStringSynchronizer **)(a1 + 15416); /*0x106859864*/
        v15 = RBX::Network::getHashFromNetAssetId(a1: a2); /*0x10685986e*/
        RBX::Network::SharedStringSynchronizer::writeConvexDecompHolderToInstanceDataTable(this: v14, a2: v10, a3: v15); /*0x10685987c*/
      }
      v20 = v10; /*0x106859885*/
      RBX::Network::NetAssetManagerForType::loadNetworkedAssetFromLocalCache<RBX::ConvexDecompHolder>( /*0x10685989c*/
        a1: v18,
        a2: v6,
        a3: &v20,
        a4: *(unsigned int *)(a1 + 192),
        a5: *(unsigned int *)(a1 + 196));
      v16 = v20; /*0x1068598a1*/
      v20 = nullptr; /*0x1068598a5*/
      if ( v16 != nullptr ) /*0x1068598b0*/
      {
        RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: v16); /*0x1068598b5*/
        operator delete(a1: v16); /*0x1068598bd*/
      }
      if ( FFlag::LrRegisterCachedAssetInReceiver == 1 ) /*0x1068598cc*/
        RBX::Network::LargeReplicator::registerCachedAssetInReceiver( /*0x1068598d9*/
          this: *(RBX::Network::LargeReplicator **)(a1 + 11200),
          a2: (const RBX::Network::NetAssetRef *)v18);
      v17 = v19; /*0x1068598de*/
      if ( v19 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v19 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1068598f7*/
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v17 + 16LL))(a1: v17); /*0x1068598ff*/
        std::__shared_weak_count::__release_weak(this: v17); /*0x106859905*/
      }
      RBX::Network::NetAssetRef::~NetAssetRef(this: (RBX::Network::NetAssetRef *)v18); /*0x10685990e*/
    }
  }
}

// Address: 0x10689be64 | Name: __ZN3RBX7Network10Replicator21isLegalDeleteInstanceEPNS_8InstanceE
char __fastcall RBX::Network::Replicator::isLegalDeleteInstance(RBX::Network::Replicator *this, RBX::Instance *a2)
{
  return 1; /*0x10689be6a*/
}

// Address: 0x10689c2cc | Name: __ZN3RBX7Network10Replicator33isLegalReceiveNewInstancePropertyEPNS_6ObjectERKNS_10Reflection18PropertyDescriptorE
char __fastcall RBX::Network::Replicator::isLegalReceiveNewInstanceProperty(
        RBX::Network::Replicator *this,
        RBX::Object *a2,
        const RBX::Reflection::PropertyDescriptor *a3)
{
  return 1; /*0x10689c2d2*/
}

// Address: 0x10689c310 | Name: __ZN3RBX7Network10Replicator44isLegalReceiveNewInstanceProperty_DEPRECATEDERKNS_10Reflection18PropertyDescriptorE
char __fastcall RBX::Network::Replicator::isLegalReceiveNewInstanceProperty_DEPRECATED(
        RBX::Network::Replicator *this,
        const RBX::Reflection::PropertyDescriptor *a2)
{
  return 1; /*0x10689c316*/
}

// Address: 0x1068a7fa4 | Name: __ZN3RBX7Network10Replicator26updateUnprocessedItemStatsERKNS0_16DeserializedItemE
void __fastcall RBX::Network::Replicator::updateUnprocessedItemStats(
        RBX::Network::Replicator *this,
        const RBX::Network::DeserializedItem *a2)
{
  ; /*0x1068a7fa4*/
}

// Address: 0x1068a7fac | Name: __ZN3RBX7Network10Replicator26postProcessReceivedPacketsEv
void __fastcall RBX::Network::Replicator::postProcessReceivedPackets(RBX::Network::Replicator *this)
{
  ; /*0x1068a7fac*/
}

// Address: 0x1068a7fb4 | Name: __ZN3RBX7Network10Replicator25preProcessReceivedPacketsEv
void __fastcall RBX::Network::Replicator::preProcessReceivedPackets(RBX::Network::Replicator *this)
{
  ; /*0x1068a7fb4*/
}

// Address: 0x1068a7fbc | Name: __ZN3RBX7Network10Replicator29shouldRateLimitTxRemoteEventsEPKNS_6ObjectERKNS_10Reflection15EventDescriptorERKNSt3__16vectorINS5_7VariantENS9_9allocatorISB_EEEE
__int64 RBX::Network::Replicator::shouldRateLimitTxRemoteEvents()
{
  return 0; /*0x1068a7fc2*/
}

// Address: 0x1068a7fc4 | Name: __ZN3RBX7Network10Replicator13processQLimitEv
void __fastcall RBX::Network::Replicator::processQLimit(RBX::Network::Replicator *this)
{
  ; /*0x1068a7fc4*/
}

// Address: 0x1068a7fcc | Name: __ZN3RBX7Network10Replicator25preserveForwardRefsToGuidENS_4GuidEb
void RBX::Network::Replicator::preserveForwardRefsToGuid()
{
  ; /*0x1068a7fcc*/
}

// Address: 0x1068a7fd4 | Name: __ZN3RBX7Network10Replicator16doSecurityChecksEv
void __fastcall RBX::Network::Replicator::doSecurityChecks(RBX::Network::Replicator *this)
{
  ; /*0x1068a7fd4*/
}

// Address: 0x1068a7fdc | Name: __ZN3RBX7Network10Replicator24recordRegionRemovalStatsEjj
void __fastcall RBX::Network::Replicator::recordRegionRemovalStats(RBX::Network::Replicator *this)
{
  ; /*0x1068a7fdc*/
}

// Address: 0x1068a7fe4 | Name: __ZNK3RBX7Network10Replicator24isDuplicateOfLocalPlayerERKNS_6PlayerE
__int64 __fastcall RBX::Network::Replicator::isDuplicateOfLocalPlayer(
        RBX::Network::Replicator *this,
        const RBX::Player *a2)
{
  return 0; /*0x1068a7fea*/
}

// Address: 0x1068a7fec | Name: __ZN3RBX7Network10Replicator21isLegalReceiveTerrainEPNS_8InstanceE
char __fastcall RBX::Network::Replicator::isLegalReceiveTerrain(RBX::Network::Replicator *this, RBX::Instance *a2)
{
  return 1; /*0x1068a7ff2*/
}

// Address: 0x1068a7ff4 | Name: __ZN3RBX7Network10Replicator19isLegalReceiveEventEPNS_6ObjectERKNS_10Reflection15EventDescriptorE
char __fastcall RBX::Network::Replicator::isLegalReceiveEvent(
        RBX::Network::Replicator *this,
        RBX::Object *a2,
        const RBX::Reflection::EventDescriptor *a3)
{
  return 1; /*0x1068a7ffa*/
}

// Address: 0x1068a7ffc | Name: __ZN3RBX7Network10Replicator23isLegalReceiveAttributeEv
char __fastcall RBX::Network::Replicator::isLegalReceiveAttribute(RBX::Network::Replicator *this)
{
  return 1; /*0x1068a8002*/
}

// Address: 0x1068a8004 | Name: __ZN3RBX7Network10Replicator17isLegalSendObjectEPKNS_6ObjectE
char __fastcall RBX::Network::Replicator::isLegalSendObject(RBX::Network::Replicator *this, const RBX::Object *a2)
{
  return 1; /*0x1068a800a*/
}

// Address: 0x1068a800c | Name: __ZN3RBX7Network10Replicator16isLegalSendEventEPNS_6ObjectERKNS_10Reflection15EventDescriptorE
char __fastcall RBX::Network::Replicator::isLegalSendEvent(
        RBX::Network::Replicator *this,
        RBX::Object *a2,
        const RBX::Reflection::EventDescriptor *a3)
{
  return 1; /*0x1068a8012*/
}

// Address: 0x1068a8014 | Name: __ZNK3RBX7Network10Replicator11isCloudEditEv
__int64 __fastcall RBX::Network::Replicator::isCloudEdit(RBX::Network::Replicator *this)
{
  return 0; /*0x1068a801a*/
}

// Address: 0x1068a801c | Name: __ZN3RBX7Network10Replicator20checkUnprocessedSizeEv
void __fastcall RBX::Network::Replicator::checkUnprocessedSize(RBX::Network::Replicator *this)
{
  ; /*0x1068a801c*/
}

// Address: 0x1068a8024 | Name: __ZN3RBX7Network10Replicator20stageGraphParamRelayEPNS0_31DeserializedEventInvocationItemE
void __fastcall RBX::Network::Replicator::stageGraphParamRelay(
        RBX::Network::Replicator *this,
        RBX::Network::DeserializedEventInvocationItem *a2)
{
  ; /*0x1068a8024*/
}

// Address: 0x1068a802c | Name: __ZN3RBX7Network10Replicator22replicatorOnChildAddedERKNSt3__110shared_ptrINS_8InstanceEEE
void RBX::Network::Replicator::replicatorOnChildAdded()
{
  ; /*0x1068a802c*/
}

// Address: 0x1068a8034 | Name: __ZN3RBX7Network10Replicator9onSentTagENS0_11TagItemTypeE
void RBX::Network::Replicator::onSentTag()
{
  ; /*0x1068a8034*/
}

// Address: 0x1068a803c | Name: __ZN3RBX7Network10Replicator16processSendStatsEjj
void __fastcall RBX::Network::Replicator::processSendStats(RBX::Network::Replicator *this)
{
  ; /*0x1068a803c*/
}

// Address: 0x1068a8044 | Name: __ZNK3RBX7Network10Replicator9getServerEv
__int64 __fastcall RBX::Network::Replicator::getServer(RBX::Network::Replicator *this)
{
  return 0; /*0x1068a804a*/
}

// Address: 0x1068a804c | Name: __ZNK3RBX7Network10Replicator16serializeSFFlagsERNS0_13NetworkStreamE
void __fastcall RBX::Network::Replicator::serializeSFFlags(
        RBX::Network::Replicator *this,
        RBX::Network::NetworkStream *a2)
{
  ; /*0x1068a804c*/
}

// Address: 0x1068a8054 | Name: __ZN3RBX7Network10Replicator14isClassRemovedEPKNS_8InstanceE
__int64 __fastcall RBX::Network::Replicator::isClassRemoved(RBX::Network::Replicator *this, const RBX::Instance *a2)
{
  return 0; /*0x1068a805a*/
}

// Address: 0x1068a805c | Name: __ZN3RBX7Network10Replicator17isPropertyRemovedEPKNS_8InstanceERKNS_4NameE
__int64 __fastcall RBX::Network::Replicator::isPropertyRemoved(
        RBX::Network::Replicator *this,
        const RBX::Instance *a2,
        const RBX::Name *a3)
{
  return 0; /*0x1068a8062*/
}

// Address: 0x1068a8064 | Name: __ZN3RBX7Network10Replicator14isEventRemovedEPKNS_8InstanceERKNS_4NameE
__int64 __fastcall RBX::Network::Replicator::isEventRemoved(
        RBX::Network::Replicator *this,
        const RBX::Instance *a2,
        const RBX::Name *a3)
{
  return 0; /*0x1068a806a*/
}

// Address: 0x1068a806c | Name: __ZN3RBX7Network10Replicator30ProcessOutdatedChangedPropertyERNS0_13NetworkStreamERKNS_4GuidEPKNS_8InstanceEPKNS_10Reflection18PropertyDescriptorEj
__int64 __fastcall RBX::Network::Replicator::ProcessOutdatedChangedProperty(
        RBX::Network::Replicator *this,
        RBX::Network::NetworkStream *a2,
        const RBX::Guid *a3,
        const RBX::Instance *a4,
        const RBX::Reflection::PropertyDescriptor *a5)
{
  return 0; /*0x1068a8072*/
}

// Address: 0x1068a8074 | Name: __ZN3RBX7Network10Replicator25ProcessOutdatedPropertiesERNS0_13NetworkStreamEPNS_8InstanceENS1_17PropertyCacheTypeEbbPNSt3__16vectorINS0_13PropValuePairENS7_9allocatorIS9_EEEE
__int64 RBX::Network::Replicator::ProcessOutdatedProperties()
{
  return 0; /*0x1068a807a*/
}

// Address: 0x1068a807c | Name: __ZN3RBX7Network10Replicator23ProcessOutdatedInstanceERNS0_13NetworkStreamEbRKNS_4GuidEPKNS_10Reflection15ClassDescriptorEj
__int64 __fastcall RBX::Network::Replicator::ProcessOutdatedInstance(
        RBX::Network::Replicator *this,
        RBX::Network::NetworkStream *a2,
        bool a3,
        const RBX::Guid *a4,
        const RBX::Reflection::ClassDescriptor *a5)
{
  return 0; /*0x1068a8082*/
}

// Address: 0x1068a8084 | Name: __ZN3RBX7Network10Replicator30ProcessOutdatedEventInvocationERNS0_13NetworkStreamERKNS_4GuidEPKNS_8InstanceEPKNS_10Reflection15EventDescriptorEj
__int64 __fastcall RBX::Network::Replicator::ProcessOutdatedEventInvocation(
        RBX::Network::Replicator *this,
        RBX::Network::NetworkStream *a2,
        const RBX::Guid *a3,
        const RBX::Instance *a4,
        const RBX::Reflection::EventDescriptor *a5)
{
  return 0; /*0x1068a808a*/
}

// Address: 0x1068a808c | Name: __ZN3RBX7Network10Replicator32ProcessOutdatedEnumSerializationERKNS_10Reflection4TypeERKNS2_7VariantERNS0_13NetworkStreamE
__int64 __fastcall RBX::Network::Replicator::ProcessOutdatedEnumSerialization(
        RBX::Network::Replicator *this,
        const RBX::Reflection::Type *a2,
        const RBX::Reflection::Variant *a3,
        RBX::Network::NetworkStream *a4)
{
  return 0; /*0x1068a8092*/
}

// Address: 0x1068a8094 | Name: __ZN3RBX7Network10Replicator34ProcessOutdatedEnumDeserializationERNS0_13NetworkStreamERKNS_10Reflection4TypeERNS4_7VariantE
__int64 __fastcall RBX::Network::Replicator::ProcessOutdatedEnumDeserialization(
        RBX::Network::Replicator *this,
        RBX::Network::NetworkStream *a2,
        const RBX::Reflection::Type *a3,
        RBX::Reflection::Variant *a4)
{
  return 0; /*0x1068a809a*/
}

// Address: 0x1068a809c | Name: __ZN3RBX7Network10Replicator40ProcessOutdatedPropertyEnumSerializationERKNS_13ConstPropertyERNS0_13NetworkStreamE
__int64 RBX::Network::Replicator::ProcessOutdatedPropertyEnumSerialization()
{
  return 0; /*0x1068a80a2*/
}

// Address: 0x1068a80a4 | Name: __ZN3RBX7Network10Replicator42ProcessOutdatedPropertyEnumDeserializationERNS_8PropertyERNS0_13NetworkStreamE
__int64 RBX::Network::Replicator::ProcessOutdatedPropertyEnumDeserialization()
{
  return 0; /*0x1068a80aa*/
}

// Address: 0x1068a80ac | Name: __ZNK3RBX7Network10Replicator22isPropertyConfidentialEPKNS_6ObjectERKNS_10Reflection18PropertyDescriptorE
__int64 __fastcall RBX::Network::Replicator::isPropertyConfidential(
        RBX::Network::Replicator *this,
        const RBX::Object *a2,
        const RBX::Reflection::PropertyDescriptor *a3)
{
  return 0; /*0x1068a80b2*/
}

// Address: 0x1068a80b4 | Name: __ZN3RBX7Network10Replicator42sendAnalyticsForLocallyInitiatedDisconnectEi
void __fastcall RBX::Network::Replicator::sendAnalyticsForLocallyInitiatedDisconnect(RBX::Network::Replicator *this)
{
  ; /*0x1068a80b4*/
}

// Address: 0x1068a80bc | Name: __ZN3RBX7Network10Replicator25getAnalyticsPlaySessionIdEv
RBX::Network::Replicator *__fastcall RBX::Network::Replicator::getAnalyticsPlaySessionId(
        RBX::Network::Replicator *this,
        __int64 a2,
        __int64 a3,
        __int64 a4)
{
  std::string::basic_string[abi:ne200100]<0>(a1: this, a2: "", a3, a4); /*0x1068a80cc*/
  return this; /*0x1068a80d8*/
}

// Address: 0x1068a80dc | Name: __ZN3RBX7Network10Replicator23analyzeEventVariantArgsERKNSt3__110shared_ptrINS_10Reflection10ValueTableEEE
void RBX::Network::Replicator::analyzeEventVariantArgs()
{
  ; /*0x1068a80dc*/
}

// Address: 0x1068a80e4 | Name: __ZN3RBX7Network10Replicator33analyzeEventVariantArgsMaybeThrowERKNSt3__110shared_ptrINS_10Reflection10ValueTableEEE
void RBX::Network::Replicator::analyzeEventVariantArgsMaybeThrow()
{
  ; /*0x1068a80e4*/
}

// Address: 0x1068a80ec | Name: __ZN3RBX7Network10Replicator25isReplicatedFirstFinishedEv
char __fastcall RBX::Network::Replicator::isReplicatedFirstFinished(RBX::Network::Replicator *this)
{
  return 1; /*0x1068a80f2*/
}

// Address: 0x1068a80f4 | Name: __ZN3RBX7Network10Replicator19reportSampledBwDataEv
void __fastcall RBX::Network::Replicator::reportSampledBwData(RBX::Network::Replicator *this)
{
  ; /*0x1068a80f4*/
}

// Address: 0x1068a80fc | Name: __ZN3RBX7Network10Replicator13isRateLimitedERKNS0_31DeserializedEventInvocationItemE
__int64 __fastcall RBX::Network::Replicator::isRateLimited(
        RBX::Network::Replicator *this,
        const RBX::Network::DeserializedEventInvocationItem *a2)
{
  return 0; /*0x1068a8102*/
}

// Address: 0x10690751c | Name: __ZNK3RBX7Network10Replicator15isOctreeEnabledEv
char __fastcall RBX::Network::Replicator::isOctreeEnabled(RBX::Network::Replicator *this)
{
  unsigned __int8 v1; // cl
  char result; // al

  v1 = (*(__int64 (__fastcall **)(RBX::Network::Replicator *))(*(_QWORD *)this + 1032LL))(a1: this); /*0x106907529*/
  result = FFlag::StreamingObserverUsesOctree; /*0x106907532*/
  if ( ((unsigned __int8)FFlag::StreamingObserverUsesOctree | v1 ^ 1) == 0 ) /*0x106907539*/
    return FFlag::TeamCityStreamingObserverUsesOctree; /*0x106907542*/
  return result; /*0x106907544*/
}

// Address: 0x106d6bf6a | Name: __ZN3RBX7Network10Replicator20isLegalReceiveObjectEPNS_6ObjectEPNS_8InstanceERKNSt3__16vectorINS0_13PropValuePairENS6_9allocatorIS8_EEEE
char RBX::Network::Replicator::isLegalReceiveObject()
{
  return 1; /*0x106d6bf70*/
}

// Address: 0x106d722ec | Name: __ZNK3RBX7Network10Replicator13getAsInternalENS_10Reflection11InterfaceIdE
__int64 RBX::Network::Replicator::getAsInternal()
{
  return 0; /*0x106d722f2*/
}

// Address: 0x106d722f4 | Name: __ZN3RBX7Network10Replicator35writeAllPropertiesForChangeTrackingEPNS_23DataModelChangeTracking13ChangeTrackerENS2_12DeltaTypeTagE
__int64 __fastcall RBX::Network::Replicator::writeAllPropertiesForChangeTracking(__int64 a1)
{
  return RBX::Instance::writeAllPropertiesForChangeTracking(a1); /*0x106d722f8*/
}

// Address: 0x106d724d0 | Name: __ZNK3RBX7Network10Replicator12getClassNameEv
__int64 __fastcall RBX::Network::Replicator::getClassName(RBX::Network::Replicator *this)
{
  return RBX::Name::getNullName(this); /*0x106d724d4*/
}

// Address: 0x10876769c | Name: __ZN3RBX7Network10Replicator16schemaWriteValueINS0_19GuidDataValueGetterEEEvRNS0_13NetworkStreamERKNS0_18NetworkSchemaTypes4TypeEbRKT_mRNSt3__16vectorINS_12SharedStringENSD_9allocatorISF_EEEERNS0_36ReplicationVariantSizeLimitsMetaDataERNS0_15ReplicatorItems20SerializerParametersE.cold.1
void __fastcall __noreturn RBX::Network::Replicator::schemaWriteValue<RBX::Network::GuidDataValueGetter>(
        unsigned int a1)
{
  unsigned int v2; // r14d
  const char *v3; // rdx
  RBX::Network::NetworkStream *v4; // rdx
  __int128 v5; // [rsp+0h] [rbp-20h] BYREF

  v5 = 0; /*0x1087676b1*/
  std::shared_ptr<std::map<std::string,RBX::Reflection::Variant> const>::~shared_ptr[abi:ne200100](a1: &v5); /*0x1087676b4*/
  v2 = MEMORY[0x10]; /*0x1087676b9*/
  RBX::Network::Replicator::checkVariantContainerCountLimit( /*0x1087676cb*/
    this: (RBX::Network::Replicator *)MEMORY[0x10],
    a2: "ValueMap (write)",
    a3: v3);
  RBX::Network::serializeUnsignedVarint(this: (RBX::Network *)v2, a2: a1, a3: v4); /*0x1087676d6*/
  BUG(); /*0x1087676db*/
}

// Address: 0x108767713 | Name: __ZN3RBX7Network10Replicator16onPlayerRemovingERKNSt3__110shared_ptrINS_8InstanceEEES7_.cold.1
void __fastcall RBX::Network::Replicator::onPlayerRemoving(__int64 a1)
{
  if ( (*(_BYTE *)(a1 + 16) & 1) != 0 ) /*0x108767717*/
    operator delete(a1: *(void **)(a1 + 32)); /*0x108767721*/
}

// Address: 0x108767728 | Name: __ZN3RBX7Network10Replicator17requestDisconnectEiNSt3__18optionalINS0_17DisconnectDetailsEEE.cold.1
void __fastcall RBX::Network::Replicator::requestDisconnect(__int64 a1)
{
  if ( (*(_BYTE *)(a1 + 16) & 1) != 0 ) /*0x10876772c*/
    operator delete(a1: *(void **)(a1 + 32)); /*0x108767736*/
}

// Address: 0x10876773d | Name: __ZN3RBX7Network10Replicator32reportReplicatorStats_deprecatedEv.cold.1
void __fastcall RBX::Network::Replicator::reportReplicatorStats_deprecated(void **this, RBX::Network::Replicator *a2)
{
  do /*0x108767761*/
  {
    if ( (*(_BYTE *)(this - 3) & 1) != 0 ) /*0x10876774f*/
      operator delete(a1: *(this - 1)); /*0x108767755*/
    this -= 3; /*0x10876775a*/
  }
  while ( this != (void **)a2 ); /*0x108767761*/
}

// Address: 0x108767768 | Name: __ZN3RBX7Network10Replicator32reportReplicatorStats_deprecatedEv.cold.2
void __fastcall RBX::Network::Replicator::reportReplicatorStats_deprecated(void **this, RBX::Network::Replicator *a2)
{
  do /*0x10876778c*/
  {
    if ( (*(_BYTE *)(this - 3) & 1) != 0 ) /*0x10876777a*/
      operator delete(a1: *(this - 1)); /*0x108767780*/
    this -= 3; /*0x108767785*/
  }
  while ( this != (void **)a2 ); /*0x10876778c*/
}

// END Replicator part 2/2, 70 functions
