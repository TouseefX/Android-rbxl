// DeserializedJoinDataItem -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 7 functions


// Address: 0x10672632c | Name: __ZN3RBX7Network24DeserializedJoinDataItemC2ENS0_4Item8ItemTypeE
void (__fastcall **__fastcall RBX::Network::DeserializedJoinDataItem::DeserializedJoinDataItem(
        __int64 a1,
        int a2))(RBX::Network::DeserializedJoinDataItem *__hidden this)
{
  *(_DWORD *)(a1 + 8) = a2; /*0x106726330*/
  *(_QWORD *)(a1 + 12) = 1; /*0x106726333*/
  *(_QWORD *)(a1 + 24) = 0; /*0x10672633b*/
  *(_QWORD *)a1 = off_10CAA91A0; /*0x10672634a*/
  *(_OWORD *)(a1 + 32) = 0; /*0x106726350*/
  *(_OWORD *)(a1 + 44) = 0; /*0x106726354*/
  return off_10CAA91A0; /*0x106726358*/
}

// Address: 0x10672635a | Name: __ZN3RBX7Network24DeserializedJoinDataItemC1ENS0_4Item8ItemTypeE
void (__fastcall **__fastcall RBX::Network::DeserializedJoinDataItem::DeserializedJoinDataItem(
        __int64 a1,
        int a2))(RBX::Network::DeserializedJoinDataItem *__hidden this)
{
  *(_DWORD *)(a1 + 8) = a2; /*0x10672635e*/
  *(_QWORD *)(a1 + 12) = 1; /*0x106726361*/
  *(_QWORD *)(a1 + 24) = 0; /*0x106726369*/
  *(_QWORD *)a1 = off_10CAA91A0; /*0x106726378*/
  *(_OWORD *)(a1 + 32) = 0; /*0x10672637e*/
  *(_OWORD *)(a1 + 44) = 0; /*0x106726382*/
  return off_10CAA91A0; /*0x106726386*/
}

// Address: 0x106726388 | Name: __ZN3RBX7Network24DeserializedJoinDataItemD2Ev
void __fastcall RBX::Network::DeserializedJoinDataItem::~DeserializedJoinDataItem(
        RBX::Network::DeserializedJoinDataItem *this)
{
  char *v1; // [rsp+8h] [rbp-8h] BYREF

  *(_QWORD *)this = off_10CAA91A0; /*0x106726397*/
  v1 = (char *)this + 32; /*0x1067263a2*/
  std::vector<RBX::Network::DeserializedNewObjectItem>::__destroy_vector::operator()[abi:ne200100](a1: &v1); /*0x1067263a8*/
}

// Address: 0x1067263b4 | Name: __ZN3RBX7Network24DeserializedJoinDataItemD1Ev
void __fastcall RBX::Network::DeserializedJoinDataItem::~DeserializedJoinDataItem(
        RBX::Network::DeserializedJoinDataItem *this)
{
  char *v1; // [rsp+8h] [rbp-8h] BYREF

  *(_QWORD *)this = off_10CAA91A0; /*0x1067263c3*/
  v1 = (char *)this + 32; /*0x1067263ce*/
  std::vector<RBX::Network::DeserializedNewObjectItem>::__destroy_vector::operator()[abi:ne200100](a1: &v1); /*0x1067263d4*/
}

// Address: 0x1067263e0 | Name: __ZN3RBX7Network24DeserializedJoinDataItemD0Ev
void __fastcall RBX::Network::DeserializedJoinDataItem::~DeserializedJoinDataItem(
        RBX::Network::DeserializedJoinDataItem *this)
{
  void *v2; // rsi
  char *v3; // [rsp+0h] [rbp-10h] BYREF

  *(_QWORD *)this = off_10CAA91A0; /*0x1067263f0*/
  v3 = (char *)this + 32; /*0x1067263fb*/
  std::vector<RBX::Network::DeserializedNewObjectItem>::__destroy_vector::operator()[abi:ne200100](a1: &v3); /*0x1067263fe*/
  operator delete(a1: this, a2: v2); /*0x106726406*/
}

// Address: 0x106726412 | Name: __ZN3RBX7Network24DeserializedJoinDataItem7processERNS0_10ReplicatorE
_BOOL8 __fastcall RBX::Network::DeserializedJoinDataItem::process(
        RBX::Network::DeserializedJoinDataItem *this,
        RBX::Network::Replicator *a2)
{
  (*(void (__fastcall **)(RBX::Network::Replicator *, RBX::Network::DeserializedJoinDataItem *))(*(_QWORD *)a2 + 1376LL))( /*0x106726424*/
    a1: a2,
    a2: this);
  return 0x84BDA12F684BDA13LL * ((__int64)(*((_QWORD *)this + 5) - *((_QWORD *)this + 4)) >> 3) == *((unsigned int *)this + 14); /*0x106726453*/
}

// Address: 0x106726456 | Name: __ZNK3RBX7Network24DeserializedJoinDataItem18finishedProcessingEv
bool __fastcall RBX::Network::DeserializedJoinDataItem::finishedProcessing(
        RBX::Network::DeserializedJoinDataItem *this)
{
  return 0x84BDA12F684BDA13LL * ((__int64)(*((_QWORD *)this + 5) - *((_QWORD *)this + 4)) >> 3) == *((unsigned int *)this + 14); /*0x10672647d*/
}

// END DeserializedJoinDataItem part 1/1, 7 functions
