// DeserializePacketsThread -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 7 functions


// Address: 0x10681c894 | Name: __ZN3RBX7Network24DeserializePacketsThread29pushIncomingPacketAndNotifyV2ENS0_14IncomingPacketE
__int64 __fastcall RBX::Network::DeserializePacketsThread::pushIncomingPacketAndNotifyV2(__int64 a1, __int64 a2)
{
  __int128 v3; // xmm1
  _QWORD v5[5]; // [rsp+0h] [rbp-A0h] BYREF
  _BYTE v6[8]; // [rsp+28h] [rbp-78h] BYREF
  _BYTE v7[96]; // [rsp+30h] [rbp-70h] BYREF

  v3 = *(_OWORD *)(a2 + 16); /*0x10681c8b4*/
  *(_OWORD *)v5 = *(_OWORD *)a2; /*0x10681c8bc*/
  *(_OWORD *)&v5[2] = v3; /*0x10681c8c0*/
  v5[4] = *(_QWORD *)(a2 + 32); /*0x10681c8c8*/
  std::__optional_move_base<RBX::RbxTransport::NetStream,false>::__optional_move_base[abi:ne200100](a1: v6, a2: a2 + 40); /*0x10681c8d0*/
  RBX::Network::DeserializePacketsJob::pushIncomingPacketV2(a1: a1 + 24, a2: (__int128 *)v5); /*0x10681c8e0*/
  if ( v7[88] == 1 ) /*0x10681c8e9*/
    RBX::RbxTransport::NetStreamBuffer::~NetStreamBuffer(this: (RBX::RbxTransport::NetStreamBuffer *)v7); /*0x10681c8ef*/
  RSL::Condition::notify_one(this: (RSL::Condition *)(a1 + 16)); /*0x10681c8fb*/
  return __stack_chk_guard; /*0x10681c910*/
}

// Address: 0x10681cc20 | Name: __ZN3RBX7Network24DeserializePacketsThread38pushIncomingPacketAndNotify_deprecatedEPN6RakNet6PacketE
__int64 __fastcall RBX::Network::DeserializePacketsThread::pushIncomingPacketAndNotify_deprecated(
        __int64 a1,
        __int64 a2)
{
  RBX::Network::DeserializePacketsJob::pushIncomingPacket_deprecated(a1: a1 + 24, a2); /*0x10681cc2d*/
  return RSL::Condition::notify_one(this: (RSL::Condition *)(a1 + 16)); /*0x10681cc3d*/
}

// Address: 0x10683b748 | Name: __ZN3RBX7Network24DeserializePacketsThread25cacheReceivedSharedStringERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS_12SharedStringE
__int64 __fastcall RBX::Network::DeserializePacketsThread::cacheReceivedSharedString(
        __int64 a1,
        unsigned __int64 a2,
        __int64 a3)
{
  __int64 v3; // rax
  __int64 v5; // r14
  _QWORD v7[4]; // [rsp+0h] [rbp-20h] BYREF

  v7[0] = v3; /*0x10683b751*/
  v5 = a1 + 24; /*0x10683b758*/
  RBX::Flyweight<RBX::SharedString::Data,void,true>::Flyweight(a1: v7, a2: a3); /*0x10683b766*/
  RBX::Network::DeserializePacketsJob::cacheReceivedSharedString(a1: v5, a2, a3: (__int64)v7); /*0x10683b774*/
  return RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: v7); /*0x10683b786*/
}

// Address: 0x10683ea84 | Name: __ZN3RBX7Network24DeserializePacketsThread28pushIncomingPacketNoNotifyV2ENS0_14IncomingPacketE
__int64 __fastcall RBX::Network::DeserializePacketsThread::pushIncomingPacketNoNotifyV2(__int64 a1, __int64 a2)
{
  __int128 v3; // xmm1
  _QWORD v5[5]; // [rsp+0h] [rbp-A0h] BYREF
  _BYTE v6[8]; // [rsp+28h] [rbp-78h] BYREF
  _BYTE v7[96]; // [rsp+30h] [rbp-70h] BYREF

  v3 = *(_OWORD *)(a2 + 16); /*0x10683eaa4*/
  *(_OWORD *)v5 = *(_OWORD *)a2; /*0x10683eaac*/
  *(_OWORD *)&v5[2] = v3; /*0x10683eab0*/
  v5[4] = *(_QWORD *)(a2 + 32); /*0x10683eab8*/
  std::__optional_move_base<RBX::RbxTransport::NetStream,false>::__optional_move_base[abi:ne200100](a1: v6, a2: a2 + 40); /*0x10683eac0*/
  RBX::Network::DeserializePacketsJob::pushIncomingPacketV2(a1: a1 + 24, a2: (__int128 *)v5); /*0x10683ead3*/
  if ( v7[88] == 1 ) /*0x10683eadc*/
    RBX::RbxTransport::NetStreamBuffer::~NetStreamBuffer(this: (RBX::RbxTransport::NetStreamBuffer *)v7); /*0x10683eae2*/
  return __stack_chk_guard; /*0x10683eaf7*/
}

// Address: 0x10683eb26 | Name: __ZN3RBX7Network24DeserializePacketsThread37pushIncomingPacketNoNotify_deprecatedEPN6RakNet6PacketE
__int64 __fastcall RBX::Network::DeserializePacketsThread::pushIncomingPacketNoNotify_deprecated(
        __int64 a1,
        __int64 a2)
{
  return RBX::Network::DeserializePacketsJob::pushIncomingPacket_deprecated(a1: a1 + 24, a2); /*0x10683eb2e*/
}

// Address: 0x106861ea2 | Name: __ZN3RBX7Network24DeserializePacketsThread14removeBlockingEv
__int64 __fastcall RBX::Network::DeserializePacketsThread::removeBlocking(RBX::Network::DeserializePacketsThread *this)
{
  *(_BYTE *)this = 1; /*0x106861ead*/
  RSL::Condition::notify_one(this: (RBX::Network::DeserializePacketsThread *)((char *)this + 16)); /*0x106861eb3*/
  RSL::Thread::join(this: (RBX::Network::DeserializePacketsThread *)((char *)this + 8)); /*0x106861ebc*/
  return RBX::Network::DeserializePacketsJob::deallocatePacketsOnDisconnect(this: (RBX::Network::DeserializePacketsThread *)((char *)this + 24)); /*0x106861ecc*/
}

// Address: 0x10686c2fa | Name: __ZN3RBX7Network24DeserializePacketsThreadC2ERNS0_10ReplicatorE
__int64 __fastcall RBX::Network::DeserializePacketsThread::DeserializePacketsThread(
        RBX::Network::DeserializePacketsThread *this,
        RBX::Network::Replicator *a2)
{
  char *v4; // rbx
  __int64 v5; // rdx
  __int64 v6; // rcx
  _BYTE v8[160]; // [rsp+10h] [rbp-D0h] BYREF
  _BYTE v9[8]; // [rsp+B0h] [rbp-30h] BYREF

  *(_WORD *)this = 0; /*0x10686c320*/
  v4 = (char *)this + 8; /*0x10686c325*/
  RSL::Thread::Thread(this: (RBX::Network::DeserializePacketsThread *)((char *)this + 8)); /*0x10686c32c*/
  RSL::Condition::Condition( /*0x10686c33f*/
    this: (RBX::Network::DeserializePacketsThread *)((char *)this + 16),
    a2: "DeserializePacketsThreadCondition");
  RBX::Network::DeserializePacketsJob::DeserializePacketsJob( /*0x10686c34b*/
    this: (RBX::Network::DeserializePacketsThread *)((char *)this + 24),
    a2);
  RSL::Closure::Closure<RBX::Network::DeserializePacketsThread::DeserializePacketsThread(RBX::Network::Replicator &)::{lambda(void)#1}>(a1: v8); /*0x10686c364*/
  v5 = 0x100000; /*0x10686c379*/
  if ( FInt::DPJThreadStackSizeKiB < 257 ) /*0x10686c37e*/
    v5 = 0x40000; /*0x10686c37e*/
  v6 = 0x10000; /*0x10686c385*/
  if ( FInt::DPJThreadStackSizeKiB >= 65 ) /*0x10686c38a*/
    v6 = v5; /*0x10686c38a*/
  RSL::Thread::Thread(a1: v9, a2: "DeserializePacketsThread", a3: v8, a4: v6, a5: 0, a6: 0); /*0x10686c3a5*/
  RSL::Thread::operator=(a1: v4, a2: v9); /*0x10686c3b0*/
  RSL::Thread::~Thread(this: (RSL::Thread *)v9); /*0x10686c3b8*/
  RSL::Closure::~Closure(this: (RSL::Closure *)v8); /*0x10686c3c0*/
  return __stack_chk_guard; /*0x10686c3d5*/
}

// END DeserializePacketsThread part 1/1, 7 functions
