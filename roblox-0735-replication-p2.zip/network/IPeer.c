// IPeer -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 9 functions


// Address: 0x1066f81c4 | Name: __ZN3RBX7Network5IPeer43updateMonotonicClockDifferential_deprecatedEyx
void __fastcall RBX::Network::IPeer::updateMonotonicClockDifferential_deprecated(RBX::Network::IPeer *this)
{
  ; /*0x1066f81c4*/
}

// Address: 0x1066f81ca | Name: __ZN3RBX7Network5IPeer9OnReceiveEPN6RakNet6PacketE
__int64 RBX::Network::IPeer::OnReceive()
{
  return 1; /*0x1066f81d3*/
}

// Address: 0x1066f81d8 | Name: __ZN3RBX7Network5IPeer29OnReceiveOpenConnectionReply2Ev
void __fastcall RBX::Network::IPeer::OnReceiveOpenConnectionReply2(RBX::Network::IPeer *this)
{
  ; /*0x1066f81d8*/
}

// Address: 0x1066f81e0 | Name: __ZN3RBX7Network5IPeer47OnFailedToIncludeRemoteSystemInRemoteSystemListERKN6RakNet13SystemAddressE
void __fastcall RBX::Network::IPeer::OnFailedToIncludeRemoteSystemInRemoteSystemList(
        RBX::Network::IPeer *this,
        const RakNet::SystemAddress *a2)
{
  ; /*0x1066f81e0*/
}

// Address: 0x1066f81e8 | Name: __ZN3RBX7Network5IPeer32OnReliabilityLayerDeadConnectionERKN6RakNet13SystemAddressE
void __fastcall RBX::Network::IPeer::OnReliabilityLayerDeadConnection(
        RBX::Network::IPeer *this,
        const RakNet::SystemAddress *a2)
{
  ; /*0x1066f81e8*/
}

// Address: 0x106d72f82 | Name: __ZN3RBX7Network5IPeer29OnReceiveOpenConnectionReply1Ev
void __fastcall RBX::Network::IPeer::OnReceiveOpenConnectionReply1(RBX::Network::IPeer *this)
{
  ; /*0x106d72f82*/
}

// Address: 0x106d72f88 | Name: __ZN3RBX7Network5IPeer26OnConnectFirstStageTimeoutERKN6RakNet13SystemAddressE
void __fastcall RBX::Network::IPeer::OnConnectFirstStageTimeout(
        RBX::Network::IPeer *this,
        const RakNet::SystemAddress *a2)
{
  ; /*0x106d72f88*/
}

// Address: 0x106d72f8e | Name: __ZN3RBX7Network5IPeer35OnTimeoutWaitingForPasswordAcceptedERKN6RakNet13SystemAddressE
void __fastcall RBX::Network::IPeer::OnTimeoutWaitingForPasswordAccepted(
        RBX::Network::IPeer *this,
        const RakNet::SystemAddress *a2)
{
  ; /*0x106d72f8e*/
}

// Address: 0x106d72f94 | Name: __ZN3RBX7Network5IPeer24OnRemoteActiveDisconnectERKN6RakNet13SystemAddressE
void __fastcall RBX::Network::IPeer::OnRemoteActiveDisconnect(
        RBX::Network::IPeer *this,
        const RakNet::SystemAddress *a2)
{
  ; /*0x106d72f94*/
}

// END IPeer part 1/1, 9 functions
