// SendDataJob -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 5 functions


// Address: 0x1067924da | Name: __ZN3RBX7Network10Replicator11SendDataJob13serializeDataEi
__int64 __fastcall RBX::Network::Replicator::SendDataJob::serializeData(
        RBX::Network::Replicator::SendDataJob *this,
        unsigned int a2)
{
  __int64 v4; // rsi
  unsigned int v5; // esi
  __int64 *v6; // r14
  bool canSendPacket; // r12
  __int64 result; // rax
  __int64 v9; // rsi
  __int64 v10; // rbx
  __int64 v11; // rdi
  __int64 i; // r13
  int v13; // r15d
  int v14; // eax
  int v15; // r9d
  const char *v16; // rsi
  int v17; // r15d
  int v18; // eax
  int v19; // ecx
  int v20; // r8d
  int v21; // r9d
  __int64 v22; // rsi
  unsigned __int8 v23; // r8
  unsigned __int8 v24; // r8
  unsigned __int8 v25; // r8
  const char *v26; // rsi
  _QWORD v27[13]; // [rsp+8h] [rbp-98h] BYREF
  unsigned int v28; // [rsp+74h] [rbp-2Ch]

  if ( (_BYTE)`guard variable for'RBX::Network::Replicator::SendDataJob::serializeData(int)::proftoken69 == 0
    && __cxa_guard_acquire(a1: &`guard variable for'RBX::Network::Replicator::SendDataJob::serializeData(int)::proftoken69) != 0 )
  {
    v27[0] = "ationProtocol] Error: Loading status is not returned from the MessageBus. File a bug to NFDN component.";
    RBX::Network::Replicator::SendDataJob::serializeData(int)::proftoken69 = RBX::Profiler::getToken( /*0x1067927b6*/
                                                                               this: (RBX::Profiler *)&aSecondArgument[-64324],
                                                                               a2: &aFlogExperiment_1[-526978],
                                                                               a3: (const char *)0xFFFFFFFFLL,
                                                                               a4: 255,
                                                                               a5: v23);
    __cxa_guard_release(a1: &`guard variable for'RBX::Network::Replicator::SendDataJob::serializeData(int)::proftoken69); /*0x1067927c4*/
  }
  if ( DFFlag::DebugAdditionalSendDataScopes != 0 ) /*0x106792506*/
    v4 = RBX::Network::Replicator::SendDataJob::serializeData(int)::proftoken69; /*0x106792508*/
  else
    v4 = 0; /*0x106792511*/
  RBX::Profiler::ConditionalScope::ConditionalScope(a1: v27, a2: v4); /*0x10679251a*/
  v5 = *((_DWORD *)this + 109); /*0x10679251f*/
  v6 = (__int64 *)((char *)this + 408); /*0x106792526*/
  canSendPacket = RBX::Network::Replicator::canSendPacket(a1: v6, a2: v5, a3: 1u); /*0x10679253a*/
  RBX::Profiler::ConditionalScope::~ConditionalScope(this: (RBX::Profiler::ConditionalScope *)v27); /*0x106792544*/
  result = 0xFFFFFFFFLL; /*0x106792549*/
  if ( canSendPacket )
  {
    if ( *v6 != 0 )
    {
      (*(void (__fastcall **)(__int64))(*(_QWORD *)*v6 + 776LL))(a1: *v6); /*0x106792562*/
      if ( (_BYTE)`guard variable for'RBX::Network::Replicator::SendDataJob::serializeData(int)::proftoken85 == 0 /*0x1067927dc*/
        && __cxa_guard_acquire(a1: &`guard variable for'RBX::Network::Replicator::SendDataJob::serializeData(int)::proftoken85) != 0 )
      {
        v27[0] = "st [T = const crashpad::Annotation]"; /*0x106792805*/
        RBX::Network::Replicator::SendDataJob::serializeData(int)::proftoken85 = RBX::Profiler::getToken( /*0x106792829*/
                                                                                   this: (RBX::Profiler *)&aDflogRaknetcon_21[-436443],
                                                                                   a2: &aTCrashpadAnnot_2[-714620],
                                                                                   a3: (const char *)0xFFFFFFFFLL,
                                                                                   a4: 255,
                                                                                   a5: v24);
        __cxa_guard_release(a1: &`guard variable for'RBX::Network::Replicator::SendDataJob::serializeData(int)::proftoken85); /*0x106792837*/
      }
      if ( DFFlag::DebugAdditionalSendDataScopes != 0 ) /*0x10679257d*/
        v9 = RBX::Network::Replicator::SendDataJob::serializeData(int)::proftoken85; /*0x10679257f*/
      else
        v9 = 0; /*0x10679258f*/
      RBX::Profiler::ConditionalScope::ConditionalScope(a1: v27, a2: v9); /*0x106792598*/
      v28 = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)*v6 + 1304LL))(a1: *v6, a2); /*0x1067925ac*/
      RBX::Profiler::ConditionalScope::~ConditionalScope(this: (RBX::Profiler::ConditionalScope *)v27); /*0x1067925b6*/
      v10 = *v6; /*0x1067925bb*/
      v11 = *v6; /*0x1067925c5*/
      for ( i = 0; i != 43; ++i )
      {
        if ( *(_DWORD *)(*(_QWORD *)(v11 + 18648) + 4 * i) != 0 || *(_DWORD *)(*(_QWORD *)(v10 + 14560) + 4 * i) != 0 )
        {
          if ( DFFlag::DebugEnablePerReplicatorMPProfiles == 1 )
          {
            if ( (_BYTE)`guard variable for'RBX::Network::Replicator::SendDataJob::serializeData(int)::proflabeltoken == 0 /*0x106792661*/
              && __cxa_guard_acquire(a1: &`guard variable for'RBX::Network::Replicator::SendDataJob::serializeData(int)::proflabeltoken) != 0 )
            {
              v27[0] = "ool, bool) const"; /*0x10679266a*/
              RBX::Network::Replicator::SendDataJob::serializeData(int)::proflabeltoken = RBX::Profiler::getLabelToken( /*0x106792687*/
                                                                                            this: (RBX::Profiler *)&aBoolNvttSurfac_0[-809572],
                                                                                            a2: v16);
              __cxa_guard_release(a1: &`guard variable for'RBX::Network::Replicator::SendDataJob::serializeData(int)::proflabeltoken); /*0x106792695*/
            }
            v13 = RBX::Network::Replicator::SendDataJob::serializeData(int)::proflabeltoken; /*0x1067925fa*/
            v14 = RBX::Network::Item::convertItemEnumToString(a1: (unsigned int)i); /*0x106792604*/
            RBX::Profiler::addLabelFormat(
              a1: v13,
              a2: (unsigned int)"%s (Left) : %d (%d)",
              a3: v14,
              a4: *(_DWORD *)(*(_QWORD *)(*v6 + 18648) + 4 * i),
              a5: *(_DWORD *)(*(_QWORD *)(v10 + 14560) + 4 * i),
              a6: v15);
            v11 = *v6; /*0x106792632*/
          }
          *(_DWORD *)(*(_QWORD *)(v11 + 18648) + 4 * i) = 0; /*0x10679263c*/
        }
      }
      if ( DFFlag::DebugEnablePerReplicatorMPProfiles != 0
        && RBX::Network::ItemQueue::size(this: (RBX::Network::ItemQueue *)(v11 + 14584)) != 0 )
      {
        if ( (_BYTE)`guard variable for'RBX::Network::Replicator::SendDataJob::serializeData(int)::proflabeltoken == 0 /*0x1067928c2*/
          && __cxa_guard_acquire(a1: &`guard variable for'RBX::Network::Replicator::SendDataJob::serializeData(int)::proflabeltoken) != 0 )
        {
          v27[0] = "ing for close frame"; /*0x1067928cf*/
          RBX::Network::Replicator::SendDataJob::serializeData(int)::proflabeltoken = RBX::Profiler::getLabelToken( /*0x1067928e9*/
                                                                                        this: (RBX::Profiler *)&aConnectionTerm[-19573],
                                                                                        a2: v26);
          __cxa_guard_release(a1: &`guard variable for'RBX::Network::Replicator::SendDataJob::serializeData(int)::proflabeltoken); /*0x1067928f7*/
        }
        v17 = RBX::Network::Replicator::SendDataJob::serializeData(int)::proflabeltoken; /*0x1067926c7*/
        v18 = RBX::Network::ItemQueue::size(this: (RBX::Network::ItemQueue *)(*v6 + 14584)); /*0x1067926d6*/
        RBX::Profiler::addLabelFormat(
          a1: v17,
          a2: (unsigned int)"Leftover HighPriority Items: %zu",
          a3: v18,
          a4: v19,
          a5: v20,
          a6: v21);
      }
      (*(void (__fastcall **)(__int64))(*(_QWORD *)*v6 + 760LL))(a1: *v6); /*0x1067926f5*/
      if ( DFFlag::DetailedBandwidthStatsInflux2 == 1 ) /*0x106792705*/
      {
        if ( (_BYTE)`guard variable for'RBX::Network::Replicator::SendDataJob::serializeData(int)::proftoken119 == 0 /*0x10679284f*/
          && __cxa_guard_acquire(a1: &`guard variable for'RBX::Network::Replicator::SendDataJob::serializeData(int)::proftoken119) != 0 )
        {
          v27[0] = "rtbeatRate"; /*0x106792878*/
          RBX::Network::Replicator::SendDataJob::serializeData(int)::proftoken119 = RBX::Profiler::getToken( /*0x10679289c*/
                                                                                      this: (RBX::Profiler *)&aDflogRbxtransp_379[-366057],
                                                                                      a2: &aInstantheartbe[-83024],
                                                                                      a3: (const char *)0xFFFFFFFFLL,
                                                                                      a4: 255,
                                                                                      a5: v25);
          __cxa_guard_release(a1: &`guard variable for'RBX::Network::Replicator::SendDataJob::serializeData(int)::proftoken119); /*0x1067928aa*/
        }
        if ( DFFlag::DebugAdditionalSendDataScopes != 0 ) /*0x10679271c*/
          v22 = RBX::Network::Replicator::SendDataJob::serializeData(int)::proftoken119; /*0x10679271e*/
        else
          v22 = 0; /*0x106792727*/
        RBX::Profiler::ConditionalScope::ConditionalScope(a1: v27, a2: v22); /*0x106792730*/
        RBX::Network::Replicator::analyticsReportPoll(this: (RBX::Network::Replicator *)*v6); /*0x106792738*/
        RBX::Profiler::ConditionalScope::~ConditionalScope(this: (RBX::Profiler::ConditionalScope *)v27); /*0x106792744*/
      }
      return v28; /*0x106792749*/
    }
    else
    {
      return 0; /*0x106792588*/
    }
  }
  return result; /*0x10679274c*/
}

// Address: 0x10685c11a | Name: __ZN3RBX7Network10Replicator11SendDataJobC2ERS1_
__int64 __fastcall RBX::Network::Replicator::SendDataJob::SendDataJob(
        RBX::Network::Replicator::SendDataJob *this,
        RBX::Network::Replicator *a2)
{
  RBX::Network::ReplicatorJob::ReplicatorJob( /*0x10685c139*/
    a1: this,
    a2: (RBX::Instance *)"Replicator SendData",
    a3: a2,
    a4: 4u,
    a5: 0xDu);
  *(_QWORD *)this = &off_10CAADAF8; /*0x10685c145*/
  *((_QWORD *)this + 53) = 0; /*0x10685c148*/
  *((_DWORD *)this + 108) = (_DWORD)this + 1106248112; /*0x10685c15f*/
  *(_QWORD *)((char *)this + 436) = 2; /*0x10685c165*/
  return RBX::DataModelJob::sendProfileDataToTelemetry(this); /*0x10685c178*/
}

// Address: 0x10685c1a6 | Name: __ZN3RBX7Network10Replicator11SendDataJobD1Ev
void __fastcall RBX::Network::Replicator::SendDataJob::~SendDataJob(RBX::Network::Replicator::SendDataJob *this)
{
  *(_QWORD *)this = &off_10CAB2260; /*0x10685c1b6*/
  std::shared_ptr<RBX::Network::Replicator>::~shared_ptr[abi:ne200100](a1: (char *)this + 408); /*0x10685c1c0*/
  RBX::TaskScheduler::Job::~Job(this); /*0x10685c1ce*/
}

// Address: 0x10685c1d4 | Name: __ZN3RBX7Network10Replicator11SendDataJobD0Ev
void __fastcall RBX::Network::Replicator::SendDataJob::~SendDataJob(RBX::Network::Replicator::SendDataJob *this)
{
  *(_QWORD *)this = &off_10CAB2260; /*0x10685c1e4*/
  std::shared_ptr<RBX::Network::Replicator>::~shared_ptr[abi:ne200100](a1: (char *)this + 408); /*0x10685c1ee*/
  RBX::TaskScheduler::Job::~Job(this); /*0x10685c1f6*/
  operator delete(a1: this); /*0x10685c204*/
}

// Address: 0x10685c20a | Name: __ZN3RBX7Network10Replicator11SendDataJob16stepDataModelJobERKNS_13TaskScheduler3Job5StatsE
__int64 RBX::Network::Replicator::SendDataJob::stepDataModelJob()
{
  return 1; /*0x10685c213*/
}

// END SendDataJob part 1/1, 5 functions
