// TableAndMapSchemaReadHelper -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 2 functions


// Address: 0x10680ee16 | Name: __ZN3RBX7Network27TableAndMapSchemaReadHelperINS0_17ObjectValueSetterENS_10Reflection10ValueTableEE4readERNS0_13NetworkStreamEbRS2_mRN5boost9unordered13unordered_mapINSt3__112basic_stringIcNSC_11char_traitsIcEENSC_9allocatorIcEEEENSC_6vectorINS0_26DeferredSharedStringSetterENSG_ISK_EEEENS9_4hashISI_EENSC_8equal_toISI_EENSG_INSC_4pairIKSI_SM_EEEEEERNS0_36ReplicationVariantSizeLimitsMetaDataERNS0_10ReplicatorE
void __fastcall RBX::Network::TableAndMapSchemaReadHelper<RBX::Network::ObjectValueSetter,RBX::Reflection::ValueTable>::read(
        unsigned int *a1,
        unsigned __int8 a2,
        RBX::Network::NetworkStream *a3,
        unsigned __int64 a4,
        _QWORD *a5,
        __int32 *a6,
        RBX::Network::IdSerializer *a7)
{
  const char *v9; // rdx
  __int64 v10; // rax
  unsigned int v11; // r13d
  int v12; // r12d
  char v13; // al
  int *v14; // rcx
  int *v15; // rdx
  __int64 v16; // rax
  volatile signed __int64 *v17; // rbx
  __int64 v18; // rax
  std::__shared_weak_count *v19; // rbx
  __int128 v24; // [rsp+30h] [rbp-80h] BYREF
  void *v25; // [rsp+40h] [rbp-70h]
  __int128 v26; // [rsp+50h] [rbp-60h] BYREF
  std::__shared_weak_count *v27[2]; // [rsp+60h] [rbp-50h] BYREF
  unsigned int v28; // [rsp+7Ch] [rbp-34h] BYREF
  int v29; // [rsp+80h] [rbp-30h]
  _BYTE v30[41]; // [rsp+87h] [rbp-29h] BYREF

  RBX::Network::deserializeUnsignedVarint(this: (RBX::Network *)&v28, a2: a1, a3); /*0x10680ee5a*/
  RBX::Network::Replicator::checkVariantContainerCountLimit( /*0x10680ee69*/
    this: (RBX::Network::Replicator *)v28,
    a2: "ValueTable (read)",
    a3: v9);
  v10 = operator new(a1: 0x28u); /*0x10680ee73*/
  v11 = 0; /*0x10680ee78*/
  *(_QWORD *)(v10 + 32) = 0; /*0x10680ee7b*/
  *(_OWORD *)v10 = 0; /*0x10680ee82*/
  *(_OWORD *)(v10 + 16) = 0; /*0x10680ee85*/
  *(_DWORD *)(v10 + 32) = 1065353216; /*0x10680ee89*/
  std::shared_ptr<RBX::Reflection::ValueTable>::shared_ptr[abi:ne200100]<RBX::Reflection::ValueTable,0>( /*0x10680ee97*/
    a1: v27,
    a2: v10);
  v25 = nullptr; /*0x10680ee9c*/
  v24 = 0; /*0x10680eea3*/
  if ( v28 != 0 ) /*0x10680eeab*/
  {
    v29 = a2; /*0x10680eeb9*/
    do /*0x10680ef58*/
    {
      v12 = *((_DWORD *)a7 + 69); /*0x10680eebc*/
      v13 = (*(__int64 (__fastcall **)(RBX::Network::IdSerializer *))(*(_QWORD *)a7 + 1032LL))(a1: a7); /*0x10680eec9*/
      v14 = &DFInt::CliTcMaxPayloadRcv; /*0x10680eed3*/
      if ( v12 == 1 ) /*0x10680eeda*/
        v14 = &DFInt::RccTcMaxPayloadRcv; /*0x10680eeda*/
      v15 = &DFInt::CliMaxPayloadRcv; /*0x10680eee2*/
      if ( v12 == 1 ) /*0x10680eee9*/
        v15 = &DFInt::RccMaxPayloadRcv; /*0x10680eee9*/
      if ( v13 != 0 ) /*0x10680eef3*/
        v15 = v14; /*0x10680eef3*/
      RBX::Network::deserializeString(a1: &v24, a2: a1, a3: (unsigned int)*v15); /*0x10680eeff*/
      *(_QWORD *)&v26 = &v24; /*0x10680ef08*/
      v16 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<>>( /*0x10680ef1e*/
              a1: v27[0],
              a2: &v24,
              a3: std::piecewise_construct,
              a4: &v26,
              a5: v30);
      RBX::Network::Replicator::schemaReadVariant( /*0x10680ef4c*/
        a1: a7,
        a2: (RBX::Network::NetworkStream *)a1,
        a3: v29,
        a4: v16 + 40,
        a5: a4,
        a6: a5,
        a7: a6);
      ++v11; /*0x10680ef51*/
    }
    while ( v11 < v28 ); /*0x10680ef58*/
  }
  (*(void (__fastcall **)(RBX::Network::IdSerializer *, std::__shared_weak_count **))(*(_QWORD *)a7 + 1544LL))( /*0x10680ef68*/
    a1: a7,
    a2: v27);
  v17 = (volatile signed __int64 *)v27[1]; /*0x10680ef6e*/
  v26 = *(_OWORD *)v27; /*0x10680ef76*/
  if ( v27[1] != nullptr ) /*0x10680ef84*/
    _InterlockedIncrement64((volatile signed __int64 *)v27[1] + 1); /*0x10680ef86*/
  v18 = *((_QWORD *)a3 + 1); /*0x10680ef8b*/
  if ( v18 != 0 ) /*0x10680ef92*/
  {
    (*(void (__fastcall **)(_QWORD, _QWORD, __int128 *))(**(_QWORD **)(v18 + 144) + 40LL))( /*0x10680efa5*/
      a1: *(_QWORD *)(v18 + 144),
      a2: *(_QWORD *)a3,
      a3: &v26);
    v17 = *((volatile signed __int64 **)&v26 + 1); /*0x10680efa8*/
  }
  if ( v17 != nullptr && _InterlockedExchangeAdd64(v17 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10680efc1*/
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v17 + 16))(a1: v17); /*0x10680efc9*/
    std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v17); /*0x10680efcf*/
  }
  if ( (v24 & 1) != 0 ) /*0x10680efd8*/
    operator delete(a1: v25); /*0x10680efde*/
  v19 = v27[1]; /*0x10680efe3*/
  if ( v27[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v27[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10680effc*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v19 + 16LL))(a1: v19); /*0x10680f004*/
    std::__shared_weak_count::__release_weak(this: v19); /*0x10680f00a*/
  }
}

// Address: 0x106812f56 | Name: __ZN3RBX7Network27TableAndMapSchemaReadHelperINS0_18VariantValueSetterENS_10Reflection10ValueTableEE4readERNS0_13NetworkStreamEbRS2_mRN5boost9unordered13unordered_mapINSt3__112basic_stringIcNSC_11char_traitsIcEENSC_9allocatorIcEEEENSC_6vectorINS0_26DeferredSharedStringSetterENSG_ISK_EEEENS9_4hashISI_EENSC_8equal_toISI_EENSG_INSC_4pairIKSI_SM_EEEEEERNS0_36ReplicationVariantSizeLimitsMetaDataERNS0_10ReplicatorE
void __fastcall RBX::Network::TableAndMapSchemaReadHelper<RBX::Network::VariantValueSetter,RBX::Reflection::ValueTable>::read(
        unsigned int *a1,
        unsigned __int8 a2,
        RBX::Network::NetworkStream *a3,
        unsigned __int64 a4,
        _QWORD *a5,
        __int32 *a6,
        RBX::Network::IdSerializer *a7)
{
  const char *v9; // rdx
  __int64 v10; // rax
  unsigned int v11; // r13d
  int v12; // r12d
  char v13; // al
  int *v14; // rcx
  int *v15; // rdx
  __int64 v16; // rax
  __int64 v17; // rdi
  _QWORD *v18; // rbx
  std::__shared_weak_count *v19; // rbx
  std::__shared_weak_count *v20; // rbx
  __int128 v25; // [rsp+30h] [rbp-80h] BYREF
  void *v26; // [rsp+40h] [rbp-70h]
  std::__shared_weak_count *v27[2]; // [rsp+50h] [rbp-60h] BYREF
  std::__shared_weak_count *v28[2]; // [rsp+60h] [rbp-50h] BYREF
  unsigned int v29; // [rsp+7Ch] [rbp-34h] BYREF
  int v30; // [rsp+80h] [rbp-30h]
  _BYTE v31[41]; // [rsp+87h] [rbp-29h] BYREF

  RBX::Network::deserializeUnsignedVarint(this: (RBX::Network *)&v29, a2: a1, a3); /*0x106812f9a*/
  RBX::Network::Replicator::checkVariantContainerCountLimit( /*0x106812fa9*/
    this: (RBX::Network::Replicator *)v29,
    a2: "ValueTable (read)",
    a3: v9);
  v10 = operator new(a1: 0x28u); /*0x106812fb3*/
  v11 = 0; /*0x106812fb8*/
  *(_QWORD *)(v10 + 32) = 0; /*0x106812fbb*/
  *(_OWORD *)v10 = 0; /*0x106812fc2*/
  *(_OWORD *)(v10 + 16) = 0; /*0x106812fc5*/
  *(_DWORD *)(v10 + 32) = 1065353216; /*0x106812fc9*/
  std::shared_ptr<RBX::Reflection::ValueTable>::shared_ptr[abi:ne200100]<RBX::Reflection::ValueTable,0>( /*0x106812fd7*/
    a1: v28,
    a2: v10);
  v26 = nullptr; /*0x106812fdc*/
  v25 = 0; /*0x106812fe3*/
  if ( v29 != 0 ) /*0x106812feb*/
  {
    v30 = a2; /*0x106812ff9*/
    do /*0x106813098*/
    {
      v12 = *((_DWORD *)a7 + 69); /*0x106812ffc*/
      v13 = (*(__int64 (__fastcall **)(RBX::Network::IdSerializer *))(*(_QWORD *)a7 + 1032LL))(a1: a7); /*0x106813009*/
      v14 = &DFInt::CliTcMaxPayloadRcv; /*0x106813013*/
      if ( v12 == 1 ) /*0x10681301a*/
        v14 = &DFInt::RccTcMaxPayloadRcv; /*0x10681301a*/
      v15 = &DFInt::CliMaxPayloadRcv; /*0x106813022*/
      if ( v12 == 1 ) /*0x106813029*/
        v15 = &DFInt::RccMaxPayloadRcv; /*0x106813029*/
      if ( v13 != 0 ) /*0x106813033*/
        v15 = v14; /*0x106813033*/
      RBX::Network::deserializeString(a1: &v25, a2: a1, a3: (unsigned int)*v15); /*0x10681303f*/
      v27[0] = (std::__shared_weak_count *)&v25; /*0x106813048*/
      v16 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<>>( /*0x10681305e*/
              a1: v28[0],
              a2: &v25,
              a3: std::piecewise_construct,
              a4: v27,
              a5: v31);
      RBX::Network::Replicator::schemaReadVariant( /*0x10681308c*/
        a1: a7,
        a2: (RBX::Network::NetworkStream *)a1,
        a3: v30,
        a4: v16 + 40,
        a5: a4,
        a6: a5,
        a7: a6);
      ++v11; /*0x106813091*/
    }
    while ( v11 < v29 ); /*0x106813098*/
  }
  (*(void (__fastcall **)(RBX::Network::IdSerializer *, std::__shared_weak_count **))(*(_QWORD *)a7 + 1544LL))( /*0x1068130a8*/
    a1: a7,
    a2: v28);
  *(_OWORD *)v27 = *(_OWORD *)v28; /*0x1068130b6*/
  if ( v28[1] != nullptr ) /*0x1068130bd*/
    _InterlockedIncrement64((volatile signed __int64 *)v28[1] + 1); /*0x1068130bf*/
  v18 = *((_QWORD **)a3 + 1); /*0x1068130cb*/
  *v18 = RBX::Reflection::Type::getSingleton<std::shared_ptr<RBX::Reflection::ValueTable const>>(a1: v17); /*0x1068130d4*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::shared_ptr<RBX::Reflection::ValueTable const>>( /*0x1068130e2*/
    a1: v18 + 1,
    a2: (__int64)v27);
  v19 = v27[1]; /*0x1068130e7*/
  if ( v27[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v27[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106813100*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v19 + 16LL))(a1: v19); /*0x106813108*/
    std::__shared_weak_count::__release_weak(this: v19); /*0x10681310e*/
  }
  if ( (v25 & 1) != 0 ) /*0x106813117*/
    operator delete(a1: v26); /*0x10681311d*/
  v20 = v28[1]; /*0x106813122*/
  if ( v28[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v28[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10681313b*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v20 + 16LL))(a1: v20); /*0x106813143*/
    std::__shared_weak_count::__release_weak(this: v20); /*0x106813149*/
  }
}

// END TableAndMapSchemaReadHelper part 1/1, 2 functions
