// JoinDataItem -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 17 functions


// Address: 0x1068ef04c | Name: __ZN3RBX7Network10Replicator12JoinDataItemC2EPS1_
__int64 __fastcall RBX::Network::Replicator::JoinDataItem::JoinDataItem(
        RBX::Network::Replicator::JoinDataItem *this,
        RBX::Network::Replicator *a2)
{
  RSL::Arena *v3; // rdi
  __int64 v4; // rdx
  __int64 v5; // rcx
  __int64 result; // rax

  RBX::Network::Item::Item(this, a2); /*0x1068ef05d*/
  *(_QWORD *)this = off_10CAB1CA8; /*0x1068ef06d*/
  *((_DWORD *)this + 16) = -1; /*0x1068ef070*/
  *((_QWORD *)this + 13) = 0; /*0x1068ef07a*/
  *(_OWORD *)((char *)this + 68) = 0; /*0x1068ef085*/
  *(_OWORD *)((char *)this + 84) = 0; /*0x1068ef089*/
  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::Replicator::JoinDataItem *)((char *)this + 112)); /*0x1068ef090*/
  *((_QWORD *)this + 24) = 0; /*0x1068ef09c*/
  *((_OWORD *)this + 11) = 0; /*0x1068ef0a6*/
  *((_QWORD *)this + 25) = RSL::Arena::getDefaultArena(this: v3); /*0x1068ef0b9*/
  *((_OWORD *)this + 13) = 0; /*0x1068ef0c3*/
  *((_OWORD *)this + 14) = 0; /*0x1068ef0ca*/
  result = std::string::basic_string[abi:ne200100]<0>(a1: (char *)this + 240, a2: "JoinDataItem", a3: v4, a4: v5); /*0x1068ef0df*/
  *((_BYTE *)this + 264) = 1; /*0x1068ef0e4*/
  return result; /*0x1068ef0ef*/
}

// Address: 0x1068fc5be | Name: __ZN3RBX7Network10Replicator12JoinDataItemD2Ev
void __fastcall RBX::Network::Replicator::JoinDataItem::~JoinDataItem(
        RBX::Network::Replicator::JoinDataItem *this,
        void *a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6)
{
  char v7; // al
  __int64 v8; // rdx
  __int64 v9; // rcx
  void *v10; // rsi
  __int64 v11; // rdx
  __int64 v12; // rcx
  void *v13; // rsi
  __int64 v14; // r8
  __int64 v15; // rcx
  void *v16; // rsi
  RBX::Memory *v17; // rdi
  int v18; // [rsp+0h] [rbp-220h]
  int v19; // [rsp+8h] [rbp-218h]
  int v20; // [rsp+10h] [rbp-210h]
  _BYTE v21[16]; // [rsp+20h] [rbp-200h] BYREF
  void *v22; // [rsp+30h] [rbp-1F0h]
  void *v23[59]; // [rsp+38h] [rbp-1E8h] BYREF

  *(_QWORD *)this = off_10CAB1CA8; /*0x1068fc5e2*/
  v7 = *((_BYTE *)this + 264); /*0x1068fc5e5*/
  if ( v7 == 1 ) /*0x1068fc5ed*/
  {
    RBX::Analytics::InfluxDb::Points::Points(a1: v23, a2: 0xFFFFFFFFLL, a3: 0, a4: 0); /*0x1068fc603*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1068fc622*/
      this: (RBX::Analytics::InfluxDb::Points *)v23,
      a2: "JoinSnapShotTime",
      a3: *(float *)(*((_QWORD *)this + 3) + 15592LL));
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1068fc63d*/
      this: (RBX::Analytics::InfluxDb::Points *)v23,
      a2: "instanceWriteTime",
      a3: *((float *)this + 23));
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1068fc653*/
      this: (RBX::Analytics::InfluxDb::Points *)v23,
      a2: "instanceWriteInvocation",
      a3: *((_DWORD *)this + 17));
    std::string::basic_string[abi:ne200100]<0>(a1: v21, a2: "ReplicatorJoinDataItemStats", a3: v8, a4: v9); /*0x1068fc666*/
    RBX::Analytics::InfluxDb::Points::report( /*0x1068fc681*/
      a1: v23,
      a2: v21,
      a3: (unsigned int)DFInt::ReplicatorJoinDataItemStatsInfluxHundrethsPercentage,
      a4: 0);
    if ( (v21[0] & 1) != 0 ) /*0x1068fc68d*/
      operator delete(a1: (RBX::Memory *)v22, a2: v10); /*0x1068fc696*/
    RBX::Analytics::InfluxDb::Points::~Points(this: v23); /*0x1068fc6a2*/
    v7 = *((_BYTE *)this + 264); /*0x1068fc6a7*/
  }
  if ( (v7 & 1) != 0 && DFInt::ReportJoinDataItemCacheEfficiencyHundrethsPercentage2 > 0 ) /*0x1068fc6bc*/
  {
    RBX::Analytics::InfluxDb::Points::Points(a1: v23, a2: 0xFFFFFFFFLL, a3: 0, a4: 0); /*0x1068fc6d2*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1068fc6e8*/
      this: (RBX::Analytics::InfluxDb::Points *)v23,
      a2: "Hits",
      a3: *((_DWORD *)this + 22));
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1068fc6ff*/
      this: (RBX::Analytics::InfluxDb::Points *)v23,
      a2: "Total",
      a3: *((_QWORD *)this + 9));
    std::string::basic_string[abi:ne200100]<0>(a1: v21, a2: "ReplicatorJoinDataItemCacheEfficiency", a3: v11, a4: v12); /*0x1068fc712*/
    RBX::Analytics::InfluxDb::Points::report( /*0x1068fc72d*/
      a1: v23,
      a2: v21,
      a3: (unsigned int)DFInt::ReportJoinDataItemCacheEfficiencyHundrethsPercentage2,
      a4: 0);
    if ( (v21[0] & 1) != 0 ) /*0x1068fc739*/
      operator delete(a1: (RBX::Memory *)v22, a2: v13); /*0x1068fc742*/
    RBX::Analytics::InfluxDb::Points::~Points(this: v23); /*0x1068fc74e*/
  }
  v14 = *((_QWORD *)this + 9); /*0x1068fc753*/
  if ( v14 != 0 ) /*0x1068fc75a*/
  {
    a4 = (unsigned int)DFLog::NetworkJoin >> 8; /*0x1068fc768*/
    LOBYTE(a3) = (unsigned __int8)DFLog::NetworkJoin < 6u; /*0x1068fc76f*/
    LOBYTE(a4) = (unsigned __int8)DFLog::NetworkJoin < 6u || BYTE1(DFLog::NetworkJoin) < 3u; /*0x1068fc778*/
    if ( (_BYTE)a4 == 0 ) /*0x1068fc77a*/
    {
      if ( (*((_BYTE *)this + 240) & 1) != 0 ) /*0x1068fc787*/
        v15 = *((_QWORD *)this + 32); /*0x1068fc792*/
      else
        LODWORD(v15) = (_DWORD)this + 241; /*0x1068fc789*/
      v20 = *((_DWORD *)this + 21); /*0x1068fc7b4*/
      v19 = *((_DWORD *)this + 20); /*0x1068fc7b9*/
      v18 = *((_DWORD *)this + 22); /*0x1068fc7bd*/
      FLog::FastLogFormatted( /*0x1068fc7c9*/
        a1: DFLog::NetworkJoin,
        a2: qword_10D7F3E08,
        a3: (unsigned int)"[DFLog::NetworkJoin] ~%s handled %zu instances over %u invocations %fms. %u from cache %u bytes se"
                      "nt (%u bytes uncompressed %fms compress time).",
        a4: v15,
        a5: v14,
        a6: *((_DWORD *)this + 17));
    }
  }
  if ( (*((_BYTE *)this + 240) & 1) != 0 ) /*0x1068fc7d5*/
    operator delete(a1: *((RBX::Memory **)this + 32), a2); /*0x1068fc7de*/
  RSL::Detail::Deque<RBX::Network::Replicator::JoinDataItem::ReplicationSetItem>::~Deque( /*0x1068fc7ea*/
    a1: (char *)this + 200,
    a2,
    a3,
    a4,
    a5: v14,
    a6,
    a7: v18,
    a8: v19,
    a9: v20);
  v17 = *((RBX::Memory **)this + 22); /*0x1068fc7ef*/
  if ( v17 != nullptr ) /*0x1068fc7f9*/
  {
    *((_QWORD *)this + 23) = v17; /*0x1068fc7fb*/
    operator delete(a1: v17, a2: v16); /*0x1068fc802*/
  }
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::Replicator::JoinDataItem *)((char *)this + 112)); /*0x1068fc80e*/
}

// Address: 0x1068fc844 | Name: __ZN3RBX7Network10Replicator12JoinDataItemD1Ev
void __fastcall RBX::Network::Replicator::JoinDataItem::~JoinDataItem(
        RBX::Network::Replicator::JoinDataItem *this,
        void *a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6)
{
  RBX::Network::Replicator::JoinDataItem::~JoinDataItem(this, a2, a3, a4, a5, a6); /*0x1068fc849*/
}

// Address: 0x1068fc84e | Name: __ZN3RBX7Network10Replicator12JoinDataItemD0Ev
void __fastcall RBX::Network::Replicator::JoinDataItem::~JoinDataItem(
        RBX::Network::Replicator::JoinDataItem *this,
        void *a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6)
{
  void *v7; // rsi

  RBX::Network::Replicator::JoinDataItem::~JoinDataItem(this, a2, a3, a4, a5, a6); /*0x1068fc857*/
  operator delete(a1: this, a2: v7); /*0x1068fc865*/
}

// Address: 0x1068fc86a | Name: __ZN3RBX7Network10Replicator12JoinDataItem13writeInstanceEPKNS_8InstanceERKNS_4GuidERKNS0_18NetworkSchemaTypes9ClassInfoERNS0_13NetworkStreamERNSt3__16vectorINS_12SharedStringENSF_9allocatorISH_EEEERNSG_INS0_14NetAssetHandleENSI_ISM_EEEE
__int64 __fastcall RBX::Network::Replicator::JoinDataItem::writeInstance(
        __int64 a1,
        const RBX::Object *a2,
        RBX::Guid *a3,
        unsigned __int16 *a4,
        unsigned int *a5,
        __int64 a6,
        __int64 a7)
{
  _BYTE *v10; // r12
  void *v11; // rsi
  __int64 v12; // rdi
  __int64 v13; // r12
  __int64 v14; // rax
  unsigned __int16 *v15; // r14
  __int64 Default; // rax
  _QWORD v18[4]; // [rsp+30h] [rbp-E0h] BYREF
  _BYTE v19[32]; // [rsp+50h] [rbp-C0h] BYREF
  _WORD v20[16]; // [rsp+70h] [rbp-A0h] BYREF
  __int64 v21; // [rsp+90h] [rbp-80h]
  RBX::Guid *v22; // [rsp+98h] [rbp-78h]
  __int64 v23; // [rsp+A0h] [rbp-70h]
  unsigned __int16 *v24; // [rsp+A8h] [rbp-68h]
  _BYTE v25[48]; // [rsp+B0h] [rbp-60h] BYREF

  v21 = a6; /*0x1068fc87e*/
  v22 = a3; /*0x1068fc885*/
  v23 = a5[12]; /*0x1068fc8a1*/
  v24 = a4; /*0x1068fc8af*/
  if ( FFlag::DebugVeryDetailedBandwidthUsage == 1 ) /*0x1068fc8b3*/
  {
    v10 = v25; /*0x1068fc8cd*/
    RBX::Network::RecordDetailedPerInstanceMetricsRAII::RecordDetailedPerInstanceMetricsRAII( /*0x1068fc8dc*/
      a1: (unsigned int)v25,
      a2: *(_DWORD *)(a1 + 24) + 288,
      a3: (_DWORD)a5,
      a4: 0,
      a5: (_DWORD)a2 + 48,
      a6: 0,
      a7: (__int64)"");
  }
  else
  {
    v10 = nullptr; /*0x1068fc8e3*/
  }
  v18[0] = v10; /*0x1068fc8ed*/
  v18[3] = (char *)RBX::unique_function<void ()(void),24ul,8ul,true>::unique_function<RBX::Network::Replicator::JoinDataItem::writeInstance(RBX::Instance const*,RBX::Guid const&,RBX::Network::NetworkSchemaTypes::ClassInfo const&,RBX::Network::NetworkStream &,std::vector<RBX::SharedString> &,std::vector<RBX::Network::NetAssetHandle> &)::$_0>(RBX::Network::Replicator::JoinDataItem::writeInstance(RBX::Instance const*,RBX::Guid const&,RBX::Network::NetworkSchemaTypes::ClassInfo const&,RBX::Network::NetworkStream &,std::vector<RBX::SharedString> &,std::vector<RBX::Network::NetAssetHandle> &)::$_0)::Callback /*0x1068fc8f7*/
         + 2;
  RBX::unique_function<void ()(void),24ul,8ul,true>::unique_function<24ul,8ul>(a1: (__int64)v19, a2: (__int64)v18); /*0x1068fc905*/
  RBX::unique_function<void ()(void),24ul,8ul,true>::~unique_function(a1: (__int64)v18, a2: v11); /*0x1068fc90d*/
  if ( a2 != nullptr && (_BYTE)DFLog::NetworkCluster != 0 ) /*0x1068fc922*/
  {
    v13 = *((_QWORD *)a2 + 3); /*0x1068fc924*/
    v14 = RBX::Reflection::Class_getDescriptorPtr<RBX::MegaClusterInstance>(a1: v12); /*0x1068fc928*/
    if ( *(unsigned __int16 *)(v13 + 440) - (unsigned int)*(unsigned __int16 *)(v14 + 440) <= *(unsigned __int16 *)(v14 + 442) /*0x1068fc95b*/
      && (unsigned __int8)DFLog::NetworkCluster >= 6u
      && BYTE1(DFLog::NetworkCluster) >= 3u )
    {
      FLog::FastLog( /*0x1068fc96f*/
        a1: DFLog::NetworkCluster,
        a2: qword_10D80D258,
        a3: "[DFLog::NetworkCluster] Wrote join data item for megacluster",
        0);
    }
  }
  RBX::Network::IdSerializer::serializeId( /*0x1068fc97e*/
    this: *(RBX::Network::IdSerializer **)(a1 + 24),
    a2: (RBX::Network::NetworkStream *)a5,
    a3: a2);
  v20[0] = *v24; /*0x1068fc991*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)a5, a2: v20, a3: 2u); /*0x1068fc9a1*/
  if ( (unsigned __int8)RBX::Network::Replicator::getRemoveDeprecatedBool(this: *(RBX::Network::Replicator **)(a1 + 24)) == 0 ) /*0x1068fc9b1*/
  {
    LOBYTE(v20[0]) = RBX::Network::Replicator::remoteDeleteOnDisconnect_deprecated( /*0x1068fc9c6*/
                       this: *(RBX::Network::Replicator **)(a1 + 24),
                       a2);
    RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)a5, a2: v20, a3: 1u); /*0x1068fc9d0*/
  }
  v15 = v24; /*0x1068fc9e1*/
  Default = RBX::Network::Replicator::getDefault( /*0x1068fc9ed*/
              this: *(RBX::Network::Replicator **)(a1 + 24),
              a2: (RBX::EngineContext *)(*(_QWORD *)(*(_QWORD *)(a1 + 24) + 88LL) & 0xFFFFFFFFFFFFFFF8LL),
              a3: *(const RBX::Name **)(*((_QWORD *)v24 + 1) + 8LL));
  memset(v20, 0, 28); /*0x1068fca00*/
  RBX::Network::NewObjectItem::schemaWritePropertyGroup( /*0x1068fca42*/
    a1: *(RBX::Reflection::PropertyDescriptor **)(a1 + 24),
    this: (RBX::Network::NetworkStream *)a5,
    a3: Default,
    a4: v21,
    a5: a7,
    a6: (__int64)v20,
    a7: 0,
    a8: 0);
  RBX::Network::IdSerializer::serializeId( /*0x1068fca52*/
    this: *(RBX::Network::IdSerializer **)(a1 + 24),
    a2: (RBX::Network::NetworkStream *)a5,
    a3: v22);
  RBX::Network::TwoWayBandwidthMetrics::onInstanceNetworked( /*0x1068fca70*/
    a1: *(_QWORD *)(a1 + 24) + 288LL,
    a2: 0,
    a3: *v15,
    a4: 0,
    a5: a5[12] - v23);
  RBX::ScopedExit::~ScopedExit(this: (RBX::ScopedExit *)v19); /*0x1068fca7c*/
  return __stack_chk_guard; /*0x1068fca91*/
}

// Address: 0x1068fcac8 | Name: __ZN3RBX7Network10Replicator12JoinDataItem12readInstanceERS1_RNS0_13NetworkStreamERNS0_25DeserializedNewObjectItemERN5boost9unordered13unordered_mapINSt3__112basic_stringIcNSB_11char_traitsIcEENSB_9allocatorIcEEEENSB_6vectorINS0_26DeferredSharedStringSetterENSF_ISJ_EEEENS8_4hashISH_EENSB_8equal_toISH_EENSF_INSB_4pairIKSH_SL_EEEEEE
__int64 __fastcall RBX::Network::Replicator::JoinDataItem::readInstance(
        RBX::Instance *this,
        unsigned int *a2,
        __int64 a3,
        _QWORD *a4)
{
  _BYTE *v7; // r15
  void *v8; // rsi
  __int64 v9; // r15
  char StreamOutToDiskEnabled; // al
  __int64 v11; // rdi
  RBX::InstanceStitchingHandler *v12; // r12
  __int64 v13; // r15
  __int64 v14; // rax
  const char *v15; // rsi
  const RBX::RbxStorage::StorageKey *StorageInterface; // r13
  RBX::Guid *v17; // r15
  RBX::Network::ClientReplicator::GCJob *v18; // rdi
  __int64 v19; // rsi
  unsigned __int16 UInt16; // ax
  __int64 v21; // rdx
  RBX::InstanceStitchingHandler *v22; // rdi
  const char *v23; // rsi
  __int64 v24; // r8
  __int64 v25; // r9
  __m128 v26; // xmm0
  __m128 v27; // xmm1
  __m128 v28; // xmm2
  __m128 v29; // xmm3
  __m128 v30; // xmm4
  __m128 v31; // xmm5
  __m128 v32; // xmm6
  __m128 v33; // xmm7
  __int64 v34; // rcx
  __int64 v35; // r12
  unsigned __int16 *v36; // r12
  const RBX::Reflection::ClassDescriptor *v37; // r13
  RBX::InstanceStitchingHandler *v38; // rdi
  char v39; // al
  _QWORD *v40; // r15
  __int64 v41; // rax
  __int64 v42; // r14
  const char *v43; // r14
  _QWORD *v44; // r15
  __int64 v45; // rdx
  __int64 v46; // rcx
  __int64 v47; // r8
  __int64 v48; // r9
  __m128 v49; // xmm0
  __m128 v50; // xmm1
  __m128 v51; // xmm2
  __m128 v52; // xmm3
  __m128 v53; // xmm4
  __m128 v54; // xmm5
  __m128 v55; // xmm6
  __m128 v56; // xmm7
  std::__shared_weak_count *v57; // r13
  unsigned int v58; // esi
  RBX::Network::NetworkStream *v59; // rdi
  int *v60; // rax
  __int64 v61; // rcx
  unsigned int v62; // r15d
  RBX::Network::NetworkStream *v63; // rdx
  RBX::Network::NetworkStream *v64; // r13
  unsigned int v65; // esi
  __int64 v66; // rdx
  __int64 v67; // rcx
  RBX::Instance *v68; // rdi
  RBX::CollectionService *v69; // r15
  __int64 v70; // r13
  __int64 v71; // rax
  const RBX::Instance *v72; // rsi
  __int64 v73; // r13
  unsigned __int8 Byte; // al
  __int64 v75; // r12
  std::__shared_weak_count *v76; // r14
  std::__shared_weak_count *v77; // r14
  int v78; // esi
  __int64 v79; // rdi
  __int64 v80; // r14
  __int64 v81; // rax
  RBX::Network::ClientReplicator::GCJob *v82; // rdi
  std::__shared_weak_count *v83; // rbx
  RBX::Network::NetworkStream *v85; // rsi
  std::__shared_weak_count *v86; // rdx
  __int64 v87; // rcx
  const char *v88; // rsi
  __int64 v89; // r8
  __int64 v90; // r9
  __m128 v91; // xmm0
  __m128 v92; // xmm1
  __m128 v93; // xmm2
  __m128 v94; // xmm3
  __m128 v95; // xmm4
  __m128 v96; // xmm5
  __m128 v97; // xmm6
  __m128 v98; // xmm7
  __int64 v99; // rdx
  __int64 v100; // rcx
  const char *v101; // rsi
  __int64 v102; // r8
  __int64 v103; // r9
  __m128 v104; // xmm0
  __m128 v105; // xmm1
  __m128 v106; // xmm2
  __m128 v107; // xmm3
  __m128 v108; // xmm4
  __m128 v109; // xmm5
  __m128 v110; // xmm6
  __m128 v111; // xmm7
  __int64 v112; // r15
  __int64 v113; // r13
  __int64 v114; // rax
  unsigned int v115; // r15d
  char *v116; // rsi
  void *v117; // rsi
  int v118; // r12d
  RBX::Network::NetworkStream *v119; // r13
  unsigned __int64 v120; // r15
  unsigned __int64 v121; // r15
  std::__shared_weak_count *v122; // r13
  int v123; // ecx
  __int64 v124; // rdx
  __int64 v125; // rcx
  __int64 v126; // r8
  __int64 v127; // r9
  __m128 v128; // xmm0
  __m128 v129; // xmm1
  __m128 v130; // xmm2
  __m128 v131; // xmm3
  __m128 v132; // xmm4
  __m128 v133; // xmm5
  __m128 v134; // xmm6
  __m128 v135; // xmm7
  const char *v136; // rsi
  char v137; // r14
  char *v138; // rbx
  __int64 v139; // rdx
  __int64 v140; // rcx
  void *v141; // rsi
  void *exception; // r14
  __int64 v143; // rsi
  const char *v144; // rsi
  unsigned __int8 v145; // r8
  char *v146; // r12
  RBX::InstanceStitchingHandler *v147; // rax
  __int64 v148; // r13
  char v149; // bl
  __int64 v150; // r15
  __m128 v151; // xmm0
  __m128 v152; // xmm1
  __m128 v153; // xmm2
  __m128 v154; // xmm3
  __m128 v155; // xmm4
  __m128 v156; // xmm5
  __m128 v157; // xmm6
  __m128 v158; // xmm7
  __int64 v159; // r13
  char *v160; // r9
  char v161; // [rsp+0h] [rbp-1C0h]
  _QWORD v162[4]; // [rsp+8h] [rbp-1B8h] BYREF
  _BYTE v163[32]; // [rsp+28h] [rbp-198h] BYREF
  __int64 v164; // [rsp+48h] [rbp-178h] BYREF
  std::__shared_weak_count *v165; // [rsp+50h] [rbp-170h]
  _BYTE v166[16]; // [rsp+58h] [rbp-168h] BYREF
  void *v167; // [rsp+68h] [rbp-158h]
  _QWORD *v168; // [rsp+70h] [rbp-150h]
  __int64 v169; // [rsp+78h] [rbp-148h]
  __int128 v170; // [rsp+80h] [rbp-140h] BYREF
  char v171[104]; // [rsp+90h] [rbp-130h] BYREF
  char v172; // [rsp+F8h] [rbp-C8h] BYREF
  char v173; // [rsp+F9h] [rbp-C7h] BYREF
  std::__shared_weak_count *v174; // [rsp+100h] [rbp-C0h]
  RBX::InstanceStitchingHandler *v175; // [rsp+108h] [rbp-B8h]
  std::__shared_weak_count *v176[2]; // [rsp+110h] [rbp-B0h] BYREF
  __int128 v177; // [rsp+120h] [rbp-A0h] BYREF
  void *v178; // [rsp+130h] [rbp-90h]
  RBX::Network::NetworkStream *v179; // [rsp+140h] [rbp-80h]
  int v180; // [rsp+148h] [rbp-78h]
  int v181; // [rsp+14Ch] [rbp-74h]
  RBX::InstanceStitchingHandler *v182; // [rsp+150h] [rbp-70h]
  RBX::Guid *v183; // [rsp+158h] [rbp-68h]
  _BYTE v184[48]; // [rsp+160h] [rbp-60h] BYREF

  v168 = a4; /*0x1068fcadc*/
  v169 = a2[14]; /*0x1068fcafd*/
  *(_QWORD *)(a3 + 80) = RBX::Network::IdSerializer::deserializeId(this, (RBX::Network::NetworkStream *)a2); /*0x1068fcb0d*/
  v182 = (RBX::InstanceStitchingHandler *)a2; /*0x1068fcb1b*/
  v183 = (RBX::Guid *)(a3 + 80); /*0x1068fcb1f*/
  if ( FFlag::DebugVeryDetailedBandwidthUsage == 1 ) /*0x1068fcb23*/
  {
    v7 = v184; /*0x1068fcb37*/
    RBX::Network::RecordDetailedPerInstanceMetricsRAII::RecordDetailedPerInstanceMetricsRAII( /*0x1068fcb49*/
      a1: (unsigned int)v184,
      a2: (_DWORD)this + 288,
      a3: (_DWORD)a2,
      a4: 1,
      a5: a3 + 80,
      a6: 0,
      a7: (__int64)"");
  }
  else
  {
    v7 = nullptr; /*0x1068fcb50*/
  }
  v162[0] = v7; /*0x1068fcb5a*/
  v162[3] = (char *)&RBX::unique_function<void ()(void),24ul,8ul,true>::unique_function<RBX::Network::Replicator::JoinDataItem::readInstance(RBX::Network::Replicator&,RBX::Network::NetworkStream &,RBX::Network::DeserializedNewObjectItem &,boost::unordered::unordered_map<std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,std::vector<RBX::Network::DeferredSharedStringSetter>>>> &)::$_0>(RBX::Network::Replicator::JoinDataItem::readInstance(RBX::Network::Replicator&,RBX::Network::NetworkStream &,RBX::Network::DeserializedNewObjectItem &,boost::unordered::unordered_map<std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,std::vector<RBX::Network::DeferredSharedStringSetter>>>> &)::$_0)::Callback /*0x1068fcb65*/
          + 2;
  RBX::unique_function<void ()(void),24ul,8ul,true>::unique_function<24ul,8ul>(a1: (__int64)v163, a2: (__int64)v162); /*0x1068fcb74*/
  RBX::unique_function<void ()(void),24ul,8ul,true>::~unique_function(a1: (__int64)v162, a2: v8); /*0x1068fcb7c*/
  v9 = *((_QWORD *)this + 1471); /*0x1068fcb81*/
  StreamOutToDiskEnabled = RBX::Network::Replicator::getStreamOutToDiskEnabled(this); /*0x1068fcb8b*/
  v179 = (RBX::Network::NetworkStream *)(v9 + 72); /*0x1068fcb94*/
  v12 = v182; /*0x1068fcb9a*/
  if ( StreamOutToDiskEnabled != 0 ) /*0x1068fcb9e*/
  {
    v13 = *((_QWORD *)this + 3); /*0x1068fcba0*/
    v14 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::ClientReplicator>(a1: v11); /*0x1068fcba4*/
    if ( *(unsigned __int16 *)(v13 + 440) - (unsigned int)*(unsigned __int16 *)(v14 + 440) <= *(unsigned __int16 *)(v14 + 442) ) /*0x1068fcbc3*/
    {
      v18 = *((RBX::Network::ClientReplicator::GCJob **)this + 2753); /*0x1068fcbdb*/
      v17 = v183; /*0x1068fcbe5*/
      if ( v18 != nullptr ) /*0x1068fcbe9*/
        StorageInterface = (const RBX::RbxStorage::StorageKey *)RBX::Network::ClientReplicator::GCJob::getStorageInterface( /*0x1068fcbf0*/
                                                                  this: v18,
                                                                  a2: v15);
      else
        StorageInterface = nullptr; /*0x1068fcbf5*/
    }
    else
    {
      StorageInterface = nullptr; /*0x1068fcbc5*/
      v17 = v183; /*0x1068fcbc8*/
    }
    RBX::Network::NetworkStream::Reset(this: v179); /*0x1068fcbfc*/
    if ( *(_DWORD *)v17 != 4 ) /*0x1068fcc05*/
    {
      v181 = 0; /*0x1068fcc2e*/
      goto LABEL_17; /*0x1068fcc2e*/
    }
    if ( (_BYTE)`guard variable for'RBX::Network::Replicator::JoinDataItem::readInstance(RBX::Network::Replicator&,RBX::Network::NetworkStream &,RBX::Network::DeserializedNewObjectItem &,boost::unordered::unordered_map<std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,std::vector<RBX::Network::DeferredSharedStringSetter>>>> &)::proftoken163 == 0 /*0x1068fd338*/
      && __cxa_guard_acquire(a1: &`guard variable for'RBX::Network::Replicator::JoinDataItem::readInstance(RBX::Network::Replicator&,RBX::Network::NetworkStream &,RBX::Network::DeserializedNewObjectItem &,boost::unordered::unordered_map<std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,std::vector<RBX::Network::DeferredSharedStringSetter>>>> &)::proftoken163) != 0 )
    {
      *(_QWORD *)v171 = ":generateMaterialVariantsAsync"; /*0x1068fd361*/
      RBX::Network::Replicator::JoinDataItem::readInstance(RBX::Network::Replicator&,RBX::Network::NetworkStream &,RBX::Network::DeserializedNewObjectItem &,boost::unordered::unordered_map<std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,std::vector<RBX::Network::DeferredSharedStringSetter>>>> &)::proftoken163 = RBX::Profiler::getToken(this: (RBX::Profiler *)&aSdpMungingNumb_0[-589322], a2: &aMaterialgenera_36[-734936], a3: (const char *)0xFFFFFFFFLL, a4: 255, a5: v145); /*0x1068fd385*/
      __cxa_guard_release(a1: &`guard variable for'RBX::Network::Replicator::JoinDataItem::readInstance(RBX::Network::Replicator&,RBX::Network::NetworkStream &,RBX::Network::DeserializedNewObjectItem &,boost::unordered::unordered_map<std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,std::vector<RBX::Network::DeferredSharedStringSetter>>>> &)::proftoken163); /*0x1068fd393*/
      v12 = v182; /*0x1068fd398*/
    }
    if ( DFFlag::DebugEnableStreamOutToDiskProfiler != 0 ) /*0x1068fcc1c*/
      v19 = RBX::Network::Replicator::JoinDataItem::readInstance(RBX::Network::Replicator&,RBX::Network::NetworkStream &,RBX::Network::DeserializedNewObjectItem &,boost::unordered::unordered_map<std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,std::vector<RBX::Network::DeferredSharedStringSetter>>>> &)::proftoken163; /*0x1068fcc22*/
    else
      v19 = 0; /*0x1068fd07e*/
    RBX::Profiler::ConditionalScope::ConditionalScope(a1: v171, a2: v19); /*0x1068fd087*/
    v176[0] = (std::__shared_weak_count *)RBX::Network::CustomSerializers::deserializeFingerprint(this: v12, a2: v85); /*0x1068fd094*/
    v176[1] = v86; /*0x1068fd09b*/
    if ( StorageInterface == nullptr ) /*0x1068fd0a5*/
      RBX::throw_runtime_error( /*0x1068fd3aa*/
        this: (RBX *)"Failed to get GCJob's StorageInterface.",
        a2: v88,
        a3: (__int64)v86,
        a4: v87,
        a5: v89,
        a6: v90,
        a7: v91,
        a8: v92,
        a9: v93,
        a10: v94,
        a11: v95,
        a12: v96,
        a13: v97,
        a14: v98,
        a15: v161);
    RBX::RbxStorage::StorageKey::StorageKey(a1: &v172, a2: v176, a3: 16, a4: 19); /*0x1068fd0c3*/
    RBX::RbxStorage::StorageInterface::get(this: (RBX::RbxStorage::StorageInterface *)&v164, a2: StorageInterface); /*0x1068fd0d9*/
    v112 = v164; /*0x1068fd0de*/
    if ( v164 == 0 ) /*0x1068fd0e8*/
      RBX::throw_runtime_error( /*0x1068fd3bd*/
        this: (RBX *)"Cache miss when loading from RbxStorage!",
        a2: v101,
        a3: v99,
        a4: v100,
        a5: v102,
        a6: v103,
        a7: v104,
        a8: v105,
        a9: v106,
        a10: v107,
        a11: v108,
        a12: v109,
        a13: v110,
        a14: v111,
        a15: v161);
    v113 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v164 + 24LL))(a1: v164); /*0x1068fd0f7*/
    v114 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v112 + 16LL))(a1: v112); /*0x1068fd100*/
    v115 = v114; /*0x1068fd103*/
    if ( v113 != 0 ) /*0x1068fd109*/
    {
      std::string::basic_string[abi:ne200100](a1: &v177, a2: v113, a3: v114); /*0x1068fd118*/
      if ( (v177 & 1) != 0 ) /*0x1068fd124*/
        v116 = (char *)v178; /*0x1068fd147*/
      else
        v116 = (char *)&v177 + 1; /*0x1068fd126*/
    }
    else
    {
      v116 = (char *)&v177 + 1; /*0x1068fd132*/
      v177 = 0; /*0x1068fd139*/
      v178 = nullptr; /*0x1068fd13d*/
    }
    RBX::Network::NetworkStream::writeBytes(this: v179, a2: v116, a3: v115); /*0x1068fd155*/
    if ( (v177 & 1) != 0 ) /*0x1068fd161*/
      operator delete(a1: (RBX::Memory *)v178, a2: v117); /*0x1068fd16a*/
    v118 = *(_DWORD *)(a3 + 84); /*0x1068fd16f*/
    v119 = v179; /*0x1068fd176*/
    v120 = RBX::Network::IdSerializer::deserializeId(this, a2: v179); /*0x1068fd182*/
    *(_QWORD *)v183 = v120; /*0x1068fd189*/
    v181 = (*(__int64 (__fastcall **)(RBX::Network::NetworkStream *))(*(_QWORD *)v119 + 24LL))(a1: v119); /*0x1068fd196*/
    v121 = HIDWORD(v120); /*0x1068fd199*/
    v122 = v165; /*0x1068fd19d*/
    if ( v165 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v165 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1068fd1b9*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v122 + 16LL))(a1: v122); /*0x1068fd1c2*/
      std::__shared_weak_count::__release_weak(this: v122); /*0x1068fd1c8*/
    }
    v181 -= 21; /*0x1068fd1cd*/
    RBX::Profiler::ConditionalScope::~ConditionalScope(this: (RBX::Profiler::ConditionalScope *)v171); /*0x1068fd1d8*/
    if ( v118 == (_DWORD)v121 ) /*0x1068fd1e0*/
    {
      UInt16 = RBX::Network::NetworkStream::readUInt16(this: v179); /*0x1068fd1e6*/
      v17 = v183; /*0x1068fd1eb*/
      LOBYTE(v123) = 1; /*0x1068fd1ef*/
      v180 = v123; /*0x1068fd1f1*/
      goto LABEL_18; /*0x1068fd1f4*/
    }
    v12 = v182; /*0x1068fd1f9*/
  }
  else
  {
    v181 = 0; /*0x1068fcbce*/
  }
  v17 = v183; /*0x1068fcbd5*/
LABEL_17:
  UInt16 = RBX::Network::NetworkStream::readUInt16(this: v12); /*0x1068fcc35*/
  v180 = 0; /*0x1068fcc3d*/
LABEL_18:
  v34 = *((_QWORD *)this + 1560); /*0x1068fcc44*/
  v35 = *(_QWORD *)(v34 + 184); /*0x1068fcc4b*/
  if ( v35 == 0 /*0x1068fcc7d*/
    || (v34 = (*(_QWORD *)(v34 + 192) - v35) >> 3, v21 = 0xD37A6F4DE9BD37A7LL * v34,
                                                   0xD37A6F4DE9BD37A7LL * v34 <= UInt16) )
  {
    RBX::throw_runtime_error( /*0x1068fd20b*/
      this: (RBX *)"Join data contained invalid class network id",
      a2: v23,
      a3: v21,
      a4: v34,
      a5: v24,
      a6: v25,
      a7: v26,
      a8: v27,
      a9: v28,
      a10: v29,
      a11: v30,
      a12: v31,
      a13: v32,
      a14: v33,
      a15: v161);
  }
  v36 = (unsigned __int16 *)(184LL * UInt16 + v35); /*0x1068fcc8a*/
  *(_QWORD *)(a3 + 96) = v36; /*0x1068fcc8d*/
  v37 = *((const RBX::Reflection::ClassDescriptor **)v36 + 1); /*0x1068fcc91*/
  if ( (unsigned __int8)RBX::InstanceStitchingHandler::isInstanceStitchingEnabled(this: v22) != 0
    && (unsigned __int8)RBX::Network::Replicator::isInServerAuthoritativeMode(this) != 0
    && (v38 = *((RBX::InstanceStitchingHandler **)this + 2317)) != nullptr )
  {
    v39 = RBX::InstanceStitchingHandler::markPotentiallyCollidingStitchableInstance(this: v38, a2: v17, a3: v37); /*0x1068fccbd*/
    *(_OWORD *)v176 = 0; /*0x1068fccc5*/
    if ( v39 != 0 )
    {
LABEL_31:
      if ( v37 != nullptr )
      {
        RBX::Creatable::createWithEngineContextByName<RBX::Object>( /*0x1068fcd59*/
          a1: v171,
          a2: *((_QWORD *)this + 11) & 0xFFFFFFFFFFFFFFF8LL,
          a3: *((_QWORD *)v37 + 1),
          a4: 0);
        v44 = (_QWORD *)(a3 + 112); /*0x1068fcd5e*/
        std::shared_ptr<RBX::Object>::operator=[abi:ne200100](a1: a3 + 112, a2: v171); /*0x1068fcd6f*/
        v57 = *(std::__shared_weak_count **)&v171[8]; /*0x1068fcd74*/
        if ( *(_QWORD *)&v171[8] != 0 /*0x1068fcd8d*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)(*(_QWORD *)&v171[8] + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v57 + 16LL))(a1: v57); /*0x1068fcd96*/
          std::__shared_weak_count::__release_weak(this: v57); /*0x1068fcd9c*/
        }
        if ( *v44 == 0 )
        {
          v143 = *(_QWORD *)(*(_QWORD *)(*(_QWORD *)(a3 + 96) + 8LL) + 8LL); /*0x1068fd315*/
          if ( (*(_BYTE *)v143 & 1) != 0 ) /*0x1068fd31c*/
            v144 = *(const char **)(v143 + 16); /*0x1068fd3f2*/
          else
            v144 = (const char *)(v143 + 1); /*0x1068fd322*/
          RBX::throw_runtime_error(
            this: (RBX *)"Replication: Can't create object of type %s",
            a2: v144,
            a3: v45,
            a4: v46,
            a5: v47,
            a6: v48,
            a7: v49,
            a8: v50,
            a9: v51,
            a10: v52,
            a11: v53,
            a12: v54,
            a13: v55,
            a14: v56,
            a15: v161);
        }
        RBX::GuidItem<RBX::Object>::Registry::assignGuid(a1: *((_QWORD *)this + 22), a2: *v44, a3: v183); /*0x1068fcdb8*/
        *(_BYTE *)(a3 + 144) = 1; /*0x1068fcdbd*/
      }
      goto LABEL_37; /*0x1068fcdbd*/
    }
  }
  else
  {
    *(_OWORD *)v176 = 0; /*0x1068fccd5*/
  }
  if ( (unsigned __int8)RBX::GuidItem<RBX::Object>::Registry::lookupByGuid( /*0x1068fccf4*/
                          a1: *((_QWORD *)this + 22),
                          a2: v17,
                          a3: v176) == 0 )
    goto LABEL_31; /*0x1068fccf4*/
  v40 = (_QWORD *)(a3 + 112); /*0x1068fccf6*/
  std::shared_ptr<RBX::Object>::operator=[abi:ne200100](a1: a3 + 112, a2: v176); /*0x1068fcd04*/
  v41 = *(_QWORD *)(a3 + 112); /*0x1068fcd09*/
  if ( v41 == 0 ) /*0x1068fcd10*/
  {
    RBX::Guid::readableString(this: (RBX::Guid *)v171, a2: (int)v183); /*0x1068fd22a*/
    if ( (v171[0] & 1) != 0 ) /*0x1068fd236*/
      v136 = *(const char **)&v171[16]; /*0x1068fd23c*/
    else
      v136 = &v171[1]; /*0x1068fd409*/
    RBX::throw_runtime_error( /*0x1068fd419*/
      this: (RBX *)"read join object got a null object (guid %s)",
      a2: v136,
      a3: v124,
      a4: v125,
      a5: v126,
      a6: v127,
      a7: v128,
      a8: v129,
      a9: v130,
      a10: v131,
      a11: v132,
      a12: v133,
      a13: v134,
      a14: v135,
      a15: v161);
  }
  if ( *(_QWORD *)(v41 + 24) != *((_QWORD *)v36 + 1) )
  {
    v42 = *((_QWORD *)v37 + 1); /*0x1068fcd25*/
    if ( (*(_BYTE *)v42 & 1) != 0 ) /*0x1068fcd2d*/
      v43 = *(const char **)(v42 + 16); /*0x1068fd3c7*/
    else
      v43 = (const char *)(v42 + 1); /*0x1068fcd33*/
    RBX::Guid::readableString(this: (RBX::Guid *)v171, a2: (int)v183); /*0x1068fd3db*/
    if ( (v171[0] & 1) != 0 ) /*0x1068fd3e7*/
      v146 = *(char **)&v171[16]; /*0x1068fd3e9*/
    else
      v146 = &v171[1]; /*0x1068fd423*/
    RBX::Network::RakNetAddressToString( /*0x1068fd445*/
      this: (RBX::Network *)&v172,
      a2: (RBX::Instance *)((char *)this + 240),
      a3: true,
      a4: 124);
    if ( (v172 & 1) != 0 ) /*0x1068fd451*/
      v147 = v175; /*0x1068fd453*/
    else
      v147 = (RBX::InstanceStitchingHandler *)&v173; /*0x1068fd45c*/
    v182 = v147; /*0x1068fd463*/
    v148 = (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*v40 + 64LL))(a1: *v40); /*0x1068fd470*/
    v149 = *(_BYTE *)v148; /*0x1068fd473*/
    v150 = *(_QWORD *)(v148 + 16); /*0x1068fd475*/
    RBX::Guid::readableString(this: (RBX::Guid *)&v177, a2: (int)v183); /*0x1068fd489*/
    v159 = v148 + 1; /*0x1068fd48e*/
    if ( (v149 & 1) == 0 ) /*0x1068fd494*/
      v150 = v159; /*0x1068fd494*/
    if ( (v177 & 1) != 0 ) /*0x1068fd49f*/
      v160 = (char *)v178; /*0x1068fd4a1*/
    else
      v160 = (char *)&v177 + 1; /*0x1068fd4aa*/
    RBX::throw_runtime_error(
      this: (RBX *)"Replication: Bad re-binding in deserialize new instance %s-%s << %s, %s-%s",
      a2: v43,
      a3: (__int64)v146,
      a4: (__int64)v182,
      a5: v150,
      a6: (__int64)v160,
      a7: v151,
      a8: v152,
      a9: v153,
      a10: v154,
      a11: v155,
      a12: v156,
      a13: v157,
      a14: v158,
      a15: v161);
  }
LABEL_37:
  if ( (unsigned __int8)RBX::Network::Replicator::getRemoveDeprecatedBool(this) == 0 ) /*0x1068fcdcf*/
  {
    v59 = v182; /*0x1068fcdd5*/
    if ( (_BYTE)v180 != 0 ) /*0x1068fcdd9*/
      v59 = v179; /*0x1068fcdd9*/
    RBX::Network::NetworkStream::readBool(this: v59); /*0x1068fcdde*/
  }
  v60 = (int *)&RBX::Memory::NetworkReplicator; /*0x1068fcde3*/
  if ( *(_BYTE *)(a3 + 144) == 1 ) /*0x1068fcdf2*/
  {
    v61 = *(_QWORD *)(a3 + 112); /*0x1068fcdf4*/
    if ( v61 != 0 ) /*0x1068fcdfb*/
    {
      v60 = *(int **)(*(_QWORD *)(v61 + 24) + 424LL); /*0x1068fce01*/
      if ( v60 == nullptr ) /*0x1068fce0b*/
        v60 = &RBX::Memory::InstanceObject; /*0x1068fce0d*/
    }
  }
  v62 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)*v60, a2: v58); /*0x1068fce1b*/
  memset(v171, 0, 28); /*0x1068fce2c*/
  v63 = v179; /*0x1068fce33*/
  if ( (_BYTE)v180 == 0 ) /*0x1068fce37*/
    v63 = v182; /*0x1068fce37*/
  v64 = v63; /*0x1068fce46*/
  RBX::Network::DeserializedNewObjectItem::schemaReadPropertyGroup( /*0x1068fce55*/
    a1: a3,
    a2: this,
    a3: v63,
    a4: 0,
    a5: 0,
    a6: v168,
    a7: (__int32 *)v171);
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v62, a2: v65); /*0x1068fce5d*/
  *(_QWORD *)(a3 + 88) = RBX::Network::IdSerializer::deserializeId(this, a2: v64); /*0x1068fce6d*/
  if ( (unsigned __int8)RBX::Network::Replicator::getInstanceIntentReplicationEnabled(this) != 0 ) /*0x1068fce7b*/
  {
    v69 = *(RBX::CollectionService **)(a3 + 112); /*0x1068fce7d*/
    v70 = *((_QWORD *)v69 + 3); /*0x1068fce81*/
    v71 = RBX::Instance::classDescriptor(this: v68); /*0x1068fce85*/
    v66 = *(unsigned __int16 *)(v71 + 440); /*0x1068fce92*/
    v67 = *(unsigned __int16 *)(v70 + 440) - (unsigned int)v66; /*0x1068fce99*/
    if ( (unsigned int)v67 <= *(unsigned __int16 *)(v71 + 442) /*0x1068fceb0*/
      && (unsigned __int8)RBX::CollectionService::isIntentTarget(this: v69, a2: v72) != 0 )
    {
      v73 = *((_QWORD *)this + 2316); /*0x1068fceb2*/
      Byte = RBX::Network::NetworkStream::readByte(this: v182); /*0x1068fcebd*/
      RBX::CollectionService::onTagRuleChanging(a1: v73, a2: v69, a3: Byte); /*0x1068fcecb*/
    }
  }
  if ( *(_DWORD *)(a3 + 88) == -1 ) /*0x1068fced8*/
  {
    if ( *((_DWORD *)this + 69) == 1 ) /*0x1068fcee1*/
    {
      std::string::basic_string[abi:ne200100]<0>( /*0x1068fd256*/
        a1: v171,
        a2: "Client is trying to start an atomic replication transfer",
        a3: v66,
        a4: v67);
      v137 = v171[0]; /*0x1068fd25b*/
      v138 = *(char **)&v171[16]; /*0x1068fd262*/
      v170 = 0; /*0x1068fd26c*/
      std::string::basic_string[abi:ne200100]<0>(a1: v166, a2: "", a3: v139, a4: v140); /*0x1068fd281*/
      if ( (v137 & 1) == 0 ) /*0x1068fd291*/
        v138 = &v171[1]; /*0x1068fd291*/
      RBX::CreatorLog::print(a1: 3, a2: v138, a3: 4, a4: &v170, a5: v166); /*0x1068fd2b0*/
      if ( (v166[0] & 1) != 0 ) /*0x1068fd2bc*/
        operator delete(a1: (RBX::Memory *)v167, a2: v141); /*0x1068fd2c5*/
      std::shared_ptr<RBX::Reflection::ValueTable const>::~shared_ptr[abi:ne200100](a1: (__int64)&v170); /*0x1068fd2d1*/
      exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1068fd2e0*/
      std::runtime_error::runtime_error(a1: exception, a2: v171); /*0x1068fd2ed*/
      __cxa_throw( /*0x1068fd303*/
        a1: exception,
        lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
        a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
    }
    *(_BYTE *)(a3 + 145) = 1; /*0x1068fcee7*/
  }
  RBX::Network::TwoWayBandwidthMetrics::onInstanceNetworked( /*0x1068fcf11*/
    a1: (char *)this + 288,
    a2: 1,
    a3: *v36,
    a4: 0,
    a5: *((unsigned int *)v182 + 14) - v169);
  v75 = *((_QWORD *)v36 + 1); /*0x1068fcf16*/
  if ( v75 != 0 ) /*0x1068fcf1e*/
  {
    RBX::GuidItem<RBX::Object>::Registry::getByGuid(a1: &v172, a2: *((_QWORD *)this + 22)); /*0x1068fcf35*/
    RBX::Reflection::DescribedBase::fastSharedDynamicCast<RBX::Instance,RBX::Object>(a1: v171, a2: &v172); /*0x1068fcf48*/
    std::shared_ptr<RBX::Instance>::operator=[abi:ne200100](a1: a3 + 128, a2: (__int128 *)v171); /*0x1068fcf5e*/
    v76 = *(std::__shared_weak_count **)&v171[8]; /*0x1068fcf63*/
    if ( *(_QWORD *)&v171[8] != 0 /*0x1068fcf7c*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)(*(_QWORD *)&v171[8] + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v76 + 16LL))(a1: v76); /*0x1068fcf84*/
      std::__shared_weak_count::__release_weak(this: v76); /*0x1068fcf8a*/
    }
    v77 = v174; /*0x1068fcf8f*/
    if ( v174 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v174 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1068fcfab*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v77 + 16LL))(a1: v77); /*0x1068fcfb3*/
      std::__shared_weak_count::__release_weak(this: v77); /*0x1068fcfb9*/
    }
    if ( (unsigned __int8)RBX::Network::Replicator::getStreamOutToDiskEnabled(this) != 0 /*0x1068fcfda*/
      && (unsigned __int8)RBX::Analytics::InfluxDb::canSend(
                            this: (RBX::Analytics::InfluxDb *)(unsigned int)FInt::StreamOutToDiskStatsHundredthsPercentage,
                            a2: v78) != 0 )
    {
      v80 = *((_QWORD *)this + 3); /*0x1068fcfdc*/
      v81 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::ClientReplicator>(a1: v79); /*0x1068fcfe0*/
      if ( *(unsigned __int16 *)(v80 + 440) - (unsigned int)*(unsigned __int16 *)(v81 + 440) <= *(unsigned __int16 *)(v81 + 442) ) /*0x1068fcfff*/
      {
        v82 = *((RBX::Network::ClientReplicator::GCJob **)this + 2753); /*0x1068fd001*/
        if ( v82 != nullptr ) /*0x1068fd00b*/
          RBX::Network::ClientReplicator::GCJob::updateStreamInStats(this: v82, a2: v181); /*0x1068fd010*/
      }
    }
  }
  v83 = v176[1]; /*0x1068fd015*/
  if ( v176[1] != nullptr /*0x1068fd031*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)v176[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v83 + 16LL))(a1: v83); /*0x1068fd039*/
    std::__shared_weak_count::__release_weak(this: v83); /*0x1068fd03f*/
  }
  LOBYTE(v83) = v75 != 0; /*0x1068fd047*/
  RBX::ScopedExit::~ScopedExit(this: (RBX::ScopedExit *)v163); /*0x1068fd051*/
  return (unsigned int)v83; /*0x1068fd06c*/
}

// Address: 0x1068fd740 | Name: __ZN3RBX7Network10Replicator12JoinDataItem36debugVerifyInstanceSetsSeparatedByIdERN3RSL5DequeINS2_18ReplicationSetItemEEE
__int64 __fastcall RBX::Network::Replicator::JoinDataItem::debugVerifyInstanceSetsSeparatedById(__int64 a1)
{
  __int64 *v1; // rbx
  __int64 v2; // rcx
  void *v3; // rsi
  int *v4; // rax
  int *v5; // r13
  _QWORD v7[3]; // [rsp+8h] [rbp-88h] BYREF
  _QWORD v8[2]; // [rsp+20h] [rbp-70h] BYREF
  void *v9[2]; // [rsp+30h] [rbp-60h] BYREF
  int v10; // [rsp+40h] [rbp-50h]
  __int64 v11; // [rsp+50h] [rbp-40h] BYREF
  __int64 v12; // [rsp+58h] [rbp-38h]

  *(_OWORD *)v9 = 0; /*0x1068fd754*/
  v10 = 0; /*0x1068fd758*/
  v11 = a1; /*0x1068fd763*/
  v12 = 0; /*0x1068fd766*/
  v2 = *(_QWORD *)(a1 + 32); /*0x1068fd76e*/
  v8[0] = a1; /*0x1068fd776*/
  v8[1] = v2; /*0x1068fd779*/
  if ( !RSL::Detail::DequeIteratorBase<RBX::Network::Replicator::JoinDataItem::ReplicationSetItem,RSL::Detail::DequeIterator<RBX::Network::Replicator::JoinDataItem::ReplicationSetItem>>::operator==( /*0x1068fd780*/
          a1: &v11,
          a2: v8) )
  {
    v1 = &v11; /*0x1068fd789*/
    do /*0x1068fd7a4*/
    {
      v4 = (int *)RSL::Detail::Deque<RBX::Network::Replicator::JoinDataItem::ReplicationSetItem>::at(a1: v11, a2: v12); /*0x1068fd7a4*/
      v5 = v4; /*0x1068fd7a9*/
      if ( *v4 != -1 ) /*0x1068fd7af*/
      {
        if ( RBX::DenseMapBase<RBX::DenseMap<unsigned int,RBX::detail::DenseSetEmpty,RBX::DenseMapInfo<unsigned int,void>,RBX::detail::DenseSetPair<unsigned int>>,unsigned int,RBX::detail::DenseSetEmpty,RBX::DenseMapInfo<unsigned int,void>,RBX::detail::DenseSetPair<unsigned int>>::LookupBucketFor<unsigned int>( /*0x1068fd7c1*/
               a1: (__int64 *)v9,
               a2: v4,
               a3: v7) != 0 )
        {
          LODWORD(v1) = 0; /*0x1068fd804*/
          goto LABEL_8; /*0x1068fd806*/
        }
        RBX::DenseMapBase<RBX::DenseMap<unsigned int,RBX::detail::DenseSetEmpty,RBX::DenseMapInfo<unsigned int,void>,RBX::detail::DenseSetPair<unsigned int>>,unsigned int,RBX::detail::DenseSetEmpty,RBX::DenseMapInfo<unsigned int,void>,RBX::detail::DenseSetPair<unsigned int>>::try_emplace<RBX::detail::DenseSetEmpty&>( /*0x1068fd7d0*/
          a1: (__int64)v7,
          a2: (__int64)v9,
          a3: v5);
      }
      ++v12; /*0x1068fd7d5*/
    }
    while ( !RSL::Detail::DequeIteratorBase<RBX::Network::Replicator::JoinDataItem::ReplicationSetItem,RSL::Detail::DequeIterator<RBX::Network::Replicator::JoinDataItem::ReplicationSetItem>>::operator==( /*0x1068fd7a4*/
               a1: &v11,
               a2: v8) );
  }
  LOBYTE(v1) = 1; /*0x1068fd7e8*/
LABEL_8:
  operator delete(a1: (RBX::Memory *)v9[0], a2: v3); /*0x1068fd7ea*/
  return (unsigned int)v1; /*0x1068fd7f5*/
}

// Address: 0x1068fd826 | Name: __ZN3RBX7Network10Replicator12JoinDataItem26writeInstanceOrFingerprintERKNS2_12InstanceItemERNS0_13NetworkStreamEbRNSt3__16vectorINS_12SharedStringENS8_9allocatorISA_EEEERNS9_INS0_14NetAssetHandleENSB_ISF_EEEE
__int64 __fastcall RBX::Network::Replicator::JoinDataItem::writeInstanceOrFingerprint(
        __int64 a1,
        __int64 a2,
        unsigned int *a3,
        int a4,
        __int64 a5,
        __int64 a6)
{
  const RBX::Object *v9; // r12
  __m128i v10; // xmm0
  __int64 v11; // rdx
  __m128i v12; // xmm0
  const void *v13; // r13
  unsigned int v14; // eax
  int v15; // esi
  unsigned int v16; // r15d
  int v17; // eax
  RBX::Network::Replicator::StreamJob *v18; // r14
  _DWORD v20[2]; // [rsp+8h] [rbp-48h] BYREF
  __int128 v21; // [rsp+10h] [rbp-40h] BYREF

  v9 = *(const RBX::Object **)a2; /*0x1068fd840*/
  if ( a4 == 0 ) /*0x1068fd845*/
    RBX::Network::Replicator::JoinDataItem::writeInstance( /*0x1068fd862*/
      a1,
      a2: v9,
      a3: (RBX::Guid *)(a2 + 16),
      a4: *(unsigned __int16 **)(a2 + 24),
      a5: a3,
      a6: a5,
      a7: a6);
  v21 = RBX::Network::EmptyFingerprintData; /*0x1068fd86e*/
  v10 = _mm_xor_si128(_mm_loadu_si128((const __m128i *)(a2 + 48)), (__m128i)xmmword_109A07CE0); /*0x1068fd877*/
  if ( !_mm_testz_si128(v10, v10) /*0x1068fd8a5*/
    && (*(_QWORD *)&v21 = RBX::Network::getFingerprint(
                            this: (RBX::Network *)a3,
                            (const RBX::Network::NetworkStream *)a2),
        *((_QWORD *)&v21 + 1) = v11,
        v12 = _mm_xor_si128(_mm_loadu_si128((const __m128i *)(a2 + 48)), (__m128i)v21),
        _mm_testz_si128(v12, v12)) )
  {
    v17 = *((_DWORD *)v9 + 13); /*0x1068fd8d2*/
    v20[0] = 4; /*0x1068fd8db*/
    v20[1] = v17; /*0x1068fd8e1*/
    v16 = a1 + 112; /*0x1068fd8e8*/
    RBX::Network::IdSerializer::serializeId( /*0x1068fd8ef*/
      this: *(RBX::Network::IdSerializer **)(a1 + 24),
      a2: (RBX::Network::NetworkStream *)(a1 + 112),
      a3: (const RBX::Guid *)v20);
    RBX::Network::CustomSerializers::serializeFingerprint(a1: a1 + 112, a2: (__int64)&v21); /*0x1068fd8fb*/
    LOBYTE(v16) = 1; /*0x1068fd900*/
  }
  else
  {
    v13 = (const void *)(*(__int64 (__fastcall **)(unsigned int *))(*(_QWORD *)a3 + 16LL))(a1: a3); /*0x1068fd8b4*/
    v14 = (*(__int64 (__fastcall **)(unsigned int *))(*(_QWORD *)a3 + 24LL))(a1: a3); /*0x1068fd8bd*/
    RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)(a1 + 112), a2: v13, a3: v14); /*0x1068fd8c8*/
    v16 = 0; /*0x1068fd8cd*/
  }
  v18 = *(RBX::Network::Replicator::StreamJob **)(*(_QWORD *)(a1 + 24) + 14520LL); /*0x1068fd907*/
  if ( v18 != nullptr /*0x1068fd944*/
    && (unsigned __int8)RBX::Analytics::InfluxDb::canSend(
                          this: (RBX::Analytics::InfluxDb *)(unsigned int)FInt::StreamOutToDiskStatsHundredthsPercentage,
                          a2: v15) != 0
    && (*(_QWORD *)(a2 + 48) ^ 0xA6A1F9F5B94913AFLL | *(_QWORD *)(a2 + 56) ^ 0x49C9DC36EA4D40A0LL) != 0 )
  {
    RBX::Network::Replicator::StreamJob::updateStreamOutToDiskStats(this: v18, a2: v16); /*0x1068fd94d*/
  }
  return v16; /*0x1068fd955*/
}

// Address: 0x1068fd964 | Name: __ZN3RBX7Network10Replicator12JoinDataItem24writeInstanceToBitStreamERjS3_RNS0_13NetworkStreamERNSt3__16vectorINS_12SharedStringENS6_9allocatorIS8_EEEERNS7_INS0_14NetAssetHandleENS9_ISD_EEEERKNS2_12InstanceItemE
__int64 __fastcall RBX::Network::Replicator::JoinDataItem::writeInstanceToBitStream(
        __int64 a1,
        _DWORD *a2,
        _DWORD *a3,
        __int64 a4,
        __int64 *a5,
        _QWORD *a6,
        __int64 a7)
{
  const RBX::Object *v10; // r15
  __int64 v11; // rax
  bool v12; // r15
  char v13; // al
  pthread_mutex_t *v14; // r13
  _QWORD *v15; // r12
  int v16; // eax
  __int64 *v17; // r14
  __int64 v18; // rdi
  char StreamOutToDiskEnabled; // al
  __int64 v20; // rdx
  RBX::Network::NetworkStream *v21; // r13
  __int64 v22; // r15
  const RBX::Instance *v23; // rsi
  __int64 v24; // rax
  __int64 UserID; // rdx
  __int64 v26; // r15
  __int64 i; // r13
  __int64 v28; // r8
  __int64 v29; // r9
  int v30; // r13d
  unsigned __int64 v31; // rdx
  unsigned __int64 v32; // rcx
  __int64 v33; // r15
  const void *v34; // rsi
  signed __int64 v35; // rdx
  __int64 v36; // r15
  unsigned __int64 v37; // rdi
  __int64 v38; // rcx
  __int64 v39; // rax
  __int64 v40; // r14
  __int64 v41; // rax
  __int64 v42; // rdx
  __int64 v43; // r14
  __int64 v44; // rcx
  RBX::Network::NetworkStream *v45; // r13
  __int64 v46; // r12
  __int64 v47; // r14
  void *v48; // r12
  void *v49; // rsi
  RBX::Memory *v50; // rdi
  __int64 result; // rax
  __int64 v52; // r13
  __int64 v53; // rax
  RBX::Network::NetworkStream *v54; // r13
  unsigned int *v55; // rdx
  _QWORD *v56; // rax
  __int64 v57; // rcx
  unsigned int v58; // edx
  _DWORD *v59; // rdi
  char *v60; // rsi
  __int64 v61; // r13
  __int64 v62; // r8
  __int64 v63; // r9
  __int64 v64; // [rsp+0h] [rbp-90h]
  __int64 v65; // [rsp+10h] [rbp-80h] BYREF
  __int64 v66; // [rsp+18h] [rbp-78h]
  _DWORD *v67; // [rsp+20h] [rbp-70h]
  __int64 v68; // [rsp+28h] [rbp-68h]
  __int64 v69; // [rsp+30h] [rbp-60h]
  int v70; // [rsp+3Ch] [rbp-54h]
  __int64 *v71; // [rsp+40h] [rbp-50h]
  _DWORD *v72; // [rsp+48h] [rbp-48h]
  RBX::Network::NetworkStream *v73; // [rsp+50h] [rbp-40h]
  __int64 v74; // [rsp+58h] [rbp-38h]
  RBX::CollectionService *v75; // [rsp+60h] [rbp-30h]

  v71 = a5; /*0x1068fd978*/
  v74 = a4; /*0x1068fd97c*/
  v72 = a3; /*0x1068fd980*/
  v10 = *(const RBX::Object **)a7; /*0x1068fd98e*/
  RBX::Network::Replicator::markObjectSyncing( /*0x1068fd99b*/
    this: *(RBX::Network::Replicator **)(a1 + 24),
    a2: *(const RBX::Object **)a7,
    a3: false);
  v75 = v10; /*0x1068fd9a0*/
  v11 = *((_QWORD *)v10 + 13); /*0x1068fd9a4*/
  v12 = true; /*0x1068fd9a8*/
  if ( v11 != 0 && *(_DWORD *)(v11 + 52) == *(_DWORD *)(a7 + 20) ) /*0x1068fd9b8*/
    v12 = *(_DWORD *)(v11 + 48) != *(_DWORD *)(a7 + 16); /*0x1068fd9c2*/
  v73 = (RBX::Network::NetworkStream *)(a1 + 112); /*0x1068fd9ca*/
  v70 = *(_DWORD *)(a1 + 160); /*0x1068fd9d4*/
  v13 = (*(__int64 (__fastcall **)(_QWORD, RBX::CollectionService *, _QWORD))(**(_QWORD **)(a1 + 24) + 1480LL))( /*0x1068fd9e7*/
          a1: *(_QWORD *)(a1 + 24),
          a2: v75,
          a3: *(_QWORD *)(a7 + 24));
  v67 = a2; /*0x1068fd9ef*/
  if ( v13 == 0 /*0x1068fda0d*/
    || v12
    || (unsigned __int8)RBX::Network::Replicator::getRemoveDeprecatedBool(this: *(RBX::Network::Replicator **)(a1 + 24)) == 0 )
  {
    v15 = a6; /*0x1068fda96*/
    if ( (unsigned __int8)RBX::Network::Replicator::getStreamOutToDiskEnabled(this: *(RBX::Network::Replicator **)(a1 + 24)) != 0 ) /*0x1068fda99*/
    {
      v21 = (RBX::Network::NetworkStream *)(*(_QWORD *)(*(_QWORD *)(a1 + 24) + 11768LL) + 72LL); /*0x1068fdaa6*/
      RBX::Network::NetworkStream::Reset(this: v21); /*0x1068fdaad*/
      v17 = v71; /*0x1068fdabe*/
      RBX::Network::Replicator::JoinDataItem::writeInstanceOrFingerprint( /*0x1068fdac8*/
        a1,
        a2: a7,
        a3: (unsigned int *)v21,
        a4: 0,
        a5: (__int64)v71,
        a6: (__int64)v15);
    }
    else
    {
      v64 = (__int64)a6; /*0x1068fdadb*/
      v17 = v71; /*0x1068fdaea*/
      RBX::Network::Replicator::JoinDataItem::writeInstance( /*0x1068fdaf1*/
        a1,
        a2: v75,
        a3: (RBX::Guid *)(a7 + 16),
        a4: *(unsigned __int16 **)(a7 + 24),
        a5: (unsigned int *)v73,
        a6: (__int64)v71,
        a7: v64);
    }
    goto LABEL_16; /*0x1068fdacd*/
  }
  v14 = (pthread_mutex_t *)(*(_QWORD *)(a7 + 32) + 8LL); /*0x1068fda17*/
  v15 = a6; /*0x1068fda1b*/
  do /*0x1068fda29*/
    v16 = pthread_mutex_trylock(a1: v14); /*0x1068fda21*/
  while ( v16 == 4 ); /*0x1068fda29*/
  v17 = v71; /*0x1068fda2d*/
  if ( v16 != 0 ) /*0x1068fda31*/
  {
    v22 = v74; /*0x1068fdc90*/
    if ( (unsigned __int8)RBX::Network::Replicator::getStreamOutToDiskEnabled(this: *(RBX::Network::Replicator **)(a1 + 24)) != 0 ) /*0x1068fdc94*/
    {
      v45 = (RBX::Network::NetworkStream *)(*(_QWORD *)(*(_QWORD *)(a1 + 24) + 11768LL) + 72LL); /*0x1068fdca5*/
      RBX::Network::NetworkStream::Reset(this: v45); /*0x1068fdcac*/
      RBX::Network::Replicator::JoinDataItem::writeInstanceOrFingerprint( /*0x1068fdcc3*/
        a1,
        a2: a7,
        a3: (unsigned int *)v45,
        a4: 0,
        a5: (__int64)v71,
        a6: (__int64)v15);
    }
    else
    {
      RBX::Network::Replicator::JoinDataItem::writeInstance( /*0x1068fddef*/
        a1,
        a2: v75,
        a3: (RBX::Guid *)(a7 + 16),
        a4: *(unsigned __int16 **)(a7 + 24),
        a5: (unsigned int *)v73,
        a6: (__int64)v71,
        a7: (__int64)v15);
    }
    goto LABEL_17; /*0x1068fdcc8*/
  }
  v18 = *(_QWORD *)(a7 + 32); /*0x1068fda3b*/
  if ( *(_DWORD *)v18 != 1 ) /*0x1068fda42*/
  {
    v72 = (_DWORD *)*(unsigned int *)(a1 + 160); /*0x1068fdd66*/
    v52 = v71[1] - *v71; /*0x1068fdd6e*/
    v68 = v15[1] - *v15; /*0x1068fdd7a*/
    if ( (unsigned __int8)RBX::Network::Replicator::getStreamOutToDiskEnabled(this: *(RBX::Network::Replicator **)(a1 + 24)) != 0 ) /*0x1068fdd89*/
    {
      v53 = *(_QWORD *)(a1 + 24); /*0x1068fdd8f*/
      v69 = v52; /*0x1068fdd93*/
      v54 = (RBX::Network::NetworkStream *)(*(_QWORD *)(v53 + 11768) + 72LL); /*0x1068fdd9e*/
      RBX::Network::NetworkStream::Reset(this: v54); /*0x1068fdda5*/
      v55 = (unsigned int *)v54; /*0x1068fddb0*/
      v52 = v69; /*0x1068fddb3*/
      if ( (unsigned __int8)RBX::Network::Replicator::JoinDataItem::writeInstanceOrFingerprint( /*0x1068fddc6*/
                              a1,
                              a2: a7,
                              a3: v55,
                              a4: 0,
                              a5: (__int64)v71,
                              a6: (__int64)v15) != 0 )
        goto LABEL_56; /*0x1068fddc6*/
    }
    else
    {
      RBX::Network::Replicator::JoinDataItem::writeInstance( /*0x1068fdea1*/
        a1,
        a2: v75,
        a3: (RBX::Guid *)(a7 + 16),
        a4: *(unsigned __int16 **)(a7 + 24),
        a5: (unsigned int *)v73,
        a6: (__int64)v71,
        a7: (__int64)v15);
    }
    v57 = v52 >> 3; /*0x1068fdea9*/
    v58 = *(_DWORD *)(a1 + 160) - (_DWORD)v72; /*0x1068fded0*/
    v59 = *(_DWORD **)(a7 + 32); /*0x1068fded2*/
    v60 = (char *)v72 + *(_QWORD *)(a1 + 128); /*0x1068fded6*/
    v61 = *v71 + v52; /*0x1068fdee4*/
    v62 = ((v71[1] - *v71) >> 3) - v57; /*0x1068fdeee*/
    v63 = (__int64)(v15[1] - *v15) >> 3; /*0x1068fdf00*/
    v65 = *v15 + v68; /*0x1068fdf15*/
    v66 = 0x5555555555555555LL * (v68 >> 3) - 0x5555555555555555LL * v63; /*0x1068fdf19*/
    RBX::Network::CachedBitstream::update(a1: v59, a2: v60, a3: v58, a4: v61, a5: v62, a6: v63, a7: v65, a8: v66); /*0x1068fdf28*/
LABEL_56:
    boost::mutex::unlock(this: (pthread_mutex_t *)(*(_QWORD *)(a7 + 32) + 8LL)); /*0x1068fdf2d*/
LABEL_16:
    v22 = v74; /*0x1068fdaf6*/
    goto LABEL_17; /*0x1068fdaf6*/
  }
  boost::mutex::unlock(this: (pthread_mutex_t *)(v18 + 8)); /*0x1068fda4c*/
  ++*v72; /*0x1068fda55*/
  StreamOutToDiskEnabled = RBX::Network::Replicator::getStreamOutToDiskEnabled(this: *(RBX::Network::Replicator **)(a1 + 24)); /*0x1068fda5b*/
  v20 = *(_QWORD *)(a7 + 32); /*0x1068fda60*/
  if ( StreamOutToDiskEnabled != 0 ) /*0x1068fda66*/
    RBX::Network::Replicator::JoinDataItem::writeInstanceOrFingerprint( /*0x1068fda81*/
      a1,
      a2: a7,
      a3: (unsigned int *)(v20 + 80),
      a4: 1,
      a5: (__int64)v17,
      a6: (__int64)v15);
  else
    RBX::Network::NetworkStream::writeBytes(this: v73, a2: *(const void **)(v20 + 96), a3: *(_DWORD *)(v20 + 128)); /*0x1068fde07*/
  v56 = *(_QWORD **)(a7 + 32); /*0x1068fde0c*/
  if ( v56 + 18 != v17 ) /*0x1068fde1a*/
  {
    std::vector<RBX::SharedString>::__assign_with_size[abi:ne200100]<RBX::SharedString*,RBX::SharedString*>( /*0x1068fde37*/
      a1: v17,
      a2: v56[18],
      a3: v56[19],
      a4: (__int64)(v56[19] - v56[18]) >> 3);
    v56 = *(_QWORD **)(a7 + 32); /*0x1068fde3c*/
  }
  v22 = v74; /*0x1068fde40*/
  if ( v56 + 21 != v15 ) /*0x1068fde4e*/
    std::vector<RBX::Network::NetAssetHandle>::__assign_with_size[abi:ne200100]<RBX::Network::NetAssetHandle*,RBX::Network::NetAssetHandle*>( /*0x1068fde7d*/
      a1: v15,
      a2: v56[21],
      a3: v56[22],
      a4: 0xAAAAAAAAAAAAAAABLL * ((__int64)(v56[22] - v56[21]) >> 3));
LABEL_17:
  if ( (unsigned __int8)RBX::Network::Replicator::getInstanceIntentReplicationEnabled(this: *(RBX::Network::Replicator **)(a1 + 24)) != 0 /*0x1068fdb12*/
    && (unsigned __int8)RBX::CollectionService::isIntentTarget(this: v75, a2: v23) != 0 )
  {
    v24 = (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)(a1 + 24) + 688LL))(a1: *(_QWORD *)(a1 + 24)); /*0x1068fdb1b*/
    if ( FFlag::MigrateUserIdAccessors == 1 ) /*0x1068fdb2b*/
      UserID = *(_QWORD *)(v24 + 208); /*0x1068fdb2d*/
    else
      UserID = RBX::PlayerProp::getUserID(this: (RBX::PlayerProp *)(v24 + 176)); /*0x1068fdb44*/
    LOBYTE(v65) = RBX::CollectionService::getInstanceIntentForPlayer( /*0x1068fdb5f*/
                    this: *(RBX::CollectionService **)(*(_QWORD *)(a1 + 24) + 18528LL),
                    a2: v75,
                    a3: UserID);
    RBX::Network::NetworkStream::writeBytes(this: v73, a2: &v65, a3: 1u); /*0x1068fdb6a*/
  }
  RBX::Network::Replicator::writeNewSharedStrings(a1: *(_QWORD *)(a1 + 24), a2: v22, a3: v17, a4: 0); /*0x1068fdb7b*/
  v26 = *v17; /*0x1068fdb80*/
  for ( i = v17[1]; i != v26; RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: i) ) /*0x1068fdb83*/
    i -= 8; /*0x1068fdb8c*/
  v17[1] = v26; /*0x1068fdb9a*/
  RBX::Network::Replicator::inlineNetAssets(a1: *(_QWORD *)(a1 + 24), a2: v15); /*0x1068fdba5*/
  v15[1] = *v15; /*0x1068fdbae*/
  if ( DFFlag::DetailedBandwidthStatsInflux2 == 1 ) /*0x1068fdbbd*/
  {
    v29 = *(_QWORD *)(a7 + 24); /*0x1068fdbc7*/
    v30 = *(_DWORD *)(a1 + 160) - v70; /*0x1068fdbd2*/
    v31 = *(_QWORD *)(a1 + 184); /*0x1068fdbd6*/
    v32 = *(_QWORD *)(a1 + 192); /*0x1068fdbdd*/
    if ( v31 >= v32 ) /*0x1068fdbe7*/
    {
      v34 = *(const void **)(a1 + 176); /*0x1068fdc00*/
      v35 = v31 - (_QWORD)v34; /*0x1068fdc07*/
      v36 = v35 >> 4; /*0x1068fdc0d*/
      v37 = (v35 >> 4) + 1; /*0x1068fdc11*/
      if ( v37 >> 60 != 0 ) /*0x1068fdc1c*/
        std::vector<std::pair<RBX::Reflection::ClassDescriptor const*,unsigned int>>::__throw_length_error[abi:ne200100]( /*0x1068fdf3f*/
          a1: v37,
          a2: v34,
          a3: v35,
          a4: v32,
          a5: v28,
          a6: v29);
      v38 = v32 - (_QWORD)v34; /*0x1068fdc2c*/
      v39 = v38 >> 3; /*0x1068fdc32*/
      if ( v38 >> 3 <= v37 ) /*0x1068fdc39*/
        v39 = (v35 >> 4) + 1; /*0x1068fdc39*/
      if ( (unsigned __int64)v38 >= 0x7FFFFFFFFFFFFFF0LL ) /*0x1068fdc4a*/
        v39 = 0xFFFFFFFFFFFFFFFLL; /*0x1068fdc4a*/
      if ( v39 != 0 ) /*0x1068fdc51*/
      {
        v40 = *(_QWORD *)(a7 + 24); /*0x1068fdc5d*/
        v41 = std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<RBX::Reflection::ClassDescriptor const*,unsigned int>>>( /*0x1068fdc60*/
                a1: a1 + 192,
                a2: v39,
                a3: v35,
                a4: v38,
                a5: 0xFFFFFFFFFFFFFFFLL);
        v29 = v40; /*0x1068fdc65*/
        v43 = v42; /*0x1068fdc68*/
        v34 = *(const void **)(a1 + 176); /*0x1068fdc6b*/
        v35 = *(_QWORD *)(a1 + 184) - (_QWORD)v34; /*0x1068fdc79*/
        v44 = v35 >> 4; /*0x1068fdc7f*/
      }
      else
      {
        v41 = 0; /*0x1068fdccd*/
        v44 = v35 >> 4; /*0x1068fdccf*/
        v43 = 0; /*0x1068fdcd2*/
      }
      v46 = v41 + 16 * v36; /*0x1068fdcd9*/
      v47 = v41 + 16 * v43; /*0x1068fdce1*/
      v33 = v46 + 16; /*0x1068fdceb*/
      *(_QWORD *)v46 = *(_QWORD *)(v29 + 8); /*0x1068fdcef*/
      *(_DWORD *)(v46 + 8) = v30; /*0x1068fdcf3*/
      v48 = (void *)(v46 - 16 * v44); /*0x1068fdcfb*/
      memcpy(__dst: v48, __src: v34, __n: v35); /*0x1068fdd01*/
      v50 = *(RBX::Memory **)(a1 + 176); /*0x1068fdd06*/
      *(_QWORD *)(a1 + 176) = v48; /*0x1068fdd0d*/
      *(_QWORD *)(a1 + 184) = v33; /*0x1068fdd14*/
      *(_QWORD *)(a1 + 192) = v47; /*0x1068fdd1b*/
      if ( v50 != nullptr ) /*0x1068fdd25*/
        operator delete(a1: v50, a2: v49); /*0x1068fdd27*/
    }
    else
    {
      *(_QWORD *)v31 = *(_QWORD *)(v29 + 8); /*0x1068fdbed*/
      *(_DWORD *)(v31 + 8) = v30; /*0x1068fdbf0*/
      v33 = v31 + 16; /*0x1068fdbf8*/
    }
    *(_QWORD *)(a1 + 184) = v33; /*0x1068fdd2c*/
  }
  ++*v67; /*0x1068fdd37*/
  result = *(_QWORD *)(a1 + 24); /*0x1068fdd39*/
  if ( v75 == *(RBX::CollectionService **)(result + 12560) ) /*0x1068fdd48*/
    *(_BYTE *)(result + 15552) = 1; /*0x1068fdd4a*/
  return result; /*0x1068fdd51*/
}

// Address: 0x1068fdf44 | Name: __ZN3RBX7Network10Replicator12JoinDataItem14writeInstancesERNS0_13NetworkStreamE
__int64 __fastcall RBX::Network::Replicator::JoinDataItem::writeInstances(
        RBX::Network::Replicator::JoinDataItem *this,
        RBX::Network::NetworkStream *a2)
{
  unsigned int v4; // r15d
  unsigned __int64 v5; // r15
  _QWORD *v6; // rax
  __int64 v7; // rax
  bool v8; // al
  int v9; // eax
  RBX::Network::NetworkStream *v10; // r14
  __int64 v11; // rdi
  int v12; // r14d
  __int64 v13; // rdi
  unsigned __int8 v14; // cl
  __int64 v15; // rdi
  double v16; // xmm0_8
  __int128 v17; // xmm0
  int v18; // eax
  __int64 v19; // r12
  __int64 v20; // rdi
  void *v21; // rsi
  double v22; // xmm0_8
  __m128 v23; // xmm0
  __int64 v24; // r15
  __int64 v25; // r13
  __int64 v26; // rax
  float v27; // xmm0_4
  unsigned __int64 v28; // rax
  int v29; // r14d
  RBX::Network::NetworkStream *v30; // rcx
  int v31; // r15d
  _BYTE v33[16]; // [rsp+10h] [rbp-100h] BYREF
  void *v34; // [rsp+20h] [rbp-F0h]
  unsigned int v35; // [rsp+40h] [rbp-D0h]
  __int128 v36; // [rsp+50h] [rbp-C0h] BYREF
  __int64 v37; // [rsp+60h] [rbp-B0h]
  unsigned int v38; // [rsp+6Ch] [rbp-A4h] BYREF
  __int128 v39; // [rsp+70h] [rbp-A0h]
  double v40; // [rsp+88h] [rbp-88h]
  void *v41[2]; // [rsp+90h] [rbp-80h] BYREF
  __int64 v42; // [rsp+A0h] [rbp-70h]
  int v43; // [rsp+B4h] [rbp-5Ch]
  double v44; // [rsp+B8h] [rbp-58h]
  int v45; // [rsp+C4h] [rbp-4Ch] BYREF
  int v46; // [rsp+C8h] [rbp-48h]
  unsigned int v47; // [rsp+CCh] [rbp-44h]
  RBX::Network::NetworkStream *v48; // [rsp+D0h] [rbp-40h]
  unsigned int v49; // [rsp+DCh] [rbp-34h] BYREF
  RBX::Network::NetworkStream *v50; // [rsp+E0h] [rbp-30h]

  v40 = RBX::Time::now<(RBX::Time::SampleMethod)2>(a1: this); /*0x1068fdf63*/
  v48 = a2; /*0x1068fdf6b*/
  v46 = *((_DWORD *)a2 + 12); /*0x1068fdf73*/
  v50 = (RBX::Network::Replicator::JoinDataItem *)((char *)this + 112); /*0x1068fdf7a*/
  RBX::Network::NetworkStream::Reset(this: (RBX::Network::Replicator::JoinDataItem *)((char *)this + 112)); /*0x1068fdf7e*/
  if ( DFFlag::DetailedBandwidthStatsInflux2 == 1 ) /*0x1068fdf8d*/
    *((_QWORD *)this + 23) = *((_QWORD *)this + 22); /*0x1068fdf96*/
  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)v33); /*0x1068fdfa4*/
  v49 = 0; /*0x1068fdfab*/
  v45 = 0; /*0x1068fdfae*/
  v37 = 0; /*0x1068fdfb1*/
  v36 = 0; /*0x1068fdfbb*/
  v42 = 0; /*0x1068fdfc2*/
  *(_OWORD *)v41 = 0; /*0x1068fdfc6*/
  if ( *((_QWORD *)this + 29) != 0 ) /*0x1068fdfd1*/
  {
    while ( 1 ) /*0x1068fdfed*/
    {
      v4 = v49; /*0x1068fdfed*/
      if ( *((_QWORD *)this + 13) - 1LL < (unsigned __int64)v49 ) /*0x1068fdffa*/
        break; /*0x1068fdffa*/
      v5 = 1; /*0x1068fe000*/
      while ( *(_QWORD *)(RSL::Detail::Deque<RBX::Network::Replicator::JoinDataItem::ReplicationSetItem>::at( /*0x1068fe015*/
                            a1: (char *)this + 200,
                            a2: 0)
                        + 88) != 0 )
      {
        v6 = (_QWORD *)RSL::Detail::Deque<RBX::Network::Replicator::JoinDataItem::ReplicationSetItem>::at( /*0x1068fe01c*/
                         a1: (char *)this + 200,
                         a2: 0);
        RBX::Network::Replicator::JoinDataItem::writeInstanceToBitStream( /*0x1068fe052*/
          a1: (__int64)this,
          a2: &v49,
          a3: &v45,
          a4: (__int64)v33,
          a5: (__int64 *)&v36,
          a6: v41,
          a7: v6[8] + ((v6[10] % v6[9]) << 6));
        v7 = RSL::Detail::Deque<RBX::Network::Replicator::JoinDataItem::ReplicationSetItem>::at( /*0x1068fe05c*/
               a1: (char *)this + 200,
               a2: 0);
        RSL::Detail::Deque<RBX::Network::Replicator::JoinDataItem::InstanceItem>::pop_front(a1: v7 + 56); /*0x1068fe068*/
        v8 = v5++ > (unsigned int)DFInt::StreamingSetGroupSendInstanceSizeLimit; /*0x1068fe07d*/
        if ( v8 && DFInt::StreamingSetGroupSendInstanceSizeLimit > 0 ) /*0x1068fe075*/
          goto LABEL_12; /*0x1068fe085*/
      }
      RSL::Detail::Deque<RBX::Network::Replicator::JoinDataItem::ReplicationSetItem>::pop_front(a1: (char *)this + 200); /*0x1068fe090*/
      v9 = *((_DWORD *)this + 16); /*0x1068fe095*/
      if ( v9 > 0 /*0x1068fe0de*/
        && (float)(int)(*((_DWORD *)this + 40) + v35) >= (float)((float)((float)DFInt::JoinDataItemEstimatedCompressionRatioHundreths
                                                                       / 100.0)
                                                               * (float)v9)
        || *((_QWORD *)this + 29) == 0 )
      {
        goto LABEL_12; /*0x1068fe0de*/
      }
    }
  }
  else
  {
LABEL_12:
    v4 = v49; /*0x1068fe0e4*/
  }
  v38 = v4; /*0x1068fe0ef*/
  v10 = v48; /*0x1068fe0f2*/
  RBX::Network::NetworkStream::writeBytes(this: v48, a2: &v38, a3: 4u); /*0x1068fe0fe*/
  v12 = *((_DWORD *)v10 + 12); /*0x1068fe103*/
  if ( v4 != 0 ) /*0x1068fe10a*/
  {
    RBX::Network::NetworkStream::writeBytes(this: v50, a2: v34, a3: v35); /*0x1068fe11d*/
    v44 = RBX::Time::now<(RBX::Time::SampleMethod)2>(a1: v13); /*0x1068fe127*/
    RBX::Network::Replicator::compressBitStream( /*0x1068fe13e*/
      this: v50,
      a2: v48,
      a3: (RBX::Network::NetworkStream *)(unsigned __int8)DFInt::JoinDataCompressionLevel,
      a4: v14);
    v16 = RBX::Time::now<(RBX::Time::SampleMethod)2>(a1: v15); /*0x1068fe143*/
    *(double *)&v17 = (v16 - v44) * 1000.0; /*0x1068fe14d*/
    *(float *)&v17 = *(double *)&v17; /*0x1068fe155*/
    v39 = v17; /*0x1068fe159*/
    v18 = *((_DWORD *)v48 + 12); /*0x1068fe164*/
  }
  else
  {
    v39 = 0; /*0x1068fe16c*/
    v18 = v12; /*0x1068fe173*/
  }
  v47 = v4; /*0x1068fe176*/
  v19 = v4; /*0x1068fe17a*/
  *((_QWORD *)this + 9) += v4; /*0x1068fe17d*/
  *((_QWORD *)this + 10) = _mm_add_epi32( /*0x1068fe19b*/
                             _mm_insert_epi32(_mm_cvtsi32_si128(v18 - v46), *((_DWORD *)this + 40), 1),
                             _mm_loadl_epi64((const __m128i *)this + 5)).u64[0];
  v43 = v45; /*0x1068fe1a3*/
  *((_DWORD *)this + 22) += v45; /*0x1068fe1a6*/
  v22 = RBX::Time::now<(RBX::Time::SampleMethod)2>(a1: v11); /*0x1068fe1a9*/
  *(double *)v23.i64 = (v22 - v40) * 1000.0; /*0x1068fe1b6*/
  v23.f32[0] = *(double *)v23.i64; /*0x1068fe1be*/
  _mm_storel_ps( /*0x1068fe1d4*/
    (double *)((char *)this + 92),
    _mm_add_ps(_mm_insert_ps(v23, (__m128)(unsigned int)v39, 16), (__m128)*(unsigned __int64 *)((char *)this + 92)));
  if ( DFFlag::DetailedBandwidthStatsInflux2 == 1 ) /*0x1068fe1e2*/
  {
    v24 = *((_QWORD *)this + 22); /*0x1068fe1e8*/
    v25 = *((_QWORD *)this + 23); /*0x1068fe1ef*/
    if ( v24 != v25 ) /*0x1068fe1f9*/
    {
      *(float *)&v44 = (float)(*((_DWORD *)v48 + 12) - v12) / (float)*((int *)this + 40); /*0x1068fe231*/
      *(float *)&v50 = (float)(int)v35 * *(float *)&v44; /*0x1068fe23a*/
      v26 = (v25 - v24) >> 4; /*0x1068fe245*/
      if ( v26 < 0 ) /*0x1068fe249*/
      {
        v28 = ((unsigned __int64)((v25 - v24) >> 4) >> 1) | ((v25 - v24) >> 4) & 1; /*0x1068fe25e*/
        v27 = (float)(int)v28 + (float)(int)v28; /*0x1068fe269*/
      }
      else
      {
        v27 = (float)(int)v26; /*0x1068fe24e*/
      }
      *(float *)&v50 = *(float *)&v50 / v27; /*0x1068fe276*/
      do /*0x1068fe2ad*/
      {
        RBX::Network::OngoingBandwidthStats::recordNewInstance( /*0x1068fe2a1*/
          this: (RBX::Network::OngoingBandwidthStats *)(*((_QWORD *)this + 3) + 10208LL),
          a2: *(const RBX::Reflection::ClassDescriptor **)v24,
          a3: (float)((float)*(int *)(v24 + 8) * *(float *)&v44) + *(float *)&v50);
        v24 += 16; /*0x1068fe2a6*/
      }
      while ( v24 != v25 ); /*0x1068fe2ad*/
    }
  }
  if ( v47 != 0 ) /*0x1068fe2b3*/
  {
    v29 = DFLog::NetworkJoin; /*0x1068fe2c0*/
    if ( (unsigned __int8)DFLog::NetworkJoin >= 6u && BYTE1(DFLog::NetworkJoin) >= 3u ) /*0x1068fe2d3*/
    {
      if ( (*((_BYTE *)this + 240) & 1) != 0 ) /*0x1068fe2e5*/
        v30 = *((RBX::Network::NetworkStream **)this + 32); /*0x1068fe2f0*/
      else
        v30 = (RBX::Network::Replicator::JoinDataItem *)((char *)this + 241); /*0x1068fe2e7*/
      v50 = v30; /*0x1068fe2f7*/
      v31 = qword_10D7F3E08; /*0x1068fe2fb*/
      RBX::Time::now<(RBX::Time::SampleMethod)2>(a1: v20); /*0x1068fe307*/
      FLog::FastLogFormatted( /*0x1068fe35c*/
        a1: v29,
        a2: v31,
        a3: (unsigned int)"[DFLog::NetworkJoin] %s Finished writing %u instances %u from cache %u bytes %fms (%u bytes uncomp"
                      "ressed %fms compress time)",
        a4: (_DWORD)v50,
        a5: v47,
        a6: v43);
    }
  }
  if ( v41[0] != nullptr ) /*0x1068fe368*/
  {
    v41[1] = v41[0]; /*0x1068fe36a*/
    operator delete(a1: (RBX::Memory *)v41[0], a2: v21); /*0x1068fe36e*/
  }
  v41[0] = &v36; /*0x1068fe37e*/
  std::vector<RBX::SharedString>::__destroy_vector::operator()[abi:ne200100](a1: v41); /*0x1068fe381*/
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v33); /*0x1068fe38d*/
  return v19; /*0x1068fe395*/
}

// Address: 0x1068fe4b8 | Name: __ZN3RBX7Network10Replicator12JoinDataItem11addInstanceENSt3__110shared_ptrINS_8InstanceEEERKNS0_18NetworkSchemaTypes9ClassInfoENS4_INS0_15CachedBitstreamEEEbjNS0_20StreamingFingerprintE
__int64 __fastcall RBX::Network::Replicator::JoinDataItem::addInstance(
        _QWORD *a1,
        __int64 a2,
        unsigned __int64 a3,
        __int64 a4,
        __int64 a5,
        int a6,
        char a7)
{
  unsigned __int64 v9; // rbx
  __int64 v10; // r15
  __int64 v12; // rax
  __int64 v13; // rax
  __int64 v15[6]; // [rsp+0h] [rbp-30h] BYREF

  v9 = a3; /*0x1068fe4cc*/
  v10 = a2; /*0x1068fe4cf*/
  v15[0] = 0xFFFFFFFFLL; /*0x1068fe4da*/
  v12 = *(_QWORD *)(*(_QWORD *)a2 + 104LL); /*0x1068fe4e1*/
  if ( v12 != 0 ) /*0x1068fe4e8*/
    v15[0] = *(_QWORD *)(v12 + 48); /*0x1068fe4ee*/
  if ( (_BYTE)a5 != 0 ) /*0x1068fe4f5*/
    v15[0] = 0xFFFFFFFFLL; /*0x1068fe4fc*/
  v13 = a1[29]; /*0x1068fe504*/
  if ( v13 == 0 /*0x1068fe53f*/
    || (a3 = (unsigned __int64)(a1[28] + v13 - 1) % a1[27], a6 == -1)
    || *(_DWORD *)((a2 = a1[26]) + 96 * a3) != a6 )
  {
    RSL::Detail::Deque<RBX::Network::Replicator::JoinDataItem::ReplicationSetItem>::emplace_back<>( /*0x1068fe548*/
      a1: a1 + 25,
      a2,
      a3,
      a4,
      a5,
      a6: &a7,
      a7: v15[0]);
    a2 = a1[26]; /*0x1068fe558*/
    a3 = (unsigned __int64)(a1[28] + a1[29] - 1LL) % a1[27]; /*0x1068fe56e*/
    *(_DWORD *)(a2 + 96 * a3) = a6; /*0x1068fe57d*/
  }
  return RSL::Detail::Deque<RBX::Network::Replicator::JoinDataItem::InstanceItem>::emplace_back<std::shared_ptr<RBX::Instance>,RBX::Guid &,RBX::Network::NetworkSchemaTypes::ClassInfo const&,std::shared_ptr<RBX::Network::CachedBitstream>,RBX::Network::StreamingFingerprint>( /*0x1068fe5a7*/
           a1: a2 + 96 * a3 + 56,
           a2: v10,
           a3: v15,
           a4: v9,
           a5: a4,
           a6: &a7);
}

// Address: 0x1068fe8f6 | Name: __ZN3RBX7Network10Replicator12JoinDataItem5writeERNS0_13NetworkStreamE
bool __fastcall RBX::Network::Replicator::JoinDataItem::write(
        RBX::Network::Replicator::JoinDataItem *this,
        RBX::Network::NetworkStream *a2)
{
  ++*((_DWORD *)this + 17); /*0x1068fe903*/
  RBX::Network::Item::writeItemType(a1: (__int64)this, a2, a3: 0xBu); /*0x1068fe90b*/
  RBX::Network::Replicator::JoinDataItem::writeInstances(this, a2); /*0x1068fe916*/
  return *((_QWORD *)this + 29) == 0; /*0x1068fe926*/
}

// Address: 0x1068fe92c | Name: __ZN3RBX7Network10Replicator12JoinDataItem4readERS1_RNS0_13NetworkStreamE
RBX::Network::Replicator::JoinDataItem *__fastcall RBX::Network::Replicator::JoinDataItem::read(
        RBX::Network::Replicator::JoinDataItem *this,
        RBX::Network::Replicator *a2,
        RBX::Network::NetworkStream *a3)
{
  unsigned int v5; // ebx
  __int64 v6; // rdi
  unsigned __int64 v7; // rsi
  unsigned int UInt32; // r15d
  __int64 v9; // r14
  int v10; // r13d
  int v11; // r12d
  int v12; // ebx
  __int64 *v13; // r14
  __int64 v14; // rdx
  __int64 v15; // r12
  __int64 v16; // r15
  int v17; // r13d
  __int64 v18; // rdi
  __int64 v19; // rbx
  __int64 v20; // rax
  __int64 v21; // rcx
  float v22; // xmm2_4
  double v23; // xmm0_8
  _QWORD v25[6]; // [rsp+8h] [rbp-D8h] BYREF
  unsigned int v26[14]; // [rsp+38h] [rbp-A8h] BYREF
  int v27; // [rsp+70h] [rbp-70h]
  double v28; // [rsp+78h] [rbp-68h]
  RBX::Network::Replicator::JoinDataItem *v29; // [rsp+80h] [rbp-60h]
  RBX::Network::NetworkStream *v30; // [rsp+88h] [rbp-58h]
  unsigned int v31[2]; // [rsp+90h] [rbp-50h]
  __int64 v32; // [rsp+98h] [rbp-48h]
  RBX::Instance *v33; // [rsp+A0h] [rbp-40h]
  float v34; // [rsp+ACh] [rbp-34h]
  int v35; // [rsp+B0h] [rbp-30h]
  RBX::Memory *v36; // [rsp+B4h] [rbp-2Ch]

  v33 = a2; /*0x1068fe943*/
  v5 = RBX::Memory::setCurrentCategory( /*0x1068fe958*/
         this: (RBX::Memory *)(unsigned int)RBX::Memory::NetworkReplicatedInstances,
         (unsigned int)a2);
  v28 = RBX::Time::now<(RBX::Time::SampleMethod)2>(a1: v6); /*0x1068fe95f*/
  UInt32 = RBX::Network::NetworkStream::readUInt32(this: a3); /*0x1068fe96c*/
  if ( UInt32 != 0 ) /*0x1068fe971*/
  {
    LODWORD(v36) = v5; /*0x1068fe97c*/
    v9 = operator new(a1: (RBX::Memory *)0x40, a2: v7); /*0x1068fe984*/
    RBX::Network::DeserializedJoinDataItem::DeserializedJoinDataItem(a1: v9, a2: 11); /*0x1068fe98f*/
    v35 = *((_DWORD *)a3 + 14); /*0x1068fe998*/
    v32 = v9; /*0x1068fe9a2*/
    RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)v26); /*0x1068fe9a6*/
    v29 = this; /*0x1068fe9ab*/
    RBX::Network::Replicator::decompressBitStream(this: a3, a2: (RBX::Network::NetworkStream *)v26, a3: 0); /*0x1068fe9bb*/
    v30 = a3; /*0x1068fe9c0*/
    v10 = *((_DWORD *)a3 + 14); /*0x1068fe9c4*/
    v11 = v26[12]; /*0x1068fe9c8*/
    v12 = v27; /*0x1068fe9cc*/
    v13 = (__int64 *)(v9 + 32); /*0x1068fe9cf*/
    std::vector<RBX::Network::DeserializedNewObjectItem>::resize(a1: v13, a2: UInt32); /*0x1068fe9dc*/
    v34 = (float)(v10 - v35) / (float)v11; /*0x1068fe9f6*/
    LOBYTE(v25[0]) = 0; /*0x1068fea02*/
    v25[1] = 16; /*0x1068fea05*/
    v25[2] = 0; /*0x1068fea0d*/
    LODWORD(v25[3]) = 1065353216; /*0x1068fea15*/
    *(_OWORD *)&v25[4] = 0; /*0x1068fea1f*/
    v14 = *v13; /*0x1068fea23*/
    *(_QWORD *)v31 = UInt32; /*0x1068fea26*/
    v15 = 216LL * UInt32; /*0x1068fea2a*/
    v16 = 0; /*0x1068fea31*/
    do /*0x1068fea7b*/
    {
      RBX::Network::Replicator::JoinDataItem::readInstance(this: v33, a2: v26, a3: v16 + v14, a4: v25); /*0x1068fea49*/
      v17 = v27; /*0x1068fea4e*/
      v14 = *v13; /*0x1068fea64*/
      *(float *)(*v13 + v16 + 16) = (float)(v27 - v12) * v34; /*0x1068fea67*/
      v16 += 216; /*0x1068fea6e*/
      v12 = v17; /*0x1068fea75*/
    }
    while ( v15 != v16 ); /*0x1068fea7b*/
    RBX::Network::Replicator::readNewSharedStrings(a1: v33, a2: v26, a3: v25); /*0x1068fea8f*/
    v19 = v32; /*0x1068fea94*/
    v20 = *(_QWORD *)(v32 + 32); /*0x1068fea98*/
    v21 = *(_QWORD *)(v32 + 40); /*0x1068fea9c*/
    if ( v20 != v21 ) /*0x1068feaac*/
    {
      v22 = v34 * (float)((float)(v27 - v17) / (float)(int)v31[0]); /*0x1068feac8*/
      do /*0x1068feae3*/
      {
        *(float *)(v20 + 16) = *(float *)(v20 + 16) + v22; /*0x1068fead5*/
        v20 += 216; /*0x1068feada*/
      }
      while ( v20 != v21 ); /*0x1068feae3*/
    }
    *(float *)(v19 + 16) = (float)(*((_DWORD *)v30 + 14) - v35 + 4); /*0x1068feafa*/
    v23 = RBX::Time::now<(RBX::Time::SampleMethod)2>(a1: v18); /*0x1068feaff*/
    *(float *)&v23 = (v23 - v28) * 1000.0; /*0x1068feb11*/
    *((float *)v33 + 3908) = *(float *)&v23 + *((float *)v33 + 3908); /*0x1068feb21*/
    this = v29; /*0x1068feb29*/
    *(_QWORD *)v29 = v19; /*0x1068feb2d*/
    boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::vector<RBX::Network::DeferredSharedStringSetter>>>,std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string>,std::equal_to<std::string>>>::delete_buckets(a1: (__int64)v25); /*0x1068feb38*/
    v5 = (unsigned int)v36; /*0x1068feb3d*/
    RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v26); /*0x1068feb47*/
  }
  else
  {
    *(_QWORD *)this = 0; /*0x1068feb4e*/
  }
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v5, a2: v7); /*0x1068feb58*/
  return this; /*0x1068feb60*/
}

// Address: 0x1068fec66 | Name: __ZNK3RBX7Network10Replicator12JoinDataItem5emptyEv
bool __fastcall RBX::Network::Replicator::JoinDataItem::empty(RBX::Network::Replicator::JoinDataItem *this)
{
  return *((_QWORD *)this + 29) == 0; /*0x1068fec75*/
}

// Address: 0x1068fec78 | Name: __ZNK3RBX7Network10Replicator12JoinDataItem4sizeEv
__int64 __fastcall RBX::Network::Replicator::JoinDataItem::size(RBX::Network::Replicator::JoinDataItem *this)
{
  return *((_QWORD *)this + 29); /*0x1068fec83*/
}

// Address: 0x1068fec88 | Name: __ZNK3RBX7Network10Replicator12JoinDataItem7getTypeEv
__int64 __fastcall RBX::Network::Replicator::JoinDataItem::getType(RBX::Network::Replicator::JoinDataItem *this)
{
  return 11; /*0x1068fec91*/
}

// Address: 0x106900dca | Name: __ZN3RBX7Network10Replicator12JoinDataItemC2EPS1_j
__int64 __fastcall RBX::Network::Replicator::JoinDataItem::JoinDataItem(
        RBX::Network::Replicator::JoinDataItem *this,
        RBX::Network::Replicator *a2,
        unsigned int a3)
{
  RSL::Arena *v5; // rdi
  __int64 v6; // rdx
  __int64 v7; // rcx
  __int64 result; // rax

  RBX::Network::Item::Item(this, a2); /*0x106900dde*/
  *(_QWORD *)this = off_10CAB1CA8; /*0x106900dee*/
  *((_DWORD *)this + 16) = -1; /*0x106900df1*/
  *((_QWORD *)this + 13) = 0; /*0x106900dfb*/
  *(_OWORD *)((char *)this + 68) = 0; /*0x106900e06*/
  *(_OWORD *)((char *)this + 84) = 0; /*0x106900e0a*/
  RBX::Network::NetworkStream::NetworkStream( /*0x106900e14*/
    this: (RBX::Network::Replicator::JoinDataItem *)((char *)this + 112),
    a2: a3);
  *((_QWORD *)this + 24) = 0; /*0x106900e20*/
  *((_OWORD *)this + 11) = 0; /*0x106900e2a*/
  *((_QWORD *)this + 25) = RSL::Arena::getDefaultArena(this: v5); /*0x106900e3d*/
  *((_OWORD *)this + 13) = 0; /*0x106900e47*/
  *((_OWORD *)this + 14) = 0; /*0x106900e4e*/
  result = std::string::basic_string[abi:ne200100]<0>(a1: (char *)this + 240, a2: "JoinDataItem", a3: v6, a4: v7); /*0x106900e63*/
  *((_BYTE *)this + 264) = 1; /*0x106900e68*/
  return result; /*0x106900e73*/
}

// END JoinDataItem part 1/1, 17 functions
