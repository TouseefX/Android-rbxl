// Peer -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 30 functions


// Address: 0x1066f81be | Name: __ZN3RBX7Network4Peer13doReceiveLoopEv
void __fastcall RBX::Network::Peer::doReceiveLoop(RBX::Network::Peer *this)
{
  ; /*0x1066f81be*/
}

// Address: 0x1067a5a22 | Name: __ZN3RBX7Network4PeerC2ERNS_28ForceConstructionInCreatableE
__int64 __fastcall RBX::Network::Peer::Peer(__int64 a1)
{
  __int64 v2; // rdi
  __int64 result; // rax

  RBX::Described<RBX::Network::Peer,RBX::Instance>::Described<RBX::ForceConstructionInCreatable &>(a1); /*0x1067a5a33*/
  *(_QWORD *)a1 = off_10CAF1EB0; /*0x1067a5a43*/
  *(_QWORD *)(a1 + 176) = off_10CAF2148; /*0x1067a5a4c*/
  *(_QWORD *)(a1 + 184) = 0x3FA999999999999ALL; /*0x1067a5a5d*/
  *(_OWORD *)(a1 + 192) = 0; /*0x1067a5a67*/
  *(_QWORD *)(a1 + 208) = 0; /*0x1067a5a6e*/
  *(_BYTE *)(a1 + 216) = 1; /*0x1067a5a79*/
  *(double *)(a1 + 224) = RBX::Time::now<(RBX::Time::SampleMethod)1>(a1: v2); /*0x1067a5a85*/
  *(_BYTE *)(a1 + 232) = 1; /*0x1067a5a8f*/
  *(_QWORD *)(a1 + 240) = 0x3FA999999999999ALL; /*0x1067a5a95*/
  *(_OWORD *)(a1 + 248) = 0; /*0x1067a5a9f*/
  *(_QWORD *)(a1 + 264) = 0; /*0x1067a5aa8*/
  *(_BYTE *)(a1 + 272) = 1; /*0x1067a5aaf*/
  *(_OWORD *)(a1 + 280) = 0; /*0x1067a5abc*/
  *(_OWORD *)(a1 + 296) = 0; /*0x1067a5ac3*/
  *(_OWORD *)(a1 + 312) = 0; /*0x1067a5aca*/
  *(_QWORD *)(a1 + 328) = 0; /*0x1067a5ad1*/
  *(_OWORD *)(a1 + 344) = 0; /*0x1067a5ad8*/
  *(_QWORD *)(a1 + 360) = 0; /*0x1067a5adf*/
  RBX::Random::Random(this: (RBX::Random *)(a1 + 368)); /*0x1067a5ae6*/
  *(_OWORD *)(a1 + 424) = 0; /*0x1067a5b0a*/
  *(_OWORD *)(a1 + 408) = 0; /*0x1067a5b11*/
  *(_OWORD *)(a1 + 392) = 0; /*0x1067a5b18*/
  *(_OWORD *)(a1 + 376) = 0; /*0x1067a5b1f*/
  result = RBX::Subsystem<RBX::Network::NetworkTracer,true>::startup<RBX::SubsystemDefaultFactory<RBX::Network::NetworkTracer>>(); /*0x1067a5b26*/
  *(_QWORD *)(a1 + 440) = result; /*0x1067a5b2b*/
  *(_DWORD *)(a1 + 448) = 0; /*0x1067a5b32*/
  *(_QWORD *)(a1 + 456) = 0; /*0x1067a5b3c*/
  RBX::Network::Peer::aesKey = xmmword_109A00AE0; /*0x1067a5b4e*/
  *(_DWORD *)(a1 + 336) = 36; /*0x1067a5b55*/
  return result; /*0x1067a5b63*/
}

// Address: 0x1067a5c56 | Name: __ZN3RBX7Network4PeerD2Ev
void __fastcall RBX::Network::Peer::~Peer(RBX::Network::Peer *this)
{
  __int64 v2; // rsi
  __int64 v3; // rdi
  __int64 v4; // rdi
  __int64 v5; // rdi
  __int64 v6; // rdi
  __int64 i; // r14
  std::__shared_weak_count *v8; // rdi

  *(_QWORD *)this = off_10CAF1EB0; /*0x1067a5c6b*/
  *((_QWORD *)this + 22) = off_10CAF2148; /*0x1067a5c74*/
  v2 = *((_QWORD *)this + 57); /*0x1067a5c7b*/
  *((_QWORD *)this + 57) = 0; /*0x1067a5c82*/
  if ( v2 != 0 ) /*0x1067a5c90*/
    std::default_delete<RBX::RemoteAllowList>::operator()[abi:ne200100](a1: (char *)this + 456); /*0x1067a5c99*/
  v3 = *((_QWORD *)this + 55); /*0x1067a5c9e*/
  if ( v3 != 0 ) /*0x1067a5ca8*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 16LL))(a1: v3); /*0x1067a5cad*/
  v4 = *((_QWORD *)this + 54); /*0x1067a5cb0*/
  *((_QWORD *)this + 54) = 0; /*0x1067a5cb7*/
  if ( v4 != 0 ) /*0x1067a5cc5*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 8LL))(a1: v4); /*0x1067a5cca*/
  v5 = *((_QWORD *)this + 53); /*0x1067a5ccd*/
  *((_QWORD *)this + 53) = 0; /*0x1067a5cd4*/
  if ( v5 != 0 ) /*0x1067a5ce2*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v5 + 8LL))(a1: v5); /*0x1067a5ce7*/
  std::shared_ptr<RBX::Network::NetworkFilterWhiteList>::~shared_ptr[abi:ne200100](a1: (char *)this + 408); /*0x1067a5cf1*/
  std::shared_ptr<RBX::Network::NetworkFilterWhiteList>::~shared_ptr[abi:ne200100](a1: (char *)this + 392); /*0x1067a5cfd*/
  std::shared_ptr<RBX::Network::NetworkFilterGlobalStats>::~shared_ptr[abi:ne200100](a1: (char *)this + 376); /*0x1067a5d09*/
  std::shared_ptr<RBX::Network::PacketReceiveJob>::~shared_ptr[abi:ne200100](a1: (char *)this + 352); /*0x1067a5d15*/
  v6 = *((_QWORD *)this + 43); /*0x1067a5d1a*/
  *((_QWORD *)this + 43) = 0; /*0x1067a5d21*/
  if ( v6 != 0 ) /*0x1067a5d2f*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v6 + 8LL))(a1: v6); /*0x1067a5d34*/
  for ( i = 328; i != 296; i -= 16 ) /*0x1067a5d37*/
  {
    v8 = *(std::__shared_weak_count **)((char *)this + i); /*0x1067a5d3d*/
    if ( v8 != nullptr ) /*0x1067a5d44*/
      std::__shared_weak_count::__release_weak(this: v8); /*0x1067a5d46*/
  }
  std::shared_ptr<RBX::Network::ConcurrentRakPeer>::~shared_ptr[abi:ne200100](a1: (char *)this + 288); /*0x1067a5d5f*/
  RBX::Network::NetworkPeerProp::~NetworkPeerProp(this); /*0x1067a5d67*/
  RBX::Instance::~Instance(this); /*0x1067a5d73*/
}

// Address: 0x1067a5d80 | Name: __ZN3RBX7Network4PeerD1Ev
void __fastcall __noreturn RBX::Network::Peer::~Peer(RBX::Network::Peer *this)
{
  BUG(); /*0x1067a5d84*/
}

// Address: 0x1067a5d86 | Name: __ZThn176_N3RBX7Network4PeerD1Ev
void __fastcall __noreturn `non-virtual thunk to'RBX::Network::Peer::~Peer(RBX::Network::Peer *this)
{
  BUG(); /*0x1067a5d8a*/
}

// Address: 0x1067a5d8c | Name: __ZN3RBX7Network4PeerD0Ev
void __fastcall __noreturn RBX::Network::Peer::~Peer(RBX::Network::Peer *this)
{
  BUG(); /*0x1067a5d90*/
}

// Address: 0x1067a5d92 | Name: __ZThn176_N3RBX7Network4PeerD0Ev
void __fastcall __noreturn `non-virtual thunk to'RBX::Network::Peer::~Peer(RBX::Network::Peer *this)
{
  BUG(); /*0x1067a5d96*/
}

// Address: 0x1067a5d98 | Name: __ZN3RBX7Network4Peer15onCreateRakPeerEv
__int64 __fastcall RBX::Network::Peer::onCreateRakPeer(RBX::Network::ConcurrentRakPeer **this)
{
  _QWORD *v2; // rax
  __int64 v3; // rdx
  __int64 v4; // rsi
  __int64 v5; // r8
  __int64 v6; // r9
  _QWORD *v7; // rax
  __int64 v8; // rax

  v2 = (_QWORD *)RBX::Network::ConcurrentRakPeer::rawPeer(this: *(this + 36)); /*0x1067a5dab*/
  v7 = (_QWORD *)(*(__int64 (__fastcall **)(_QWORD *, __int64, __int64, _QWORD, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD))(*v2 + 424LL))( /*0x1067a5ddd*/
                   a1: v2,
                   a2: v4,
                   a3: v3,
                   a4: *v2,
                   a5: v5,
                   a6: v6,
                   a7: RakNet::UNASSIGNED_SYSTEM_ADDRESS,
                   a8: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 1),
                   a9: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 2),
                   a10: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 3),
                   a11: RakNet::UNASSIGNED_SYSTEM_ADDRESS,
                   a12: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 1),
                   a13: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 2),
                   a14: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 3));
  RBX::Random::reseed(this: (RBX::Random *)(this + 46), a2: HIDWORD(*v7) ^ (unsigned int)*v7); /*0x1067a5df6*/
  v8 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *(this + 36)); /*0x1067a5e02*/
  return (*(__int64 (__fastcall **)(__int64, __int64))(*(_QWORD *)v8 + 376LL))(a1: v8, a2: 1); /*0x1067a5e19*/
}

// Address: 0x1067a5e22 | Name: __ZN3RBX7Network4Peer15encryptDataPartERNS0_13NetworkStreamE
__int64 __fastcall RBX::Network::Peer::encryptDataPart(RBX::Network::Peer *this, RBX::Network::NetworkStream *a2)
{
  return RBX::Network::Peer::encryptDataPartWithKey(this, a2, a3: (const unsigned __int8 *)&RBX::Network::Peer::aesKey); /*0x1067a5e2d*/
}

// Address: 0x1067a5e34 | Name: __ZN3RBX7Network4Peer22encryptDataPartWithKeyERNS0_13NetworkStreamEPKh
__int64 __fastcall RBX::Network::Peer::encryptDataPartWithKey(
        RBX::Network::Peer *this,
        RBX::Network::NetworkStream *a2,
        const unsigned __int8 *a3)
{
  int v6; // r12d
  int v7; // eax
  __int64 v8; // r12
  __int64 v9; // rax
  unsigned int v11; // [rsp+8h] [rbp-288h] BYREF
  _BYTE v12[604]; // [rsp+Ch] [rbp-284h] BYREF

  DataBlockEncryptor::DataBlockEncryptor(this: (DataBlockEncryptor *)v12); /*0x1067a5e64*/
  DataBlockEncryptor::SetKey(this: (DataBlockEncryptor *)v12, a2: a3); /*0x1067a5e73*/
  v6 = (*(__int64 (__fastcall **)(RBX::Network::NetworkStream *))(*(_QWORD *)a2 + 24LL))(a1: a2); /*0x1067a5e81*/
  LODWORD(a3) = v6 - 1; /*0x1067a5e84*/
  v11 = v6 - 1; /*0x1067a5e89*/
  v7 = (*(__int64 (__fastcall **)(RBX::Network::NetworkStream *))(*(_QWORD *)a2 + 24LL))(a1: a2); /*0x1067a5e96*/
  RBX::Network::NetworkStream::AddBytesAndReallocate(this: a2, a2: ((v6 + 20) & 0xFFFFFFF0) + 1 - v7); /*0x1067a5ead*/
  v8 = (*(__int64 (__fastcall **)(RBX::Network::NetworkStream *))(*(_QWORD *)a2 + 16LL))(a1: a2); /*0x1067a5ebb*/
  v9 = (*(__int64 (__fastcall **)(RBX::Network::NetworkStream *))(*(_QWORD *)a2 + 16LL))(a1: a2); /*0x1067a5ec4*/
  DataBlockEncryptor::Encrypt( /*0x1067a5eee*/
    this: (DataBlockEncryptor *)v12,
    a2: (unsigned __int8 *)(v8 + 1),
    (unsigned int)a3,
    a4: (unsigned __int8 *)(v9 + 1),
    a5: &v11,
    a6: (RBX::Network::Peer *)((char *)this + 368));
  RBX::Network::NetworkStream::SetWriteOffsetBytes(this: a2, a2: v11 + 1, a3: 0); /*0x1067a5f00*/
  DataBlockEncryptor::~DataBlockEncryptor(this: (DataBlockEncryptor *)v12); /*0x1067a5f0c*/
  return __stack_chk_guard; /*0x1067a5f21*/
}

// Address: 0x1067a5f56 | Name: __ZN3RBX7Network4Peer15decryptDataPartERNS0_13NetworkStreamE
__int64 __fastcall RBX::Network::Peer::decryptDataPart(
        RBX::Network::Peer *this,
        RBX::Network::NetworkStream *a2,
        const unsigned __int8 *a3)
{
  return RBX::Network::Peer::decryptDataPartWithKey( /*0x1067a5f61*/
           this,
           a2: (RBX::Network::NetworkStream *)&RBX::Network::Peer::aesKey,
           a3);
}

// Address: 0x1067a5f68 | Name: __ZN3RBX7Network4Peer22decryptDataPartWithKeyERNS0_13NetworkStreamEPKh
__int64 __fastcall RBX::Network::Peer::decryptDataPartWithKey(
        RBX::Network::Peer *this,
        RBX::Network::NetworkStream *a2,
        const unsigned __int8 *a3)
{
  __int64 v5; // r15
  __int64 v6; // rax
  std::runtime_error *exception; // r14
  unsigned int v9; // [rsp+0h] [rbp-280h] BYREF
  _BYTE v10[604]; // [rsp+4h] [rbp-27Ch] BYREF

  DataBlockEncryptor::DataBlockEncryptor(this: (DataBlockEncryptor *)v10); /*0x1067a5f93*/
  DataBlockEncryptor::SetKey(this: (DataBlockEncryptor *)v10, (const unsigned __int8 *)a2); /*0x1067a5fa2*/
  v9 = (*(__int64 (__fastcall **)(RBX::Network::Peer *))(*(_QWORD *)this + 24LL))(a1: this) - 1; /*0x1067a5fb6*/
  v5 = (*(__int64 (__fastcall **)(RBX::Network::Peer *))(*(_QWORD *)this + 16LL))(a1: this); /*0x1067a5fc6*/
  v6 = (*(__int64 (__fastcall **)(RBX::Network::Peer *))(*(_QWORD *)this + 16LL))(a1: this); /*0x1067a5fcf*/
  if ( DataBlockEncryptor::Decrypt( /*0x1067a5ff6*/
         this: (DataBlockEncryptor *)v10,
         a2: (unsigned __int8 *)(v5 + 1),
         a3: v9,
         a4: (unsigned __int8 *)(v6 + 1),
         a5: &v9) == 0 )
  {
    exception = (std::runtime_error *)__cxa_allocate_exception(thrown_size: 0x10u); /*0x1067a602c*/
    std::runtime_error::runtime_error(this: exception, a2: "Data error"); /*0x1067a6039*/
    __cxa_throw( /*0x1067a604f*/
      a1: exception,
      lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
      a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
  }
  DataBlockEncryptor::~DataBlockEncryptor(this: (DataBlockEncryptor *)v10); /*0x1067a5fff*/
  return __stack_chk_guard; /*0x1067a6014*/
}

// Address: 0x1067a6088 | Name: __ZNK3RBX7Network4Peer11askAddChildEPKNS_8InstanceE
bool __fastcall RBX::Network::Peer::askAddChild(RBX::Network::Peer *this, const RBX::Instance *a2)
{
  __int64 v2; // rbx
  __int64 v3; // rax

  if ( a2 == nullptr ) /*0x1067a608b*/
    return false; /*0x1067a60bf*/
  v2 = *((_QWORD *)a2 + 3); /*0x1067a6093*/
  v3 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Replicator>(a1: this); /*0x1067a6097*/
  return *(unsigned __int16 *)(v2 + 440) - (unsigned int)*(unsigned __int16 *)(v3 + 440) <= *(unsigned __int16 *)(v3 + 442); /*0x1067a60be*/
}

// Address: 0x1067a60c2 | Name: __ZN3RBX7Network4Peer20setOutgoingKBPSLimitEi
__int64 __fastcall RBX::Network::Peer::setOutgoingKBPSLimit(RBX::Network::ConcurrentRakPeer **this, int a2)
{
  __int64 v3; // rax
  unsigned int v4; // ecx
  int v5; // edx
  __int64 v6; // rsi

  v3 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *(this + 36)); /*0x1067a60d1*/
  if ( a2 <= 0 ) /*0x1067a60d8*/
  {
    v6 = 0; /*0x1067a60f7*/
  }
  else
  {
    v4 = 10000; /*0x1067a60da*/
    if ( (unsigned int)a2 < 0x2710 ) /*0x1067a60e1*/
      v4 = a2; /*0x1067a60e1*/
    v5 = 10; /*0x1067a60e7*/
    if ( v4 >= 0xB ) /*0x1067a60ec*/
      v5 = v4; /*0x1067a60ec*/
    v6 = (unsigned int)(1000 * v5); /*0x1067a60ef*/
  }
  return (*(__int64 (__fastcall **)(__int64, __int64))(*(_QWORD *)v3 + 584LL))(a1: v3, a2: v6); /*0x1067a610b*/
}

// Address: 0x1067a610e | Name: __ZN3RBX7Network4Peer17onServiceProviderEPNS_15ServiceProviderES3_
RBX::Instance **__fastcall RBX::Network::Peer::onServiceProvider(
        RBX::Network::Peer *this,
        RBX::ServiceProvider *a2,
        RBX::ServiceProvider *a3)
{
  RBX::ServiceProvider *v3; // r13
  __int64 v6; // rdx
  __int64 v7; // rcx
  __int64 v8; // r15
  __int64 FirstChildByName; // rax
  __int64 v10; // rsi
  void *v11; // rsi
  std::__shared_weak_count *v12; // r15
  _OWORD *v13; // r15
  __int64 v14; // rax
  std::__shared_weak_count *v15; // rdi
  __int64 v16; // rax
  std::__shared_weak_count *v17; // r13
  RBX::Network::ConcurrentRakPeer *v18; // rdi
  __int64 v19; // r13
  __int64 v20; // rax
  int v21; // ecx
  RBX::Network::ConcurrentRakPeer *v22; // rdi
  __int64 v23; // rax
  __int64 v24; // rdi
  RBX::Instance **result; // rax
  RBX::Network::NetworkFilterGlobalStats *v26; // rdi
  unsigned __int64 v27; // rsi
  RBX::Network::NetAssetManager *NetAssetManager_subsystem; // rax
  RBX::Network::NetAssetManager *v29; // rax
  __int64 v30; // r14
  __int64 v31; // rax
  RBX::Network::ConcurrentRakPeer *v32; // r12
  unsigned __int64 v33; // rsi
  RakNet::RakPeer *v34; // r13
  __int64 v35; // rax
  unsigned __int64 v36; // rsi
  RBX::DataModelJob *v37; // r12
  __int64 v38; // rax
  std::__shared_weak_count *v39; // r12
  std::__shared_weak_count *v40; // r12
  std::__shared_weak_count *v41; // r12
  __int64 v42; // rax
  unsigned __int64 v43; // rsi
  std::__shared_weak_count *v44; // r15
  std::__shared_weak_count *v45; // r15
  unsigned __int64 v46; // rsi
  std::__shared_weak_count *v47; // r15
  RBX::Instance *v48; // rsi
  std::__shared_weak_count *v49; // r15
  RBX::DataModel *v50; // rax
  std::__shared_weak_count *v51; // rax
  RBX::Instance *v52; // rsi
  RBX::Network::NetAssetHelpers *v53; // rax
  RBX::DataModel *v54; // rsi
  __int64 NetAssetManager; // rax
  unsigned __int64 v56; // rsi
  RBX::Network::NetAssetManager *v57; // r15
  char v58; // al
  _QWORD *v59; // rax
  unsigned __int64 v60; // rsi
  __int64 v61; // rdi
  _QWORD *v62; // rax
  __int64 v63; // rdi
  unsigned __int64 v64; // rsi
  std::__shared_weak_count *v65; // rax
  __int64 v66; // rdi
  std::__shared_weak_count *v67; // rdi
  __int64 v68; // r12
  std::__shared_weak_count *v69; // r12
  _QWORD *v70; // r12
  unsigned __int64 v71; // rsi
  _QWORD *v72; // rax
  __int64 v73; // rdi
  RBX::EngineContext *v74; // rdi
  RBX::Instance *v75; // r14
  __int128 v76; // kr00_16
  __int64 v77; // rdx
  __int64 v78; // rcx
  void *v79; // rsi
  __int128 v80; // [rsp+8h] [rbp-C8h] BYREF
  RBX::Network::Peer *v81; // [rsp+18h] [rbp-B8h] BYREF
  __int128 v82; // [rsp+20h] [rbp-B0h] BYREF
  __int128 v83; // [rsp+30h] [rbp-A0h] BYREF
  std::__shared_weak_count *v84[2]; // [rsp+40h] [rbp-90h] BYREF
  __int128 v85; // [rsp+58h] [rbp-78h] BYREF
  _QWORD *v86; // [rsp+68h] [rbp-68h] BYREF
  _QWORD *v87; // [rsp+70h] [rbp-60h] BYREF
  _QWORD *v88; // [rsp+78h] [rbp-58h] BYREF
  _QWORD *v89; // [rsp+80h] [rbp-50h] BYREF
  RBX::EngineContext *v90; // [rsp+88h] [rbp-48h]
  std::__shared_weak_count *v91[2]; // [rsp+90h] [rbp-40h] BYREF
  void *v92; // [rsp+A0h] [rbp-30h]

  v3 = a3; /*0x1067a6122*/
  v90 = a3; /*0x1067a612e*/
  if ( a2 != nullptr ) /*0x1067a6132*/
  {
    v8 = *(_QWORD *)RBX::ServiceProvider::refByClass<RBX::Stats::StatsService>(this: a2); /*0x1067a6140*/
    if ( v8 != 0 ) /*0x1067a6146*/
    {
      std::string::basic_string[abi:ne200100]<0>(a1: v91, a2: "Network", a3: v6, a4: v7); /*0x1067a615a*/
      FirstChildByName = RBX::Instance::findFirstChildByName(a1: v8, a2: v91, a3: 0); /*0x1067a6167*/
      v10 = FirstChildByName + 8; /*0x1067a616c*/
      if ( FirstChildByName == 0 ) /*0x1067a6173*/
        v10 = 0; /*0x1067a6173*/
      RBX::shared_from_polymorphic_downcast<RBX::Stats::Item,RBX::Reflection::DescribedBase>(a1: &v85, a2: v10); /*0x1067a617b*/
      if ( ((__int64)v91[0] & 1) != 0 ) /*0x1067a6184*/
        operator delete(a1: (RBX::Memory *)v92, a2: v11); /*0x1067a618a*/
      v3 = v90; /*0x1067a6196*/
      if ( (_QWORD)v85 != 0 ) /*0x1067a619a*/
        RBX::Instance::setParent(this: (RBX::Instance *)v85, a2: nullptr); /*0x1067a619e*/
      v12 = *((std::__shared_weak_count **)&v85 + 1); /*0x1067a61a3*/
      if ( *((_QWORD *)&v85 + 1) != 0 /*0x1067a61bc*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v85 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v12 + 16LL))(a1: v12); /*0x1067a61c4*/
        std::__shared_weak_count::__release_weak(this: v12); /*0x1067a61ca*/
      }
    }
  }
  v13 = (_OWORD *)((char *)this + 352); /*0x1067a61cf*/
  v14 = *((_QWORD *)this + 44); /*0x1067a61d6*/
  if ( v14 != 0 ) /*0x1067a61e0*/
  {
    v15 = *(std::__shared_weak_count **)(v14 + 432); /*0x1067a61e5*/
    *(_OWORD *)(v14 + 424) = 0; /*0x1067a61ec*/
    if ( v15 != nullptr ) /*0x1067a61f6*/
      std::__shared_weak_count::__release_weak(this: v15); /*0x1067a61f8*/
    v16 = *((_QWORD *)this + 45); /*0x1067a61fd*/
    *(_OWORD *)v91 = *v13; /*0x1067a6205*/
    if ( v16 != 0 ) /*0x1067a620c*/
      _InterlockedIncrement64((volatile signed __int64 *)(v16 + 8)); /*0x1067a620e*/
    RBX::TaskScheduler::remove(a1: v91); /*0x1067a6217*/
    v17 = v91[1]; /*0x1067a621c*/
    if ( v91[1] != nullptr /*0x1067a6235*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v91[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v17 + 16LL))(a1: v17); /*0x1067a623e*/
      std::__shared_weak_count::__release_weak(this: v17); /*0x1067a6244*/
    }
    std::shared_ptr<RBX::Network::PacketReceiveJob>::reset[abi:ne200100](a1: (char *)this + 352); /*0x1067a624c*/
    v3 = v90; /*0x1067a6251*/
  }
  RBX::Instance::removeAllChildren(this); /*0x1067a6258*/
  if ( DFFlag::BlockingRemoveConcurrentRakPeerJobs == 1 ) /*0x1067a6264*/
  {
    v18 = *((RBX::Network::ConcurrentRakPeer **)this + 36); /*0x1067a6266*/
    if ( v18 != nullptr ) /*0x1067a6270*/
      RBX::Network::ConcurrentRakPeer::shutdownJobs(this: v18); /*0x1067a6272*/
  }
  if ( FFlag::ConnectViaConnectionInternal == 1 /*0x1067a62ab*/
    && (v19 = *((_QWORD *)this + 3),
        v20 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>(a1: v18),
        v21 = *(unsigned __int16 *)(v19 + 440),
        v3 = v90,
        v21 - (unsigned int)*(unsigned __int16 *)(v20 + 440) <= *(unsigned __int16 *)(v20 + 442)) )
  {
    v24 = *((_QWORD *)this + 43); /*0x1067a631a*/
    *((_QWORD *)this + 43) = 0; /*0x1067a6321*/
    if ( v24 != 0 ) /*0x1067a632f*/
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v24 + 8LL))(a1: v24); /*0x1067a6334*/
  }
  else
  {
    v22 = *((RBX::Network::ConcurrentRakPeer **)this + 36); /*0x1067a62ad*/
    if ( v22 != nullptr ) /*0x1067a62b7*/
    {
      if ( (unsigned __int8)DFLog::ClientRecvFromRaknet >= 6u && BYTE1(DFLog::ClientRecvFromRaknet) >= 3u ) /*0x1067a62d8*/
      {
        FLog::FastLog( /*0x1067a62f0*/
          a1: DFLog::ClientRecvFromRaknet,
          a2: qword_10D7BB078,
          a3: "[DFLog::ClientRecvFromRaknet] Raknet rawpeer is detaching Peer plugin",
          0);
        v22 = *((RBX::Network::ConcurrentRakPeer **)this + 36); /*0x1067a62f5*/
      }
      v23 = RBX::Network::ConcurrentRakPeer::rawPeer(this: v22); /*0x1067a62f9*/
      (*(void (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v23 + 536LL))(a1: v23, a2: 0); /*0x1067a6306*/
      std::shared_ptr<RBX::Network::ConcurrentRakPeer>::reset[abi:ne200100](a1: (char *)this + 288); /*0x1067a630f*/
      v3 = v90; /*0x1067a6314*/
    }
  }
  result = (RBX::Instance **)RBX::Instance::onServiceProvider(this, a2, a3: v3); /*0x1067a6340*/
  if ( a2 != nullptr ) /*0x1067a6348*/
  {
    std::shared_ptr<RBX::Network::NetworkFilterWhiteList>::reset[abi:ne200100](a1: (char *)this + 392); /*0x1067a6355*/
    std::shared_ptr<RBX::Network::NetworkFilterWhiteList>::reset[abi:ne200100](a1: (char *)this + 408); /*0x1067a6361*/
    v27 = *((_QWORD *)this + 57); /*0x1067a6366*/
    *((_QWORD *)this + 57) = 0; /*0x1067a636d*/
    if ( v27 != 0 ) /*0x1067a637b*/
      std::default_delete<RBX::RemoteAllowList>::operator()[abi:ne200100](a1: (char *)this + 456); /*0x1067a6384*/
    if ( FFlag::NetworkFilterTelemetry == 1 ) /*0x1067a6393*/
    {
      v26 = *((RBX::Network::NetworkFilterGlobalStats **)this + 47); /*0x1067a6395*/
      if ( v26 != nullptr ) /*0x1067a639f*/
      {
        RBX::Network::NetworkFilterGlobalStats::reportFilteringResults(this: v26); /*0x1067a63a8*/
        std::shared_ptr<RBX::Network::NetworkFilterGlobalStats>::reset[abi:ne200100](a1: (char *)this + 376); /*0x1067a63b0*/
      }
    }
    result = (RBX::Instance **)&FFlag::NetAssetSubsystem; /*0x1067a63b5*/
    if ( FFlag::NetAssetSubsystem == 1 ) /*0x1067a63bf*/
    {
      NetAssetManager_subsystem = (RBX::Network::NetAssetManager *)RBX::Network::NetAssetHelpers::getNetAssetManager_subsystem(this: v26); /*0x1067a63c1*/
      result = (RBX::Instance **)RBX::Network::NetAssetManager::revertRemapId( /*0x1067a63d0*/
                                   this: NetAssetManager_subsystem,
                                   a2: *((unsigned __int16 *)this + 224));
    }
  }
  if ( v3 != nullptr ) /*0x1067a63d8*/
  {
    if ( DFFlag::LargeReplicatorValidate == 1 /*0x1067a63ef*/
      && RBX::Network::NetAssetHelpers::getNetAssetManager_deprecated(this: v26) == 0 )
    {
      RBXCRASH(a1: "Unable to find NetAssetManager but should be loaded", a2: ""); /*0x1067a6a68*/
    }
    if ( FFlag::NetAssetSubsystem == 1 ) /*0x1067a63ff*/
    {
      v29 = (RBX::Network::NetAssetManager *)RBX::Network::NetAssetHelpers::getNetAssetManager_subsystem(this: v26); /*0x1067a6401*/
      *((_DWORD *)this + 112) = (unsigned __int16)RBX::Network::NetAssetManager::reserveRemapId(this: v29); /*0x1067a6411*/
    }
    if ( FFlag::ConnectViaConnectionInternal == 1 /*0x1067a6440*/
      && (v30 = *((_QWORD *)this + 3),
          v31 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>(a1: v26),
          *(unsigned __int16 *)(v30 + 440) - (unsigned int)*(unsigned __int16 *)(v31 + 440) <= *(unsigned __int16 *)(v31 + 442)) )
    {
      RBX::NetworkBase::IFactory::createConnectionFactory(a1: v91, a2: 0, a3: (char *)this + 176); /*0x1067a685b*/
      v65 = v91[0]; /*0x1067a6860*/
      v91[0] = nullptr; /*0x1067a6864*/
      v66 = *((_QWORD *)this + 43); /*0x1067a686c*/
      *((_QWORD *)this + 43) = v65; /*0x1067a6873*/
      if ( v66 != 0 ) /*0x1067a687d*/
      {
        (*(void (__fastcall **)(__int64))(*(_QWORD *)v66 + 8LL))(a1: v66); /*0x1067a6882*/
        v67 = v91[0]; /*0x1067a6885*/
        v91[0] = nullptr; /*0x1067a6889*/
        if ( v67 != nullptr ) /*0x1067a6894*/
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v67 + 8LL))(a1: v67); /*0x1067a6899*/
      }
      v68 = operator new(a1: (RBX::Memory *)0x48, a2: v64); /*0x1067a68a6*/
      (*(void (__fastcall **)(__int128 *))(**((_QWORD **)this + 43) + 24LL))(a1: &v83); /*0x1067a68ba*/
      RBX::Network::ConcurrentRakPeer::ConcurrentRakPeer(a1: v68, a2: &v83, a3: (__int64)v3 - 464); /*0x1067a68ce*/
      std::shared_ptr<RBX::Network::ConcurrentRakPeer>::reset[abi:ne200100]<RBX::Network::ConcurrentRakPeer,0>( /*0x1067a68dd*/
        a1: (char *)this + 288,
        a2: v68);
      v69 = *((std::__shared_weak_count **)&v83 + 1); /*0x1067a68e2*/
      if ( *((_QWORD *)&v83 + 1) != 0 /*0x1067a6903*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v83 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v69 + 16LL))(a1: v69); /*0x1067a6910*/
        std::__shared_weak_count::__release_weak(this: v69); /*0x1067a6916*/
      }
    }
    else
    {
      v32 = (RBX::Network::ConcurrentRakPeer *)operator new(a1: (RBX::Memory *)0x48, a2: v27); /*0x1067a6450*/
      v34 = (RakNet::RakPeer *)operator new(a1: (RBX::Memory *)0xEA0, a2: v33); /*0x1067a645d*/
      RakNet::RakPeer::RakPeer(this: v34); /*0x1067a6463*/
      RBX::Network::ConcurrentRakPeer::ConcurrentRakPeer( /*0x1067a6479*/
        this: v32,
        a2: v34,
        a3: (RBX::EngineContext *)((char *)v90 - 464));
      std::shared_ptr<RBX::Network::ConcurrentRakPeer>::reset[abi:ne200100]<RBX::Network::ConcurrentRakPeer,0>( /*0x1067a6488*/
        a1: (char *)this + 288,
        a2: v32);
      v35 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)this + 36)); /*0x1067a6494*/
      (*(void (__fastcall **)(__int64, char *))(*(_QWORD *)v35 + 536LL))(a1: v35, a2: (char *)this + 176); /*0x1067a64a6*/
      v3 = v90; /*0x1067a64ac*/
    }
    if ( (unsigned __int8)DFLog::ClientRecvFromRaknet >= 6u && BYTE1(DFLog::ClientRecvFromRaknet) >= 3u ) /*0x1067a64c9*/
      FLog::FastLog( /*0x1067a64dd*/
        a1: DFLog::ClientRecvFromRaknet,
        a2: qword_10D7BB078,
        a3: "[DFLog::ClientRecvFromRaknet] Raknet rawpeer is attaching Peer plugin",
        0);
    (*(void (__fastcall **)(RBX::Network::Peer *))(*(_QWORD *)this + 624LL))(a1: this); /*0x1067a64e8*/
    v37 = (RBX::DataModelJob *)operator new(a1: (RBX::Memory *)0x1D0, a2: v36); /*0x1067a64f8*/
    v38 = *((_QWORD *)this + 37); /*0x1067a64fb*/
    *(_OWORD *)v84 = *((_OWORD *)this + 18); /*0x1067a6509*/
    if ( v38 != 0 ) /*0x1067a6513*/
      _InterlockedIncrement64((volatile signed __int64 *)(v38 + 8)); /*0x1067a6515*/
    RBX::shared_from<RBX::Network::Peer>(a1: &v82, a2: (__int64)this); /*0x1067a6524*/
    RBX::Network::PacketReceiveJob::PacketReceiveJob( /*0x1067a6544*/
      this: v37,
      a2: (__int64)v84,
      a3: (__int64)&v82,
      a4: (__int64)v3 - 464);
    std::shared_ptr<RBX::Network::PacketReceiveJob>::shared_ptr[abi:ne200100]<RBX::Network::PacketReceiveJob,0>( /*0x1067a6553*/
      a1: v91,
      a2: v37);
    std::shared_ptr<RBX::Network::PacketReceiveJob>::operator=[abi:ne200100](a1: (char *)this + 352, a2: v91); /*0x1067a6562*/
    v39 = v91[1]; /*0x1067a6567*/
    if ( v91[1] != nullptr /*0x1067a6582*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v91[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v39 + 16LL))(a1: v39); /*0x1067a658b*/
      std::__shared_weak_count::__release_weak(this: v39); /*0x1067a6591*/
    }
    v40 = *((std::__shared_weak_count **)&v82 + 1); /*0x1067a6596*/
    if ( *((_QWORD *)&v82 + 1) != 0 /*0x1067a65b3*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v82 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v40 + 16LL))(a1: v40); /*0x1067a65bc*/
      std::__shared_weak_count::__release_weak(this: v40); /*0x1067a65c2*/
    }
    v41 = v84[1]; /*0x1067a65c7*/
    if ( v84[1] != nullptr /*0x1067a65e4*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v84[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v41 + 16LL))(a1: v41); /*0x1067a65ed*/
      std::__shared_weak_count::__release_weak(this: v41); /*0x1067a65f3*/
    }
    v42 = *((_QWORD *)this + 45); /*0x1067a65f8*/
    *(_OWORD *)v91 = *v13; /*0x1067a6600*/
    if ( v42 != 0 ) /*0x1067a6607*/
      _InterlockedIncrement64((volatile signed __int64 *)(v42 + 8)); /*0x1067a6609*/
    RBX::TaskScheduler::add(a1: v91); /*0x1067a6612*/
    v44 = v91[1]; /*0x1067a6617*/
    if ( v91[1] != nullptr /*0x1067a6630*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v91[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v44 + 16LL))(a1: v44); /*0x1067a6638*/
      std::__shared_weak_count::__release_weak(this: v44); /*0x1067a663e*/
    }
    if ( FFlag::NetworkFilterTelemetry == 1 ) /*0x1067a664d*/
    {
      _ZNSt3__115allocate_sharedB8ne200100IN3RBX7Network24NetworkFilterGlobalStatsENS_9allocatorIS3_EEJELi0EEENS_10shared_ptrIT_EERKT0_DpOT1_( /*0x1067a665a*/
        a1: v91,
        a2: &v85);
      std::shared_ptr<RBX::Network::NetworkFilterGlobalStats>::operator=[abi:ne200100](a1: (char *)this + 376, a2: v91); /*0x1067a6669*/
      v45 = v91[1]; /*0x1067a666e*/
      if ( v91[1] != nullptr /*0x1067a6687*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v91[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v45 + 16LL))(a1: v45); /*0x1067a668f*/
        std::__shared_weak_count::__release_weak(this: v45); /*0x1067a6695*/
      }
    }
    RBX::Network::NetworkFilterWhiteList::makePropertyWhitelist( /*0x1067a66a1*/
      this: (RBX::Network::NetworkFilterWhiteList *)v91,
      a2: v43);
    std::shared_ptr<RBX::Network::NetworkFilterWhiteList>::operator=[abi:ne200100](a1: (char *)this + 392, a2: v91); /*0x1067a66b0*/
    v47 = v91[1]; /*0x1067a66b5*/
    if ( v91[1] != nullptr /*0x1067a66ce*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v91[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v47 + 16LL))(a1: v47); /*0x1067a66d6*/
      std::__shared_weak_count::__release_weak(this: v47); /*0x1067a66dc*/
    }
    RBX::Network::NetworkFilterWhiteList::makeEventWhitelist(this: (RBX::Network::NetworkFilterWhiteList *)v91, a2: v46); /*0x1067a66e8*/
    std::shared_ptr<RBX::Network::NetworkFilterWhiteList>::operator=[abi:ne200100](a1: (char *)this + 408, a2: v91); /*0x1067a66f7*/
    v49 = v91[1]; /*0x1067a66fc*/
    if ( v91[1] != nullptr /*0x1067a6715*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v91[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v49 + 16LL))(a1: v49); /*0x1067a671d*/
      std::__shared_weak_count::__release_weak(this: v49); /*0x1067a6723*/
    }
    v50 = (RBX::DataModel *)RBX::DataModel::get(this: v3, a2: v48); /*0x1067a672b*/
    RBX::RemoteAllowList::create(this: (RBX::RemoteAllowList *)v91, a2: v50); /*0x1067a673a*/
    v51 = v91[0]; /*0x1067a673f*/
    v91[0] = nullptr; /*0x1067a6742*/
    v52 = *((RBX::Instance **)this + 57); /*0x1067a6749*/
    *((_QWORD *)this + 57) = v51; /*0x1067a6750*/
    if ( v52 != nullptr ) /*0x1067a675a*/
    {
      std::default_delete<RBX::RemoteAllowList>::operator()[abi:ne200100](a1: (char *)this + 456); /*0x1067a6763*/
      v52 = v91[0]; /*0x1067a6768*/
      v91[0] = nullptr; /*0x1067a676c*/
      if ( v52 != nullptr ) /*0x1067a6777*/
        std::default_delete<RBX::RemoteAllowList>::operator()[abi:ne200100](a1: v91); /*0x1067a677d*/
    }
    v53 = (RBX::Network::NetAssetHelpers *)RBX::DataModel::get(this: v3, a2: v52); /*0x1067a6785*/
    if ( v53 == nullptr ) /*0x1067a678d*/
      goto LABEL_99; /*0x1067a678d*/
    NetAssetManager = RBX::Network::NetAssetHelpers::getNetAssetManager(this: v53, a2: v54); /*0x1067a6796*/
    if ( NetAssetManager == 0 ) /*0x1067a679e*/
      goto LABEL_99; /*0x1067a679e*/
    v57 = (RBX::Network::NetAssetManager *)NetAssetManager; /*0x1067a67a4*/
    v58 = FFlag::NetAssetSubsystem; /*0x1067a67ae*/
    if ( FFlag::NetAssetSubsystem == 1 ) /*0x1067a67b2*/
    {
      if ( (unsigned __int8)RBX::Network::NetAssetManager::getInitialized(this: v57) == 0 ) /*0x1067a67be*/
      {
        v70 = (_QWORD *)operator new(a1: (RBX::Memory *)8, a2: v56); /*0x1067a692a*/
        *v70 = off_10CA00468; /*0x1067a6938*/
        v89 = v70; /*0x1067a693b*/
        v72 = (_QWORD *)operator new(a1: (RBX::Memory *)8, a2: v71); /*0x1067a6944*/
        *v72 = off_10CA00418; /*0x1067a6954*/
        v86 = v72; /*0x1067a695b*/
        RBX::Network::NetAssetManager::initialize(a1: (__int64)v57, a2: (__int64 *)&v89, a3: (__int64 *)&v86); /*0x1067a6965*/
        v73 = (__int64)v86; /*0x1067a696a*/
        v86 = nullptr; /*0x1067a696e*/
        if ( v73 != 0 ) /*0x1067a6979*/
          (*(void (__fastcall **)(__int64))(*(_QWORD *)v73 + 8LL))(a1: v73); /*0x1067a697e*/
        v63 = (__int64)v89; /*0x1067a6981*/
        v89 = nullptr; /*0x1067a6985*/
        goto LABEL_97; /*0x1067a6985*/
      }
      v58 = FFlag::NetAssetSubsystem; /*0x1067a67cb*/
    }
    if ( (v58 & 1) != 0 ) /*0x1067a67cf*/
    {
LABEL_99:
      result = (RBX::Instance **)RBX::ServiceProvider::refByClass<RBX::Stats::StatsService>(this: v3); /*0x1067a6998*/
      v75 = *result; /*0x1067a69a0*/
      if ( *result != nullptr ) /*0x1067a69a6*/
      {
        v81 = this; /*0x1067a69b3*/
        v91[0] = (std::__shared_weak_count *)RBX::EngineContext::getThreadLocal(this: v74); /*0x1067a69bf*/
        LODWORD(v91[1]) = 11672; /*0x1067a69c2*/
        RBX::Creatable::createImpl<RBX::Network::PeerStatsItem,RBX::ForceConstructionInCreatable &,RBX::Network::Peer *>( /*0x1067a69d6*/
          a1: &v80,
          a2: v91,
          a3: &v81);
        v76 = v80; /*0x1067a69de*/
        v85 = v80; /*0x1067a69e2*/
        std::string::basic_string[abi:ne200100]<0>(a1: v91, a2: "Network", a3: v77, a4: v78); /*0x1067a69f5*/
        RBX::Instance::setName(a1: v76, a2: v91); /*0x1067a6a01*/
        if ( ((__int64)v91[0] & 1) != 0 ) /*0x1067a6a0a*/
          operator delete(a1: (RBX::Memory *)v92, a2: v79); /*0x1067a6a10*/
        result = (RBX::Instance **)RBX::Instance::setParent(this: (RBX::Instance *)v76, a2: v75); /*0x1067a6a1b*/
        if ( *((_QWORD *)&v76 + 1) != 0 ) /*0x1067a6a23*/
        {
          result = (RBX::Instance **)_InterlockedExchangeAdd64( /*0x1067a6a2c*/
                                       (volatile signed __int64 *)(*((_QWORD *)&v76 + 1) + 8LL),
                                       0xFFFFFFFFFFFFFFFFLL);
          if ( result == nullptr ) /*0x1067a6a35*/
          {
            (*(void (__fastcall **)(_QWORD))(**((_QWORD **)&v76 + 1) + 16LL))(a1: *((_QWORD *)&v76 + 1)); /*0x1067a6a3d*/
            return (RBX::Instance **)std::__shared_weak_count::__release_weak(this: *((std::__shared_weak_count **)&v76 /*0x1067a6a43*/
                                                                                    + 1));
          }
        }
      }
      return result; /*0x1067a6a43*/
    }
    v59 = (_QWORD *)operator new(a1: (RBX::Memory *)8, a2: v56); /*0x1067a67da*/
    *v59 = off_10CA00468; /*0x1067a67ea*/
    v87 = v59; /*0x1067a67f1*/
    RBX::Network::NetAssetManager::setCallbacks(a1: (__int64)v57, a2: (__int64 *)&v87); /*0x1067a67f7*/
    v61 = (__int64)v87; /*0x1067a67fc*/
    v87 = nullptr; /*0x1067a6800*/
    if ( v61 != 0 ) /*0x1067a680b*/
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v61 + 8LL))(a1: v61); /*0x1067a6810*/
    v62 = (_QWORD *)operator new(a1: (RBX::Memory *)8, a2: v60); /*0x1067a6818*/
    *v62 = off_10CA00418; /*0x1067a6828*/
    v88 = v62; /*0x1067a682f*/
    RBX::Network::NetAssetManager::setCompressor(a1: (__int64)v57, a2: (__int64 *)&v88); /*0x1067a6835*/
    v63 = (__int64)v88; /*0x1067a683a*/
    v88 = nullptr; /*0x1067a683e*/
LABEL_97:
    if ( v63 != 0 ) /*0x1067a6990*/
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v63 + 8LL))(a1: v63); /*0x1067a6995*/
    goto LABEL_99; /*0x1067a6995*/
  }
  return result; /*0x1067a6a48*/
}

// Address: 0x1067a6da8 | Name: __ZN3RBX7Network4Peer14disableTimeoutEv
__int64 __fastcall RBX::Network::Peer::disableTimeout(RBX::Network::ConcurrentRakPeer **this)
{
  _QWORD *v1; // rax
  __int64 v2; // rdx
  __int64 v3; // r8
  __int64 v4; // r9

  v1 = (_QWORD *)RBX::Network::ConcurrentRakPeer::rawPeer(this: *(this + 36)); /*0x1067a6db7*/
  return (*(__int64 (__fastcall **)(_QWORD *, __int64, __int64, _QWORD, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD))(*v1 + 448LL))( /*0x1067a6df4*/
           a1: v1,
           a2: 0x7FFFFFFF,
           a3: v2,
           a4: *v1,
           a5: v3,
           a6: v4,
           a7: RakNet::UNASSIGNED_SYSTEM_ADDRESS,
           a8: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 1),
           a9: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 2),
           a10: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 3),
           a11: RakNet::UNASSIGNED_SYSTEM_ADDRESS,
           a12: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 1),
           a13: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 2),
           a14: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 3));
}

// Address: 0x1067a6dfa | Name: __ZN3RBX7Network4Peer27sendExtAntiCheatAckHelperV2EPNS_11NetworkBase18ConnectionInternalEj
__int64 __fastcall RBX::Network::Peer::sendExtAntiCheatAckHelperV2(
        RBX::Network::Peer *this,
        RBX::NetworkBase::ConnectionInternal *a2,
        int a3)
{
  unsigned int v5; // ebx
  std::__shared_weak_count *v6; // r14
  std::__shared_weak_count *v7; // r14
  __int128 v9; // [rsp+0h] [rbp-50h] BYREF
  std::__shared_weak_count *v10[2]; // [rsp+10h] [rbp-40h] BYREF
  _DWORD v11[9]; // [rsp+2Ch] [rbp-24h] BYREF

  _ZNSt3__115allocate_sharedB8ne200100IN3RBX7Network13NetworkStreamENS_9allocatorIS3_EEJELi0EEENS_10shared_ptrIT_EERKT0_DpOT1_( /*0x1067a6e1d*/
    a1: v10,
    a2: v11);
  LOBYTE(v11[0]) = -100; /*0x1067a6e25*/
  RBX::Network::NetworkStream::writeBytes(this: v10[0], a2: v11, a3: 1u); /*0x1067a6e33*/
  LOBYTE(v11[0]) = 1; /*0x1067a6e40*/
  RBX::Network::NetworkStream::writeBytes(this: v10[0], a2: v11, a3: 1u); /*0x1067a6e48*/
  v11[0] = a3; /*0x1067a6e55*/
  RBX::Network::NetworkStream::writeBytes(this: v10[0], a2: v11, a3: 4u); /*0x1067a6e5d*/
  v9 = *(_OWORD *)v10; /*0x1067a6e6a*/
  *(_OWORD *)v10 = 0; /*0x1067a6e70*/
  v5 = (*(__int64 (__fastcall **)(RBX::NetworkBase::ConnectionInternal *, __int64, __int128 *, _QWORD, _QWORD))(*(_QWORD *)a2 + 48LL))( /*0x1067a6e87*/
         a1: a2,
         a2: 8,
         a3: &v9,
         a4: 0,
         a5: 0);
  v6 = *((std::__shared_weak_count **)&v9 + 1); /*0x1067a6e89*/
  if ( *((_QWORD *)&v9 + 1) != 0 /*0x1067a6ea2*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v9 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(a1: v6); /*0x1067a6eaa*/
    std::__shared_weak_count::__release_weak(this: v6); /*0x1067a6eb0*/
  }
  v7 = v10[1]; /*0x1067a6eb5*/
  if ( v10[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v10[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1067a6ece*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(a1: v7); /*0x1067a6ed6*/
    std::__shared_weak_count::__release_weak(this: v7); /*0x1067a6edc*/
  }
  return v5; /*0x1067a6ee3*/
}

// Address: 0x1067a6f12 | Name: __ZN3RBX7Network4Peer25sendExtAntiCheatAckHelperEN6RakNet13SystemAddressEj
__int64 __fastcall RBX::Network::Peer::sendExtAntiCheatAckHelper(
        __int64 a1,
        int a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        char a7)
{
  __int64 v9; // rbx
  void *v10; // rsi
  _BYTE v12[64]; // [rsp+18h] [rbp-88h] BYREF
  _DWORD v13[18]; // [rsp+58h] [rbp-48h] BYREF

  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)v12); /*0x1067a6f32*/
  LOBYTE(v13[0]) = -100; /*0x1067a6f3b*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v12, a2: v13, a3: 1u); /*0x1067a6f46*/
  LOBYTE(v13[0]) = 1; /*0x1067a6f4f*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v12, a2: v13, a3: 1u); /*0x1067a6f5e*/
  v13[0] = a2; /*0x1067a6f67*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v12, a2: v13, a3: 4u); /*0x1067a6f76*/
  v9 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *(RBX::Network::ConcurrentRakPeer **)(a1 + 288)); /*0x1067a6f87*/
  RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v13, a2: (const RakNet::SystemAddress *)&a7); /*0x1067a6f92*/
  LODWORD(v9) = (*(__int64 (__fastcall **)(__int64, _BYTE *, _QWORD, __int64, __int64, _DWORD *, _DWORD, _DWORD, _QWORD))(*(_QWORD *)v9 + 184LL))( /*0x1067a6fd0*/
                  a1: v9,
                  a2: v12,
                  a3: 0,
                  a4: 3,
                  a5: 1,
                  a6: v13,
                  a7: 0,
                  a8: 0,
                  a9: 0);
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v12, a2: v10); /*0x1067a6fd9*/
  return (unsigned int)v9; /*0x1067a6fe0*/
}

// Address: 0x1067a7006 | Name: __ZNK3RBX7Network4Peer24recvExtAntiCheatHelperV2ERNS0_14IncomingPacketERNS0_19ExtAntiCheatSubtypeERjRNSt3__16vectorIhNS7_9allocatorIhEEEE
void __fastcall RBX::Network::Peer::recvExtAntiCheatHelperV2(
        __int64 a1,
        RBX::Network::IncomingPacket *a2,
        _BYTE *a3,
        _DWORD *a4,
        char **a5)
{
  unsigned __int8 *v9; // r13
  unsigned int v10; // eax
  void *v11; // rsi
  __int16 Int16; // r14
  char *v13; // rsi
  unsigned __int64 v14; // rdx
  _BYTE v15[104]; // [rsp+8h] [rbp-68h] BYREF

  v9 = (unsigned __int8 *)RBX::Network::IncomingPacket::data(this: a2); /*0x1067a702b*/
  v10 = RBX::Network::IncomingPacket::size(this: a2); /*0x1067a7031*/
  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)v15, a2: v9, a3: v10, a4: 0); /*0x1067a7044*/
  RBX::Network::NetworkStream::IgnoreBytes(this: (RBX::Network::NetworkStream *)v15, a2: 1); /*0x1067a7051*/
  RBX::Network::NetworkStream::readBytes(this: (RBX::Network::NetworkStream *)v15, a2: a3, a3: 1u); /*0x1067a7062*/
  if ( *a3 < 3u ) /*0x1067a706b*/
  {
    *a4 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v15); /*0x1067a7089*/
    if ( *a3 == 0 ) /*0x1067a7090*/
    {
      Int16 = RBX::Network::NetworkStream::readInt16(this: (RBX::Network::NetworkStream *)v15); /*0x1067a709b*/
      v13 = *a5; /*0x1067a70a2*/
      v14 = a5[1] - *a5; /*0x1067a70a9*/
      if ( Int16 <= v14 ) /*0x1067a70b2*/
      {
        if ( Int16 < v14 ) /*0x1067a70c4*/
          a5[1] = &v13[Int16]; /*0x1067a70c9*/
      }
      else
      {
        std::vector<unsigned char>::__append(a1: a5); /*0x1067a70ba*/
        v13 = *a5; /*0x1067a70bf*/
      }
      RBX::Network::NetworkStream::readBytes(this: (RBX::Network::NetworkStream *)v15, a2: v13, a3: Int16); /*0x1067a70d5*/
    }
  }
  else
  {
    *a3 = 2; /*0x1067a706d*/
    if ( a5[1] != *a5 ) /*0x1067a7078*/
      a5[1] = *a5; /*0x1067a707a*/
  }
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v15, a2: v11); /*0x1067a70de*/
}

// Address: 0x1067a7108 | Name: __ZN3RBX7Network4Peer22sendExtAntiCheatHelperERKNSt3__16vectorIhNS2_9allocatorIhEEEEN6RakNet13SystemAddressEj
__int64 __fastcall RBX::Network::Peer::sendExtAntiCheatHelper(
        __int64 a1,
        __int64 a2,
        int a3,
        _DWORD a4,
        _DWORD a5,
        _DWORD a6,
        char a7)
{
  __int64 v10; // rbx
  void *v11; // rsi
  _BYTE v13[64]; // [rsp+20h] [rbp-90h] BYREF
  _DWORD v14[20]; // [rsp+60h] [rbp-50h] BYREF

  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)v13); /*0x1067a712d*/
  LOBYTE(v14[0]) = -100; /*0x1067a7136*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v13, a2: v14, a3: 1u); /*0x1067a7141*/
  LOBYTE(v14[0]) = 0; /*0x1067a714a*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v13, a2: v14, a3: 1u); /*0x1067a7159*/
  v14[0] = a3; /*0x1067a7162*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v13, a2: v14, a3: 4u); /*0x1067a7171*/
  LOWORD(v14[0]) = *(_WORD *)(a2 + 8) - *(_WORD *)a2; /*0x1067a7181*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v13, a2: v14, a3: 2u); /*0x1067a7190*/
  RBX::Network::NetworkStream::writeBytes( /*0x1067a71a5*/
    this: (RBX::Network::NetworkStream *)v13,
    a2: *(const void **)a2,
    a3: *(_DWORD *)(a2 + 8) - *(_QWORD *)a2);
  v10 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *(RBX::Network::ConcurrentRakPeer **)(a1 + 288)); /*0x1067a71b6*/
  RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v14, a2: (const RakNet::SystemAddress *)&a7); /*0x1067a71c1*/
  LODWORD(v10) = (*(__int64 (__fastcall **)(__int64, _BYTE *, _QWORD, __int64, __int64, _DWORD *, _DWORD, _DWORD, _QWORD))(*(_QWORD *)v10 + 184LL))( /*0x1067a71ff*/
                   a1: v10,
                   a2: v13,
                   a3: 0,
                   a4: 3,
                   a5: 1,
                   a6: v14,
                   a7: 0,
                   a8: 0,
                   a9: 0);
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v13, a2: v11); /*0x1067a7208*/
  return (unsigned int)v10; /*0x1067a720f*/
}

// Address: 0x1067a7236 | Name: __ZN3RBX7Network4Peer33recvExtAntiCheatHelper_deprecatedEPN6RakNet6PacketERNS0_19ExtAntiCheatSubtypeERjRNSt3__16vectorIhNS8_9allocatorIhEEEE
void __fastcall RBX::Network::Peer::recvExtAntiCheatHelper_deprecated(
        __int64 a1,
        __int64 a2,
        _BYTE *a3,
        _DWORD *a4,
        char **a5)
{
  void *v8; // rsi
  __int16 Int16; // r14
  char *v10; // rsi
  unsigned __int64 v11; // rdx
  _BYTE v12[96]; // [rsp+0h] [rbp-60h] BYREF

  RBX::Network::NetworkStream::NetworkStream( /*0x1067a7261*/
    this: (RBX::Network::NetworkStream *)v12,
    a2: *(unsigned __int8 **)(a2 + 56),
    a3: *(_DWORD *)(a2 + 48),
    a4: 0);
  RBX::Network::NetworkStream::IgnoreBytes(this: (RBX::Network::NetworkStream *)v12, a2: 1); /*0x1067a726e*/
  RBX::Network::NetworkStream::readBytes(this: (RBX::Network::NetworkStream *)v12, a2: a3, a3: 1u); /*0x1067a727f*/
  if ( *a3 < 3u ) /*0x1067a7288*/
  {
    *a4 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v12); /*0x1067a72a6*/
    if ( *a3 == 0 ) /*0x1067a72ad*/
    {
      Int16 = RBX::Network::NetworkStream::readInt16(this: (RBX::Network::NetworkStream *)v12); /*0x1067a72b8*/
      v10 = *a5; /*0x1067a72bf*/
      v11 = a5[1] - *a5; /*0x1067a72c6*/
      if ( Int16 <= v11 ) /*0x1067a72cf*/
      {
        if ( Int16 < v11 ) /*0x1067a72e1*/
          a5[1] = &v10[Int16]; /*0x1067a72e6*/
      }
      else
      {
        std::vector<unsigned char>::__append(a1: a5); /*0x1067a72d7*/
        v10 = *a5; /*0x1067a72dc*/
      }
      RBX::Network::NetworkStream::readBytes(this: (RBX::Network::NetworkStream *)v12, a2: v10, a3: Int16); /*0x1067a72f2*/
    }
  }
  else
  {
    *a3 = 2; /*0x1067a728a*/
    if ( a5[1] != *a5 ) /*0x1067a7295*/
      a5[1] = *a5; /*0x1067a7297*/
  }
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v12, a2: v8); /*0x1067a72fb*/
}

// Address: 0x1067a7324 | Name: __ZN3RBX7Network4Peer22setPacketErrorDelegateEONSt3__110unique_ptrINS1_19PacketErrorDelegateENS2_14default_deleteIS4_EEEE
__int64 __fastcall RBX::Network::Peer::setPacketErrorDelegate(__int64 a1, __int64 *a2)
{
  __int64 result; // rax
  __int64 v3; // rcx
  __int64 v4; // rdi

  result = a1; /*0x1067a7328*/
  v3 = *a2; /*0x1067a732b*/
  *a2 = 0; /*0x1067a732e*/
  v4 = *(_QWORD *)(a1 + 424); /*0x1067a7335*/
  *(_QWORD *)(result + 424) = v3; /*0x1067a733c*/
  if ( v4 != 0 ) /*0x1067a7346*/
    return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v4 + 8LL))(a1: v4); /*0x1067a734c*/
  return result; /*0x1067a734f*/
}

// Address: 0x1067a7352 | Name: __ZN3RBX7Network4Peer17notifyPacketErrorENS_10StringViewE
__int64 __fastcall RBX::Network::Peer::notifyPacketError(__int64 a1)
{
  __int64 v1; // rdi
  __int64 result; // rax

  v1 = *(_QWORD *)(a1 + 424); /*0x1067a7356*/
  if ( v1 != 0 ) /*0x1067a7360*/
    return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v1 + 16LL))(a1: v1); /*0x1067a736a*/
  return result; /*0x1067a736c*/
}

// Address: 0x1067a736e | Name: __ZN3RBX7Network4Peer24setSendErrorDelegateTestEONSt3__110unique_ptrINS1_17SendErrorDelegateENS2_14default_deleteIS4_EEEE
__int64 __fastcall RBX::Network::Peer::setSendErrorDelegateTest(__int64 a1, __int64 *a2)
{
  __int64 result; // rax
  __int64 v3; // rcx
  __int64 v4; // rdi

  result = a1; /*0x1067a7372*/
  v3 = *a2; /*0x1067a7375*/
  *a2 = 0; /*0x1067a7378*/
  v4 = *(_QWORD *)(a1 + 432); /*0x1067a737f*/
  *(_QWORD *)(result + 432) = v3; /*0x1067a7386*/
  if ( v4 != 0 ) /*0x1067a7390*/
    return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v4 + 8LL))(a1: v4); /*0x1067a7396*/
  return result; /*0x1067a7399*/
}

// Address: 0x1067a739c | Name: __ZN3RBX7Network4Peer15notifySendErrorENS_10StringViewE
__int64 __fastcall RBX::Network::Peer::notifySendError(__int64 a1)
{
  __int64 v1; // rdi
  __int64 result; // rax

  v1 = *(_QWORD *)(a1 + 432); /*0x1067a73a0*/
  if ( v1 != 0 ) /*0x1067a73aa*/
    return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v1 + 16LL))(a1: v1); /*0x1067a73b4*/
  return result; /*0x1067a73b6*/
}

// Address: 0x1067a73b8 | Name: __ZN3RBX7Network4Peer22initRemoteAllowListLuaENSt3__110shared_ptrIKNS2_6vectorINS_10Reflection7VariantENS2_9allocatorIS6_EEEEEE
__int64 __fastcall RBX::Network::Peer::initRemoteAllowListLua(
        __int64 a1,
        const char *a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        __m128 a7,
        __m128 a8,
        __m128 a9,
        __m128 a10,
        __m128 a11,
        __m128 a12,
        __m128 a13,
        __m128 a14)
{
  __int64 result; // rax
  __int64 **v15; // rcx
  __int64 *v16; // r14
  __int64 *v17; // r15
  __int64 v19; // r12
  _QWORD *v20; // rsi
  char *v21; // rdi
  char v22; // [rsp+0h] [rbp-20h]

  result = *(_QWORD *)(a1 + 456); /*0x1067a73c3*/
  if ( result == 0 ) /*0x1067a73cd*/
    return result; /*0x1067a73cd*/
  if ( *(_BYTE *)(result + 40) == 1 ) /*0x1067a73d3*/
  {
    v21 = "The remote allow list can only be initialized once"; /*0x1067a743f*/
LABEL_13:
    RBX::throw_runtime_error(this: (RBX *)v21, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15: v22); /*0x1067a7438*/
  }
  v15 = *(__int64 ***)a2; /*0x1067a73d5*/
  if ( *(_QWORD *)a2 == 0 ) /*0x1067a73db*/
    return result; /*0x1067a73db*/
  v16 = *v15; /*0x1067a73dd*/
  v17 = v15[1]; /*0x1067a73e0*/
  if ( *v15 != v17 ) /*0x1067a73e7*/
  {
    do /*0x1067a741b*/
    {
      v19 = *v16; /*0x1067a73ec*/
      if ( RBX::Reflection::Type::getSingleton<std::string>(a1, a2, a3, a4: v15) != v19 ) /*0x1067a73f7*/
      {
        v21 = "Variant cast failed"; /*0x1067a7431*/
        goto LABEL_13; /*0x1067a7431*/
      }
      v20 = v16 + 2; /*0x1067a73fd*/
      if ( v16[1] == 0 ) /*0x1067a7404*/
        v20 = nullptr; /*0x1067a7404*/
      RBX::RemoteAllowList::allow(a1: *(_QWORD *)(a1 + 456), a2: v20); /*0x1067a740f*/
      v16 += 10; /*0x1067a7414*/
    }
    while ( v16 != v17 ); /*0x1067a741b*/
    result = *(_QWORD *)(a1 + 456); /*0x1067a741d*/
  }
  *(_BYTE *)(result + 40) = 1; /*0x1067a7424*/
  return result; /*0x1067a7428*/
}

// Address: 0x1067a7448 | Name: __ZNK3RBX7Network4Peer11isLocalTestEv
char __fastcall RBX::Network::Peer::isLocalTest(RBX::Network::Peer *this)
{
  if ( (unsigned __int8)RBX::RunService::productIsStudio(this) != 0 /*0x1067a7468*/
    && (*(unsigned __int8 (__fastcall **)(RBX::Network::Peer *))(*(_QWORD *)this + 640LL))(a1: this) == 0 )
  {
    return (*(__int64 (__fastcall **)(RBX::Network::Peer *))(*(_QWORD *)this + 632LL))(a1: this) ^ 1; /*0x1067a747a*/
  }
  else
  {
    return 0; /*0x1067a746a*/
  }
}

// Address: 0x106d71494 | Name: __ZNK3RBX7Network4Peer13getAsInternalENS_10Reflection11InterfaceIdE
__int64 RBX::Network::Peer::getAsInternal()
{
  return 0; /*0x106d7149a*/
}

// Address: 0x106d7149c | Name: __ZN3RBX7Network4Peer35writeAllPropertiesForChangeTrackingEPNS_23DataModelChangeTracking13ChangeTrackerENS2_12DeltaTypeTagE
__int64 __fastcall RBX::Network::Peer::writeAllPropertiesForChangeTracking(__int64 a1)
{
  return RBX::Instance::writeAllPropertiesForChangeTracking(a1); /*0x106d714a0*/
}

// Address: 0x108764a56 | Name: __ZN3RBX7Network4PeerC2ERNS_28ForceConstructionInCreatableE.cold.1
__int64 __fastcall RBX::Network::Peer::Peer(__int64 *a1, __int64 a2, __int64 a3, __int64 a4)
{
  __int64 v8; // rdi

  v8 = *a1; /*0x108764a6c*/
  *a1 = 0; /*0x108764a6f*/
  if ( v8 != 0 ) /*0x108764a76*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v8 + 8LL))(a1: v8); /*0x108764a7b*/
  std::shared_ptr<RBX::Network::NetworkFilterWhiteList>::~shared_ptr[abi:ne200100](a1: a2); /*0x108764a81*/
  std::shared_ptr<RBX::Network::NetworkFilterWhiteList>::~shared_ptr[abi:ne200100](a1: a3); /*0x108764a89*/
  return std::shared_ptr<RBX::Network::NetworkFilterGlobalStats>::~shared_ptr[abi:ne200100](a1: a4); /*0x108764a95*/
}

// END Peer part 1/1, 30 functions
