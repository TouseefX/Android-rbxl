// ProcessPacketsJob -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 12 functions


// Address: 0x1067fd5b4 | Name: __ZN3RBX7Network10Replicator17ProcessPacketsJobC2ERS1_
__int64 __fastcall RBX::Network::Replicator::ProcessPacketsJob::ProcessPacketsJob(
        RBX::Network::Replicator::ProcessPacketsJob *this,
        RBX::Network::Replicator *a2)
{
  RBX::Time *v4; // rdi
  __int64 v5; // xmm0_8
  __int64 v6; // rdi
  __int64 v7; // rdi
  __int64 v8; // rdi
  int v9; // r14d
  int v10; // ecx
  void *v11; // rsi
  void *v12; // rsi
  RBX::DataModel *v13; // r12
  RBX::Instance *v14; // rsi
  __int64 v15; // rdi
  RBX::Instance *v16; // rsi
  __int64 v17; // r8
  __int64 v18; // r9
  __m128 v19; // xmm1
  __m128 v20; // xmm2
  __m128 v21; // xmm3
  __m128 v22; // xmm4
  __m128 v23; // xmm5
  __m128 v24; // xmm6
  __m128 v25; // xmm7
  __m128 v26; // xmm0
  rbx::signals::slots_holder **v27; // r15
  unsigned int v28; // esi
  unsigned int v29; // r13d
  unsigned __int64 v30; // rsi
  volatile signed __int32 *v31; // r14
  rbx::signals::slots_holder *v32; // rax
  unsigned __int64 v33; // rax
  unsigned int v34; // esi
  void *v35; // rdi
  __int64 v36; // rax
  __int64 v37; // rax
  __int64 v38; // rcx
  __int64 v39; // rdx
  __int64 v40; // rcx
  void *v41; // rsi
  int PairIntValue; // r14d
  __int64 v43; // rax
  __int64 v44; // rcx
  __int64 v45; // rdx
  __int64 v46; // rcx
  void *v47; // rsi
  int v48; // r14d
  bool v49; // zf
  int *v50; // rcx
  unsigned __int8 *v51; // rcx
  unsigned __int8 v52; // al
  void **v53; // rcx
  size_t *v54; // rdx
  void *v55; // r15
  size_t v56; // r13
  __int64 v57; // rax
  __int64 v58; // rdx
  __int64 v59; // rcx
  int v60; // r14d
  void *v61; // rsi
  int v62; // r14d
  unsigned __int8 *v63; // rcx
  unsigned __int8 v64; // al
  void **v65; // rcx
  size_t *v66; // rdx
  void *v67; // r15
  size_t v68; // r13
  __int64 v69; // r14
  void *v70; // rsi
  int v71; // r14d
  __int64 result; // rax
  _QWORD v73[4]; // [rsp+0h] [rbp-B0h] BYREF
  _QWORD v74[4]; // [rsp+20h] [rbp-90h] BYREF
  RBX::DataModel *v75; // [rsp+40h] [rbp-70h]
  char *v76; // [rsp+48h] [rbp-68h]
  rbx::signals::connection *v77; // [rsp+50h] [rbp-60h]
  _BYTE v78[16]; // [rsp+58h] [rbp-58h] BYREF
  void *v79; // [rsp+68h] [rbp-48h]
  void *v80[2]; // [rsp+70h] [rbp-40h] BYREF
  void *v81; // [rsp+80h] [rbp-30h]

  RBX::Network::ReplicatorJob::ReplicatorJob(a1: this, a2: "Replicator ProcessPackets", a3: a2, a4: 7, a5: 4); /*0x1067fd5e3*/
  *(_QWORD *)this = &off_10CAACFC8; /*0x1067fd5ef*/
  *((_DWORD *)this + 106) = 0; /*0x1067fd5f2*/
  RBX::CEvent::CEvent(this: (RBX::Network::Replicator::ProcessPacketsJob *)((char *)this + 432), a2: false); /*0x1067fd608*/
  *((_QWORD *)this + 60) = 0; /*0x1067fd60d*/
  *((_DWORD *)this + 122) = 0; /*0x1067fd618*/
  *((_OWORD *)this + 31) = 0; /*0x1067fd625*/
  *((_OWORD *)this + 32) = 0; /*0x1067fd62c*/
  v76 = (char *)this + 432; /*0x1067fd633*/
  RBX::Time::nowFast(this: v4); /*0x1067fd637*/
  v75 = a2; /*0x1067fd63c*/
  *((_QWORD *)this + 66) = v5; /*0x1067fd640*/
  v77 = (RBX::Network::Replicator::ProcessPacketsJob *)((char *)this + 544); /*0x1067fd64f*/
  *(_OWORD *)((char *)this + 536) = 0; /*0x1067fd656*/
  *((double *)this + 69) = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: v6); /*0x1067fd662*/
  *((double *)this + 70) = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: v7); /*0x1067fd66f*/
  *((double *)this + 71) = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: v8); /*0x1067fd67c*/
  *((_QWORD *)this + 72) = 0x3FA999999999999ALL; /*0x1067fd68e*/
  *(_OWORD *)((char *)this + 584) = 0; /*0x1067fd698*/
  *((_QWORD *)this + 75) = 0; /*0x1067fd69f*/
  *((_BYTE *)this + 608) = 1; /*0x1067fd6aa*/
  v9 = 999; /*0x1067fd6b7*/
  v10 = 999; /*0x1067fd6c0*/
  if ( (unsigned int)DFInt::ClientPacketHealthyMsPerSecondLimit < 0x3E7 ) /*0x1067fd6c5*/
    v10 = DFInt::ClientPacketHealthyMsPerSecondLimit; /*0x1067fd6c5*/
  if ( DFInt::ClientPacketHealthyMsPerSecondLimit <= 0 ) /*0x1067fd6d0*/
    v10 = 1; /*0x1067fd6d0*/
  v74[0] = RBX::Time::nowFast; /*0x1067fd6f8*/
  v74[3] = (char *)&RBX::unique_function<RBX::Time ()(void),24ul,8ul,true>::unique_function<RBX::Time (*)(void)>(RBX::Time (*)(void))::Callback /*0x1067fd702*/
         + 2;
  RBX::LeakyBucket::LeakyBucket(a1: (char *)this + 616, a2: (float)v10 / 1000.0, a3: 2.0); /*0x1067fd70e*/
  RBX::unique_function<RBX::Time ()(void),24ul,8ul,true>::~unique_function(a1: (__int64)v74, a2: v11); /*0x1067fd71a*/
  if ( (unsigned int)DFInt::ClientPacketUnhealthyContEscMsPerSecond < 0x3E7 ) /*0x1067fd728*/
    v9 = DFInt::ClientPacketUnhealthyContEscMsPerSecond; /*0x1067fd728*/
  if ( DFInt::ClientPacketUnhealthyContEscMsPerSecond <= 0 ) /*0x1067fd72e*/
    v9 = 1; /*0x1067fd72e*/
  v73[0] = RBX::Time::nowFast; /*0x1067fd750*/
  v73[3] = (char *)&RBX::unique_function<RBX::Time ()(void),24ul,8ul,true>::unique_function<RBX::Time (*)(void)>(RBX::Time (*)(void))::Callback /*0x1067fd753*/
         + 2;
  RBX::LeakyBucket::LeakyBucket(a1: (char *)this + 672, a2: (float)v9 / 1000.0, a3: 2.0); /*0x1067fd762*/
  RBX::unique_function<RBX::Time ()(void),24ul,8ul,true>::~unique_function(a1: (__int64)v73, a2: v12); /*0x1067fd76e*/
  *(_OWORD *)((char *)this + 728) = 0; /*0x1067fd776*/
  *(_DWORD *)((char *)this + 743) = 0; /*0x1067fd77d*/
  RBX::DataModelJob::sendProfileDataToTelemetry(this); /*0x1067fd78a*/
  v13 = v75; /*0x1067fd78f*/
  *((_DWORD *)this + 106) = 1; /*0x1067fd793*/
  *((_BYTE *)this + 428) = 0; /*0x1067fd79d*/
  *((_QWORD *)this + 57) = RBX::DataModel::get(this: v13, a2: v14); /*0x1067fd7ac*/
  v26 = 0; /*0x1067fd7b3*/
  *((_OWORD *)this + 29) = 0; /*0x1067fd7b6*/
  if ( *((_DWORD *)v13 + 69) != 1 ) /*0x1067fd7c6*/
  {
    *(double *)(*((_QWORD *)this + 51) + 15936LL) = RBX::Time::now<(RBX::Time::SampleMethod)2>(a1: v15); /*0x1067fd7d8*/
    v27 = (rbx::signals::slots_holder **)(*((_QWORD *)this + 57) + 992LL); /*0x1067fd7e6*/
    v29 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)RBX::Memory::InstanceSignal, a2: v28); /*0x1067fd7fb*/
    rbx::lazyInitSlotsHolder(a1: v27); /*0x1067fd801*/
    v31 = (volatile signed __int32 *)rbx::signals::slot_base::operator new( /*0x1067fd810*/
                                       this: (rbx::signals::slot_base *)0x30,
                                       a2: v30);
    *(_QWORD *)v31 = &_mh_execute_header; /*0x1067fd81d*/
    *((_QWORD *)v31 + 1) = rbx::signals::slot_with_functor<RBX::Network::Replicator::ProcessPacketsJob::ProcessPacketsJob(RBX::Network::Replicator&)::$_0>::do_call; /*0x1067fd827*/
    *((_OWORD *)v31 + 1) = 0; /*0x1067fd82e*/
    v32 = *v27; /*0x1067fd833*/
    *((_QWORD *)v31 + 4) = *v27; /*0x1067fd836*/
    if ( v32 != nullptr ) /*0x1067fd83d*/
    {
      _InterlockedIncrement((volatile signed __int32 *)v32 + 1); /*0x1067fd83f*/
      v33 = *((_QWORD *)v31 + 3) & 0xFFFFFFFFFFFFFFFBLL; /*0x1067fd847*/
    }
    else
    {
      v33 = 0; /*0x1067fd84d*/
    }
    *((_QWORD *)v31 + 3) = v33; /*0x1067fd84f*/
    *((_QWORD *)v31 + 5) = this; /*0x1067fd853*/
    rbx::signals::slots_holder::insert(this: *v27, a2: (unsigned __int64)v31); /*0x1067fd85d*/
    v80[0] = (void *)v31; /*0x1067fd862*/
    _InterlockedIncrement(v31 + 1); /*0x1067fd866*/
    RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v29, a2: v34); /*0x1067fd86e*/
    rbx::signals::scoped_connection::operator=(this: v77); /*0x1067fd87b*/
    v35 = v80[0]; /*0x1067fd880*/
    if ( v80[0] != nullptr && _InterlockedDecrement((volatile signed __int32 *)v80[0] + 1) == 0 ) /*0x1067fd88d*/
      rbx::signals::slot_base::operator delete(a1: v35); /*0x1067fd88f*/
  }
  if ( DFInt::NetworkProcessPacketThresholdMs > 0 ) /*0x1067fd89c*/
    *((_DWORD *)this + 121) = DFInt::NetworkProcessPacketThresholdMs; /*0x1067fd89e*/
  if ( (DFString::ProcessingConfigPerDC & 1) != 0 ) /*0x1067fd8ad*/
    v36 = qword_10D80C480; /*0x1067fd8af*/
  else
    v36 = (unsigned __int8)DFString::ProcessingConfigPerDC >> 1; /*0x1067fd8b8*/
  if ( v36 != 0 ) /*0x1067fd8bd*/
  {
    v37 = RBX::DataModel::get(this: v13, a2: v16); /*0x1067fd8c2*/
    if ( v37 != 0 ) /*0x1067fd8ca*/
    {
      RBX::format( /*0x1067fd8df*/
        this: (RBX *)v80,
        a2: "%d",
        a3: *(unsigned int *)(v37 + 2184),
        a4: v38,
        a5: v17,
        a6: v18,
        a7: v26,
        a8: v19,
        a9: v20,
        a10: v21,
        a11: v22,
        a12: v23,
        a13: v24,
        a14: v25,
        a15: v73[0]);
      std::string::basic_string[abi:ne200100]<0>(a1: v78, a2: ",", a3: v39, a4: v40); /*0x1067fd8ef*/
      PairIntValue = RBX::Network::getPairIntValue( /*0x1067fd908*/
                       a1: (unsigned __int8 *)v80,
                       a2: (unsigned __int8 *)&DFString::ProcessingConfigPerDC,
                       a3: (__int64)v78);
      if ( (v78[0] & 1) != 0 ) /*0x1067fd90f*/
        operator delete(a1: (RBX::Memory *)v79, a2: v41); /*0x1067fd915*/
      if ( ((__int64)v80[0] & 1) != 0 ) /*0x1067fd91e*/
        operator delete(a1: (RBX::Memory *)v81, a2: v41); /*0x1067fd924*/
      if ( PairIntValue != -1 ) /*0x1067fd92d*/
        *((_DWORD *)this + 121) = PairIntValue; /*0x1067fd92f*/
    }
  }
  if ( (DFString::PacketProcessConfigUserIdPer100 & 1) != 0 ) /*0x1067fd93f*/
    v43 = qword_10D80C438; /*0x1067fd941*/
  else
    v43 = (unsigned __int8)DFString::PacketProcessConfigUserIdPer100 >> 1; /*0x1067fd94a*/
  if ( v43 != 0 ) /*0x1067fd959*/
  {
    v44 = (unsigned int)(*((_QWORD *)v13 + 2700) % 100LL); /*0x1067fd980*/
    RBX::format( /*0x1067fd991*/
      this: (RBX *)v80,
      a2: "%d",
      a3: (unsigned int)v44,
      a4: v44,
      a5: v17,
      a6: v18,
      a7: v26,
      a8: v19,
      a9: v20,
      a10: v21,
      a11: v22,
      a12: v23,
      a13: v24,
      a14: v25,
      a15: v73[0]);
    std::string::basic_string[abi:ne200100]<0>(a1: v78, a2: ",", a3: v45, a4: v46); /*0x1067fd9a1*/
    v48 = RBX::Network::getPairIntValue( /*0x1067fd9ba*/
            a1: (unsigned __int8 *)v80,
            a2: (unsigned __int8 *)&DFString::PacketProcessConfigUserIdPer100,
            a3: (__int64)v78);
    if ( (v78[0] & 1) != 0 ) /*0x1067fd9c1*/
      operator delete(a1: (RBX::Memory *)v79, a2: v47); /*0x1067fd9c7*/
    if ( ((__int64)v80[0] & 1) != 0 ) /*0x1067fd9d0*/
      operator delete(a1: (RBX::Memory *)v81, a2: v47); /*0x1067fd9d6*/
    if ( v48 != -1 ) /*0x1067fd9df*/
      *((_DWORD *)this + 121) = v48; /*0x1067fd9e1*/
  }
  *((_DWORD *)v13 + 3947) = *((_DWORD *)this + 121); /*0x1067fd9ee*/
  v49 = *((_DWORD *)v13 + 69) == 0; /*0x1067fd9f6*/
  v50 = &DFInt::NetworkInProcessLimitGameplayMsRcc; /*0x1067fda06*/
  if ( *((_DWORD *)v13 + 69) == 0 ) /*0x1067fda0d*/
    v50 = &DFInt::NetworkInProcessLimitGameplayMsClient; /*0x1067fda0d*/
  *((_DWORD *)this + 122) = *v50; /*0x1067fda13*/
  v51 = (unsigned __int8 *)&DFString::NetworkInProcessLimitGameplayPerDCRcc; /*0x1067fda20*/
  if ( v49 ) /*0x1067fda27*/
    v51 = (unsigned __int8 *)&DFString::NetworkInProcessLimitGameplayPerDCClient; /*0x1067fda27*/
  v52 = *v51; /*0x1067fda2b*/
  v53 = (void **)&unk_10D80C4B8; /*0x1067fda34*/
  if ( v49 ) /*0x1067fda3b*/
    v53 = (void **)&unk_10D80C4A0; /*0x1067fda3b*/
  v54 = (size_t *)&unk_10D80C4B0; /*0x1067fda46*/
  if ( v49 ) /*0x1067fda4d*/
    v54 = (size_t *)&unk_10D80C498; /*0x1067fda4d*/
  v55 = &unk_10D80C4A9; /*0x1067fda58*/
  if ( v49 ) /*0x1067fda5f*/
    v55 = &unk_10D80C491; /*0x1067fda5f*/
  if ( (v52 & 1) != 0 ) /*0x1067fda65*/
  {
    v55 = *v53; /*0x1067fda67*/
    v56 = *v54; /*0x1067fda6a*/
  }
  else
  {
    v56 = v52 >> 1; /*0x1067fda71*/
  }
  if ( v56 != 0 ) /*0x1067fda78*/
  {
    v57 = RBX::DataModel::get(this: v13, a2: (RBX::Instance *)&unk_10D80C491); /*0x1067fda7d*/
    if ( v57 != 0 ) /*0x1067fda85*/
    {
      v60 = *(_DWORD *)(v57 + 2184); /*0x1067fda87*/
      std::string::basic_string[abi:ne200100]<0>(a1: v80, a2: ",", a3: v58, a4: v59); /*0x1067fda99*/
      v62 = RBX::Network::getPairIntValue(a1: v60, a2: v55, a3: v56, a4: (unsigned __int8 *)v80); /*0x1067fdab0*/
      if ( ((__int64)v80[0] & 1) != 0 ) /*0x1067fdab7*/
        operator delete(a1: (RBX::Memory *)v81, a2: v61); /*0x1067fdabd*/
      if ( v62 != -1 ) /*0x1067fdac6*/
        *((_DWORD *)this + 122) = v62; /*0x1067fdac8*/
    }
  }
  v63 = (unsigned __int8 *)&DFString::NetworkInProcessLimitGameplayUserIdPer100Rcc; /*0x1067fdadf*/
  if ( *((_DWORD *)v13 + 69) == 0 ) /*0x1067fdae6*/
    v63 = (unsigned __int8 *)&DFString::NetworkInProcessLimitGameplayUserIdPer100Client; /*0x1067fdae6*/
  v64 = *v63; /*0x1067fdaea*/
  v65 = (void **)&unk_10D80C470; /*0x1067fdaf3*/
  if ( *((_DWORD *)v13 + 69) == 0 ) /*0x1067fdafa*/
    v65 = (void **)&unk_10D80C458; /*0x1067fdafa*/
  v66 = (size_t *)&unk_10D80C468; /*0x1067fdb05*/
  if ( *((_DWORD *)v13 + 69) == 0 ) /*0x1067fdb0c*/
    v66 = (size_t *)&unk_10D80C450; /*0x1067fdb0c*/
  v67 = &unk_10D80C461; /*0x1067fdb17*/
  if ( *((_DWORD *)v13 + 69) == 0 ) /*0x1067fdb1e*/
    v67 = &unk_10D80C449; /*0x1067fdb1e*/
  if ( (v64 & 1) != 0 ) /*0x1067fdb24*/
  {
    v67 = *v65; /*0x1067fdb26*/
    v68 = *v66; /*0x1067fdb29*/
  }
  else
  {
    v68 = v64 >> 1; /*0x1067fdb30*/
  }
  if ( v68 != 0 ) /*0x1067fdb37*/
  {
    v69 = *((_QWORD *)v13 + 2700); /*0x1067fdb39*/
    std::string::basic_string[abi:ne200100]<0>(a1: v80, a2: ",", a3: v66, a4: v65); /*0x1067fdb4c*/
    v71 = RBX::Network::getPairIntValue(a1: v69 % 100, a2: v67, a3: v68, a4: (unsigned __int8 *)v80); /*0x1067fdb89*/
    if ( ((__int64)v80[0] & 1) != 0 ) /*0x1067fdb90*/
      operator delete(a1: (RBX::Memory *)v81, a2: v70); /*0x1067fdb96*/
    if ( v71 != -1 ) /*0x1067fdb9f*/
      *((_DWORD *)this + 122) = v71; /*0x1067fdba1*/
  }
  result = *((unsigned int *)this + 122); /*0x1067fdba8*/
  *((_DWORD *)v13 + 4656) = result; /*0x1067fdbae*/
  return result; /*0x1067fdbb6*/
}

// Address: 0x1067fdcb6 | Name: __ZN3RBX7Network10Replicator17ProcessPacketsJobC1ERS1_
__int64 __fastcall RBX::Network::Replicator::ProcessPacketsJob::ProcessPacketsJob(
        RBX::Network::Replicator::ProcessPacketsJob *this,
        RBX::Network::Replicator *a2)
{
  return RBX::Network::Replicator::ProcessPacketsJob::ProcessPacketsJob(this, a2); /*0x1067fdcba*/
}

// Address: 0x1067fdcc0 | Name: __ZN3RBX7Network10Replicator17ProcessPacketsJob8testWakeEv
void __fastcall RBX::Network::Replicator::ProcessPacketsJob::testWake(
        RBX::Network::Replicator::ProcessPacketsJob *this)
{
  *((_DWORD *)this + 106) = 1; /*0x1067fdcc4*/
  *((_BYTE *)this + 428) = 0; /*0x1067fdcce*/
}

// Address: 0x1067fdcd8 | Name: __ZNK3RBX7Network10Replicator17ProcessPacketsJob26computeHealthyTimeIntervalERKNS_13TaskScheduler3Job5StatsE
double __fastcall RBX::Network::Replicator::ProcessPacketsJob::computeHealthyTimeInterval(__int64 a1)
{
  float v1; // xmm0_4

  v1 = (float)((float)DFInt::ClientPacketHealthyAllocationPercent / 100.0) * *(double *)(a1 + 592); /*0x1067fdcf8*/
  return fmaxf((float)DFInt::ClientPacketMinMicroseconds, v1) * 0.000001; /*0x1067fdd17*/
}

// Address: 0x1067fdd1a | Name: __ZN3RBX7Network10Replicator17ProcessPacketsJob19processTimeIntervalERKNS_13TaskScheduler3Job5StatsE
double __fastcall RBX::Network::Replicator::ProcessPacketsJob::processTimeInterval(RBX::DataModelJob *this, __int64 a2)
{
  __int64 v4; // rdi
  __int64 v5; // r15
  float v6; // xmm1_4
  __int64 v7; // rax
  int v8; // r12d
  int v9; // ecx
  int v10; // ecx
  int v11; // r8d
  int v12; // r9d
  float v13; // xmm0_4
  _QWORD *v14; // rdi
  __int64 v15; // rax
  float v16; // xmm0_4
  _QWORD *v17; // rdi
  __int64 v18; // rax
  const char *v19; // rdx
  float v20; // xmm1_4
  float v21; // xmm0_4
  double v22; // xmm1_8
  double v23; // xmm0_8
  int v24; // eax
  int v25; // ecx
  const char *v27; // rsi
  double v28; // [rsp+18h] [rbp-38h]
  RBX::LeakyBucket *v29; // [rsp+18h] [rbp-38h]
  double v30; // [rsp+20h] [rbp-30h]
  float v31; // [rsp+20h] [rbp-30h]

  if ( DFFlag::ClientPacketLimiting != 1 ) /*0x1067fdd38*/
    goto LABEL_33; /*0x1067fdd38*/
  v4 = *((_QWORD *)this + 51); /*0x1067fdd3e*/
  if ( *(_DWORD *)(v4 + 276) == 0 && *(_BYTE *)(v4 + 18702) == 1 )
  {
    v28 = *(double *)(a2 + 8) * 1000.0 * 1000.0; /*0x1067fdd79*/
    v30 = *(double *)(a2 + 8) + *((double *)this + 91); /*0x1067fdd86*/
    v5 = RBX::Network::Replicator::packetProcessingStats(this: (RBX::Network::Replicator *)v4); /*0x1067fdd90*/
    v6 = v28; /*0x1067fdda8*/
    RBX::RunningAverage<double,double>::sample( /*0x1067fddb5*/
      a1: (__int64)this + 576,
      a2: fminf((float)DFInt::ClientPacketMaxFrameMicroseconds, v6));
    v7 = 16; /*0x1067fddbf*/
    if ( *((_BYTE *)this + 746) != 1 /*0x1067fdde9*/
      || (*(double *)(v5 + 24) = *(double *)(v5 + 24) + v30, v7 = 32, *((_BYTE *)this + 744) == 1) )
    {
      *(double *)(v5 + v7) = *(double *)(v5 + v7) + v30; /*0x1067fddf5*/
    }
    v8 = 999; /*0x1067fde05*/
    v9 = 999; /*0x1067fde0e*/
    if ( (unsigned int)DFInt::ClientPacketHealthyMsPerSecondLimit < 0x3E7 ) /*0x1067fde13*/
      v9 = DFInt::ClientPacketHealthyMsPerSecondLimit; /*0x1067fde13*/
    if ( DFInt::ClientPacketHealthyMsPerSecondLimit <= 0 ) /*0x1067fde1e*/
      v9 = 1; /*0x1067fde1e*/
    v29 = (RBX::DataModelJob *)((char *)this + 616); /*0x1067fde40*/
    RBX::LeakyBucket::updateParameters(this: (RBX::DataModelJob *)((char *)this + 616), a2: (float)v9 / 1000.0, a3: 2.0); /*0x1067fde44*/
    if ( (unsigned int)DFInt::ClientPacketUnhealthyContEscMsPerSecond < 0x3E7 ) /*0x1067fde52*/
      v8 = DFInt::ClientPacketUnhealthyContEscMsPerSecond; /*0x1067fde52*/
    if ( DFInt::ClientPacketUnhealthyContEscMsPerSecond <= 0 ) /*0x1067fde5f*/
      v8 = 1; /*0x1067fde5f*/
    RBX::LeakyBucket::updateParameters(this: (RBX::DataModelJob *)((char *)this + 672), a2: (float)v8 / 1000.0, a3: 2.0); /*0x1067fde7e*/
    if ( *((_BYTE *)this + 745) == 1 ) /*0x1067fde8a*/
    {
      if ( *((_BYTE *)this + 746) == 1 ) /*0x1067fde97*/
      {
        if ( *((double *)this + 92) * 1000.0 > (double)DFInt::ClientPacketMaxDelayMs /*0x1067fded1*/
          || (v13 = v30, (unsigned __int8)RBX::LeakyBucket::checkAdd(this: v29, a2: v13) == 0) )
        {
          *((_BYTE *)this + 746) = 0; /*0x1067fded7*/
          *((_DWORD *)this + 156) = 0; /*0x1067fdede*/
          v14 = (_QWORD *)((char *)this + 640); /*0x1067fdee8*/
          v15 = *((_QWORD *)this + 83); /*0x1067fdeef*/
          if ( (v15 & 2) == 0 ) /*0x1067fdef8*/
            v14 = (_QWORD *)*v14; /*0x1067fdefa*/
          *(double *)v29 = (*(double (__fastcall **)(_QWORD *))(v15 & 0xFFFFFFFFFFFFFFF8LL))(a1: v14); /*0x1067fdf0b*/
          ++*(_DWORD *)(v5 + 12); /*0x1067fdf0f*/
        }
      }
    }
    else
    {
      v16 = v30; /*0x1067fdf18*/
      if ( (unsigned __int8)RBX::LeakyBucket::checkAdd(this: (RBX::DataModelJob *)((char *)this + 672), a2: v16) == 0 ) /*0x1067fdf27*/
      {
        *((_DWORD *)this + 170) = 0; /*0x1067fdf29*/
        v17 = (_QWORD *)((char *)this + 696); /*0x1067fdf33*/
        v18 = *((_QWORD *)this + 90); /*0x1067fdf3a*/
        if ( (v18 & 2) == 0 ) /*0x1067fdf43*/
          v17 = (_QWORD *)*v17; /*0x1067fdf45*/
        *((double *)this + 84) = (*(double (__fastcall **)(_QWORD *))(v18 & 0xFFFFFFFFFFFFFFF8LL))(a1: v17); /*0x1067fdf4e*/
        *((_BYTE *)this + 746) = 1; /*0x1067fdf56*/
      }
    }
    if ( DFFlag::DebugCLientPacketLimitingLabels == 1 )
    {
      if ( (_BYTE)`guard variable for'RBX::Network::Replicator::ProcessPacketsJob::processTimeInterval(RBX::TaskScheduler::Job::Stats const&)::proflabeltoken == 0 /*0x1067fe092*/
        && __cxa_guard_acquire(a1: &`guard variable for'RBX::Network::Replicator::ProcessPacketsJob::processTimeInterval(RBX::TaskScheduler::Job::Stats const&)::proflabeltoken) != 0 )
      {
        RBX::Network::Replicator::ProcessPacketsJob::processTimeInterval(RBX::TaskScheduler::Job::Stats const&)::proflabeltoken = RBX::Profiler::getLabelToken(this: (RBX::Profiler *)&aNull_7[-195779], a2: v27); /*0x1067fe0b3*/
        __cxa_guard_release(a1: &`guard variable for'RBX::Network::Replicator::ProcessPacketsJob::processTimeInterval(RBX::TaskScheduler::Job::Stats const&)::proflabeltoken); /*0x1067fe0c1*/
      }
      v19 = "false"; /*0x1067fdf82*/
      if ( *((_BYTE *)this + 746) != 0 ) /*0x1067fdf90*/
        v19 = "true"; /*0x1067fdf90*/
      RBX::Profiler::addLabelFormat(
        a1: RBX::Network::Replicator::ProcessPacketsJob::processTimeInterval(RBX::TaskScheduler::Job::Stats const&)::proflabeltoken,
        a2: (unsigned int)"Healthy : %s",
        a3: (_DWORD)v19,
        a4: v10,
        a5: v11,
        a6: v12);
    }
  }
  *((_QWORD *)this + 91) = 0; /*0x1067fdfa2*/
  if ( *((_BYTE *)this + 746) == 1 ) /*0x1067fdfb4*/
  {
    v20 = (float)((float)DFInt::ClientPacketHealthyAllocationPercent / 100.0) * *((double *)this + 74); /*0x1067fdfe3*/
    v21 = fmaxf((float)DFInt::ClientPacketMinMicroseconds, v20); /*0x1067fdfe7*/
    v22 = 0.000001; /*0x1067fdfeb*/
  }
  else
  {
LABEL_33:
    RBX::DataModelJob::updateStepsRequiredForCyclicExecutive( /*0x1067fe019*/
      this,
      a2: *(double *)(a2 + 8),
      a3: 60.0,
      a4: (float)DFInt::MaxProcessPacketsStepsPerCyclic,
      a5: (float)DFInt::MaxProcessPacketsStepsAccumulated);
    *(float *)&v23 = v23; /*0x1067fe01e*/
    v31 = *(float *)&v23; /*0x1067fe022*/
    v24 = RBX::Network::Replicator::incomingPacketsCount(this: *((RBX::Network::Replicator **)this + 51)); /*0x1067fe02e*/
    v25 = 5; /*0x1067fe036*/
    if ( v24 < 5 ) /*0x1067fe03b*/
      v25 = v24; /*0x1067fe03b*/
    v21 = fminf((float)v25 * fmaxf(v31, 1.0), (float)DFInt::MaxProcessPacketsJobScaling); /*0x1067fe061*/
    v22 = 0.008333333333333333; /*0x1067fe065*/
  }
  return v21 * v22; /*0x1067fe075*/
}

// Address: 0x1067fe0e2 | Name: __ZN3RBX7Network10Replicator17ProcessPacketsJob10trackPauseEv
void __fastcall RBX::Network::Replicator::ProcessPacketsJob::trackPause(
        RBX::Network::Replicator::ProcessPacketsJob *this)
{
  __int64 v1; // rax
  __int64 v3; // rdi
  __int64 v4; // r14
  __int64 RakNetPacket; // rsi
  RBX::CoreNetworkSettings *v6; // rdi
  RBX::Network::Replicator *v7; // rdi
  char *v8; // r14
  __int64 v9; // r15
  unsigned __int8 v10; // dl
  unsigned __int8 v11; // r12
  RBX::CoreNetworkSettings *v12; // rdi
  __int64 v13; // r13
  __int64 v14; // r9
  __int64 v15; // rdx
  char *v16; // rdi
  __int64 v17; // rsi
  __int64 v18; // rcx
  __int64 v19; // r8
  __int64 v20; // r14
  RBX::Network::Replicator *v21; // rdi
  char *v22; // r15
  __int64 v23; // rax
  RBX::Network::Replicator *v24; // rdi
  char *v25; // r14
  __int64 v26; // rax
  RBX::Network::Replicator *v27; // rdi
  RBX::Network::EmptyQueueTracker *v28; // rbx
  __int64 v29; // rax
  __int64 v30; // [rsp-8h] [rbp-30h]

  v30 = v1; /*0x1067fe0ef*/
  v3 = *((_QWORD *)this + 51); /*0x1067fe0f3*/
  v4 = v3 + 10640; /*0x1067fe0fa*/
  if ( FFlag::RefactorIngressFlow == 1 ) /*0x1067fe10b*/
    RakNetPacket = RBX::Network::IncomingPacket::getRakNetPacket(this: (RBX::Network::IncomingPacket *)(v3 + 11440)); /*0x1067fe119*/
  else
    RakNetPacket = *(_QWORD *)(v3 + 11320); /*0x1067fe11e*/
  RBX::Network::StuckPacketTracker::updateAndReportOnThreshold(a1: v4, a2: RakNetPacket); /*0x1067fe128*/
  if ( DFFlag::ReportDmIsShuttingDownQueueStuck == 1 ) /*0x1067fe137*/
  {
    v7 = *((RBX::Network::Replicator **)this + 51); /*0x1067fe139*/
    v8 = (char *)v7 + 10672; /*0x1067fe140*/
    v9 = RBX::Network::Replicator::peekPacketHeadTimestamp(this: v7); /*0x1067fe14c*/
    v11 = v10; /*0x1067fe14f*/
    v13 = *(_QWORD *)(RBX::CoreNetworkSettings::singleton(this: v12) + 112); /*0x1067fe157*/
    v14 = (unsigned __int8)RBX::DataModel::getIsShuttingDown(this: *((RBX::DataModel **)this + 57)) | 0x100u; /*0x1067fe16b*/
    v15 = v11; /*0x1067fe172*/
    v16 = v8; /*0x1067fe176*/
    v17 = v9; /*0x1067fe179*/
    v18 = v13; /*0x1067fe17c*/
    v19 = 1; /*0x1067fe17f*/
  }
  else
  {
    if ( DFFlag::ReportIncomingRepLagWithStats == 1 ) /*0x1067fe191*/
    {
      v20 = *(_QWORD *)(RBX::CoreNetworkSettings::singleton(this: v6) + 112); /*0x1067fe198*/
      v21 = *((RBX::Network::Replicator **)this + 51); /*0x1067fe19c*/
      v22 = (char *)v21 + 10672; /*0x1067fe1a3*/
      v23 = RBX::Network::Replicator::peekPacketHeadTimestamp(this: v21); /*0x1067fe1aa*/
      v15 = (unsigned __int8)v15; /*0x1067fe1af*/
      v16 = v22; /*0x1067fe1b2*/
      v17 = v23; /*0x1067fe1b5*/
      v18 = v20; /*0x1067fe1b8*/
      v19 = 1; /*0x1067fe1bb*/
    }
    else
    {
      v24 = *((RBX::Network::Replicator **)this + 51); /*0x1067fe1c3*/
      v25 = (char *)v24 + 10672; /*0x1067fe1ca*/
      v26 = RBX::Network::Replicator::peekPacketHeadTimestamp(this: v24); /*0x1067fe1d1*/
      v15 = (unsigned __int8)v15; /*0x1067fe1d6*/
      v16 = v25; /*0x1067fe1d9*/
      v17 = v26; /*0x1067fe1dc*/
      v18 = 0; /*0x1067fe1df*/
      v19 = 0; /*0x1067fe1e1*/
    }
    v14 = 0; /*0x1067fe1e4*/
  }
  RBX::Network::StuckQueueTracker::updateAndReportOnThreshold( /*0x1067fe1e7*/
    a1: v16,
    a2: v17,
    a3: v15,
    a4: v18,
    a5: v19,
    a6: v14,
    a7: v30);
  v27 = *((RBX::Network::Replicator **)this + 51); /*0x1067fe1ec*/
  v28 = (RBX::Network::Replicator *)((char *)v27 + 10624); /*0x1067fe1f3*/
  v29 = RBX::Network::Replicator::incomingPacketsCount(this: v27); /*0x1067fe1fa*/
  RBX::Network::EmptyQueueTracker::updateAndReportOnThreshold(this: v28, a2: v29); /*0x1067fe213*/
}

// Address: 0x1067fe218 | Name: __ZN3RBX7Network10Replicator17ProcessPacketsJob16stepDataModelJobERKNS_13TaskScheduler3Job5StatsE
__int64 __fastcall RBX::Network::Replicator::ProcessPacketsJob::stepDataModelJob(
        RBX::Network::Replicator **this,
        char *a2)
{
  unsigned int v4; // r13d
  __int64 v5; // rdi
  __int64 v6; // rdi
  __int64 v7; // rax
  __int64 v8; // rdi
  double v9; // xmm0_8
  float v10; // xmm0_4
  __int64 v11; // rdi
  __int64 v12; // rdi
  double v13; // xmm0_8
  float v14; // xmm0_4
  RBX::Network::Replicator *v15; // rdi
  __int64 v16; // rdi
  RBX::ScriptContext **v17; // rax
  RBX::Http *v18; // rdi
  void *v19; // rsi
  RBX::ScriptContext *v20; // rbx
  double v21; // xmm0_8
  double v22; // xmm0_8
  __int64 v23; // rax
  __int64 v24; // rcx
  __int64 NumOfDownloadedBytes; // r12
  __int64 v26; // rbx
  __int64 v27; // rdx
  __int64 v28; // rcx
  int v29; // r8d
  int v30; // r9d
  double v31; // xmm0_8
  double v32; // xmm3_8
  __m128d v33; // xmm7
  __m128d v34; // xmm7
  unsigned int v35; // ecx
  __int64 Dangerous_DEPRECATED; // rax
  RBX::Instance *v37; // rsi
  __int64 v38; // rdi
  __int64 v39; // rsi
  void *v40; // rsi
  double v41; // xmm0_8
  __int64 v42; // rdi
  char hasUnprocessedData; // al
  unsigned int v44; // r12d
  __int64 v45; // rax
  double v46; // xmm0_8
  __int64 v47; // rdi
  __int64 v48; // xmm0_8
  RBX::Time *v49; // rdi
  bool v50; // al
  __int64 v51; // rsi
  __int64 v52; // rdx
  unsigned __int8 v53; // al
  char *v54; // rcx
  int v55; // r8d
  int v56; // r10d
  char v57; // r11
  __int64 v58; // rcx
  __int64 v59; // rdx
  int v60; // r8d
  int v61; // r10d
  char v62; // r11
  __int64 *v63; // rdx
  __int64 v64; // r8
  __int64 v65; // rdi
  double v66; // xmm0_8
  __int64 v67; // rax
  double v68; // xmm0_8
  _QWORD *v69; // rdi
  __int64 v70; // rbx
  __int64 v71; // rdi
  __int64 v72; // rax
  char *v73; // rdx
  int v74; // ecx
  char v75; // r8
  __int64 v76; // rcx
  char *v77; // rax
  int v78; // edx
  char v79; // r8
  _QWORD *v80; // rcx
  bool v81; // zf
  double v82; // xmm0_8
  double v83; // r13
  int *v84; // rdi
  RBX::Network::Replicator *v85; // xmm0_8
  double v86; // xmm0_8
  double v87; // xmm1_8
  double v88; // xmm0_8
  RBX::Network::Replicator *v89; // rdi
  double v90; // xmm0_8
  __int64 v91; // rax
  __m128i v92; // xmm1
  __m128d v93; // xmm0
  double v94; // xmm3_8
  __m128d v95; // xmm2
  __m128d v96; // xmm2
  char v97; // al
  double v98; // xmm0_8
  int v99; // ecx
  __int64 v100; // r12
  double v101; // xmm0_8
  __int64 v102; // rax
  __int64 v103; // r12
  double v104; // xmm1_8
  float v105; // xmm0_4
  double v106; // xmm4_8
  RBX::CoreNetworkSettings *v107; // rdi
  __int64 v108; // rax
  int v109; // edx
  int v110; // ecx
  int v111; // r8d
  int v112; // r9d
  double v113; // xmm0_8
  bool v114; // cc
  int v115; // edx
  int v116; // ecx
  int v117; // r8d
  int v118; // r9d
  float v119; // xmm0_4
  __int64 v120; // rdi
  __int64 v121; // rax
  __int64 v122; // r15
  int v123; // ebx
  unsigned int v124; // eax
  int v125; // r8d
  int v126; // r9d
  const char *v127; // rsi
  int v128; // ecx
  RBX::WorldRoot *Workspace; // rax
  int WorldStepId; // r15d
  int RemoteWorldStepId; // r12d
  RBX::AuroraService *v132; // rax
  char hasData; // al
  const char *v134; // rsi
  const char *v136; // rsi
  const char *v137; // rsi
  _BYTE v138[32]; // [rsp+8h] [rbp-118h] BYREF
  void *v139; // [rsp+28h] [rbp-F8h]
  char v140; // [rsp+40h] [rbp-E0h]
  double v141; // [rsp+48h] [rbp-D8h]
  double v142; // [rsp+50h] [rbp-D0h]
  __int128 v143; // [rsp+58h] [rbp-C8h] BYREF
  void *v144; // [rsp+68h] [rbp-B8h]
  double v145; // [rsp+80h] [rbp-A0h] BYREF
  double v146; // [rsp+88h] [rbp-98h]
  __m128d v147; // [rsp+90h] [rbp-90h]
  int *v148; // [rsp+A8h] [rbp-78h]
  double v149; // [rsp+B0h] [rbp-70h]
  double v150; // [rsp+B8h] [rbp-68h]
  __m128d v151; // [rsp+C0h] [rbp-60h]
  double v152; // [rsp+D8h] [rbp-48h] BYREF
  unsigned __int8 v153; // [rsp+E7h] [rbp-39h]
  double v154; // [rsp+E8h] [rbp-38h]
  unsigned int v155; // [rsp+F4h] [rbp-2Ch]

  v4 = RBX::Memory::setCurrentCategory( /*0x1067fe23d*/
         this: (RBX::Memory *)(unsigned int)RBX::Memory::NetworkProcessPackets,
         (unsigned int)a2);
  if ( DFFlag::TrackPPJProgress == 1 && *(this + 51) != nullptr ) /*0x1067fe251*/
    RBX::Network::Replicator::ProcessPacketsJob::trackPause((RBX::Network::Replicator::ProcessPacketsJob *)this); /*0x1067fe256*/
  v5 = (__int64)*(this + 51); /*0x1067fe25b*/
  if ( *(_DWORD *)(v5 + 276) != 0 ) /*0x1067fe269*/
  {
    RBX::Network::Replicator::updateMaxPacketQueueSize(this: (RBX::Network::Replicator *)v5); /*0x1067fe26b*/
  }
  else
  {
    *(_BYTE *)(v5 + 15729) = 0; /*0x1067fe274*/
    RBX::Network::TaskSchedulerJobStats::TaskSchedulerJobStats( /*0x1067fe28c*/
      this: (RBX::Network::TaskSchedulerJobStats *)&v143,
      (const RBX::Time *)a2,
      a3: (const RBX::Time::Interval *)(a2 + 8),
      a4: (const RBX::Time::Interval *)(a2 + 16));
    v7 = *((_QWORD *)*(this + 51) + 1471); /*0x1067fe298*/
    *(_QWORD *)(v7 + 56) = v144; /*0x1067fe2a6*/
    *(_OWORD *)(v7 + 40) = v143; /*0x1067fe2b2*/
    RBX::Network::Replicator::recordPacketsMissingFrameStats(this: *(this + 51)); /*0x1067fe2be*/
    RBX::Network::Replicator::reportPacketsMissingPPJFrameWindowIfTimerAllows(this: *(this + 51)); /*0x1067fe2ca*/
  }
  v9 = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: v6) - *((double *)this + 70); /*0x1067fe2d4*/
  if ( v9 > (double)DFInt::RakNetStatsShortInterval ) /*0x1067fe2ec*/
  {
    v10 = v9; /*0x1067fe2f5*/
    RBX::Network::Replicator::handleShortIntervalStats(this: *(this + 51), a2: v10); /*0x1067fe2f9*/
    *((double *)this + 70) = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: v11); /*0x1067fe303*/
  }
  v13 = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: v8) - *((double *)this + 69); /*0x1067fe311*/
  if ( v13 > (double)DFInt::SendRakNetStatsInterval ) /*0x1067fe32c*/
  {
    v154 = v13; /*0x1067fe32e*/
    if ( (unsigned __int8)RBX::Network::Replicator::shouldRecordPhysicsReplicationStats(this: *(this + 51)) != 0 /*0x1067fe355*/
      || (*(unsigned __int8 (__fastcall **)(_QWORD))(*(_QWORD *)*(this + 51) + 1032LL))(a1: *(this + 51)) != 0 )
    {
      v14 = v154; /*0x1067fe361*/
      RBX::Network::Replicator::reportReplicatorStatsToTelemetryV2(this: *(this + 51), a2: v14); /*0x1067fe366*/
      v15 = *(this + 51); /*0x1067fe372*/
      if ( DFFlag::MoveESEIReplicatorStatsToNewFlow == 1 ) /*0x1067fe37c*/
        (*(void (__fastcall **)(RBX::Network::Replicator *))(*(_QWORD *)v15 + 1568LL))(a1: v15); /*0x1067fe381*/
      else
        RBX::Network::Replicator::reportReplicatorStats_deprecated(this: v15); /*0x1067fe389*/
    }
    RBX::Network::Replicator::resetRakNetStatistics(this: *(this + 51)); /*0x1067fe395*/
    *((double *)this + 69) = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: v16); /*0x1067fe39f*/
  }
  if ( FFlag::ReportTypeBandwidthStatsInterval == 1 /*0x1067fe3d4*/
    && RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: v12) - *((double *)this + 71) > (double)DFInt::ReportTypeBandwidthStatsEveryNSec )
  {
    *((double *)this + 71) = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: v12); /*0x1067fe3db*/
    RBX::Network::TwoWayBandwidthMetrics::reportOnInterval(a1: (char *)*(this + 51) + 288, a2: 0); /*0x1067fe3f2*/
    v12 = (__int64)*(this + 51); /*0x1067fe3f7*/
    if ( *(_DWORD *)(v12 + 276) == 1 ) /*0x1067fe405*/
      RBX::Network::TwoWayBandwidthMetrics::reportOnInterval(a1: v12 + 288, a2: 1); /*0x1067fe413*/
  }
  *(this + 65) = nullptr; /*0x1067fe418*/
  *((double *)this + 66) = RBX::Time::now<(RBX::Time::SampleMethod)2>(a1: v12); /*0x1067fe428*/
  v17 = (RBX::ScriptContext **)RBX::ServiceProvider::refByClass<RBX::ScriptContext>(this: (RBX::Network::Replicator *)((char *)*(this + 57) + 464)); /*0x1067fe43d*/
  v20 = *v17; /*0x1067fe442*/
  if ( *v17 != nullptr ) /*0x1067fe448*/
  {
    RBX::ScriptContext::getLuaTimeThisFrame(this: *v17); /*0x1067fe44d*/
    v154 = v21; /*0x1067fe452*/
    RBX::ScriptContext::getLuaGcTimeThisFrame(this: v20); /*0x1067fe45a*/
    *((double *)this + 65) = v154 + v22; /*0x1067fe468*/
  }
  v23 = (__int64)*(this + 51); /*0x1067fe478*/
  if ( FFlag::LogClientLoadToAvatarLoad != 1 ) /*0x1067fe482*/
  {
LABEL_35:
    if ( v23 != 0 ) /*0x1067fe619*/
      goto LABEL_36; /*0x1067fe619*/
LABEL_208:
    v44 = 1; /*0x1067ff2a0*/
    goto LABEL_209; /*0x1067ff2a0*/
  }
  if ( v23 == 0 ) /*0x1067fe48b*/
    goto LABEL_208; /*0x1067fe48b*/
  if ( *(_DWORD *)(v23 + 276) != 1 ) /*0x1067fe498*/
  {
    v24 = (__int64)*(this + 57); /*0x1067fe49e*/
    if ( v24 != 0 && *(_BYTE *)(v24 + 1512) == 0 ) /*0x1067fe4b5*/
    {
      NumOfDownloadedBytes = RBX::Http::getNumOfDownloadedBytes(this: v18); /*0x1067fe4c0*/
      v26 = (__int64)*(this + 51); /*0x1067fe4c3*/
      std::string::basic_string[abi:ne200100]<0>(a1: &v143, a2: "Total Bytes Received", a3: v27, a4: v28); /*0x1067fe4d8*/
      v31 = (*(double (__fastcall **)(__int64, __int128 *))(*(_QWORD *)v26 + 808LL))(a1: v26, a2: &v143); /*0x1067fe4ea*/
      v32 = v31; /*0x1067fe4f0*/
      v33 = _mm_sub_pd( /*0x1067fe501*/
              (__m128d)_mm_unpacklo_epi32((__m128i)(unsigned __int64)NumOfDownloadedBytes, (__m128i)xmmword_108F2F9A0),
              (__m128d)xmmword_108F2F9B0);
      v34 = _mm_hadd_pd(v33, v33); /*0x1067fe509*/
      if ( (v143 & 1) != 0 ) /*0x1067fe514*/
      {
        v154 = v31; /*0x1067fe51d*/
        v151 = v34; /*0x1067fe522*/
        operator delete(a1: (RBX::Memory *)v144, a2: v19); /*0x1067fe527*/
        v34 = v151; /*0x1067fe52c*/
        v32 = v154; /*0x1067fe531*/
      }
      if ( *((double *)this + 58) != 0.0 && *((double *)this + 59) != 0.0 && *((double *)a2 + 1) != 0.0 ) /*0x1067fe56e*/
      {
        v35 = (unsigned int)FLog::LogStepTimeAndNetworkUsage >> 8; /*0x1067fe582*/
        LOBYTE(v35) = (unsigned __int8)FLog::LogStepTimeAndNetworkUsage < 6u /*0x1067fe592*/
                   || BYTE1(FLog::LogStepTimeAndNetworkUsage) < 3u;
        if ( (_BYTE)v35 == 0 ) /*0x1067fe594*/
        {
          v154 = v32; /*0x1067fe5c6*/
          v151 = v34; /*0x1067fe5e9*/
          FLog::FastLogFormatted( /*0x1067fe5ee*/
            a1: FLog::LogStepTimeAndNetworkUsage,
            a2: qword_10D804018,
            a3: (unsigned int)"[FLog::LogStepTimeAndNetworkUsage] %f, %f, %f, %f",
            a4: v35,
            a5: v29,
            a6: v30);
          v34.f64[0] = v151.f64[0]; /*0x1067fe5f3*/
          v32 = v154; /*0x1067fe5f8*/
        }
      }
      *(this + 58) = *(RBX::Network::Replicator **)&v34.f64[0]; /*0x1067fe5fd*/
      *((double *)this + 59) = v32; /*0x1067fe606*/
      v23 = (__int64)*(this + 51); /*0x1067fe60f*/
      goto LABEL_35; /*0x1067fe60f*/
    }
  }
LABEL_36:
  if ( *(_DWORD *)(v23 + 18792) != 0 ) /*0x1067fe627*/
  {
    Dangerous_DEPRECATED = RBX::DataModel::getDangerous_DEPRECATED(this: *(this + 51), a2: (RBX::Instance *)v19); /*0x1067fe630*/
    v37 = (RBX::Instance *)(Dangerous_DEPRECATED + 464); /*0x1067fe635*/
    if ( Dangerous_DEPRECATED == 0 ) /*0x1067fe63f*/
      v37 = nullptr; /*0x1067fe63f*/
    RBX::DataModel::scoped_write_request::scoped_write_request( /*0x1067fe64a*/
      this: (RBX::DataModel::scoped_write_request *)&v143,
      a2: v37);
    v38 = (__int64)*(this + 51); /*0x1067fe64f*/
    v39 = *(unsigned int *)(v38 + 18792); /*0x1067fe656*/
    v138[0] = 0; /*0x1067fe665*/
    v140 = 0; /*0x1067fe667*/
    RBX::Network::Replicator::requestDisconnectWithSignal(a1: v38, a2: v39, a3: v138); /*0x1067fe66a*/
    if ( v140 == 1 && (v138[16] & 1) != 0 ) /*0x1067fe683*/
      operator delete(a1: (RBX::Memory *)v139, a2: v40); /*0x1067fe690*/
LABEL_207:
    RBX::DataModel::scoped_write_request::~scoped_write_request(this: (RBX::DataModel::scoped_write_request *)&v143); /*0x1067ff294*/
    goto LABEL_208; /*0x1067ff29b*/
  }
  (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*(this + 51) + 784LL))(a1: *(this + 51)); /*0x1067fe6a4*/
  if ( RBX::Network::Replicator::incomingPacketsCount(this: *(this + 51)) != 0 )
  {
    v19 = *(this + 51); /*0x1067fe6bf*/
    if ( v19 != nullptr )
    {
      if ( (unsigned __int8)FLog::NetworkStepsMultipliers >= 6u && BYTE1(FLog::NetworkStepsMultipliers) >= 3u ) /*0x1067fe6e7*/
      {
        FLog::FastLog( /*0x1067fe6fb*/
          a1: FLog::NetworkStepsMultipliers,
          a2: qword_10D80D218,
          a3: "[FLog::NetworkStepsMultipliers] ProcessPacketsJob running",
          0);
        v19 = *(this + 51); /*0x1067fe700*/
      }
      v155 = v4; /*0x1067fe70e*/
      RBX::DataModel::scoped_write_request::scoped_write_request( /*0x1067fe712*/
        this: (RBX::DataModel::scoped_write_request *)&v143,
        a2: (RBX::Instance *)v19);
      v150 = 0.0; /*0x1067fe71b*/
      if ( DFFlag::ClientPacketLimiting == 1 ) /*0x1067fe727*/
      {
        RBX::Network::Replicator::incomingPacketsCountHeadWaitTimeSec(this: *(this + 51), (const RBX::Time *)a2); /*0x1067fe737*/
        v150 = v41; /*0x1067fe73c*/
        v42 = (__int64)*(this + 51); /*0x1067fe748*/
        if ( FFlag::RefactorIngressFlow == 1 ) /*0x1067fe752*/
          hasUnprocessedData = RBX::Network::ProcessingPacketV2::hasUnprocessedData(this: (RBX::Network::ProcessingPacketV2 *)(v42 + 11440)); /*0x1067fe75b*/
        else
          hasUnprocessedData = RBX::Network::ProcessingPacket::hasUnprocessedData(this: (RBX::Network::ProcessingPacket *)(v42 + 11320)); /*0x1067fe7c2*/
        if ( hasUnprocessedData != 0 ) /*0x1067fe7c9*/
          v46 = *((double *)a2 + 1) + *((double *)this + 92); /*0x1067fe7d1*/
        else
          v46 = v150; /*0x1067fe7dc*/
        *((double *)this + 92) = v46; /*0x1067fe7e1*/
      }
      v151.f64[0] = RBX::Network::Replicator::ProcessPacketsJob::processTimeInterval( /*0x1067fe7f5*/
                      (RBX::DataModelJob *)this,
                      (__int64)a2);
      if ( DFFlag::ClientPacketLimiting == 1 ) /*0x1067fe801*/
      {
        v154 = *(double *)a2; /*0x1067fe808*/
        *((_BYTE *)this + 745) = 0; /*0x1067fe80d*/
        v48 = *(_QWORD *)&v151.f64[0]; /*0x1067fe824*/
        if ( *((_BYTE *)this + 746) == 0 ) /*0x1067fe829*/
          v48 = 0x7FEFFFFFFFFFFFFFLL; /*0x1067fe82b*/
        *((_QWORD *)*(this + 51) + 1559) = v48; /*0x1067fe833*/
      }
      else
      {
        v154 = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: v47); /*0x1067fe842*/
      }
      v49 = FLog::NetworkStepsMultipliers; /*0x1067fe84e*/
      v50 = (unsigned __int8)FLog::NetworkStepsMultipliers >= 6u && BYTE1(FLog::NetworkStepsMultipliers) >= 3u; /*0x1067fe862*/
      if ( FFlag::RefactorIngressFlow == 1 )
      {
        if ( v50 )
        {
          v51 = qword_10D80D218; /*0x1067fe873*/
          v52 = (__int64)*(this + 51); /*0x1067fe877*/
          v53 = *(_BYTE *)(v52 + 15224); /*0x1067fe87e*/
          v54 = (char *)(v52 + 18880); /*0x1067fe884*/
          v55 = 1; /*0x1067fe899*/
          if ( DFInt::SpinMutexAttemptsBeforeYield >= 2 ) /*0x1067fe89f*/
            v55 = DFInt::SpinMutexAttemptsBeforeYield; /*0x1067fe89f*/
          v56 = 0; /*0x1067fe8a6*/
          while ( 1 ) /*0x1067fe8ac*/
          {
            v57 = *v54; /*0x1067fe8ac*/
            *v54 = 1; /*0x1067fe8ac*/
            if ( (v57 & 1) == 0 ) /*0x1067fe8b3*/
              break; /*0x1067fe8b3*/
            if ( ++v56 == v55 ) /*0x1067fe8bb*/
              v56 = 0; /*0x1067fe8bb*/
          }
          v63 = (__int64 *)(v52 + 18872); /*0x1067fe91a*/
LABEL_83:
          v64 = *v63; /*0x1067fe927*/
          *v54 = 0; /*0x1067fe92a*/
          FLog::FastLog(
            a1: v49,
            a2: v51,
            a3: "[FLog::NetworkStepsMultipliers] ProcessPacketsJob: StepOnce, processAllPackets: %d, packets in Queue: %d",
            v53,
            v64);
        }
      }
      else if ( v50 ) /*0x1067fe8c3*/
      {
        v51 = qword_10D80D218; /*0x1067fe8c5*/
        v58 = (__int64)*(this + 51); /*0x1067fe8c9*/
        v53 = *(_BYTE *)(v58 + 15224); /*0x1067fe8d0*/
        v59 = v58 + 18800; /*0x1067fe8d6*/
        v54 = (char *)(v58 + 18832); /*0x1067fe8dd*/
        v60 = 1; /*0x1067fe8f2*/
        if ( DFInt::SpinMutexAttemptsBeforeYield >= 2 ) /*0x1067fe8f8*/
          v60 = DFInt::SpinMutexAttemptsBeforeYield; /*0x1067fe8f8*/
        v61 = 0; /*0x1067fe8ff*/
        while ( 1 ) /*0x1067fe905*/
        {
          v62 = *v54; /*0x1067fe905*/
          *v54 = 1; /*0x1067fe905*/
          if ( (v62 & 1) == 0 ) /*0x1067fe90c*/
            break; /*0x1067fe90c*/
          if ( ++v61 == v60 ) /*0x1067fe914*/
            v61 = 0; /*0x1067fe914*/
        }
        v63 = (__int64 *)(v59 + 24); /*0x1067fe923*/
        goto LABEL_83; /*0x1067fe923*/
      }
      if ( *((_BYTE *)*(this + 51) + 18702) == 1 ) /*0x1067fe94d*/
      {
        v66 = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: v49); /*0x1067fe94f*/
        v67 = 488; /*0x1067fe954*/
      }
      else
      {
        v66 = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: v49); /*0x1067fe95b*/
        v67 = 484; /*0x1067fe960*/
      }
      *((double *)this + 62) = (double)*(int *)((char *)this + v67) * 0.001 + v66; /*0x1067fe977*/
      v145 = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: v65); /*0x1067fe985*/
      if ( DFFlag::ClientPacketLimiting == 0 ) /*0x1067fe994*/
      {
        RBX::Network::Replicator::incomingPacketsCountHeadWaitTimeSec(this: *(this + 51), a2: (const RBX::Time *)&v145); /*0x1067fe9a4*/
        v150 = v68; /*0x1067fe9a9*/
      }
      v69 = *(this + 51); /*0x1067fe9ae*/
      v70 = v69[1567]; /*0x1067fe9b5*/
      v153 = (*(__int64 (__fastcall **)(_QWORD *))(*v69 + 1048LL))(a1: v69); /*0x1067fe9c5*/
      if ( *((double *)this + 67) == 0.0 ) /*0x1067fe9d9*/
      {
        v72 = (__int64)*(this + 51); /*0x1067fe9e5*/
        if ( FFlag::RefactorIngressFlow == 1 ) /*0x1067fe9f1*/
        {
          v73 = (char *)(v72 + 18880); /*0x1067fe9f3*/
          v74 = 1; /*0x1067fea06*/
          if ( DFInt::SpinMutexAttemptsBeforeYield >= 2 ) /*0x1067fea0b*/
            v74 = DFInt::SpinMutexAttemptsBeforeYield; /*0x1067fea0b*/
          v71 = 0; /*0x1067fea10*/
          while ( 1 ) /*0x1067fea15*/
          {
            v75 = *v73; /*0x1067fea15*/
            *v73 = 1; /*0x1067fea15*/
            if ( (v75 & 1) == 0 ) /*0x1067fea1c*/
              break; /*0x1067fea1c*/
            v71 = (unsigned int)(v71 + 1); /*0x1067fea1e*/
            if ( (_DWORD)v71 == v74 ) /*0x1067fea22*/
              v71 = 0; /*0x1067fea22*/
          }
          v80 = (_QWORD *)(v72 + 18872); /*0x1067fea67*/
        }
        else
        {
          v76 = v72 + 18800; /*0x1067fea27*/
          v77 = (char *)(v72 + 18832); /*0x1067fea2e*/
          v78 = 1; /*0x1067fea40*/
          if ( DFInt::SpinMutexAttemptsBeforeYield >= 2 ) /*0x1067fea45*/
            v78 = DFInt::SpinMutexAttemptsBeforeYield; /*0x1067fea45*/
          v71 = 0; /*0x1067fea4a*/
          while ( 1 ) /*0x1067fea4f*/
          {
            v79 = *v77; /*0x1067fea4f*/
            *v77 = 1; /*0x1067fea4f*/
            if ( (v79 & 1) == 0 ) /*0x1067fea56*/
              break; /*0x1067fea56*/
            v71 = (unsigned int)(v71 + 1); /*0x1067fea58*/
            if ( (_DWORD)v71 == v78 ) /*0x1067fea5c*/
              v71 = 0; /*0x1067fea5c*/
          }
          v80 = (_QWORD *)(v76 + 24); /*0x1067fea6c*/
          v73 = v77; /*0x1067fea70*/
        }
        v81 = *v80 == 0; /*0x1067fea73*/
        *v73 = 0; /*0x1067fea77*/
        if ( !v81 ) /*0x1067fea7a*/
          *((double *)this + 67) = RBX::Time::now<(RBX::Time::SampleMethod)2>(a1: v71); /*0x1067fea81*/
      }
      v82 = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: v71); /*0x1067fea8a*/
      v151.f64[0] = v151.f64[0] + v154; /*0x1067fea99*/
      v141 = v82; /*0x1067feaa5*/
      v148 = (int *)(this + 60); /*0x1067feab2*/
      v83 = 0.0; /*0x1067feabe*/
      v147 = (__m128d)0xBFF0000000000000LL; /*0x1067feac1*/
      v146 = -1.0; /*0x1067feac9*/
      while ( 1 ) /*0x1067fead1*/
      {
        v154 = v83; /*0x1067fead1*/
        if ( (unsigned __int8)RBX::DataModel::getIsShuttingDown(this: *(this + 57)) != 0 /*0x1067feafa*/
          || (unsigned __int8)RBX::Network::Replicator::processNextIncomingPacket(this: *(this + 51)) == 0 )
        {
          break; /*0x1067feafa*/
        }
        if ( DFFlag::ClientPacketLimiting == 1 ) /*0x1067feb07*/
        {
          RBX::Network::Replicator::incomingPacketsCountHeadWaitTimeSec(this: *(this + 51), (const RBX::Time *)a2); /*0x1067feb13*/
          *(this + 92) = v85; /*0x1067feb18*/
        }
        v86 = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: v84); /*0x1067feb21*/
        *(_QWORD *)&v83 = *(_QWORD *)&v154 + 1LL; /*0x1067feb2a*/
        v152 = v86; /*0x1067feb2e*/
        v84 = (int *)*(this + 51); /*0x1067feb33*/
        if ( *((_BYTE *)v84 + 15224) == 1 ) /*0x1067feb41*/
        {
          if ( *((int *)this + 121) > 0 ) /*0x1067feb4b*/
          {
            v87 = *((double *)this + 62); /*0x1067feb4d*/
            if ( v86 > v87 ) /*0x1067feb5a*/
            {
              v98 = (v86 - v87) * 1000.0; /*0x1067fed1b*/
              *((double *)v84 + 1976) = *((double *)v84 + 1976) + v98; /*0x1067fed2f*/
              *((double *)v84 + 1977) = fmax(v98, *((double *)v84 + 1977)); /*0x1067fed3f*/
              v84 += 3956; /*0x1067fed47*/
              v99 = 1; /*0x1067fed4e*/
LABEL_142:
              *v84 += v99; /*0x1067fed53*/
LABEL_143:
              ++*(_QWORD *)&v154; /*0x1067fed55*/
              break; /*0x1067fed55*/
            }
          }
        }
        else if ( v86 <= v151.f64[0] ) /*0x1067feb6a*/
        {
          if ( *((int *)this + 122) > 0 && v86 > *((double *)this + 62) ) /*0x1067febb7*/
            goto LABEL_143; /*0x1067febb7*/
        }
        else
        {
          if ( DFFlag::ClientPacketLimiting == 1 ) /*0x1067feb73*/
          {
            if ( v84[69] == 0 && *((_BYTE *)v84 + 18702) == 1 && *((_BYTE *)this + 746) != 0 ) /*0x1067feb8f*/
              goto LABEL_143; /*0x1067feb8f*/
            v88 = *((double *)this + 92); /*0x1067feb95*/
          }
          else
          {
            RBX::Network::Replicator::incomingPacketsCountHeadWaitTimeSec( /*0x1067febc5*/
              this: (RBX::Network::Replicator *)v84,
              (const RBX::Time *)a2);
          }
          if ( (float)((float)DFInt::MaxWaitTimeBeforeForcePacketProcessMS / 1000.0) >= v88 ) /*0x1067febe5*/
            goto LABEL_143; /*0x1067febe5*/
          v149 = v152 - v145; /*0x1067febf8*/
          if ( v152 - v145 > 0.2 ) /*0x1067fec05*/
          {
            v89 = *(this + 51); /*0x1067fec0b*/
            if ( *((_DWORD *)v89 + 69) == 1 ) /*0x1067fec19*/
            {
              RBX::Network::Replicator::incomingPacketsCountHeadWaitTimeSec(this: v89, a2: (const RBX::Time *)&v152); /*0x1067fec23*/
              v147.f64[0] = v90; /*0x1067fec28*/
              v91 = RBX::Network::Replicator::incomingPacketsCount(this: *(this + 51)); /*0x1067fec37*/
              v92 = _mm_loadl_epi64((const __m128i *)&xmmword_108F2F9A0); /*0x1067fec41*/
              v93 = _mm_sub_pd( /*0x1067fec55*/
                      (__m128d)_mm_unpacklo_epi32((__m128i)*(unsigned __int64 *)&v83, v92),
                      (__m128d)xmmword_108F2F9B0);
              v94 = v150 - v147.f64[0]; /*0x1067fec62*/
              v95 = _mm_sub_pd( /*0x1067fec73*/
                      (__m128d)_mm_unpacklo_epi32((__m128i)(unsigned __int64)v91, v92),
                      (__m128d)xmmword_108F2F9B0);
              v96 = _mm_hadd_pd(v95, v95); /*0x1067fec77*/
              v96.f64[0] = v96.f64[0] * (v149 / _mm_hadd_pd(v93, v93).f64[0]); /*0x1067fec84*/
              v147 = v96; /*0x1067fec88*/
              v146 = v94; /*0x1067fec93*/
              if ( v70 != 0 ) /*0x1067fec9b*/
              {
                if ( (double)DFInt::PpjPmThreshold / 100.0 <= v94 || DFInt::PpjPmFill <= 0 ) /*0x1067fecbe*/
                {
                  v97 = 0; /*0x1067fecca*/
                }
                else
                {
                  *v148 += DFInt::PpjPmFill; /*0x1067fecc4*/
                  v97 = 1; /*0x1067fecc6*/
                }
                v99 = DFInt::PpjEtrFill; /*0x1067fece6*/
                if ( DFInt::PpjEtrFill > 0 && v147.f64[0] > (double)DFInt::PpjEtrThreshold ) /*0x1067fece3*/
                {
                  v84 = v148; /*0x1067ff2c3*/
                  goto LABEL_142; /*0x1067ff2c7*/
                }
              }
              else
              {
                v97 = 0; /*0x1067fecfc*/
              }
              if ( v149 > 0.3 || v97 != 0 ) /*0x1067fed0f*/
                goto LABEL_143; /*0x1067fed0f*/
            }
          }
        }
      }
      if ( (FFlag::DebugHashTableMetrics != 0 /*0x1067fed93*/
         || (FFlag::SAuthWorkspaceFlagged & 1) != 0
         || FFlag::NextGenReplicatorEnabledRead == 1)
        && *(_QWORD *)(*((_QWORD *)*(this + 51) + 1801) + 920LL) != 0 )
      {
        while ( (unsigned __int8)RBX::Network::Replicator::processNextPendingIsrPacket(this: *(this + 51)) != 0 ) /*0x1067feda3*/
          ; /*0x1067fed95*/
      }
      v100 = (__int64)*(this + 51); /*0x1067feda5*/
      if ( *(_DWORD *)(v100 + 276) == 0 ) /*0x1067fedb5*/
      {
        v101 = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: v84); /*0x1067fedb7*/
        RBX::TotalCountTimeInterval<double,(RBX::Time::SampleMethod)1>::increment(a1: v100 + 15128, a2: v101 - v141); /*0x1067fedce*/
      }
      if ( DFFlag::ClientPacketLimiting != 1 ) /*0x1067fedda*/
        goto LABEL_172; /*0x1067fedda*/
      v102 = (__int64)*(this + 51); /*0x1067fede0*/
      if ( *(_DWORD *)(v102 + 276) != 0 || *(_BYTE *)(v102 + 18702) != 1 ) /*0x1067fedfb*/
        goto LABEL_172; /*0x1067fedfb*/
      v151.f64[0] = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: v84); /*0x1067fee06*/
      v103 = RBX::Network::Replicator::packetProcessingStats(this: *(this + 51)); /*0x1067fee17*/
      v104 = *((double *)this + 74); /*0x1067fee2f*/
      v105 = (float)((float)DFInt::ClientPacketHealthyAllocationPercent / 100.0) * v104; /*0x1067fee53*/
      v106 = fmaxf((float)DFInt::ClientPacketMinMicroseconds, v105) * 0.000001; /*0x1067fee62*/
      v151.f64[0] = v151.f64[0] - *(double *)a2; /*0x1067fee72*/
      *(double *)(v103 + 120) = v151.f64[0] * 1000.0; /*0x1067fee7f*/
      v150 = v106; /*0x1067fee84*/
      *(double *)(v103 + 136) = v106 * 1000.0; /*0x1067fee91*/
      *(double *)(v103 + 128) = v104 / 1000.0; /*0x1067fee9d*/
      *(_BYTE *)(v103 + 144) = *((_BYTE *)this + 746); /*0x1067feeac*/
      v149 = (double)DFInt::ClientPacketExcessMicroseconds; /*0x1067feebf*/
      v142 = *((double *)this + 92); /*0x1067feecd*/
      v108 = RBX::CoreNetworkSettings::singleton(this: v107); /*0x1067feed5*/
      v113 = (v151.f64[0] - v150) * 1000.0 * 1000.0; /*0x1067feef0*/
      v114 = v142 <= *(double *)(v108 + 112); /*0x1067feefc*/
      *((_BYTE *)this + 744) = v142 > *(double *)(v108 + 112); /*0x1067fef01*/
      v151.f64[0] = v113; /*0x1067fef09*/
      if ( v114 )
      {
        if ( v113 <= v149 )
        {
LABEL_168:
          if ( *((_BYTE *)this + 746) == 1 && *((_BYTE *)this + 745) == 1 && v151.f64[0] <= v149 ) /*0x1067fefff*/
            ++*(_DWORD *)(v103 + 8); /*0x1067ff001*/
LABEL_172:
          v120 = (__int64)*(this + 51); /*0x1067ff006*/
          v121 = *(_QWORD *)(v120 + 18672); /*0x1067ff00d*/
          if ( (int)((unsigned __int64)(*(_QWORD *)(v120 + 18680) - v121) >> 2) > 0 )
          {
            v122 = 0; /*0x1067ff038*/
            do
            {
              if ( *(_DWORD *)(v121 + 4 * v122) != 0 )
              {
                if ( DFFlag::DebugEnablePerReplicatorMPProfiles == 1 )
                {
                  if ( (_BYTE)`guard variable for'RBX::Network::Replicator::ProcessPacketsJob::stepDataModelJob(RBX::TaskScheduler::Job::Stats const&)::proflabeltoken == 0 /*0x1067ff0c3*/
                    && __cxa_guard_acquire(a1: &`guard variable for'RBX::Network::Replicator::ProcessPacketsJob::stepDataModelJob(RBX::TaskScheduler::Job::Stats const&)::proflabeltoken) != 0 )
                  {
                    v152 = COERCE_DOUBLE("rationType"); /*0x1067ff0cc*/
                    RBX::Network::Replicator::ProcessPacketsJob::stepDataModelJob(RBX::TaskScheduler::Job::Stats const&)::proflabeltoken = RBX::Profiler::getLabelToken(this: (RBX::Profiler *)&aUnsupportedOpe_1[-1042438], a2: v127); /*0x1067ff0e3*/
                    __cxa_guard_release(a1: &`guard variable for'RBX::Network::Replicator::ProcessPacketsJob::stepDataModelJob(RBX::TaskScheduler::Job::Stats const&)::proflabeltoken); /*0x1067ff0f1*/
                  }
                  v123 = RBX::Network::Replicator::ProcessPacketsJob::stepDataModelJob(RBX::TaskScheduler::Job::Stats const&)::proflabeltoken; /*0x1067ff053*/
                  v124 = (unsigned int)RBX::Network::convertExtendedAnalyticsItemTypeToString(a1: v122); /*0x1067ff05d*/
                  RBX::Profiler::addLabelFormat(
                    a1: v123,
                    a2: (unsigned int)"%s : %d",
                    a3: v124,
                    a4: *(_DWORD *)(*((_QWORD *)*(this + 51) + 2334) + 4 * v122),
                    a5: v125,
                    a6: v126);
                  v120 = (__int64)*(this + 51); /*0x1067ff084*/
                }
                v121 = *(_QWORD *)(v120 + 18672); /*0x1067ff08b*/
                *(_DWORD *)(v121 + 4 * v122) = 0; /*0x1067ff092*/
              }
              ++v122; /*0x1067ff09a*/
            }
            while ( v122 < (int)((unsigned __int64)(*(_QWORD *)(v120 + 18680) - v121) >> 2) );
          }
          if ( DFFlag::ClientPacketLimiting != 0 ) /*0x1067ff102*/
            *(_DWORD *)(v120 + 18696) = 0; /*0x1067ff104*/
          v128 = 0; /*0x1067ff11a*/
          if ( *v148 - DFInt::PpjLeak > 0 ) /*0x1067ff11e*/
            v128 = *v148 - DFInt::PpjLeak; /*0x1067ff11e*/
          *v148 = v128; /*0x1067ff121*/
          v81 = ((v128 <= DFInt::PpjCapacity) | v153) == 0; /*0x1067ff12c*/
          v153 |= v128 <= DFInt::PpjCapacity; /*0x1067ff12c*/
          v4 = v155; /*0x1067ff12f*/
          if ( v81 ) /*0x1067ff133*/
          {
            (*(void (__fastcall **)(__int64, double, double, double))(*(_QWORD *)v120 + 1512LL))( /*0x1067ff14c*/
              a1: v120,
              a2: COERCE_DOUBLE(*(_QWORD *)&v154),
              a3: v146,
              a4: v147.f64[0]);
            v120 = (__int64)*(this + 51); /*0x1067ff152*/
          }
          if ( DFFlag::DebugNetworkProfiler == 1 /*0x1067ff18c*/
            && *(_BYTE *)(v120 + 15568) == 1
            && (DFFlag::DebugNetworkProfilerReplicator != 0 || DFFlag::DebugNetworkProfilerDeserialize == 1) )
          {
            Workspace = (RBX::WorldRoot *)RBX::DataModelProp::getWorkspace(this: (RBX::Network::Replicator *)((char *)*(this + 57) + 720)); /*0x1067ff19e*/
            if ( Workspace != nullptr ) /*0x1067ff1a6*/
              WorldStepId = RBX::WorldRoot::getWorldStepId(this: Workspace); /*0x1067ff1b0*/
            else
              WorldStepId = 0; /*0x1067ff1b5*/
            RemoteWorldStepId = 0; /*0x1067ff1c4*/
            v132 = (RBX::AuroraService *)RBX::ServiceProvider::find<RBX::AuroraService>(this: (RBX::Network::Replicator *)((char *)*(this + 57) + 464)); /*0x1067ff1c9*/
            if ( v132 != nullptr ) /*0x1067ff1d1*/
              RemoteWorldStepId = RBX::AuroraService::getRemoteWorldStepId(this: v132); /*0x1067ff1db*/
            *((_DWORD *)*(this + 51) + 4594) = WorldStepId; /*0x1067ff1e5*/
            *((_DWORD *)*(this + 51) + 4595) = RemoteWorldStepId; /*0x1067ff1f3*/
            v120 = (__int64)*(this + 51); /*0x1067ff1fa*/
            if ( DFFlag::DebugNetworkProfilerReplicator == 1 ) /*0x1067ff204*/
            {
              hasData = RBX::NetworkProfiler::CapturePackets::hasData(this: (RBX::NetworkProfiler::CapturePackets *)(v120 + 16296)); /*0x1067ff20d*/
              v120 = (__int64)*(this + 51); /*0x1067ff212*/
              if ( hasData != 0 ) /*0x1067ff21b*/
              {
                v134 = "C:RepRecv"; /*0x1067ff22b*/
                if ( *(_DWORD *)(v120 + 276) == 1 ) /*0x1067ff232*/
                  v134 = "S:RepRecv"; /*0x1067ff232*/
                RBX::NetworkProfiler::CapturePackets::flush( /*0x1067ff249*/
                  this: (RBX::NetworkProfiler::CapturePackets *)(v120 + 16296),
                  a2: v134,
                  a3: *(_DWORD *)(v120 + 16288),
                  a4: WorldStepId,
                  a5: RemoteWorldStepId);
                v120 = (__int64)*(this + 51); /*0x1067ff24e*/
              }
            }
          }
          (*(void (__fastcall **)(__int64))(*(_QWORD *)v120 + 768LL))(a1: v120); /*0x1067ff258*/
          if ( (*((_BYTE *)*(this + 51) + 15729) & 1) != 0 ) /*0x1067ff26d*/
            ++*((_DWORD *)*(this + 51) + 3963); /*0x1067ff276*/
          if ( (unsigned __int8)rbx::signals::connection::connected(this: (rbx::signals::connection *)(this + 68)) != 0 ) /*0x1067ff28a*/
            RBX::Network::Replicator::ProcessPacketsJob::accumulateJoinCppAndLuaTime((RBX::Network::Replicator::ProcessPacketsJob *)this); /*0x1067ff28f*/
          goto LABEL_207; /*0x1067ff28f*/
        }
      }
      else
      {
        ++*(_DWORD *)v103; /*0x1067fef10*/
        if ( v113 <= v149 ) /*0x1067fef19*/
          goto LABEL_159; /*0x1067fef19*/
      }
      ++*(_DWORD *)(v103 + 4); /*0x1067fef28*/
LABEL_159:
      if ( DFFlag::DebugCLientPacketLimitingLabels == 1 ) /*0x1067fef34*/
      {
        if ( (_BYTE)`guard variable for'RBX::Network::Replicator::ProcessPacketsJob::stepDataModelJob(RBX::TaskScheduler::Job::Stats const&)::proflabeltoken == 0 /*0x1067ff2da*/
          && __cxa_guard_acquire(a1: &`guard variable for'RBX::Network::Replicator::ProcessPacketsJob::stepDataModelJob(RBX::TaskScheduler::Job::Stats const&)::proflabeltoken) != 0 )
        {
          v152 = COERCE_DOUBLE("e is supported."); /*0x1067ff2e7*/
          RBX::Network::Replicator::ProcessPacketsJob::stepDataModelJob(RBX::TaskScheduler::Job::Stats const&)::proflabeltoken = RBX::Profiler::getLabelToken(this: (RBX::Profiler *)&aSOnlyDataChann[-741624], a2: v136); /*0x1067ff2fb*/
          __cxa_guard_release(a1: &`guard variable for'RBX::Network::Replicator::ProcessPacketsJob::stepDataModelJob(RBX::TaskScheduler::Job::Stats const&)::proflabeltoken); /*0x1067ff309*/
        }
        RBX::Profiler::addLabelFormat( /*0x1067fef54*/
          a1: RBX::Network::Replicator::ProcessPacketsJob::stepDataModelJob(RBX::TaskScheduler::Job::Stats const&)::proflabeltoken,
          a2: (unsigned int)"Missed Frame Deadline",
          a3: v109,
          a4: v110,
          a5: v111,
          a6: v112);
        if ( *((_BYTE *)this + 744) == 1 ) /*0x1067fef61*/
        {
          if ( (_BYTE)`guard variable for'RBX::Network::Replicator::ProcessPacketsJob::stepDataModelJob(RBX::TaskScheduler::Job::Stats const&)::proflabeltoken == 0 /*0x1067ff321*/
            && __cxa_guard_acquire(a1: &`guard variable for'RBX::Network::Replicator::ProcessPacketsJob::stepDataModelJob(RBX::TaskScheduler::Job::Stats const&)::proflabeltoken) != 0 )
          {
            v152 = COERCE_DOUBLE("M not locked in findPluginGuiById"); /*0x1067ff32e*/
            RBX::Network::Replicator::ProcessPacketsJob::stepDataModelJob(RBX::TaskScheduler::Job::Stats const&)::proflabeltoken = RBX::Profiler::getLabelToken(this: (RBX::Profiler *)&aDmNotLockedInF[-1024483], a2: v137); /*0x1067ff342*/
            __cxa_guard_release(a1: &`guard variable for'RBX::Network::Replicator::ProcessPacketsJob::stepDataModelJob(RBX::TaskScheduler::Job::Stats const&)::proflabeltoken); /*0x1067ff350*/
          }
          RBX::Profiler::addLabelFormat( /*0x1067fef81*/
            a1: RBX::Network::Replicator::ProcessPacketsJob::stepDataModelJob(RBX::TaskScheduler::Job::Stats const&)::proflabeltoken,
            a2: (unsigned int)"Delayed Packets",
            a3: v115,
            a4: v116,
            a5: v117,
            a6: v118);
        }
      }
      *((_BYTE *)this + 745) = 1; /*0x1067fef86*/
      RBX::RunningAverage<float,double>::sample( /*0x1067fefa5*/
        a1: v103 + 80,
        a2: COERCE_DOUBLE((unsigned __int64)COERCE_UNSIGNED_INT((float)*((int *)*(this + 51) + 4674))));
      if ( v154 < 0.0 ) /*0x1067fefb8*/
        v119 = (float)(int)((*(_QWORD *)&v154 >> 1) | LOBYTE(v154) & 1) /*0x1067fefd8*/
             + (float)(int)((*(_QWORD *)&v154 >> 1) | LOBYTE(v154) & 1);
      else
        v119 = (float)SLODWORD(v154); /*0x1067fefbd*/
      RBX::RunningAverage<float,double>::sample(a1: v103 + 40, a2: COERCE_DOUBLE((unsigned __int64)LODWORD(v119))); /*0x1067fefdc*/
      goto LABEL_168; /*0x1067fefdc*/
    }
    v44 = 0; /*0x1067fe7b3*/
  }
  else
  {
    v44 = 1; /*0x1067fe762*/
    if ( DFFlag::ClientPacketLimiting == 1 ) /*0x1067fe76f*/
    {
      v45 = (__int64)*(this + 51); /*0x1067fe775*/
      if ( *(_DWORD *)(v45 + 276) == 0 && *(_BYTE *)(v45 + 18702) == 1 ) /*0x1067fe790*/
        *((double *)this + 91) = *((double *)a2 + 1) + *((double *)this + 91); /*0x1067fe7a5*/
    }
  }
LABEL_209:
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v4, a2: (unsigned int)v19); /*0x1067ff2a6*/
  return v44; /*0x1067ff2b1*/
}

// Address: 0x1067ff446 | Name: __ZN3RBX7Network10Replicator17ProcessPacketsJob27accumulateJoinCppAndLuaTimeEv
__int64 __fastcall RBX::Network::Replicator::ProcessPacketsJob::accumulateJoinCppAndLuaTime(
        RBX::Network::Replicator::ProcessPacketsJob *this)
{
  __int128 v2; // xmm0
  RBX::ScriptContext *v3; // rax
  RBX::ScriptContext *v4; // r14
  double v5; // xmm0_8
  __m128d v6; // xmm0
  __m128d v7; // xmm2
  __int64 result; // rax
  __int128 v9; // [rsp+0h] [rbp-30h]
  double v10; // [rsp+10h] [rbp-20h]
  double v11; // [rsp+18h] [rbp-18h]

  *(double *)&v2 = RBX::Time::now<(RBX::Time::SampleMethod)2>(a1: this); /*0x1067ff454*/
  v9 = v2; /*0x1067ff459*/
  v10 = *((double *)this + 66); /*0x1067ff465*/
  v3 = (RBX::ScriptContext *)RBX::ServiceProvider::find<RBX::ScriptContext>(a1: *((_QWORD *)this + 57) + 464LL, a2: 0); /*0x1067ff478*/
  if ( v3 != nullptr ) /*0x1067ff480*/
  {
    v4 = v3; /*0x1067ff482*/
    RBX::ScriptContext::getLuaTimeThisFrame(this: v3); /*0x1067ff488*/
    v11 = v5; /*0x1067ff48d*/
    RBX::ScriptContext::getLuaGcTimeThisFrame(this: v4); /*0x1067ff495*/
    v6.f64[0] = v6.f64[0] + v11 - *((double *)this + 65); /*0x1067ff49f*/
    *((double *)this + 63) = *((double *)this + 63) + v6.f64[0]; /*0x1067ff4b3*/
  }
  else
  {
    v6 = 0; /*0x1067ff4bd*/
  }
  v7.f64[1] = *((double *)&v9 + 1); /*0x1067ff4c1*/
  v7.f64[0] = (*(double *)&v9 - v10) * 1000.0 - v6.f64[0]; /*0x1067ff4d3*/
  *((double *)this + 64) = *((double *)this + 64) + v7.f64[0]; /*0x1067ff4e3*/
  result = *((_QWORD *)this + 51); /*0x1067ff4eb*/
  *(__m128d *)(result + 15880) = _mm_max_pd(_mm_unpacklo_pd(v7, v6), *(__m128d *)(result + 15880)); /*0x1067ff502*/
  return result; /*0x1067ff50a*/
}

// Address: 0x1067ff514 | Name: __ZNK3RBX7Network10Replicator17ProcessPacketsJob30joinProcessingTimeLimitReachedEv
bool __fastcall RBX::Network::Replicator::ProcessPacketsJob::joinProcessingTimeLimitReached(
        RBX::Network::Replicator::ProcessPacketsJob *this)
{
  return *((int *)this + 121) > 0 && RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: this) > *((double *)this + 62); /*0x1067ff53c*/
}

// Address: 0x1067ff540 | Name: __ZN3RBX7Network10Replicator17ProcessPacketsJobD1Ev
void __fastcall RBX::Network::Replicator::ProcessPacketsJob::~ProcessPacketsJob(
        RBX::Network::Replicator::ProcessPacketsJob *this,
        void *a2)
{
  void *v3; // rsi

  *(_QWORD *)this = &off_10CAACFC8; /*0x1067ff550*/
  RBX::unique_function<RBX::Time ()(void),24ul,8ul,true>::~unique_function(a1: (__int64)this + 696, a2); /*0x1067ff55a*/
  RBX::unique_function<RBX::Time ()(void),24ul,8ul,true>::~unique_function(a1: (__int64)this + 640, a2: v3); /*0x1067ff566*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::Network::Replicator::ProcessPacketsJob *)((char *)this + 544)); /*0x1067ff572*/
  RBX::CEvent::~CEvent(this: (RBX::Network::Replicator::ProcessPacketsJob *)((char *)this + 432)); /*0x1067ff57e*/
  *(_QWORD *)this = &off_10CAB2260; /*0x1067ff58a*/
  std::shared_ptr<RBX::Network::Replicator>::~shared_ptr[abi:ne200100](a1: (char *)this + 408); /*0x1067ff594*/
  RBX::TaskScheduler::Job::~Job(this); /*0x1067ff5a2*/
}

// Address: 0x1067ff5a8 | Name: __ZN3RBX7Network10Replicator17ProcessPacketsJobD0Ev
void __fastcall RBX::Network::Replicator::ProcessPacketsJob::~ProcessPacketsJob(
        RBX::Network::Replicator::ProcessPacketsJob *this,
        void *a2)
{
  void *v3; // rsi
  void *v4; // rsi

  *(_QWORD *)this = &off_10CAACFC8; /*0x1067ff5b8*/
  RBX::unique_function<RBX::Time ()(void),24ul,8ul,true>::~unique_function(a1: (__int64)this + 696, a2); /*0x1067ff5c2*/
  RBX::unique_function<RBX::Time ()(void),24ul,8ul,true>::~unique_function(a1: (__int64)this + 640, a2: v3); /*0x1067ff5ce*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::Network::Replicator::ProcessPacketsJob *)((char *)this + 544)); /*0x1067ff5da*/
  RBX::CEvent::~CEvent(this: (RBX::Network::Replicator::ProcessPacketsJob *)((char *)this + 432)); /*0x1067ff5e6*/
  *(_QWORD *)this = &off_10CAB2260; /*0x1067ff5f2*/
  std::shared_ptr<RBX::Network::Replicator>::~shared_ptr[abi:ne200100](a1: (char *)this + 408); /*0x1067ff5fc*/
  RBX::TaskScheduler::Job::~Job(this); /*0x1067ff604*/
  operator delete(a1: this, a2: v4); /*0x1067ff612*/
}

// Address: 0x108766f55 | Name: __ZN3RBX7Network10Replicator17ProcessPacketsJob16stepDataModelJobERKNS_13TaskScheduler3Job5StatsE.cold.1
void __fastcall RBX::Network::Replicator::ProcessPacketsJob::stepDataModelJob(__int64 a1, void *a2)
{
  if ( (*(_BYTE *)(a1 + 16) & 1) != 0 ) /*0x108766f59*/
    operator delete(a1: *(RBX::Memory **)(a1 + 32), a2); /*0x108766f63*/
}

// END ProcessPacketsJob part 1/1, 12 functions
