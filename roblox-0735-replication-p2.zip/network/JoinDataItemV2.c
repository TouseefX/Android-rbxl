// JoinDataItemV2 -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 16 functions


// Address: 0x1067ed892 | Name: __ZN3RBX7Network10Replicator14JoinDataItemV2C2EPS1_RKNSt3__110shared_ptrIKNS0_29PreserializedReplicationCacheEEEbm
__int64 __fastcall RBX::Network::Replicator::JoinDataItemV2::JoinDataItemV2(
        __int64 a1,
        RBX::Network::Replicator *a2,
        __int64 *a3,
        char a4,
        int a5)
{
  __m128 v9; // xmm0
  __int64 v10; // rax
  __int64 result; // rax

  RBX::Network::Item::Item(this: (RBX::Network::Item *)a1, a2); /*0x1067ed8a9*/
  *(_QWORD *)a1 = off_10CAACB58; /*0x1067ed8b5*/
  v9 = 0; /*0x1067ed8b8*/
  *(_OWORD *)(a1 + 64) = 0; /*0x1067ed8bb*/
  *(_OWORD *)(a1 + 80) = 0; /*0x1067ed8bf*/
  *(_BYTE *)(a1 + 96) = a4; /*0x1067ed8c3*/
  *(_DWORD *)(a1 + 100) = a5; /*0x1067ed8c7*/
  *(_OWORD *)(a1 + 104) = 0; /*0x1067ed8cb*/
  *(_QWORD *)(a1 + 120) = 0; /*0x1067ed8cf*/
  v10 = *a3; /*0x1067ed8d7*/
  if ( *a3 != 0 ) /*0x1067ed8dd*/
    v9 = (__m128)*(unsigned __int64 *)(v10 + 104); /*0x1067ed8df*/
  _mm_storel_ps((double *)(a1 + 128), v9); /*0x1067ed8e4*/
  *(_QWORD *)(a1 + 136) = v10; /*0x1067ed8eb*/
  result = a3[1]; /*0x1067ed8f2*/
  *(_QWORD *)(a1 + 144) = result; /*0x1067ed8f6*/
  if ( result != 0 ) /*0x1067ed900*/
    _InterlockedIncrement64((volatile signed __int64 *)(result + 8)); /*0x1067ed902*/
  *(_OWORD *)(a1 + 152) = 0; /*0x1067ed90a*/
  *(_QWORD *)(a1 + 168) = 0; /*0x1067ed911*/
  return result; /*0x1067ed91c*/
}

// Address: 0x1067ed926 | Name: __ZN3RBX7Network10Replicator14JoinDataItemV2C1EPS1_RKNSt3__110shared_ptrIKNS0_29PreserializedReplicationCacheEEEbm
__int64 __fastcall RBX::Network::Replicator::JoinDataItemV2::JoinDataItemV2(
        __int64 a1,
        RBX::Network::Replicator *a2,
        __int64 *a3,
        char a4,
        int a5)
{
  return RBX::Network::Replicator::JoinDataItemV2::JoinDataItemV2(a1, a2, a3, a4, a5); /*0x1067ed92a*/
}

// Address: 0x1067ed930 | Name: __ZN3RBX7Network10Replicator14JoinDataItemV2D2Ev
void __fastcall RBX::Network::Replicator::JoinDataItemV2::~JoinDataItemV2(
        RBX::Network::Replicator::JoinDataItemV2 *this)
{
  __int64 v1; // rdx
  __int64 v2; // rcx
  void *v3; // rsi
  unsigned __int64 v4; // r15
  int v5; // eax
  int v6; // edx
  double v7; // xmm0_8
  double v8; // xmm0_8
  int v9; // eax
  double v10; // xmm0_8
  int v11; // eax
  double v12; // xmm0_8
  __int64 v13; // rdx
  __int64 v14; // rcx
  int v15; // ecx
  void *v16; // rsi
  int v17; // r8d
  int v18; // r9d
  __int64 v19; // rdx
  __int64 v20; // rcx
  void *v21; // rsi
  int *v22; // rax
  int v23; // r14d
  int v24; // r13d
  int v25; // r12d
  int v26; // ebx
  int v27; // r15d
  __int64 v28; // rdx
  __int64 v29; // rcx
  void *v30; // rsi
  int v31; // edi
  unsigned int v32; // eax
  _DWORD *v33; // rax
  __int64 *i; // r12
  __int64 v35; // rcx
  __int64 v36; // r8
  __int64 v37; // rdx
  __int64 v38; // rcx
  __int64 v39; // rsi
  __int64 v40; // r8
  __int64 v41; // r9
  int v42; // [rsp+0h] [rbp-4B0h]
  int v43; // [rsp+8h] [rbp-4A8h]
  int v44; // [rsp+10h] [rbp-4A0h]
  int v45; // [rsp+18h] [rbp-498h]
  _BYTE v46[16]; // [rsp+20h] [rbp-490h] BYREF
  void *v47; // [rsp+30h] [rbp-480h]
  int v48; // [rsp+3Ch] [rbp-474h]
  RBX::Network::Replicator::JoinDataItemV2 *v49; // [rsp+40h] [rbp-470h]
  _DWORD **v50; // [rsp+48h] [rbp-468h]
  void *v51[9]; // [rsp+50h] [rbp-460h] BYREF
  _BYTE v52[528]; // [rsp+98h] [rbp-418h] BYREF
  void *v53[59]; // [rsp+2A8h] [rbp-208h] BYREF

  v49 = this; /*0x1067ed959*/
  *(_QWORD *)this = off_10CAACB58; /*0x1067ed960*/
  RBX::Analytics::InfluxDb::Points::Points(a1: v51, a2: 0xFFFFFFFFLL, a3: 0, a4: 0); /*0x1067ed973*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067ed999*/
    this: (RBX::Analytics::InfluxDb::Points *)v51,
    a2: "JoinSnapShotTime",
    a3: *(float *)(*((_QWORD *)v49 + 3) + 15592LL));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067ed9bd*/
    this: (RBX::Analytics::InfluxDb::Points *)v51,
    a2: "numOfPacketsSent",
    a3: *(_DWORD *)(*((_QWORD *)v49 + 17) + 48LL));
  std::string::basic_string[abi:ne200100]<0>(a1: v53, a2: "ReplicatorJoinDataItemV2Stats", a3: v1, a4: v2); /*0x1067ed9d0*/
  RBX::Analytics::InfluxDb::Points::report( /*0x1067ed9eb*/
    a1: v51,
    a2: v53,
    a3: (unsigned int)DFInt::ReplicatorJoinDataItemV2StatsInfluxHundrethsPercentage,
    a4: 0);
  if ( ((__int64)v53[0] & 1) != 0 ) /*0x1067ed9f7*/
    operator delete(a1: (RBX::Memory *)v53[2], a2: v3); /*0x1067eda00*/
  RBX::Analytics::InfluxDb::Points::~Points(this: v51); /*0x1067eda0c*/
  RBX::Analytics::InfluxDb::Points::Points(a1: v53, a2: 0xFFFFFFFFLL, a3: 0, a4: 0); /*0x1067eda21*/
  v4 = *(unsigned int *)(*((_QWORD *)v49 + 17) + 52LL); /*0x1067eda34*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067eda4a*/
    this: (RBX::Analytics::InfluxDb::Points *)v53,
    a2: "StreamingEnabled",
    a3: *((_BYTE *)v49 + 96));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067eda60*/
    this: (RBX::Analytics::InfluxDb::Points *)v53,
    a2: "JoinDataInstances",
    a3: v4);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067eda7d*/
    this: (RBX::Analytics::InfluxDb::Points *)v53,
    a2: "TotalReplicatorInstances",
    a3: *((_DWORD *)v49 + 25));
  v5 = *((_DWORD *)v49 + 25); /*0x1067eda89*/
  if ( v5 != 0 ) /*0x1067eda8e*/
    v6 = (int)(float)((float)((float)(int)v4 * 1000.0) / (float)v5); /*0x1067edaab*/
  else
    v6 = 1000; /*0x1067edab1*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067edac4*/
    this: (RBX::Analytics::InfluxDb::Points *)v53,
    a2: "JoinInstanceTenthPercent",
    a3: v6);
  v50 = (_DWORD **)((char *)v49 + 136); /*0x1067edad6*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067edaf1*/
    this: (RBX::Analytics::InfluxDb::Points *)v53,
    a2: "TotalJoinBytesCompressed",
    a3: *(_DWORD *)(*((_QWORD *)v49 + 17) + 60LL));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067edb11*/
    this: (RBX::Analytics::InfluxDb::Points *)v53,
    a2: "TotalJoinBytesUncompressed",
    a3: *(_DWORD *)(*((_QWORD *)v49 + 17) + 64LL));
  if ( v4 != 0 ) /*0x1067edb19*/
    v7 = (float)((float)(int)(*v50)[15] / (float)(int)v4); /*0x1067edb3c*/
  else
    v7 = 0.0; /*0x1067edb42*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067edb53*/
    this: (RBX::Analytics::InfluxDb::Points *)v53,
    a2: "CompressedBytesPerJoinInstance",
    a3: v7);
  if ( v4 != 0 ) /*0x1067edb5b*/
    v8 = (float)((float)(int)(*v50)[16] / (float)(int)v4); /*0x1067edb7e*/
  else
    v8 = 0.0; /*0x1067edb84*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067edb95*/
    this: (RBX::Analytics::InfluxDb::Points *)v53,
    a2: "UncompresedBytesPerJoinInstance",
    a3: v8);
  v9 = *((_DWORD *)v49 + 25); /*0x1067edba1*/
  if ( v9 != 0 ) /*0x1067edba6*/
    v10 = (float)((float)(int)(*v50)[15] / (float)v9); /*0x1067edbcb*/
  else
    v10 = 0.0; /*0x1067edbd1*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067edbe2*/
    this: (RBX::Analytics::InfluxDb::Points *)v53,
    a2: "CompressedBytesPerReplicatableInstance",
    a3: v10);
  v11 = *((_DWORD *)v49 + 25); /*0x1067edbee*/
  if ( v11 != 0 ) /*0x1067edbf3*/
    v12 = (float)((float)(int)(*v50)[16] / (float)v11); /*0x1067edc18*/
  else
    v12 = 0.0; /*0x1067edc1e*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067edc2f*/
    this: (RBX::Analytics::InfluxDb::Points *)v53,
    a2: "UncompresedBytesPerReplicatableInstance",
    a3: v12);
  std::string::basic_string[abi:ne200100]<0>(a1: v51, a2: "JoinInstanceStatsForStreaming", a3: v13, a4: v14); /*0x1067edc42*/
  RBX::Analytics::InfluxDb::Points::report( /*0x1067edc5d*/
    a1: v53,
    a2: v51,
    a3: (unsigned int)DFInt::ReportJoinInstanceCountStreamingDataHundredthPercentage,
    a4: 0);
  if ( ((__int64)v51[0] & 1) != 0 ) /*0x1067edc69*/
    operator delete(a1: (RBX::Memory *)v51[2], a2: v16); /*0x1067edc72*/
  if ( DFInt::ReportJoinInstaceStatsToEventIngestHundredthsPercent > 0 ) /*0x1067edc7e*/
  {
    RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)1,std::enable_if<true,void>>( /*0x1067edc92*/
      a1: v51,
      a2: &RBX::Telemetry::kServerJoinInstanceStats);
    if ( (unsigned __int8)RBX::Telemetry::RobloxTelemetryEvent::willThrottleEventIngest(this: (RBX::Telemetry::RobloxTelemetryEvent *)v51) == 0 ) /*0x1067edca5*/
    {
      std::string::basic_string[abi:ne200100]<0>(a1: v46, a2: "", a3: v19, a4: v20); /*0x1067edcb9*/
      RBX::Telemetry::FieldsContainer::addPlaceId(this: (RBX::Analytics *)v52); /*0x1067edccf*/
      if ( (v46[0] & 1) != 0 ) /*0x1067edcdb*/
        operator delete(a1: (RBX::Memory *)v47, a2: v21); /*0x1067edce4*/
      RBX::Telemetry::FieldsContainer::addUniverseId(this: (RBX::Telemetry::FieldsContainer *)v52); /*0x1067edcec*/
      RBX::Telemetry::FieldsContainer::addField(a1: v52, a2: "JoinDataInstances", a3: 17, a4: v4, a5: 1); /*0x1067edd09*/
      RBX::Telemetry::FieldsContainer::addField( /*0x1067edd2d*/
        a1: v52,
        a2: "TotalReplicatorInstances",
        a3: 24,
        a4: *((unsigned int *)v49 + 25),
        a5: 1);
      RBX::Telemetry::FieldsContainer::addField( /*0x1067edd54*/
        a1: v52,
        a2: "TotalJoinBytesCompressed",
        a3: 24,
        a4: (unsigned int)(*v50)[15],
        a5: 1);
      RBX::Telemetry::FieldsContainer::addField( /*0x1067edd7b*/
        a1: v52,
        a2: "TotalJoinBytesUncompressed",
        a3: 26,
        a4: (unsigned int)(*v50)[16],
        a5: 1);
      RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v51); /*0x1067edd87*/
    }
    RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v51); /*0x1067edd9a*/
  }
  if ( DFInt::ReportJoinDataItemV2CacheEfficiencyHundrethsPercentage2 > 0 ) /*0x1067edda6*/
  {
    v22 = *((int **)v49 + 17); /*0x1067eddb3*/
    v23 = v22[4] + *((_DWORD *)v49 + 16); /*0x1067eddc2*/
    v24 = *v22; /*0x1067eddc6*/
    v25 = v22[3]; /*0x1067eddc9*/
    v26 = v22[8]; /*0x1067eddcd*/
    v27 = v22[7] + *((_DWORD *)v49 + 19); /*0x1067eddd0*/
    v48 = v22[11]; /*0x1067eddd7*/
    RBX::Analytics::InfluxDb::Points::Points(a1: v51, a2: 0xFFFFFFFFLL, a3: 0, a4: 0); /*0x1067edded*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067ede16*/
      this: (RBX::Analytics::InfluxDb::Points *)v51,
      a2: "InstanceHits",
      a3: (*v50)[13] - (v26 + v23 + v24));
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067ede39*/
      this: (RBX::Analytics::InfluxDb::Points *)v51,
      a2: "InstanceTotal",
      a3: (*v50)[13] - v23);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067ede66*/
      this: (RBX::Analytics::InfluxDb::Points *)v51,
      a2: "BlobHits",
      a3: (*v50)[12] - (v48 + v27 + v25));
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067ede89*/
      this: (RBX::Analytics::InfluxDb::Points *)v51,
      a2: "BlobTotal",
      a3: (*v50)[12] - v27);
    std::string::basic_string[abi:ne200100]<0>(a1: v46, a2: "ReplicatorJoinDataItemV2CacheEfficiency", a3: v28, a4: v29); /*0x1067ede9c*/
    RBX::Analytics::InfluxDb::Points::report( /*0x1067edeb7*/
      a1: v51,
      a2: v46,
      a3: (unsigned int)DFInt::ReportJoinDataItemV2CacheEfficiencyHundrethsPercentage2,
      a4: 0);
    if ( (v46[0] & 1) != 0 ) /*0x1067edec3*/
      operator delete(a1: (RBX::Memory *)v47, a2: v30); /*0x1067edecc*/
    RBX::Analytics::InfluxDb::Points::~Points(this: v51); /*0x1067eded8*/
  }
  v31 = DFLog::NetworkJoin; /*0x1067edee4*/
  v32 = (unsigned int)DFLog::NetworkJoin >> 8; /*0x1067edee9*/
  if ( (unsigned __int8)DFLog::NetworkJoin >= 6u && BYTE1(DFLog::NetworkJoin) >= 3u )
  {
    v42 = (*v50)[2]; /*0x1067edf17*/
    FLog::FastLogFormatted(
      a1: DFLog::NetworkJoin,
      a2: qword_10D7F3E08,
      a3: (unsigned int)"[DFLog::NetworkJoin] ~JoinDataItemV2 : Cache Update Stats (CacheableInstances) : %u instances added,"
                    " %u blob(s) added, %u raw bytes added, %u compressed bytes added",
      a4: **v50,
      a5: (*v50)[3],
      a6: (*v50)[1]);
    v31 = DFLog::NetworkJoin; /*0x1067edf28*/
    v32 = (unsigned int)DFLog::NetworkJoin >> 8; /*0x1067edf2d*/
  }
  if ( (unsigned __int8)v31 >= 6u && (unsigned __int8)v32 >= 3u )
  {
    v42 = (*v50)[6]; /*0x1067edf5c*/
    FLog::FastLogFormatted(
      a1: v31,
      a2: qword_10D7F3E08,
      a3: (unsigned int)"[DFLog::NetworkJoin] ~JoinDataItemV2 : Cache Update Stats (NotCacheableInstances) : %u instances add"
                    "ed, %u blob(s) added, %u raw bytes added, %u compressed bytes added",
      a4: (*v50)[4],
      a5: (*v50)[7],
      a6: (*v50)[5]);
    v31 = DFLog::NetworkJoin; /*0x1067edf6d*/
    v32 = (unsigned int)DFLog::NetworkJoin >> 8; /*0x1067edf72*/
  }
  if ( (unsigned __int8)v31 >= 6u && (unsigned __int8)v32 >= 3u )
  {
    v42 = (*v50)[10]; /*0x1067edfa1*/
    FLog::FastLogFormatted(
      a1: v31,
      a2: qword_10D7F3E08,
      a3: (unsigned int)"[DFLog::NetworkJoin] ~JoinDataItemV2 : Cache Update Stats (PartInstances) : %u instances added, %u b"
                    "lob(s) added, %u raw bytes added, %u compressed bytes added",
      a4: (*v50)[8],
      a5: (*v50)[11],
      a6: (*v50)[9]);
    v31 = DFLog::NetworkJoin; /*0x1067edfb2*/
    v32 = (unsigned int)DFLog::NetworkJoin >> 8; /*0x1067edfb7*/
  }
  if ( (unsigned __int8)v31 >= 6u && (unsigned __int8)v32 >= 3u )
  {
    v42 = *((_DWORD *)v49 + 18); /*0x1067edfec*/
    FLog::FastLogFormatted(
      a1: v31,
      a2: qword_10D7F3E08,
      a3: (unsigned int)"[DFLog::NetworkJoin] ~JoinDataItemV2 : sharedStringsInstanceCounters : %u instances added, %u blob(s"
                    ") added, %u raw bytes added, %u compressed bytes added, took %f ms",
      a4: *((_DWORD *)v49 + 16),
      a5: *((_DWORD *)v49 + 19),
      a6: *((_DWORD *)v49 + 17));
    v31 = DFLog::NetworkJoin; /*0x1067edffd*/
  }
  if ( DFFlag::BatchNetAssetJoinBlob == 1 && (unsigned __int8)v31 >= 6u && BYTE1(v31) >= 3u )
  {
    v42 = *((_DWORD *)v49 + 22); /*0x1067ee03a*/
    FLog::FastLogFormatted(
      a1: v31,
      a2: qword_10D7F3E08,
      a3: (unsigned int)"[DFLog::NetworkJoin] ~JoinDataItemV2 : batchNetAssetsInstanceCounters : %u assets added, %u blob(s) "
                    "added, %u raw bytes added, %u compressed bytes added",
      a4: *((_DWORD *)v49 + 20),
      a5: *((_DWORD *)v49 + 23),
      a6: *((_DWORD *)v49 + 21));
    v31 = DFLog::NetworkJoin; /*0x1067ee04b*/
  }
  if ( (unsigned __int8)v31 >= 6u && BYTE1(v31) >= 3u )
  {
    v33 = *((_DWORD **)v49 + 17); /*0x1067ee06e*/
    v44 = v33[17]; /*0x1067ee091*/
    v43 = v33[16]; /*0x1067ee095*/
    v42 = v33[15]; /*0x1067ee09a*/
    FLog::FastLogFormatted(
      a1: v31,
      a2: qword_10D7F3E08,
      a3: (unsigned int)"[DFLog::NetworkJoin] ~JoinDataItemV2 : Total Join Stats : %u instances, %u blob(s), %u total bytes, "
                    "%u compressed bytes, %u uncompressed bytes, %u useful uncompressed bytes",
      a4: v33[13] + *((_DWORD *)v49 + 27),
      a5: v33[12] + *((_DWORD *)v49 + 26),
      a6: v33[14]);
  }
  if ( (_BYTE)DFLog::NetworkJoinDetails != 0 ) /*0x1067ee0b6*/
  {
    if ( (unsigned __int8)DFLog::NetworkJoinDetails >= 6u && BYTE1(DFLog::NetworkJoinDetails) >= 3u ) /*0x1067ee0cd*/
    {
      LOBYTE(v15) = (unsigned __int8)DFLog::NetworkJoinDetails < 6u; /*0x1067ee0c8*/
      FLog::FastLogFormatted( /*0x1067ee0e1*/
        a1: DFLog::NetworkJoinDetails,
        a2: qword_10D7F3E18,
        a3: (unsigned int)"[DFLog::NetworkJoinDetails] InstanceTypePtr,InstanceTypeName,BlobType,Count,minSize,maxSize,avgSize",
        a4: v15,
        a5: v17,
        a6: v18);
    }
    if ( *((_QWORD *)*v50 + 17) != 0 ) /*0x1067ee0f8*/
    {
      for ( i = *(__int64 **)(*((_QWORD *)*v50 + 20) + 8LL * *((_QWORD *)*v50 + 16)); i != nullptr; i = (__int64 *)*i ) /*0x1067ee113*/
      {
        if ( (unsigned __int8)DFLog::NetworkJoinDetails >= 6u && BYTE1(DFLog::NetworkJoinDetails) >= 3u ) /*0x1067ee12d*/
        {
          v35 = i[2]; /*0x1067ee134*/
          v36 = *(_QWORD *)(v35 + 8); /*0x1067ee139*/
          if ( (*(_BYTE *)v36 & 1) != 0 ) /*0x1067ee141*/
            v36 = *(_QWORD *)(v36 + 16); /*0x1067ee148*/
          else
            LODWORD(v36) = v36 + 1; /*0x1067ee143*/
          v45 = *((_DWORD *)i + 10) / *((_DWORD *)i + 7); /*0x1067ee16e*/
          v44 = *((_DWORD *)i + 9); /*0x1067ee172*/
          v43 = *((_DWORD *)i + 8); /*0x1067ee177*/
          v42 = *((_DWORD *)i + 7); /*0x1067ee17c*/
          FLog::FastLogFormatted( /*0x1067ee185*/
            a1: DFLog::NetworkJoinDetails,
            a2: qword_10D7F3E18,
            a3: (unsigned int)"[DFLog::NetworkJoinDetails] %p,%s,%d,%d,%d,%d,%d",
            a4: v35,
            a5: v36,
            a6: *((_DWORD *)i + 6));
        }
      }
    }
  }
  RBX::Analytics::InfluxDb::Points::~Points(this: v53); /*0x1067ee19a*/
  std::shared_ptr<RBX::Network::PreserializedReplicationCache const>::~shared_ptr[abi:ne200100]( /*0x1067ee1a6*/
    a1: v50,
    a2: v39,
    a3: v37,
    a4: v38,
    a5: v40,
    a6: v41,
    a7: v42,
    a8: v43,
    a9: v44,
    a10: v45);
}

// Address: 0x1067ee1e8 | Name: __ZN3RBX7Network10Replicator14JoinDataItemV2D1Ev
void __fastcall RBX::Network::Replicator::JoinDataItemV2::~JoinDataItemV2(
        RBX::Network::Replicator::JoinDataItemV2 *this)
{
  RBX::Network::Replicator::JoinDataItemV2::~JoinDataItemV2(this); /*0x1067ee1ed*/
}

// Address: 0x1067ee1f2 | Name: __ZN3RBX7Network10Replicator14JoinDataItemV2D0Ev
void __fastcall RBX::Network::Replicator::JoinDataItemV2::~JoinDataItemV2(
        RBX::Network::Replicator::JoinDataItemV2 *this)
{
  void *v2; // rsi

  RBX::Network::Replicator::JoinDataItemV2::~JoinDataItemV2(this); /*0x1067ee1fb*/
  operator delete(a1: this, a2: v2); /*0x1067ee209*/
}

// Address: 0x1067ee20e | Name: __ZN3RBX7Network10Replicator14JoinDataItemV221prepareStreamsForSendERNSt3__110shared_ptrINS0_29PreserializedReplicationCacheEEERNS0_20ReplicationDataCacheERNS3_4listINS0_19ReplicationDataBlobENS3_9allocatorISB_EEEE
__int64 __fastcall RBX::Network::Replicator::JoinDataItemV2::prepareStreamsForSend(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 CacheableDataBlobs; // rax
  __int64 PartBlobCache; // rax
  __int64 CharacterModelRootBlobCache; // rax

  *(_OWORD *)*(_QWORD *)a1 = *(_OWORD *)(a2 + 280); /*0x1067ee225*/
  *(_OWORD *)(*(_QWORD *)a1 + 16LL) = *(_OWORD *)(a2 + 296); /*0x1067ee232*/
  *(_OWORD *)(*(_QWORD *)a1 + 32LL) = *(_OWORD *)(a2 + 312); /*0x1067ee240*/
  RBX::Network::Replicator::JoinDataItemV2::constructBlobStreams(a1: a3, a2: 3, a3: a1); /*0x1067ee24f*/
  CacheableDataBlobs = RBX::Network::ReplicationDataCache::getCacheableDataBlobs(this: (RBX::Network::ReplicationDataCache *)a2); /*0x1067ee257*/
  RBX::Network::Replicator::JoinDataItemV2::constructBlobStreams(a1: CacheableDataBlobs, a2: 2, a3: a1); /*0x1067ee267*/
  PartBlobCache = RBX::Network::ReplicationDataCache::getPartBlobCache(this: (RBX::Network::ReplicationDataCache *)a2); /*0x1067ee26f*/
  RBX::Network::Replicator::JoinDataItemV2::constructBlobStreams(a1: PartBlobCache, a2: 4, a3: a1); /*0x1067ee27f*/
  CharacterModelRootBlobCache = RBX::Network::ReplicationDataCache::getCharacterModelRootBlobCache(this: (RBX::Network::ReplicationDataCache *)a2); /*0x1067ee287*/
  return RBX::Network::Replicator::JoinDataItemV2::constructBlobStreams(a1: CharacterModelRootBlobCache, a2: 2, a3: a1); /*0x1067ee297*/
}

// Address: 0x1067ee2a0 | Name: __ZN3RBX7Network10Replicator14JoinDataItemV220constructBlobStreamsERKNSt3__14listINS0_19ReplicationDataBlobENS3_9allocatorIS5_EEEENS2_19JoinDataSubItemTypeERNS3_10shared_ptrINS0_29PreserializedReplicationCacheEEE
__int64 __fastcall RBX::Network::Replicator::JoinDataItemV2::constructBlobStreams(_QWORD *a1, int a2, __int64 *a3)
{
  _QWORD *v4; // rbx
  int v5; // eax
  RBX::Network::NetworkStream *v6; // r12
  bool v7; // zf
  RBX::Network::NetworkStream *v8; // rdx
  RBX::Network::NetworkStream *v9; // rdx
  unsigned int *v10; // r14
  unsigned int *v11; // r15
  RBX::Network::NetworkStream *v12; // rdx
  unsigned int *v13; // r14
  __int64 v14; // rax
  _QWORD *v15; // rdi
  __int64 v16; // rax
  _QWORD *v17; // rdi
  __int64 v18; // rax
  _QWORD *v19; // rdi
  __int64 v20; // rax
  unsigned int v21; // ebx
  unsigned int v22; // r15d
  _QWORD *v23; // rdi
  __int64 v24; // rax
  _QWORD *v25; // rdi
  unsigned int v26; // ebx
  unsigned int v27; // r15d
  _QWORD *v28; // rdi
  __int64 v29; // rax
  unsigned int v30; // ebx
  _QWORD *v31; // rdi
  __int64 v32; // rax
  int v33; // r15d
  int v34; // r12d
  RBX::Network::NetworkStream *v35; // rcx
  __int64 v36; // rbx
  __int64 v37; // rbx
  char *v38; // rax
  __int64 v39; // rdx
  __int64 v40; // rcx
  void *v41; // rsi
  __int64 v42; // rcx
  int v43; // eax
  __int64 v44; // rcx
  __int64 v45; // r15
  _QWORD *v46; // r12
  unsigned __int8 v47; // bl
  unsigned __int8 v48; // r14
  RBX::Network *v49; // rdi
  void *v50; // rsi
  std::__shared_weak_count *v51; // rbx
  std::__shared_weak_count *v52; // rbx
  __int64 result; // rax
  __int64 v54; // [rsp+10h] [rbp-170h]
  __m128i v55; // [rsp+20h] [rbp-160h] BYREF
  unsigned int *v56; // [rsp+30h] [rbp-150h]
  RBX::Network::NetworkStream *v57; // [rsp+38h] [rbp-148h]
  RBX::Network::NetworkStream *v58; // [rsp+40h] [rbp-140h]
  _QWORD *i; // [rsp+48h] [rbp-138h]
  __int128 v60; // [rsp+50h] [rbp-130h] BYREF
  __int64 v61; // [rsp+60h] [rbp-120h]
  RBX::Network::NetworkStream *v62; // [rsp+68h] [rbp-118h] BYREF
  std::__shared_weak_count *v63; // [rsp+70h] [rbp-110h]
  char v64; // [rsp+78h] [rbp-108h] BYREF
  char v65; // [rsp+79h] [rbp-107h] BYREF
  void *v66; // [rsp+88h] [rbp-F8h]
  void *v67[2]; // [rsp+90h] [rbp-F0h] BYREF
  __int64 v68; // [rsp+A0h] [rbp-E0h]
  RBX::Network::NetworkStream *v69[2]; // [rsp+B0h] [rbp-D0h] BYREF
  __int64 v70; // [rsp+C0h] [rbp-C0h]
  char *v71; // [rsp+D0h] [rbp-B0h]
  __int64 v72; // [rsp+E0h] [rbp-A0h]
  __int64 v73; // [rsp+F0h] [rbp-90h]
  std::__shared_weak_count *v74[2]; // [rsp+100h] [rbp-80h]
  void *v75[2]; // [rsp+110h] [rbp-70h] BYREF
  __int64 v76; // [rsp+120h] [rbp-60h]
  __int64 v77[2]; // [rsp+130h] [rbp-50h] BYREF
  void *v78; // [rsp+140h] [rbp-40h]
  _QWORD *v79; // [rsp+148h] [rbp-38h]
  int v80; // [rsp+150h] [rbp-30h] BYREF
  int v81; // [rsp+154h] [rbp-2Ch]

  v81 = a2; /*0x1067ee2b7*/
  v4 = (_QWORD *)a1[1]; /*0x1067ee2ba*/
  for ( i = a1; v4 != i; v4 = (_QWORD *)v79[1] )
  {
    v5 = *((_DWORD *)v4 + 22); /*0x1067ee2d5*/
    v80 = v5 + 3; /*0x1067ee2db*/
    if ( v4[15] != v4[14] ) /*0x1067ee2e6*/
      v80 = v5 + 12 * *((_DWORD *)v4 + 8) + 7; /*0x1067ee2f4*/
    *(_OWORD *)v74 = 0; /*0x1067ee2fb*/
    std::allocate_shared[abi:ne200100]<RBX::Network::NetworkStream,std::allocator<RBX::Network::NetworkStream>,unsigned int &,0>( /*0x1067ee30b*/
      a1: v69,
      a2: v77,
      a3: &v80);
    v6 = v69[0]; /*0x1067ee310*/
    *(__m128i *)v74 = _mm_load_si128((const __m128i *)v69); /*0x1067ee31f*/
    LOBYTE(v69[0]) = -125; /*0x1067ee324*/
    RBX::Network::NetworkStream::writeBytes(this: v6, a2: v69, a3: 1u); /*0x1067ee336*/
    LOBYTE(v69[0]) = 22; /*0x1067ee33b*/
    RBX::Network::NetworkStream::writeBytes(this: v6, a2: v69, a3: 1u); /*0x1067ee351*/
    LOBYTE(v69[0]) = v81; /*0x1067ee359*/
    RBX::Network::NetworkStream::writeBytes(this: v6, a2: v69, a3: 1u); /*0x1067ee36e*/
    RBX::Network::NetworkStream::writeBytes(this: v6, a2: (const void *)v4[7], a3: *((_DWORD *)v4 + 22)); /*0x1067ee37d*/
    if ( (unsigned __int8)DFLog::ReplicationDataCaching >= 6u && BYTE1(DFLog::ReplicationDataCaching) >= 3u ) /*0x1067ee39a*/
    {
      LODWORD(v54) = *((_DWORD *)v4 + 8); /*0x1067ee3c5*/
      FLog::FastLogFormatted( /*0x1067ee3da*/
        a1: DFLog::ReplicationDataCaching,
        a2: qword_10D7F3E28,
        a3: (unsigned int)"[DFLog::ReplicationDataCaching] ReplicationDataCache::Copying blob#%d [%p],  compressedStream=%p, "
                      "numOfRawBytes=%d, numOfCompressedBytes=%d, numOfInstances=%d",
        a4: *(_DWORD *)(*a3 + 48),
        a5: (_DWORD)v4 + 16,
        a6: v4[7]);
      v6 = v74[0]; /*0x1067ee3df*/
    }
    v7 = v4[15] == v4[14]; /*0x1067ee3e7*/
    v79 = v4; /*0x1067ee3eb*/
    if ( !v7 )
    {
      LODWORD(v69[0]) = *((_DWORD *)v4 + 8); /*0x1067ee3f8*/
      RBX::Network::NetworkStream::writeBytes(this: v6, a2: v69, a3: 4u); /*0x1067ee40d*/
      RBX::Network::serializeUnsignedVarint( /*0x1067ee427*/
        this: (RBX::Network *)((v4[18] - v4[17]) >> 3),
        a2: (unsigned int)v6,
        a3: v8);
      if ( (unsigned __int8)DFLog::ReplicationDataCaching >= 6u && BYTE1(DFLog::ReplicationDataCaching) >= 3u )
        FLog::FastLog(
          a1: *(_QWORD *)&DFLog::ReplicationDataCaching,
          a2: qword_10D7F3E28,
          a3: "[DFLog::ReplicationDataCaching] ReplicationDataCache::Num invalidated cache in blob : %zu",
          (__int64)(v4[18] - v4[17]) >> 3);
      v10 = (unsigned int *)v4[17]; /*0x1067ee474*/
      v11 = (unsigned int *)v4[18]; /*0x1067ee47b*/
      while ( v10 != v11 )
      {
        if ( (unsigned __int8)DFLog::ReplicationDataCaching >= 6u && BYTE1(DFLog::ReplicationDataCaching) >= 3u )
          FLog::FastLog(
            a1: *(_QWORD *)&DFLog::ReplicationDataCaching,
            a2: qword_10D7F3E28,
            a3: "[DFLog::ReplicationDataCaching] ReplicationDataCache::Invalidated Instance : offset %u  length %u",
            *v10,
            v10[1]);
        RBX::Network::serializeUnsignedVarint(this: (RBX::Network *)*v10, a2: (unsigned int)v6, a3: v9); /*0x1067ee4cd*/
        RBX::Network::serializeUnsignedVarint(this: (RBX::Network *)v10[1], a2: (unsigned int)v6, a3: v12); /*0x1067ee4d9*/
        v10 += 2; /*0x1067ee4de*/
      }
      if ( (_BYTE)DFLog::NetworkJoinDetails != 0 ) /*0x1067ee4ee*/
      {
        v13 = (unsigned int *)v4[14]; /*0x1067ee4f4*/
        v56 = (unsigned int *)v4[15]; /*0x1067ee4fc*/
        if ( v13 != v56 ) /*0x1067ee506*/
        {
          v58 = v6; /*0x1067ee50c*/
          do /*0x1067ee7ba*/
          {
            v14 = *((_QWORD *)v13 + 1); /*0x1067ee513*/
            if ( v14 != 0 ) /*0x1067ee51a*/
            {
              if ( (_BYTE)DFLog::NetworkJoinDetails != 0 ) /*0x1067ee52a*/
              {
                v15 = (_QWORD *)(*a3 + 120); /*0x1067ee534*/
                v69[0] = *(RBX::Network::NetworkStream **)(*(_QWORD *)(v14 + 8) + 24LL); /*0x1067ee540*/
                v16 = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Reflection::ClassDescriptor const* const,RBX::Network::PreserializedReplicationCache::instanceTypeCount>>,RBX::Reflection::ClassDescriptor const*,RBX::Network::PreserializedReplicationCache::instanceTypeCount,boost::hash<RBX::Reflection::ClassDescriptor const*>,std::equal_to<RBX::Reflection::ClassDescriptor const*>>>::operator[]( /*0x1067ee551*/
                        a1: v15,
                        a2: (__int64 *)v69);
                *(_DWORD *)(v16 + 8) = v81; /*0x1067ee559*/
                v17 = (_QWORD *)(*a3 + 120); /*0x1067ee560*/
                v69[0] = *(RBX::Network::NetworkStream **)(*(_QWORD *)(*((_QWORD *)v13 + 1) + 8LL) + 24LL); /*0x1067ee570*/
                v18 = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Reflection::ClassDescriptor const* const,RBX::Network::PreserializedReplicationCache::instanceTypeCount>>,RBX::Reflection::ClassDescriptor const*,RBX::Network::PreserializedReplicationCache::instanceTypeCount,boost::hash<RBX::Reflection::ClassDescriptor const*>,std::equal_to<RBX::Reflection::ClassDescriptor const*>>>::operator[]( /*0x1067ee57a*/
                        a1: v17,
                        a2: (__int64 *)v69);
                ++*(_DWORD *)(v18 + 12); /*0x1067ee57f*/
                v19 = (_QWORD *)(*a3 + 120); /*0x1067ee586*/
                v69[0] = *(RBX::Network::NetworkStream **)(*(_QWORD *)(*((_QWORD *)v13 + 1) + 8LL) + 24LL); /*0x1067ee596*/
                v20 = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Reflection::ClassDescriptor const* const,RBX::Network::PreserializedReplicationCache::instanceTypeCount>>,RBX::Reflection::ClassDescriptor const*,RBX::Network::PreserializedReplicationCache::instanceTypeCount,boost::hash<RBX::Reflection::ClassDescriptor const*>,std::equal_to<RBX::Reflection::ClassDescriptor const*>>>::operator[]( /*0x1067ee5a0*/
                        a1: v19,
                        a2: (__int64 *)v69);
                v21 = v13[1]; /*0x1067ee5a5*/
                v22 = *(_DWORD *)(v20 + 16); /*0x1067ee5a9*/
                v23 = (_QWORD *)(*a3 + 120); /*0x1067ee5b1*/
                v77[0] = *(_QWORD *)(*(_QWORD *)(*((_QWORD *)v13 + 1) + 8LL) + 24LL); /*0x1067ee5c1*/
                v24 = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Reflection::ClassDescriptor const* const,RBX::Network::PreserializedReplicationCache::instanceTypeCount>>,RBX::Reflection::ClassDescriptor const*,RBX::Network::PreserializedReplicationCache::instanceTypeCount,boost::hash<RBX::Reflection::ClassDescriptor const*>,std::equal_to<RBX::Reflection::ClassDescriptor const*>>>::operator[]( /*0x1067ee5c9*/
                        a1: v23,
                        a2: v77);
                if ( v21 < v22 ) /*0x1067ee5d1*/
                  v22 = v21; /*0x1067ee5d1*/
                *(_DWORD *)(v24 + 16) = v22; /*0x1067ee5d5*/
                v25 = (_QWORD *)(*a3 + 120); /*0x1067ee5dd*/
                v69[0] = *(RBX::Network::NetworkStream **)(*(_QWORD *)(*((_QWORD *)v13 + 1) + 8LL) + 24LL); /*0x1067ee5ed*/
                v26 = *(_DWORD *)(boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Reflection::ClassDescriptor const* const,RBX::Network::PreserializedReplicationCache::instanceTypeCount>>,RBX::Reflection::ClassDescriptor const*,RBX::Network::PreserializedReplicationCache::instanceTypeCount,boost::hash<RBX::Reflection::ClassDescriptor const*>,std::equal_to<RBX::Reflection::ClassDescriptor const*>>>::operator[]( /*0x1067ee600*/
                                    a1: v25,
                                    a2: (__int64 *)v69)
                                + 20);
                v27 = v13[1]; /*0x1067ee603*/
                v28 = (_QWORD *)(*a3 + 120); /*0x1067ee60b*/
                v77[0] = *(_QWORD *)(*(_QWORD *)(*((_QWORD *)v13 + 1) + 8LL) + 24LL); /*0x1067ee61b*/
                v29 = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Reflection::ClassDescriptor const* const,RBX::Network::PreserializedReplicationCache::instanceTypeCount>>,RBX::Reflection::ClassDescriptor const*,RBX::Network::PreserializedReplicationCache::instanceTypeCount,boost::hash<RBX::Reflection::ClassDescriptor const*>,std::equal_to<RBX::Reflection::ClassDescriptor const*>>>::operator[]( /*0x1067ee623*/
                        a1: v28,
                        a2: v77);
                if ( v26 > v27 ) /*0x1067ee62b*/
                  v27 = v26; /*0x1067ee62b*/
                *(_DWORD *)(v29 + 20) = v27; /*0x1067ee62f*/
                v30 = v13[1]; /*0x1067ee633*/
                v31 = (_QWORD *)(*a3 + 120); /*0x1067ee63b*/
                v69[0] = *(RBX::Network::NetworkStream **)(*(_QWORD *)(*((_QWORD *)v13 + 1) + 8LL) + 24LL); /*0x1067ee64b*/
                v32 = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Reflection::ClassDescriptor const* const,RBX::Network::PreserializedReplicationCache::instanceTypeCount>>,RBX::Reflection::ClassDescriptor const*,RBX::Network::PreserializedReplicationCache::instanceTypeCount,boost::hash<RBX::Reflection::ClassDescriptor const*>,std::equal_to<RBX::Reflection::ClassDescriptor const*>>>::operator[]( /*0x1067ee659*/
                        a1: v31,
                        a2: (__int64 *)v69);
                *(_DWORD *)(v32 + 24) += v30; /*0x1067ee65e*/
                v4 = v79; /*0x1067ee661*/
              }
              v33 = DFLog::ReplicationDataCaching; /*0x1067ee66c*/
              if ( (unsigned __int8)DFLog::ReplicationDataCaching >= 6u && BYTE1(DFLog::ReplicationDataCaching) >= 6u ) /*0x1067ee67e*/
              {
                v34 = qword_10D7F3E28; /*0x1067ee690*/
                (*(void (__fastcall **)(__int64 *))(**(_QWORD **)(*((_QWORD *)v13 + 1) + 8LL) + 184LL))(a1: v77); /*0x1067ee6a3*/
                v35 = (RBX::Network::NetworkStream *)((char *)v77 + 1); /*0x1067ee6ad*/
                if ( (v77[0] & 1) != 0 ) /*0x1067ee6b1*/
                  v35 = (RBX::Network::NetworkStream *)v78; /*0x1067ee6b3*/
                v36 = *(_QWORD *)(*(_QWORD *)(*(_QWORD *)(*((_QWORD *)v13 + 1) + 8LL) + 24LL) + 8LL); /*0x1067ee6c3*/
                v7 = (*(_BYTE *)v36 & 1) == 0; /*0x1067ee6c7*/
                v57 = v35; /*0x1067ee6ca*/
                if ( v7 ) /*0x1067ee6d1*/
                  v37 = v36 + 1; /*0x1067ee6d3*/
                else
                  v37 = *(_QWORD *)(v36 + 16); /*0x1067ee6d8*/
                RBX::Guid::toString(this: (RBX::Guid *)&v64); /*0x1067ee6e7*/
                v38 = &v65; /*0x1067ee6f3*/
                if ( (v64 & 1) != 0 ) /*0x1067ee701*/
                  v38 = (char *)v66; /*0x1067ee703*/
                v39 = *v13; /*0x1067ee70e*/
                v40 = *(unsigned int *)(*a3 + 48); /*0x1067ee711*/
                v69[0] = v57; /*0x1067ee71b*/
                v70 = v37; /*0x1067ee722*/
                v71 = v38; /*0x1067ee729*/
                v72 = v39; /*0x1067ee730*/
                v73 = v40; /*0x1067ee737*/
                v55.i64[0] = 142540; /*0x1067ee73e*/
                v55.i64[1] = (__int64)v69; /*0x1067ee749*/
                FLog::detail::FastLogSafeFormattedInternal( /*0x1067ee77b*/
                  a1: v33,
                  a2: v34,
                  a3: 6,
                  a4: (unsigned int)"[DFLog::ReplicationDataCaching] Pushing instance {}[type={}][guid={}] with metaDataOffse"
                                "t={} into blobIndex={}",
                  a5: 110,
                  a6: 1,
                  _mm_loadu_si128(&v55),
                  v54);
                v4 = v79; /*0x1067ee787*/
                v6 = v58; /*0x1067ee78b*/
                if ( (v64 & 1) != 0 ) /*0x1067ee792*/
                  operator delete(a1: (RBX::Memory *)v66, a2: v41); /*0x1067ee79b*/
                if ( (v77[0] & 1) != 0 ) /*0x1067ee7a4*/
                  operator delete(a1: (RBX::Memory *)v78, a2: v41); /*0x1067ee7aa*/
              }
            }
            v13 += 8; /*0x1067ee7af*/
          }
          while ( v13 != v56 ); /*0x1067ee7ba*/
        }
      }
    }
    v42 = *a3; /*0x1067ee7c3*/
    *(_DWORD *)(v42 + 52) += *((_DWORD *)v4 + 8); /*0x1067ee7c7*/
    *(_QWORD *)(v42 + 60) = _mm_add_epi32( /*0x1067ee7df*/
                              _mm_insert_epi32(_mm_cvtsi32_si128(*((_DWORD *)v4 + 22)), *((_DWORD *)v4 + 7), 1),
                              _mm_loadl_epi64((const __m128i *)(v42 + 60))).u64[0];
    *(_DWORD *)(v42 + 68) += *((_DWORD *)v4 + 6); /*0x1067ee7e7*/
    v43 = (*(__int64 (__fastcall **)(RBX::Network::NetworkStream *))(*(_QWORD *)v6 + 24LL))(a1: v6); /*0x1067ee7f1*/
    v44 = *a3; /*0x1067ee7f4*/
    *(_DWORD *)(v44 + 56) += v43; /*0x1067ee7f8*/
    ++*(_DWORD *)(v44 + 48); /*0x1067ee7fb*/
    LOBYTE(v69[0]) = 0; /*0x1067ee7fe*/
    RBX::Network::NetworkStream::writeBytes(this: v6, a2: v69, a3: 1u); /*0x1067ee814*/
    v45 = *a3; /*0x1067ee819*/
    v62 = v6; /*0x1067ee81d*/
    v63 = v74[1]; /*0x1067ee828*/
    *(_OWORD *)v74 = 0; /*0x1067ee833*/
    v46 = v4; /*0x1067ee838*/
    v47 = *((_BYTE *)v4 + 36); /*0x1067ee83b*/
    v48 = *((_BYTE *)v46 + 37); /*0x1067ee83e*/
    v60 = 0; /*0x1067ee843*/
    v61 = 0; /*0x1067ee84b*/
    std::vector<RBX::SharedString>::__init_with_size[abi:ne200100]<RBX::SharedString*,RBX::SharedString*>( /*0x1067ee877*/
      a1: &v60,
      a2: v46[20],
      a3: v46[21],
      a4: (__int64)(v46[21] - v46[20]) >> 3);
    *(_OWORD *)v67 = 0; /*0x1067ee880*/
    v68 = 0; /*0x1067ee888*/
    std::vector<RBX::Network::NetAssetHandle>::__init_with_size[abi:ne200100]<RBX::Network::NetAssetHandle*,RBX::Network::NetAssetHandle*>( /*0x1067ee8c2*/
      a1: v67,
      a2: v46[23],
      a3: v46[24],
      a4: 0xAAAAAAAAAAAAAAABLL * ((__int64)(v46[24] - v46[23]) >> 3));
    if ( (unsigned __int8)RBX::Network::shouldCaptureExpensiveJoinBandwidthUsageStats(this: v49) != 0 ) /*0x1067ee8d5*/
    {
      *(_OWORD *)v75 = 0; /*0x1067ee8d7*/
      v76 = 0; /*0x1067ee8dc*/
      std::vector<unsigned short>::__init_with_size[abi:ne200100]<unsigned short *,unsigned short *>( /*0x1067ee903*/
        a1: v75,
        a2: v79[26],
        a3: v79[27],
        a4: (__int64)(v79[27] - v79[26]) >> 1);
    }
    else
    {
      *(_OWORD *)v75 = 0; /*0x1067ee90a*/
      v76 = 0; /*0x1067ee90f*/
    }
    RBX::Network::PreserializedReplicationCache::addToCacheSetAndUpdate( /*0x1067ee93e*/
      a1: v45,
      a2: (unsigned int)&v62,
      a3: v47,
      a4: v48,
      a5: (unsigned int)&v60,
      a6: (unsigned int)v67,
      a7: (__int64)v75);
    if ( v75[0] != nullptr ) /*0x1067ee94a*/
    {
      v75[1] = v75[0]; /*0x1067ee94c*/
      operator delete(a1: (RBX::Memory *)v75[0], a2: v50); /*0x1067ee950*/
    }
    if ( v67[0] != nullptr ) /*0x1067ee95f*/
    {
      v67[1] = v67[0]; /*0x1067ee961*/
      operator delete(a1: (RBX::Memory *)v67[0], a2: v50); /*0x1067ee968*/
    }
    v69[0] = (RBX::Network::NetworkStream *)&v60; /*0x1067ee974*/
    std::vector<RBX::SharedString>::__destroy_vector::operator()[abi:ne200100](a1: v69); /*0x1067ee982*/
    v51 = v63; /*0x1067ee987*/
    if ( v63 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v63 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1067ee9a3*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v51 + 16LL))(a1: v51); /*0x1067ee9ab*/
      std::__shared_weak_count::__release_weak(this: v51); /*0x1067ee9b1*/
    }
    v52 = v74[1]; /*0x1067ee9b6*/
    if ( v74[1] != nullptr /*0x1067ee9d6*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v74[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v52 + 16LL))(a1: v52); /*0x1067ee9de*/
      std::__shared_weak_count::__release_weak(this: v52); /*0x1067ee9e4*/
    }
  }
  result = *a3; /*0x1067ee9fe*/
  *(_BYTE *)(*a3 + 112) = 1; /*0x1067eea02*/
  return result; /*0x1067eea06*/
}

// Address: 0x1067eead2 | Name: __ZN3RBX7Network10Replicator14JoinDataItemV25writeERNS0_13NetworkStreamE
char __fastcall RBX::Network::Replicator::JoinDataItemV2::write(
        RBX::Network::Replicator::JoinDataItemV2 *this,
        RBX::Network::NetworkStream *a2)
{
  return 1; /*0x1067eead8*/
}

// Address: 0x1067eeada | Name: __ZN3RBX7Network10Replicator14JoinDataItemV212readInstanceERS1_RNS0_13NetworkStreamERNS0_25DeserializedNewObjectItemE
__int64 __fastcall RBX::Network::Replicator::JoinDataItemV2::readInstance(
        RBX::Network::NetAssetHelpers **this,
        RBX::Network::Replicator *a2,
        RBX::Network::NetworkStream *a3,
        RBX::Network::DeserializedNewObjectItem *a4)
{
  __int64 v7; // r13
  _BYTE *v8; // r12
  void *v9; // rsi
  unsigned __int16 UInt16; // ax
  __int64 v11; // rdx
  RBX::InstanceStitchingHandler *v12; // rdi
  __int64 v13; // r8
  __int64 v14; // r9
  __m128 v15; // xmm0
  __m128 v16; // xmm1
  __m128 v17; // xmm2
  __m128 v18; // xmm3
  __m128 v19; // xmm4
  __m128 v20; // xmm5
  __m128 v21; // xmm6
  __m128 v22; // xmm7
  __int64 v23; // rcx
  const char *v24; // rsi
  RBX::Guid *v25; // r12
  const char *v26; // rsi
  const RBX::Reflection::ClassDescriptor *v27; // r13
  RBX::InstanceStitchingHandler *v28; // rdi
  char v29; // al
  unsigned int v30; // esi
  _QWORD *v31; // r12
  __int64 v32; // rax
  __int64 v33; // r14
  const char *v34; // r14
  _QWORD *v35; // r12
  __int64 v36; // rdx
  __int64 v37; // rcx
  __int64 v38; // r8
  __int64 v39; // r9
  __m128 v40; // xmm0
  __m128 v41; // xmm1
  __m128 v42; // xmm2
  __m128 v43; // xmm3
  __m128 v44; // xmm4
  __m128 v45; // xmm5
  __m128 v46; // xmm6
  __m128 v47; // xmm7
  std::__shared_weak_count *v48; // r13
  int *v49; // rax
  __int64 v50; // rcx
  unsigned __int8 SharedStringCachingEnabled; // al
  const RBX::Reflection::PropertyDescriptor *v52; // rsi
  _QWORD *i; // r15
  __int64 v54; // r13
  __int64 v55; // r14
  const RBX::SharedString *SharedStringFromCache; // r13
  const RBX::Reflection::PropertyDescriptor **v57; // r12
  const RBX::Reflection::PropertyDescriptor **v58; // r14
  char v59; // al
  RBX::Guid *v60; // r14
  unsigned int *v61; // r15
  RBX::DataModel *v62; // rsi
  __int64 v63; // r12
  RBX::Network::NetAssetHelpers *v64; // rdi
  RBX::DataModel *v65; // rsi
  __int64 v66; // r14
  __int64 v67; // r13
  __int64 v68; // r15
  __int64 v69; // r12
  __int64 HashFromNetAssetId; // rax
  unsigned int v71; // esi
  RBX::Network *v72; // rdi
  __int64 v73; // r15
  std::__shared_weak_count *v74; // rbx
  std::__shared_weak_count *v75; // rbx
  std::__shared_weak_count *v76; // rbx
  __int64 v78; // rdx
  __int64 v79; // rcx
  __int64 v80; // r8
  __int64 v81; // r9
  __m128 v82; // xmm0
  __m128 v83; // xmm1
  __m128 v84; // xmm2
  __m128 v85; // xmm3
  __m128 v86; // xmm4
  __m128 v87; // xmm5
  __m128 v88; // xmm6
  __m128 v89; // xmm7
  const char *v90; // rsi
  __int64 v91; // rsi
  const char *v92; // rsi
  const char *v93; // r15
  std::__shared_weak_count *v94; // rax
  __int64 v95; // r13
  char v96; // bl
  __int64 v97; // r12
  __m128 v98; // xmm0
  __m128 v99; // xmm1
  __m128 v100; // xmm2
  __m128 v101; // xmm3
  __m128 v102; // xmm4
  __m128 v103; // xmm5
  __m128 v104; // xmm6
  __m128 v105; // xmm7
  __int64 v106; // r13
  char *v107; // r9
  char v108; // [rsp+0h] [rbp-160h]
  _QWORD v109[4]; // [rsp+10h] [rbp-150h] BYREF
  _BYTE v110[32]; // [rsp+30h] [rbp-130h] BYREF
  char v111[8]; // [rsp+50h] [rbp-110h] BYREF
  __int64 v112; // [rsp+58h] [rbp-108h]
  __int64 NetAssetManager; // [rsp+60h] [rbp-100h]
  RBX::Network::NetworkStream *v114; // [rsp+68h] [rbp-F8h]
  std::__shared_weak_count *v115[2]; // [rsp+70h] [rbp-F0h] BYREF
  std::__shared_weak_count *v116[4]; // [rsp+80h] [rbp-E0h] BYREF
  __int128 v117; // [rsp+A0h] [rbp-C0h] BYREF
  const char *v118; // [rsp+B0h] [rbp-B0h]
  int v119; // [rsp+B8h] [rbp-A8h]
  __int128 v120; // [rsp+C0h] [rbp-A0h]
  _DWORD v121[3]; // [rsp+D4h] [rbp-8Ch]
  RBX::Guid *v122; // [rsp+E0h] [rbp-80h]
  _QWORD v123[3]; // [rsp+E8h] [rbp-78h] BYREF
  _BYTE v124[48]; // [rsp+100h] [rbp-60h] BYREF

  v7 = 0; /*0x1067eeb0e*/
  if ( (unsigned __int8)RBX::Network::shouldCaptureExpensiveJoinBandwidthUsageStats((RBX::Network *)this) != 0 ) /*0x1067eeb13*/
    v7 = *((unsigned int *)a2 + 14); /*0x1067eeb13*/
  if ( (unsigned __int8)DFLog::ReplicationDataCaching >= 6u && BYTE1(DFLog::ReplicationDataCaching) >= 3u ) /*0x1067eeb2f*/
    FLog::FastLog( /*0x1067eeb41*/
      a1: *(_QWORD *)&DFLog::ReplicationDataCaching,
      a2: qword_10D7F3E28,
      a3: "[DFLog::ReplicationDataCaching] Begin reading join instance offset=%X bytes",
      *((_DWORD *)a2 + 14));
  *((_QWORD *)a3 + 10) = RBX::Network::IdSerializer::deserializeId((RBX::Network::IdSerializer *)this, a2); /*0x1067eeb55*/
  v122 = (RBX::Network::NetworkStream *)((char *)a3 + 80); /*0x1067eeb63*/
  v112 = v7; /*0x1067eeb67*/
  if ( FFlag::DebugVeryDetailedBandwidthUsage == 1 ) /*0x1067eeb6e*/
  {
    v8 = v124; /*0x1067eeb82*/
    RBX::Network::RecordDetailedPerInstanceMetricsRAII::RecordDetailedPerInstanceMetricsRAII( /*0x1067eeb94*/
      a1: (unsigned int)v124,
      a2: (_DWORD)this + 288,
      a3: (_DWORD)a2,
      a4: 1,
      a5: (_DWORD)a3 + 80,
      a6: 0,
      a7: (__int64)"");
  }
  else
  {
    v8 = nullptr; /*0x1067eeb9b*/
  }
  v109[0] = v8; /*0x1067eeba5*/
  v109[3] = (char *)&RBX::unique_function<void ()(void),24ul,8ul,true>::unique_function<RBX::Network::Replicator::JoinDataItemV2::readInstance(RBX::Network::Replicator&,RBX::Network::NetworkStream &,RBX::Network::DeserializedNewObjectItem &)::$_0>(RBX::Network::Replicator::JoinDataItemV2::readInstance(RBX::Network::Replicator&,RBX::Network::NetworkStream &,RBX::Network::DeserializedNewObjectItem &)::$_0)::Callback /*0x1067eebb0*/
          + 2;
  RBX::unique_function<void ()(void),24ul,8ul,true>::unique_function<24ul,8ul>(a1: (__int64)v110, a2: (__int64)v109); /*0x1067eebbe*/
  RBX::unique_function<void ()(void),24ul,8ul,true>::~unique_function(a1: (__int64)v109, a2: v9); /*0x1067eebc6*/
  UInt16 = RBX::Network::NetworkStream::readUInt16(this: a2); /*0x1067eebce*/
  v23 = (__int64)*(this + 1560); /*0x1067eebd3*/
  v24 = *(const char **)(v23 + 184); /*0x1067eebda*/
  v25 = v122; /*0x1067eebe4*/
  if ( v24 == nullptr /*0x1067eec10*/
    || (v23 = (__int64)(*(_QWORD *)(v23 + 192) - (_QWORD)v24) >> 3,
        v11 = 0xD37A6F4DE9BD37A7LL * v23,
        0xD37A6F4DE9BD37A7LL * v23 <= UInt16) )
  {
    RBX::throw_runtime_error( /*0x1067ef1cd*/
      this: (RBX *)"Join data contained invalid class network id",
      a2: v24,
      a3: v11,
      a4: v23,
      a5: v13,
      a6: v14,
      a7: v15,
      a8: v16,
      a9: v17,
      a10: v18,
      a11: v19,
      a12: v20,
      a13: v21,
      a14: v22,
      a15: v108);
  }
  v26 = &v24[184 * UInt16]; /*0x1067eec1d*/
  *((_QWORD *)a3 + 12) = v26; /*0x1067eec20*/
  *(_QWORD *)&v121[1] = v26; /*0x1067eec24*/
  v27 = *((const RBX::Reflection::ClassDescriptor **)v26 + 1); /*0x1067eec2b*/
  if ( (unsigned __int8)RBX::InstanceStitchingHandler::isInstanceStitchingEnabled(this: v12) != 0
    && (unsigned __int8)RBX::Network::Replicator::isInServerAuthoritativeMode((RBX::Network::Replicator *)this) != 0
    && (v28 = *(this + 2317)) != nullptr )
  {
    v29 = RBX::InstanceStitchingHandler::markPotentiallyCollidingStitchableInstance(this: v28, a2: v25, a3: v27); /*0x1067eec56*/
    *(_OWORD *)v115 = 0; /*0x1067eec5e*/
    if ( v29 != 0 )
    {
LABEL_21:
      if ( v27 != nullptr )
      {
        RBX::Creatable::createWithEngineContextByName<RBX::Object>( /*0x1067eecf8*/
          a1: &v117,
          a2: (unsigned __int64)*(this + 11) & 0xFFFFFFFFFFFFFFF8LL,
          a3: *((_QWORD *)v27 + 1),
          a4: 0);
        v35 = (_QWORD *)((char *)a3 + 112); /*0x1067eecfd*/
        std::shared_ptr<RBX::Object>::operator=[abi:ne200100](a1: (char *)a3 + 112, a2: &v117); /*0x1067eed0e*/
        v48 = *((std::__shared_weak_count **)&v117 + 1); /*0x1067eed13*/
        if ( *((_QWORD *)&v117 + 1) != 0 /*0x1067eed2c*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v117 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v48 + 16LL))(a1: v48); /*0x1067eed35*/
          std::__shared_weak_count::__release_weak(this: v48); /*0x1067eed3b*/
        }
        if ( *v35 == 0 )
        {
          v91 = *(_QWORD *)(*(_QWORD *)(*((_QWORD *)a3 + 12) + 8LL) + 8LL); /*0x1067ef20b*/
          if ( (*(_BYTE *)v91 & 1) != 0 ) /*0x1067ef212*/
            v92 = *(const char **)(v91 + 16); /*0x1067ef244*/
          else
            v92 = (const char *)(v91 + 1); /*0x1067ef214*/
          RBX::throw_runtime_error(
            this: (RBX *)"Replication: Can't create object of type %s",
            a2: v92,
            a3: v36,
            a4: v37,
            a5: v38,
            a6: v39,
            a7: v40,
            a8: v41,
            a9: v42,
            a10: v43,
            a11: v44,
            a12: v45,
            a13: v46,
            a14: v47,
            a15: v108);
        }
        RBX::GuidItem<RBX::Object>::Registry::assignGuid(a1: *(this + 22), a2: *v35, a3: v122); /*0x1067eed58*/
        *((_BYTE *)a3 + 144) = 1; /*0x1067eed5d*/
      }
      goto LABEL_27; /*0x1067eed5d*/
    }
  }
  else
  {
    *(_OWORD *)v115 = 0; /*0x1067eec6e*/
  }
  if ( (unsigned __int8)RBX::GuidItem<RBX::Object>::Registry::lookupByGuid(a1: *(this + 22), a2: v25, a3: v115) == 0 ) /*0x1067eec8d*/
    goto LABEL_21; /*0x1067eec8d*/
  v31 = (_QWORD *)((char *)a3 + 112); /*0x1067eec8f*/
  std::shared_ptr<RBX::Object>::operator=[abi:ne200100](a1: (char *)a3 + 112, a2: v115); /*0x1067eec9d*/
  v32 = *((_QWORD *)a3 + 14); /*0x1067eeca2*/
  if ( v32 == 0 ) /*0x1067eeca9*/
  {
    RBX::Guid::readableString(this: (RBX::Guid *)&v117, a2: (int)v122); /*0x1067ef1ec*/
    if ( (v117 & 1) != 0 ) /*0x1067ef1f8*/
      v90 = v118; /*0x1067ef1fa*/
    else
      v90 = (char *)&v117 + 1; /*0x1067ef25b*/
    RBX::throw_runtime_error( /*0x1067ef26b*/
      this: (RBX *)"read join object got a null object (guid %s)",
      a2: v90,
      a3: v78,
      a4: v79,
      a5: v80,
      a6: v81,
      a7: v82,
      a8: v83,
      a9: v84,
      a10: v85,
      a11: v86,
      a12: v87,
      a13: v88,
      a14: v89,
      a15: v108);
  }
  if ( *(_QWORD *)(v32 + 24) != *(_QWORD *)(*(_QWORD *)&v121[1] + 8LL) )
  {
    v33 = *((_QWORD *)v27 + 1); /*0x1067eecc4*/
    if ( (*(_BYTE *)v33 & 1) != 0 ) /*0x1067eeccc*/
      v34 = *(const char **)(v33 + 16); /*0x1067ef219*/
    else
      v34 = (const char *)(v33 + 1); /*0x1067eecd2*/
    RBX::Guid::readableString(this: (RBX::Guid *)&v117, a2: (int)v122); /*0x1067ef22d*/
    if ( (v117 & 1) != 0 ) /*0x1067ef239*/
      v93 = v118; /*0x1067ef23b*/
    else
      v93 = (char *)&v117 + 1; /*0x1067ef275*/
    RBX::Network::RakNetAddressToString( /*0x1067ef297*/
      this: (RBX::Network *)v116,
      a2: (const RakNet::SystemAddress *)(this + 30),
      a3: true,
      a4: 124);
    if ( ((__int64)v116[0] & 1) != 0 ) /*0x1067ef2a3*/
      v94 = v116[2]; /*0x1067ef2a5*/
    else
      v94 = (std::__shared_weak_count *)((char *)v116 + 1); /*0x1067ef2ae*/
    *(_QWORD *)&v121[1] = v94; /*0x1067ef2b5*/
    v95 = (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*v31 + 64LL))(a1: *v31); /*0x1067ef2c6*/
    v96 = *(_BYTE *)v95; /*0x1067ef2c9*/
    v97 = *(_QWORD *)(v95 + 16); /*0x1067ef2cb*/
    RBX::Guid::readableString(this: (RBX::Guid *)v123, a2: (int)v122); /*0x1067ef2dc*/
    v106 = v95 + 1; /*0x1067ef2e1*/
    if ( (v96 & 1) == 0 ) /*0x1067ef2e7*/
      v97 = v106; /*0x1067ef2e7*/
    if ( (v123[0] & 1) != 0 ) /*0x1067ef2ef*/
      v107 = (char *)v123[2]; /*0x1067ef2f1*/
    else
      v107 = (char *)v123 + 1; /*0x1067ef2f7*/
    RBX::throw_runtime_error(
      this: (RBX *)"Replication: Bad re-binding in deserialize new instance %s-%s << %s, %s-%s",
      a2: v34,
      a3: (__int64)v93,
      a4: *(__int64 *)&v121[1],
      a5: v97,
      a6: (__int64)v107,
      a7: v98,
      a8: v99,
      a9: v100,
      a10: v101,
      a11: v102,
      a12: v103,
      a13: v104,
      a14: v105,
      a15: v108);
  }
LABEL_27:
  v49 = (int *)&RBX::Memory::NetworkReplicator; /*0x1067eed65*/
  if ( *((_BYTE *)a3 + 144) == 1 ) /*0x1067eed74*/
  {
    v50 = *((_QWORD *)a3 + 14); /*0x1067eed76*/
    if ( v50 != 0 ) /*0x1067eed7d*/
    {
      v49 = *(int **)(*(_QWORD *)(v50 + 24) + 424LL); /*0x1067eed83*/
      if ( v49 == nullptr ) /*0x1067eed8d*/
        v49 = &RBX::Memory::InstanceObject; /*0x1067eed8f*/
    }
  }
  v121[0] = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)*v49, a2: v30); /*0x1067eed9d*/
  LOBYTE(v117) = 0; /*0x1067eedaa*/
  *((_QWORD *)&v117 + 1) = 16; /*0x1067eedae*/
  v118 = nullptr; /*0x1067eedb6*/
  v119 = 1065353216; /*0x1067eedbe*/
  v120 = 0; /*0x1067eedc9*/
  memset(v116, 0, 28); /*0x1067eedd9*/
  RBX::Network::DeserializedNewObjectItem::schemaReadPropertyGroup( /*0x1067eedee*/
    a1: (__int64)a3,
    a2: (RBX::Network::Replicator *)this,
    a3: a2,
    a4: 0,
    a5: 0,
    a6: &v117,
    a7: (__int32 *)v116);
  SharedStringCachingEnabled = RBX::Network::Replicator::getSharedStringCachingEnabled((RBX::Network::Replicator *)this); /*0x1067eedf6*/
  v114 = a2; /*0x1067eedfb*/
  v122 = a3; /*0x1067eee02*/
  if ( ((*((_DWORD *)this + 69) == 0) & SharedStringCachingEnabled) == 1 /*0x1067eee2f*/
    && *((_BYTE *)this + 18409) == 0
    && v118 != nullptr )
  {
    for ( i = *(_QWORD **)(*((_QWORD *)&v120 + 1) + 8LL * *((_QWORD *)&v117 + 1)); i != nullptr; i = (_QWORD *)*i ) /*0x1067eee43*/
    {
      v54 = i[5]; /*0x1067eee50*/
      v55 = i[6]; /*0x1067eee54*/
      if ( v54 != v55 ) /*0x1067eee5b*/
      {
        while ( (unsigned __int8)RBX::Network::SharedStringSynchronizer::isSharedStringCacheableToDisk( /*0x1067eee70*/
                                   this: *(RBX::Network::SharedStringSynchronizer **)(v54 + 8),
                                   a2: v52) == 0 )
        {
          v54 += 32; /*0x1067eee72*/
          if ( v54 == v55 ) /*0x1067eee79*/
            goto LABEL_45; /*0x1067eee79*/
        }
        if ( (unsigned __int8)RBX::Network::SharedStringSynchronizer::sharedStringHashIsRecognizedFromCache( /*0x1067eee91*/
                                a1: *(this + 1927),
                                a2: i + 2) != 0 )
        {
          SharedStringFromCache = (const RBX::SharedString *)RBX::Network::SharedStringSynchronizer::getSharedStringFromCache( /*0x1067eeea2*/
                                                               a1: *(this + 1927),
                                                               a2: i + 2);
          RBX::Flyweight<RBX::SharedString::Data,void,true>::Flyweight(a1: v111, a2: SharedStringFromCache); /*0x1067eeeb2*/
          RBX::Network::Replicator::cacheReceivedSharedString(a1: this, a2: i + 2, a3: v111); /*0x1067eeec0*/
          RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: v111); /*0x1067eeec8*/
          v57 = (const RBX::Reflection::PropertyDescriptor **)i[5]; /*0x1067eeecd*/
          v58 = (const RBX::Reflection::PropertyDescriptor **)i[6]; /*0x1067eeed1*/
          if ( v57 != v58 ) /*0x1067eeed8*/
          {
            do /*0x1067eeeec*/
            {
              RBX::Network::DeferredSharedStringSetter::setSharedString( /*0x1067eeee0*/
                this: (RBX::Network::DeferredSharedStringSetter *)v57,
                a2: SharedStringFromCache);
              v57 += 4; /*0x1067eeee5*/
            }
            while ( v57 != v58 ); /*0x1067eeeec*/
            v57 = (const RBX::Reflection::PropertyDescriptor **)i[5]; /*0x1067eeeee*/
          }
          RBX::Network::Replicator::registerSharedStringUsage( /*0x1067eef09*/
            (RBX::Network::Replicator *)this,
            a2: SharedStringFromCache,
            a3: *(const RBX::Reflection::ClassDescriptor **)(*((_QWORD *)v122 + 14) + 24LL),
            a4: v57[1]);
        }
      }
LABEL_45:
      ; /*0x1067eef0e*/
    }
  }
  v59 = RBX::Network::Replicator::getSharedStringCachingEnabled((RBX::Network::Replicator *)this); /*0x1067eef19*/
  v60 = v122; /*0x1067eef1e*/
  v61 = (unsigned int *)v114; /*0x1067eef22*/
  if ( v59 != 0 /*0x1067eef54*/
    && ((*((_DWORD *)this + 69) == 0)
      & (unsigned __int8)RBX::Network::Replicator::getNetAssetCachingEnabled((RBX::Network::Replicator *)this)) == 1
    && *((_BYTE *)this + 18409) == 0 )
  {
    v63 = (__int64)*(this + 1927); /*0x1067eef5a*/
    if ( *(_DWORD *)(v63 + 88) != 0 ) /*0x1067eef67*/
    {
      v64 = *(this + 2315); /*0x1067eef6d*/
      if ( v64 != nullptr && RBX::Network::NetAssetHelpers::getNetAssetManager(this: v64, a2: v62) != 0 ) /*0x1067eef85*/
      {
        NetAssetManager = RBX::Network::NetAssetHelpers::getNetAssetManager(this: *(this + 2315), a2: v65); /*0x1067eef97*/
        v66 = v63; /*0x1067eef9e*/
        if ( *(_DWORD *)(v63 + 88) != 0 ) /*0x1067eefa9*/
        {
          v67 = *(_QWORD *)(v63 + 80); /*0x1067eefab*/
          v68 = 24LL * *(unsigned int *)(v63 + 88); /*0x1067eefb3*/
          do /*0x1067ef005*/
          {
            v69 = (__int64)*(this + 1927); /*0x1067eefb7*/
            HashFromNetAssetId = RBX::Network::getHashFromNetAssetId(a1: v67); /*0x1067eefc1*/
            if ( *(_DWORD *)(v69 + 40) != 0 ) /*0x1067eefcc*/
            {
              v123[0] = HashFromNetAssetId; /*0x1067eefd2*/
              if ( (RBX::details::SplitHashTable<RBX::details::SharedStringHashContainer<8ul>,std::pair<RBX::details::SharedStringHashContainer<8ul>,std::pair<std::unique_ptr<RBX::ConvexDecompHolder>,int>>,(RBX::SplitHashPolicy)10,0u,RBX::details::SharedStringHashFunc<8ul>,RBX::details::SharedStringHashEqualityFunc<8ul>,RBX::details::GetMapKey<RBX::details::SharedStringHashContainer<8ul>,std::pair<std::unique_ptr<RBX::ConvexDecompHolder>,int>>>::findTableSlot<RBX::details::SharedStringHashContainer<8ul>>( /*0x1067eefe9*/
                      a1: v69 + 40,
                      a2: v123,
                      a3: 0)
                  & 0x100000000LL) == 0 )
                RBX::Network::Replicator::loadConvexDecompHolderFromCache(a1: this, a2: v67, a3: NetAssetManager); /*0x1067eeff8*/
            }
            v67 += 24; /*0x1067eeffd*/
            v68 -= 24; /*0x1067ef001*/
          }
          while ( v68 != 0 ); /*0x1067ef005*/
        }
        *(_DWORD *)(v66 + 88) = 0; /*0x1067ef007*/
        v60 = v122; /*0x1067ef00f*/
        v61 = (unsigned int *)v114; /*0x1067ef013*/
      }
    }
  }
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::vector<RBX::Network::DeferredSharedStringSetter>>>,std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string>,std::equal_to<std::string>>>::delete_buckets(a1: (__int64)&v117); /*0x1067ef021*/
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v121[0], a2: v71); /*0x1067ef02c*/
  *((_QWORD *)v60 + 11) = RBX::Network::IdSerializer::deserializeId( /*0x1067ef03c*/
                            (RBX::Network::IdSerializer *)this,
                            a2: (RBX::Network::NetworkStream *)v61);
  if ( (unsigned __int8)RBX::Network::shouldCaptureExpensiveJoinBandwidthUsageStats(this: v72) != 0 ) /*0x1067ef047*/
    RBX::Network::TwoWayBandwidthMetrics::onInstanceNetworked( /*0x1067ef06c*/
      a1: this + 36,
      a2: 1,
      a3: (unsigned __int16)**(_WORD **)&v121[1],
      a4: 0,
      a5: v61[14] - v112);
  v73 = *(_QWORD *)(*(_QWORD *)&v121[1] + 8LL); /*0x1067ef078*/
  if ( v73 != 0 ) /*0x1067ef07f*/
  {
    RBX::GuidItem<RBX::Object>::Registry::getByGuid(a1: v116, a2: *(this + 22)); /*0x1067ef09b*/
    RBX::Reflection::DescribedBase::fastSharedDynamicCast<RBX::Instance,RBX::Object>(a1: &v117, a2: v116); /*0x1067ef0ae*/
    std::shared_ptr<RBX::Instance>::operator=[abi:ne200100](a1: (__int64)v122 + 128, a2: &v117); /*0x1067ef0c5*/
    v74 = *((std::__shared_weak_count **)&v117 + 1); /*0x1067ef0ca*/
    if ( *((_QWORD *)&v117 + 1) != 0 /*0x1067ef0e3*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v117 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v74 + 16LL))(a1: v74); /*0x1067ef0eb*/
      std::__shared_weak_count::__release_weak(this: v74); /*0x1067ef0f1*/
    }
    v75 = v116[1]; /*0x1067ef0f6*/
    if ( v116[1] != nullptr /*0x1067ef112*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v116[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v75 + 16LL))(a1: v75); /*0x1067ef11a*/
      std::__shared_weak_count::__release_weak(this: v75); /*0x1067ef120*/
    }
  }
  else if ( (unsigned __int8)DFLog::ReplicationDataCaching >= 6u && BYTE1(DFLog::ReplicationDataCaching) >= 3u ) /*0x1067ef13f*/
  {
    FLog::FastLog( /*0x1067ef15a*/
      a1: *(_QWORD *)&DFLog::ReplicationDataCaching,
      a2: qword_10D7F3E28,
      a3: "[DFLog::ReplicationDataCaching] Discarding join instance due to null local descriptor (schema diff)",
      0);
  }
  v76 = v115[1]; /*0x1067ef15f*/
  if ( v115[1] != nullptr /*0x1067ef17b*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)v115[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v76 + 16LL))(a1: v76); /*0x1067ef183*/
    std::__shared_weak_count::__release_weak(this: v76); /*0x1067ef189*/
  }
  LOBYTE(v76) = v73 != 0; /*0x1067ef191*/
  RBX::ScopedExit::~ScopedExit(this: (RBX::ScopedExit *)v110); /*0x1067ef19b*/
  return (unsigned int)v76; /*0x1067ef1b2*/
}

// Address: 0x1067ef476 | Name: __ZN3RBX7Network10Replicator14JoinDataItemV228serializeASharedStringVectorERKNSt3__16vectorINS_12SharedStringENS3_9allocatorIS5_EEEERKNS4_ItNS6_ItEEEERi
RBX::Network::NetworkStream **__fastcall RBX::Network::Replicator::JoinDataItemV2::serializeASharedStringVector(
        RBX::Network::NetworkStream **a1,
        __int64 a2,
        __int64 *a3,
        _QWORD *a4,
        int *a5)
{
  unsigned __int64 v9; // rsi
  unsigned __int64 v10; // rax
  __int64 v11; // rcx
  unsigned __int64 v12; // rdx
  __int64 v13; // rsi
  unsigned int v14; // edx
  char *v15; // rsi
  unsigned __int64 v16; // rdx
  __int64 v17; // r12
  void *v18; // rsi
  void *v19; // rsi
  char v20; // dl
  RBX::Network *v21; // rdi
  const RBX::SharedString *v22; // rdx
  unsigned int v23; // r12d
  RBX::Network *v24; // rdi
  char v25; // al
  RBX::Network::NetworkStream *v26; // rbx
  RBX::Network::NetworkStream **v27; // r12
  unsigned int v28; // r13d
  int v29; // r15d
  unsigned __int8 v30; // cl
  int v31; // eax
  unsigned int v32; // ecx
  _BYTE v34[48]; // [rsp+8h] [rbp-C8h] BYREF
  unsigned int v35; // [rsp+38h] [rbp-98h]
  _QWORD *v36; // [rsp+48h] [rbp-88h]
  __m128i v37; // [rsp+50h] [rbp-80h] BYREF
  void *v38; // [rsp+60h] [rbp-70h]
  char v39[8]; // [rsp+68h] [rbp-68h] BYREF
  __m128i v40; // [rsp+70h] [rbp-60h] BYREF
  void *v41; // [rsp+80h] [rbp-50h]
  _BYTE v42[16]; // [rsp+88h] [rbp-48h] BYREF
  RBX::Network::NetworkStream **v43; // [rsp+98h] [rbp-38h]
  unsigned int v44; // [rsp+A0h] [rbp-30h]
  unsigned int v45; // [rsp+A4h] [rbp-2Ch]

  v36 = a4; /*0x1067ef48d*/
  v44 = 1000 * DFInt::MaxJoinDataSizeKBv2; /*0x1067ef4b1*/
  RBX::Network::NetworkStream::NetworkStream( /*0x1067ef4b4*/
    this: (RBX::Network::NetworkStream *)v34,
    a2: 1000 * DFInt::MaxJoinDataSizeKBv2);
  v43 = a1; /*0x1067ef4b9*/
  *a1 = nullptr; /*0x1067ef4bd*/
  v10 = *a5; /*0x1067ef4c4*/
  v11 = *a3; /*0x1067ef4c7*/
  v12 = (a3[1] - *a3) >> 3; /*0x1067ef4d2*/
  v45 = 0; /*0x1067ef4d6*/
  if ( v12 > v10 ) /*0x1067ef4e0*/
  {
    v45 = 0; /*0x1067ef4e6*/
    while ( 1 ) /*0x1067ef4ed*/
    {
      v13 = *(_QWORD *)(a2 + 24); /*0x1067ef4ed*/
      v14 = *(unsigned __int8 *)(v13 + 11744); /*0x1067ef4f1*/
      if ( (v14 & 1) != 0 ) /*0x1067ef4fb*/
      {
        v16 = *(_QWORD *)(v13 + 11752); /*0x1067ef508*/
        v15 = *(char **)(v13 + 11760); /*0x1067ef50f*/
      }
      else
      {
        v15 = (char *)(v13 + 11745); /*0x1067ef4fd*/
        v16 = v14 >> 1; /*0x1067ef504*/
      }
      RBX::SharedString::getHash(this: (RBX::SharedString *)(v11 + 8 * v10), a2: v15, a3: v16); /*0x1067ef51a*/
      v17 = *(_QWORD *)(a2 + 24); /*0x1067ef51f*/
      std::pair<std::string,RBX::SharedString>::pair[abi:ne200100]<std::string&,RBX::SharedString const&,0>( /*0x1067ef53a*/
        a1: &v40,
        a2: v17 + 11744,
        a3: *a3 + 8LL * *a5);
      v38 = v41; /*0x1067ef54a*/
      v37 = _mm_load_si128(&v40); /*0x1067ef553*/
      v40 = 0; /*0x1067ef55c*/
      v41 = nullptr; /*0x1067ef561*/
      RBX::Flyweight<RBX::SharedString::Data,void,true>::Flyweight(a1: v39, a2: v42); /*0x1067ef574*/
      boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,RBX::SharedString>>,std::string,RBX::SharedString,boost::hash<std::string>,std::equal_to<std::string>>>::emplace_impl<std::pair<std::string const,RBX::SharedString>>( /*0x1067ef583*/
        a1: (_QWORD *)(v17 + 15320),
        a2: (unsigned __int8 *)&v37,
        a3: (__int64)&v37);
      RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: v39); /*0x1067ef58b*/
      if ( (v37.i8[0] & 1) != 0 ) /*0x1067ef594*/
        operator delete(a1: (RBX::Memory *)v38, a2: v18); /*0x1067ef59a*/
      RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: v42); /*0x1067ef5a3*/
      if ( (v40.i8[0] & 1) != 0 ) /*0x1067ef5ac*/
        operator delete(a1: (RBX::Memory *)v41, a2: v19); /*0x1067ef5b2*/
      std::__hash_table<RBX::SharedString,std::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>,std::allocator<RBX::SharedString>>::__emplace_unique_key_args<RBX::SharedString,RBX::SharedString const&>( /*0x1067ef5d1*/
        a1: *(_QWORD *)(a2 + 24) + 15280LL,
        a2: *a3 + 8LL * *a5);
      if ( (v20 & 1) == 0 ) /*0x1067ef5d9*/
        goto LABEL_18; /*0x1067ef5d9*/
      if ( (unsigned __int8)RBX::Network::Replicator::getSharedStringCachingEnabled(this: *(RBX::Network::Replicator **)(a2 + 24)) == 0 /*0x1067ef605*/
        || (unsigned __int8)RBX::Network::SharedStringSynchronizer::sharedStringHashIsRecognizedFromClient(
                              a1: *(_QWORD *)(*(_QWORD *)(a2 + 24) + 15416LL),
                              a2: *(_QWORD *)(a2 + 24) + 11744LL) == 0 )
      {
        break; /*0x1067ef605*/
      }
      ++v45; /*0x1067ef607*/
LABEL_19:
      v10 = *a5 + 1LL; /*0x1067ef680*/
      *a5 = v10; /*0x1067ef686*/
      v11 = *a3; /*0x1067ef689*/
      if ( (a3[1] - *a3) >> 3 <= v10 ) /*0x1067ef69b*/
        goto LABEL_20; /*0x1067ef69b*/
    }
    v23 = 0; /*0x1067ef611*/
    if ( (unsigned __int8)RBX::Network::shouldCaptureExpensiveJoinBandwidthUsageStats(this: v21) != 0 ) /*0x1067ef616*/
      v23 = v35; /*0x1067ef618*/
    RBX::Network::Replicator::writeASharedString( /*0x1067ef631*/
      this: (RBX::Network::Replicator *)v34,
      a2: (RBX::Network::NetworkStream *)(*a3 + 8LL * *a5),
      a3: v22);
    v25 = RBX::Network::shouldCaptureExpensiveJoinBandwidthUsageStats(this: v24); /*0x1067ef636*/
    ++v45; /*0x1067ef63b*/
    if ( v25 != 0 ) /*0x1067ef640*/
      RBX::Network::TwoWayBandwidthMetrics::onInstanceNetworked( /*0x1067ef670*/
        a1: *(_QWORD *)(a2 + 24) + 288LL,
        a2: 0,
        a3: *(unsigned __int16 *)(*v36 + 2LL * *a5),
        a4: 1,
        a5: v35 - v23);
LABEL_18:
    if ( v35 >= v44 ) /*0x1067ef67e*/
      goto LABEL_20; /*0x1067ef67e*/
    goto LABEL_19; /*0x1067ef67e*/
  }
LABEL_20:
  v26 = (RBX::Network::NetworkStream *)operator new(a1: (RBX::Memory *)0x40, a2: v9); /*0x1067ef6a1*/
  v27 = v43; /*0x1067ef6b1*/
  RBX::Network::NetworkStream::NetworkStream(this: v26); /*0x1067ef6b5*/
  v28 = v45; /*0x1067ef6ba*/
  *v27 = v26; /*0x1067ef6be*/
  v37.i8[0] = -125; /*0x1067ef6c6*/
  RBX::Network::NetworkStream::writeBytes(this: v26, a2: &v37, a3: 1u); /*0x1067ef6d1*/
  RBX::Network::Item::writeItemType(a1: a2, a2: v26, a3: 0x16u); /*0x1067ef6e1*/
  v37.i8[0] = 1; /*0x1067ef6ea*/
  RBX::Network::NetworkStream::writeBytes(this: v26, a2: &v37, a3: 1u); /*0x1067ef6f5*/
  v29 = *((_DWORD *)v26 + 12); /*0x1067ef6fa*/
  RBX::Network::Replicator::compressBitStream( /*0x1067ef712*/
    this: (RBX::Network::Replicator *)v34,
    a2: v26,
    a3: (RBX::Network::NetworkStream *)(unsigned __int8)DFInt::JoinDataCompressionLevel,
    a4: v30);
  if ( (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)a2 + 64LL))(a1: a2) != 0 ) /*0x1067ef722*/
  {
    v37.i8[0] = 0; /*0x1067ef728*/
    RBX::Network::NetworkStream::writeBytes(this: v26, a2: &v37, a3: 1u); /*0x1067ef733*/
  }
  v31 = v35; /*0x1067ef738*/
  v32 = *((_DWORD *)v26 + 12) - v29; /*0x1067ef741*/
  *(_DWORD *)(a2 + 72) += v32; /*0x1067ef744*/
  *(_QWORD *)(a2 + 64) = _mm_add_epi32( /*0x1067ef75d*/
                           _mm_insert_epi32(_mm_cvtsi32_si128(v28), v31, 1),
                           _mm_loadl_epi64((const __m128i *)(a2 + 64))).u64[0];
  *(_DWORD *)(a2 + 124) += v31; /*0x1067ef763*/
  *(_QWORD *)(a2 + 116) = _mm_add_epi32( /*0x1067ef77b*/
                            _mm_insert_epi32(_mm_cvtsi32_si128(v32), v31, 1),
                            _mm_loadl_epi64((const __m128i *)(a2 + 116))).u64[0];
  *(_DWORD *)(a2 + 112) += (*(__int64 (__fastcall **)(RBX::Network::NetworkStream *))(*(_QWORD *)v26 + 24LL))(a1: v26); /*0x1067ef78a*/
  *(_QWORD *)(a2 + 104) = _mm_add_epi32( /*0x1067ef7a8*/
                            _mm_insert_epi32(_mm_cvtepi8_epi32(16843009), v28, 1),
                            _mm_loadl_epi64((const __m128i *)(a2 + 104))).u64[0];
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v34); /*0x1067ef7b5*/
  return v27; /*0x1067ef7bd*/
}

// Address: 0x1067ef8f8 | Name: __ZN3RBX7Network10Replicator14JoinDataItemV230serializeBatchedNetAssetVectorERKNSt3__16vectorINS0_14NetAssetHandleENS3_9allocatorIS5_EEEERi
RBX::Network::NetworkStream **__fastcall RBX::Network::Replicator::JoinDataItemV2::serializeBatchedNetAssetVector(
        RBX::Network::NetworkStream **a1,
        __int64 a2,
        __int64 *a3,
        int *a4)
{
  __int64 v8; // rax
  void *v9; // rsi
  int v10; // ecx
  __int64 v11; // rax
  int v12; // edx
  __int64 v13; // rcx
  __int64 v14; // rbx
  unsigned __int16 v15; // ax
  __int64 Factory; // rax
  __int16 v17; // r13
  __int64 v18; // rdi
  unsigned int v19; // r13d
  unsigned int v20; // r12d
  RBX::Network::NetworkStream *v21; // rax
  RBX::Network::NetworkStream *v22; // r15
  int v23; // ebx
  unsigned __int8 v24; // cl
  unsigned int v25; // esi
  __m128i inserted; // xmm0
  int v27; // eax
  _BYTE v29[48]; // [rsp+0h] [rbp-D0h] BYREF
  unsigned int v30; // [rsp+30h] [rbp-A0h]
  _BYTE v31[24]; // [rsp+40h] [rbp-90h] BYREF
  void *v32; // [rsp+58h] [rbp-78h] BYREF
  void *v33; // [rsp+60h] [rbp-70h]
  void *v34; // [rsp+68h] [rbp-68h]
  unsigned int v35; // [rsp+78h] [rbp-58h]
  RBX::Network::NetworkStream **v36; // [rsp+88h] [rbp-48h]
  unsigned int v37; // [rsp+94h] [rbp-3Ch]
  __int64 v38; // [rsp+98h] [rbp-38h]
  int v39; // [rsp+A4h] [rbp-2Ch]

  v37 = 1000 * DFInt::MaxJoinDataSizeKBv2; /*0x1067ef92c*/
  RBX::Network::NetworkStream::NetworkStream( /*0x1067ef92f*/
    this: (RBX::Network::NetworkStream *)v29,
    a2: 1000 * DFInt::MaxJoinDataSizeKBv2);
  if ( (unsigned __int8)RBX::Network::Replicator::getSharedStringCachingEnabled(this: *(RBX::Network::Replicator **)(a2 + 24)) != 0 /*0x1067ef962*/
    && (unsigned __int8)RBX::Network::Replicator::getNetAssetCachingEnabled(this: *(RBX::Network::Replicator **)(a2 + 24)) != 0
    && *(_DWORD *)((v8 = *(_QWORD *)(a2 + 24)) + 276) == 1
    && *(_BYTE *)(v8 + 18410) == 0 )
  {
    LOBYTE(v8) = *(_QWORD *)(v8 + 15416) != 0; /*0x1067efce7*/
    v39 = v8; /*0x1067efcea*/
  }
  else
  {
    v39 = 0; /*0x1067ef968*/
  }
  RBX::Network::NetworkStreamContent::NetworkStreamContent(this: (RBX::Network::NetworkStreamContent *)&v32); /*0x1067ef973*/
  v10 = *a4; /*0x1067ef978*/
  v11 = *a3; /*0x1067ef97b*/
  v12 = -1431655765 * ((unsigned __int64)(a3[1] - *a3) >> 3); /*0x1067ef98b*/
  v38 = 0; /*0x1067ef991*/
  if ( v10 >= v12 ) /*0x1067ef99b*/
  {
    v22 = nullptr; /*0x1067efc9c*/
    goto LABEL_28; /*0x1067efc9f*/
  }
  v36 = a1; /*0x1067ef9a1*/
  while ( 1 ) /*0x1067ef9a8*/
  {
    v13 = 3LL * v10; /*0x1067ef9a8*/
    if ( *(_QWORD *)(v11 + 8 * v13) != 0 ) /*0x1067ef9b1*/
    {
      v14 = v11 + 8 * v13; /*0x1067ef9b7*/
      v15 = *(_WORD *)(v14 + 16); /*0x1067ef9bb*/
      if ( v15 == 0 ) /*0x1067ef9c2*/
        goto LABEL_21; /*0x1067ef9c2*/
      Factory = RBX::Network::NetAssetManager::getFactory( /*0x1067ef9dd*/
                  this: *(RBX::Network::NetAssetManager **)(*(_QWORD *)(*(_QWORD *)(a2 + 24) + 11200LL) + 1456LL),
                  a2: v15);
      if ( Factory == 0 /*0x1067efa11*/
        || (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)Factory + 32LL))(a1: Factory) == 0
        || (unsigned __int8)RBX::Network::LargeReplicator::isAssetPublished(
                              a1: *(_QWORD *)(*(_QWORD *)(a2 + 24) + 11200LL),
                              a2: v14) != 0 )
      {
        goto LABEL_21; /*0x1067efa11*/
      }
      if ( (_BYTE)v39 == 0 ) /*0x1067efa1b*/
        break; /*0x1067efa1b*/
      v17 = *(_WORD *)(v14 + 16); /*0x1067efa1d*/
      if ( v17 != (unsigned __int16)RBX::Network::getNetAssetType<RBX::ConvexDecompHolder>() ) /*0x1067efa2b*/
        break; /*0x1067efa2b*/
      if ( (unsigned __int8)RBX::Network::isHashedNetAssetId(a1: v14) == 0 ) /*0x1067efa37*/
        break; /*0x1067efa37*/
      v18 = *(_QWORD *)(*(_QWORD *)(a2 + 24) + 15416LL); /*0x1067efa3d*/
      if ( *(_DWORD *)(v18 + 304) == 0 /*0x1067efa63*/
        || (RBX::details::SplitHashTable<RBX::Network::NetAssetId,RBX::Network::NetAssetId,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<RBX::Network::NetAssetId>,RBX::details::DefaultEqualTo<RBX::Network::NetAssetId>,RBX::details::GetSelfKey<RBX::Network::NetAssetId>>::findTableSlot<RBX::Network::NetAssetId>(
              a1: v18 + 304,
              a2: v14,
              a3: 0)
          & 0x100000000LL) != 0 )
      {
        break; /*0x1067efa63*/
      }
      RBX::Network::LargeReplicator::markAssetPublished(a1: *(_QWORD *)(*(_QWORD *)(a2 + 24) + 11200LL), a2: v14); /*0x1067efa73*/
    }
LABEL_21:
    v10 = *a4 + 1; /*0x1067efb3f*/
    *a4 = v10; /*0x1067efb44*/
    v11 = *a3; /*0x1067efb47*/
    if ( v10 >= (int)(-1431655765 * ((unsigned __int64)(a3[1] - *a3) >> 3)) ) /*0x1067efb5f*/
      goto LABEL_22; /*0x1067efb5f*/
  }
  RBX::Network::NetworkStreamContext::NetworkStreamContext( /*0x1067efaa0*/
    a1: v31,
    a2: *(unsigned int *)(*(_QWORD *)(*(_QWORD *)(a2 + 24) + 11200LL) + 6900LL),
    a3: *(unsigned int *)(*(_QWORD *)(*(_QWORD *)(a2 + 24) + 11200LL) + 6904LL),
    a4: 0);
  RBX::Network::Serializer<RBX::Network::NetAssetHandle>::serialize(a1: v31, a2: v29, a3: v14); /*0x1067efab2*/
  RBX::Network::NetworkStreamContent::Reset(this: (RBX::Network::NetworkStreamContent *)&v32); /*0x1067efabb*/
  if ( (unsigned __int8)RBX::Network::LargeReplicator::serializeRawAssetContent( /*0x1067efad9*/
                          a1: *(_QWORD *)(*(_QWORD *)(a2 + 24) + 11200LL),
                          a2: v14,
                          a3: &v32) == 0 )
    goto LABEL_21; /*0x1067efad9*/
  v19 = v35; /*0x1067efadb*/
  RBX::Network::NetworkStream::writeUInt32VarInt(this: (RBX::Network::NetworkStream *)v29, a2: v35); /*0x1067efae9*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v29, a2: v32, a3: v19); /*0x1067efafc*/
  RBX::Network::LargeReplicator::addBatchSendAssetStats( /*0x1067efb12*/
    a1: *(_QWORD *)(*(_QWORD *)(a2 + 24) + 11200LL),
    a2: v14,
    a3: v19);
  RBX::Network::LargeReplicator::markAssetPublished(a1: *(_QWORD *)(*(_QWORD *)(a2 + 24) + 11200LL), a2: v14); /*0x1067efb25*/
  v38 = (unsigned int)(v38 + 1); /*0x1067efb30*/
  if ( v30 < v37 ) /*0x1067efb3d*/
    goto LABEL_21; /*0x1067efb3d*/
LABEL_22:
  v20 = v38; /*0x1067efb65*/
  if ( (_DWORD)v38 != 0 ) /*0x1067efb6c*/
  {
    v21 = (RBX::Network::NetworkStream *)operator new(a1: (RBX::Memory *)0x40, a2: (unsigned __int64)v9); /*0x1067efb77*/
    a1 = v36; /*0x1067efb7c*/
    v22 = v21; /*0x1067efb80*/
    RBX::Network::NetworkStream::NetworkStream(this: v21); /*0x1067efb86*/
    v31[0] = -125; /*0x1067efb92*/
    RBX::Network::NetworkStream::writeBytes(this: v22, a2: v31, a3: 1u); /*0x1067efb9d*/
    RBX::Network::Item::writeItemType(a1: a2, a2: v22, a3: 0x16u); /*0x1067efbad*/
    v31[0] = 5; /*0x1067efbb9*/
    RBX::Network::NetworkStream::writeBytes(this: v22, a2: v31, a3: 1u); /*0x1067efbc4*/
    v23 = *((_DWORD *)v22 + 12); /*0x1067efbc9*/
    RBX::Network::Replicator::compressBitStream( /*0x1067efbe1*/
      this: (RBX::Network::Replicator *)v29,
      a2: v22,
      a3: (RBX::Network::NetworkStream *)(unsigned __int8)DFInt::JoinDataCompressionLevel,
      a4: v24);
    if ( (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)a2 + 64LL))(a1: a2) != 0 ) /*0x1067efbf1*/
    {
      v31[0] = 0; /*0x1067efbfa*/
      RBX::Network::NetworkStream::writeBytes(this: v22, a2: v31, a3: 1u); /*0x1067efc05*/
    }
    v25 = *((_DWORD *)v22 + 12) - v23; /*0x1067efc0e*/
    inserted = _mm_insert_epi32(_mm_cvtsi32_si128(v20), v30, 1); /*0x1067efc15*/
    *(_DWORD *)(a2 + 88) += v25; /*0x1067efc1f*/
    *(_QWORD *)(a2 + 80) = _mm_add_epi32(_mm_loadl_epi64((const __m128i *)(a2 + 80)), inserted).u64[0]; /*0x1067efc2d*/
    RBX::Network::LargeReplicator::addBatchSendCompressedBytes( /*0x1067efc3e*/
      this: *(RBX::Network::LargeReplicator **)(*(_QWORD *)(a2 + 24) + 11200LL),
      a2: v25);
    v27 = v30; /*0x1067efc43*/
    *(_DWORD *)(a2 + 124) += v30; /*0x1067efc49*/
    *(_QWORD *)(a2 + 116) = _mm_add_epi32( /*0x1067efc67*/
                              _mm_insert_epi32(_mm_cvtsi32_si128(*((_DWORD *)v22 + 12) - v23), v27, 1),
                              _mm_loadl_epi64((const __m128i *)(a2 + 116))).u64[0];
    *(_DWORD *)(a2 + 112) += (*(__int64 (__fastcall **)(RBX::Network::NetworkStream *))(*(_QWORD *)v22 + 24LL))(a1: v22); /*0x1067efc76*/
    *(_QWORD *)(a2 + 104) = _mm_add_epi32( /*0x1067efc94*/
                              _mm_insert_epi32(_mm_cvtepi8_epi32(16843009), v20, 1),
                              _mm_loadl_epi64((const __m128i *)(a2 + 104))).u64[0];
  }
  else
  {
    v22 = nullptr; /*0x1067efca1*/
    a1 = v36; /*0x1067efca4*/
  }
LABEL_28:
  *a1 = v22; /*0x1067efca8*/
  if ( v33 != nullptr ) /*0x1067efcb3*/
  {
    v34 = v33; /*0x1067efcb5*/
    operator delete(a1: (RBX::Memory *)v33, a2: v9); /*0x1067efcb9*/
  }
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v29); /*0x1067efcc5*/
  return a1; /*0x1067efccd*/
}

// Address: 0x1067efd4e | Name: __ZN3RBX7Network10Replicator14JoinDataItemV224areCachedStreamsCompleteEv
char __fastcall RBX::Network::Replicator::JoinDataItemV2::areCachedStreamsComplete(
        RBX::Network::Replicator::JoinDataItemV2 *this)
{
  __int64 v1; // rax

  v1 = *((_QWORD *)this + 17); /*0x1067efd4e*/
  if ( v1 != 0 ) /*0x1067efd58*/
    return *(_BYTE *)(v1 + 112); /*0x1067efd5e*/
  else
    return 0; /*0x1067efd63*/
}

// Address: 0x1067efd66 | Name: __ZN3RBX7Network10Replicator14JoinDataItemV223getReadyBitStreamSharedEv
RBX::Network::Replicator::JoinDataItemV2 *__fastcall RBX::Network::Replicator::JoinDataItemV2::getReadyBitStreamShared(
        RBX::Network::Replicator::JoinDataItemV2 *this,
        __int64 a2)
{
  unsigned __int64 v4; // r13
  char BatchNetAssetJoinEnabled; // al
  unsigned int *v6; // r12
  __int64 v7; // rcx
  unsigned int v8; // edx
  void *v9; // rdi
  unsigned int v10; // eax
  __int64 v11; // rsi
  __int64 v12; // rcx
  __int64 v13; // rdx
  void *v14; // rsi
  __int64 v15; // r15
  __int64 v16; // r12
  unsigned __int16 v17; // ax
  __int64 Factory; // rax
  void *v19; // rdi
  __int64 v20; // rax
  unsigned int v21; // edx
  __int64 v22; // rax
  __int64 v23; // rcx
  bool v24; // al
  _DWORD *v25; // r15
  void *v26; // rdi
  __int64 v27; // rax
  __int64 v28; // rdx
  __int64 v29; // rax
  __int64 v30; // rcx
  void *v31; // rdi
  __int64 v32; // rsi
  __int64 v33; // rdx
  __int64 v34; // rdx
  unsigned __int64 v36; // rax
  int v37; // ecx
  int v38; // eax
  void *v39[2]; // [rsp+0h] [rbp-40h] BYREF
  __int64 v40; // [rsp+10h] [rbp-30h]

  v4 = 0x2E8BA2E8BA2E8BA3LL /*0x1067efd9a*/
     * ((__int64)(*(_QWORD *)(*(_QWORD *)(a2 + 136) + 88LL) - *(_QWORD *)(*(_QWORD *)(a2 + 136) + 80LL)) >> 3);
  if ( (unsigned __int8)DFLog::ReplicationDataCaching >= 6u && BYTE1(DFLog::ReplicationDataCaching) >= 3u )
    FLog::FastLog(
      a1: *(_QWORD *)&DFLog::ReplicationDataCaching,
      a2: qword_10D7F3E28,
      a3: "[DFLog::ReplicationDataCaching] JoinDataItemV2::getReadyBitStream: readyBitstreamList size: %d",
      v4);
  *(_OWORD *)this = 0; /*0x1067efdd4*/
  if ( v4 <= *(unsigned int *)(a2 + 152) ) /*0x1067efde1*/
    return this; /*0x1067efde1*/
  BatchNetAssetJoinEnabled = RBX::Network::Replicator::getBatchNetAssetJoinEnabled( /*0x1067efdeb*/
                               this: *(RBX::Network::Replicator **)(a2 + 24),
                               (RBX::Network::Replicator *)a2);
  v6 = (unsigned int *)(a2 + 156); /*0x1067efdf0*/
  v7 = *(unsigned int *)(a2 + 152); /*0x1067efdf7*/
  v8 = *(_DWORD *)(a2 + 156); /*0x1067efdfe*/
  if ( BatchNetAssetJoinEnabled != 0 ) /*0x1067efe07*/
  {
    if ( v8 <= (unsigned int)v7 ) /*0x1067efe0f*/
    {
      RBX::Network::Replicator::JoinDataItemV2::serializeASharedStringVector( /*0x1067efe42*/
        a1: (RBX::Network::NetworkStream **)v39,
        a2,
        a3: (__int64 *)(*(_QWORD *)(*(_QWORD *)(a2 + 136) + 80LL) + 88 * v7 + 16),
        a4: (_QWORD *)(*(_QWORD *)(*(_QWORD *)(a2 + 136) + 80LL) + 88 * v7 + 64),
        a5: (int *)(a2 + 160));
      std::shared_ptr<RBX::Network::NetworkStream>::operator=[abi:ne200100]<RBX::Network::NetworkStream,std::default_delete<RBX::Network::NetworkStream>,0>( /*0x1067efe4e*/
        a1: this,
        a2: v39);
      v9 = v39[0]; /*0x1067efe53*/
      v39[0] = nullptr; /*0x1067efe57*/
      if ( v9 != nullptr ) /*0x1067efe62*/
        (*(void (__fastcall **)(void *))(*(_QWORD *)v9 + 8LL))(a1: v9); /*0x1067efe67*/
      v7 = *(unsigned int *)(a2 + 152); /*0x1067efe78*/
      if ( (__int64)(*(_QWORD *)(*(_QWORD *)(*(_QWORD *)(a2 + 136) + 80LL) + 88 * v7 + 24) /*0x1067efe98*/
                   - *(_QWORD *)(*(_QWORD *)(*(_QWORD *)(a2 + 136) + 80LL) + 88 * v7 + 16)) >> 3 == *(_DWORD *)(a2 + 160) )
      {
        *(_DWORD *)(a2 + 160) = 0; /*0x1067efe9a*/
        ++*v6; /*0x1067efea1*/
      }
    }
    if ( *(_QWORD *)this != 0 ) /*0x1067efea9*/
      goto LABEL_51; /*0x1067efea9*/
    v10 = *(_DWORD *)(a2 + 172); /*0x1067efeaf*/
    if ( v10 <= (unsigned int)v7 ) /*0x1067efeb8*/
    {
      v11 = (unsigned int)v7; /*0x1067efec5*/
      v12 = *(_QWORD *)(*(_QWORD *)(a2 + 136) + 80LL); /*0x1067efec7*/
      v13 = 88 * v11; /*0x1067efecb*/
      v14 = *(void **)(v12 + 88 * v11 + 40); /*0x1067efecf*/
      if ( v14 == *(void **)(v12 + v13 + 48) ) /*0x1067efed9*/
      {
        *(_DWORD *)(a2 + 172) = v10 + 1; /*0x1067f007e*/
      }
      else
      {
        *(_OWORD *)v39 = 0; /*0x1067efeea*/
        v40 = 0; /*0x1067efeee*/
        v15 = *(_QWORD *)(v12 + v13 + 40); /*0x1067efef6*/
        v16 = *(_QWORD *)(v12 + v13 + 48); /*0x1067efef9*/
        if ( v15 != v16 ) /*0x1067eff00*/
        {
          do /*0x1067eff51*/
          {
            if ( *(_QWORD *)v15 != 0 ) /*0x1067eff06*/
            {
              v17 = *(_WORD *)(v15 + 16); /*0x1067eff08*/
              if ( v17 != 0 ) /*0x1067eff10*/
              {
                Factory = RBX::Network::NetAssetManager::getFactory( /*0x1067eff27*/
                            this: *(RBX::Network::NetAssetManager **)(*(_QWORD *)(*(_QWORD *)(a2 + 24) + 11200LL) + 1456LL),
                            a2: v17);
                if ( Factory == 0 /*0x1067eff3c*/
                  || (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)Factory + 32LL))(a1: Factory) == 0 )
                {
                  std::vector<RBX::Network::NetAssetHandle>::push_back[abi:ne200100](a1: v39, a2: v15); /*0x1067eff45*/
                }
              }
            }
            v15 += 24; /*0x1067eff4a*/
          }
          while ( v15 != v16 ); /*0x1067eff51*/
          v19 = v39[0]; /*0x1067eff53*/
          if ( v39[0] != v39[1] ) /*0x1067eff5b*/
          {
            RBX::Network::Replicator::inlineNetAssets(a1: *(_QWORD *)(a2 + 24), a2: v39); /*0x1067eff65*/
            v19 = v39[0]; /*0x1067eff6a*/
          }
          if ( v19 != nullptr ) /*0x1067eff71*/
          {
            v39[1] = v19; /*0x1067eff73*/
            operator delete(a1: (RBX::Memory *)v19, a2: v14); /*0x1067eff77*/
          }
        }
        v20 = *(_QWORD *)this; /*0x1067eff7c*/
        ++*(_DWORD *)(a2 + 172); /*0x1067eff7f*/
        if ( v20 != 0 ) /*0x1067eff89*/
          goto LABEL_51; /*0x1067eff89*/
      }
    }
    v27 = *(unsigned int *)(a2 + 152); /*0x1067f0085*/
    if ( *(_DWORD *)(a2 + 164) > (unsigned int)v27 ) /*0x1067f0093*/
      goto LABEL_37; /*0x1067f0093*/
    v28 = *(_QWORD *)(*(_QWORD *)(a2 + 136) + 80LL); /*0x1067f00a3*/
    v29 = 88 * v27; /*0x1067f00a7*/
    v30 = *(_QWORD *)(v28 + v29 + 40); /*0x1067f00ab*/
    if ( v30 == *(_QWORD *)(v28 + v29 + 48) ) /*0x1067f00b5*/
    {
      v24 = false; /*0x1067f011d*/
      v34 = v30; /*0x1067f011f*/
    }
    else
    {
      RBX::Network::Replicator::JoinDataItemV2::serializeBatchedNetAssetVector( /*0x1067f00cc*/
        a1: (RBX::Network::NetworkStream **)v39,
        a2,
        a3: (__int64 *)(v29 + v28 + 40),
        a4: (int *)(a2 + 168));
      std::shared_ptr<RBX::Network::NetworkStream>::operator=[abi:ne200100]<RBX::Network::NetworkStream,std::default_delete<RBX::Network::NetworkStream>,0>( /*0x1067f00d8*/
        a1: this,
        a2: v39);
      v31 = v39[0]; /*0x1067f00dd*/
      v39[0] = nullptr; /*0x1067f00e1*/
      if ( v31 != nullptr ) /*0x1067f00ec*/
        (*(void (__fastcall **)(void *))(*(_QWORD *)v31 + 8LL))(a1: v31); /*0x1067f00f1*/
      v24 = *(_QWORD *)this != 0; /*0x1067f00f8*/
      v32 = *(_QWORD *)(*(_QWORD *)(a2 + 136) + 80LL); /*0x1067f0109*/
      v33 = 88LL * *(unsigned int *)(a2 + 152); /*0x1067f010d*/
      v30 = *(_QWORD *)(v32 + v33 + 40); /*0x1067f0111*/
      v34 = *(_QWORD *)(v32 + v33 + 48); /*0x1067f0116*/
    }
    if ( *(_DWORD *)(a2 + 168) < (signed int)(-1431655765 * ((unsigned __int64)(v34 - v30) >> 3)) ) /*0x1067f0136*/
      goto LABEL_48; /*0x1067f0136*/
    v6 = (unsigned int *)(a2 + 164); /*0x1067f0138*/
    v25 = (_DWORD *)(a2 + 168); /*0x1067f013f*/
    goto LABEL_45; /*0x1067f013f*/
  }
  if ( v8 <= (unsigned int)v7 ) /*0x1067eff96*/
  {
    v25 = (_DWORD *)(a2 + 160); /*0x1067f0001*/
    RBX::Network::Replicator::JoinDataItemV2::serializeASharedStringVector( /*0x1067f0012*/
      a1: (RBX::Network::NetworkStream **)v39,
      a2,
      a3: (__int64 *)(*(_QWORD *)(*(_QWORD *)(a2 + 136) + 80LL) + 88 * v7 + 16),
      a4: (_QWORD *)(*(_QWORD *)(*(_QWORD *)(a2 + 136) + 80LL) + 88 * v7 + 64),
      a5: (int *)(a2 + 160));
    std::shared_ptr<RBX::Network::NetworkStream>::operator=[abi:ne200100]<RBX::Network::NetworkStream,std::default_delete<RBX::Network::NetworkStream>,0>( /*0x1067f001e*/
      a1: this,
      a2: v39);
    v26 = v39[0]; /*0x1067f0023*/
    v39[0] = nullptr; /*0x1067f0027*/
    if ( v26 != nullptr ) /*0x1067f0032*/
      (*(void (__fastcall **)(void *))(*(_QWORD *)v26 + 8LL))(a1: v26); /*0x1067f0037*/
    v24 = false; /*0x1067f0065*/
    if ( (__int64)(*(_QWORD *)(*(_QWORD *)(*(_QWORD *)(a2 + 136) + 80LL) + 88LL * *(unsigned int *)(a2 + 152) + 24) /*0x1067f006a*/
                 - *(_QWORD *)(*(_QWORD *)(*(_QWORD *)(a2 + 136) + 80LL) + 88LL * *(unsigned int *)(a2 + 152) + 16)) >> 3 != *(_DWORD *)(a2 + 160) )
      goto LABEL_48; /*0x1067f006a*/
LABEL_45:
    *v25 = 0; /*0x1067f0146*/
    goto LABEL_46; /*0x1067f0146*/
  }
  v21 = *(_DWORD *)(a2 + 172); /*0x1067eff98*/
  if ( v21 <= (unsigned int)v7 ) /*0x1067effa1*/
  {
    v6 = (unsigned int *)(a2 + 172); /*0x1067effa7*/
    v22 = *(_QWORD *)(*(_QWORD *)(a2 + 136) + 80LL); /*0x1067effb5*/
    v23 = 88 * v7; /*0x1067effb9*/
    if ( *(_QWORD *)(v22 + v23 + 40) == *(_QWORD *)(v22 + v23 + 48) ) /*0x1067effc7*/
    {
      v24 = false; /*0x1067f0075*/
LABEL_47:
      *v6 = v21 + 1; /*0x1067f0151*/
      goto LABEL_48; /*0x1067f0153*/
    }
    RBX::Network::Replicator::inlineNetAssets(a1: *(_QWORD *)(a2 + 24), a2: v22 + v23 + 40); /*0x1067effd9*/
    v24 = false; /*0x1067effde*/
LABEL_46:
    v21 = *v6; /*0x1067f014d*/
    goto LABEL_47; /*0x1067f014d*/
  }
LABEL_37:
  v24 = false; /*0x1067f0095*/
LABEL_48:
  if ( *(_QWORD *)this != 0 ) /*0x1067f015b*/
  {
    if ( v24 ) /*0x1067f015f*/
    {
      ++*(_DWORD *)(a2 + 92); /*0x1067f0161*/
      return this; /*0x1067f0165*/
    }
LABEL_51:
    ++*(_DWORD *)(a2 + 76); /*0x1067f0167*/
    return this; /*0x1067f0167*/
  }
  v36 = *(unsigned int *)(a2 + 152); /*0x1067f017d*/
  if ( v4 > v36 ) /*0x1067f0187*/
  {
    std::shared_ptr<RBX::Network::NetworkStream>::operator=[abi:ne200100]( /*0x1067f019b*/
      a1: this,
      a2: *(_QWORD *)(*(_QWORD *)(a2 + 136) + 80LL) + 88 * v36);
    ++*(_DWORD *)(a2 + 152); /*0x1067f01a0*/
    v37 = *(_DWORD *)(a2 + 128); /*0x1067f01a7*/
    v38 = *(_DWORD *)(a2 + 132); /*0x1067f01ae*/
    if ( v37 != 0 ) /*0x1067f01b7*/
    {
      if ( v38 != 0 ) /*0x1067f01bb*/
        *(_DWORD *)(a2 + 132) = v38 - 1; /*0x1067f01bf*/
      *(_DWORD *)(a2 + 128) = v37 - 1; /*0x1067f01c8*/
    }
    else if ( v38 != 0 ) /*0x1067f01d3*/
    {
      *(_DWORD *)(a2 + 132) = v38 - 1; /*0x1067f01d7*/
    }
    else
    {
      *(_BYTE *)(*(_QWORD *)(a2 + 24) + 15552LL) = 1; /*0x1067f01e4*/
    }
  }
  return this; /*0x1067f016e*/
}

// Address: 0x1067f02c8 | Name: __ZN3RBX7Network10Replicator14JoinDataItemV221isPacketReadyToBeSentEv
bool __fastcall RBX::Network::Replicator::JoinDataItemV2::isPacketReadyToBeSent(
        RBX::Network::Replicator::JoinDataItemV2 *this)
{
  __int64 v1; // rax

  v1 = *(_QWORD *)(*((_QWORD *)this + 17) + 88LL) - *(_QWORD *)(*((_QWORD *)this + 17) + 80LL); /*0x1067f02d7*/
  return v1 != 0 && 0x2E8BA2E8BA2E8BA3LL * (v1 >> 3) > (unsigned __int64)*((unsigned int *)this + 38); /*0x1067f02ff*/
}

// Address: 0x1067f10a6 | Name: __ZNK3RBX7Network10Replicator14JoinDataItemV211getSendModeEv
__int64 __fastcall RBX::Network::Replicator::JoinDataItemV2::getSendMode(
        RBX::Network::Replicator::JoinDataItemV2 *this)
{
  return 0; /*0x1067f10ac*/
}

// Address: 0x1067f10ae | Name: __ZNK3RBX7Network10Replicator14JoinDataItemV27getTypeEv
__int64 __fastcall RBX::Network::Replicator::JoinDataItemV2::getType(RBX::Network::Replicator::JoinDataItemV2 *this)
{
  return 22; /*0x1067f10b7*/
}

// END JoinDataItemV2 part 1/1, 16 functions
