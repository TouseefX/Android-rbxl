# 0.735 — Reply2 / Rupp / Capabilities context notes (companion to this ZIP)

Build: **0.735 Studio, Mac symbols, 2026-08** (same build as all previous zips — no 0.740 exists in this dump).

## Items 1 & 3 — "raw assembly" cannot be produced from this dataset

The export is **Hex-Rays pseudocode only**: 22,705 archive entries, every content file is a `.c` listing with `// Address:` / `Name:` headers and per-statement `/*0x...*/` annotations. **There is no disassembly text, no `.asm`, no binary.** Register-level evidence for `0x1039c5c89` and `0x1039e1cd0-0x1039e1cf0` can only come from the IDA database that produced the export (same addresses — flip to Text/Graph view at those addresses).

However, the pseudocode at those exact ranges is fully address-annotated, and the operands you asked about are recoverable from context. Verbatim transcripts below; resolutions after.

---

## Item 1 — `RakPeer::processRbxOpenReply2`, 0x1039c5c20–0x1039c5ca6 (RakPeer.c, fn @ 0x1039c5404)

```c
        *(_BYTE *)(v31 + 1) = 1;                     /*0x1039c5c05*/
        *(_DWORD *)(v31 + 5364) = 4;                 /*0x1039c5c0a*/
        v37 = *(_DWORD *)(v14 + 336);                /*0x1039c5c15*/
        if ( v37 != 0 )                              /*0x1039c5c1e*/
          RakNet::ReliabilityLayer::SetTimeoutTime(this: (RakNet::ReliabilityLayer *)(v31 + 392), a2: v37); /*0x1039c5c27*/
        RakNet::RakPeer::sendApplicationConnectionRequest(this); /*0x1039c5c3c*/
        goto LABEL_58;                               /*0x1039c5c41*/
        ...
        if ( BYTE1(DFLog::SessionCrypto) >= 3u && (unsigned __int8)DFLog::SessionCrypto >= 6u ) /*0x1039c5c53*/
          FLog::FastLog(a1: DFLog::SessionCrypto, a2: qword_10D7BB210,
                        a3: "[DFLog::SessionCrypto] RbxOpenReply2 too many recent connections", 0); /*0x1039c5c6f*/
        RakNet::RakPeer::applicationConnectionFailed(this); /*0x1039c5c81*/
        v31 = 0;                                     /*0x1039c5c86*/
LABEL_58:
        std::shared_ptr<RBX::Rupp::Rupp>::operator=[abi:ne200100](a1: v31 + 5280); /*0x1039c5c89*/
        v59 = (RakNet::RakPeer *)((char *)this + 1160); /*0x1039c5ca6*/   // +1160 = remoteSystemList mutex
```

**Resolution of the dropped `operator=` source:**

- `v31` is a `RemoteSystemStruct*`. Independently confirmed: `AssignSystemAddressToRemoteSystemList(...)` returns it at **0x1039c5bca**; the remote-system array uses a stride of **5368** (`v29 = 5368LL * RemoteSystemIndex` @ 0x1039c59ff, and `v31 = v29 + v30` @ 0x1039c5a3c on the reuse path). So **RemoteSystemStruct + 5280 = the `shared_ptr<Rupp>` member**, +5364 = a `uint32` state field (set to 4), +1 = activation byte, +392 = embedded ReliabilityLayer.
- The `v31 = 0; /*0x1039c5c86*/` immediately before `LABEL_58` is a **Hex-Rays phi-merge artifact**, not real code: on the failure path it would write through `0 + 5280` and crash. In the real control flow the success path (`goto LABEL_58 @ 0x1039c5c41`) and failure path each have their own assignment; the shared label hid it.
- The dropped source is a **local `shared_ptr<Rupp>`** built earlier in Reply2. The Rupp-carrying entity in this function is `v14 = RequestedConnectionStruct` (`v61 = v14 + 360` at 0x1039c566e holds its `shared_ptr<RakPeerCrypto>`, passed to `clientInitEphemeralSessionKeys` @ 0x1039c5926 and copied into local `v55` @ 0x1039c5acb). The Rupp shared_ptr assigned into the RSS at +5280 is the request's outer RUPP header (kept so connected-mode sends reuse the same TLV set / token).

## Item 4 — `RakPeer::getRuppHeader`, both overloads (RakPeer.c)

There are **zero call sites** of `getRuppHeader` anywhere in the export (tree-wide; names not invoked — they are either inlined at all uses or kept for ABI). No "caller immediately before the Reply2 remote assignment" exists; the Reply2 Rupp assignment is the `operator=` at 0x1039c5c89 above.

```c
// Address: 0x1039c256c | Name: __ZN6RakNet7RakPeer13getRuppHeaderEPKNS0_18RemoteSystemStructE
// getRuppHeader(const RemoteSystemStruct*)  — rdi = sret(shared_ptr<Rupp> out), second arg = RSS
RakPeer* getRuppHeader(RakPeer* out, const RemoteSystemStruct* rss) {
  *(_OWORD *)out = 0;                                 /*0x1039c2578*/  // null shared_ptr
  if ( a3 != 0 )                                      /*0x1039c257e*/  // decompiler's 3rd hidden arg
    std::shared_ptr<RBX::Rupp::Rupp>::operator=(a1: out /*a2 dropped: rss's shared_ptr field*/); /*0x1039c258d*/
  return out;                                         /*0x1039c2599*/
}
// ('a3' is Hex-Rays recovering the RSS->rupp strong-count pointer as a phantom
//  parameter — the body nulls the out shared_ptr, then copies the RSS's member
//  shared_ptr<Rupp> in, with the usual refcount bump.)

// Address: 0x1039d0f04 | Name: __ZN6RakNet7RakPeer13getRuppHeaderEv
// getRuppHeader() — rdi = sret(out), rsi = real RakPeer* this (Hex-Rays labeled them this/a2)
RakPeer* getRuppHeader(RakPeer* out /*mislabeled this*/, RakPeer* this /*mislabeled a2*/) {
  v3 = *(_QWORD *)(this + 3304);                      /*0x1039d0f07*/  // strong-count ptr of stored shared_ptr
  *(_OWORD *)out = *(_OWORD *)(this + 3296);          /*0x1039d0f15*/  // copy ptr+ctrl of **RakPeer::this + 3296**
  if ( v3 != 0 ) _InterlockedIncrement64((v3 + 8));   /*0x1039d0f1b*/   // ++strong ref
  return out;                                         /*0x1039d0f27*/
}
```

So: **RakPeer holds its own template `shared_ptr<Rupp>` at this+3296** (strong-count word at +3304); the per-connection copy lives at **RemoteSystemStruct+5280**. (Also handy at 0x1039d0f46: `RakPeer::overrideCapabilities(uint64)` writes `this+387*8` = +3096.)

---

## Item 3 — `ReliabilityLayer::SendBitStream` encryption boundary (ReliabilityLayer.c, fn @ 0x1039e1a0e)

```c
  HeaderTotalByteLength = (*(*a4 + 24))(a4);          /*0x1039e1a49*/   // BitStream::GetNumberOfBytesUsed
  v12 = HeaderTotalByteLength;                        /*0x1039e1a4c*/   // v12 = total datagram bytes (RUPP header included)
  if ( *a6 != nullptr )                               /*0x1039e1a55*/   // a6 = shared_ptr<Rupp>* param of SendBitStream
    v13 = (unsigned __int16)Rupp::getHeaderTotalByteLength(*a6);  /*0x1039e1a57-5c*/  // v13 = RUPP header bytes
  else
    v13 = 0;                                          /*0x1039e1a62*/
  v14 = *(SessionCrypto **)this;                      /*0x1039e1a65*/   // ReliabilityLayer+0 = SessionCrypto*
  v15 = (*this == 0);
  v43 = v13;                                          /*0x1039e1a6b*/
  if ( v15 || !SessionCrypto::getEnabledForRaknet(v14) ) {          /*0x1039e1a7c*/
    // cleartext path
  } else {
    v41 = (*(*a4 + 16))(a4);                          /*0x1039e1a8b*/   // BitStream DATA BASE POINTER
    BitStream::PadWithZeroToByteLength(a4, v12 + 18); /*0x1039e1a99*/   // append 18 bytes of slack
    ...                                               /* SlidingWindow4 stats path 0x1039e1aa5–0x1039e1ae0 */
    v12 = (*(*a4 + 24))(a4);                          /*0x1039e1aeb*/   // reread: now INCLUDES the +18 pad
    if ( DFFlag::RakNetUseSlidingWindow4 ) {
      v20 = v43;                                      /*0x1039e1b0b*/  // = v13 = RUPP header length
      v21 = (*(*a4 + 16))(a4) + v43;                  /*0x1039e1b0f*/   // base + ruppLen (same start ptr)
      ...
    } else {
      v20 = v13;                                      /*0x1039e1cd6*/
    }
    v34 = RBX::Security::SessionCrypto::encryptRakDataInPlace(
            a1: *(_QWORD *)this,                      // SessionCrypto*
            a2: v20 + v41,                            // START  = BitStream data base + RUPP-header byte length
            a3: v12 - v13);                           // LENGTH = total bytes used (incl. +18 pad) − RUPP-header length
                                                        /*0x1039e1ce9*/
```

**Conclusive, no register speculation needed:**

- **Encryption start pointer = datagram base + `Rupp::getHeaderTotalByteLength()`** — the outer RUPP header is excluded and stays cleartext.
- **Byte count = totalBytesUsed − ruppHeaderLength**, where totalBytesUsed is read **after** `PadWithZeroToByteLength(len + 18)` — i.e. ciphertext length = plaintext-after-RUPP + **18 bytes overhead** (your "18-byte normal RakNet crypto format": tag/nonce trailer written into the slack).
- Sender-side crypto object is `*(SessionCrypto**)ReliabilityLayer+0`, gated by `SessionCrypto::getEnabledForRaknet()`.

---

## Item 2 — `RakNet::buildCapabilitiesHelper(uint64_t& caps, Network::PeerType)` @ 0x1039b42a5

Definition is in **`_external/_r/RakNet.c`** (in this ZIP — file also has GetTime/GetTimeUS etc). Full function body below the table. Callers found in the whole dump:

| caller | site | PeerType arg | meaning |
|---|---|---|---|
| `processRbxOpenRequest2` @ 0x1039c3f6c | 0x1039c4a7f | `1` | **server** builds its caps for reply-processing |
| `processRbxOpenReply2` @ 0x1039c5404 | 0x1039c58e9 | `0` | NetworkTrace log only (`"Peer has capabilities: 0x%llx, common capabilities: 0x%llx"`) |
| `sendRbxOpenRequest2` @ 0x1039ce472 | 0x1039ce61e | `0` | **client** builds caps serialized into Request2 |
| `_free/_free_b.part002.c` | 0x1039b62e6 | (1 arg — arg tracking failed) | `buildRakPeerCapabilities` wrapper (already in the P1 zip) |

`PeerType`: `0` = client path, `1` = server path (server call passes 1, client call passes 0).

### Bit semantics (all OR-accumulated into `*caps`)

| mask | bit(s) | source |
|---|---|---|
| `0xC2` | 1,6,7 | **unconditional** (`0x1C2` — adds bit 8 — iff `DFFlag::DebugForceStreamingEnabled`) |
| `AvatarChatProtocolV1<<38` | 38 | FFlag::AvatarChatProtocolV1 |
| `4*VoxelGridLeanDM` | 2 | FFlag::VoxelGridLeanDM |
| `0x20000B10A30` (+bit10) | 4,5,9,11,16,20,21,23,41 | **unconditional**, bit 10 added iff `DFFlag::CLI139085` (→ `0x20000B10E30`) |
| `8*(PeerType<2)` | 3 | **always set** for both client and server (both < 2) |
| `RaknetPacketTracing<<19` | 19 | DFFlag::RaknetPacketTracing |
| `0x2E000` (+bit42) | 13,14,15,17 | **unconditional**, bit 42 added iff `FFlag::DebugEnableStreamOutToDisk` (→ `0x4000002E000`) |
| `0x80000000000` | 43 | iff `FFlag::EnableStreamingBitStreamStateFlags` |
| `0x100000000000` | 44 | iff `FFlag::EnableSharedStringCaching` |
| `SimParentPrimSpacePVsRead<<45` | 45 | DFFlag::SimParentPrimSpacePVsRead |
| `0x40000` | 18 | **unconditional** |
| `0x440000` / `0x2440000` | 18,22 ( / +25) | iff compression on: `AddCompressionInConnectionInternalSend && !DebugDisableCompressionInConnectionInternalSend`; `0x2440000` iff also `PartiallyCompressPhysicsPackets` |
| `0x800000000` | 35 | above branch, iff additionally `DFFlag::AddHashToCompressedPayload` |
| `0x4000000` | 26 | iff `FFlag::ServerTimeItem` |
| `0x18000000` / `0x38000000` | 27,28 (+29) | `0x38000000` iff `BugfixCLI184305 && EnableNetAssetProxiesCache`, else `0x18000000` — one of the two is always present |
| `0x80000000` | 31 | iff `DFFlag::BatchNetAssetJoinBlob` |
| `0x400000000` | 34 | iff `DFFlag::ServerAuthorityEnableInputLatency` |
| `0x1000000000000` | 48 | iff `DFFlag::ReplicateCameraStateForSA` |
| `0x40000000000000` | 54 | iff `FFlag::PlayerControlStateEnabled` |
| `bit61` | 61 | `DebugNetworkProfilerForce \| (DebugNetworkProfiler & (PeerType==1))` — server-only second term |
| `0x400000000000` | 46 | iff `DebugAddTestStreamingFrustum` OR (`StreamingObserverUsesOctree && UseExpandedSpatialQueryShapes && UseCoreSpatialQueryShapesForGC && EnableFrustumAutomation`) |
| `0x2000000000` | 37 | iff `FFlag::SupportGcRegionQuotaSource` |
| `0x300000000` | 32,33 | **unconditional** |
| `0x8300000000` | 32,33,39 | iff `FFlag::ReplicateFocusTargetRadius` (adds bit 39) |
| `0x800000000000` | 47 | iff `DFFlag::AndroidSurfaceCompositor` |
| `0x8000000000000` | 51 | iff `DFFlag::PingItemReportClientMemory` |
| `0x4000000000000` | 50 | iff `DFFlag::EvictDynamicMetadata` |
| `0x10000000000000` | 52 | iff `TagRuleReplicationPipelineEnabled && TagRuleCoreEnabled` |
| `0x20000000000000` | 53 | iff `DFFlag::UseCompressedPVSerialization` |
| `0x40000000` | 30 | **unconditional** |

### Floor constant (client, every gate OFF)

`0xC2 | 0x20000B10A30 | 0x8 | 0x2E000 | 0x40000 | 0x40000000 | 0x300000000 | 0x18000000` = **`0x20358B7EAFA`** (with `DFFlag::CLI139085==1` → `0x20358B7EEFA`). Every other bit above this floor is flag-gated per the table; evaluate with the shipping flag set to get the deployed client value. (Bits 27,28 are effectively always set — the code ORs `0x18000000` unconditionally, swapping in the wider `0x38000000` only when `BugfixCLI184305 && EnableNetAssetProxiesCache`.)

> Note the drift vs 2022: in the 2022 build the caps included a streaming-enabled bit and compression bits 18/22/25 as well, but the exact constants and the `PeerType<2` bit-3 gate are 0.735-specific. Use this table, not the 2022 one.
