// IdSerializer -- 2022 Studio + full PDB
// tier 3, 11 functions


// Address: 0x141132c60 | Name: ??0IdSerializer@Network@RBX@@QEAA@XZ
RBX::Network::IdSerializer *__fastcall RBX::Network::IdSerializer::IdSerializer(RBX::Network::IdSerializer *this)
{
  RBX::Instance::Instance(this); /*0x141132c69*/
  this->__vftable = (RBX::Network::IdSerializer_vtbl *)RBX::Network::IdSerializer::`vftable'; /*0x141132c75*/
  this->guidRegistry.px = nullptr; /*0x141132c7a*/
  this->guidService = nullptr; /*0x141132c81*/
  this->localPeerId = -1; /*0x141132c8b*/
  return this; /*0x141132c95*/
}

// Address: 0x141132cd0 | Name: ?canSerializeId@IdSerializer@Network@RBX@@QEAA_NPEBVInstance@3@@Z
char __fastcall RBX::Network::IdSerializer::canSerializeId(
        RBX::Network::IdSerializer *this,
        const RBX::Instance *instance)
{
  if ( instance == nullptr ) /*0x141132cd7*/
    return 0; /*0x141132cec*/
  RBX::GuidItem<RBX::Instance>::Registry::reg(this: this->guidRegistry.px, item: instance); /*0x141132ce0*/
  return 1; /*0x141132ce7*/
}

// Address: 0x141132d00 | Name: ?deserializeId@IdSerializer@Network@RBX@@QEAA?AVGuid@3@AEAVNetworkStream@23@@Z
RBX::Guid *__fastcall RBX::Network::IdSerializer::deserializeId(
        RBX::Network::IdSerializer *this,
        RBX::Guid *result,
        RBX::Network::NetworkStream *stream)
{
  RBX::Guid::Scope scope; // [rsp+30h] [rbp+8h] BYREF
  int index; // [rsp+48h] [rbp+20h] BYREF

  RBX::Network::deserializeGuidScope(result: &scope, stream, localPeerId: this->localPeerId); /*0x141132d1f*/
  if ( scope.peerId.peerId == -1 ) /*0x141132d29*/
  {
    result->scope.peerId.peerId = -1; /*0x141132d2b*/
    result->index = 0; /*0x141132d34*/
    return result; /*0x141132d31*/
  }
  else
  {
    index = 0; /*0x141132d4c*/
    RBX::Network::NetworkStream::readBytes(this: stream, inOutByteArray: &index, numberOfBytesToRead: 4u); /*0x141132d5c*/
    result->scope = scope; /*0x141132d65*/
    result->index = index; /*0x141132d6b*/
    return result; /*0x141132d6e*/
  }
}

// Address: 0x141132d80 | Name: ?deserializeInstanceRef@IdSerializer@Network@RBX@@QEAA_NAEAVNetworkStream@23@AEAV?$shared_ptr@VInstance@RBX@@@std@@AEAVGuid@3@@Z
bool __fastcall RBX::Network::IdSerializer::deserializeInstanceRef(
        RBX::Network::IdSerializer *this,
        RBX::Network::NetworkStream *stream,
        std::shared_ptr<RBX::Instance> *instance,
        RBX::Guid *id)
{
  unsigned int peerId; // eax
  int v9; // edx
  RBX::Guid::Scope v11; // [rsp+40h] [rbp+8h] BYREF
  int inOutByteArray; // [rsp+58h] [rbp+20h] BYREF

  RBX::Network::deserializeGuidScope(result: &v11, stream, localPeerId: this->localPeerId); /*0x141132da4*/
  peerId = -1; /*0x141132da9*/
  v9 = 0; /*0x141132dae*/
  if ( v11.peerId.peerId != -1 ) /*0x141132db4*/
  {
    inOutByteArray = 0; /*0x141132db6*/
    RBX::Network::NetworkStream::readBytes(this: stream, &inOutByteArray, numberOfBytesToRead: 4u); /*0x141132dc6*/
    peerId = v11.peerId.peerId; /*0x141132dcb*/
    v9 = inOutByteArray; /*0x141132dcf*/
  }
  id->index = v9; /*0x141132dd3*/
  id->scope.peerId.peerId = peerId; /*0x141132dd9*/
  return RBX::GuidItem<RBX::Instance>::Registry::lookupByGuid(this: this->guidRegistry.px, guid: id, result: instance); /*0x141132de5*/
}

// Address: 0x141132e00 | Name: ?deserializeInstanceRefNoLock@IdSerializer@Network@RBX@@QEAA_NAEAVNetworkStream@23@AEAV?$shared_ptr@VInstance@RBX@@@std@@AEAVGuid@3@@Z
bool __fastcall RBX::Network::IdSerializer::deserializeInstanceRefNoLock(
        RBX::Network::IdSerializer *this,
        RBX::Network::NetworkStream *stream,
        std::shared_ptr<RBX::Instance> *instance,
        RBX::Guid *id)
{
  unsigned int peerId; // eax
  int v9; // edx
  RBX::Guid::Scope v11; // [rsp+40h] [rbp+8h] BYREF
  int inOutByteArray; // [rsp+58h] [rbp+20h] BYREF

  RBX::Network::deserializeGuidScope(result: &v11, stream, localPeerId: this->localPeerId); /*0x141132e24*/
  peerId = -1; /*0x141132e29*/
  v9 = 0; /*0x141132e2e*/
  if ( v11.peerId.peerId != -1 ) /*0x141132e34*/
  {
    inOutByteArray = 0; /*0x141132e36*/
    RBX::Network::NetworkStream::readBytes(this: stream, &inOutByteArray, numberOfBytesToRead: 4u); /*0x141132e46*/
    peerId = v11.peerId.peerId; /*0x141132e4b*/
    v9 = inOutByteArray; /*0x141132e4f*/
  }
  id->index = v9; /*0x141132e53*/
  id->scope.peerId.peerId = peerId; /*0x141132e59*/
  return RBX::GuidItem<RBX::Instance>::Registry::lookupByGuidNoLock( /*0x141132e65*/
           this: this->guidRegistry.px,
           guid: id,
           result: instance);
}

// Address: 0x141132e80 | Name: ?initializeIdSerializer@IdSerializer@Network@RBX@@QEAAXPEAVServiceProvider@3@@Z
void __fastcall RBX::Network::IdSerializer::initializeIdSerializer(
        RBX::Network::IdSerializer *this,
        RBX::ServiceProvider *provider)
{
  RBX::Network::GuidRegistryService *v3; // rax
  RBX::GuidItem<RBX::Instance>::Registry *px; // rcx
  RBX::GuidItem<RBX::Instance>::Registry *v5; // rax
  boost::intrusive_ptr<RBX::GuidItem<RBX::Instance>::Registry> v6; // [rsp+30h] [rbp+8h] BYREF

  if ( provider != nullptr ) /*0x141132e90*/
    v3 = RBX::ServiceProvider::create<RBX::Network::GuidRegistryService>(this: provider); /*0x141132e95*/
  else
    v3 = nullptr; /*0x141132e9c*/
  this->guidService = v3; /*0x141132ea5*/
  boost::intrusive_ptr<RBX::GuidItem<RBX::Instance>::Registry>::reset(this: &this->guidRegistry); /*0x141132eac*/
  px = this->guidService->registry.px; /*0x141132eb8*/
  if ( px != nullptr ) /*0x141132ec2*/
    _InterlockedIncrement(&px->refs._Storage._Value); /*0x141132ec4*/
  v5 = this->guidRegistry.px; /*0x141132ec7*/
  this->guidRegistry.px = px; /*0x141132ece*/
  v6.px = v5; /*0x141132eda*/
  boost::intrusive_ptr<RBX::GuidItem<RBX::Instance>::Registry>::~intrusive_ptr<RBX::GuidItem<RBX::Instance>::Registry>(this: &v6); /*0x141132edf*/
}

// Address: 0x141133060 | Name: ?onServiceProvider@IdSerializer@Network@RBX@@MEAAXPEAVServiceProvider@3@0@Z
void __fastcall RBX::Network::IdSerializer::onServiceProvider(
        RBX::Network::IdSerializer *this,
        RBX::ServiceProvider *oldProvider,
        RBX::ServiceProvider *newProvider)
{
  boost::intrusive_ptr<RBX::GuidItem<RBX::Instance>::Registry> *p_guidRegistry; // rdi
  RBX::Network::GuidRegistryService *v7; // rax
  volatile signed __int32 *p_Value; // rcx
  RBX::GuidItem<RBX::Instance>::Registry *px; // rax
  RBX::GuidItem<RBX::Instance>::Registry *v10; // rbx
  std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Guid const ,std::weak_ptr<RBX::Instance> > > > > *Myfirst; // rcx
  std::_List_node<std::pair<RBX::Guid const ,std::weak_ptr<RBX::Instance> >,void *> *Myhead; // rcx
  std::_List_node<std::pair<RBX::Guid const ,std::weak_ptr<RBX::Instance> >,void *> *Next; // rdi
  volatile signed __int32 *Rep; // rcx
  std::_List_node<std::pair<RBX::Guid const ,std::weak_ptr<RBX::Instance> >,void *> *v15; // rsi
  boost::intrusive_ptr<RBX::GuidItem<RBX::Instance>::Registry> v16; // [rsp+48h] [rbp+10h] BYREF

  p_guidRegistry = &this->guidRegistry; /*0x14113306c*/
  boost::intrusive_ptr<RBX::GuidItem<RBX::Instance>::Registry>::reset(this: &this->guidRegistry); /*0x14113307f*/
  RBX::Instance::onServiceProvider(this, oldProvider, newProvider); /*0x14113308d*/
  if ( newProvider != nullptr ) /*0x141133095*/
  {
    v7 = RBX::ServiceProvider::create<RBX::Network::GuidRegistryService>(this: newProvider); /*0x14113309a*/
    this->guidService = v7; /*0x14113309f*/
    p_Value = &v7->registry.px->refs._Storage._Value; /*0x1411330a6*/
    if ( p_Value != nullptr ) /*0x1411330b0*/
      _InterlockedIncrement(p_Value); /*0x1411330b2*/
    px = p_guidRegistry->px; /*0x1411330b5*/
    p_guidRegistry->px = (RBX::GuidItem<RBX::Instance>::Registry *)p_Value; /*0x1411330b8*/
    v16.px = px; /*0x1411330c0*/
    boost::intrusive_ptr<RBX::GuidItem<RBX::Instance>::Registry>::~intrusive_ptr<RBX::GuidItem<RBX::Instance>::Registry>(this: &v16); /*0x1411330c5*/
  }
  if ( oldProvider != nullptr && newProvider == nullptr ) /*0x1411330d6*/
  {
    v10 = p_guidRegistry->px; /*0x1411330dc*/
    p_guidRegistry->px = nullptr; /*0x1411330e1*/
    if ( v10 != nullptr && _InterlockedExchangeAdd(&v10->refs._Storage._Value, 0xFFFFFFFF) == 1 ) /*0x1411330f9*/
    {
      Mtx_destroy_in_situ_0(a1: (_Mtx_t)&v10->mx); /*0x141133103*/
      Myfirst = v10->map._Vec._Mypair._Myval2._Myfirst; /*0x141133108*/
      if ( (((char *)v10->map._Vec._Mypair._Myval2._Mylast - (char *)Myfirst) & 0xFFFFFFFFFFFFFFF8uLL) >= 0x1000 ) /*0x14113311e*/
      {
        if ( (unsigned __int64)((char *)Myfirst - (char *)Myfirst[-1]._Ptr - 8) > 0x1F ) /*0x141133133*/
          _invalid_parameter_noinfo_noreturn(); /*0x1411331be*/
        Myfirst = (std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Guid const ,std::weak_ptr<RBX::Instance> > > > > *)Myfirst[-1]._Ptr; /*0x141133139*/
      }
      operator delete(ptr: Myfirst); /*0x14113313c*/
      v10->map._Vec._Mypair._Myval2._Myfirst = nullptr; /*0x141133141*/
      v10->map._Vec._Mypair._Myval2._Mylast = nullptr; /*0x141133145*/
      v10->map._Vec._Mypair._Myval2._Myend = nullptr; /*0x141133149*/
      Myhead = v10->map._List._Mypair._Myval2._Myhead; /*0x14113314d*/
      Myhead->_Prev->_Next = nullptr; /*0x141133155*/
      Next = Myhead->_Next; /*0x141133158*/
      if ( Myhead->_Next != nullptr ) /*0x14113315e*/
      {
        do /*0x141133194*/
        {
          Rep = (volatile signed __int32 *)Next->_Myval.second._Rep; /*0x141133160*/
          v15 = Next->_Next; /*0x141133164*/
          if ( Rep != nullptr && _InterlockedExchangeAdd(Rep + 3, 0xFFFFFFFF) == 1 ) /*0x141133179*/
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)Rep + 8LL))(a1: Rep); /*0x14113317e*/
          operator delete(ptr: Next); /*0x141133189*/
          Next = v15; /*0x14113318e*/
        }
        while ( v15 != nullptr ); /*0x141133194*/
      }
      operator delete(ptr: v10->map._List._Mypair._Myval2._Myhead); /*0x14113319f*/
      operator delete(ptr: v10); /*0x1411331ac*/
    }
  }
}

// Address: 0x1411331d0 | Name: ?sendId@IdSerializer@Network@RBX@@QEAAXAEAVNetworkStream@23@AEBUId@123@@Z
void __fastcall RBX::Network::IdSerializer::sendId(
        RBX::Network::IdSerializer *this,
        RBX::Network::NetworkStream *stream,
        const RBX::Network::IdSerializer::Id *id)
{
  int index; // [rsp+40h] [rbp+18h] BYREF

  if ( id->valid ) /*0x1411331da*/
  {
    RBX::Network::serializeGuidScope(stream, localPeerId: this->localPeerId, scope: (const RBX::Guid::Scope *)&id->id); /*0x1411331f3*/
    index = id->id.index; /*0x141133206*/
    RBX::Network::NetworkStream::writeBytes(this: stream, inByteArray: &index, numberOfBytesToWrite: 4u); /*0x14113320d*/
  }
  else
  {
    RBX::Network::serializeUnsignedVarint(value: 0, stream); /*0x141133229*/
  }
}

// Address: 0x141133230 | Name: ?serializeId@IdSerializer@Network@RBX@@QEAAXAEAVNetworkStream@23@AEBVGuid@3@@Z
void __fastcall RBX::Network::IdSerializer::serializeId(
        RBX::Network::IdSerializer *this,
        RBX::Network::NetworkStream *stream,
        const RBX::Guid *id)
{
  int index; // [rsp+40h] [rbp+18h] BYREF

  if ( id->scope.peerId.peerId == -1 ) /*0x141133244*/
  {
    RBX::Network::serializeUnsignedVarint(value: 0, stream); /*0x141133252*/
  }
  else
  {
    RBX::Network::serializeGuidScope(stream, localPeerId: this->localPeerId, scope: (const RBX::Guid::Scope *)id); /*0x141133260*/
    index = id->index; /*0x141133273*/
    RBX::Network::NetworkStream::writeBytes(this: stream, inByteArray: &index, numberOfBytesToWrite: 4u); /*0x14113327a*/
  }
}

// Address: 0x141133290 | Name: ?serializeId@IdSerializer@Network@RBX@@QEAAXAEAVNetworkStream@23@PEBVInstance@3@@Z
void __fastcall RBX::Network::IdSerializer::serializeId(
        RBX::Network::IdSerializer *this,
        RBX::Network::NetworkStream *stream,
        const RBX::Instance *instance)
{
  RBX::Network::NetworkStream *v4; // rbx
  int inByteArray; // [rsp+40h] [rbp+18h] BYREF
  RBX::Guid id; // [rsp+48h] [rbp+20h] BYREF

  v4 = stream; /*0x1411332a2*/
  if ( instance == nullptr ) /*0x1411332ab*/
    goto LABEL_4; /*0x1411332ab*/
  RBX::GuidItem<RBX::Instance>::Registry::reg(this: this->guidRegistry.px, item: instance); /*0x1411332b7*/
  id = instance->guid; /*0x1411332c0*/
  if ( id.scope.peerId.peerId == -1 ) /*0x1411332c8*/
  {
    stream = v4; /*0x1411332ca*/
LABEL_4:
    RBX::Network::serializeUnsignedVarint(value: 0, stream); /*0x1411332cd*/
    return; /*0x1411332e3*/
  }
  RBX::Network::serializeGuidScope(stream: v4, localPeerId: this->localPeerId, scope: (const RBX::Guid::Scope *)&id); /*0x1411332f2*/
  inByteArray = id.index; /*0x141133306*/
  RBX::Network::NetworkStream::writeBytes(this: v4, &inByteArray, numberOfBytesToWrite: 4u); /*0x14113330d*/
}

// Address: 0x141133330 | Name: ?serializeId@IdSerializer@Network@RBX@@SAXAEAVNetworkStream@23@AEBIAEBVGuid@3@@Z
void __fastcall RBX::Network::IdSerializer::serializeId(
        RBX::Network::NetworkStream *stream,
        unsigned int *peerIdType,
        const RBX::Guid *id)
{
  int index; // [rsp+40h] [rbp+18h] BYREF

  if ( id->scope.peerId.peerId == -1 ) /*0x141133344*/
  {
    RBX::Network::serializeUnsignedVarint(value: 0, stream); /*0x141133355*/
  }
  else
  {
    RBX::Network::serializeGuidScope(stream, localPeerId: *peerIdType, scope: (const RBX::Guid::Scope *)id); /*0x14113335c*/
    index = id->index; /*0x14113336f*/
    RBX::Network::NetworkStream::writeBytes(this: stream, inByteArray: &index, numberOfBytesToWrite: 4u); /*0x141133376*/
  }
}

// END IdSerializer part 1/1, 11 functions
