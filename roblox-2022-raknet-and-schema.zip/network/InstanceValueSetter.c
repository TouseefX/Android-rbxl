// InstanceValueSetter -- 2022 Studio + full PDB
// tier 3, 1 functions


// Address: 0x14104e030 | Name: ??$schemaReadValue@UInstanceValueSetter@Network@RBX@@@Replicator@Network@RBX@@IEAAXAEAVNetworkStream@12@AEBUType@NetworkSchema@12@_NAEAUInstanceValueSetter@12@_KAEAV?$unordered_map@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@V?$vector@UDeferredSharedStringSetter@Network@RBX@@V?$allocator@UDeferredSharedStringSetter@Network@RBX@@@std@@@2@U?$hash@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@boost@@U?$equal_to@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@2@V?$allocator@U?$pair@$$CBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@V?$vector@UDeferredSharedStringSetter@Network@RBX@@V?$allocator@UDeferredSharedStringSetter@Network@RBX@@@std@@@2@@std@@@2@@unordered@boost@@AEAUReplicationVariantSizeLimitsMetaData@12@@Z
// local variable allocation has failed, the output may be wrong!
void __fastcall RBX::Network::Replicator::schemaReadValue<RBX::Network::InstanceValueSetter>(
        RBX::Network::Replicator *this,
        RBX::Network::NetworkStream *inBitStream,
        const RBX::Network::NetworkSchema::Type *valueType,
        bool useDictionaries,
        RBX::Network::InstanceValueSetter *out,
        unsigned __int64 depth,
        boost::unordered::unordered_map<std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string >,std::equal_to<std::string >,std::allocator<std::pair<std::string const ,std::vector<RBX::Network::DeferredSharedStringSetter> > > > *deferredSharedStrings,
        RBX::Network::ReplicationVariantSizeLimitsMetaData *replicationMetaData)
{
  unsigned int readOffset; // r8d
  const RBX::Reflection::PropertyDescriptor *v13; // rcx
  _BYTE *v14; // rax
  RBX::UniqueId *v15; // rdx
  RBX::UniqueId *v16; // r11
  RBX::UniqueId *v17; // r8
  unsigned __int64 v18; // r10
  size_t v19; // rsi
  RBX::UniqueId *v20; // r11
  RBX::UniqueId *v21; // rax
  unsigned __int64 v22; // r9
  unsigned __int64 v23; // rcx
  unsigned __int64 v24; // rdi
  boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > v25; // rcx
  unsigned __int64 v26; // r13
  boost::unordered::detail::ptr_bucket *v27; // rbx
  boost::unordered::detail::ptr_bucket *v28; // rbx
  boost::unordered::detail::ptr_bucket *v29; // rax
  boost::unordered::detail::ptr_bucket *v30; // rdx
  RBX::UniqueId *v31; // rcx
  std::pair<std::string const ,std::vector<RBX::Network::DeferredSharedStringSetter> > *v32; // rax
  RBX::Network::InstanceValueSetter *v33; // rbx
  char *Ptr; // rcx
  const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *v35; // rcx
  RBX::ProtectedString *v36; // rax
  const RBX::Reflection::PropertyDescriptor *v37; // rcx
  _BYTE *v38; // rax
  RBX::UniqueId *p_uid; // rdx
  RBX::UniqueId *v40; // r11
  RBX::UniqueId *v41; // r8
  unsigned __int64 v42; // r10
  size_t v43; // rsi
  RBX::UniqueId *v44; // r11
  RBX::UniqueId *v45; // rax
  unsigned __int64 v46; // r9
  unsigned __int64 v47; // rcx
  unsigned __int64 v48; // rdi
  boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > v49; // rdx
  unsigned __int64 v50; // r13
  boost::unordered::detail::ptr_bucket *next; // rbx
  boost::unordered::detail::ptr_bucket *v52; // rbx
  boost::unordered::detail::ptr_bucket *v53; // rcx
  boost::unordered::detail::ptr_bucket *v54; // rdx
  RBX::UniqueId *v55; // rcx
  std::pair<std::string const ,std::vector<RBX::Network::DeferredSharedStringSetter> > *v56; // rax
  const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *h; // rcx
  RBX::ProtectedString *v58; // rax
  const RBX::Reflection::PropertyDescriptor *v59; // rcx
  int PayloadLimit; // eax
  const RBX::Reflection::PropertyDescriptor *desc; // rcx
  int v62; // eax
  RBX::Network::InstanceValueSetter *v63; // rbx
  RBX::SharedString *v64; // rax
  const RBX::Reflection::PropertyDescriptor *v65; // rcx
  const RBX::Reflection::PropertyDescriptor *v66; // rcx
  const RBX::Reflection::PropertyDescriptor *v67; // rcx
  RBX::Network::InstanceValueSetter *v68; // rdx
  const RBX::Reflection::PropertyDescriptor *v69; // rcx
  RBX::Rect2D *UDim; // rax
  const RBX::Reflection::PropertyDescriptor *v71; // rcx
  const RBX::Reflection::PropertyDescriptor *v72; // rcx
  const RBX::Reflection::PropertyDescriptor *v73; // rcx
  RBX::OptionalCoordinateFrame *OptionalCoordinateFrame; // rax
  const RBX::Reflection::PropertyDescriptor *v75; // rcx
  RBX::Guid *v76; // rax
  unsigned int peerId; // ecx
  RBX::GuidItem<RBX::Instance>::Registry *px; // rbx
  RBX::Network::InstanceValueSetter *v79; // rcx
  unsigned __int64 v80; // rcx
  std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Guid const ,std::weak_ptr<RBX::Instance> > > > > *Myfirst; // rax
  std::_List_node<std::pair<RBX::Guid const ,std::weak_ptr<RBX::Instance> >,void *> *v82; // rdx
  std::_List_node<std::pair<RBX::Guid const ,std::weak_ptr<RBX::Instance> >,void *> *Myhead; // r9
  std::_List_node<std::pair<RBX::Guid const ,std::weak_ptr<RBX::Instance> >,void *> *v84; // rax
  RBX::Instance *v85; // rbx
  std::_Ref_count_base *v86; // r9
  std::_Ref_count_base *Rep; // r8
  signed __int32 Uses; // eax
  signed __int32 v89; // ett
  const RBX::Reflection::PropertyDescriptor *v90; // r9
  RBX::Instance *v91; // rbx
  std::_Ref_count_base *v92; // rdx
  signed __int32 v93; // eax
  signed __int32 v94; // ett
  std::_Ref_count_base *v95; // rbx
  RBX::Reflection::Tuple *v96; // rax
  const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *v97; // rsi
  unsigned int v98; // ebx
  boost::unordered::unordered_map<std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string >,std::equal_to<std::string >,std::allocator<std::pair<std::string const ,std::vector<RBX::Network::DeferredSharedStringSetter> > > > *v99; // r13
  const RBX::Reflection::PropertyDescriptor *v100; // rcx
  std::vector<RBX::Reflection::Variant> *v101; // rax
  std::vector<RBX::Reflection::Variant> *v102; // rax
  unsigned int v103; // ebx
  boost::unordered::unordered_map<std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string >,std::equal_to<std::string >,std::allocator<std::pair<std::string const ,std::vector<RBX::Network::DeferredSharedStringSetter> > > > *v104; // rsi
  const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *v105; // r13
  RBX::Network::ReplicationVariantSizeLimitsMetaData *v106; // r15
  const RBX::Reflection::PropertyDescriptor *v107; // rcx
  std::unordered_map<std::string,RBX::Reflection::Variant> *v108; // rax
  std::unordered_map<std::string,RBX::Reflection::Variant> *v109; // rax
  unsigned int v110; // ebx
  boost::unordered::unordered_map<std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string >,std::equal_to<std::string >,std::allocator<std::pair<std::string const ,std::vector<RBX::Network::DeferredSharedStringSetter> > > > *v111; // rsi
  RBX::Network::ReplicationVariantSizeLimitsMetaData *v112; // r15
  int v113; // eax
  std::pair<std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *,bool> *v114; // rax
  const RBX::Reflection::PropertyDescriptor *v115; // rcx
  char *v116; // rcx
  std::map<std::string,cricket::RidDescription> *v117; // rax
  std::map<std::string,RBX::Reflection::Variant> *v118; // rax
  unsigned int v119; // ebx
  boost::unordered::unordered_map<std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string >,std::equal_to<std::string >,std::allocator<std::pair<std::string const ,std::vector<RBX::Network::DeferredSharedStringSetter> > > > *v120; // rsi
  std::map<std::string,RBX::Reflection::Variant> *v121; // r13
  RBX::Network::ReplicationVariantSizeLimitsMetaData *v122; // r15
  int v123; // eax
  std::pair<std::_Tree_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *,bool> *v124; // rax
  const RBX::Reflection::PropertyDescriptor *v125; // rcx
  char *v126; // rcx
  int v127; // eax
  double sec; // xmm2_8
  unsigned __int64 v129; // r8
  RBX::UniqueId *v130; // rdx
  char *v131; // rcx
  int v132; // ebx
  char *v133; // rcx
  const RBX::Reflection::PropertyDescriptor *v134; // rcx
  const RBX::Reflection::PropertyDescriptor *v135; // rcx
  RBX::NumberSequence *NumberSequence; // rax
  const RBX::Reflection::PropertyDescriptor *v137; // rcx
  RBX::ColorSequence *ColorSequence; // rax
  const RBX::Reflection::PropertyDescriptor *v139; // rcx
  RBX::UniqueId *v140; // rdx
  const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *v141; // rbx
  std::pair<std::string const ,std::vector<RBX::Network::DeferredSharedStringSetter> > *v142; // rax
  RBX::Network::NetworkSchema::LocalConformance localConformance; // r8d
  const rtc::webrtc_checks_impl::ToStringVal *Contents; // rax
  rtc::webrtc_checks_impl::ToStringVal *v145; // rax
  const RBX::Reflection::PropertyDescriptor *v146; // rcx
  RBX::Reflection::Variant *variantOut; // rcx
  const RBX::Reflection::PropertyDescriptor *v148; // rcx
  unsigned __int8 Byte; // al
  unsigned __int8 v150; // al
  int v151; // ecx
  unsigned int v152; // ebx
  RBX::UniqueId *v153; // rdx
  int v154; // eax
  const RBX::Reflection::PropertyDescriptor *v155; // rcx
  unsigned __int64 UInt64; // rdi
  unsigned int UInt32; // ebx
  unsigned int v158; // esi
  const RBX::Reflection::PropertyDescriptor *v159; // rcx
  int v160; // eax
  RBX::PathWaypoint *PathWaypointWithLabel; // rax
  const RBX::Reflection::PropertyDescriptor *v162; // rcx
  int v163; // eax
  RBX::Text::FontInfo *Font; // rax
  const RBX::Reflection::PropertyDescriptor *v165; // rcx
  bool v166; // r11
  bool v167; // r10
  bool v168; // r13
  unsigned int v169; // esi
  bool v170; // di
  bool v171; // bl
  unsigned int replicatedStringDataSizeLimit; // eax
  unsigned int variantCountLimit; // eax
  bool v174; // r8
  bool v175; // r9
  unsigned int replicatedStringDataSizeReportingThreshold; // eax
  unsigned int variantCountReportingThreshold; // eax
  bool v178; // r14
  bool v179; // al
  bool v180; // zf
  RBX::Reflection::Variant *v181; // rcx
  RBX::Network::ReplicationVariantSizeLimitsMetaData *v182; // r14
  RBX::Network::ServerReplicator *v183; // rax
  ShareModalAnalytics *v184; // rax
  RBX::Graphics::ProfilerAdorn::Item *v185; // rax
  unsigned int NumberOfUnreadBytes; // eax
  RBX::Graphics::ProfilerAdorn::Item *v187; // rax
  RBX::Graphics::ProfilerAdorn::Item *v188; // rax
  RBX::Graphics::ProfilerAdorn::Item *v189; // rax
  RBX::Graphics::ProfilerAdorn::Item *v190; // rax
  RBX::UniqueId uid; // [rsp+40h] [rbp-C0h] BYREF
  size_t Size; // [rsp+50h] [rbp-B0h]
  unsigned __int64 v193; // [rsp+58h] [rbp-A8h]
  RBX::SharedString source; // [rsp+60h] [rbp-A0h] BYREF
  RBX::SharedString value; // [rsp+70h] [rbp-90h] OVERLAPPED BYREF
  std::string keyBuffer; // [rsp+80h] [rbp-80h] BYREF
  RBX::Guid data; // [rsp+A8h] [rbp-58h] BYREF
  RBX::Network::DeferredSharedStringSetter v198; // [rsp+B0h] [rbp-50h] BYREF
  std::shared_ptr<RBX::Instance> instance; // [rsp+D0h] [rbp-30h] BYREF
  RBX::CoordinateFrame cFrame; // [rsp+E0h] [rbp-20h] BYREF
  RBX::Analytics::InfluxDb::Points points; // [rsp+120h] [rbp+20h] BYREF
  std::shared_ptr<RBX::Instance> referencer; // [rsp+190h] [rbp+90h] BYREF
  boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > networkId; // [rsp+1E8h] [rbp+E8h] BYREF
  unsigned int v204; // [rsp+1F0h] [rbp+F0h]

  readOffset = inBitStream->readOffset; /*0x14104e05c*/
  v204 = readOffset; /*0x14104e060*/
  if ( valueType->valueFormat == NetworkValueFormat_Unsupported )
  {
    RBX::runtime_error(result: (std::runtime_error *)&uid, fmt: "Cannot read value: value sent via unsupported format");
    throw (std::runtime_error *)&uid; /*0x14104fda0*/
  }
  switch ( valueType->valueFormat )
  {
    case NetworkValueFormat_String_NeverDictionary:
      __wind /*0xf1c000000000039c*/
      {
        keyBuffer._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14104e705*/
        keyBuffer._Mypair._Myval2._Mysize = 0; /*0x14104e709*/
        keyBuffer._Mypair._Myval2._Myres = 15; /*0x14104e70d*/
        PayloadLimit = RBX::Network::Replicator::getReadPayloadLimit(this); /*0x14104e71c*/
        RBX::Network::deserializeString(value: &keyBuffer, stream: inBitStream, maxStringReadSize: PayloadLimit); /*0x14104e72b*/
        replicationMetaData->replicatedStringDataSize += LODWORD(keyBuffer._Mypair._Myval2._Mysize); /*0x14104e73a*/
        desc = out->desc; /*0x14104e743*/
        if ( desc != nullptr ) /*0x14104e74a*/
          (*((void (__fastcall **)(RBX::Reflection::PropertyDescriptor_vtbl *, RBX::Instance *, std::string *))desc[1].dtr_Descriptor /*0x14104e75a*/
           + 4))(
            a1: desc[1].__vftable,
            a2: out->instance,
            a3: &keyBuffer);
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&keyBuffer); /*0xf1c0000000000394*/
      }
      if ( keyBuffer._Mypair._Myval2._Myres < 0x10 ) /*0x14104e766*/
        goto LABEL_342; /*0x14104e766*/
      Ptr = keyBuffer._Mypair._Myval2._Bx._Ptr; /*0x14104e76f*/
      if ( keyBuffer._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14104e77d*/
      {
        Ptr = *((char **)keyBuffer._Mypair._Myval2._Bx._Ptr - 1); /*0x14104e787*/
        if ( (unsigned __int64)(keyBuffer._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x14104e796*/
          _invalid_parameter_noinfo_noreturn(); /*0x14104e79c*/
      }
      goto LABEL_44; /*0x14104e796*/
    case NetworkValueFormat_ProtectedStringServerIndexString:
      goto $LN2_9;
    case NetworkValueFormat_ProtectedStringSource:
      v38 = operator new(size: 0x20u); /*0x14104e436*/
      __eh34_enter_wind_state(-1, 0); /*0xf1c00000000003e0*/
      Size = 16; /*0x14104e43b*/
      v193 = 31; /*0x14104e444*/
      *(_OWORD *)v38 = 0; /*0x14104e450*/
      v38[16] = 0; /*0x14104e453*/
      *(_QWORD *)&uid.sessionId.bits_hi = v38; /*0x14104e457*/
      RBX::SharedString::SharedString(this: &source); /*0x14104e461*/
      p_uid = &uid; /*0x14104e467*/
      if ( v193 >= 0x10 ) /*0x14104e472*/
        p_uid = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x14104e472*/
      __eh34_enter_wind_state(0, 1); /*0xf1c00000000003d8*/
      RBX::Network::NetworkStream::readBytes( /*0x14104e481*/
        this: inBitStream,
        inOutByteArray: (void *)p_uid,
        numberOfBytesToRead: 0x10u);
      v40 = &uid; /*0x14104e486*/
      v41 = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x14104e48b*/
      v42 = v193; /*0x14104e490*/
      if ( v193 >= 0x10 ) /*0x14104e499*/
        v40 = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x14104e499*/
      v43 = Size; /*0x14104e49d*/
      v44 = &v40[Size / 0x10]; /*0x14104e4a2*/
      v45 = &uid; /*0x14104e4a5*/
      if ( v193 >= 0x10 ) /*0x14104e4ae*/
        v45 = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x14104e4ae*/
      v46 = 0; /*0x14104e4b2*/
      if ( v45 != v44 ) /*0x14104e4b8*/
      {
        do /*0x14104e4e5*/
        {
          v46 ^= (v46 >> 2) + 2654435769u + (v46 << 6) + SLOBYTE(v45->sessionId.bits_hi); /*0x14104e4dc*/
          v45 = (RBX::UniqueId *)((char *)v45 + 1); /*0x14104e4df*/
        }
        while ( v45 != v44 ); /*0x14104e4e5*/
        v41 = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x14104e4e7*/
        v42 = v193; /*0x14104e4ec*/
      }
      v47 = 265 * ((~v46 + (v46 << 21)) ^ ((~v46 + (v46 << 21)) >> 24)); /*0x14104e508*/
      v48 = 2147483649u * (((21 * (v47 ^ (v47 >> 14))) >> 28) ^ (21 * (v47 ^ (v47 >> 14)))); /*0x14104e52c*/
      v49.h = (const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *)(this->sharedStringReceiverDictionary.table_.bucket_count_ - 1); /*0x14104e538*/
      networkId.h = v49.h; /*0x14104e53b*/
      v50 = v48 & (unsigned __int64)v49.h; /*0x14104e545*/
      if ( this->sharedStringReceiverDictionary.table_.size_ == 0 ) /*0x14104e551*/
        goto LABEL_68; /*0x14104e551*/
      next = this->sharedStringReceiverDictionary.table_.buckets_[v50].next_; /*0x14104e55f*/
      if ( next == nullptr ) /*0x14104e566*/
        goto LABEL_68; /*0x14104e566*/
      v52 = next->next_; /*0x14104e568*/
      if ( v52 == nullptr ) /*0x14104e56e*/
        goto LABEL_68; /*0x14104e56e*/
      while ( 2 ) /*0x14104e570*/
      {
        v53 = v52[1].next_; /*0x14104e570*/
        if ( (boost::unordered::detail::ptr_bucket *)v48 != v53 ) /*0x14104e577*/
        {
          if ( ((unsigned __int64)v53 & (unsigned __int64)v49.h) != v50 ) /*0x14104e5d1*/
          {
LABEL_68:
            v56 = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::vector<RBX::Network::DeferredSharedStringSetter>>>,std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string>,std::equal_to<std::string>>>::operator[]( /*0x14104e5d3*/
                    this: &deferredSharedStrings->table_,
                    k: (const std::string *)&uid);
            v198.variantOut = nullptr; /*0x14104e5e8*/
            v198.desc = out->desc; /*0x14104e5f7*/
            v198.instance = out->instance; /*0x14104e5fe*/
            v198.localConformance = LocalConformance_NetworkProtectedStringSource; /*0x14104e602*/
            std::vector<RBX::Network::DeferredSharedStringSetter>::emplace_back<RBX::Network::DeferredSharedStringSetter>( /*0x14104e60d*/
              this: &v56->second,
              <_Val_0>: (const std::optional<std::pair<Luau::AstName,Luau::Location> > *)&v198);
            goto LABEL_516; /*0xf1c0000000000550*/
          }
LABEL_65:
          v52 = v52->next_; /*0x14104e5b4*/
          if ( v52 != nullptr ) /*0x14104e5ba*/
          {
            v41 = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x14104e5bc*/
            v42 = v193; /*0x14104e5c1*/
            continue; /*0x14104e5c6*/
          }
          goto LABEL_68; /*0x14104e5ba*/
        }
        break;
      }
      v54 = v52 + 2; /*0x14104e579*/
      if ( v52[5].next_ >= (boost::unordered::detail::ptr_bucket *)0x10 ) /*0x14104e586*/
        v54 = v54->next_; /*0x14104e588*/
      v55 = &uid; /*0x14104e58b*/
      if ( v42 >= 0x10 ) /*0x14104e594*/
        v55 = v41; /*0x14104e594*/
      if ( (boost::unordered::detail::ptr_bucket *)v43 != v52[4].next_ || memcmp_0(Buf1: v55, Buf2: v54, Size: v43) != 0 ) /*0x14104e5a7*/
      {
        v49.h = networkId.h; /*0x14104e5ad*/
        goto LABEL_65; /*0x14104e5ad*/
      }
      if ( DFFlag::ReportSharedStringBreakdown.value ) /*0x14104e675*/
        RBX::PolicyServiceAnalyticsStatReporter::incrementCallbackQueueExceededCount(this: (RBX::RVideo::Mp4IoWriter *)&v52[6]); /*0x14104e67b*/
      networkId.h = (const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *)v52[6].next_; /*0x14104e684*/
      _InterlockedIncrement(&networkId.h->ref.value_); /*0x14104e68b*/
      h = source.flyweight.h.h; /*0x14104e68f*/
      source.flyweight.h = networkId; /*0x14104e69b*/
      networkId.h = h; /*0x14104e6a0*/
      boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: &networkId); /*0x14104e6ae*/
      source.readCount = (unsigned int)v52[7].next_; /*0x14104e6b6*/
      v58 = RBX::ProtectedString::fromTrustedSharedSource( /*0x14104e6c3*/
              result: (RBX::ProtectedString *)&keyBuffer,
              trustedString: &source);
      __eh34_enter_wind_state(1, 2); /*0xf1c00000000003bc*/
      v59 = out->desc; /*0x14104e6d0*/
      if ( v59 != nullptr ) /*0x14104e6d7*/
        (*((void (__fastcall **)(RBX::Reflection::PropertyDescriptor_vtbl *, RBX::Instance *, RBX::ProtectedString *))v59[1].dtr_Descriptor /*0x14104e6ea*/
         + 4))(
          a1: v59[1].__vftable,
          a2: out->instance,
          a3: v58);
      if ( __eh34_unwind(2) ) /*0xf1c00000000003a8*/
        goto unwind_state_2; /*0xf1c00000000003a8*/
      __eh34_exit_wind_state(2, 1); /*0xf1c00000000003b4*/
      boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: (boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *)&keyBuffer._Mypair._Myval2._Mysize); /*0x14104e6f2*/
      boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: (boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *)&keyBuffer); /*0x14104e6fb*/
      if ( __eh34_unwind(1) ) /*0xf1c00000000003c4*/
        goto unwind_state_1; /*0xf1c00000000003c4*/
LABEL_516:
      __eh34_exit_wind_state(1, 0); /*0xf1c00000000003d0*/
      boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: &source.flyweight.h); /*0x14104e618*/
      if ( v193 < 0x10 ) /*0x14104e627*/
        goto LABEL_400; /*0x14104e627*/
      Ptr = *(char **)&uid.sessionId.bits_hi; /*0x14104e630*/
      if ( v193 + 1 >= 0x1000 ) /*0x14104e63f*/
      {
        Ptr = *(char **)(*(_QWORD *)&uid.sessionId.bits_hi - 8LL); /*0x14104e649*/
        if ( (unsigned __int64)(*(_QWORD *)&uid.sessionId.bits_hi - (_QWORD)Ptr - 8LL) > 0x1F ) /*0x14104e658*/
          _invalid_parameter_noinfo_noreturn(); /*0x14104e65e*/
      }
      if ( __eh34_unwind(0) ) /*0xf1c00000000003e8*/
        goto unwind_state_0; /*0xf1c00000000003e8*/
LABEL_520:
      __eh34_exit_wind_state(0, -1); /*0xf1c00000000003ec*/
LABEL_44:
      operator delete(ptr: Ptr); /*0x14104e40f*/
      goto LABEL_342; /*0x14104e414*/
    case NetworkValueFormat_Enum_VarInt:
      RBX::Network::deserializeUnsignedVarint(value: (unsigned int *)&networkId, stream: inBitStream); /*0x14104e0a0*/
      v13 = out->desc; /*0x14104e0ac*/
      if ( v13 != nullptr ) /*0x14104e0b3*/
        ((void (__fastcall *)(const RBX::Reflection::PropertyDescriptor *, RBX::Instance *, _QWORD))v13->__vftable[1].isTypedDescriptor)( /*0x14104e0c6*/
          a1: v13,
          a2: out->instance,
          a3: LODWORD(networkId.h));
      goto LABEL_342; /*0x14104e0cc*/
    case NetworkValueFormat_BinaryString:
      __wind /*0xf1c0000000000384*/
      {
        keyBuffer._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14104e7a3*/
        keyBuffer._Mypair._Myval2._Mysize = 0; /*0x14104e7a7*/
        keyBuffer._Mypair._Myval2._Myres = 15; /*0x14104e7ab*/
        v62 = RBX::Network::Replicator::getReadPayloadLimit(this); /*0x14104e7ba*/
        RBX::Network::deserializeString(value: &keyBuffer, stream: inBitStream, maxStringReadSize: v62); /*0x14104e7c9*/
        replicationMetaData->replicatedStringDataSize += LODWORD(keyBuffer._Mypair._Myval2._Mysize); /*0x14104e7d8*/
        v63 = out; /*0x14104e7da*/
        if ( valueType->localConformance == LocalConformance_NetworkBinaryStringLocalSharedString ) /*0x14104e7e5*/
        {
          v64 = RBX::SharedString::SharedString(this: (RBX::SharedString *)&uid, contents: &keyBuffer); /*0x14104e7f0*/
          __wind /*0xf1c0000000000378*/
          {
            v65 = v63->desc; /*0x14104e7f6*/
            if ( v65 != nullptr ) /*0x14104e7fd*/
              (*((void (__fastcall **)(RBX::Reflection::PropertyDescriptor_vtbl *, RBX::Instance *, RBX::SharedString *))v65[1].dtr_Descriptor /*0x14104e810*/
               + 4))(
                a1: v65[1].__vftable,
                a2: v63->instance,
                a3: v64);
          }
          __unwind
          {
            RBX::SharedString::~SharedString(this: (RBX::SharedString *)&uid); /*0xf1c0000000000370*/
          }
          boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: (boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *)&uid); /*0x14104e819*/
        }
        else
        {
          v66 = out->desc; /*0x14104e820*/
          if ( v66 != nullptr ) /*0x14104e827*/
            (*((void (__fastcall **)(RBX::Reflection::PropertyDescriptor_vtbl *, RBX::Instance *, std::string *))v66[1].dtr_Descriptor /*0x14104e837*/
             + 4))(
              a1: v66[1].__vftable,
              a2: out->instance,
              a3: &keyBuffer);
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&keyBuffer); /*0xf1c0000000000364*/
      }
      if ( keyBuffer._Mypair._Myval2._Myres < 0x10 ) /*0x14104e843*/
        goto LABEL_342; /*0x14104e843*/
      Ptr = keyBuffer._Mypair._Myval2._Bx._Ptr; /*0x14104e84c*/
      if ( keyBuffer._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14104e85a*/
      {
        Ptr = *((char **)keyBuffer._Mypair._Myval2._Bx._Ptr - 1); /*0x14104e864*/
        if ( (unsigned __int64)(keyBuffer._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x14104e873*/
          _invalid_parameter_noinfo_noreturn(); /*0x14104e879*/
      }
      goto LABEL_44; /*0x14104e873*/
    case NetworkValueFormat_Bool:
      LOBYTE(networkId.h) = RBX::Network::NetworkStream::readBool(this: inBitStream); /*0x14104e888*/
      v67 = out->desc; /*0x14104e895*/
      if ( v67 != nullptr ) /*0x14104e89c*/
        goto LABEL_103; /*0x14104e89c*/
      goto LABEL_342; /*0x14104e89c*/
    case NetworkValueFormat_Int:
      RBX::Network::deserializeSignedVarint(value: (int *)&networkId, stream: inBitStream); /*0x14104e8c5*/
      v68 = out; /*0x14104e8ca*/
      v69 = out->desc; /*0x14104e8d1*/
      if ( valueType->localConformance != LocalConformance_NetworkIntLocalInt64 ) /*0x14104e8d9*/
        goto LABEL_291; /*0x14104e8d9*/
      value.flyweight.h.h = (const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *)SLODWORD(networkId.h); /*0x14104e8e6*/
      goto LABEL_98; /*0x14104e8e6*/
    case NetworkValueFormat_Float:
      LODWORD(networkId.h) = RBX::Network::NetworkStream::readFloat(this: inBitStream); /*0x14104e913*/
      v67 = out->desc; /*0x14104e922*/
      if ( v67 != nullptr ) /*0x14104e929*/
        goto LABEL_103; /*0x14104e929*/
      goto LABEL_342; /*0x14104e929*/
    case NetworkValueFormat_Double:
      *(double *)&networkId.h = RBX::Network::NetworkStream::readDouble(this: inBitStream); /*0x14104e950*/
      v67 = out->desc; /*0x14104e95f*/
      if ( v67 != nullptr ) /*0x14104e966*/
LABEL_103:
        (*((void (__fastcall **)(RBX::Reflection::PropertyDescriptor_vtbl *, RBX::Instance *, boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *))v67[1].dtr_Descriptor /*0x14104e96c*/
         + 4))(
          a1: v67[1].__vftable,
          a2: out->instance,
          a3: &networkId);
      goto LABEL_342; /*0x14104e980*/
    case NetworkValueFormat_UDim:
      UDim = (RBX::Rect2D *)RBX::Network::NetworkStream::readUDim(this: inBitStream, result: (RBX::UDim *)&networkId); /*0x14104e98f*/
      goto LABEL_105; /*0x14104e98f*/
    case NetworkValueFormat_UDim2:
      UDim = (RBX::Rect2D *)RBX::Network::NetworkStream::readUDim2(this: inBitStream, result: (RBX::UDim2 *)&uid); /*0x14104e9c9*/
      goto LABEL_105; /*0x14104e9ce*/
    case NetworkValueFormat_Ray:
      UDim = (RBX::Rect2D *)RBX::Network::NetworkStream::readRay(this: inBitStream, result: (RBX::Ray *)&uid); /*0x14104e9d8*/
      goto LABEL_105; /*0x14104e9dd*/
    case NetworkValueFormat_Faces:
    case NetworkValueFormat_Axes:
      UDim = (RBX::Rect2D *)RBX::Network::NetworkStream::readFaces(this: inBitStream, result: (RBX::Faces *)&networkId); /*0x14104e9e9*/
      goto LABEL_105; /*0x14104e9ee*/
    case NetworkValueFormat_BrickColor:
      UDim = (RBX::Rect2D *)RBX::Network::NetworkStream::readBrickColor( /*0x14104ea0b*/
                              this: inBitStream,
                              result: (RBX::BrickColor *)&networkId);
      goto LABEL_105; /*0x14104ea10*/
    case NetworkValueFormat_Color3:
    case NetworkValueFormat_Vector3_Fixed12Bytes:
    case NetworkValueFormat_NumberSequenceKeypoint:
      UDim = (RBX::Rect2D *)RBX::Network::NetworkStream::readVector3(this: inBitStream, result: (RBX::Vector3 *)&value); /*0x14104f64a*/
      goto LABEL_105; /*0x14104f64f*/
    case NetworkValueFormat_Color3uint8:
      UDim = (RBX::Rect2D *)RBX::Network::NetworkStream::readColor3uint8( /*0x14104ea2e*/
                              this: inBitStream,
                              result: (RBX::Color3uint8 *)&networkId);
      goto LABEL_105; /*0x14104ea33*/
    case NetworkValueFormat_Vector2:
    case NetworkValueFormat_NumberRange:
      UDim = (RBX::Rect2D *)RBX::Network::NetworkStream::readNumberRange( /*0x14104ea42*/
                              this: inBitStream,
                              result: (RBX::Vector2 *)&networkId);
      goto LABEL_105; /*0x14104ea47*/
    case NetworkValueFormat_Vector2int16:
      UDim = (RBX::Rect2D *)RBX::Network::NetworkStream::readVector2int16( /*0x14104ea68*/
                              this: inBitStream,
                              result: (RBX::Vector2int16 *)&networkId);
      goto LABEL_105; /*0x14104ea6d*/
    case NetworkValueFormat_Vector3int16:
      UDim = (RBX::Rect2D *)RBX::Network::NetworkStream::readVector3int16( /*0x14104ea7c*/
                              this: inBitStream,
                              result: (RBX::Vector3int16 *)&networkId);
      goto LABEL_105; /*0x14104ea81*/
    case NetworkValueFormat_CoordinateFrame_ExactEncoding:
      *(_OWORD *)&cFrame.rotation.elt[0][0] = _xmm; /*0x14104ea8d*/
      *(_OWORD *)&cFrame.rotation.elt[1][1] = _xmm; /*0x14104ea94*/
      *(_OWORD *)&cFrame.rotation.elt[2][2] = _xmm; /*0x14104ea98*/
      RBX::Network::deserializeCoordinateFrameExact(cframe: &cFrame, bitStream: inBitStream); /*0x14104eaa3*/
      v72 = out->desc; /*0x14104eaaf*/
      if ( v72 != nullptr ) /*0x14104eab6*/
        (*((void (__fastcall **)(RBX::Reflection::PropertyDescriptor_vtbl *, RBX::Instance *, RBX::CoordinateFrame *))v72[1].dtr_Descriptor /*0x14104eaca*/
         + 4))(
          a1: v72[1].__vftable,
          a2: out->instance,
          a3: &cFrame);
      goto LABEL_342; /*0x14104eacd*/
    case NetworkValueFormat_CoordinateFrame_GeneralEncoding:
      UDim = (RBX::Rect2D *)RBX::Network::NetworkStream::readCoordinateFrame(this: inBitStream, result: &cFrame); /*0x14104ead9*/
      goto LABEL_105; /*0x14104eade*/
    case NetworkValueFormat_InstanceGuid:
      v76 = RBX::Network::IdSerializer::deserializeId(this, result: (RBX::Guid *)&value, stream: inBitStream); /*0x14104eb86*/
      peerId = v76->scope.peerId.peerId; /*0x14104eb8b*/
      data = *v76; /*0x14104eb8d*/
      instance = 0; /*0x14104eb99*/
      __wind /*0xf1c0000000000324*/
      {
        px = this->guidRegistry.px; /*0x14104eb9e*/
        if ( peerId == -1 ) /*0x14104eba9*/
        {
          instance = 0; /*0x14104ebab*/
          v79 = out; /*0x14104ebb0*/
          goto LABEL_144; /*0x14104ebb7*/
        }
        networkId.h = (const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *)&px->mx; /*0x14104ebc0*/
        RBX::InstrumentedMutex<std::mutex>::lock(this: &px->mx); /*0x14104ebc7*/
        __wind /*0xf1c0000000000318*/
        {
          v80 = 2 * (RBX::hash_value(guid: &data) & px->map._Mask); /*0x14104ebdd*/
          Myfirst = px->map._Vec._Mypair._Myval2._Myfirst; /*0x14104ebe0*/
          v82 = Myfirst[v80 + 1]._Ptr; /*0x14104ebe4*/
          Myhead = px->map._List._Mypair._Myval2._Myhead; /*0x14104ebe9*/
          if ( v82 == Myhead ) /*0x14104ebf0*/
            goto LABEL_133; /*0x14104ebf0*/
          v84 = Myfirst[v80]._Ptr; /*0x14104ebf2*/
          while ( data.index != v82->_Myval.first.index /*0x14104ec09*/
               || data.scope.peerId.peerId != v82->_Myval.first.scope.peerId.peerId )
          {
            if ( v82 == v84 ) /*0x14104ec0e*/
              goto LABEL_133; /*0x14104ec0e*/
            v82 = v82->_Prev; /*0x14104ec10*/
          }
          if ( v82 == nullptr ) /*0x14104ec19*/
LABEL_133:
            v82 = px->map._List._Mypair._Myval2._Myhead; /*0x14104ec1b*/
          v85 = nullptr; /*0x14104ec1e*/
          if ( v82 == Myhead ) /*0x14104ec24*/
          {
            instance = 0; /*0x14104ec6e*/
          }
          else
          {
            v86 = nullptr; /*0x14104ec26*/
            Rep = v82->_Myval.second._Rep; /*0x14104ec29*/
            if ( Rep != nullptr ) /*0x14104ec30*/
            {
              Uses = Rep->_Uses; /*0x14104ec32*/
              if ( Uses != 0 ) /*0x14104ec38*/
              {
                while ( 1 ) /*0x14104ec43*/
                {
                  v89 = Uses; /*0x14104ec43*/
                  Uses = _InterlockedCompareExchange((volatile signed __int32 *)&Rep->_Uses, Uses + 1, Uses); /*0x14104ec43*/
                  if ( v89 == Uses ) /*0x14104ec49*/
                    break; /*0x14104ec49*/
                  if ( Uses == 0 ) /*0x14104ec4d*/
                  {
                    instance._Ptr = nullptr; /*0x14104ec4f*/
                    instance._Rep = nullptr; /*0x14104ec53*/
                    goto LABEL_491; /*0x14104ec57*/
                  }
                }
                v85 = v82->_Myval.second._Ptr; /*0x14104ec59*/
                v86 = v82->_Myval.second._Rep; /*0x14104ec5d*/
              }
            }
            instance._Ptr = v85; /*0x14104ec61*/
            instance._Rep = v86; /*0x14104ec65*/
          }
        }
        __unwind
        {
          std::scoped_lock<RBX::InstrumentedMutex<std::recursive_mutex>>::~scoped_lock<RBX::InstrumentedMutex<std::recursive_mutex>>(this: (MicroProfileScopeLock *)&networkId); /*0xf1c0000000000310*/
        }
LABEL_491:
        Mtx_unlock_0(a1: (_Mtx_t)networkId.h); /*0x14104ec7a*/
        v79 = out; /*0x14104ec7f*/
        if ( v85 != nullptr ) /*0x14104ec89*/
        {
LABEL_144:
          v90 = v79->desc; /*0x14104ec8b*/
          if ( v90 != nullptr ) /*0x14104ec92*/
            ((void (__fastcall *)(const RBX::Reflection::PropertyDescriptor *, RBX::Instance *, RBX::Instance *))v90->__vftable[1].isTypedDescriptor)( /*0x14104eca1*/
              a1: v79->desc,
              a2: v79->instance,
              a3: instance._Ptr);
          goto LABEL_485; /*0x14104eca7*/
        }
        referencer = 0; /*0x14104ecac*/
        __wind /*0xf1c00000000002f4*/
        {
          v91 = out->instance; /*0x14104ecb4*/
          if ( out->instance != nullptr ) /*0x14104ecba*/
          {
            v92 = v91->_Wptr._Rep; /*0x14104ecbc*/
            if ( v92 == nullptr || (v93 = v92->_Uses) == 0 ) /*0x14104ecce*/
LABEL_384:
              std::_Throw_bad_weak_ptr(); /*0x14104fd7d*/
            while ( 1 ) /*0x14104ecd7*/
            {
              v94 = v93; /*0x14104ecd7*/
              v93 = _InterlockedCompareExchange((volatile signed __int32 *)&v92->_Uses, v93 + 1, v93); /*0x14104ecd7*/
              if ( v94 == v93 ) /*0x14104ecdc*/
                break; /*0x14104ecdc*/
              if ( v93 == 0 ) /*0x14104ece0*/
                goto LABEL_384; /*0x14104ece0*/
            }
            v95 = v91->_Wptr._Rep; /*0x14104ece8*/
          }
          else
          {
            v95 = nullptr; /*0x14104ecee*/
          }
          if ( v95 != nullptr ) /*0x14104ecf4*/
            std::_Ref_count_base::_Decref(this: v95); /*0x14104ecf9*/
        }
        __unwind
        {
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&referencer); /*0xf1c0000000000304*/
        }
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&instance); /*0xf1c00000000002ec*/
      }
LABEL_485:
      if ( instance._Rep != nullptr ) /*0x14104ed06*/
        std::_Ref_count_base::_Decref(this: instance._Rep); /*0x14104ed0c*/
      goto LABEL_342; /*0x14104ed11*/
    case NetworkValueFormat_Tuple:
      if ( depth != 0 ) /*0x14104ed1d*/
      {
        v183 = RBX::Reflection::DescribedBase::fastDynamicCast<RBX::Network::ServerReplicator>(instance: this); /*0x14104fdb6*/
        if ( v183 != nullptr ) /*0x14104fdbe*/
          ((void (__fastcall *)(RBX::Network::ServerReplicator *, const char *, __int64))v183->handleSecurityViolation)( /*0x14104fde8*/
            a1: v183,
            a2: "codeName",
            a3: 36);
        RBX::throw_runtime_error(fmt: "Tuple cannot be received as a member of another container."); /*0x14104fdf6*/
      }
      RBX::Network::deserializeUnsignedVarint(value: (unsigned int *)&networkId, stream: inBitStream); /*0x14104ed2d*/
      RBX::Network::Replicator::checkVariantContainerCountLimit(count: (unsigned int)networkId.h, type: "Tuple (read)"); /*0x14104ed3f*/
      v96 = (RBX::Reflection::Tuple *)operator new(size: 0x18u); /*0x14104ed49*/
      data = (RBX::Guid)v96; /*0x14104ed4e*/
      if ( v96 != nullptr ) /*0x14104ed55*/
      {
        v96->values._Mypair._Myval2._Myfirst = nullptr; /*0x14104ed57*/
        v96->values._Mypair._Myval2._Mylast = nullptr; /*0x14104ed5a*/
        v96->values._Mypair._Myval2._Myend = nullptr; /*0x14104ed5e*/
      }
      else
      {
        v96 = nullptr; /*0x14104ed64*/
      }
      std::shared_ptr<RBX::Reflection::Tuple>::shared_ptr<RBX::Reflection::Tuple>( /*0x14104ed6f*/
        this: (std::shared_ptr<RBX::Reflection::Tuple> *)&source,
        _Px: v96);
      __wind /*0xf1c00000000002dc*/
      {
        v97 = source.flyweight.h.h; /*0x14104ed7b*/
        std::vector<RBX::Reflection::Variant>::resize( /*0x14104ed83*/
          this: (std::vector<RBX::Reflection::Variant> *)source.flyweight.h.h,
          _Newsize: LODWORD(networkId.h));
        v98 = 0; /*0x14104ed88*/
        if ( LODWORD(networkId.h) != 0 ) /*0x14104ed91*/
        {
          v99 = deferredSharedStrings; /*0x14104ed93*/
          do /*0x14104edda*/
            RBX::Network::Replicator::schemaReadVariant( /*0x14104edcd*/
              this,
              inBitStream,
              useDictionaries,
              out: (RBX::Reflection::Variant *)(v97->x.x.b2b.asSizet[0] + 80LL * v98++),
              depth: 0,
              deferredSharedStrings: v99,
              replicationMetaData);
          while ( v98 < LODWORD(networkId.h) ); /*0x14104edda*/
        }
        value = 0; /*0x14104eddf*/
        if ( *(_QWORD *)&source.readCount != 0 ) /*0x14104eded*/
          _InterlockedIncrement((volatile signed __int32 *)(*(_QWORD *)&source.readCount + 8LL)); /*0x14104edef*/
        value = source; /*0x14104edf8*/
        __wind /*0xf1c00000000002d0*/
        {
          v100 = out->desc; /*0x14104ee05*/
          if ( v100 != nullptr ) /*0x14104ee0c*/
            (*((void (__fastcall **)(RBX::Reflection::PropertyDescriptor_vtbl *, RBX::Instance *, RBX::SharedString *))v100[1].dtr_Descriptor /*0x14104ee1d*/
             + 4))(
              a1: v100[1].__vftable,
              a2: out->instance,
              a3: &value);
        }
        __unwind
        {
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&value); /*0xf1c00000000002c8*/
        }
        if ( *(_QWORD *)&value.readCount != 0 ) /*0x14104ee29*/
          std::_Ref_count_base::_Decref(this: *(std::_Ref_count_base **)&value.readCount); /*0x14104ee2b*/
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&source); /*0x14104ee36*/
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&source); /*0xf1c00000000000a8*/
      }
      goto LABEL_342; /*0xf1c00000000000a4*/
    case NetworkValueFormat_ValueArray:
      RBX::Network::deserializeUnsignedVarint((unsigned int *)&value, stream: inBitStream); /*0x14104ee48*/
      RBX::Network::Replicator::checkVariantContainerCountLimit( /*0x14104ee58*/
        count: (unsigned int)value.flyweight.h.h,
        type: "ValueArray (read)");
      v101 = (std::vector<RBX::Reflection::Variant> *)operator new(size: 0x18u); /*0x14104ee62*/
      data = (RBX::Guid)v101; /*0x14104ee67*/
      __wind /*0xf1c00000000002b8*/
      {
        if ( v101 != nullptr ) /*0x14104ee6e*/
          v102 = std::vector<RBX::Reflection::Variant>::vector<RBX::Reflection::Variant>( /*0x14104ee7e*/
                   this: v101,
                   _Count: LODWORD(value.flyweight.h.h),
                   _Al: (const std::allocator<RBX::Reflection::Variant> *)&networkId);
        else
          v102 = nullptr; /*0x14104ee85*/
      }
      __unwind
      {
        operator delete(ptr: *(void **)&data); /*0x1431e8445*/
      }
      std::shared_ptr<std::vector<RBX::Reflection::Variant>>::shared_ptr<std::vector<RBX::Reflection::Variant>>( /*0x14104ee90*/
        this: (std::shared_ptr<std::vector<RBX::Reflection::Variant> > *)&source,
        _Px: v102);
      __wind /*0xf1c00000000002a0*/
      {
        v103 = 0; /*0x14104ee96*/
        if ( LODWORD(value.flyweight.h.h) != 0 ) /*0x14104ee9d*/
        {
          v104 = deferredSharedStrings; /*0x14104ee9f*/
          v105 = source.flyweight.h.h; /*0x14104eea6*/
          v106 = replicationMetaData; /*0x14104eeab*/
          do /*0x14104eeeb*/
            RBX::Network::Replicator::schemaReadVariant( /*0x14104eee0*/
              this,
              inBitStream,
              useDictionaries,
              out: (RBX::Reflection::Variant *)(v105->x.x.b2b.asSizet[0] + 80LL * v103++),
              depth,
              deferredSharedStrings: v104,
              replicationMetaData: v106);
          while ( v103 < LODWORD(value.flyweight.h.h) ); /*0x14104eeeb*/
        }
        uid = 0; /*0x14104eef3*/
        if ( *(_QWORD *)&source.readCount != 0 ) /*0x14104ef01*/
          _InterlockedIncrement((volatile signed __int32 *)(*(_QWORD *)&source.readCount + 8LL)); /*0x14104ef03*/
        uid = (RBX::UniqueId)source; /*0x14104ef0c*/
        __wind /*0xf1c0000000000294*/
        {
          v107 = out->desc; /*0x14104ef19*/
          if ( v107 != nullptr ) /*0x14104ef20*/
            (*((void (__fastcall **)(RBX::Reflection::PropertyDescriptor_vtbl *, RBX::Instance *, RBX::UniqueId *))v107[1].dtr_Descriptor /*0x14104ef31*/
             + 4))(
              a1: v107[1].__vftable,
              a2: out->instance,
              a3: &uid);
        }
        __unwind
        {
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&uid); /*0xf1c000000000028c*/
        }
        if ( *(_QWORD *)&uid.sessionId.timestamp != 0 ) /*0x14104ef3d*/
          std::_Ref_count_base::_Decref(this: *(std::_Ref_count_base **)&uid.sessionId.timestamp); /*0x14104ef3f*/
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&source); /*0x14104ef4a*/
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&source); /*0xf1c00000000000b4*/
      }
      goto LABEL_342; /*0xf1c00000000000b0*/
    case NetworkValueFormat_ValueTable:
      RBX::Network::deserializeUnsignedVarint(value: (unsigned int *)&networkId, stream: inBitStream); /*0x14104ef5e*/
      RBX::Network::Replicator::checkVariantContainerCountLimit( /*0x14104ef70*/
        count: (unsigned int)networkId.h,
        type: "ValueTable (read)");
      v108 = (std::unordered_map<std::string,RBX::Reflection::Variant> *)operator new(size: 0x40u); /*0x14104ef7a*/
      data = (RBX::Guid)v108; /*0x14104ef7f*/
      __wind /*0xf1c000000000027c*/
      {
        if ( v108 != nullptr ) /*0x14104ef86*/
          v109 = std::unordered_map<std::string,RBX::Reflection::Variant>::unordered_map<std::string,RBX::Reflection::Variant>(this: v108); /*0x14104ef8b*/
        else
          v109 = nullptr; /*0x14104ef92*/
      }
      __unwind
      {
        operator delete(ptr: *(void **)&data); /*0x1431e8465*/
      }
      std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant>>::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant>>( /*0x14104ef9d*/
        this: (std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> > *)&source,
        _Px: v109);
      __wind /*0xf1c0000000000258*/
      {
        keyBuffer._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14104efa3*/
        keyBuffer._Mypair._Myval2._Mysize = 0; /*0x14104efa7*/
        keyBuffer._Mypair._Myval2._Myres = 15; /*0x14104efab*/
        v110 = 0; /*0x14104efb7*/
        if ( LODWORD(networkId.h) != 0 ) /*0x14104efc0*/
        {
          v111 = deferredSharedStrings; /*0x14104efc2*/
          v112 = replicationMetaData; /*0x14104efc9*/
          __eh34_enter_wind_state(16, 17); /*0xf1c0000000000250*/
          do /*0x14104f02e*/
          {
            v113 = RBX::Network::Replicator::getReadPayloadLimit(this); /*0x14104efd3*/
            RBX::Network::deserializeString(value: &keyBuffer, stream: inBitStream, maxStringReadSize: v113); /*0x14104efe2*/
            v114 = std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,0>>::_Try_emplace<std::string const &,>( /*0x14104eff5*/
                     this: (std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,RBX::Reflection::Variant> >,0> > *)source.flyweight.h.h,
                     result: (std::pair<std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *,bool> *)&value,
                     _Keyval_arg: &keyBuffer);
            RBX::Network::Replicator::schemaReadVariant( /*0x14104f021*/
              this,
              inBitStream,
              useDictionaries,
              out: &v114->first->_Myval.second,
              depth,
              deferredSharedStrings: v111,
              replicationMetaData: v112);
            ++v110; /*0x14104f026*/
          }
          while ( v110 < LODWORD(networkId.h) ); /*0x14104f02e*/
        }
        else
        {
          __eh34_enter_wind_state(16, 17); /*0xf1c0000000000248*/
        }
        if ( DFFlag::ReplicatorCheckReadTableCollisions.value ) /*0x14104f03a*/
          this->analyzeEventVariantArgs( /*0x14104f048*/
            this,
            a2: (const std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> > *)&source);
        uid = 0; /*0x14104f051*/
        if ( *(_QWORD *)&source.readCount != 0 ) /*0x14104f05f*/
          _InterlockedIncrement((volatile signed __int32 *)(*(_QWORD *)&source.readCount + 8LL)); /*0x14104f061*/
        uid = (RBX::UniqueId)source; /*0x14104f06a*/
        __wind /*0xf1c000000000023c*/
        {
          v115 = out->desc; /*0x14104f077*/
          if ( v115 != nullptr ) /*0x14104f07e*/
            (*((void (__fastcall **)(RBX::Reflection::PropertyDescriptor_vtbl *, RBX::Instance *, RBX::UniqueId *))v115[1].dtr_Descriptor /*0x14104f08f*/
             + 4))(
              a1: v115[1].__vftable,
              a2: out->instance,
              a3: &uid);
        }
        __unwind
        {
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&uid); /*0xf1c0000000000234*/
        }
        if ( *(_QWORD *)&uid.sessionId.timestamp != 0 ) /*0x14104f09b*/
          std::_Ref_count_base::_Decref(this: *(std::_Ref_count_base **)&uid.sessionId.timestamp); /*0x14104f09d*/
        if ( keyBuffer._Mypair._Myval2._Myres >= 0x10 ) /*0x14104f0ab*/
        {
          v116 = keyBuffer._Mypair._Myval2._Bx._Ptr; /*0x14104f0b0*/
          if ( keyBuffer._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14104f0be*/
          {
            v116 = *((char **)keyBuffer._Mypair._Myval2._Bx._Ptr - 1); /*0x14104f0c4*/
            if ( (unsigned __int64)(keyBuffer._Mypair._Myval2._Bx._Ptr - v116 - 8) > 0x1F ) /*0x14104f0d3*/
              _invalid_parameter_noinfo_noreturn(); /*0x14104f0d5*/
          }
          operator delete(ptr: v116); /*0x14104f0dc*/
        }
        keyBuffer._Mypair._Myval2._Mysize = 0; /*0x14104f0e1*/
        keyBuffer._Mypair._Myval2._Myres = 15; /*0x14104f0e5*/
        keyBuffer._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14104f0ed*/
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&source); /*0x14104f0f6*/
        if ( __eh34_unwind(17) ) /*0xf1c0000000000424*/
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&keyBuffer); /*0xf1c0000000000428*/
          __eh34_continue_unwinding(17, 16); /*0xf1c000000000042c*/
        }
        __eh34_exit_wind_state(17, 16); /*0xf1c0000000000430*/
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&source); /*0xf1c0000000000268*/
      }
      goto LABEL_342; /*0xf1c0000000000264*/
    case NetworkValueFormat_ValueMap:
      RBX::Network::deserializeUnsignedVarint(value: (unsigned int *)&networkId, stream: inBitStream); /*0x14104f10a*/
      RBX::Network::Replicator::checkVariantContainerCountLimit( /*0x14104f11c*/
        count: (unsigned int)networkId.h,
        type: "ValueMap (read)");
      v117 = (std::map<std::string,cricket::RidDescription> *)operator new(size: 0x10u); /*0x14104f126*/
      data = (RBX::Guid)v117; /*0x14104f12b*/
      __wind /*0xf1c0000000000224*/
      {
        if ( v117 != nullptr ) /*0x14104f132*/
          v118 = (std::map<std::string,RBX::Reflection::Variant> *)std::map<std::string,RBX::Reflection::Variant>::map<std::string,RBX::Reflection::Variant>(this: v117); /*0x14104f137*/
        else
          v118 = nullptr; /*0x14104f13e*/
      }
      __unwind
      {
        operator delete(ptr: *(void **)&data); /*0x1431784a5*/
      }
      std::shared_ptr<std::map<std::string,RBX::Reflection::Variant>>::shared_ptr<std::map<std::string,RBX::Reflection::Variant>>( /*0x14104f149*/
        this: (std::shared_ptr<std::map<std::string,RBX::Reflection::Variant> > *)&source,
        _Px: v118);
      __wind /*0xf1c0000000000200*/
      {
        keyBuffer._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14104f14f*/
        keyBuffer._Mypair._Myval2._Mysize = 0; /*0x14104f153*/
        keyBuffer._Mypair._Myval2._Myres = 15; /*0x14104f157*/
        v119 = 0; /*0x14104f163*/
        if ( LODWORD(networkId.h) != 0 ) /*0x14104f16c*/
        {
          v120 = deferredSharedStrings; /*0x14104f16e*/
          v121 = (std::map<std::string,RBX::Reflection::Variant> *)source.flyweight.h.h; /*0x14104f175*/
          v122 = replicationMetaData; /*0x14104f17a*/
          __eh34_enter_wind_state(20, 21); /*0xf1c00000000001f8*/
          do /*0x14104f1dd*/
          {
            v123 = RBX::Network::Replicator::getReadPayloadLimit(this); /*0x14104f184*/
            RBX::Network::deserializeString(value: &keyBuffer, stream: inBitStream, maxStringReadSize: v123); /*0x14104f193*/
            v124 = std::map<std::string,RBX::Reflection::Variant>::_Try_emplace<std::string const &,>( /*0x14104f1a4*/
                     this: v121,
                     result: (std::pair<std::_Tree_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *,bool> *)&value,
                     _Keyval: &keyBuffer);
            RBX::Network::Replicator::schemaReadVariant( /*0x14104f1d0*/
              this,
              inBitStream,
              useDictionaries,
              out: &v124->first->_Myval.second,
              depth,
              deferredSharedStrings: v120,
              replicationMetaData: v122);
            ++v119; /*0x14104f1d5*/
          }
          while ( v119 < LODWORD(networkId.h) ); /*0x14104f1dd*/
        }
        else
        {
          __eh34_enter_wind_state(20, 21); /*0xf1c00000000001f0*/
        }
        uid = 0; /*0x14104f1e5*/
        if ( *(_QWORD *)&source.readCount != 0 ) /*0x14104f1f3*/
          _InterlockedIncrement((volatile signed __int32 *)(*(_QWORD *)&source.readCount + 8LL)); /*0x14104f1f5*/
        uid = (RBX::UniqueId)source; /*0x14104f1fe*/
        __wind /*0xf1c00000000001e4*/
        {
          v125 = out->desc; /*0x14104f20b*/
          if ( v125 != nullptr ) /*0x14104f212*/
            (*((void (__fastcall **)(RBX::Reflection::PropertyDescriptor_vtbl *, RBX::Instance *, RBX::UniqueId *))v125[1].dtr_Descriptor /*0x14104f223*/
             + 4))(
              a1: v125[1].__vftable,
              a2: out->instance,
              a3: &uid);
        }
        __unwind
        {
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&uid); /*0xf1c00000000001dc*/
        }
        if ( *(_QWORD *)&uid.sessionId.timestamp != 0 ) /*0x14104f22f*/
          std::_Ref_count_base::_Decref(this: *(std::_Ref_count_base **)&uid.sessionId.timestamp); /*0x14104f231*/
        if ( keyBuffer._Mypair._Myval2._Myres >= 0x10 ) /*0x14104f23f*/
        {
          v126 = keyBuffer._Mypair._Myval2._Bx._Ptr; /*0x14104f244*/
          if ( keyBuffer._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14104f252*/
          {
            v126 = *((char **)keyBuffer._Mypair._Myval2._Bx._Ptr - 1); /*0x14104f258*/
            if ( (unsigned __int64)(keyBuffer._Mypair._Myval2._Bx._Ptr - v126 - 8) > 0x1F ) /*0x14104f267*/
              _invalid_parameter_noinfo_noreturn(); /*0x14104f269*/
          }
          operator delete(ptr: v126); /*0x14104f270*/
        }
        keyBuffer._Mypair._Myval2._Mysize = 0; /*0x14104f275*/
        keyBuffer._Mypair._Myval2._Myres = 15; /*0x14104f279*/
        keyBuffer._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14104f281*/
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&source); /*0x14104f28a*/
        if ( __eh34_unwind(21) ) /*0xf1c0000000000438*/
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&keyBuffer); /*0xf1c000000000043c*/
          __eh34_continue_unwinding(21, 20); /*0xf1c0000000000440*/
        }
        __eh34_exit_wind_state(21, 20); /*0xf1c0000000000444*/
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&source); /*0xf1c0000000000210*/
      }
      goto LABEL_342; /*0xf1c000000000020c*/
    case NetworkValueFormat_ContentId:
      __eh34_enter_wind_state(-1, 0); /*0xf1c00000000001d0*/
      *(_QWORD *)&uid.sessionId.bits_hi = 0; /*0x14104f294*/
      Size = 0; /*0x14104f299*/
      v193 = 15; /*0x14104f29e*/
      if ( useDictionaries ) /*0x14104f2b2*/
      {
        RBX::Network::Replicator::readPrefixedContentId(this, inByteStream: inBitStream, contentId: (std::string *)&uid); /*0x14104f2bc*/
      }
      else
      {
        v127 = RBX::Network::Replicator::getReadPayloadLimit(this); /*0x14104f2c3*/
        RBX::Network::deserializeString(value: (std::string *)&uid, stream: inBitStream, maxStringReadSize: v127); /*0x14104f2d3*/
      }
      if ( DFFlag::NetworkReportContentIdLimit.value /*0x14104f31b*/
        && this->isServerReplicator(this)
        && !this->isCloudEdit(this)
        && Size > DFInt::NetworkReportContentIdLimitRead )
      {
        RBX::Time::nowFast(result: (RBX::Time *)&networkId); /*0x14104f328*/
        sec = this->lastContentIdLimitReport.sec; /*0x14104f32d*/
        if ( sec == 0.0 || *(double *)&networkId.h - sec >= (double)DFInt::NetworkReportContentIdLimitIntervalSeconds ) /*0x14104f35e*/
        {
          RBX::Analytics::InfluxDb::Points::Points( /*0x14104f372*/
            this: &points,
            throttleHundredthsPercentage: -1,
            categoryType: kStandardType,
            priorityHundredthsPercentage: 0);
          __wind /*0xf1c00000000001c4*/
          {
            RBX::Analytics::InfluxDb::Points::addPoint(this: &points, name: "Size", value: Size); /*0x14104f388*/
            v129 = DFInt::NetworkReportContentIdLimitMax; /*0x14104f38d*/
            keyBuffer._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14104f394*/
            keyBuffer._Mypair._Myval2._Mysize = 0; /*0x14104f398*/
            keyBuffer._Mypair._Myval2._Myres = 15; /*0x14104f39c*/
            if ( Size < DFInt::NetworkReportContentIdLimitMax ) /*0x14104f3ad*/
              v129 = Size; /*0x14104f3ad*/
            v130 = &uid; /*0x14104f3b3*/
            if ( v193 >= 0x10 ) /*0x14104f3be*/
              v130 = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x14104f3be*/
            std::string::assign(this: &keyBuffer, _Ptr: (const char *const)v130, _Count: v129); /*0x14104f3c8*/
            __eh34_enter_wind_state(23, 24); /*0xf1c00000000001bc*/
            RBX::Analytics::InfluxDb::Points::addPoint(this: &points, name: "ContentId", value: &keyBuffer); /*0x14104f3dd*/
            if ( __eh34_unwind(24) ) /*0xf1c00000000001b0*/
            {
unwind_state_24:
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&keyBuffer); /*0xf1c0000000000198*/
              __eh34_continue_unwinding(24, 23); /*0xf1c000000000019c*/
            }
            __eh34_exit_wind_state(24, 23); /*0xf1c00000000001b4*/
            if ( keyBuffer._Mypair._Myval2._Myres >= 0x10 ) /*0x14104f3eb*/
            {
              v131 = keyBuffer._Mypair._Myval2._Bx._Ptr; /*0x14104f3f0*/
              if ( keyBuffer._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14104f3fe*/
              {
                v131 = *((char **)keyBuffer._Mypair._Myval2._Bx._Ptr - 1); /*0x14104f404*/
                if ( (unsigned __int64)(keyBuffer._Mypair._Myval2._Bx._Ptr - v131 - 8) > 0x1F ) /*0x14104f413*/
                  _invalid_parameter_noinfo_noreturn(); /*0x14104f415*/
              }
              operator delete(ptr: v131); /*0x14104f41c*/
            }
            v132 = DFInt::NetworkReportContentIdLimitPerMyriad; /*0x14104f421*/
            keyBuffer._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14104f427*/
            keyBuffer._Mypair._Myval2._Mysize = 0; /*0x14104f42b*/
            keyBuffer._Mypair._Myval2._Myres = 15; /*0x14104f42f*/
            std::string::assign(this: &keyBuffer, _Ptr: "NetworkStreamContentIdLimit", _Count: 0x1Bu); /*0x14104f44c*/
            __eh34_enter_wind_state(23, 24); /*0xf1c00000000001a8*/
            RBX::Analytics::InfluxDb::Points::report( /*0x14104f460*/
              this: &points,
              resource: &keyBuffer,
              throttleHundredthsPercentage: v132,
              blocking: false);
            if ( __eh34_unwind(24) ) /*0xf1c0000000000194*/
              goto unwind_state_24; /*0xf1c0000000000194*/
            __eh34_exit_wind_state(24, 23); /*0xf1c00000000001a0*/
            if ( keyBuffer._Mypair._Myval2._Myres >= 0x10 ) /*0x14104f46e*/
            {
              v133 = keyBuffer._Mypair._Myval2._Bx._Ptr; /*0x14104f473*/
              if ( keyBuffer._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14104f481*/
              {
                v133 = *((char **)keyBuffer._Mypair._Myval2._Bx._Ptr - 1); /*0x14104f487*/
                if ( (unsigned __int64)(keyBuffer._Mypair._Myval2._Bx._Ptr - v133 - 8) > 0x1F ) /*0x14104f496*/
                  _invalid_parameter_noinfo_noreturn(); /*0x14104f498*/
              }
              operator delete(ptr: v133); /*0x14104f49f*/
            }
            this->lastContentIdLimitReport.sec = *(double *)&networkId.h; /*0x14104f4ac*/
            RBX::Analytics::InfluxDb::Points::~Points(this: &points); /*0x14104f4ba*/
          }
          __unwind
          {
            RBX::Analytics::InfluxDb::Points::~Points(this: &points); /*0xf1c000000000018c*/
          }
        }
      }
      if ( DFFlag::EnableContentIdLengthCheck.value
        && this->isServerReplicator(this)
        && !this->isCloudEdit(this)
        && DFInt::ContentIdMaxLength > 0
        && Size > DFInt::ContentIdMaxLength )
      {
        v184 = boost::multi_index::detail::auto_space<unsigned __int64,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>>>::data(this: (ShareModalController *)&uid); /*0x14104fe01*/
        v185 = RBX::format(
                 result: (RBX::Graphics::ProfilerAdorn::Item *)&v198,
                 fmt: "ContentId read: String too long: %zu",
                 (size_t)v184);
        __eh34_enter_wind_state(0, 25); /*0xf1c0000000000044*/
        RBX::network_stream_exception::network_stream_exception( /*0x14104fe21*/
          this: (RBX::network_stream_exception *)&cFrame,
          m: &v185->text);
        throw (RBX::network_stream_exception *)&cFrame; /*0x14104fe31*/
      }
      v134 = out->desc; /*0x14104f507*/
      if ( v134 != nullptr ) /*0x14104f50e*/
        v134->setStringValue(this: v134, a2: out->instance, a3: (const std::string *)&uid); /*0x14104f51b*/
      if ( __eh34_unwind(0) ) /*0xf1c0000000000170*/
        goto unwind_state_0; /*0xf1c0000000000170*/
      __eh34_exit_wind_state(0, -1); /*0xf1c0000000000174*/
      if ( v193 < 0x10 ) /*0x14104f528*/
        goto LABEL_342; /*0x14104f528*/
      Ptr = *(char **)&uid.sessionId.bits_hi; /*0x14104f531*/
      if ( v193 + 1 >= 0x1000 ) /*0x14104f540*/
      {
        Ptr = *(char **)(*(_QWORD *)&uid.sessionId.bits_hi - 8LL); /*0x14104f54a*/
        if ( (unsigned __int64)(*(_QWORD *)&uid.sessionId.bits_hi - (_QWORD)Ptr - 8LL) > 0x1F ) /*0x14104f559*/
          _invalid_parameter_noinfo_noreturn(); /*0x14104f55f*/
      }
      goto LABEL_44; /*0x14104f559*/
    case NetworkValueFormat_SystemAddress:
      RBX::Network::deserializeUnsignedVarint(value: (unsigned int *)&networkId, stream: inBitStream); /*0x14104f570*/
      LODWORD(value.flyweight.h.h) = networkId.h; /*0x14104f57b*/
      v135 = out->desc; /*0x14104f586*/
      if ( v135 != nullptr ) /*0x14104f58d*/
        (*((void (__fastcall **)(RBX::Reflection::PropertyDescriptor_vtbl *, RBX::Instance *, RBX::SharedString *))v135[1].dtr_Descriptor /*0x14104f5a2*/
         + 4))(
          a1: v135[1].__vftable,
          a2: out->instance,
          a3: &value);
      goto LABEL_342; /*0x14104f5a5*/
    case NetworkValueFormat_NumberSequence:
      NumberSequence = RBX::Network::NetworkStream::readNumberSequence( /*0x14104f5b2*/
                         this: inBitStream,
                         result: (RBX::NumberSequence *)&uid);
      __wind /*0xf1c0000000000164*/
      {
        v137 = out->desc; /*0x14104f5bf*/
        if ( v137 != nullptr ) /*0x14104f5c6*/
          (*((void (__fastcall **)(RBX::Reflection::PropertyDescriptor_vtbl *, RBX::Instance *, RBX::NumberSequence *))v137[1].dtr_Descriptor /*0x14104f5d9*/
           + 4))(
            a1: v137[1].__vftable,
            a2: out->instance,
            a3: NumberSequence);
      }
      __unwind
      {
        std::vector<RBX::HeightmapImporter::VoxelImportInfo>::_Tidy(this: (std::vector<VkVertexInputBindingDescription> *)&uid); /*0xf1c000000000015c*/
      }
      std::vector<RBX::HeightmapImporter::VoxelImportInfo>::_Tidy(this: (std::vector<VkVertexInputBindingDescription> *)&uid); /*0x14104f5e2*/
      goto LABEL_342; /*0x14104f5e7*/
    case NetworkValueFormat_ColorSequence:
      ColorSequence = RBX::Network::NetworkStream::readColorSequence( /*0x14104f608*/
                        this: inBitStream,
                        result: (RBX::ColorSequence *)&uid);
      __wind /*0xf1c000000000014c*/
      {
        v139 = out->desc; /*0x14104f615*/
        if ( v139 != nullptr ) /*0x14104f61c*/
          (*((void (__fastcall **)(RBX::Reflection::PropertyDescriptor_vtbl *, RBX::Instance *, RBX::ColorSequence *))v139[1].dtr_Descriptor /*0x14104f62f*/
           + 4))(
            a1: v139[1].__vftable,
            a2: out->instance,
            a3: ColorSequence);
      }
      __unwind
      {
        std::vector<GradientPoint>::_Tidy(this: (std::vector<webrtc::RtpPacketizerAv1::Packet> *)&uid); /*0xf1c0000000000144*/
      }
      std::vector<GradientPoint>::_Tidy(this: (std::vector<webrtc::RtpPacketizerAv1::Packet> *)&uid); /*0x14104f638*/
      goto LABEL_342; /*0x14104f63d*/
    case NetworkValueFormat_ColorSequenceKeypoint:
      UDim = (RBX::Rect2D *)RBX::Network::NetworkStream::readColorSequenceKeypoint( /*0x14104f65c*/
                              this: inBitStream,
                              result: (RBX::ColorSequenceKeypoint *)&uid);
      goto LABEL_105; /*0x14104f661*/
    case NetworkValueFormat_Rect2d:
      UDim = RBX::Network::NetworkStream::readRect2D(this: inBitStream, result: (RBX::Rect2D *)&uid); /*0x14104f66e*/
      goto LABEL_105; /*0x14104f673*/
    case NetworkValueFormat_PhysicalProperties:
      UDim = (RBX::Rect2D *)RBX::Network::NetworkStream::readPhysicalProperties( /*0x14104f680*/
                              this: inBitStream,
                              result: (RBX::PhysicalProperties *)&uid);
      goto LABEL_105; /*0x14104f685*/
    case NetworkValueFormat_Region3:
      UDim = (RBX::Rect2D *)RBX::Network::NetworkStream::readRegion3(this: inBitStream, result: (RBX::Region3 *)&points); /*0x14104f691*/
      goto LABEL_105; /*0x14104f696*/
    case NetworkValueFormat_Region3int16:
      UDim = (RBX::Rect2D *)RBX::Network::NetworkStream::readRegion3int16( /*0x14104f6a3*/
                              this: inBitStream,
                              result: (RBX::Region3int16 *)&value);
      goto LABEL_105; /*0x14104f6a8*/
    case NetworkValueFormat_Int64:
      RBX::Network::deserializeSignedVarint64((__int64 *)&value, stream: inBitStream); /*0x14104f6b5*/
      v68 = out; /*0x14104f6ba*/
      v69 = out->desc; /*0x14104f6c1*/
      if ( valueType->localConformance == LocalConformance_NetworkInt64LocalInt ) /*0x14104f6c9*/
      {
        LODWORD(networkId.h) = value.flyweight.h.h; /*0x14104f6d3*/
LABEL_291:
        if ( v69 != nullptr ) /*0x14104f6dc*/
          (*((void (__fastcall **)(RBX::Reflection::PropertyDescriptor_vtbl *, RBX::Instance *, boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *))v69[1].dtr_Descriptor /*0x14104f6f3*/
           + 4))(
            a1: v69[1].__vftable,
            a2: v68->instance,
            a3: &networkId);
      }
      else
      {
LABEL_98:
        if ( v69 != nullptr ) /*0x14104e8ee*/
          (*((void (__fastcall **)(RBX::Reflection::PropertyDescriptor_vtbl *, RBX::Instance *, RBX::SharedString *))v69[1].dtr_Descriptor /*0x14104e903*/
           + 4))(
            a1: v69[1].__vftable,
            a2: v68->instance,
            a3: &value);
      }
      goto LABEL_342; /*0x14104f6f6*/
    case NetworkValueFormat_SharedString:
      *(_QWORD *)&uid.sessionId.bits_hi = 0; /*0x14104f6fb*/
      Size = 0; /*0x14104f700*/
      v193 = 15; /*0x14104f705*/
      std::string::assign(this: (std::string *)&uid, _Count: 0x10u, _Ch: 0); /*0x14104f71f*/
      __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000138*/
      v140 = &uid; /*0x14104f725*/
      if ( v193 >= 0x10 ) /*0x14104f730*/
        v140 = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x14104f730*/
      RBX::Network::NetworkStream::readBytes( /*0x14104f73f*/
        this: inBitStream,
        inOutByteArray: (void *)v140,
        numberOfBytesToRead: 0x10u);
      boost::unordered::unordered_map<std::string,RBX::SharedString,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::SharedString>>>::find( /*0x14104f758*/
        this: &this->sharedStringReceiverDictionary,
        result: (boost::unordered::iterator_detail::iterator<boost::unordered::detail::ptr_node<std::pair<std::string const ,RBX::SharedString> > > *)&networkId,
        k: (const std::string *)&uid);
      v141 = networkId.h; /*0x14104f75d*/
      if ( *(double *)&networkId.h == 0.0 ) /*0x14104f767*/
      {
        v142 = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::vector<RBX::Network::DeferredSharedStringSetter>>>,std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string>,std::equal_to<std::string>>>::operator[]( /*0x14104f775*/
                 this: &deferredSharedStrings->table_,
                 k: (const std::string *)&uid);
        localConformance = valueType->localConformance; /*0x14104f77e*/
        v198.variantOut = nullptr; /*0x14104f782*/
        v198.desc = out->desc; /*0x14104f791*/
        v198.instance = out->instance; /*0x14104f798*/
        v198.localConformance = localConformance; /*0x14104f79c*/
        std::vector<RBX::Network::DeferredSharedStringSetter>::emplace_back<RBX::Network::DeferredSharedStringSetter>( /*0x14104f7a4*/
          this: &v142->second,
          <_Val_0>: (const std::optional<std::pair<Luau::AstName,Luau::Location> > *)&v198);
      }
      else
      {
        if ( DFFlag::ReportSharedStringBreakdown.value ) /*0x14104f7b5*/
          RBX::PolicyServiceAnalyticsStatReporter::incrementCallbackQueueExceededCount(this: (RBX::RVideo::Mp4IoWriter *)&networkId.h->ref); /*0x14104f7bb*/
        if ( valueType->localConformance == LocalConformance_NetworkSharedStringLocalBinaryString ) /*0x14104f7c4*/
        {
          Contents = (const rtc::webrtc_checks_impl::ToStringVal *)RBX::SharedString::getContents(this: (RBX::SharedString *)&v141->ref); /*0x14104f7ce*/
          v145 = std::string::string(this: (rtc::webrtc_checks_impl::ToStringVal *)&keyBuffer, __that: Contents); /*0x14104f7da*/
          v198.variantOut = nullptr; /*0x14104f7df*/
          *(_OWORD *)&v198.instance = 0; /*0x14104f7e6*/
          v198 = (RBX::Network::DeferredSharedStringSetter)*v145; /*0x14104f7ee*/
          v145->val._Mypair._Myval2._Mysize = 0; /*0x14104f7fa*/
          v145->val._Mypair._Myval2._Myres = 15; /*0x14104f7fe*/
          v145->val._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14104f806*/
          __wind /*0xf1c000000000012c*/
          {
            v146 = out->desc; /*0x14104f810*/
            if ( v146 != nullptr ) /*0x14104f817*/
              (*((void (__fastcall **)(RBX::Reflection::PropertyDescriptor_vtbl *, RBX::Instance *, RBX::Network::DeferredSharedStringSetter *))v146[1].dtr_Descriptor /*0x14104f827*/
               + 4))(
                a1: v146[1].__vftable,
                a2: out->instance,
                a3: &v198);
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v198); /*0xf1c0000000000124*/
          }
          if ( *(_QWORD *)&v198.localConformance >= 0x10u ) /*0x14104f833*/
          {
            variantOut = v198.variantOut; /*0x14104f838*/
            if ( (unsigned __int64)(*(_QWORD *)&v198.localConformance + 1LL) >= 0x1000 ) /*0x14104f846*/
            {
              variantOut = *(RBX::Reflection::Variant **)&v198.variantOut[-1].value.data[56]; /*0x14104f84c*/
              if ( (unsigned __int64)((char *)v198.variantOut - (char *)variantOut - 8) > 0x1F ) /*0x14104f85b*/
                _invalid_parameter_noinfo_noreturn(); /*0x14104f85d*/
            }
            operator delete(ptr: (void *)variantOut); /*0x14104f864*/
          }
        }
        else
        {
          v148 = out->desc; /*0x14104f876*/
          if ( v148 != nullptr ) /*0x14104f87d*/
            (*((void (__fastcall **)(RBX::Reflection::PropertyDescriptor_vtbl *, RBX::Instance *, boost::detail::atomic_count *))v148[1].dtr_Descriptor /*0x14104f889*/
             + 4))(
              a1: v148[1].__vftable,
              a2: out->instance,
              a3: &v141->ref);
        }
      }
      if ( __eh34_unwind(0) ) /*0xf1c0000000000114*/
        goto unwind_state_0; /*0xf1c0000000000114*/
      __eh34_exit_wind_state(0, -1); /*0xf1c0000000000118*/
      if ( v193 < 0x10 ) /*0x14104f896*/
        goto LABEL_342; /*0x14104f896*/
      Ptr = *(char **)&uid.sessionId.bits_hi; /*0x14104f89f*/
      if ( v193 + 1 >= 0x1000 ) /*0x14104f8ae*/
      {
        Ptr = *(char **)(*(_QWORD *)&uid.sessionId.bits_hi - 8LL); /*0x14104f8b8*/
        if ( (unsigned __int64)(*(_QWORD *)&uid.sessionId.bits_hi - (_QWORD)Ptr - 8LL) > 0x1F ) /*0x14104f8c7*/
          _invalid_parameter_noinfo_noreturn(); /*0x14104f8cd*/
      }
      goto LABEL_44; /*0x14104f8c7*/
    case NetworkValueFormat_ProtectedStringBytecode:
      if ( !DFFlag::ReplicatorReadPSWithout.value && this->sessionCrypto._Ptr == nullptr ) /*0x14104e0e2*/
      {
        if ( DFLog::SessionCrypto == 0 ) /*0x14104e0ed*/
          goto $LN2_9; /*0x14104e0ed*/
        FLog::FastLog( /*0x14104e0fd*/
          level: DFLog::SessionCrypto,
          message: "[DFLog::SessionCrypto] Can't recv protected bytecode due to missing SessionCrypto.",
          arg0: nullptr);
        goto LABEL_342; /*0x14104e102*/
      }
      v14 = operator new(size: 0x20u); /*0x14104e124*/
      Size = 16; /*0x14104e129*/
      v193 = 31; /*0x14104e132*/
      *(_OWORD *)v14 = 0; /*0x14104e13e*/
      v14[16] = 0; /*0x14104e141*/
      *(_QWORD *)&uid.sessionId.bits_hi = v14; /*0x14104e145*/
      __eh34_enter_wind_state(-1, 0); /*0xf1c000000000041c*/
      RBX::SharedString::SharedString(this: &source); /*0x14104e14f*/
      __eh34_enter_wind_state(0, 1); /*0xf1c0000000000414*/
      v15 = &uid; /*0x14104e155*/
      if ( v193 >= 0x10 ) /*0x14104e160*/
        v15 = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x14104e160*/
      RBX::Network::NetworkStream::readBytes(this: inBitStream, inOutByteArray: (void *)v15, numberOfBytesToRead: 0x10u); /*0x14104e16f*/
      v16 = &uid; /*0x14104e174*/
      v17 = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x14104e179*/
      v18 = v193; /*0x14104e17e*/
      if ( v193 >= 0x10 ) /*0x14104e187*/
        v16 = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x14104e187*/
      v19 = Size; /*0x14104e18b*/
      v20 = &v16[Size / 0x10]; /*0x14104e190*/
      v21 = &uid; /*0x14104e193*/
      if ( v193 >= 0x10 ) /*0x14104e19c*/
        v21 = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x14104e19c*/
      v22 = 0; /*0x14104e1a0*/
      if ( v21 != v20 ) /*0x14104e1a6*/
      {
        do /*0x14104e1d5*/
        {
          v22 ^= (v22 >> 2) + 2654435769u + (v22 << 6) + SLOBYTE(v21->sessionId.bits_hi); /*0x14104e1cc*/
          v21 = (RBX::UniqueId *)((char *)v21 + 1); /*0x14104e1cf*/
        }
        while ( v21 != v20 ); /*0x14104e1d5*/
        v17 = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x14104e1d7*/
        v18 = v193; /*0x14104e1dc*/
      }
      v23 = 265 * ((~v22 + (v22 << 21)) ^ ((~v22 + (v22 << 21)) >> 24)); /*0x14104e1f8*/
      v24 = 2147483649u * (((21 * (v23 ^ (v23 >> 14))) >> 28) ^ (21 * (v23 ^ (v23 >> 14)))); /*0x14104e21c*/
      v25.h = (const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *)(this->sharedStringReceiverDictionary.table_.bucket_count_ - 1); /*0x14104e228*/
      networkId.h = v25.h; /*0x14104e22b*/
      v26 = (unsigned __int64)v25.h & v24; /*0x14104e235*/
      if ( this->sharedStringReceiverDictionary.table_.size_ == 0 ) /*0x14104e241*/
        goto LABEL_32; /*0x14104e241*/
      v27 = this->sharedStringReceiverDictionary.table_.buckets_[v26].next_; /*0x14104e24b*/
      if ( v27 == nullptr ) /*0x14104e252*/
        goto LABEL_32; /*0x14104e252*/
      v28 = v27->next_; /*0x14104e254*/
      if ( v28 == nullptr ) /*0x14104e25a*/
        goto LABEL_32; /*0x14104e25a*/
      while ( 2 ) /*0x14104e260*/
      {
        v29 = v28[1].next_; /*0x14104e260*/
        if ( (boost::unordered::detail::ptr_bucket *)v24 != v29 ) /*0x14104e267*/
        {
          if ( ((unsigned __int64)v25.h & (unsigned __int64)v29) != v26 ) /*0x14104e2be*/
          {
LABEL_32:
            v32 = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::vector<RBX::Network::DeferredSharedStringSetter>>>,std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string>,std::equal_to<std::string>>>::operator[]( /*0x14104e2c0*/
                    this: &deferredSharedStrings->table_,
                    k: (const std::string *)&uid);
            v198.variantOut = nullptr; /*0x14104e2d5*/
            v33 = out; /*0x14104e2d9*/
            v198.desc = out->desc; /*0x14104e2e4*/
            v198.instance = out->instance; /*0x14104e2eb*/
            v198.localConformance = LocalConformance_NetworkProtectedStringBytecode; /*0x14104e2ef*/
            std::vector<RBX::Network::DeferredSharedStringSetter>::emplace_back<RBX::Network::DeferredSharedStringSetter>( /*0x14104e2fa*/
              this: &v32->second,
              <_Val_0>: (const std::optional<std::pair<Luau::AstName,Luau::Location> > *)&v198);
            goto LABEL_33; /*0x14104e2fa*/
          }
LABEL_29:
          v28 = v28->next_; /*0x14104e2a4*/
          if ( v28 != nullptr ) /*0x14104e2aa*/
          {
            v17 = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x14104e2ac*/
            v18 = v193; /*0x14104e2b1*/
            continue; /*0x14104e2b6*/
          }
          goto LABEL_32; /*0x14104e2aa*/
        }
        break;
      }
      v30 = v28 + 2; /*0x14104e269*/
      if ( v28[5].next_ >= (boost::unordered::detail::ptr_bucket *)0x10 ) /*0x14104e276*/
        v30 = v30->next_; /*0x14104e278*/
      v31 = &uid; /*0x14104e27b*/
      if ( v18 >= 0x10 ) /*0x14104e284*/
        v31 = v17; /*0x14104e284*/
      if ( (boost::unordered::detail::ptr_bucket *)v19 != v28[4].next_ || memcmp_0(Buf1: v31, Buf2: v30, Size: v19) != 0 ) /*0x14104e297*/
      {
        v25.h = networkId.h; /*0x14104e29d*/
        goto LABEL_29; /*0x14104e29d*/
      }
      if ( DFFlag::ReportSharedStringBreakdown.value ) /*0x14104e37f*/
        RBX::PolicyServiceAnalyticsStatReporter::incrementCallbackQueueExceededCount(this: (RBX::RVideo::Mp4IoWriter *)&v28[6]); /*0x14104e385*/
      networkId.h = (const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *)v28[6].next_; /*0x14104e38e*/
      _InterlockedIncrement(&networkId.h->ref.value_); /*0x14104e395*/
      v35 = source.flyweight.h.h; /*0x14104e399*/
      source.flyweight.h = networkId; /*0x14104e3a5*/
      networkId.h = v35; /*0x14104e3aa*/
      boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: &networkId); /*0x14104e3b8*/
      source.readCount = (unsigned int)v28[7].next_; /*0x14104e3c0*/
      v36 = RBX::ProtectedString::fromSharedBytecode(result: (RBX::ProtectedString *)&keyBuffer, stringRef: &source); /*0x14104e3cd*/
      __eh34_enter_wind_state(1, 2); /*0xf1c0000000000400*/
      v33 = out; /*0x14104e3d3*/
      v37 = out->desc; /*0x14104e3da*/
      if ( v37 != nullptr ) /*0x14104e3e1*/
        (*((void (__fastcall **)(RBX::Reflection::PropertyDescriptor_vtbl *, RBX::Instance *, RBX::ProtectedString *))v37[1].dtr_Descriptor /*0x14104e3f4*/
         + 4))(
          a1: v37[1].__vftable,
          a2: out->instance,
          a3: v36);
      if ( __eh34_unwind(2) ) /*0xf1c00000000003f4*/
      {
unwind_state_2:
        RBX::ProtectedString::~ProtectedString(this: (RBX::Scripting::DebuggerEvalExpression *)&keyBuffer); /*0xf1c00000000003ac*/
        __eh34_continue_unwinding(2, 1); /*0xf1c00000000003b0*/
      }
      __eh34_exit_wind_state(2, 1); /*0xf1c00000000003f8*/
      boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: (boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *)&keyBuffer._Mypair._Myval2._Mysize); /*0x14104e3fc*/
      boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: (boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *)&keyBuffer); /*0x14104e405*/
LABEL_33:
      if ( v33->instance->guid.scope.peerId.peerId == -1 /*0x14104e317*/
        || v33->networkId == RBX::Network::NetworkSchema::kInvalidNetworkId )
      {
        RBX::throw_runtime_error(fmt: "Invalid Bytecode."); /*0x14104fdad*/
      }
      if ( __eh34_unwind(1) ) /*0xf1c0000000000408*/
      {
unwind_state_1:
        RBX::SharedString::~SharedString(this: &source); /*0xf1c00000000003c8*/
        __eh34_continue_unwinding(1, 0); /*0xf1c00000000003cc*/
      }
      __eh34_exit_wind_state(1, 0); /*0xf1c000000000040c*/
      boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: &source.flyweight.h); /*0x14104e322*/
      if ( v193 >= 0x10 ) /*0x14104e331*/
      {
        Ptr = *(char **)&uid.sessionId.bits_hi; /*0x14104e33a*/
        if ( v193 + 1 >= 0x1000 ) /*0x14104e349*/
        {
          Ptr = *(char **)(*(_QWORD *)&uid.sessionId.bits_hi - 8LL); /*0x14104e353*/
          if ( (unsigned __int64)(*(_QWORD *)&uid.sessionId.bits_hi - (_QWORD)Ptr - 8LL) > 0x1F ) /*0x14104e362*/
            _invalid_parameter_noinfo_noreturn(); /*0x14104e368*/
        }
        goto LABEL_520; /*0x14104e362*/
      }
      if ( __eh34_unwind(0) ) /*0xf1c0000000000090*/
        goto unwind_state_0; /*0xf1c0000000000090*/
LABEL_400:
      __eh34_exit_wind_state(0, -1); /*0xf1c000000000009c*/
LABEL_342:
      readOffset = v204; /*0x14104fb3d*/
$LN2_9: /*0x14104fb44*/
      v166 = false; /*0x14104fb44*/
      if ( DFInt::ReplicationVariantReportingLimitDepth != 0 ) /*0x14104fb55*/
        v166 = depth > DFInt::ReplicationVariantReportingLimitDepth; /*0x14104fb62*/
      v167 = false; /*0x14104fb66*/
      v168 = false; /*0x14104fb69*/
      v169 = inBitStream->readOffset - readOffset; /*0x14104fb70*/
      if ( DFInt::ReplicationVariantReportingLimitBytes != 0 ) /*0x14104fb7b*/
        v167 = v169 > DFInt::ReplicationVariantReportingLimitBytes; /*0x14104fb83*/
      if ( DFInt::ReplicationVariantKickLimitBytes != 0 ) /*0x14104fb8f*/
        v168 = v169 > DFInt::ReplicationVariantKickLimitBytes; /*0x14104fb97*/
      v170 = false; /*0x14104fb9b*/
      v171 = false; /*0x14104fb9e*/
      replicatedStringDataSizeLimit = replicationMetaData->replicatedStringDataSizeLimit; /*0x14104fba7*/
      if ( replicatedStringDataSizeLimit != 0 ) /*0x14104fbac*/
        v170 = replicationMetaData->replicatedStringDataSize > replicatedStringDataSizeLimit; /*0x14104fbb4*/
      variantCountLimit = replicationMetaData->variantCountLimit; /*0x14104fbb7*/
      if ( variantCountLimit != 0 ) /*0x14104fbbc*/
        v171 = replicationMetaData->variantCount > variantCountLimit; /*0x14104fbc4*/
      v174 = false; /*0x14104fbc7*/
      v175 = false; /*0x14104fbca*/
      if ( DFFlag::ReplicatorSeparateVarThresholds.value ) /*0x14104fbd4*/
      {
        replicatedStringDataSizeReportingThreshold = replicationMetaData->replicatedStringDataSizeReportingThreshold; /*0x14104fbd6*/
        if ( replicatedStringDataSizeReportingThreshold != 0 ) /*0x14104fbdb*/
          v175 = replicationMetaData->replicatedStringDataSize > replicatedStringDataSizeReportingThreshold; /*0x14104fbe3*/
        variantCountReportingThreshold = replicationMetaData->variantCountReportingThreshold; /*0x14104fbe7*/
        if ( variantCountReportingThreshold != 0 ) /*0x14104fbec*/
          v174 = replicationMetaData->variantCount > variantCountReportingThreshold; /*0x14104fbf5*/
      }
      v178 = false; /*0x14104fbf9*/
      v179 = DFFlag::EventMetaDataReportingTypeAndMem.value; /*0x14104fbfc*/
      if ( DFFlag::EventMetaDataReportingTypeAndMem.value && DFInt::EventMetaDataReportingTotalMemoryRcvThreshold != 0 ) /*0x14104fc0e*/
      {
        v178 = replicationMetaData->replicatedStringDataSize + 80 * (unsigned __int64)replicationMetaData->variantCount > DFInt::EventMetaDataReportingTotalMemoryRcvThreshold; /*0x14104fc35*/
        v179 = DFFlag::EventMetaDataReportingTypeAndMem.value; /*0x14104fc39*/
      }
      if ( DFFlag::ReplicatorSeparateVarThresholds.value ) /*0x14104fc47*/
      {
        if ( v174 ) /*0x14104fc4c*/
          goto LABEL_371; /*0x14104fc4c*/
        v180 = !v175; /*0x14104fc4e*/
      }
      else
      {
        if ( v170 ) /*0x14104fc56*/
          goto LABEL_371; /*0x14104fc56*/
        v180 = !v171; /*0x14104fc58*/
      }
      if ( v180 && !v167 && !v166 && (!v179 || !v178) ) /*0x14104fc71*/
      {
        v182 = replicationMetaData; /*0x14104fd0c*/
        goto LABEL_378; /*0x14104fd0c*/
      }
LABEL_371:
      v198.variantOut = nullptr; /*0x14104fc77*/
      v198.instance = nullptr; /*0x14104fc7b*/
      *(_QWORD *)&v198.localConformance = 15; /*0x14104fc7f*/
      std::string::assign(this: (std::string *)&v198, _Ptr: "ReplicatorReadVariantLimit", _Count: 0x1Au); /*0x14104fc9c*/
      __wind /*0xf1c0000000000084*/
      {
        v182 = replicationMetaData; /*0x14104fcbc*/
        RBX::Network::Replicator::reportEventParameterLimitReached( /*0x14104fcc6*/
          metaData: replicationMetaData,
          levelNestedStreamSizeBytes: v169,
          table: (const std::string *)&v198,
          evtSerializationReportData: &this->evtDeserializationReportData,
          depth);
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v198); /*0xf1c000000000007c*/
      }
      if ( *(_QWORD *)&v198.localConformance >= 0x10u ) /*0x14104fcd4*/
      {
        v181 = v198.variantOut; /*0x14104fcd9*/
        if ( (unsigned __int64)(*(_QWORD *)&v198.localConformance + 1LL) >= 0x1000 ) /*0x14104fce7*/
        {
          v181 = *(RBX::Reflection::Variant **)&v198.variantOut[-1].value.data[56]; /*0x14104fced*/
          if ( (unsigned __int64)((char *)v198.variantOut - (char *)v181 - 8) > 0x1F ) /*0x14104fcfc*/
            _invalid_parameter_noinfo_noreturn(); /*0x14104fcfe*/
        }
        operator delete(ptr: (void *)v181); /*0x14104fd05*/
      }
LABEL_378:
      if ( DFFlag::ReplicatorKickReadEventStringDataAndVariantLimit.value )
      {
        if ( v170 )
        {
          v188 = RBX::format(
                   result: (RBX::Graphics::ProfilerAdorn::Item *)&cFrame,
                   fmt: "Replicator read variant: Total string data size exceed limit! (%u)",
                   v182->replicatedStringDataSize);
          __eh34_enter_wind_state(-1, 32); /*0xf1c0000000000034*/
          RBX::network_stream_exception::network_stream_exception( /*0x14104fe8e*/
            this: (RBX::network_stream_exception *)&points,
            m: &v188->text);
          throw (RBX::network_stream_exception *)&points; /*0x14104fe9e*/
        }
        if ( v171 )
        {
          v189 = RBX::format(
                   result: (RBX::Graphics::ProfilerAdorn::Item *)&cFrame,
                   fmt: "Replicator read variant: Variant count exceeded limit! (%u)",
                   v182->variantCount);
          __eh34_enter_wind_state(-1, 32); /*0xf1c000000000002c*/
          RBX::network_stream_exception::network_stream_exception( /*0x14104fec0*/
            this: (RBX::network_stream_exception *)&points,
            m: &v189->text);
          throw (RBX::network_stream_exception *)&points; /*0x14104fed0*/
        }
      }
      if ( DFFlag::ReplicatorKickBigV.value && v168 )
      {
        v190 = RBX::format(
                 result: (RBX::Graphics::ProfilerAdorn::Item *)&cFrame,
                 fmt: "Replicator read variant: Variant read size exceeded limit! (%u)",
                 v169);
        __eh34_enter_wind_state(-1, 32); /*0xf1c0000000000024*/
        RBX::network_stream_exception::network_stream_exception( /*0x14104fef1*/
          this: (RBX::network_stream_exception *)&points,
          m: &v190->text);
        throw (RBX::network_stream_exception *)&points; /*0x14104ff01*/
      }
      return; /*0x14104fd3f*/
    case NetworkValueFormat_DateTime:
      UDim = (RBX::Rect2D *)RBX::Network::NetworkStream::readDateTime(this: inBitStream, result: (RBX::DateTime *)&uid); /*0x14104f8dc*/
      goto LABEL_105; /*0x14104f8e1*/
    case NetworkValueFormat_String_FixedDictionary:
      Byte = RBX::Network::NetworkStream::readByte(this: inBitStream); /*0x14104f8e9*/
      if ( (Byte & 0x80u) == 0 )
      {
        *(_QWORD *)&uid.sessionId.bits_hi = 0; /*0x14104f945*/
        Size = 0; /*0x14104f94a*/
        v193 = 15; /*0x14104f94f*/
        __eh34_enter_wind_state(-1, 0); /*0xf1c000000000010c*/
        if ( Byte >= 0x7Fu )
        {
          v154 = RBX::Network::Replicator::getReadPayloadLimit(this); /*0x14104f9a4*/
          RBX::Network::deserializeString(value: (std::string *)&uid, stream: inBitStream, maxStringReadSize: v154); /*0x14104f9b4*/
        }
        else
        {
          v152 = Byte; /*0x14104f961*/
          if ( Byte > inBitStream->numberOfBytesUsed - inBitStream->readOffset )
          {
            NumberOfUnreadBytes = RBX::Network::NetworkStream::GetNumberOfUnreadBytes(this: inBitStream); /*0x14104fe3a*/
            v187 = RBX::format(
                     result: (RBX::Graphics::ProfilerAdorn::Item *)&v198,
                     fmt: "BitStream string read: String too long (%u requested %u available)",
                     v152,
                     NumberOfUnreadBytes);
            __eh34_enter_wind_state(0, 25); /*0xf1c000000000003c*/
            RBX::network_stream_exception::network_stream_exception( /*0x14104fe5d*/
              this: (RBX::network_stream_exception *)&cFrame,
              m: &v187->text);
            throw (RBX::network_stream_exception *)&cFrame; /*0x14104fe6d*/
          }
          std::string::resize(this: (std::string *)&uid, _Newsize: Byte, _Ch: 0); /*0x14104f97e*/
          v153 = &uid; /*0x14104f983*/
          if ( v193 >= 0x10 ) /*0x14104f98e*/
            v153 = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x14104f98e*/
          RBX::Network::NetworkStream::readBytes( /*0x14104f99a*/
            this: inBitStream,
            inOutByteArray: (void *)v153,
            numberOfBytesToRead: v152);
        }
        replicationMetaData->replicatedStringDataSize += Size; /*0x14104f9c4*/
        v155 = out->desc; /*0x14104f9cd*/
        if ( v155 != nullptr ) /*0x14104f9d4*/
          (*((void (__fastcall **)(RBX::Reflection::PropertyDescriptor_vtbl *, RBX::Instance *, RBX::UniqueId *))v155[1].dtr_Descriptor /*0x14104f9e5*/
           + 4))(
            a1: v155[1].__vftable,
            a2: out->instance,
            a3: &uid);
        if ( __eh34_unwind(0) ) /*0xf1c00000000000ec*/
        {
unwind_state_0:
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&uid); /*0xf1c0000000000094*/
          __eh34_propagate_exception_into_caller(0, -1); /*0xf1c0000000000098*/
        }
        __eh34_exit_wind_state(0, -1); /*0xf1c00000000000f0*/
        if ( v193 >= 0x10 ) /*0x14104f9f2*/
        {
          Ptr = *(char **)&uid.sessionId.bits_hi; /*0x14104f9fb*/
          if ( v193 + 1 >= 0x1000 ) /*0x14104fa0a*/
          {
            Ptr = *(char **)(*(_QWORD *)&uid.sessionId.bits_hi - 8LL); /*0x14104fa14*/
            if ( (unsigned __int64)(*(_QWORD *)&uid.sessionId.bits_hi - (_QWORD)Ptr - 8LL) > 0x1F ) /*0x14104fa23*/
              _invalid_parameter_noinfo_noreturn(); /*0x14104fa29*/
          }
          goto LABEL_44; /*0x14104fa23*/
        }
      }
      else
      {
        v150 = Byte & 0x7F; /*0x14104f8f2*/
        LODWORD(networkId.h) = 0; /*0x14104f8f4*/
        if ( v150 >= 0x7Fu ) /*0x14104f8fd*/
        {
          RBX::Network::deserializeUnsignedVarint(value: (unsigned int *)&networkId, stream: inBitStream); /*0x14104f90e*/
          v151 = LODWORD(networkId.h) + 127; /*0x14104f919*/
        }
        else
        {
          v151 = v150; /*0x14104f8ff*/
        }
        LODWORD(networkId.h) = v151; /*0x14104f91c*/
        UDim = (RBX::Rect2D *)RBX::Network::NetworkSchema::fixedDictionaryStringFromNetworkId( /*0x14104f92d*/
                                this: this->networkSchema,
                                networkId: v151);
        replicationMetaData->replicatedStringDataSize += *(_QWORD *)&UDim[1].min.x; /*0x14104f93d*/
LABEL_105:
        v71 = out->desc; /*0x14104e994*/
        if ( v71 != nullptr ) /*0x14104e9a2*/
          (*((void (__fastcall **)(RBX::Reflection::PropertyDescriptor_vtbl *, RBX::Instance *, RBX::Rect2D *))v71[1].dtr_Descriptor /*0x14104e9b9*/
           + 4))(
            a1: v71[1].__vftable,
            a2: out->instance,
            a3: UDim);
      }
      goto LABEL_342; /*0x14104e9bc*/
    case NetworkValueFormat_OptionalCoordinateFrame_ExactEncoding:
      webrtc::AudioNetworkAdaptorImpl::Config::Config(this: (Json::Value::CommentInfo *)&networkId); /*0x14104eaea*/
      __eh34_enter_wind_state(-1, 6); /*0xf1c0000000000358*/
      RBX::Network::deserializeOptionalCoordinateFrameExact( /*0x14104eafa*/
        optionalCFrame: (RBX::OptionalCoordinateFrame *)&networkId,
        bitStream: inBitStream);
      v73 = out->desc; /*0x14104eb06*/
      if ( v73 != nullptr ) /*0x14104eb0d*/
        (*((void (__fastcall **)(RBX::Reflection::PropertyDescriptor_vtbl *, RBX::Instance *, boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *))v73[1].dtr_Descriptor /*0x14104eb20*/
         + 4))(
          a1: v73[1].__vftable,
          a2: out->instance,
          a3: &networkId);
      if ( __eh34_unwind(6) ) /*0xf1c000000000034c*/
        goto unwind_state_6; /*0xf1c000000000034c*/
      goto LABEL_500; /*0xf1c000000000034c*/
    case NetworkValueFormat_OptionalCoordinateFrame_GeneralEncoding:
      OptionalCoordinateFrame = RBX::Network::NetworkStream::readOptionalCoordinateFrame( /*0x14104eb3f*/
                                  this: inBitStream,
                                  result: (RBX::OptionalCoordinateFrame *)&networkId);
      __eh34_enter_wind_state(-1, 6); /*0xf1c0000000000344*/
      v75 = out->desc; /*0x14104eb4c*/
      if ( v75 != nullptr ) /*0x14104eb53*/
        (*((void (__fastcall **)(RBX::Reflection::PropertyDescriptor_vtbl *, RBX::Instance *, RBX::OptionalCoordinateFrame *))v75[1].dtr_Descriptor /*0x14104eb66*/
         + 4))(
          a1: v75[1].__vftable,
          a2: out->instance,
          a3: OptionalCoordinateFrame);
      if ( __eh34_unwind(6) ) /*0xf1c0000000000330*/
      {
unwind_state_6:
        RBX::OptionalCoordinateFrame::~OptionalCoordinateFrame(this: (RBX::OptionalCoordinateFrame *)&networkId); /*0xf1c0000000000334*/
        __eh34_propagate_exception_into_caller(6, -1); /*0xf1c0000000000338*/
      }
LABEL_500:
      __eh34_exit_wind_state(6, -1); /*0xf1c0000000000350*/
      RBX::OptionalCoordinateFrame::~OptionalCoordinateFrame(this: (RBX::OptionalCoordinateFrame *)&networkId); /*0x14104eb2b*/
      goto LABEL_342; /*0x14104eb30*/
    case NetworkValueFormat_UniqueId:
      UInt64 = RBX::Network::NetworkStream::readUInt64(this: inBitStream); /*0x14104fa38*/
      UInt32 = RBX::Network::NetworkStream::readUInt32(this: inBitStream); /*0x14104fa43*/
      v158 = RBX::Network::NetworkStream::readUInt32(this: inBitStream); /*0x14104fa4d*/
      *(RBX::UniqueSessionId *)&value.flyweight.h.h = *RBX::UniqueSessionId::UniqueSessionId( /*0x14104fa63*/
                                                         this: (RBX::UniqueSessionId *)&source,
                                                         rawbits: UInt64,
                                                         timestamp: UInt32);
      RBX::UniqueId::UniqueId(this: &uid, sessionId: (RBX::UniqueSessionId *)&value, index: v158); /*0x14104fa7d*/
      v159 = out->desc; /*0x14104fa89*/
      if ( v159 != nullptr ) /*0x14104fa90*/
        (*((void (__fastcall **)(RBX::Reflection::PropertyDescriptor_vtbl *, RBX::Instance *, RBX::UniqueId *))v159[1].dtr_Descriptor /*0x14104faa5*/
         + 4))(
          a1: v159[1].__vftable,
          a2: out->instance,
          a3: &uid);
      goto LABEL_342; /*0x14104faa8*/
    case NetworkValueFormat_PathWaypointWithLabel:
      v160 = RBX::Network::Replicator::getReadPayloadLimit(this); /*0x14104fab0*/
      PathWaypointWithLabel = RBX::Network::NetworkStream::readPathWaypointWithLabel( /*0x14104fac0*/
                                this: inBitStream,
                                result: (RBX::PathWaypoint *)&uid,
                                readPayloadLimit: v160);
      __wind /*0xf1c00000000000e0*/
      {
        v162 = out->desc; /*0x14104facd*/
        if ( v162 != nullptr ) /*0x14104fad4*/
          (*((void (__fastcall **)(RBX::Reflection::PropertyDescriptor_vtbl *, RBX::Instance *, RBX::PathWaypoint *))v162[1].dtr_Descriptor /*0x14104fae7*/
           + 4))(
            a1: v162[1].__vftable,
            a2: out->instance,
            a3: PathWaypointWithLabel);
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&uid); /*0xf1c00000000000d8*/
      }
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&uid); /*0x14104faf0*/
      goto LABEL_342; /*0x14104faf5*/
    case NetworkValueFormat_Font:
      v163 = RBX::Network::Replicator::getReadPayloadLimit(this); /*0x14104fafa*/
      Font = RBX::Network::NetworkStream::readFont( /*0x14104fb09*/
               this: inBitStream,
               result: (RBX::Text::FontInfo *)&points,
               maxStringReadSize: v163);
      __wind /*0xf1c00000000000c8*/
      {
        v165 = out->desc; /*0x14104fb16*/
        if ( v165 != nullptr ) /*0x14104fb1d*/
          (*((void (__fastcall **)(RBX::Reflection::PropertyDescriptor_vtbl *, RBX::Instance *, RBX::Text::FontInfo *))v165[1].dtr_Descriptor /*0x14104fb30*/
           + 4))(
            a1: v165[1].__vftable,
            a2: out->instance,
            a3: Font);
      }
      __unwind
      {
        RBX::Text::FontInfo::~FontInfo(this: (RBX::Text::FontInfo *)&points); /*0xf1c00000000000c0*/
      }
      RBX::Text::FontInfo::~FontInfo(this: (RBX::Text::FontInfo *)&points); /*0x14104fb38*/
      goto LABEL_342; /*0x14104fb38*/
    default:
      RBX::runtime_error(result: (std::runtime_error *)&uid, fmt: "Cannot read property value: unhandled type");
      throw (std::runtime_error *)&uid; /*0x14104fd77*/
  }
}

// END InstanceValueSetter part 1/1, 1 functions
