// _1_ -- 2022 Studio + full PDB
// tier 3, 400 functions, part 1 of 4


// Address: 0x14315d500 | Name: _RBX::Network::MegaReplicator::addToRebroadcastList_::_1_::dtor$3
void __fastcall RBX::Network::MegaReplicator::addToRebroadcastList_::_1_::dtor_3(__int64 a1, __int64 a2)
{
  operator delete(ptr: *(void **)(a2 + 360)); /*0x14315d515*/
}

// Address: 0x14315e8f0 | Name: _RBX::Network::ClientReplicator::GCJob::GCJob_::_1_::dtor$61
void __fastcall RBX::Network::ClientReplicator::GCJob::GCJob_::_1_::dtor_61(__int64 a1, __int64 a2)
{
  if ( (*(_DWORD *)(a2 + 240) & 1) != 0 ) /*0x14315e904*/
  {
    *(_DWORD *)(a2 + 240) &= ~1u; /*0x14315e906*/
    rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)(a2 + 80)); /*0x14315e911*/
  }
}

// Address: 0x143161ce0 | Name: _RBX::Network::Replicator::schemaReadValue_RBX::Network::InstanceValueSetter__::_1_::dtor$76
void __fastcall RBX::Network::Replicator::schemaReadValue_RBX::Network::InstanceValueSetter__::_1_::dtor_76(
        __int64 a1,
        MicroProfileScopeLock *a2)
{
  std::scoped_lock<RBX::InstrumentedMutex<std::recursive_mutex>>::~scoped_lock<RBX::InstrumentedMutex<std::recursive_mutex>>(this: a2 + 61); /*0x143161ce7*/
}

// Address: 0x143162850 | Name: _std::vector_RBX::Network::DisconnectingReplicatorMetaData_std::allocator_RBX::Network::DisconnectingReplicatorMetaData___::_Emplace_reallocate_std::weak_ptr_RBX::Network::Replicator__int_&__::_1_::catch$3
void __fastcall __noreturn std::vector_RBX::Network::DisconnectingReplicatorMetaData_std::allocator_RBX::Network::DisconnectingReplicatorMetaData___::_Emplace_reallocate_std::weak_ptr_RBX::Network::Replicator__int____::_1_::catch_3(
        __int64 a1,
        __int64 a2)
{
  std::vector<std::pair<std::weak_ptr<RBX::Instance>,enum RBX::Instance::PropertyOverrideStatus>>::_Destroy( /*0x143162870*/
    this: *(std::vector<std::pair<std::weak_ptr<RBX::FACSRigCFrameProvider>,unsigned __int64>> **)(a2 + 128),
    _First: *(std::pair<std::weak_ptr<RBX::FACSRigCFrameProvider>,unsigned __int64> **)(a2 + 136),
    _Last: *(std::pair<std::weak_ptr<RBX::FACSRigCFrameProvider>,unsigned __int64> **)(a2 + 48));
  boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<__int64>>>::deallocate( /*0x143162884*/
    this: *(std::allocator<RBX::Graphics::FramebufferVulkan::FramebufferInfo> **)(a2 + 128),
    _Ptr: *(RBX::Graphics::Framebuffer **)(a2 + 56),
    _Count: *(_QWORD *)(a2 + 32));
  throw; /*0x14316288d*/
}

// Address: 0x1431629b0 | Name: _RBX::Network::PhysicsTouchSerializer::PhysicsTouchSerializer_::_1_::dtor$2
void __fastcall RBX::Network::PhysicsTouchSerializer::PhysicsTouchSerializer_::_1_::dtor_2(__int64 a1, __int64 a2)
{
  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)(*(_QWORD *)(a2 + 112) /*0x1431629bb*/
                                                                                                + 88LL));
}

// Address: 0x143175e50 | Name: _RBX::Network::StreamingSolver::addMovingNetworkOwnershipUnit_::_1_::dtor$10
void __fastcall RBX::Network::StreamingSolver::addMovingNetworkOwnershipUnit_::_1_::dtor_10(__int64 a1, __int64 a2)
{
  std::_Alloc_construct_ptr<std::allocator<std::_List_node<std::pair<RBX::Primitive * const,RBX::StreamRegion::IdExtents>,void *>>>::~_Alloc_construct_ptr<std::allocator<std::_List_node<std::pair<RBX::Primitive * const,RBX::StreamRegion::IdExtents>,void *>>>(this: (std::_Alloc_construct_ptr<std::allocator<std::_List_node<std::pair<__int64 const ,std::vector<RBX::Permission> >,void *> > > *)(a2 + 136)); /*0x143175e57*/
}

// Address: 0x14317cfb0 | Name: _RBX::Network::NetworkSchema::NetworkSchema_::_1_::dtor$2
void __fastcall RBX::Network::NetworkSchema::NetworkSchema_::_1_::dtor_2(__int64 a1, __int64 a2)
{
  std::vector<Luau::Location>::~vector<Luau::Location>(this: (RBX::DenseHashMap<RBX::Graphics::ShaderProgram *,VkPipeline_T *,boost::hash<RBX::Graphics::ShaderProgram *>,std::equal_to<RBX::Graphics::ShaderProgram *> > *)(*(_QWORD *)(a2 + 80) + 104LL)); /*0x14317cfbb*/
}

// Address: 0x14317d750 | Name: _RBX::Network::MegaReplicator::onCombinedSignalChildRemoved_::_1_::dtor$53
void __fastcall RBX::Network::MegaReplicator::onCombinedSignalChildRemoved_::_1_::dtor_53(__int64 a1, __int64 a2)
{
  std::function<void (__int64)>::~function<void (__int64)>(this: (std::function<void __cdecl(std::string,std::unordered_map<__int64,std::vector<RBX::Permission>>)> *)(a2 + 880)); /*0x14317d757*/
}

// Address: 0x14317eab0 | Name: _RBX::ServiceProvider::doGetClassIndex_RBX::Network::Client__::_1_::dtor$0
void RBX::ServiceProvider::doGetClassIndex_RBX::Network::Client__::_1_::dtor_0()
{
  Init_thread_abort(pOnce: &__TSS0__1____doGetClassIndex_VClient_Network_RBX___ServiceProvider_RBX__CA_KXZ_4HA); /*0x14317eab7*/
}

// Address: 0x14317f9b0 | Name: _RBX::Network::DeserializedNewInstanceItem::process_::_1_::dtor$19
void __fastcall RBX::Network::DeserializedNewInstanceItem::process_::_1_::dtor_19(
        __int64 a1,
        RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> *a2)
{
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: a2 + 188); /*0x14317f9b7*/
}

// Address: 0x143181510 | Name: _RBX::Network::ClientReplicator::OnReceive_::_1_::dtor$17
void __fastcall RBX::Network::ClientReplicator::OnReceive_::_1_::dtor_17(__int64 a1, __int64 a2)
{
  std::unordered_map<RBX::Soundscape::SoundId,std::string>::~unordered_map<RBX::Soundscape::SoundId,std::string>(t: (void *)(a2 + 352)); /*0x143181517*/
}

// Address: 0x143184730 | Name: _RBX::Network::ClientReplicator::GCJob::setServerStreamingMetadata_::_1_::dtor$0
void __fastcall RBX::Network::ClientReplicator::GCJob::setServerStreamingMetadata_::_1_::dtor_0(__int64 a1, __int64 a2)
{
  std::unordered_map<RBX::Guid,unsigned __int64,RBX::Hash<void>,std::equal_to<RBX::Guid>,std::allocator<std::pair<RBX::Guid const,unsigned __int64>>>::~unordered_map<RBX::Guid,unsigned __int64,RBX::Hash<void>,std::equal_to<RBX::Guid>,std::allocator<std::pair<RBX::Guid const,unsigned __int64>>>(this: (std::unordered_map<SearchResult *,QuickOpenItemWidget *> *)(a2 + 80)); /*0x143184737*/
}

// Address: 0x143184b80 | Name: _RBX::Network::StreamingObserver::onPrimitiveAddedOrRemoved_::_1_::dtor$0
void __fastcall RBX::Network::StreamingObserver::onPrimitiveAddedOrRemoved_::_1_::dtor_0(
        __int64 a1,
        RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> *a2)
{
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: a2 + 55); /*0x143184b87*/
}

// Address: 0x143184c10 | Name: _RBX::Network::StreamingObserver::onPrimitiveMoved_::_1_::dtor$0
void __fastcall RBX::Network::StreamingObserver::onPrimitiveMoved_::_1_::dtor_0(
        __int64 a1,
        RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> *a2)
{
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: a2 + 53); /*0x143184c17*/
}

// Address: 0x143189300 | Name: _RBX::Network::ClientReplicator::updateClientCapacity_::_1_::dtor$1
void __fastcall RBX::Network::ClientReplicator::updateClientCapacity_::_1_::dtor_1(__int64 a1, __int64 a2)
{
  operator delete(ptr: *(void **)(a2 + 304)); /*0x143189315*/
}

// Address: 0x14318a0a0 | Name: _RBX::Network::ClientReplicator::GCJob::updateFixedNetworkOwnershipUnit_deprecated_::_1_::dtor$9
void __fastcall RBX::Network::ClientReplicator::GCJob::updateFixedNetworkOwnershipUnit_deprecated_::_1_::dtor_9(
        __int64 a1,
        __int64 a2)
{
  std::_Alloc_construct_ptr<std::allocator<std::_List_node<std::pair<RBX::Primitive * const,RBX::StreamRegion::IdExtents>,void *>>>::~_Alloc_construct_ptr<std::allocator<std::_List_node<std::pair<RBX::Primitive * const,RBX::StreamRegion::IdExtents>,void *>>>(this: (std::_Alloc_construct_ptr<std::allocator<std::_List_node<std::pair<__int64 const ,std::vector<RBX::Permission> >,void *> > > *)(a2 + 168)); /*0x14318a0a7*/
}

// Address: 0x14318a500 | Name: _RBX::Network::MegaReplicator::addPropertyChangeToCommonQueue_::_1_::dtor$3
void __fastcall RBX::Network::MegaReplicator::addPropertyChangeToCommonQueue_::_1_::dtor_3(__int64 a1, __int64 a2)
{
  operator delete(ptr: *(void **)(a2 + 272)); /*0x14318a515*/
}

// Address: 0x14318c9d0 | Name: _RBX::Network::Client::setArtificialLatencyFromIxp_::_1_::dtor$1
void __fastcall RBX::Network::Client::setArtificialLatencyFromIxp_::_1_::dtor_1(__int64 a1, __int64 a2)
{
  std::weak_ptr<RBX::Soundscape::Sound>::~weak_ptr<RBX::Soundscape::Sound>(this: *(std::weak_ptr<PluginPermissionsFetcher> **)(a2 + 632)); /*0x14318c9d7*/
}

// Address: 0x14318eb20 | Name: _RBX::Network::MegaReplicator::addPropertyChangeToCommonQueue_::_1_::dtor$14
void __fastcall RBX::Network::MegaReplicator::addPropertyChangeToCommonQueue_::_1_::dtor_14(__int64 a1, __int64 a2)
{
  operator delete(ptr: *(void **)(a2 + 80)); /*0x14318eb32*/
}

// Address: 0x1431908b0 | Name: _RBX::Network::MegaReplicator::startServerOnlyMegaJobs_::_1_::dtor$0
void __fastcall RBX::Network::MegaReplicator::startServerOnlyMegaJobs_::_1_::dtor_0(__int64 a1, __int64 a2)
{
  operator delete(ptr: *(void **)(a2 + 208)); /*0x1431908c5*/
}

// Address: 0x143192900 | Name: _RBX::Network::RomarkPhaseTrackingJob::RomarkPhaseTrackingJob_::_1_::dtor$15
void __fastcall RBX::Network::RomarkPhaseTrackingJob::RomarkPhaseTrackingJob_::_1_::dtor_15(__int64 a1, __int64 a2)
{
  boost::algorithm::detail::is_any_ofF<char>::~is_any_ofF<char>(this: *(boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > **)(a2 + 176)); /*0x143192907*/
}

// Address: 0x143196e00 | Name: _RBX::Network::Replicator::registerInstanceForDescendantTracking_::_1_::dtor$4
__int64 __fastcall RBX::Network::Replicator::registerInstanceForDescendantTracking_::_1_::dtor_4(
        __int64 a1,
        __int64 a2)
{
  return lambda_e78d932d53c4c8f77e813d3705d110d4_::__lambda_e78d932d53c4c8f77e813d3705d110d4_(a1: a2 + 120);
}

// Address: 0x14319a220 | Name: _RBX::Network::Replicator::reportJoinTimeFrameStats_::_1_::dtor$3
void __fastcall RBX::Network::Replicator::reportJoinTimeFrameStats_::_1_::dtor_3(__int64 a1, __int64 a2)
{
  RBX::Analytics::InfluxDb::Points::~Points(this: (RBX::Analytics::InfluxDb::Points *)(a2 + 320)); /*0x14319a227*/
}

// Address: 0x14319d080 | Name: _RBX::Network::StreamingSolver::computeSetExtents_::_1_::dtor$3
void __fastcall RBX::Network::StreamingSolver::computeSetExtents_::_1_::dtor_3(
        __int64 a1,
        std::_Hash<std::_Uset_traits<ISandboxLocalCache::ScriptLocalCacheData *,std::_Uhash_compare<ISandboxLocalCache::ScriptLocalCacheData *,std::hash<ISandboxLocalCache::ScriptLocalCacheData *>,std::equal_to<ISandboxLocalCache::ScriptLocalCacheData *> >,std::allocator<ISandboxLocalCache::ScriptLocalCacheData *>,0> > *a2)
{
  std::_Hash<std::_Uset_traits<enum RBX::Security::Permissions,std::_Uhash_compare<enum RBX::Security::Permissions,std::hash<enum RBX::Security::Permissions>,std::equal_to<enum RBX::Security::Permissions>>,std::allocator<enum RBX::Security::Permissions>,0>>::~_Hash<std::_Uset_traits<enum RBX::Security::Permissions,std::_Uhash_compare<enum RBX::Security::Permissions,std::hash<enum RBX::Security::Permissions>,std::equal_to<enum RBX::Security::Permissions>>,std::allocator<enum RBX::Security::Permissions>,0>>(this: a2 + 3); /*0x14319d087*/
}

// Address: 0x14319edd0 | Name: _RBX::Network::ClientReplicator::GCJob::updateAncestorForRemovedDescendant_deprecated_::_1_::dtor$0
void __fastcall RBX::Network::ClientReplicator::GCJob::updateAncestorForRemovedDescendant_deprecated_::_1_::dtor_0(
        __int64 a1,
        std::unordered_map<SearchResult *,QuickOpenItemWidget *> *a2)
{
  std::unordered_map<RBX::Guid,unsigned __int64,RBX::Hash<void>,std::equal_to<RBX::Guid>,std::allocator<std::pair<RBX::Guid const,unsigned __int64>>>::~unordered_map<RBX::Guid,unsigned __int64,RBX::Hash<void>,std::equal_to<RBX::Guid>,std::allocator<std::pair<RBX::Guid const,unsigned __int64>>>(this: a2 + 1); /*0x14319edd7*/
}

// Address: 0x14319ee10 | Name: _RBX::Network::Replicator::StreamJob::checkAndSendServerStreamingMetaInfo_::_1_::dtor$5
void __fastcall RBX::Network::Replicator::StreamJob::checkAndSendServerStreamingMetaInfo_::_1_::dtor_5(
        __int64 a1,
        __int64 a2)
{
  std::list<std::pair<RBX::StreamRegion::Id const,bool>>::~list<std::pair<RBX::StreamRegion::Id const,bool>>(this: (std::list<std::pair<SearchResult * const,QuickOpenItemWidget *>> *)(a2 + 72)); /*0x14319ee1b*/
}

// Address: 0x1431a1270 | Name: _RBX::Network::Replicator::onServiceProvider_::_1_::dtor$150
void __fastcall RBX::Network::Replicator::onServiceProvider_::_1_::dtor_150(__int64 a1, __int64 a2)
{
  std::function<void (__int64)>::~function<void (__int64)>(this: *(std::function<void __cdecl(std::string,std::unordered_map<__int64,std::vector<RBX::Permission>>)> **)(a2 + 1712)); /*0x1431a1277*/
}

// Address: 0x1431a1810 | Name: _RBX::Network::ClientReplicator::readStats_::_1_::dtor$30
void __fastcall RBX::Network::ClientReplicator::readStats_::_1_::dtor_30(
        __int64 a1,
        std::pair<RBX::Instance * const,std::shared_ptr<SearchResult> > *a2)
{
  RBX::CageHSRFetchRequest::CageHSRAsset::~CageHSRAsset(this: a2 + 9); /*0x1431a1817*/
}

// Address: 0x1431a51c0 | Name: _RBX::Network::NetworkSenderScheduleJob::stepDataModelJob_::_1_::dtor$57
void __fastcall RBX::Network::NetworkSenderScheduleJob::stepDataModelJob_::_1_::dtor_57(
        __int64 a1,
        RBX::DataModel::scoped_write_request *a2)
{
  RBX::DataModel::scoped_write_request::~scoped_write_request(this: a2 + 16); /*0x1431a51c7*/
}

// Address: 0x1431a5a00 | Name: _RBX::Creatable_RBX::Instance_::create_RBX::Network::Server__::_1_::dtor$1
void __fastcall RBX::Creatable_RBX::Instance_::create_RBX::Network::Server__::_1_::dtor_1(__int64 a1, __int64 a2)
{
  operator delete(ptr: *(void **)(a2 + 96)); /*0x1431a5a12*/
}

// Address: 0x1431a5a30 | Name: _RBX::ServiceProvider::doGetClassIndex_RBX::Network::Server__::_1_::dtor$0
void RBX::ServiceProvider::doGetClassIndex_RBX::Network::Server__::_1_::dtor_0()
{
  Init_thread_abort(pOnce: &__TSS0__1____doGetClassIndex_VServer_Network_RBX___ServiceProvider_RBX__CA_KXZ_4HA); /*0x1431a5a37*/
}

// Address: 0x1431a5c00 | Name: _RBX::Creatable_RBX::Instance_::create_RBX::Network::Client__::_1_::dtor$1
void __fastcall RBX::Creatable_RBX::Instance_::create_RBX::Network::Client__::_1_::dtor_1(__int64 a1, __int64 a2)
{
  operator delete(ptr: *(void **)(a2 + 96)); /*0x1431a5c12*/
}

// Address: 0x1431bd9a0 | Name: _RBX::Network::Replicator::processWorkingPacket_::_1_::dtor$0
void __fastcall RBX::Network::Replicator::processWorkingPacket_::_1_::dtor_0(
        __int64 a1,
        RBX::Security::Impersonator *a2)
{
  RBX::Security::Impersonator::~Impersonator(this: a2 + 6); /*0x1431bd9a7*/
}

// Address: 0x1431befc0 | Name: _RBX::Network::ClientReplicator::readStats_::_1_::dtor$32
void __fastcall RBX::Network::ClientReplicator::readStats_::_1_::dtor_32(
        __int64 a1,
        std::pair<RBX::Instance * const,std::shared_ptr<SearchResult> > *a2)
{
  RBX::CageHSRFetchRequest::CageHSRAsset::~CageHSRAsset(this: a2 + 8); /*0x1431befc7*/
}

// Address: 0x1431c12a0 | Name: _RBX::Network::StreamingObserver::StreamingObserver_::_1_::dtor$26
void __fastcall RBX::Network::StreamingObserver::StreamingObserver_::_1_::dtor_26(__int64 a1, __int64 a2)
{
  std::list<std::pair<std::pair<RBX::Vector3,unsigned int> const,RBX::Vector3>>::~list<std::pair<std::pair<RBX::Vector3,unsigned int> const,RBX::Vector3>>(this: (std::list<std::pair<unsigned __int64 const ,RBX::Collision::BulletCollisionBoxSetPool::BoxSetStorage>> *)(*(_QWORD *)(a2 + 88) + 8LL)); /*0x1431c12ab*/
}

// Address: 0x1431c2720 | Name: _RBX::Network::Replicator::StreamJob::evaluateLodChangeForStreaming_::_1_::dtor$1
void __fastcall RBX::Network::Replicator::StreamJob::evaluateLodChangeForStreaming_::_1_::dtor_1(
        __int64 a1,
        __int64 a2)
{
  std::vector<dtl::Point>::~vector<dtl::Point>(this: (RBX::DenseHashMap<RBX::Graphics::SamplerState,VkSampler_T *,RBX::Graphics::StateHasher<RBX::Graphics::SamplerState>,std::equal_to<RBX::Graphics::SamplerState> > *)(a2 + 128)); /*0x1431c2727*/
}

// Address: 0x1431c5a00 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$104
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_104(__int64 a1, __int64 a2)
{
  std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>::~_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>(this: (std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<__int64 const ,std::vector<RBX::Permission> > > > > > > *)(*(_QWORD *)(a2 + 448) + 24LL)); /*0x1431c5a0b*/
}

// Address: 0x1431c7560 | Name: _RBX::Network::Sync::Base_RBX::Network::Sync::MasterItem_RBX::Network::Sync::AttributeKey_::expireItems_::_1_::dtor$0
void __fastcall RBX::Network::Sync::Base_RBX::Network::Sync::MasterItem_RBX::Network::Sync::AttributeKey_::expireItems_::_1_::dtor_0(
        __int64 a1,
        boost::detail::spinlock::scoped_lock *a2)
{
  rbx::spin_mutex::scoped_lock::~scoped_lock(this: a2 + 18); /*0x1431c7567*/
}

// Address: 0x1431cd200 | Name: _RBX::Network::StrictNetworkFilter::ResolvedWeldAttachmentInfo::ResolvedWeldAttachmentInfo_::_1_::dtor$5
void __fastcall RBX::Network::StrictNetworkFilter::ResolvedWeldAttachmentInfo::ResolvedWeldAttachmentInfo_::_1_::dtor_5(
        __int64 a1,
        __int64 a2)
{
  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)(*(_QWORD *)(a2 + 80) /*0x1431cd20b*/
                                                                                                + 72LL));
}

// Address: 0x1431cd360 | Name: _RBX::Network::NetworkSchema::NetworkSchema_::_1_::dtor$7
void __fastcall RBX::Network::NetworkSchema::NetworkSchema_::_1_::dtor_7(__int64 a1, __int64 a2)
{
  RBX::ScriptServices::Documentation::ValidateResult::~ValidateResult(this: (std::vector<RBX::MeshId> *)(*(_QWORD *)(a2 + 80) + 256LL)); /*0x1431cd36e*/
}

// Address: 0x1431cd5c0 | Name: _RBX::Network::Replicator::onServiceProvider_::_1_::dtor$24
void __fastcall RBX::Network::Replicator::onServiceProvider_::_1_::dtor_24(__int64 a1, __int64 a2)
{
  RBX::Analytics::InfluxDb::Points::~Points(this: (RBX::Analytics::InfluxDb::Points *)(a2 + 944)); /*0x1431cd5c7*/
}

// Address: 0x1431cfcc0 | Name: _RBX::Network::Replicator::handlePropertyChanged_::_1_::dtor$1
void __fastcall RBX::Network::Replicator::handlePropertyChanged_::_1_::dtor_1(__int64 a1, __int64 a2)
{
  if ( (*(_DWORD *)(a2 + 64) & 1) != 0 ) /*0x1431cfcd1*/
  {
    *(_DWORD *)(a2 + 64) &= ~1u; /*0x1431cfcd3*/
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)(a2 + 104)); /*0x1431cfcdb*/
  }
}

// Address: 0x1431cfcf0 | Name: _RBX::Network::Replicator::handlePropertyChanged_::_1_::dtor$6
void __fastcall RBX::Network::Replicator::handlePropertyChanged_::_1_::dtor_6(__int64 a1, __int64 a2)
{
  if ( (*(_DWORD *)(a2 + 64) & 2) != 0 ) /*0x1431cfd01*/
  {
    *(_DWORD *)(a2 + 64) &= ~2u; /*0x1431cfd03*/
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)(a2 + 160)); /*0x1431cfd0e*/
  }
}

// Address: 0x1431d25a0 | Name: _RBX::Network::NetworkSchema::NetworkSchema_::_1_::dtor$3
void __fastcall RBX::Network::NetworkSchema::NetworkSchema_::_1_::dtor_3(__int64 a1, __int64 a2)
{
  std::vector<Luau::AstExpr *>::~vector<Luau::AstExpr *>(this: (std::vector<RBX::Graphics::FramebufferVulkan *> *)(*(_QWORD *)(a2 + 80) + 152LL)); /*0x1431d25ae*/
}

// Address: 0x1431d2720 | Name: _RBX::Network::Replicator::schemaWriteValue_RBX::Network::VariantValueGetter__::_1_::dtor$11
void __fastcall RBX::Network::Replicator::schemaWriteValue_RBX::Network::VariantValueGetter__::_1_::dtor_11(
        __int64 a1,
        RBX::SharedString *a2)
{
  RBX::SharedString::~SharedString(this: a2 + 4); /*0x1431d2727*/
}

// Address: 0x1431d8400 | Name: _RBX::Network::ClientReplicator::GCJob::GCJob_::_1_::dtor$66
void __fastcall RBX::Network::ClientReplicator::GCJob::GCJob_::_1_::dtor_66(__int64 a1, __int64 a2)
{
  if ( (*(_DWORD *)(a2 + 240) & 2) != 0 ) /*0x1431d8414*/
  {
    *(_DWORD *)(a2 + 240) &= ~2u; /*0x1431d8416*/
    rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)(a2 + 48)); /*0x1431d8421*/
  }
}

// Address: 0x1431d8610 | Name: _RBX::Network::Server::onServiceProvider_::_1_::dtor$45
void __fastcall RBX::Network::Server::onServiceProvider_::_1_::dtor_45(
        __int64 a1,
        std::_Temporary_owner<RBX::Graphics::TextureVulkan::DownloadBuffer> *a2)
{
  RBX::BulletWedgeShapeWrapper::~BulletWedgeShapeWrapper(this: a2 + 61); /*0x1431d8617*/
}

// Address: 0x1431d8d30 | Name: _RBX::Network::Replicator::StreamJob::collectPartsFromNextRegion_::_1_::dtor$0
void __fastcall RBX::Network::Replicator::StreamJob::collectPartsFromNextRegion_::_1_::dtor_0(__int64 a1, __int64 a2)
{
  std::vector<Luau::AstExpr *>::~vector<Luau::AstExpr *>(this: (std::vector<RBX::Graphics::FramebufferVulkan *> *)(a2 + 352)); /*0x1431d8d37*/
}

// Address: 0x1431da380 | Name: _RBX::Network::ClientReplicator::prepareJoinRxDataStats_::_1_::dtor$51
void __fastcall RBX::Network::ClientReplicator::prepareJoinRxDataStats_::_1_::dtor_51(__int64 a1, __int64 a2)
{
  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)(a2 + 2984)); /*0x1431da387*/
}

// Address: 0x1431dbe30 | Name: _RBX::Network::StreamedInRegions::StreamedInRegions_::_1_::dtor$1
void __fastcall RBX::Network::StreamedInRegions::StreamedInRegions_::_1_::dtor_1(__int64 a1, __int64 a2)
{
  std::set<webrtc::RTCPSender::ReportFlag>::~set<webrtc::RTCPSender::ReportFlag>(this: (std::set<TSJobItem *> *)(*(_QWORD *)(a2 + 48) + 16LL)); /*0x1431dbe3b*/
}

// Address: 0x1431dc400 | Name: _RBX::Network::ClientReplicator::streamOutPartJointInstanceHelper_::_1_::dtor$0
void __fastcall RBX::Network::ClientReplicator::streamOutPartJointInstanceHelper_::_1_::dtor_0(
        __int64 a1,
        RBX::ScopedAssign<unsigned __int64> *a2)
{
  RBX::ScopedAssign<unsigned __int64>::~ScopedAssign<unsigned __int64>(this: a2 + 2); /*0x1431dc407*/
}

// Address: 0x1431deac0 | Name: _RBX::Network::Replicator::StreamJob::StreamJob_::_1_::dtor$49
void __fastcall RBX::Network::Replicator::StreamJob::StreamJob_::_1_::dtor_49(__int64 a1, __int64 a2)
{
  std::list<std::pair<int const,RBX::Scripting::RemoteDebuggerServer::FrameReference>>::~list<std::pair<int const,RBX::Scripting::RemoteDebuggerServer::FrameReference>>(this: (std::list<webrtc::Probe> *)(*(_QWORD *)(a2 + 136) + 8LL)); /*0x1431deacb*/
}

// Address: 0x1431e4520 | Name: _RBX::Network::Replicator::ChangePropertyItem::read_::_1_::dtor$9
void __fastcall RBX::Network::Replicator::ChangePropertyItem::read_::_1_::dtor_9(
        __int64 a1,
        std::_Temporary_owner<RBX::Graphics::TextureVulkan::DownloadBuffer> *a2)
{
  RBX::BulletWedgeShapeWrapper::~BulletWedgeShapeWrapper(this: a2 + 47); /*0x1431e4527*/
}

// Address: 0x1431e51c0 | Name: _std::vector_RBX::Network::Client::ServerConnection_std::allocator_RBX::Network::Client::ServerConnection___::_Emplace_reallocate_RBX::Network::Client::ServerConnection__::_1_::catch$7
void __fastcall __noreturn std::vector_RBX::Network::Client::ServerConnection_std::allocator_RBX::Network::Client::ServerConnection___::_Emplace_reallocate_RBX::Network::Client::ServerConnection__::_1_::catch_7(
        __int64 a1,
        __int64 a2)
{
  std::vector<RBX::Network::Client::ServerConnection>::_Destroy( /*0x1431e51e0*/
    this: *(std::vector<RBX::Network::Client::ServerConnection> **)(a2 + 128),
    _First: *(RBX::Network::Client::ServerConnection **)(a2 + 152),
    _Last: *(RBX::Network::Client::ServerConnection **)(a2 + 40));
  std::allocator<RBX::MechanismInterpolationParallelTask::NetworkPlatformPrimitiveCache>::deallocate( /*0x1431e51f4*/
    this: *(std::allocator<ncnn::Blob> **)(a2 + 128),
    _Ptr: *(ncnn::Blob *const *)(a2 + 48),
    _Count: *(_QWORD *)(a2 + 32));
  throw; /*0x1431e51fd*/
}

// Address: 0x1431e5210 | Name: _std::vector_RBX::Network::Client::ServerConnection_std::allocator_RBX::Network::Client::ServerConnection___::_Insert_range_std::reverse_iterator_RBX::Network::Client::ServerConnection_const______::_1_::catch$0
void __fastcall __noreturn std::vector_RBX::Network::Client::ServerConnection_std::allocator_RBX::Network::Client::ServerConnection___::_Insert_range_std::reverse_iterator_RBX::Network::Client::ServerConnection_const______::_1_::catch_0(
        __int64 a1,
        __int64 a2)
{
  std::allocator<ncnn::Blob> *v3; // rax

  std::vector<RBX::Network::Client::ServerConnection>::_Destroy( /*0x1431e5233*/
    this: *(std::vector<RBX::Network::Client::ServerConnection> **)(a2 + 160),
    _First: *(RBX::Network::Client::ServerConnection **)(a2 + 168),
    _Last: *(RBX::Network::Client::ServerConnection **)(a2 + 176));
  v3 = (std::allocator<ncnn::Blob> *)std::_Tree<std::_Tset_traits<std::weak_ptr<RBX::FileSyncItem>,std::less<std::weak_ptr<RBX::FileSyncItem>>,std::allocator<std::weak_ptr<RBX::FileSyncItem>>,0>>::_Getal(this: *(std::vector<VkVertexInputBindingDescription> **)(a2 + 160)); /*0x1431e523f*/
  std::allocator<RBX::MechanismInterpolationParallelTask::NetworkPlatformPrimitiveCache>::deallocate( /*0x1431e5252*/
    this: v3,
    _Ptr: *(ncnn::Blob *const *)(a2 + 184),
    _Count: *(_QWORD *)(a2 + 32));
  throw; /*0x1431e525b*/
}

// Address: 0x1431e5270 | Name: _std::vector_RBX::Network::Client::ServerConnection_std::allocator_RBX::Network::Client::ServerConnection___::_Insert_range_std::reverse_iterator_RBX::Network::Client::ServerConnection_const______::_1_::catch$1
void __fastcall __noreturn std::vector_RBX::Network::Client::ServerConnection_std::allocator_RBX::Network::Client::ServerConnection___::_Insert_range_std::reverse_iterator_RBX::Network::Client::ServerConnection_const______::_1_::catch_1(
        __int64 a1,
        __int64 a2)
{
  RBX::Network::Client::ServerConnection *v2; // rbx
  RBX::Network::Client::ServerConnection **v3; // rdi

  v2 = *(RBX::Network::Client::ServerConnection **)(a2 + 168); /*0x1431e528b*/
  v3 = *(RBX::Network::Client::ServerConnection ***)(a2 + 32); /*0x1431e5295*/
  std::vector<RBX::Network::Client::ServerConnection>::_Destroy( /*0x1431e52a3*/
    this: *(std::vector<RBX::Network::Client::ServerConnection> **)(a2 + 160),
    _First: &v2[*(_QWORD *)(a2 + 48)],
    _Last: *v3);
  *v3 = v2; /*0x1431e52a8*/
  throw; /*0x1431e52af*/
}

// Address: 0x1431e52c0 | Name: _std::vector_RBX::Network::Client::ServerConnection_std::allocator_RBX::Network::Client::ServerConnection___::_Insert_range_std::reverse_iterator_RBX::Network::Client::ServerConnection_const______::_1_::catch$2
void __fastcall __noreturn std::vector_RBX::Network::Client::ServerConnection_std::allocator_RBX::Network::Client::ServerConnection___::_Insert_range_std::reverse_iterator_RBX::Network::Client::ServerConnection_const______::_1_::catch_2(
        __int64 a1,
        _QWORD *a2)
{
  __int64 v3; // rcx
  RBX::Network::Client::ServerConnection *v4; // r9
  RBX::Network::Client::ServerConnection *v5; // rbx
  RBX::Network::Client::ServerConnection *v6; // rdi
  std::vector<RBX::Network::Client::ServerConnection> *v7; // rsi
  RBX::Network::Client::ServerConnection *v8; // r8
  RBX::Network::Client::ServerConnection **v9; // rdi
  RBX::Network::Client::ServerConnection *v10; // rbx

  v3 = a2[6]; /*0x1431e52d0*/
  v4 = (RBX::Network::Client::ServerConnection *)a2[21]; /*0x1431e52dc*/
  v5 = &v4[2 * v3]; /*0x1431e52e3*/
  v6 = &v4[v3]; /*0x1431e52ee*/
  v7 = (std::vector<RBX::Network::Client::ServerConnection> *)a2[20]; /*0x1431e52f7*/
  std::vector<RBX::Network::Client::ServerConnection>::_Umove(this: v7, _First: v6, _Last: v5, _Dest: v4); /*0x1431e5301*/
  v8 = v6; /*0x1431e5307*/
  v9 = (RBX::Network::Client::ServerConnection **)a2[4]; /*0x1431e530a*/
  std::_Move_unchecked<RBX::Network::Client::ServerConnection *,RBX::Network::Client::ServerConnection *>( /*0x1431e5314*/
    _First: v5,
    _Last: *v9,
    _Dest: v8);
  v10 = (RBX::Network::Client::ServerConnection *)a2[7]; /*0x1431e531c*/
  std::vector<RBX::Network::Client::ServerConnection>::_Destroy(this: v7, _First: v10, _Last: *v9); /*0x1431e5326*/
  *v9 = v10; /*0x1431e532b*/
  throw; /*0x1431e5332*/
}

// Address: 0x1431e5340 | Name: _std::vector_RBX::Network::Client::ServerConnection_std::allocator_RBX::Network::Client::ServerConnection___::_Insert_range_std::reverse_iterator_RBX::Network::Client::ServerConnection_const______::_1_::catch$3
void __fastcall __noreturn std::vector_RBX::Network::Client::ServerConnection_std::allocator_RBX::Network::Client::ServerConnection___::_Insert_range_std::reverse_iterator_RBX::Network::Client::ServerConnection_const______::_1_::catch_3(
        __int64 a1,
        __int64 a2)
{
  RBX::Network::Client::ServerConnection **v3; // rbx

  v3 = *(RBX::Network::Client::ServerConnection ***)(a2 + 32); /*0x1431e534e*/
  std::vector<RBX::Network::Client::ServerConnection>::_Destroy( /*0x1431e5363*/
    this: *(std::vector<RBX::Network::Client::ServerConnection> **)(a2 + 160),
    _First: *(RBX::Network::Client::ServerConnection **)(a2 + 184),
    _Last: *v3);
  *v3 = *(RBX::Network::Client::ServerConnection **)(a2 + 168); /*0x1431e536f*/
  throw; /*0x1431e5376*/
}

// Address: 0x1431e5380 | Name: _std::vector_RBX::Network::Client::ServerConnection_std::allocator_RBX::Network::Client::ServerConnection___::_Insert_range_std::reverse_iterator_RBX::Network::Client::ServerConnection_const______::_1_::catch$4
void __fastcall __noreturn std::vector_RBX::Network::Client::ServerConnection_std::allocator_RBX::Network::Client::ServerConnection___::_Insert_range_std::reverse_iterator_RBX::Network::Client::ServerConnection_const______::_1_::catch_4(
        __int64 a1,
        __int64 a2)
{
  RBX::Network::Client::ServerConnection **v3; // rbx
  RBX::Network::Client::ServerConnection *v4; // rdi
  std::vector<RBX::Network::Client::ServerConnection> *v5; // rsi

  v3 = *(RBX::Network::Client::ServerConnection ***)(a2 + 32); /*0x1431e5397*/
  v4 = *(RBX::Network::Client::ServerConnection **)(a2 + 184); /*0x1431e539e*/
  v5 = *(std::vector<RBX::Network::Client::ServerConnection> **)(a2 + 160); /*0x1431e53a8*/
  std::vector<RBX::Network::Client::ServerConnection>::_Umove( /*0x1431e53b2*/
    this: v5,
    _First: v4,
    _Last: *v3,
    _Dest: *(RBX::Network::Client::ServerConnection **)(a2 + 168));
  std::vector<RBX::Network::Client::ServerConnection>::_Destroy(this: v5, _First: v4, _Last: *v3); /*0x1431e53c1*/
  *v3 = *(RBX::Network::Client::ServerConnection **)(a2 + 56); /*0x1431e53ca*/
  throw; /*0x1431e53d1*/
}

// Address: 0x1431e5410 | Name: _std::vector_RBX::Network::Client::ServerConnection_std::allocator_RBX::Network::Client::ServerConnection___::_Ucopy_std::reverse_iterator_RBX::Network::Client::ServerConnection_const______::_1_::dtor$0
void __fastcall std::vector_RBX::Network::Client::ServerConnection_std::allocator_RBX::Network::Client::ServerConnection___::_Ucopy_std::reverse_iterator_RBX::Network::Client::ServerConnection_const______::_1_::dtor_0(
        __int64 a1,
        __int64 a2)
{
  std::_Uninitialized_backout_al<std::allocator<RBX::Network::Client::ServerConnection>>::~_Uninitialized_backout_al<std::allocator<RBX::Network::Client::ServerConnection>>(this: (std::_Uninitialized_backout_al<std::allocator<RBX::Network::Client::ServerConnection> > *)(a2 + 32)); /*0x1431e5417*/
}

// Address: 0x1431e5420 | Name: _RBX::Creatable_RBX::Instance_::create_RBX::Network::ClientReplicator_RBX::Network::Replicator::ReplicatorPeerInfo_&_RBX::NetworkSettings___&_RBX::Network::MegaReplicator____::_1_::dtor$1
void __fastcall RBX::Creatable_RBX::Instance_::create_RBX::Network::ClientReplicator_RBX::Network::Replicator::ReplicatorPeerInfo___RBX::NetworkSettings_____RBX::Network::MegaReplicator____::_1_::dtor_1(
        __int64 a1,
        __int64 a2)
{
  operator delete(ptr: *(void **)(a2 + 176)); /*0x1431e5435*/
}

// Address: 0x1431e5440 | Name: _RBX::Network::Client::Client_::_1_::dtor$0
void __fastcall RBX::Network::Client::Client_::_1_::dtor_0(__int64 a1, __int64 a2)
{
  RBX::DescribedCreatable<RBX::Network::Client,RBX::Network::Peer>::~DescribedCreatable<RBX::Network::Client,RBX::Network::Peer>(this: *(RBX::DescribedCreatable<RBX::Network::Client,RBX::Network::Peer> **)(a2 + 128)); /*0x1431e5447*/
}

// Address: 0x1431e5450 | Name: _RBX::Network::Client::Client_::_1_::dtor$1
void __fastcall RBX::Network::Client::Client_::_1_::dtor_1(__int64 a1, __int64 a2)
{
  rbx::signals::scoped_connection::~scoped_connection(this: (rbx::signals::scoped_connection *)(*(_QWORD *)(a2 + 128) /*0x1431e545e*/
                                                                                              + 432LL));
}

// Address: 0x1431e5470 | Name: _RBX::Network::Client::Client_::_1_::dtor$2
void __fastcall RBX::Network::Client::Client_::_1_::dtor_2(__int64 a1, __int64 a2)
{
  rbx::signals::scoped_connection::~scoped_connection(this: (rbx::signals::scoped_connection *)(*(_QWORD *)(a2 + 128) /*0x1431e547e*/
                                                                                              + 440LL));
}

// Address: 0x1431e5490 | Name: _RBX::Network::Client::Client_::_1_::dtor$3
void __fastcall RBX::Network::Client::Client_::_1_::dtor_3(__int64 a1, __int64 a2)
{
  rbx::signals::scoped_connection::~scoped_connection(this: (rbx::signals::scoped_connection *)(*(_QWORD *)(a2 + 128) /*0x1431e549e*/
                                                                                              + 448LL));
}

// Address: 0x1431e54b0 | Name: _RBX::Network::Client::Client_::_1_::dtor$4
void __fastcall RBX::Network::Client::Client_::_1_::dtor_4(__int64 a1, __int64 a2)
{
  rbx::signals::scoped_connection::~scoped_connection(this: (rbx::signals::scoped_connection *)(*(_QWORD *)(a2 + 128) /*0x1431e54be*/
                                                                                              + 456LL));
}

// Address: 0x1431e54d0 | Name: _RBX::Network::Client::Client_::_1_::dtor$5
void __fastcall RBX::Network::Client::Client_::_1_::dtor_5(__int64 a1, __int64 a2)
{
  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)(*(_QWORD *)(a2 + 128) + 504LL)); /*0x1431e54de*/
}

// Address: 0x1431e54f0 | Name: _RBX::Network::Client::Client_::_1_::dtor$6
void __fastcall RBX::Network::Client::Client_::_1_::dtor_6(__int64 a1, __int64 a2)
{
  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)(*(_QWORD *)(a2 + 128) + 536LL)); /*0x1431e54fe*/
}

// Address: 0x1431e5530 | Name: _RBX::Network::Client::Client_::_1_::dtor$8
void __fastcall RBX::Network::Client::Client_::_1_::dtor_8(__int64 a1, __int64 a2)
{
  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)(*(_QWORD *)(a2 + 128) + 632LL)); /*0x1431e553e*/
}

// Address: 0x1431e5550 | Name: _RBX::Network::Client::Client_::_1_::dtor$9
void __fastcall RBX::Network::Client::Client_::_1_::dtor_9(__int64 a1, __int64 a2)
{
  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)(*(_QWORD *)(a2 + 128) + 672LL)); /*0x1431e555e*/
}

// Address: 0x1431e5570 | Name: _RBX::Network::Client::Client_::_1_::dtor$10
void __fastcall RBX::Network::Client::Client_::_1_::dtor_10(__int64 a1, __int64 a2)
{
  RBX::Network::MegaReplicator::~MegaReplicator(this: (RBX::Network::MegaReplicator *)(*(_QWORD *)(a2 + 128) + 704LL)); /*0x1431e557e*/
}

// Address: 0x1431e5590 | Name: _RBX::Network::Client::Client_::_1_::dtor$11
void __fastcall RBX::Network::Client::Client_::_1_::dtor_11(__int64 a1, __int64 a2)
{
  std::recursive_mutex::~recursive_mutex(this: (RBX::InstrumentedMutex<std::mutex> *)(*(_QWORD *)(a2 + 128) + 2904LL)); /*0x1431e559e*/
}

// Address: 0x1431e55b0 | Name: _RBX::Network::Client::Client_::_1_::dtor$12
void __fastcall RBX::Network::Client::Client_::_1_::dtor_12(__int64 a1, __int64 a2)
{
  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)(*(_QWORD *)(a2 + 128) + 2984LL)); /*0x1431e55be*/
}

// Address: 0x1431e55d0 | Name: _RBX::Network::Client::Client_::_1_::dtor$13
void __fastcall RBX::Network::Client::Client_::_1_::dtor_13(__int64 a1, __int64 a2)
{
  rbx::signal<void (std::string,std::string,std::string,std::string)>::~signal<void (std::string,std::string,std::string,std::string)>(this: (rbx::signal<void __cdecl(PluginReference)> *)(*(_QWORD *)(a2 + 128) + 3016LL)); /*0x1431e55de*/
}

// Address: 0x1431e55f0 | Name: _RBX::Network::Client::Client_::_1_::dtor$14
void __fastcall RBX::Network::Client::Client_::_1_::dtor_14(__int64 a1, __int64 a2)
{
  rbx::signal<void (std::string,std::string,std::string,std::string)>::~signal<void (std::string,std::string,std::string,std::string)>(this: (rbx::signal<void __cdecl(PluginReference)> *)(*(_QWORD *)(a2 + 128) + 3040LL)); /*0x1431e55fe*/
}

// Address: 0x1431e5610 | Name: _RBX::Network::Client::Client_::_1_::dtor$15
void __fastcall RBX::Network::Client::Client_::_1_::dtor_15(__int64 a1, __int64 a2)
{
  rbx::signal<void (std::string,std::string,std::string,std::string)>::~signal<void (std::string,std::string,std::string,std::string)>(this: (rbx::signal<void __cdecl(PluginReference)> *)(*(_QWORD *)(a2 + 128) + 3064LL)); /*0x1431e561e*/
}

// Address: 0x1431e5630 | Name: _RBX::Network::Client::Client_::_1_::dtor$16
void __fastcall RBX::Network::Client::Client_::_1_::dtor_16(__int64 a1, __int64 a2)
{
  rbx::signal<void (std::string,std::string,std::string,std::string)>::~signal<void (std::string,std::string,std::string,std::string)>(this: (rbx::signal<void __cdecl(PluginReference)> *)(*(_QWORD *)(a2 + 128) + 3088LL)); /*0x1431e563e*/
}

// Address: 0x1431e5650 | Name: _RBX::Network::Client::Client_::_1_::dtor$17
void __fastcall RBX::Network::Client::Client_::_1_::dtor_17(__int64 a1, __int64 a2)
{
  rbx::signal<void (std::string,std::string,std::string,std::string)>::~signal<void (std::string,std::string,std::string,std::string)>(this: (rbx::signal<void __cdecl(PluginReference)> *)(*(_QWORD *)(a2 + 128) + 3112LL)); /*0x1431e565e*/
}

// Address: 0x1431e5670 | Name: _RBX::Network::Client::Client_::_1_::dtor$18
void __fastcall RBX::Network::Client::Client_::_1_::dtor_18(__int64 a1, __int64 a2)
{
  std::vector<RBX::Network::Client::ServerConnection>::~vector<RBX::Network::Client::ServerConnection>(this: (std::vector<RBX::Network::Client::ServerConnection> *)(*(_QWORD *)(a2 + 128) + 3144LL)); /*0x1431e567e*/
}

// Address: 0x1431e5690 | Name: _RBX::Network::Client::Client_::_1_::dtor$19
void __fastcall RBX::Network::Client::Client_::_1_::dtor_19(__int64 a1, __int64 a2)
{
  RBX::Network::Client::LatencyExperimentCache::~LatencyExperimentCache(this: (RBX::Network::Client::LatencyExperimentCache *)(*(_QWORD *)(a2 + 128) + 3176LL)); /*0x1431e569e*/
}

// Address: 0x1431e56b0 | Name: _RBX::Network::Client::Client_::_1_::dtor$20
void __fastcall RBX::Network::Client::Client_::_1_::dtor_20(__int64 a1, __int64 a2)
{
  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)(*(_QWORD *)(a2 + 128) /*0x1431e56be*/
                                                                                                + 3288LL));
}

// Address: 0x1431e56d0 | Name: _RBX::Network::Client::Client_::_1_::dtor$21
void __fastcall RBX::Network::Client::Client_::_1_::dtor_21(__int64 a1, __int64 a2)
{
  std::recursive_mutex::~recursive_mutex(this: (RBX::InstrumentedMutex<std::mutex> *)(*(_QWORD *)(a2 + 128) + 3304LL)); /*0x1431e56de*/
}

// Address: 0x1431e56f0 | Name: _RBX::Network::Client::Client_::_1_::dtor$23
void __fastcall RBX::Network::Client::Client_::_1_::dtor_23(__int64 a1, __int64 a2)
{
  RBX::Network::Peer::~Peer(this: *(RBX::Network::Peer **)(a2 + 128)); /*0x1431e56f7*/
}

// Address: 0x1431e5810 | Name: _RBX::Network::Client::HandleConnection_::_1_::dtor$1
void __fastcall RBX::Network::Client::HandleConnection_::_1_::dtor_1(__int64 a1, __int64 a2)
{
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)(a2 + 432)); /*0x1431e5817*/
}

// Address: 0x1431e5820 | Name: _RBX::Network::Client::HandleConnection_::_1_::dtor$2
void __fastcall RBX::Network::Client::HandleConnection_::_1_::dtor_2(
        __int64 a1,
        std::_Binder<std::_Unforced,void (__cdecl RBX::NavigationDebugDraw::*)(dtNavMesh *,RBX::Extents),std::shared_ptr<RBX::NavigationDebugDraw> &,std::_Ph<1> const &,RBX::Extents &> *a2)
{
  rbx::signals::slot_with_functor<RBX::Reflection::ConnectGenericHelper<rbx::signal<void (enum RBX::MaterialType)>>,enum RBX::MaterialType>::do_dtor(this: a2 + 4); /*0x1431e5827*/
}

// Address: 0x1431e5830 | Name: _RBX::Network::Client::HandleConnection_::_1_::catch$20
__int64 __fastcall RBX::Network::Client::HandleConnection_::_1_::catch_20(
        __int64 a1,
        std::shared_ptr<std::vector<RBX::Guid> > *a2)
{
  const char *v3; // rax
  RBX::Instance *Rep; // rcx

  v3 = (const char *)((__int64 (__fastcall *)(std::vector<RBX::Guid> *))a2[18]._Ptr->_Mypair._Myval2._Myfirst[1])(a1: a2[18]._Ptr); /*0x1431e5847*/
  RBX::StandardOut::printf(type: MESSAGE_ERROR, format: "Error in ID_CONNECTION_REQUEST_ACCEPTED: %s", v3);
  Rep = (RBX::Instance *)a2[4]._Rep; /*0x1431e585e*/
  if ( Rep != nullptr ) /*0x1431e586a*/
  {
    Rep->isParentLocked = false; /*0x1431e586c*/
    a2[12] = 0; /*0x1431e5873*/
    RBX::Instance::setParentInternal( /*0x1431e588f*/
      this: Rep,
      newParent: nullptr,
      ignoreLock: false,
      destroying: false,
      destroyedGuids: a2 + 12);
  }
  return 0; /*0x1431e589f*/
}

// Address: 0x1431e58b0 | Name: _RBX::Network::Client::OnConnectFirstStageTimeout_::_1_::dtor$2
void __fastcall RBX::Network::Client::OnConnectFirstStageTimeout_::_1_::dtor_2(__int64 a1, __int64 a2)
{
  std::unordered_map<RBX::Soundscape::SoundId,std::string>::~unordered_map<RBX::Soundscape::SoundId,std::string>(t: *(void **)(a2 + 1344)); /*0x1431e58b7*/
}

// Address: 0x1431e58c0 | Name: _RBX::Network::Client::OnConnectFirstStageTimeout_::_1_::dtor$4
void __fastcall RBX::Network::Client::OnConnectFirstStageTimeout_::_1_::dtor_4(__int64 a1, __int64 a2)
{
  RBX::Graphics::ProfilerAdorn::Item::~Item(this: *(RBX::Graphics::ProfilerAdorn::Item **)(a2 + 1344)); /*0x1431e58c7*/
}

// Address: 0x1431e58d0 | Name: _RBX::Network::Client::OnConnectFirstStageTimeout_::_1_::dtor$13
void __fastcall RBX::Network::Client::OnConnectFirstStageTimeout_::_1_::dtor_13(__int64 a1, __int64 a2)
{
  std::list<std::pair<std::string const,std::string>>::~list<std::pair<std::string const,std::string>>(this: (std::list<std::pair<std::string,std::string >> *)(*(_QWORD *)(a2 + 1344) + 8LL)); /*0x1431e58db*/
}

// Address: 0x1431e58e0 | Name: _RBX::Network::Client::OnConnectFirstStageTimeout_::_1_::dtor$14
void __fastcall RBX::Network::Client::OnConnectFirstStageTimeout_::_1_::dtor_14(__int64 a1, __int64 a2)
{
  std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>::~_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>(this: (std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<__int64 const ,std::vector<RBX::Permission> > > > > > > *)(*(_QWORD *)(a2 + 1344) + 24LL)); /*0x1431e58eb*/
}

// Address: 0x1431e5900 | Name: _RBX::Network::Client::OnNewConnection_::_1_::dtor$0
void __fastcall RBX::Network::Client::OnNewConnection_::_1_::dtor_0(__int64 a1, __int64 a2)
{
  std::unordered_map<RBX::Soundscape::SoundId,std::string>::~unordered_map<RBX::Soundscape::SoundId,std::string>(t: *(void **)(a2 + 1296)); /*0x1431e5907*/
}

// Address: 0x1431e5910 | Name: _RBX::Network::Client::OnNewConnection_::_1_::dtor$1
void __fastcall RBX::Network::Client::OnNewConnection_::_1_::dtor_1(__int64 a1, __int64 a2)
{
  RBX::Graphics::ProfilerAdorn::Item::~Item(this: *(RBX::Graphics::ProfilerAdorn::Item **)(a2 + 1304)); /*0x1431e5917*/
}

// Address: 0x1431e5920 | Name: _RBX::Network::Client::OnNewConnection_::_1_::dtor$2
void __fastcall RBX::Network::Client::OnNewConnection_::_1_::dtor_2(__int64 a1, __int64 a2)
{
  RBX::Graphics::ProfilerAdorn::Item::~Item(this: *(RBX::Graphics::ProfilerAdorn::Item **)(a2 + 1296)); /*0x1431e5927*/
}

// Address: 0x1431e5930 | Name: _RBX::Network::Client::OnReceive_::_1_::dtor$0
void __fastcall RBX::Network::Client::OnReceive_::_1_::dtor_0(
        __int64 a1,
        RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> *a2)
{
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: a2 + 318); /*0x1431e5937*/
}

// Address: 0x1431e5940 | Name: _RBX::Network::Client::OnReceive_::_1_::dtor$5
void __fastcall RBX::Network::Client::OnReceive_::_1_::dtor_5(__int64 a1, __int64 a2)
{
  RBX::Graphics::ProfilerAdorn::Item::~Item(this: *(RBX::Graphics::ProfilerAdorn::Item **)(a2 + 1256)); /*0x1431e5947*/
}

// Address: 0x1431e59c0 | Name: _RBX::Network::Client::LatencyExperimentCache::getCacheFile_::_1_::dtor$1
void __fastcall RBX::Network::Client::LatencyExperimentCache::getCacheFile_::_1_::dtor_1(
        __int64 a1,
        RBX::MD5Hasher *a2)
{
  RBX::Crypto::HashMd5::~HashMd5(this: a2 + 25); /*0x1431e59c7*/
}

// Address: 0x1431e59d0 | Name: _RBX::Network::ExtAntiCheatCommunicator::getExtAntiCheatCommunicator_::_1_::dtor$0
void RBX::Network::ExtAntiCheatCommunicator::getExtAntiCheatCommunicator_::_1_::dtor_0()
{
  Init_thread_abort(pOnce: &_TSS0_519); /*0x1431e59d7*/
}

// Address: 0x1431e59e0 | Name: _RBX::Network::ExtAntiCheatCommunicator::getExtAntiCheatCommunicator_::_1_::dtor$1
void RBX::Network::ExtAntiCheatCommunicator::getExtAntiCheatCommunicator_::_1_::dtor_1()
{
  std::weak_ptr<RBX::Soundscape::Sound>::~weak_ptr<RBX::Soundscape::Sound>(this: (std::weak_ptr<PluginPermissionsFetcher> *)&singleton_2); /*0x1431e59e7*/
}

// Address: 0x1431e59f0 | Name: _RBX::Network::ExtAntiCheatCommunicator::getExtAntiCheatCommunicator_::_1_::dtor$2
void RBX::Network::ExtAntiCheatCommunicator::getExtAntiCheatCommunicator_::_1_::dtor_2()
{
  std::list<std::vector<unsigned char>>::~list<std::vector<unsigned char>>(this: &singleton_2.queue); /*0x1431e59fb*/
}

// Address: 0x1431e5a00 | Name: _RBX::Network::Replicator::JoinDataItem::read_::_1_::dtor$5
void __fastcall RBX::Network::Replicator::JoinDataItem::read_::_1_::dtor_5(__int64 a1, __int64 a2)
{
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)(a2 + 112)); /*0x1431e5a07*/
}

// Address: 0x1431e5aa0 | Name: _RBX::Network::Client::onServiceProvider_::_1_::dtor$21
void __fastcall RBX::Network::Client::onServiceProvider_::_1_::dtor_21(__int64 a1, __int64 a2)
{
  if ( (*(_DWORD *)(a2 + 152) & 8) != 0 ) /*0x1431e5ab4*/
  {
    *(_DWORD *)(a2 + 152) &= ~8u; /*0x1431e5ab6*/
    rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)(a2 + 64)); /*0x1431e5ac1*/
  }
}

// Address: 0x1431e5ad0 | Name: _RBX::Network::Client::playerConnect_::_1_::dtor$0
void __fastcall RBX::Network::Client::playerConnect_::_1_::dtor_0(__int64 a1, __int64 a2)
{
  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: *(std::shared_ptr<RBX::File> **)(a2 + 1864)); /*0x1431e5ad7*/
}

// Address: 0x1431e5ae0 | Name: _RBX::Network::Client::playerConnect_::_1_::dtor$1
void __fastcall RBX::Network::Client::playerConnect_::_1_::dtor_1(__int64 a1, __int64 a2)
{
  RBX::Graphics::ProfilerAdorn::Item::~Item(this: *(RBX::Graphics::ProfilerAdorn::Item **)(a2 + 1848)); /*0x1431e5ae7*/
}

// Address: 0x1431e5af0 | Name: _RBX::Network::Client::playerConnect_::_1_::dtor$2
void __fastcall RBX::Network::Client::playerConnect_::_1_::dtor_2(__int64 a1, __int64 a2)
{
  RBX::Graphics::ProfilerAdorn::Item::~Item(this: *(RBX::Graphics::ProfilerAdorn::Item **)(a2 + 1808)); /*0x1431e5af7*/
}

// Address: 0x1431e5b00 | Name: _RBX::Network::Client::playerConnect_::_1_::dtor$7
void __fastcall RBX::Network::Client::playerConnect_::_1_::dtor_7(__int64 a1, __int64 a2)
{
  RBX::Network::Client::ServerConnection::~ServerConnection(this: (RBX::Network::Client::ServerConnection *)(a2 + 592)); /*0x1431e5b07*/
}

// Address: 0x1431e5b20 | Name: _RBX::Network::Client::playerConnect_::_1_::dtor$14
void __fastcall RBX::Network::Client::playerConnect_::_1_::dtor_14(
        __int64 a1,
        std::vector<RakNet::SocketDescriptor> *a2)
{
  std::vector<RakNet::SocketDescriptor>::~vector<RakNet::SocketDescriptor>(this: a2 + 4); /*0x1431e5b27*/
}

// Address: 0x1431e5b30 | Name: _RBX::Network::Client::playerConnect_::_1_::dtor$51
void __fastcall RBX::Network::Client::playerConnect_::_1_::dtor_51(
        __int64 a1,
        std::_Tidy_guard<std::vector<RakNet::SocketDescriptor> > *a2)
{
  std::_Tidy_guard<std::vector<RakNet::SocketDescriptor>>::~_Tidy_guard<std::vector<RakNet::SocketDescriptor>>(this: a2 + 20); /*0x1431e5b37*/
}

// Address: 0x1431e5b40 | Name: _RBX::Network::Client::sendExtAntiCheat_::_1_::dtor$6
__int64 __fastcall RBX::Network::Client::sendExtAntiCheat_::_1_::dtor_6(__int64 a1, __int64 a2)
{
  return lambda_296d3da0b53b7165d85aadcb1642c9d5_::__lambda_296d3da0b53b7165d85aadcb1642c9d5_(a1: *(_QWORD *)(a2 + 80));
}

// Address: 0x1431e5b50 | Name: _RBX::Network::Client::sendExtAntiCheat_::_1_::dtor$8
void __fastcall RBX::Network::Client::sendExtAntiCheat_::_1_::dtor_8(
        __int64 a1,
        std::unique_ptr<webrtc::ComfortNoise> *a2)
{
  `std::_Global_new<std::_Func_impl_no_alloc<_lambda_f8c4b7e6150b88b311f5039a2ec2dc7b_,void,>,_lambda_f8c4b7e6150b88b311f5039a2ec2dc7b_ const &>'::`2'::_Guard_type::~_Guard_type(this: a2 + 11); /*0x1431e5b57*/
}

// Address: 0x1431e5b70 | Name: _RBX::Network::Client::sendTicket_::_1_::dtor$7
__int64 __fastcall RBX::Network::Client::sendTicket_::_1_::dtor_7(__int64 a1, __int64 a2)
{
  __int64 result; // rax

  result = *(_DWORD *)(a2 + 680) & 1; /*0x1431e5b7f*/
  if ( (_DWORD)result != 0 ) /*0x1431e5b84*/
  {
    *(_DWORD *)(a2 + 680) &= ~1u; /*0x1431e5b86*/
    return std::ios::~ios<char,std::char_traits<char>>(a1: a2 + 488); /*0x1431e5b9b*/
  }
  return result; /*0x1431e5ba1*/
}

// Address: 0x1431e5bd0 | Name: _RBX::Network::Client::setTicket_::_1_::dtor$10
void __fastcall RBX::Network::Client::setTicket_::_1_::dtor_10(
        __int64 a1,
        std::_Temporary_owner<RBX::Security::EarlyAuthData> *a2)
{
  std::_Temporary_owner<RBX::Security::EarlyAuthData>::~_Temporary_owner<RBX::Security::EarlyAuthData>(this: a2 + 20); /*0x1431e5bd7*/
}

// Address: 0x1431e5e30 | Name: _std::vector_RBX::Network::Server::LegalScript_std::allocator_RBX::Network::Server::LegalScript___::_Emplace_reallocate_RBX::Network::Server::LegalScript__::_1_::catch$20
void __fastcall __noreturn std::vector_RBX::Network::Server::LegalScript_std::allocator_RBX::Network::Server::LegalScript___::_Emplace_reallocate_RBX::Network::Server::LegalScript__::_1_::catch_20(
        __int64 a1,
        __int64 a2)
{
  std::vector<RBX::Network::Server::LegalScript>::_Destroy( /*0x1431e5e4d*/
    this: *(std::vector<RBX::Network::Server::LegalScript> **)(a2 + 128),
    _First: *(RBX::Network::Server::LegalScript **)(a2 + 32),
    _Last: *(RBX::Network::Server::LegalScript **)(a2 + 48));
  std::allocator<RBX::Security::KeyRing::KeyInfo>::deallocate( /*0x1431e5e67*/
    this: *(std::allocator<AssetProxyOverrideViewModel::AssetOverride> **)(a2 + 128),
    _Ptr: *(AssetProxyOverrideViewModel::AssetOverride *const *)(a2 + 152),
    _Count: *(_QWORD *)(a2 + 136));
  throw; /*0x1431e5e70*/
}

// Address: 0x1431e5e80 | Name: _RBX::Creatable_RBX::Instance_::create_RBX::Network::ServerReplicator_RBX::Network::Replicator::ReplicatorPeerInfo_&_RBX::Network::Server___&_RBX::NetworkSettings___&__::_1_::dtor$1
void __fastcall RBX::Creatable_RBX::Instance_::create_RBX::Network::ServerReplicator_RBX::Network::Replicator::ReplicatorPeerInfo___RBX::Network::Server_____RBX::NetworkSettings______::_1_::dtor_1(
        __int64 a1,
        __int64 a2)
{
  operator delete(ptr: *(void **)(a2 + 176)); /*0x1431e5e95*/
}

// Address: 0x1431e5ea0 | Name: _RBX::ServiceProvider::doGetClassIndex_RBX::Network::ClusterPacketCache__::_1_::dtor$0
void RBX::ServiceProvider::doGetClassIndex_RBX::Network::ClusterPacketCache__::_1_::dtor_0()
{
  Init_thread_abort(pOnce: &__TSS0__1____doGetClassIndex_VClusterPacketCache_Network_RBX___ServiceProvider_RBX__CA_KXZ_4HA); /*0x1431e5ea7*/
}

// Address: 0x1431e5ec0 | Name: _RBX::Network::RomarkPhaseTrackingJob::RomarkPhaseTrackingJob_::_1_::dtor$2
void __fastcall RBX::Network::RomarkPhaseTrackingJob::RomarkPhaseTrackingJob_::_1_::dtor_2(__int64 a1, __int64 a2)
{
  RBX::DataModelJob::~DataModelJob(this: *(RBX::BaseRenderJob **)(a2 + 320)); /*0x1431e5ec7*/
}

// Address: 0x1431e5ed0 | Name: _RBX::Network::RomarkPhaseTrackingJob::RomarkPhaseTrackingJob_::_1_::dtor$3
void __fastcall RBX::Network::RomarkPhaseTrackingJob::RomarkPhaseTrackingJob_::_1_::dtor_3(__int64 a1, __int64 a2)
{
  std::weak_ptr<RBX::Soundscape::Sound>::~weak_ptr<RBX::Soundscape::Sound>(this: (std::weak_ptr<PluginPermissionsFetcher> *)(*(_QWORD *)(a2 + 320) + 360LL)); /*0x1431e5ede*/
}

// Address: 0x1431e5ef0 | Name: _RBX::Network::RomarkPhaseTrackingJob::RomarkPhaseTrackingJob_::_1_::dtor$4
void __fastcall RBX::Network::RomarkPhaseTrackingJob::RomarkPhaseTrackingJob_::_1_::dtor_4(__int64 a1, __int64 a2)
{
  std::vector<std::pair<unsigned short,unsigned short>>::~vector<std::pair<unsigned short,unsigned short>>(this: (std::vector<enum VkPresentModeKHR> *)(*(_QWORD *)(a2 + 320) + 384LL)); /*0x1431e5efe*/
}

// Address: 0x1431e5f20 | Name: _RBX::Network::RomarkPhaseTrackingJob::RomarkPhaseTrackingJob_::_1_::dtor$12
void __fastcall RBX::Network::RomarkPhaseTrackingJob::RomarkPhaseTrackingJob_::_1_::dtor_12(__int64 a1, __int64 a2)
{
  boost::algorithm::detail::is_any_ofF<char>::~is_any_ofF<char>(this: *(boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > **)(a2 + 144)); /*0x1431e5f27*/
}

// Address: 0x1431e5f30 | Name: _RBX::Network::Server::Server_::_1_::dtor$0
void __fastcall RBX::Network::Server::Server_::_1_::dtor_0(__int64 a1, __int64 a2)
{
  RBX::DescribedCreatable<RBX::Network::Server,RBX::Network::Peer>::~DescribedCreatable<RBX::Network::Server,RBX::Network::Peer>(this: *(RBX::DescribedCreatable<RBX::Network::Server,RBX::Network::Peer> **)(a2 + 176)); /*0x1431e5f37*/
}

// Address: 0x1431e5f40 | Name: _RBX::Network::Server::Server_::_1_::dtor$1
void __fastcall RBX::Network::Server::Server_::_1_::dtor_1(__int64 a1, __int64 a2)
{
  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)(*(_QWORD *)(a2 + 176) /*0x1431e5f4e*/
                                                                                                + 440LL));
}

// Address: 0x1431e5f60 | Name: _RBX::Network::Server::Server_::_1_::dtor$2
void __fastcall RBX::Network::Server::Server_::_1_::dtor_2(__int64 a1, __int64 a2)
{
  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)(*(_QWORD *)(a2 + 176) /*0x1431e5f6e*/
                                                                                                + 456LL));
}

// Address: 0x1431e5f80 | Name: _RBX::Network::Server::Server_::_1_::dtor$3
void __fastcall RBX::Network::Server::Server_::_1_::dtor_3(__int64 a1, __int64 a2)
{
  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)(*(_QWORD *)(a2 + 176) /*0x1431e5f8e*/
                                                                                                + 472LL));
}

// Address: 0x1431e5fa0 | Name: _RBX::Network::Server::Server_::_1_::dtor$4
void __fastcall RBX::Network::Server::Server_::_1_::dtor_4(__int64 a1, __int64 a2)
{
  RBX::Network::MegaReplicator::~MegaReplicator(this: (RBX::Network::MegaReplicator *)(*(_QWORD *)(a2 + 176) + 496LL)); /*0x1431e5fae*/
}

// Address: 0x1431e5fc0 | Name: _RBX::Network::Server::Server_::_1_::dtor$5
void __fastcall RBX::Network::Server::Server_::_1_::dtor_5(__int64 a1, __int64 a2)
{
  rbx::signals::scoped_connection::~scoped_connection(this: (rbx::signals::scoped_connection *)(*(_QWORD *)(a2 + 176) /*0x1431e5fce*/
                                                                                              + 2688LL));
}

// Address: 0x1431e5fe0 | Name: _RBX::Network::Server::Server_::_1_::dtor$6
void __fastcall RBX::Network::Server::Server_::_1_::dtor_6(__int64 a1, __int64 a2)
{
  rbx::signals::scoped_connection::~scoped_connection(this: (rbx::signals::scoped_connection *)(*(_QWORD *)(a2 + 176) /*0x1431e5fee*/
                                                                                              + 2696LL));
}

// Address: 0x1431e6000 | Name: _RBX::Network::Server::Server_::_1_::dtor$7
void __fastcall RBX::Network::Server::Server_::_1_::dtor_7(__int64 a1, __int64 a2)
{
  rbx::signals::scoped_connection::~scoped_connection(this: (rbx::signals::scoped_connection *)(*(_QWORD *)(a2 + 176) /*0x1431e600e*/
                                                                                              + 2704LL));
}

// Address: 0x1431e6020 | Name: _RBX::Network::Server::Server_::_1_::dtor$8
void __fastcall RBX::Network::Server::Server_::_1_::dtor_8(__int64 a1, __int64 a2)
{
  std::vector<RBX::Network::SecurityJoinInfo>::~vector<RBX::Network::SecurityJoinInfo>(this: (std::vector<RBX::Network::SecurityJoinInfo> *)(*(_QWORD *)(a2 + 176) + 2712LL)); /*0x1431e602e*/
}

// Address: 0x1431e6040 | Name: _RBX::Network::Server::Server_::_1_::dtor$9
void __fastcall RBX::Network::Server::Server_::_1_::dtor_9(__int64 a1, __int64 a2)
{
  std::vector<RBX::Network::Server::LegalScript>::~vector<RBX::Network::Server::LegalScript>(this: (std::vector<RBX::Network::Server::LegalScript> *)(*(_QWORD *)(a2 + 176) + 2768LL)); /*0x1431e604e*/
}

// Address: 0x1431e6060 | Name: _RBX::Network::Server::Server_::_1_::dtor$10
void __fastcall RBX::Network::Server::Server_::_1_::dtor_10(__int64 a1, __int64 a2)
{
  boost::unordered::unordered_map<RBX::SharedString,int,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>,std::allocator<std::pair<RBX::SharedString const,int>>>::~unordered_map<RBX::SharedString,int,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>,std::allocator<std::pair<RBX::SharedString const,int>>>(this: (boost::unordered::unordered_map<RBX::SharedString,int,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>,std::allocator<std::pair<RBX::SharedString const ,int> > > *)(*(_QWORD *)(a2 + 176) + 2792LL)); /*0x1431e606e*/
}

// Address: 0x1431e6080 | Name: _RBX::Network::Server::Server_::_1_::dtor$11
void __fastcall RBX::Network::Server::Server_::_1_::dtor_11(__int64 a1, __int64 a2)
{
  boost::unordered::unordered_map<RBX::SharedString,int,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>,std::allocator<std::pair<RBX::SharedString const,int>>>::~unordered_map<RBX::SharedString,int,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>,std::allocator<std::pair<RBX::SharedString const,int>>>(this: (boost::unordered::unordered_map<RBX::SharedString,int,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>,std::allocator<std::pair<RBX::SharedString const ,int> > > *)(*(_QWORD *)(a2 + 176) + 2840LL)); /*0x1431e608e*/
}

// Address: 0x1431e60a0 | Name: _RBX::Network::Server::Server_::_1_::dtor$12
void __fastcall RBX::Network::Server::Server_::_1_::dtor_12(__int64 a1, __int64 a2)
{
  std::unordered_map<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,std::allocator<std::pair<RakNet::SystemAddress const,RakNet::RakPeer::BytesInReturnQueuePeerTracker>>>::~unordered_map<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,std::allocator<std::pair<RakNet::SystemAddress const,RakNet::RakPeer::BytesInReturnQueuePeerTracker>>>(this: (std::unordered_map<__int64,RBX::HumanoidDescription::AssetData> *)(*(_QWORD *)(a2 + 176) + 2888LL)); /*0x1431e60ae*/
}

// Address: 0x1431e60c0 | Name: _RBX::Network::Server::Server_::_1_::dtor$13
void __fastcall RBX::Network::Server::Server_::_1_::dtor_13(__int64 a1, __int64 a2)
{
  boost::mutex::~mutex(this: (boost::mutex *)(*(_QWORD *)(a2 + 176) + 2952LL)); /*0x1431e60ce*/
}

// Address: 0x1431e60e0 | Name: _RBX::Network::Server::Server_::_1_::dtor$14
void __fastcall RBX::Network::Server::Server_::_1_::dtor_14(__int64 a1, __int64 a2)
{
  boost::unordered::unordered_set<RBX::PackageAssetVersion,boost::hash<RBX::PackageAssetVersion>,std::equal_to<RBX::PackageAssetVersion>,std::allocator<RBX::PackageAssetVersion>>::~unordered_set<RBX::PackageAssetVersion,boost::hash<RBX::PackageAssetVersion>,std::equal_to<RBX::PackageAssetVersion>,std::allocator<RBX::PackageAssetVersion>>(this: (boost::unordered::unordered_map<__int64,enum RBX::MembershipType,boost::hash<__int64>,std::equal_to<__int64>,std::allocator<std::pair<__int64 const ,enum RBX::MembershipType> > > *)(*(_QWORD *)(a2 + 176) + 2968LL)); /*0x1431e60ee*/
}

// Address: 0x1431e6100 | Name: _RBX::Network::Server::Server_::_1_::dtor$15
void __fastcall RBX::Network::Server::Server_::_1_::dtor_15(__int64 a1, __int64 a2)
{
  boost::unordered::unordered_map<__int64,std::weak_ptr<RBX::Network::ServerReplicator>,boost::hash<__int64>,std::equal_to<__int64>,std::allocator<std::pair<__int64 const,std::weak_ptr<RBX::Network::ServerReplicator>>>>::~unordered_map<__int64,std::weak_ptr<RBX::Network::ServerReplicator>,boost::hash<__int64>,std::equal_to<__int64>,std::allocator<std::pair<__int64 const,std::weak_ptr<RBX::Network::ServerReplicator>>>>(this: (boost::unordered::unordered_map<__int64,std::weak_ptr<RBX::Network::ServerReplicator>,boost::hash<__int64>,std::equal_to<__int64>,std::allocator<std::pair<__int64 const ,std::weak_ptr<RBX::Network::ServerReplicator> > > > *)(*(_QWORD *)(a2 + 176) + 3016LL)); /*0x1431e610e*/
}

// Address: 0x1431e6120 | Name: _RBX::Network::Server::Server_::_1_::dtor$16
void __fastcall RBX::Network::Server::Server_::_1_::dtor_16(__int64 a1, __int64 a2)
{
  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)(*(_QWORD *)(a2 + 176) /*0x1431e612e*/
                                                                                                + 3064LL));
}

// Address: 0x1431e6140 | Name: _RBX::Network::Server::Server_::_1_::dtor$17
void __fastcall RBX::Network::Server::Server_::_1_::dtor_17(__int64 a1, __int64 a2)
{
  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)(*(_QWORD *)(a2 + 176) /*0x1431e614e*/
                                                                                                + 3096LL));
}

// Address: 0x1431e6160 | Name: _RBX::Network::Server::Server_::_1_::dtor$18
void __fastcall RBX::Network::Server::Server_::_1_::dtor_18(__int64 a1, __int64 a2)
{
  RBX::ProtectedString::~ProtectedString(this: (RBX::Scripting::DebuggerEvalExpression *)(*(_QWORD *)(a2 + 176) + 3112LL)); /*0x1431e616e*/
}

// Address: 0x1431e6180 | Name: _RBX::Network::Server::Server_::_1_::dtor$19
void __fastcall RBX::Network::Server::Server_::_1_::dtor_19(__int64 a1, __int64 a2)
{
  boost::mutex::~mutex(this: (boost::mutex *)(*(_QWORD *)(a2 + 176) + 3160LL)); /*0x1431e618e*/
}

// Address: 0x1431e61a0 | Name: _RBX::Network::Server::Server_::_1_::dtor$20
void __fastcall RBX::Network::Server::Server_::_1_::dtor_20(__int64 a1, __int64 a2)
{
  RBX::ScriptServices::Documentation::ValidateResult::~ValidateResult(this: (std::vector<RBX::MeshId> *)(*(_QWORD *)(a2 + 176) + 3192LL)); /*0x1431e61ae*/
}

// Address: 0x1431e61c0 | Name: _RBX::Network::Server::Server_::_1_::dtor$21
void __fastcall RBX::Network::Server::Server_::_1_::dtor_21(__int64 a1, __int64 a2)
{
  rbx::signal<void (std::string,std::string,std::string,std::string)>::~signal<void (std::string,std::string,std::string,std::string)>(this: (rbx::signal<void __cdecl(PluginReference)> *)(*(_QWORD *)(a2 + 176) + 3216LL)); /*0x1431e61ce*/
}

// Address: 0x1431e61e0 | Name: _RBX::Network::Server::Server_::_1_::dtor$22
void __fastcall RBX::Network::Server::Server_::_1_::dtor_22(__int64 a1, __int64 a2)
{
  std::set<RBX::ContentId>::~set<RBX::ContentId>(this: (std::set<RBX::Studio::ScriptRef> *)(*(_QWORD *)(a2 + 176) /*0x1431e61ee*/
                                                                                          + 3240LL));
}

// Address: 0x1431e6200 | Name: _RBX::Network::Server::Server_::_1_::dtor$23
void __fastcall RBX::Network::Server::Server_::_1_::dtor_23(__int64 a1, __int64 a2)
{
  std::set<RBX::ContentId>::~set<RBX::ContentId>(this: (std::set<RBX::Studio::ScriptRef> *)(*(_QWORD *)(a2 + 176) /*0x1431e620e*/
                                                                                          + 3256LL));
}

// Address: 0x1431e6220 | Name: _RBX::Network::Server::Server_::_1_::dtor$24
void __fastcall RBX::Network::Server::Server_::_1_::dtor_24(__int64 a1, __int64 a2)
{
  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)(*(_QWORD *)(a2 + 176) /*0x1431e622e*/
                                                                                                + 3272LL));
}

// Address: 0x1431e6250 | Name: _RBX::Network::Server::Server_::_1_::dtor$28
void __fastcall RBX::Network::Server::Server_::_1_::dtor_28(__int64 a1, __int64 a2)
{
  RBX::Network::Peer::~Peer(this: *(RBX::Network::Peer **)(a2 + 176)); /*0x1431e6257*/
}

// Address: 0x1431e6260 | Name: _RBX::Network::Server::Server_::_1_::dtor$34
void __fastcall RBX::Network::Server::Server_::_1_::dtor_34(__int64 a1, __int64 a2)
{
  std::list<std::pair<RakNet::SystemAddress const,RakNet::RakPeer::BanStruct *>>::~list<std::pair<RakNet::SystemAddress const,RakNet::RakPeer::BanStruct *>>(this: (std::list<webrtc::ProcessThreadImpl::ModuleCallback> *)(*(_QWORD *)(a2 + 184) + 8LL)); /*0x1431e626b*/
}

// Address: 0x1431e6330 | Name: _RBX::Network::Server::OnReceive_::_1_::dtor$6
void __fastcall RBX::Network::Server::OnReceive_::_1_::dtor_6(__int64 a1, __int64 a2)
{
  rbx::signals::slot_with_functor<RBX::Reflection::ConnectGenericHelper<rbx::signal<void (enum RBX::MaterialType)>>,enum RBX::MaterialType>::do_dtor(this: (std::_Binder<std::_Unforced,void (__cdecl RBX::NavigationDebugDraw::*)(dtNavMesh *,RBX::Extents),std::shared_ptr<RBX::NavigationDebugDraw> &,std::_Ph<1> const &,RBX::Extents &> *)(a2 + 80)); /*0x1431e6337*/
}

// Address: 0x1431e6340 | Name: _RBX::Network::Server::OnReceive_::_1_::dtor$18
void __fastcall RBX::Network::Server::OnReceive_::_1_::dtor_18(__int64 a1, __int64 a2)
{
  rbx::signals::slot_with_functor<RBX::Reflection::ConnectGenericHelper<rbx::signal<void (enum RBX::MaterialType)>>,enum RBX::MaterialType>::do_dtor(this: *(std::_Binder<std::_Unforced,void (__cdecl RBX::NavigationDebugDraw::*)(dtNavMesh *,RBX::Extents),std::shared_ptr<RBX::NavigationDebugDraw> &,std::_Ph<1> const &,RBX::Extents &> **)(a2 + 48)); /*0x1431e6347*/
}

// Address: 0x1431e6350 | Name: _RBX::Network::Server::OnReceive_::_1_::catch$26
__int64 __fastcall RBX::Network::Server::OnReceive_::_1_::catch_26(__int64 a1, __int64 a2)
{
  __int64 v3; // rdi
  __int64 v4; // rbx
  const char *v5; // rax
  const char *v6; // rax
  RBX::Instance *v7; // rcx

  v3 = *(_QWORD *)(a2 + 536); /*0x1431e6366*/
  if ( FLog::Error != 0 ) /*0x1431e636f*/
  {
    FLog::FastLog( /*0x1431e6380*/
      level: FLog::Error,
      message: "[FLog::Error] On receive packet %d",
      arg0: (const void *)**(unsigned __int8 **)(v3 + 56));
    v4 = *(_QWORD *)(a2 + 56); /*0x1431e6385*/
    if ( FLog::Error != 0 ) /*0x1431e6390*/
    {
      v5 = (const char *)(*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)v4 + 8LL))(a1: *(_QWORD *)(a2 + 56)); /*0x1431e6398*/
      FLog::FastLogS(level: FLog::Error, message: "[FLog::Error] Error %s", sarg: v5); /*0x1431e63ac*/
    }
  }
  else
  {
    v4 = *(_QWORD *)(a2 + 56); /*0x1431e63b3*/
  }
  v6 = (const char *)(*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v4 + 8LL))(a1: v4); /*0x1431e63bd*/
  RBX::StandardOut::printf(
    type: MESSAGE_ERROR,
    format: "Server::OnReceive packet %d: %s",
    **(unsigned __int8 **)(v3 + 56),
    v6);
  v7 = *(RBX::Instance **)(a2 + 64); /*0x1431e63dc*/
  if ( v7 != nullptr ) /*0x1431e63e8*/
  {
    v7->isParentLocked = false; /*0x1431e63ea*/
    *(_OWORD *)(a2 + 152) = 0; /*0x1431e63f1*/
    RBX::Instance::setParentInternal( /*0x1431e640d*/
      this: v7,
      newParent: nullptr,
      ignoreLock: false,
      destroying: false,
      destroyedGuids: (std::shared_ptr<std::vector<RBX::Guid> > *)(a2 + 152));
  }
  return 0; /*0x1431e641d*/
}

// Address: 0x1431e6530 | Name: _RBX::Network::Server::getNetworkSchemaInfo_::_1_::dtor$6
void __fastcall RBX::Network::Server::getNetworkSchemaInfo_::_1_::dtor_6(__int64 a1, __int64 a2)
{
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)(*(_QWORD *)(a2 + 112) + 16LL)); /*0x1431e653b*/
}

// Address: 0x1431e65a0 | Name: _RBX::Network::StreamingObserver::initialize_::_1_::dtor$0
void __fastcall RBX::Network::StreamingObserver::initialize_::_1_::dtor_0(
        __int64 a1,
        RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> *a2)
{
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: a2 + 168); /*0x1431e65a7*/
}

// Address: 0x1431e65b0 | Name: _RBX::Network::Server::onServiceProvider_::_1_::dtor$18
void __fastcall RBX::Network::Server::onServiceProvider_::_1_::dtor_18(__int64 a1, __int64 a2)
{
  if ( (*(_DWORD *)(a2 + 664) & 1) != 0 ) /*0x1431e65c4*/
  {
    *(_DWORD *)(a2 + 664) &= ~1u; /*0x1431e65c6*/
    rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)(a2 + 64)); /*0x1431e65d1*/
  }
}

// Address: 0x1431e65e0 | Name: _RBX::Network::Server::onServiceProvider_::_1_::dtor$50
void __fastcall RBX::Network::Server::onServiceProvider_::_1_::dtor_50(__int64 a1, __int64 a2)
{
  boost::unique_lock<boost::mutex>::~unique_lock<boost::mutex>(this: (boost::unique_lock<boost::mutex> *)(a2 + 408)); /*0x1431e65e7*/
}

// Address: 0x1431e65f0 | Name: _RBX::Network::Server::onServiceProvider_::_1_::dtor$51
void __fastcall RBX::Network::Server::onServiceProvider_::_1_::dtor_51(__int64 a1, __int64 a2)
{
  boost::thread_resource_error::~thread_resource_error(this: (boost::lock_error *)(a2 + 520)); /*0x1431e65f7*/
}

// Address: 0x1431e6600 | Name: _RBX::Network::Server::onServiceProvider_::_1_::dtor$70
void __fastcall RBX::Network::Server::onServiceProvider_::_1_::dtor_70(__int64 a1, __int64 a2)
{
  if ( (*(_DWORD *)(a2 + 664) & 0x200000) != 0 ) /*0x1431e6616*/
  {
    *(_DWORD *)(a2 + 664) &= ~0x200000u; /*0x1431e6618*/
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)(a2 + 296)); /*0x1431e6629*/
  }
}

// Address: 0x1431e6640 | Name: _RBX::Network::Server::onServiceProvider_::_1_::dtor$75
void __fastcall RBX::Network::Server::onServiceProvider_::_1_::dtor_75(
        __int64 a1,
        RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> *a2)
{
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: a2 + 170); /*0x1431e6647*/
}

// Address: 0x1431e6650 | Name: _RBX::Network::Server::onServiceProvider_::_1_::dtor$77
void __fastcall RBX::Network::Server::onServiceProvider_::_1_::dtor_77(__int64 a1, __int64 a2)
{
  if ( (*(_DWORD *)(a2 + 664) & 0x400000) != 0 ) /*0x1431e6666*/
  {
    *(_DWORD *)(a2 + 664) &= ~0x400000u; /*0x1431e6668*/
    rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)(a2 + 72)); /*0x1431e6676*/
  }
}

// Address: 0x1431e66c0 | Name: _RBX::Network::Server::registerLegalSharedScript_::_1_::dtor$0
void __fastcall RBX::Network::Server::registerLegalSharedScript_::_1_::dtor_0(__int64 a1, __int64 a2)
{
  rbx::implementation::typed_holder<RBX::ProtectedString>::destruct_func(dest: (char *)(a2 + 32)); /*0x1431e66c7*/
}

// Address: 0x1431e66e0 | Name: _RBX::Network::ClientReplicator::GCJob::reportPerSessionPauseStats_::_1_::dtor$3
void __fastcall RBX::Network::ClientReplicator::GCJob::reportPerSessionPauseStats_::_1_::dtor_3(
        __int64 a1,
        std::vector<RBX::Telemetry::EphemeralStatBatchEvent> *a2)
{
  std::vector<RBX::LSP::SnippetSetting>::_Tidy(this: a2 + 4); /*0x1431e66e7*/
}

// Address: 0x1431e67c0 | Name: _RBX::Network::Replicator::reportRakNetStatistics_::_1_::dtor$0
void __fastcall RBX::Network::Replicator::reportRakNetStatistics_::_1_::dtor_0(
        __int64 a1,
        std::vector<RBX::Telemetry::EphemeralStatBatchEvent> *a2)
{
  std::vector<RBX::LSP::SnippetSetting>::_Tidy(this: a2 + 6); /*0x1431e67c7*/
}

// Address: 0x1431e69f0 | Name: _RBX::Network::ReplicatorJob::ReplicatorJob_::_1_::dtor$1
void __fastcall RBX::Network::ReplicatorJob::ReplicatorJob_::_1_::dtor_1(__int64 a1, __int64 a2)
{
  RBX::DataModelJob::~DataModelJob(this: *(RBX::BaseRenderJob **)(a2 + 192)); /*0x1431e69f7*/
}

// Address: 0x1431e6a20 | Name: _RBX::Network::PacketReceiveJob::PacketReceiveJob_::_1_::dtor$5
void __fastcall RBX::Network::PacketReceiveJob::PacketReceiveJob_::_1_::dtor_5(__int64 a1, __int64 a2)
{
  std::weak_ptr<RBX::Soundscape::Sound>::~weak_ptr<RBX::Soundscape::Sound>(this: (std::weak_ptr<PluginPermissionsFetcher> *)(*(_QWORD *)(a2 + 192) + 376LL)); /*0x1431e6a2e*/
}

// Address: 0x1431e6a40 | Name: _RBX::Network::Peer::Peer_::_1_::dtor$1
void __fastcall RBX::Network::Peer::Peer_::_1_::dtor_1(__int64 a1, __int64 a2)
{
  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)(*(_QWORD *)(a2 + 64) /*0x1431e6a4e*/
                                                                                                + 336LL));
}

// Address: 0x1431e6a60 | Name: _RBX::Network::Peer::Peer_::_1_::dtor$2
void __fastcall RBX::Network::Peer::Peer_::_1_::dtor_2(__int64 a1, __int64 a2)
{
  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)(*(_QWORD *)(a2 + 64) /*0x1431e6a6e*/
                                                                                                + 360LL));
}

// Address: 0x1431e6aa0 | Name: _RBX::Network::Peer::onServiceProvider_::_1_::dtor$4
void __fastcall RBX::Network::Peer::onServiceProvider_::_1_::dtor_4(__int64 a1, __int64 a2)
{
  operator delete(ptr: *(void **)(a2 + 56)); /*0x1431e6ab2*/
}

// Address: 0x1431e6ac0 | Name: _RBX::Network::Peer::onServiceProvider_::_1_::dtor$34
void __fastcall RBX::Network::Peer::onServiceProvider_::_1_::dtor_34(
        __int64 a1,
        std::_Temporary_owner<RBX::Network::ConcurrentRakPeer> *a2)
{
  std::_Temporary_owner<RBX::Network::ConcurrentRakPeer>::~_Temporary_owner<RBX::Network::ConcurrentRakPeer>(this: a2 + 36); /*0x1431e6ac7*/
}

// Address: 0x1431e6ad0 | Name: _RBX::Network::ClientReplicator::GCJob::RegionRemovalItem::write_::_1_::dtor$0
void __fastcall RBX::Network::ClientReplicator::GCJob::RegionRemovalItem::write_::_1_::dtor_0(__int64 a1, __int64 a2)
{
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)(a2 + 32)); /*0x1431e6ad7*/
}

// Address: 0x1431e6ae0 | Name: _RBX::Network::NetworkSenderScheduleJob::stepDataModelJob_::_1_::dtor$17
void __fastcall RBX::Network::NetworkSenderScheduleJob::stepDataModelJob_::_1_::dtor_17(
        __int64 a1,
        RBX::DataModel::scoped_write_request *a2)
{
  RBX::DataModel::scoped_write_request::~scoped_write_request(this: a2 + 14); /*0x1431e6ae7*/
}

// Address: 0x1431e6ec0 | Name: _RBX::Network::ClientReplicator::prepareJoinRxDataStats_::_1_::dtor$34
void __fastcall RBX::Network::ClientReplicator::prepareJoinRxDataStats_::_1_::dtor_34(__int64 a1, __int64 a2)
{
  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)(a2 + 1672)); /*0x1431e6ec7*/
}

// Address: 0x1431e71a0 | Name: _RBX::Network::ClientReplicator::prepareJoinRxDataStats_::_1_::dtor$61
void __fastcall RBX::Network::ClientReplicator::prepareJoinRxDataStats_::_1_::dtor_61(__int64 a1, __int64 a2)
{
  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)(a2 + 3184)); /*0x1431e71a7*/
}

// Address: 0x1431e72b0 | Name: _RBX::Network::ClientReplicator::prepareJoinRxDataStats_::_1_::dtor$47
void __fastcall RBX::Network::ClientReplicator::prepareJoinRxDataStats_::_1_::dtor_47(__int64 a1, __int64 a2)
{
  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)(a2 + 2704)); /*0x1431e72b7*/
}

// Address: 0x1431e7470 | Name: _RBX::Network::ClientReplicator::prepareJoinRxDataStats_::_1_::dtor$67
void __fastcall RBX::Network::ClientReplicator::prepareJoinRxDataStats_::_1_::dtor_67(__int64 a1, __int64 a2)
{
  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)(a2 + 1832)); /*0x1431e7477*/
}

// Address: 0x1431e8270 | Name: _std::vector_RBX::Network::Replicator::AttributeVersionOverride_std::allocator_RBX::Network::Replicator::AttributeVersionOverride___::_Emplace_reallocate_std::basic_string_char_std::char_traits_char__std::allocator_char____const_&_unsigned_int__::_1_::dtor$1
void __fastcall std::vector_RBX::Network::Replicator::AttributeVersionOverride_std::allocator_RBX::Network::Replicator::AttributeVersionOverride___::_Emplace_reallocate_std::basic_string_char_std::char_traits_char__std::allocator_char____const___unsigned_int__::_1_::dtor_1(
        __int64 a1,
        __int64 a2)
{
  std::_Uninitialized_backout_al<std::allocator<std::pair<std::string,unsigned __int64>>>::~_Uninitialized_backout_al<std::allocator<std::pair<std::string,unsigned __int64>>>(this: (std::_Uninitialized_backout_al<std::allocator<cricket::SimulcastLayer> > *)(a2 + 80)); /*0x1431e8277*/
}

// Address: 0x1431e8280 | Name: _std::vector_RBX::Network::Replicator::AttributeVersionOverride_std::allocator_RBX::Network::Replicator::AttributeVersionOverride___::_Emplace_reallocate_std::basic_string_char_std::char_traits_char__std::allocator_char____const_&_unsigned_int__::_1_::catch$3
void __fastcall __noreturn std::vector_RBX::Network::Replicator::AttributeVersionOverride_std::allocator_RBX::Network::Replicator::AttributeVersionOverride___::_Emplace_reallocate_std::basic_string_char_std::char_traits_char__std::allocator_char____const___unsigned_int__::_1_::catch_3(
        __int64 a1,
        __int64 a2)
{
  std::vector<webm::Element<std::string>>::_Destroy( /*0x1431e829c*/
    this: *(std::vector<webrtc::rtclog::StreamConfig::Codec> **)(a2 + 160),
    _First: *(webrtc::rtclog::StreamConfig::Codec **)(a2 + 32),
    _Last: *(webrtc::rtclog::StreamConfig::Codec **)(a2 + 56));
  std::allocator<RBX::AsyncResult::Dependency>::deallocate( /*0x1431e82ad*/
    this: *(std::allocator<RBX::Graphics::TextureVulkan::PendingChange> **)(a2 + 72),
    _Ptr: *(RBX::Graphics::TextureVulkan::PendingChange *const *)(a2 + 64),
    _Count: *(_QWORD *)(a2 + 40));
  throw; /*0x1431e82b6*/
}

// Address: 0x1431e8310 | Name: _std::vector_RBX::Network::DeserializedNewInstanceItem_std::allocator_RBX::Network::DeserializedNewInstanceItem___::_Emplace_reallocate_RBX::Network::DeserializedNewInstanceItem__::_1_::dtor$0
void __fastcall std::vector_RBX::Network::DeserializedNewInstanceItem_std::allocator_RBX::Network::DeserializedNewInstanceItem___::_Emplace_reallocate_RBX::Network::DeserializedNewInstanceItem__::_1_::dtor_0(
        __int64 a1,
        std::_Uninitialized_backout_al<std::allocator<RBX::Network::DeserializedNewInstanceItem> > *a2)
{
  std::_Uninitialized_backout_al<std::allocator<RBX::Network::DeserializedNewInstanceItem>>::~_Uninitialized_backout_al<std::allocator<RBX::Network::DeserializedNewInstanceItem>>(this: a2 + 3); /*0x1431e8317*/
}

// Address: 0x1431e8320 | Name: _std::vector_RBX::Network::DeserializedNewInstanceItem_std::allocator_RBX::Network::DeserializedNewInstanceItem___::_Emplace_reallocate_RBX::Network::DeserializedNewInstanceItem__::_1_::catch$1
void __fastcall __noreturn std::vector_RBX::Network::DeserializedNewInstanceItem_std::allocator_RBX::Network::DeserializedNewInstanceItem___::_Emplace_reallocate_RBX::Network::DeserializedNewInstanceItem__::_1_::catch_1(
        __int64 a1,
        __int64 a2)
{
  std::vector<RBX::Network::DeserializedNewInstanceItem>::_Destroy( /*0x1431e833f*/
    this: *(std::vector<RBX::Network::DeserializedNewInstanceItem> **)(a2 + 160),
    _First: *(RBX::Network::DeserializedNewInstanceItem **)(a2 + 168),
    _Last: *(RBX::Network::DeserializedNewInstanceItem **)(a2 + 48));
  std::allocator<RBX::PostMidPhaseBuffer>::deallocate( /*0x1431e8353*/
    this: *(std::allocator<webm::Element<webm::ChapterAtom> > **)(a2 + 64),
    _Ptr: *(webm::Element<webm::ChapterAtom> *const *)(a2 + 56),
    _Count: *(_QWORD *)(a2 + 184));
  throw; /*0x1431e835c*/
}

// Address: 0x1431e83f0 | Name: _boost::unordered::detail::table_impl_boost::unordered::detail::map_std::allocator_std::pair_unsigned_int_const__RBX::Network::DeserializedNewInstanceItem____unsigned_int_RBX::Network::DeserializedNewInstanceItem_boost::hash_unsigned_int__std::equal_to_unsigned_int_____::emplace_impl_unsigned_int_&_RBX::Network::DeserializedNewInstanceItem__::_1_::dtor$0
void __fastcall boost::unordered::detail::table_impl_boost::unordered::detail::map_std::allocator_std::pair_unsigned_int_const__RBX::Network::DeserializedNewInstanceItem____unsigned_int_RBX::Network::DeserializedNewInstanceItem_boost::hash_unsigned_int__std::equal_to_unsigned_int_____::emplace_impl_unsigned_int___RBX::Network::DeserializedNewInstanceItem__::_1_::dtor_0(
        __int64 a1,
        __int64 a2)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<unsigned int const,RBX::Network::DeserializedNewInstanceItem>>>>::~node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<unsigned int const,RBX::Network::DeserializedNewInstanceItem>>>>(this: (boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<unsigned int const ,RBX::Network::DeserializedNewInstanceItem> > > > *)(a2 + 32)); /*0x1431e83f7*/
}

// Address: 0x1431e8420 | Name: _RBX::Network::Replicator::schemaReadValue_RBX::Network::InstanceValueSetter__::_1_::dtor$10
void __fastcall RBX::Network::Replicator::schemaReadValue_RBX::Network::InstanceValueSetter__::_1_::dtor_10(
        __int64 a1,
        RBX::OptionalCoordinateFrame *a2)
{
  RBX::OptionalCoordinateFrame::~OptionalCoordinateFrame(this: a2 + 61); /*0x1431e8427*/
}

// Address: 0x1431e8480 | Name: _RBX::Network::Replicator::schemaReadValue_RBX::Network::InstanceValueSetter__::_1_::dtor$40
void __fastcall RBX::Network::Replicator::schemaReadValue_RBX::Network::InstanceValueSetter__::_1_::dtor_40(
        __int64 a1,
        __int64 a2)
{
  RBX::Text::FontInfo::~FontInfo(this: (RBX::Text::FontInfo *)(a2 + 288)); /*0x1431e8487*/
}

// Address: 0x1431e8490 | Name: _RBX::Network::Replicator::schemaReadValue_RBX::Network::VariantValueSetter__::_1_::dtor$5
void __fastcall RBX::Network::Replicator::schemaReadValue_RBX::Network::VariantValueSetter__::_1_::dtor_5(
        __int64 a1,
        __int64 a2)
{
  RBX::ProtectedString::~ProtectedString(this: (RBX::Scripting::DebuggerEvalExpression *)(a2 + 304)); /*0x1431e8497*/
}

// Address: 0x1431e84a0 | Name: _RBX::Network::Replicator::schemaReadValue_RBX::Network::VariantValueSetter__::_1_::dtor$10
void __fastcall RBX::Network::Replicator::schemaReadValue_RBX::Network::VariantValueSetter__::_1_::dtor_10(
        __int64 a1,
        RBX::OptionalCoordinateFrame *a2)
{
  RBX::OptionalCoordinateFrame::~OptionalCoordinateFrame(this: a2 + 81); /*0x1431e84a7*/
}

// Address: 0x1431e84d0 | Name: _RBX::Network::Replicator::schemaReadValue_RBX::Network::VariantValueSetter__::_1_::dtor$19
void __fastcall RBX::Network::Replicator::schemaReadValue_RBX::Network::VariantValueSetter__::_1_::dtor_19(
        __int64 a1,
        __int64 a2)
{
  operator delete(ptr: *(void **)(a2 + 648)); /*0x1431e84e5*/
}

// Address: 0x1431e8510 | Name: _RBX::Network::Replicator::schemaReadValue_RBX::Network::VariantValueSetter__::_1_::dtor$40
void __fastcall RBX::Network::Replicator::schemaReadValue_RBX::Network::VariantValueSetter__::_1_::dtor_40(
        __int64 a1,
        __int64 a2)
{
  RBX::Text::FontInfo::~FontInfo(this: (RBX::Text::FontInfo *)(a2 + 368)); /*0x1431e8517*/
}

// Address: 0x1431e8520 | Name: _RBX::Network::Replicator::schemaWriteValue_RBX::Network::InstanceValueGetter__::_1_::dtor$8
void __fastcall RBX::Network::Replicator::schemaWriteValue_RBX::Network::InstanceValueGetter__::_1_::dtor_8(
        __int64 a1,
        __int64 a2)
{
  RBX::ProtectedString::~ProtectedString(this: (RBX::Scripting::DebuggerEvalExpression *)(a2 + 184)); /*0x1431e8527*/
}

// Address: 0x1431e8530 | Name: _RBX::Network::Replicator::schemaWriteValue_RBX::Network::GuidDataValueGetter__::_1_::dtor$2
void __fastcall RBX::Network::Replicator::schemaWriteValue_RBX::Network::GuidDataValueGetter__::_1_::dtor_2(
        __int64 a1,
        __int64 a2)
{
  if ( (*(_DWORD *)(a2 + 528) & 1) != 0 ) /*0x1431e8544*/
  {
    *(_DWORD *)(a2 + 528) &= ~1u; /*0x1431e8546*/
    RBX::SharedString::~SharedString(this: (RBX::SharedString *)(a2 + 80)); /*0x1431e8551*/
  }
}

// Address: 0x1431e8560 | Name: _RBX::Network::Replicator::schemaWriteValue_RBX::Network::GuidDataValueGetter__::_1_::dtor$14
void __fastcall RBX::Network::Replicator::schemaWriteValue_RBX::Network::GuidDataValueGetter__::_1_::dtor_14(
        __int64 a1,
        RBX::OptionalCoordinateFrame *a2)
{
  RBX::OptionalCoordinateFrame::~OptionalCoordinateFrame(this: a2 + 72); /*0x1431e8567*/
}

// Address: 0x1431e8580 | Name: _RBX::Network::Replicator::schemaWriteValue_RBX::Network::GuidDataValueGetter__::_1_::dtor$30
void __fastcall RBX::Network::Replicator::schemaWriteValue_RBX::Network::GuidDataValueGetter__::_1_::dtor_30(
        __int64 a1,
        __int64 a2)
{
  RBX::Text::FontInfo::~FontInfo(this: (RBX::Text::FontInfo *)(a2 + 280)); /*0x1431e8587*/
}

// Address: 0x1431e8590 | Name: _RBX::Network::Replicator::schemaWriteValue_RBX::Network::InstanceValueGetter__::_1_::dtor$2
void __fastcall RBX::Network::Replicator::schemaWriteValue_RBX::Network::InstanceValueGetter__::_1_::dtor_2(
        __int64 a1,
        __int64 a2)
{
  if ( (*(_DWORD *)(a2 + 608) & 1) != 0 ) /*0x1431e85a4*/
  {
    *(_DWORD *)(a2 + 608) &= ~1u; /*0x1431e85a6*/
    RBX::SharedString::~SharedString(this: (RBX::SharedString *)(a2 + 80)); /*0x1431e85b1*/
  }
}

// Address: 0x1431e85c0 | Name: _RBX::Network::Replicator::schemaWriteValue_RBX::Network::InstanceValueGetter__::_1_::dtor$14
void __fastcall RBX::Network::Replicator::schemaWriteValue_RBX::Network::InstanceValueGetter__::_1_::dtor_14(
        __int64 a1,
        RBX::OptionalCoordinateFrame *a2)
{
  RBX::OptionalCoordinateFrame::~OptionalCoordinateFrame(this: a2 + 82); /*0x1431e85c7*/
}

// Address: 0x1431e85d0 | Name: _RBX::Network::Replicator::schemaWriteValue_RBX::Network::VariantValueGetter__::_1_::dtor$21
void __fastcall RBX::Network::Replicator::schemaWriteValue_RBX::Network::VariantValueGetter__::_1_::dtor_21(
        __int64 a1,
        RBX::SharedString *a2)
{
  RBX::SharedString::~SharedString(this: a2 + 7); /*0x1431e85d7*/
}

// Address: 0x1431e85e0 | Name: _RBX::Network::Replicator::schemaWriteValue_RBX::Network::InstanceValueGetter__::_1_::dtor$30
void __fastcall RBX::Network::Replicator::schemaWriteValue_RBX::Network::InstanceValueGetter__::_1_::dtor_30(
        __int64 a1,
        __int64 a2)
{
  RBX::Text::FontInfo::~FontInfo(this: (RBX::Text::FontInfo *)(a2 + 328)); /*0x1431e85e7*/
}

// Address: 0x1431e85f0 | Name: _RBX::Network::Replicator::schemaWriteValue_RBX::Network::VariantValueGetter__::_1_::dtor$2
void __fastcall RBX::Network::Replicator::schemaWriteValue_RBX::Network::VariantValueGetter__::_1_::dtor_2(
        __int64 a1,
        __int64 a2)
{
  if ( (*(_DWORD *)(a2 + 544) & 1) != 0 ) /*0x1431e8604*/
  {
    *(_DWORD *)(a2 + 544) &= ~1u; /*0x1431e8606*/
    RBX::SharedString::~SharedString(this: (RBX::SharedString *)(a2 + 80)); /*0x1431e8611*/
  }
}

// Address: 0x1431e8630 | Name: _RBX::Network::Replicator::schemaWriteValue_RBX::Network::VariantValueGetter__::_1_::dtor$28
void __fastcall RBX::Network::Replicator::schemaWriteValue_RBX::Network::VariantValueGetter__::_1_::dtor_28(
        __int64 a1,
        __int64 a2)
{
  RBX::Text::FontInfo::~FontInfo(this: (RBX::Text::FontInfo *)(a2 + 272)); /*0x1431e8637*/
}

// Address: 0x1431e8650 | Name: _RBX::Network::CachedBitstream::CachedBitstream_::_1_::dtor$0
void __fastcall RBX::Network::CachedBitstream::CachedBitstream_::_1_::dtor_0(__int64 a1, __int64 a2)
{
  boost::mutex::~mutex(this: (boost::mutex *)(*(_QWORD *)(a2 + 48) + 8LL)); /*0x1431e865b*/
}

// Address: 0x1431e8660 | Name: _RBX::Network::Replicator::ClusterReplicationData::ClusterReplicationData_::_1_::dtor$0
void __fastcall RBX::Network::Replicator::ClusterReplicationData::ClusterReplicationData_::_1_::dtor_0(
        __int64 a1,
        __int64 a2)
{
  RBX::UnboundedCircularBuffer<RakNet::Packet *>::~UnboundedCircularBuffer<RakNet::Packet *>(this: *(RBX::UnboundedCircularBuffer<RBX::Time> **)(a2 + 48)); /*0x1431e8667*/
}

// Address: 0x1431e8670 | Name: _RBX::Network::Replicator::ClusterReplicationData::ClusterReplicationData_::_1_::dtor$4
void __fastcall RBX::Network::Replicator::ClusterReplicationData::ClusterReplicationData_::_1_::dtor_4(
        __int64 a1,
        __int64 a2)
{
  std::list<std::pair<RBX::Vector3int32 const,std::vector<RBX::Voxel2::Region>>>::~list<std::pair<RBX::Vector3int32 const,std::vector<RBX::Voxel2::Region>>>(this: (std::list<std::pair<RBX::Vector3int32 const ,std::vector<RBX::Voxel2::Region> >> *)(*(_QWORD *)(a2 + 56) + 8LL)); /*0x1431e867b*/
}

// Address: 0x1431e8680 | Name: _RBX::Network::DeserializePacketsJob::DeserializePacketsJob_::_1_::dtor$2
void __fastcall RBX::Network::DeserializePacketsJob::DeserializePacketsJob_::_1_::dtor_2(__int64 a1, __int64 a2)
{
  RBX::TaskScheduler::Job::~Job(this: *(RBX::TaskScheduler::Job **)(a2 + 144)); /*0x1431e8687*/
}

// Address: 0x1431e8690 | Name: _RBX::Network::DeserializePacketsJob::DeserializePacketsJob_::_1_::dtor$3
void __fastcall RBX::Network::DeserializePacketsJob::DeserializePacketsJob_::_1_::dtor_3(__int64 a1, __int64 a2)
{
  std::recursive_mutex::~recursive_mutex(this: (RBX::InstrumentedMutex<std::mutex> *)(*(_QWORD *)(a2 + 144) + 328LL)); /*0x1431e869e*/
}

// Address: 0x1431e86b0 | Name: _RBX::Network::DeserializePacketsJob::DeserializePacketsJob_::_1_::dtor$4
void __fastcall RBX::Network::DeserializePacketsJob::DeserializePacketsJob_::_1_::dtor_4(__int64 a1, __int64 a2)
{
  std::vector<Luau::AstExpr *>::~vector<Luau::AstExpr *>(this: (std::vector<RBX::Graphics::FramebufferVulkan *> *)(*(_QWORD *)(a2 + 144) + 408LL)); /*0x1431e86be*/
}

// Address: 0x1431e86d0 | Name: _RBX::Network::DeserializePacketsJob::DeserializePacketsJob_::_1_::dtor$5
void __fastcall RBX::Network::DeserializePacketsJob::DeserializePacketsJob_::_1_::dtor_5(__int64 a1, __int64 a2)
{
  RBX::UnboundedCircularBuffer<RakNet::Packet *>::~UnboundedCircularBuffer<RakNet::Packet *>(this: (RBX::UnboundedCircularBuffer<RBX::Time> *)(*(_QWORD *)(a2 + 144) + 432LL)); /*0x1431e86de*/
}

// Address: 0x1431e86f0 | Name: _RBX::Network::DeserializePacketsJob::DeserializePacketsJob_::_1_::dtor$6
void __fastcall RBX::Network::DeserializePacketsJob::DeserializePacketsJob_::_1_::dtor_6(__int64 a1, __int64 a2)
{
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)(*(_QWORD *)(a2 + 144) + 464LL)); /*0x1431e86fe*/
}

// Address: 0x1431e8710 | Name: _RBX::Network::DeserializePacketsJob::DeserializePacketsJob_::_1_::dtor$7
void __fastcall RBX::Network::DeserializePacketsJob::DeserializePacketsJob_::_1_::dtor_7(__int64 a1, __int64 a2)
{
  rbx::implementation::timestamped_safe_queue_item<RBX::Network::ProcessingPacket>::~timestamped_safe_queue_item<RBX::Network::ProcessingPacket>(this: (RBX::Network::ProcessingPacket *)(*(_QWORD *)(a2 + 144) + 536LL)); /*0x1431e871e*/
}

// Address: 0x1431e8730 | Name: _RBX::Network::DeserializePacketsJob::DeserializePacketsJob_::_1_::dtor$8
void __fastcall RBX::Network::DeserializePacketsJob::DeserializePacketsJob_::_1_::dtor_8(__int64 a1, __int64 a2)
{
  RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::~DeserializingJoinDataItemV2(this: (RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2 *)(*(_QWORD *)(a2 + 144) + 608LL)); /*0x1431e873e*/
}

// Address: 0x1431e8750 | Name: _RBX::Network::DeserializedNewInstanceItem::DeserializedNewInstanceItem_::_1_::dtor$0
void __fastcall RBX::Network::DeserializedNewInstanceItem::DeserializedNewInstanceItem_::_1_::dtor_0(
        __int64 a1,
        __int64 a2)
{
  RBX::Network::DeserializedItem::~DeserializedItem(this: *(RBX::Network::DeserializedItem **)(a2 + 112)); /*0x1431e8757*/
}

// Address: 0x1431e8760 | Name: _RBX::Network::DeserializedNewInstanceItem::DeserializedNewInstanceItem_::_1_::dtor$1
void __fastcall RBX::Network::DeserializedNewInstanceItem::DeserializedNewInstanceItem_::_1_::dtor_1(
        __int64 a1,
        __int64 a2)
{
  std::vector<RBX::Network::PropValuePair>::~vector<RBX::Network::PropValuePair>(this: (std::vector<RBX::Network::PropValuePair> *)(*(_QWORD *)(a2 + 112) + 24LL)); /*0x1431e876b*/
}

// Address: 0x1431e8770 | Name: _RBX::Network::DeserializedNewInstanceItem::DeserializedNewInstanceItem_::_1_::dtor$5
void __fastcall RBX::Network::DeserializedNewInstanceItem::DeserializedNewInstanceItem_::_1_::dtor_5(
        __int64 a1,
        std::_Tidy_guard<std::vector<RBX::Network::PropValuePair> > *a2)
{
  std::_Tidy_guard<std::vector<RBX::Network::PropValuePair>>::~_Tidy_guard<std::vector<RBX::Network::PropValuePair>>(this: a2 + 15); /*0x1431e8777*/
}

// Address: 0x1431e8780 | Name: _std::vector_RBX::Network::PropValuePair_std::allocator_RBX::Network::PropValuePair___::_Umove_if_noexcept_::_1_::dtor$0
void __fastcall std::vector_RBX::Network::PropValuePair_std::allocator_RBX::Network::PropValuePair___::_Umove_if_noexcept_::_1_::dtor_0(
        __int64 a1,
        __int64 a2)
{
  std::_Uninitialized_backout_al<std::allocator<RBX::Network::PropValuePair>>::~_Uninitialized_backout_al<std::allocator<RBX::Network::PropValuePair>>(this: (std::_Uninitialized_backout_al<std::allocator<RBX::Network::PropValuePair> > *)(a2 + 32)); /*0x1431e8787*/
}

// Address: 0x1431e8790 | Name: _RBX::Network::JoinRxStats::JoinRxStats_::_1_::dtor$0
void __fastcall RBX::Network::JoinRxStats::JoinRxStats_::_1_::dtor_0(__int64 a1, __int64 a2)
{
  std::vector<std::pair<float,std::shared_ptr<RBX::ProximityPrompt>>>::_Tidy(this: (std::vector<std::pair<enum RBX::CurveAnimationChannel,std::shared_ptr<RBX::Instance> >> *)(*(_QWORD *)(a2 + 48) + 344LL)); /*0x1431e879e*/
}

// Address: 0x1431e87b0 | Name: _RBX::Network::JoinRxStats::JoinRxStats_::_1_::dtor$1
void __fastcall RBX::Network::JoinRxStats::JoinRxStats_::_1_::dtor_1(__int64 a1, __int64 a2)
{
  RBX::DenseSet<RBX::Soundscape::NonBlockingFmodSoundLoader *,RBX::DenseMapInfo<RBX::Soundscape::NonBlockingFmodSoundLoader *>>::~DenseSet<RBX::Soundscape::NonBlockingFmodSoundLoader *,RBX::DenseMapInfo<RBX::Soundscape::NonBlockingFmodSoundLoader *>>(this: (AP4_BitWriter *)(*(_QWORD *)(a2 + 48) + 368LL)); /*0x1431e87be*/
}

// Address: 0x1431e87d0 | Name: _RBX::Network::JoinRxStats::JoinRxStats_::_1_::dtor$2
void __fastcall RBX::Network::JoinRxStats::JoinRxStats_::_1_::dtor_2(__int64 a1, __int64 a2)
{
  RBX::DenseSet<RBX::Soundscape::NonBlockingFmodSoundLoader *,RBX::DenseMapInfo<RBX::Soundscape::NonBlockingFmodSoundLoader *>>::~DenseSet<RBX::Soundscape::NonBlockingFmodSoundLoader *,RBX::DenseMapInfo<RBX::Soundscape::NonBlockingFmodSoundLoader *>>(this: (AP4_BitWriter *)(*(_QWORD *)(a2 + 48) + 392LL)); /*0x1431e87de*/
}

// Address: 0x1431e87f0 | Name: _RBX::Network::JoinRxStats::JoinRxStats_::_1_::dtor$3
void __fastcall RBX::Network::JoinRxStats::JoinRxStats_::_1_::dtor_3(__int64 a1, __int64 a2)
{
  std::unordered_map<std::string,RBX::DenseMap<RBX::Reflection::ClassDescriptor const *,unsigned int,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const *>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,unsigned int>>>::~unordered_map<std::string,RBX::DenseMap<RBX::Reflection::ClassDescriptor const *,unsigned int,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const *>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,unsigned int>>>(this: (std::unordered_map<std::string,RBX::DenseMap<RBX::Reflection::ClassDescriptor const *,unsigned int,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const *>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,unsigned int> >> *)(*(_QWORD *)(a2 + 48) + 416LL)); /*0x1431e87fe*/
}

// Address: 0x1431e8810 | Name: _RBX::Network::JoinRxStats::JoinRxStats_::_1_::dtor$4
void __fastcall RBX::Network::JoinRxStats::JoinRxStats_::_1_::dtor_4(__int64 a1, __int64 a2)
{
  RBX::DenseSet<RBX::Soundscape::NonBlockingFmodSoundLoader *,RBX::DenseMapInfo<RBX::Soundscape::NonBlockingFmodSoundLoader *>>::~DenseSet<RBX::Soundscape::NonBlockingFmodSoundLoader *,RBX::DenseMapInfo<RBX::Soundscape::NonBlockingFmodSoundLoader *>>(this: (AP4_BitWriter *)(*(_QWORD *)(a2 + 48) + 480LL)); /*0x1431e881e*/
}

// Address: 0x1431e8830 | Name: _RBX::Network::JoinRxStats::JoinRxStats_::_1_::dtor$5
void __fastcall RBX::Network::JoinRxStats::JoinRxStats_::_1_::dtor_5(__int64 a1, __int64 a2)
{
  std::vector<rbx::signals::scoped_connection>::~vector<rbx::signals::scoped_connection>(this: (std::vector<rbx::signals::scoped_connection> *)(*(_QWORD *)(a2 + 48) + 504LL)); /*0x1431e883e*/
}

// Address: 0x1431e8850 | Name: _RBX::Network::JoinRxStats::JoinRxStats_::_1_::dtor$8
void __fastcall RBX::Network::JoinRxStats::JoinRxStats_::_1_::dtor_8(__int64 a1, __int64 a2)
{
  std::list<std::pair<std::string const,RBX::DenseMap<RBX::Reflection::ClassDescriptor const *,unsigned int,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const *>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,unsigned int>>>>::~list<std::pair<std::string const,RBX::DenseMap<RBX::Reflection::ClassDescriptor const *,unsigned int,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const *>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,unsigned int>>>>(this: (std::list<std::pair<std::string const ,RBX::DenseMap<RBX::Reflection::ClassDescriptor const *,unsigned int,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const *>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,unsigned int> > >> *)(*(_QWORD *)(a2 + 56) + 8LL)); /*0x1431e885b*/
}

// Address: 0x1431e8860 | Name: _RBX::Network::OngoingBandwidthStats::OngoingBandwidthStats_::_1_::dtor$0
void __fastcall RBX::Network::OngoingBandwidthStats::OngoingBandwidthStats_::_1_::dtor_0(__int64 a1, __int64 a2)
{
  std::vector<Luau::Location>::~vector<Luau::Location>(this: *(RBX::DenseHashMap<RBX::Graphics::ShaderProgram *,VkPipeline_T *,boost::hash<RBX::Graphics::ShaderProgram *>,std::equal_to<RBX::Graphics::ShaderProgram *> > **)(a2 + 48)); /*0x1431e8867*/
}

// Address: 0x1431e8870 | Name: _RBX::Network::OngoingBandwidthStats::OngoingBandwidthStats_::_1_::dtor$1
void __fastcall RBX::Network::OngoingBandwidthStats::OngoingBandwidthStats_::_1_::dtor_1(__int64 a1, __int64 a2)
{
  std::vector<Luau::Location>::~vector<Luau::Location>(this: (RBX::DenseHashMap<RBX::Graphics::ShaderProgram *,VkPipeline_T *,boost::hash<RBX::Graphics::ShaderProgram *>,std::equal_to<RBX::Graphics::ShaderProgram *> > *)(*(_QWORD *)(a2 + 48) + 48LL)); /*0x1431e887b*/
}

// Address: 0x1431e8890 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$0
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_0(__int64 a1, __int64 a2)
{
  rbx::signals::slot_with_functor<RBX::Reflection::ConnectGenericHelper<rbx::signal<void (enum RBX::MaterialType)>>,enum RBX::MaterialType>::do_dtor(this: *(std::_Binder<std::_Unforced,void (__cdecl RBX::NavigationDebugDraw::*)(dtNavMesh *,RBX::Extents),std::shared_ptr<RBX::NavigationDebugDraw> &,std::_Ph<1> const &,RBX::Extents &> **)(a2 + 424)); /*0x1431e8897*/
}

// Address: 0x1431e88a0 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$1
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_1(__int64 a1, __int64 a2)
{
  RBX::Described<RBX::Network::Replicator,RBX::Network::IdSerializer>::~Described<RBX::Network::Replicator,RBX::Network::IdSerializer>(this: *(RBX::Network::IdSerializer **)(a2 + 416)); /*0x1431e88a7*/
}

// Address: 0x1431e88b0 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$2
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_2(__int64 a1, __int64 a2)
{
  RBX::IMetric::~IMetric(this: (RBX::IMetric *)(*(_QWORD *)(a2 + 416) + 256LL)); /*0x1431e88be*/
}

// Address: 0x1431e88d0 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$3
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_3(__int64 a1, __int64 a2)
{
  RBX::Voxel2::GridListener::~GridListener(this: (RBX::Voxel2::GridListener *)(*(_QWORD *)(a2 + 416) + 264LL)); /*0x1431e88de*/
}

// Address: 0x1431e88f0 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$4
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_4(__int64 a1, __int64 a2)
{
  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)(*(_QWORD *)(a2 + 416) /*0x1431e88fe*/
                                                                                                + 272LL));
}

// Address: 0x1431e8910 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$5
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_5(__int64 a1, __int64 a2)
{
  RBX::Network::ReplicatorStats::~ReplicatorStats( /*0x1431e891e*/
    this: (RBX::Network::ReplicatorStats *)(*(_QWORD *)(a2 + 416) + 336LL),
    a2);
}

// Address: 0x1431e8930 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$6
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_6(__int64 a1, __int64 a2)
{
  RBX::Network::JoinDiagnosticStats_DEPRECATED::~JoinDiagnosticStats_DEPRECATED(this: (RBX::Network::JoinDiagnosticStats_DEPRECATED *)(*(_QWORD *)(a2 + 416) + 7168LL)); /*0x1431e893e*/
}

// Address: 0x1431e8950 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$7
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_7(__int64 a1, __int64 a2)
{
  RBX::Network::OngoingBandwidthStats::~OngoingBandwidthStats(this: (RBX::Network::OngoingBandwidthStats *)(*(_QWORD *)(a2 + 416) + 7248LL)); /*0x1431e895e*/
}

// Address: 0x1431e8970 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$8
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_8(__int64 a1, __int64 a2)
{
  RBX::Network::OngoingBandwidthStats::~OngoingBandwidthStats(this: (RBX::Network::OngoingBandwidthStats *)(*(_QWORD *)(a2 + 416) + 7424LL)); /*0x1431e897e*/
}

// Address: 0x1431e8990 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$9
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_9(__int64 a1, __int64 a2)
{
  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)(*(_QWORD *)(a2 + 416) /*0x1431e899e*/
                                                                                                + 7608LL));
}

// Address: 0x1431e89b0 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$10
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_10(__int64 a1, __int64 a2)
{
  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)(*(_QWORD *)(a2 + 416) /*0x1431e89be*/
                                                                                                + 7632LL));
}

// Address: 0x1431e89d0 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$11
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_11(__int64 a1, __int64 a2)
{
  std::vector<Luau::Location>::~vector<Luau::Location>(this: (RBX::DenseHashMap<RBX::Graphics::ShaderProgram *,VkPipeline_T *,boost::hash<RBX::Graphics::ShaderProgram *>,std::equal_to<RBX::Graphics::ShaderProgram *> > *)(*(_QWORD *)(a2 + 416) + 7688LL)); /*0x1431e89de*/
}

// Address: 0x1431e89f0 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$12
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_12(__int64 a1, __int64 a2)
{
  std::vector<RBX::Network::Replicator::MotorAnglesPerPrimitive>::~vector<RBX::Network::Replicator::MotorAnglesPerPrimitive>(this: (std::vector<RBX::Network::Replicator::MotorAnglesPerPrimitive> *)(*(_QWORD *)(a2 + 416) + 7712LL)); /*0x1431e89fe*/
}

// Address: 0x1431e8a10 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$13
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_13(__int64 a1, __int64 a2)
{
  rbx::signal<void (std::string,std::string,std::string,std::string)>::~signal<void (std::string,std::string,std::string,std::string)>(this: (rbx::signal<void __cdecl(PluginReference)> *)(*(_QWORD *)(a2 + 416) + 7784LL)); /*0x1431e8a1e*/
}

// Address: 0x1431e8a30 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$14
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_14(__int64 a1, __int64 a2)
{
  rbx::signal<void (std::string,std::string,std::string,std::string)>::~signal<void (std::string,std::string,std::string,std::string)>(this: (rbx::signal<void __cdecl(PluginReference)> *)(*(_QWORD *)(a2 + 416) + 7808LL)); /*0x1431e8a3e*/
}

// Address: 0x1431e8a50 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$15
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_15(__int64 a1, __int64 a2)
{
  rbx::signal<void (std::string,std::string,std::string,std::string)>::~signal<void (std::string,std::string,std::string,std::string)>(this: (rbx::signal<void __cdecl(PluginReference)> *)(*(_QWORD *)(a2 + 416) + 7832LL)); /*0x1431e8a5e*/
}

// Address: 0x1431e8a70 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$16
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_16(__int64 a1, __int64 a2)
{
  rbx::implementation::timestamped_safe_queue_item<RBX::Network::ProcessingPacket>::~timestamped_safe_queue_item<RBX::Network::ProcessingPacket>(this: (RBX::Network::ProcessingPacket *)(*(_QWORD *)(a2 + 416) + 7856LL)); /*0x1431e8a7e*/
}

// Address: 0x1431e8a90 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$17
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_17(__int64 a1, __int64 a2)
{
  rbx::implementation::timestamped_safe_queue_item<RBX::Network::ProcessingPacket>::~timestamped_safe_queue_item<RBX::Network::ProcessingPacket>(this: (RBX::Network::ProcessingPacket *)(*(_QWORD *)(a2 + 416) + 7904LL)); /*0x1431e8a9e*/
}

// Address: 0x1431e8ab0 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$18
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_18(__int64 a1, __int64 a2)
{
  std::unique_ptr<RBX::AutoMemPool>::~unique_ptr<RBX::AutoMemPool>(this: (std::unique_ptr<RBX::AutoMemPool> *)(*(_QWORD *)(a2 + 416) + 7968LL)); /*0x1431e8abe*/
}

// Address: 0x1431e8ad0 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$19
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_19(__int64 a1, __int64 a2)
{
  std::unique_ptr<RBX::AutoMemPool>::~unique_ptr<RBX::AutoMemPool>(this: (std::unique_ptr<RBX::AutoMemPool> *)(*(_QWORD *)(a2 + 416) + 7976LL)); /*0x1431e8ade*/
}

// Address: 0x1431e8af0 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$20
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_20(__int64 a1, __int64 a2)
{
  std::unique_ptr<RBX::AutoMemPool>::~unique_ptr<RBX::AutoMemPool>(this: (std::unique_ptr<RBX::AutoMemPool> *)(*(_QWORD *)(a2 + 416) + 7984LL)); /*0x1431e8afe*/
}

// Address: 0x1431e8b10 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$21
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_21(__int64 a1, __int64 a2)
{
  std::unique_ptr<RBX::AutoMemPool>::~unique_ptr<RBX::AutoMemPool>(this: (std::unique_ptr<RBX::AutoMemPool> *)(*(_QWORD *)(a2 + 416) + 7992LL)); /*0x1431e8b1e*/
}

// Address: 0x1431e8b30 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$22
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_22(__int64 a1, __int64 a2)
{
  std::unique_ptr<RBX::AutoMemPool>::~unique_ptr<RBX::AutoMemPool>(this: (std::unique_ptr<RBX::AutoMemPool> *)(*(_QWORD *)(a2 + 416) + 8000LL)); /*0x1431e8b3e*/
}

// Address: 0x1431e8b50 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$23
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_23(__int64 a1, __int64 a2)
{
  std::unique_ptr<RBX::AutoMemPool>::~unique_ptr<RBX::AutoMemPool>(this: (std::unique_ptr<RBX::AutoMemPool> *)(*(_QWORD *)(a2 + 416) + 8008LL)); /*0x1431e8b5e*/
}

// Address: 0x1431e8b70 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$24
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_24(__int64 a1, __int64 a2)
{
  std::unique_ptr<RBX::AutoMemPool>::~unique_ptr<RBX::AutoMemPool>(this: (std::unique_ptr<RBX::AutoMemPool> *)(*(_QWORD *)(a2 + 416) + 8016LL)); /*0x1431e8b7e*/
}

// Address: 0x1431e8b90 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$25
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_25(__int64 a1, __int64 a2)
{
  std::unique_ptr<RBX::AutoMemPool>::~unique_ptr<RBX::AutoMemPool>(this: (std::unique_ptr<RBX::AutoMemPool> *)(*(_QWORD *)(a2 + 416) + 8024LL)); /*0x1431e8b9e*/
}

// Address: 0x1431e8bb0 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$26
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_26(__int64 a1, __int64 a2)
{
  std::unique_ptr<RBX::AutoMemPool>::~unique_ptr<RBX::AutoMemPool>(this: (std::unique_ptr<RBX::AutoMemPool> *)(*(_QWORD *)(a2 + 416) + 8032LL)); /*0x1431e8bbe*/
}

// Address: 0x1431e8bd0 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$27
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_27(__int64 a1, __int64 a2)
{
  std::unique_ptr<RBX::AutoMemPool>::~unique_ptr<RBX::AutoMemPool>(this: (std::unique_ptr<RBX::AutoMemPool> *)(*(_QWORD *)(a2 + 416) + 8040LL)); /*0x1431e8bde*/
}

// Address: 0x1431e8bf0 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$28
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_28(__int64 a1, __int64 a2)
{
  boost::unordered::unordered_set<std::string,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::string>>::~unordered_set<std::string,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::string>>(this: (boost::unordered::unordered_set<std::string,boost::hash<std::string >,std::equal_to<std::string >,std::allocator<std::string > > *)(*(_QWORD *)(a2 + 416) + 8304LL)); /*0x1431e8bfe*/
}

// Address: 0x1431e8c10 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$29
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_29(__int64 a1, __int64 a2)
{
  std::unique_ptr<RBX::Network::StrictNetworkFilter>::~unique_ptr<RBX::Network::StrictNetworkFilter>(this: (std::unique_ptr<RBX::Network::StrictNetworkFilter> *)(*(_QWORD *)(a2 + 416) + 8352LL)); /*0x1431e8c1e*/
}

// Address: 0x1431e8c30 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$30
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_30(__int64 a1, __int64 a2)
{
  RBX::Network::Replicator::ClusterReplicationData::~ClusterReplicationData(this: (RBX::Network::Replicator::ClusterReplicationData *)(*(_QWORD *)(a2 + 416) + 8368LL)); /*0x1431e8c3e*/
}

// Address: 0x1431e8c50 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$31
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_31(__int64 a1, __int64 a2)
{
  rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)(*(_QWORD *)(a2 + 416) /*0x1431e8c5e*/
                                                                                          + 8464LL));
}

// Address: 0x1431e8c70 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$32
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_32(__int64 a1, __int64 a2)
{
  RBX::Network::NetworkBandwidthManager::~NetworkBandwidthManager(this: (RBX::Network::NetworkBandwidthManager *)(*(_QWORD *)(a2 + 416) + 8472LL)); /*0x1431e8c7e*/
}

// Address: 0x1431e8c90 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$33
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_33(__int64 a1, __int64 a2)
{
  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)(*(_QWORD *)(a2 + 416) /*0x1431e8c9e*/
                                                                                                + 10032LL));
}

// Address: 0x1431e8cb0 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$34
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_34(__int64 a1, __int64 a2)
{
  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)(*(_QWORD *)(a2 + 416) /*0x1431e8cbe*/
                                                                                                + 10048LL));
}

// Address: 0x1431e8cd0 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$35
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_35(__int64 a1, __int64 a2)
{
  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)(*(_QWORD *)(a2 + 416) /*0x1431e8cde*/
                                                                                                + 10064LL));
}

// Address: 0x1431e8cf0 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$36
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_36(__int64 a1, __int64 a2)
{
  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)(*(_QWORD *)(a2 + 416) /*0x1431e8cfe*/
                                                                                                + 10080LL));
}

// Address: 0x1431e8d10 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$37
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_37(__int64 a1, __int64 a2)
{
  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)(*(_QWORD *)(a2 + 416) /*0x1431e8d1e*/
                                                                                                + 10096LL));
}

// Address: 0x1431e8d30 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$38
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_38(__int64 a1, __int64 a2)
{
  RBX::Network::ItemQueue::~ItemQueue(this: (RBX::Network::ItemQueue *)(*(_QWORD *)(a2 + 416) + 10112LL)); /*0x1431e8d3e*/
}

// Address: 0x1431e8d50 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$39
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_39(__int64 a1, __int64 a2)
{
  RBX::Network::ItemQueue::~ItemQueue(this: (RBX::Network::ItemQueue *)(*(_QWORD *)(a2 + 416) + 10160LL)); /*0x1431e8d5e*/
}

// Address: 0x1431e8d70 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$40
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_40(__int64 a1, __int64 a2)
{
  std::unordered_map<std::pair<RBX::Vector3,unsigned int>,RBX::Vector3,RBX::PositionColorHash,std::equal_to<std::pair<RBX::Vector3,unsigned int>>,std::allocator<std::pair<std::pair<RBX::Vector3,unsigned int> const,RBX::Vector3>>>::~unordered_map<std::pair<RBX::Vector3,unsigned int>,RBX::Vector3,RBX::PositionColorHash,std::equal_to<std::pair<RBX::Vector3,unsigned int>>,std::allocator<std::pair<std::pair<RBX::Vector3,unsigned int> const,RBX::Vector3>>>(this: (std::unordered_map<RBX::Primitive *,RBX::StreamRegion::IdExtents> *)(*(_QWORD *)(a2 + 416) + 10216LL)); /*0x1431e8d7e*/
}

// Address: 0x1431e8d90 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$41
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_41(__int64 a1, __int64 a2)
{
  std::unordered_map<std::pair<RBX::Vector3,unsigned int>,RBX::Vector3,RBX::PositionColorHash,std::equal_to<std::pair<RBX::Vector3,unsigned int>>,std::allocator<std::pair<std::pair<RBX::Vector3,unsigned int> const,RBX::Vector3>>>::~unordered_map<std::pair<RBX::Vector3,unsigned int>,RBX::Vector3,RBX::PositionColorHash,std::equal_to<std::pair<RBX::Vector3,unsigned int>>,std::allocator<std::pair<std::pair<RBX::Vector3,unsigned int> const,RBX::Vector3>>>(this: (std::unordered_map<RBX::Primitive *,RBX::StreamRegion::IdExtents> *)(*(_QWORD *)(a2 + 416) + 10280LL)); /*0x1431e8d9e*/
}

// Address: 0x1431e8db0 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$42
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_42(__int64 a1, __int64 a2)
{
  std::unordered_map<std::string,enum RBX::LSP::LuauScriptAnalyzerService::ChangeType>::~unordered_map<std::string,enum RBX::LSP::LuauScriptAnalyzerService::ChangeType>(this: (std::unordered_set<std::pair<std::string const ,RBX::Instance const *>,boost::hash<std::pair<std::string const ,RBX::Instance const *> >,std::equal_to<std::pair<std::string const ,RBX::Instance const *> >,std::allocator<std::pair<std::string const ,RBX::Instance const *> > > *)(*(_QWORD *)(a2 + 416) + 10344LL)); /*0x1431e8dbe*/
}

// Address: 0x1431e8dd0 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$43
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_43(__int64 a1, __int64 a2)
{
  std::recursive_mutex::~recursive_mutex(this: (RBX::InstrumentedMutex<std::mutex> *)(*(_QWORD *)(a2 + 416) + 10408LL)); /*0x1431e8dde*/
}

// Address: 0x1431e8df0 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$44
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_44(__int64 a1, __int64 a2)
{
  boost::unordered::unordered_set<RBX::PackageAssetVersion,boost::hash<RBX::PackageAssetVersion>,std::equal_to<RBX::PackageAssetVersion>,std::allocator<RBX::PackageAssetVersion>>::~unordered_set<RBX::PackageAssetVersion,boost::hash<RBX::PackageAssetVersion>,std::equal_to<RBX::PackageAssetVersion>,std::allocator<RBX::PackageAssetVersion>>(this: (boost::unordered::unordered_map<__int64,enum RBX::MembershipType,boost::hash<__int64>,std::equal_to<__int64>,std::allocator<std::pair<__int64 const ,enum RBX::MembershipType> > > *)(*(_QWORD *)(a2 + 416) + 10488LL)); /*0x1431e8dfe*/
}

// Address: 0x1431e8e10 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$45
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_45(__int64 a1, __int64 a2)
{
  RBX::DenseSet<RBX::Soundscape::NonBlockingFmodSoundLoader *,RBX::DenseMapInfo<RBX::Soundscape::NonBlockingFmodSoundLoader *>>::~DenseSet<RBX::Soundscape::NonBlockingFmodSoundLoader *,RBX::DenseMapInfo<RBX::Soundscape::NonBlockingFmodSoundLoader *>>(this: (AP4_BitWriter *)(*(_QWORD *)(a2 + 416) + 10536LL)); /*0x1431e8e1e*/
}

// Address: 0x1431e8e30 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$46
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_46(__int64 a1, __int64 a2)
{
  RBX::UnboundedCircularBuffer<RakNet::Packet *>::~UnboundedCircularBuffer<RakNet::Packet *>(this: (RBX::UnboundedCircularBuffer<RBX::Time> *)(*(_QWORD *)(a2 + 416) + 10560LL)); /*0x1431e8e3e*/
}

// Address: 0x1431e8e50 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$47
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_47(__int64 a1, __int64 a2)
{
  RBX::DenseMap<RBX::Guid,std::vector<RBX::Network::Replicator::PropertyVersionOverride>,RBX::DenseMapInfo<RBX::Guid>,RBX::detail::DenseMapPair<RBX::Guid,std::vector<RBX::Network::Replicator::PropertyVersionOverride>>>::~DenseMap<RBX::Guid,std::vector<RBX::Network::Replicator::PropertyVersionOverride>,RBX::DenseMapInfo<RBX::Guid>,RBX::detail::DenseMapPair<RBX::Guid,std::vector<RBX::Network::Replicator::PropertyVersionOverride>>>(this: (RBX::DenseMap<RBX::Guid,std::vector<RBX::Network::Replicator::PropertyVersionOverride>,RBX::DenseMapInfo<RBX::Guid>,RBX::detail::DenseMapPair<RBX::Guid,std::vector<RBX::Network::Replicator::PropertyVersionOverride> > > *)(*(_QWORD *)(a2 + 416) + 10592LL)); /*0x1431e8e5e*/
}

// Address: 0x1431e8e70 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$48
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_48(__int64 a1, __int64 a2)
{
  RBX::DenseMap<RBX::Guid,std::vector<RBX::Network::Replicator::AttributeVersionOverride>,RBX::DenseMapInfo<RBX::Guid>,RBX::detail::DenseMapPair<RBX::Guid,std::vector<RBX::Network::Replicator::AttributeVersionOverride>>>::~DenseMap<RBX::Guid,std::vector<RBX::Network::Replicator::AttributeVersionOverride>,RBX::DenseMapInfo<RBX::Guid>,RBX::detail::DenseMapPair<RBX::Guid,std::vector<RBX::Network::Replicator::AttributeVersionOverride>>>(this: (RBX::DenseMap<RBX::Guid,std::vector<RBX::Network::Replicator::AttributeVersionOverride>,RBX::DenseMapInfo<RBX::Guid>,RBX::detail::DenseMapPair<RBX::Guid,std::vector<RBX::Network::Replicator::AttributeVersionOverride> > > *)(*(_QWORD *)(a2 + 416) + 10616LL)); /*0x1431e8e7e*/
}

// Address: 0x1431e8e90 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$49
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_49(__int64 a1, __int64 a2)
{
  boost::unordered::unordered_map<RBX::Instance *,std::pair<std::shared_ptr<RBX::Instance>,boost::unordered::unordered_map<unsigned __int64,unsigned int,boost::hash<unsigned __int64>,std::equal_to<unsigned __int64>,std::allocator<std::pair<unsigned __int64 const,unsigned int>>>>,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<std::pair<RBX::Instance * const,std::pair<std::shared_ptr<RBX::Instance>,boost::unordered::unordered_map<unsigned __int64,unsigned int,boost::hash<unsigned __int64>,std::equal_to<unsigned __int64>,std::allocator<std::pair<unsigned __int64 const,unsigned int>>>>>>>::~unordered_map<RBX::Instance *,std::pair<std::shared_ptr<RBX::Instance>,boost::unordered::unordered_map<unsigned __int64,unsigned int,boost::hash<unsigned __int64>,std::equal_to<unsigned __int64>,std::allocator<std::pair<unsigned __int64 const,unsigned int>>>>,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<std::pair<RBX::Instance * const,std::pair<std::shared_ptr<RBX::Instance>,boost::unordered::unordered_map<unsigned __int64,unsigned int,boost::hash<unsigned __int64>,std::equal_to<unsigned __int64>,std::allocator<std::pair<unsigned __int64 const,unsigned int>>>>>>>(this: (boost::unordered::unordered_map<RBX::Instance *,std::pair<std::shared_ptr<RBX::Instance>,boost::unordered::unordered_map<unsigned __int64,unsigned int,boost::hash<unsigned __int64>,std::equal_to<unsigned __int64>,std::allocator<std::pair<unsigned __int64 const ,unsigned int> > > >,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<std::pair<RBX::Instance * const,std::pair<std::shared_ptr<RBX::Instance>,boost::unordered::unordered_map<unsigned __int64,unsigned int,boost::hash<unsigned __int64>,std::equal_to<unsigned __int64>,std::allocator<std::pair<unsigned __int64 const ,unsigned int> > > > > > > *)(*(_QWORD *)(a2 + 416) + 10648LL)); /*0x1431e8e9e*/
}

// Address: 0x1431e8eb0 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$50
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_50(__int64 a1, __int64 a2)
{
  boost::unordered::unordered_map<RBX::Instance *,std::pair<std::shared_ptr<RBX::Animator>,boost::unordered::unordered_map<RBX::ContentId,RBX::Network::Replicator::AnimationTrackReplicatedValues,boost::hash<RBX::ContentId>,std::equal_to<RBX::ContentId>,std::allocator<std::pair<RBX::ContentId const,RBX::Network::Replicator::AnimationTrackReplicatedValues>>>>,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<std::pair<RBX::Instance * const,std::pair<std::shared_ptr<RBX::Animator>,boost::unordered::unordered_map<RBX::ContentId,RBX::Network::Replicator::AnimationTrackReplicatedValues,boost::hash<RBX::ContentId>,std::equal_to<RBX::ContentId>,std::allocator<std::pair<RBX::ContentId const,RBX::Network::Replicator::AnimationTrackReplicatedValues>>>>>>>::~unordered_map<RBX::Instance *,std::pair<std::shared_ptr<RBX::Animator>,boost::unordered::unordered_map<RBX::ContentId,RBX::Network::Replicator::AnimationTrackReplicatedValues,boost::hash<RBX::ContentId>,std::equal_to<RBX::ContentId>,std::allocator<std::pair<RBX::ContentId const,RBX::Network::Replicator::AnimationTrackReplicatedValues>>>>,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<std::pair<RBX::Instance * const,std::pair<std::shared_ptr<RBX::Animator>,boost::unordered::unordered_map<RBX::ContentId,RBX::Network::Replicator::AnimationTrackReplicatedValues,boost::hash<RBX::ContentId>,std::equal_to<RBX::ContentId>,std::allocator<std::pair<RBX::ContentId const,RBX::Network::Replicator::AnimationTrackReplicatedValues>>>>>>>(this: (boost::unordered::unordered_map<RBX::Instance *,std::pair<std::shared_ptr<RBX::Animator>,boost::unordered::unordered_map<RBX::ContentId,RBX::Network::Replicator::AnimationTrackReplicatedValues,boost::hash<RBX::ContentId>,std::equal_to<RBX::ContentId>,std::allocator<std::pair<RBX::ContentId const ,RBX::Network::Replicator::AnimationTrackReplicatedValues> > > >,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<std::pair<RBX::Instance * const,std::pair<std::shared_ptr<RBX::Animator>,boost::unordered::unordered_map<RBX::ContentId,RBX::Network::Replicator::AnimationTrackReplicatedValues,boost::hash<RBX::ContentId>,std::equal_to<RBX::ContentId>,std::allocator<std::pair<RBX::ContentId const ,RBX::Network::Replicator::AnimationTrackReplicatedValues> > > > > > > *)(*(_QWORD *)(a2 + 416) + 10696LL)); /*0x1431e8ebe*/
}

// Address: 0x1431e8ed0 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$51
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_51(__int64 a1, __int64 a2)
{
  boost::unordered::unordered_map<RBX::Guid const,RBX::Network::Replicator::DeferredTree,boost::hash<RBX::Guid const>,std::equal_to<RBX::Guid const>,std::allocator<std::pair<RBX::Guid const,RBX::Network::Replicator::DeferredTree>>>::~unordered_map<RBX::Guid const,RBX::Network::Replicator::DeferredTree,boost::hash<RBX::Guid const>,std::equal_to<RBX::Guid const>,std::allocator<std::pair<RBX::Guid const,RBX::Network::Replicator::DeferredTree>>>(this: (boost::unordered::unordered_map<RBX::Guid const ,RBX::Network::Replicator::DeferredTree,boost::hash<RBX::Guid const >,std::equal_to<RBX::Guid const >,std::allocator<std::pair<RBX::Guid const ,RBX::Network::Replicator::DeferredTree> > > *)(*(_QWORD *)(a2 + 416) + 10752LL)); /*0x1431e8ede*/
}

// Address: 0x1431e8ef0 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$52
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_52(__int64 a1, __int64 a2)
{
  boost::unordered::unordered_map<__int64,std::shared_ptr<std::vector<std::shared_ptr<RBX::Instance>> const>,boost::hash<__int64>,std::equal_to<__int64>,std::allocator<std::pair<__int64 const,std::shared_ptr<std::vector<std::shared_ptr<RBX::Instance>> const>>>>::~unordered_map<__int64,std::shared_ptr<std::vector<std::shared_ptr<RBX::Instance>> const>,boost::hash<__int64>,std::equal_to<__int64>,std::allocator<std::pair<__int64 const,std::shared_ptr<std::vector<std::shared_ptr<RBX::Instance>> const>>>>(this: (boost::unordered::unordered_map<RBX::Name const *,std::shared_ptr<RBX::Instance>,boost::hash<RBX::Name const *>,std::equal_to<RBX::Name const *>,std::allocator<std::pair<RBX::Name const * const,std::shared_ptr<RBX::Instance> > > > *)(*(_QWORD *)(a2 + 416) + 10816LL)); /*0x1431e8efe*/
}

// Address: 0x1431e8f10 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$53
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_53(__int64 a1, __int64 a2)
{
  boost::mutex::~mutex(this: (boost::mutex *)(*(_QWORD *)(a2 + 416) + 10864LL)); /*0x1431e8f1e*/
}

// Address: 0x1431e8f30 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$54
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_54(__int64 a1, __int64 a2)
{
  std::queue<RakNet::DelayTransmitStruct *>::~queue<RakNet::DelayTransmitStruct *,std::deque<RakNet::DelayTransmitStruct *>>(this: (std::queue<float> *)(*(_QWORD *)(a2 + 416) + 10880LL)); /*0x1431e8f3e*/
}

// Address: 0x1431e8f50 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$55
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_55(__int64 a1, __int64 a2)
{
  std::queue<std::shared_ptr<RBX::Network::Marker>>::~queue<std::shared_ptr<RBX::Network::Marker>,std::deque<std::shared_ptr<RBX::Network::Marker>>>(this: (std::queue<std::shared_ptr<RBX::HttpRequest>> *)(*(_QWORD *)(a2 + 416) + 10992LL)); /*0x1431e8f5e*/
}

// Address: 0x1431e8f70 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$56
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_56(__int64 a1, __int64 a2)
{
  boost::unordered::unordered_set<RBX::SharedString,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>,std::allocator<RBX::SharedString>>::~unordered_set<RBX::SharedString,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>,std::allocator<RBX::SharedString>>(this: (boost::unordered::unordered_set<RBX::SharedString,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>,std::allocator<RBX::SharedString> > *)(*(_QWORD *)(a2 + 416) + 11040LL)); /*0x1431e8f7e*/
}

// Address: 0x1431e8f90 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$57
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_57(__int64 a1, __int64 a2)
{
  boost::unordered::unordered_map<std::string,RBX::SharedString,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::SharedString>>>::~unordered_map<std::string,RBX::SharedString,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::SharedString>>>(this: (boost::unordered::unordered_map<std::string,RBX::SharedString,boost::hash<std::string >,std::equal_to<std::string >,std::allocator<std::pair<std::string const ,RBX::SharedString> > > *)(*(_QWORD *)(a2 + 416) + 11088LL)); /*0x1431e8f9e*/
}

// Address: 0x1431e8fb0 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$58
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_58(__int64 a1, __int64 a2)
{
  boost::unordered::unordered_map<std::string,RBX::SharedString,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::SharedString>>>::~unordered_map<std::string,RBX::SharedString,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::SharedString>>>(this: (boost::unordered::unordered_map<std::string,RBX::SharedString,boost::hash<std::string >,std::equal_to<std::string >,std::allocator<std::pair<std::string const ,RBX::SharedString> > > *)(*(_QWORD *)(a2 + 416) + 11136LL)); /*0x1431e8fbe*/
}

// Address: 0x1431e8fd0 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$59
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_59(__int64 a1, __int64 a2)
{
  boost::unordered::unordered_map<RBX::Guid,RBX::Network::ChildrenWithParentOrder,boost::hash<RBX::Guid>,std::equal_to<RBX::Guid>,std::allocator<std::pair<RBX::Guid const,RBX::Network::ChildrenWithParentOrder>>>::~unordered_map<RBX::Guid,RBX::Network::ChildrenWithParentOrder,boost::hash<RBX::Guid>,std::equal_to<RBX::Guid>,std::allocator<std::pair<RBX::Guid const,RBX::Network::ChildrenWithParentOrder>>>(this: (boost::unordered::unordered_map<RBX::Guid,RBX::Network::ChildrenWithParentOrder,boost::hash<RBX::Guid>,std::equal_to<RBX::Guid>,std::allocator<std::pair<RBX::Guid const ,RBX::Network::ChildrenWithParentOrder> > > *)(*(_QWORD *)(a2 + 416) + 11192LL)); /*0x1431e8fde*/
}

// Address: 0x1431e8ff0 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$60
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_60(__int64 a1, __int64 a2)
{
  boost::unordered::unordered_map<RBX::Guid,std::vector<RBX::Network::DeserializedNewInstanceItem>,boost::hash<RBX::Guid>,std::equal_to<RBX::Guid>,std::allocator<std::pair<RBX::Guid const,std::vector<RBX::Network::DeserializedNewInstanceItem>>>>::~unordered_map<RBX::Guid,std::vector<RBX::Network::DeserializedNewInstanceItem>,boost::hash<RBX::Guid>,std::equal_to<RBX::Guid>,std::allocator<std::pair<RBX::Guid const,std::vector<RBX::Network::DeserializedNewInstanceItem>>>>(this: (boost::unordered::unordered_map<RBX::Guid,std::vector<RBX::Network::DeserializedNewInstanceItem>,boost::hash<RBX::Guid>,std::equal_to<RBX::Guid>,std::allocator<std::pair<RBX::Guid const ,std::vector<RBX::Network::DeserializedNewInstanceItem> > > > *)(*(_QWORD *)(a2 + 416) + 11240LL)); /*0x1431e8ffe*/
}

// Address: 0x1431e9010 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$61
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_61(__int64 a1, __int64 a2)
{
  RBX::Network::JoinRxStats::~JoinRxStats(this: (RBX::Network::JoinRxStats *)(*(_QWORD *)(a2 + 416) + 11344LL)); /*0x1431e901e*/
}

// Address: 0x1431e9030 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$62
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_62(__int64 a1, __int64 a2)
{
  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)(*(_QWORD *)(a2 + 416) /*0x1431e903e*/
                                                                                                + 11952LL));
}

// Address: 0x1431e9050 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$63
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_63(__int64 a1, __int64 a2)
{
  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)(*(_QWORD *)(a2 + 416) /*0x1431e905e*/
                                                                                                + 11968LL));
}

// Address: 0x1431e9070 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$64
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_64(__int64 a1, __int64 a2)
{
  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)(*(_QWORD *)(a2 + 416) /*0x1431e907e*/
                                                                                                + 11984LL));
}

// Address: 0x1431e9090 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$65
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_65(__int64 a1, __int64 a2)
{
  std::vector<std::pair<unsigned short,unsigned short>>::~vector<std::pair<unsigned short,unsigned short>>(this: (std::vector<enum VkPresentModeKHR> *)(*(_QWORD *)(a2 + 416) + 12040LL)); /*0x1431e909e*/
}

// Address: 0x1431e90b0 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$66
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_66(__int64 a1, __int64 a2)
{
  std::vector<std::pair<unsigned short,unsigned short>>::~vector<std::pair<unsigned short,unsigned short>>(this: (std::vector<enum VkPresentModeKHR> *)(*(_QWORD *)(a2 + 416) + 12064LL)); /*0x1431e90be*/
}

// Address: 0x1431e90d0 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$67
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_67(__int64 a1, __int64 a2)
{
  std::vector<std::pair<unsigned short,unsigned short>>::~vector<std::pair<unsigned short,unsigned short>>(this: (std::vector<enum VkPresentModeKHR> *)(*(_QWORD *)(a2 + 416) + 12088LL)); /*0x1431e90de*/
}

// Address: 0x1431e90f0 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$68
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_68(__int64 a1, __int64 a2)
{
  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)(*(_QWORD *)(a2 + 416) /*0x1431e90fe*/
                                                                                                + 12120LL));
}

// Address: 0x1431e9110 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$69
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_69(__int64 a1, __int64 a2)
{
  rbx::signals::scoped_connection::~scoped_connection(this: (rbx::signals::scoped_connection *)(*(_QWORD *)(a2 + 416) /*0x1431e911e*/
                                                                                              + 12160LL));
}

// Address: 0x1431e9130 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$70
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_70(__int64 a1, __int64 a2)
{
  rbx::timestamped_safe_queue<RBX::Network::ProcessingPacket>::~timestamped_safe_queue<RBX::Network::ProcessingPacket>(this: (rbx::timestamped_safe_queue<RBX::Network::ProcessingPacket> *)(*(_QWORD *)(a2 + 416) + 12176LL)); /*0x1431e913e*/
}

// Address: 0x1431e9150 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$71
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_71(__int64 a1, __int64 a2)
{
  rbx::timestamped_safe_queue<RBX::Network::ProcessingPacket>::~timestamped_safe_queue<RBX::Network::ProcessingPacket>(this: (rbx::timestamped_safe_queue<RBX::Network::ProcessingPacket> *)(*(_QWORD *)(a2 + 416) + 12232LL)); /*0x1431e915e*/
}

// Address: 0x1431e9170 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$72
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_72(__int64 a1, __int64 a2)
{
  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)(*(_QWORD *)(a2 + 416) /*0x1431e917e*/
                                                                                                + 12288LL));
}

// Address: 0x1431e9190 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$73
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_73(__int64 a1, __int64 a2)
{
  std::vector<std::shared_ptr<std::vector<RBX::Reflection::Variant> const>>::~vector<std::shared_ptr<std::vector<RBX::Reflection::Variant> const>>(this: (std::vector<std::shared_ptr<std::vector<RBX::Reflection::Variant> const >> *)(*(_QWORD *)(a2 + 416) + 13320LL)); /*0x1431e919e*/
}

// Address: 0x1431e91b0 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$74
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_74(__int64 a1, __int64 a2)
{
  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)(*(_QWORD *)(a2 + 416) /*0x1431e91be*/
                                                                                                + 13352LL));
}

// Address: 0x1431e91d0 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$85
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_85(__int64 a1, __int64 a2)
{
  operator delete(ptr: *(void **)(a2 + 448)); /*0x1431e91e5*/
}

// Address: 0x1431e91f0 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$88
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_88(__int64 a1, __int64 a2)
{
  std::vector<std::pair<float,std::shared_ptr<RBX::ProximityPrompt>>>::_Tidy(this: *(std::vector<std::pair<enum RBX::CurveAnimationChannel,std::shared_ptr<RBX::Instance> >> **)(a2 + 32)); /*0x1431e91f7*/
}

// Address: 0x1431e9200 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$100
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_100(__int64 a1, __int64 a2)
{
  std::list<std::pair<std::pair<RBX::Vector3,unsigned int> const,RBX::Vector3>>::~list<std::pair<std::pair<RBX::Vector3,unsigned int> const,RBX::Vector3>>(this: (std::list<std::pair<unsigned __int64 const ,RBX::Collision::BulletCollisionBoxSetPool::BoxSetStorage>> *)(*(_QWORD *)(a2 + 448) + 8LL)); /*0x1431e920b*/
}

// Address: 0x1431e9210 | Name: _RBX::Network::Replicator::Replicator_::_1_::dtor$103
void __fastcall RBX::Network::Replicator::Replicator_::_1_::dtor_103(__int64 a1, __int64 a2)
{
  std::list<std::pair<RBX::ContentId const,int>>::~list<std::pair<RBX::ContentId const,int>>(this: (std::list<std::pair<std::string const ,std::atomic<int> >> *)(*(_QWORD *)(a2 + 448) + 8LL)); /*0x1431e921b*/
}

// Address: 0x1431e9220 | Name: _boost::unordered::detail::table_impl_boost::unordered::detail::map_std::allocator_std::pair_std::basic_string_char_std::char_traits_char__std::allocator_char____const__std::vector_RBX::Network::DeferredSharedStringSetter_std::allocator_RBX::Network::DeferredSharedStringSetter________std::basic_string_char_std::char_traits_char__std::allocator_char____std::vector_RBX::Network::DeferredSharedStringSetter_std::allocator_RBX::Network::DeferredSharedStringSetter____boost::hash_std::basic_string_char_std::char_traits_char__std::allocator_char______std::equal_to_std::basic_string_char_std::char_traits_char__std::allocator_char_________::operator[]_::_1_::dtor$0
void __fastcall boost::unordered::detail::table_impl_boost::unordered::detail::map_std::allocator_std::pair_std::basic_string_char_std::char_traits_char__std::allocator_char____const__std::vector_RBX::Network::DeferredSharedStringSetter_std::allocator_RBX::Network::DeferredSharedStringSetter________std::basic_string_char_std::char_traits_char__std::allocator_char____std::vector_RBX::Network::DeferredSharedStringSetter_std::allocator_RBX::Network::DeferredSharedStringSetter____boost::hash_std::basic_string_char_std::char_traits_char__std::allocator_char______std::equal_to_std::basic_string_char_std::char_traits_char__std::allocator_char_________::operator[]_::_1_::dtor_0(
        __int64 a1,
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const ,std::vector<RBX::Network::DeferredSharedStringSetter> > > > > *a2)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,std::vector<RBX::Network::DeferredSharedStringSetter>>>>>::~node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,std::vector<RBX::Network::DeferredSharedStringSetter>>>>>(this: a2 + 2); /*0x1431e9227*/
}

// Address: 0x1431e9240 | Name: _boost::unordered::detail::table_impl_boost::unordered::detail::map_std::allocator_std::pair_RBX::Guid_const__RBX::Network::ChildrenWithParentOrder____RBX::Guid_RBX::Network::ChildrenWithParentOrder_boost::hash_RBX::Guid__std::equal_to_RBX::Guid_____::operator[]_::_1_::dtor$0
void __fastcall boost::unordered::detail::table_impl_boost::unordered::detail::map_std::allocator_std::pair_RBX::Guid_const__RBX::Network::ChildrenWithParentOrder____RBX::Guid_RBX::Network::ChildrenWithParentOrder_boost::hash_RBX::Guid__std::equal_to_RBX::Guid_____::operator[]_::_1_::dtor_0(
        __int64 a1,
        __int64 a2)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<RBX::Guid const,RBX::Network::ChildrenWithParentOrder>>>>::~node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<RBX::Guid const,RBX::Network::ChildrenWithParentOrder>>>>(this: (boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<RBX::Guid const ,RBX::Network::ChildrenWithParentOrder> > > > *)(a2 + 32)); /*0x1431e9247*/
}

// Address: 0x1431e9250 | Name: _boost::unordered::detail::table_impl_boost::unordered::detail::map_std::allocator_std::pair_RBX::Guid_const__std::vector_RBX::Network::DeserializedNewInstanceItem_std::allocator_RBX::Network::DeserializedNewInstanceItem________RBX::Guid_std::vector_RBX::Network::DeserializedNewInstanceItem_std::allocator_RBX::Network::DeserializedNewInstanceItem____boost::hash_RBX::Guid__std::equal_to_RBX::Guid_____::operator[]_::_1_::dtor$0
void __fastcall boost::unordered::detail::table_impl_boost::unordered::detail::map_std::allocator_std::pair_RBX::Guid_const__std::vector_RBX::Network::DeserializedNewInstanceItem_std::allocator_RBX::Network::DeserializedNewInstanceItem________RBX::Guid_std::vector_RBX::Network::DeserializedNewInstanceItem_std::allocator_RBX::Network::DeserializedNewInstanceItem____boost::hash_RBX::Guid__std::equal_to_RBX::Guid_____::operator[]_::_1_::dtor_0(
        __int64 a1,
        __int64 a2)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<RBX::Guid const,std::vector<RBX::Network::DeserializedNewInstanceItem>>>>>::~node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<RBX::Guid const,std::vector<RBX::Network::DeserializedNewInstanceItem>>>>>(this: (boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<RBX::Guid const ,std::vector<RBX::Network::DeserializedNewInstanceItem> > > > > *)(a2 + 32)); /*0x1431e9257*/
}

// Address: 0x1431e9260 | Name: _boost::unordered::detail::table_impl_boost::unordered::detail::map_std::allocator_std::pair_RBX::Instance___const_std::pair_std::shared_ptr_RBX::Animator__boost::unordered::unordered_map_RBX::ContentId_RBX::Network::Replicator::AnimationTrackReplicatedValues_boost::hash_RBX::ContentId__std::equal_to_RBX::ContentId__std::allocator_std::pair_RBX::ContentId_const__RBX::Network::Replicator::AnimationTrackReplicatedValues____________RBX::Instance___std::pair_std::shared_ptr_RBX::Animator__boost::unordered::unordered_map_RBX::ContentId_RBX::Network::Replicator::AnimationTrackReplicatedValues_boost::hash_RBX::ContentId__std::equal_to_RBX::ContentId__std::allocator_std::pair_RBX::ContentId_const__RBX::Network::Replicator::AnimationTrackReplicatedValues________boost::hash_RBX::Instance____std::equal_to_RBX::Instance_______::operator[]_::_1_::dtor$0
void __fastcall boost::unordered::detail::table_impl_boost::unordered::detail::map_std::allocator_std::pair_RBX::Instance___const_std::pair_std::shared_ptr_RBX::Animator__boost::unordered::unordered_map_RBX::ContentId_RBX::Network::Replicator::AnimationTrackReplicatedValues_boost::hash_RBX::ContentId__std::equal_to_RBX::ContentId__std::allocator_std::pair_RBX::ContentId_const__RBX::Network::Replicator::AnimationTrackReplicatedValues____________RBX::Instance___std::pair_std::shared_ptr_RBX::Animator__boost::unordered::unordered_map_RBX::ContentId_RBX::Network::Replicator::AnimationTrackReplicatedValues_boost::hash_RBX::ContentId__std::equal_to_RBX::ContentId__std::allocator_std::pair_RBX::ContentId_const__RBX::Network::Replicator::AnimationTrackReplicatedValues________boost::hash_RBX::Instance____std::equal_to_RBX::Instance_______::operator[]_::_1_::dtor_0(
        __int64 a1,
        __int64 a2)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<RBX::Instance * const,std::pair<std::shared_ptr<RBX::Animator>,boost::unordered::unordered_map<RBX::ContentId,RBX::Network::Replicator::AnimationTrackReplicatedValues,boost::hash<RBX::ContentId>,std::equal_to<RBX::ContentId>,std::allocator<std::pair<RBX::ContentId const,RBX::Network::Replicator::AnimationTrackReplicatedValues>>>>>>>>::~node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<RBX::Instance * const,std::pair<std::shared_ptr<RBX::Animator>,boost::unordered::unordered_map<RBX::ContentId,RBX::Network::Replicator::AnimationTrackReplicatedValues,boost::hash<RBX::ContentId>,std::equal_to<RBX::ContentId>,std::allocator<std::pair<RBX::ContentId const,RBX::Network::Replicator::AnimationTrackReplicatedValues>>>>>>>>(this: (boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<RBX::Instance * const,std::pair<std::shared_ptr<RBX::Animator>,boost::unordered::unordered_map<RBX::ContentId,RBX::Network::Replicator::AnimationTrackReplicatedValues,boost::hash<RBX::ContentId>,std::equal_to<RBX::ContentId>,std::allocator<std::pair<RBX::ContentId const ,RBX::Network::Replicator::AnimationTrackReplicatedValues> > > > > > > > *)(a2 + 32)); /*0x1431e9267*/
}

// Address: 0x1431e9290 | Name: _RBX::Network::_dynamic_initializer_for__prop_RemotePlayer___::_1_::dtor$0
void RBX::Network::_dynamic_initializer_for__prop_RemotePlayer___::_1_::dtor_0()
{
  RBX::Reflection::FuncDesc<RBX::Studio::DebuggerConnectionManager>::~FuncDesc<RBX::Studio::DebuggerConnectionManager>(this: (RBX::Reflection::FuncDesc<TeamCreateService> *)&RBX::Network::prop_RemotePlayer); /*0x1431e9297*/
}

// Address: 0x1431e92a0 | Name: _RBX::Network::Replicator::OnReceive_::_1_::dtor$0
void __fastcall RBX::Network::Replicator::OnReceive_::_1_::dtor_0(
        __int64 a1,
        RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> *a2)
{
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: a2 + 360); /*0x1431e92a7*/
}

// Address: 0x1431e92b0 | Name: _RBX::Network::Replicator::OnReceive_::_1_::dtor$15
void __fastcall RBX::Network::Replicator::OnReceive_::_1_::dtor_15(__int64 a1, __int64 a2)
{
  operator delete(ptr: *(void **)(a2 + 1448)); /*0x1431e92c5*/
}

// Address: 0x1431e92d0 | Name: _RBX::Network::Replicator::OnReceive_::_1_::catch$61
__int64 __fastcall RBX::Network::Replicator::OnReceive_::_1_::catch_61(__int64 a1, __int64 a2)
{
  __int64 v3; // rax
  const char *v4; // rbx
  const char *v5; // r9
  RakNet::Packet *v6; // rdi
  unsigned __int64 v7; // r8
  RBX::Network::Replicator *v8; // rbx
  unsigned __int64 v9; // rdx
  _QWORD *v10; // rcx
  unsigned __int64 v11; // rdx
  _QWORD *v12; // rcx

  v3 = (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)(a2 + 264) + 8LL))(a1: *(_QWORD *)(a2 + 264)); /*0x1431e92e9*/
  v4 = (const char *)v3; /*0x1431e92ec*/
  v5 = "empty error string"; /*0x1431e92ef*/
  if ( v3 != 0 ) /*0x1431e92f9*/
    v5 = (const char *)v3; /*0x1431e92f9*/
  v6 = *(RakNet::Packet **)(a2 + 1432); /*0x1431e92fd*/
  RBX::StandardOut::printf(type: MESSAGE_ERROR, format: "Replicator::OnReceive packet %d: %s", *v6->data, v5);
  if ( FLog::Network != 0 )
    FLog::FastLogS(level: FLog::Network, message: "[FLog::Network] Error on Replicator::OnReceive: %s", sarg: v4);
  *(_QWORD *)(a2 + 48) = 0; /*0x1431e9337*/
  *(_QWORD *)(a2 + 64) = 0; /*0x1431e933f*/
  *(_QWORD *)(a2 + 72) = 15; /*0x1431e9347*/
  *(_BYTE *)(a2 + 48) = 0; /*0x1431e934f*/
  v7 = -1; /*0x1431e9353*/
  do /*0x1431e9368*/
    ++v7; /*0x1431e9360*/
  while ( v4[v7] != 0 ); /*0x1431e9368*/
  std::string::assign(this: (std::string *)(a2 + 48), _Ptr: v4, _Count: v7); /*0x1431e9371*/
  *(_QWORD *)(a2 + 80) = 0; /*0x1431e9377*/
  *(_QWORD *)(a2 + 104) = 15; /*0x1431e937f*/
  *(_BYTE *)(a2 + 80) = 0; /*0x1431e9387*/
  *(_QWORD *)(a2 + 96) = 5; /*0x1431e938b*/
  memmove_0(a1: (void *)(a2 + 80), Src: "Other", Size: 5u); /*0x1431e93a4*/
  *(_BYTE *)(a2 + 85) = 0; /*0x1431e93a9*/
  v8 = *(RBX::Network::Replicator **)(a2 + 1424); /*0x1431e93b8*/
  RBX::Network::Replicator::logPacketError( /*0x1431e93c2*/
    this: v8,
    packet: v6,
    type: (const std::string *)(a2 + 80),
    message: (const std::string *)(a2 + 48));
  v9 = *(_QWORD *)(a2 + 104); /*0x1431e93c8*/
  if ( v9 >= 0x10 ) /*0x1431e93d5*/
  {
    v10 = *(_QWORD **)(a2 + 80); /*0x1431e93da*/
    if ( v9 + 1 >= 0x1000 ) /*0x1431e93e5*/
    {
      if ( (unsigned __int64)v10 - *(v10 - 1) - 8 > 0x1F ) /*0x1431e93fa*/
        _invalid_parameter_noinfo_noreturn(); /*0x1431e9401*/
      v10 = (_QWORD *)*(v10 - 1); /*0x1431e93fc*/
    }
    operator delete(ptr: v10); /*0x1431e9408*/
  }
  *(_QWORD *)(a2 + 96) = 0; /*0x1431e940d*/
  *(_QWORD *)(a2 + 104) = 15; /*0x1431e9415*/
  *(_BYTE *)(a2 + 80) = 0; /*0x1431e941d*/
  v11 = *(_QWORD *)(a2 + 72); /*0x1431e9421*/
  if ( v11 >= 0x10 ) /*0x1431e942e*/
  {
    v12 = *(_QWORD **)(a2 + 48); /*0x1431e9433*/
    if ( v11 + 1 >= 0x1000 ) /*0x1431e943e*/
    {
      if ( (unsigned __int64)v12 - *(v12 - 1) - 8 > 0x1F ) /*0x1431e9453*/
        _invalid_parameter_noinfo_noreturn(); /*0x1431e945a*/
      v12 = (_QWORD *)*(v12 - 1); /*0x1431e9455*/
    }
    operator delete(ptr: v12); /*0x1431e9461*/
  }
  RBX::Network::Replicator::requestDisconnectWithSignal(this: v8, reason: 260); /*0x1431e946e*/
  return 0; /*0x1431e947e*/
}

// Address: 0x1431e94c0 | Name: _std::vector_RBX::Network::DeserializedNewInstanceItem_std::allocator_RBX::Network::DeserializedNewInstanceItem___::_Ufill_::_1_::dtor$0
void __fastcall std::vector_RBX::Network::DeserializedNewInstanceItem_std::allocator_RBX::Network::DeserializedNewInstanceItem___::_Ufill_::_1_::dtor_0(
        __int64 a1,
        __int64 a2)
{
  std::_Uninitialized_backout_al<std::allocator<RBX::Network::DeserializedNewInstanceItem>>::~_Uninitialized_backout_al<std::allocator<RBX::Network::DeserializedNewInstanceItem>>(this: (std::_Uninitialized_backout_al<std::allocator<RBX::Network::DeserializedNewInstanceItem> > *)(a2 + 32)); /*0x1431e94c7*/
}

// Address: 0x1431e94d0 | Name: _RBX::Network::Replicator::addEventInvocationItem_::_1_::dtor$0
void __fastcall RBX::Network::Replicator::addEventInvocationItem_::_1_::dtor_0(__int64 a1, __int64 a2)
{
  RBX::AutoMemPool::Object::operator delete(p: *(void **)(a2 + 120), pool: *(RBX::AutoMemPool **)(a2 + 112)); /*0x1431e94e1*/
}

// Address: 0x1431e94f0 | Name: _RBX::Network::Replicator::addToPendingItemsList_::_1_::dtor$2
void __fastcall RBX::Network::Replicator::addToPendingItemsList_::_1_::dtor_2(__int64 a1, __int64 a2)
{
  RBX::AutoMemPool::Object::operator delete(p: *(void **)(a2 + 48), pool: *(RBX::AutoMemPool **)(a2 + 144)); /*0x1431e9504*/
}

// Address: 0x1431e9510 | Name: _boost::unordered::detail::table_boost::unordered::detail::map_std::allocator_std::pair_RBX::ContentId_const__RBX::Network::Replicator::AnimationTrackReplicatedValues____RBX::ContentId_RBX::Network::Replicator::AnimationTrackReplicatedValues_boost::hash_RBX::ContentId__std::equal_to_RBX::ContentId_____::assign_::_1_::dtor$0
void __fastcall boost::unordered::detail::table_boost::unordered::detail::map_std::allocator_std::pair_RBX::ContentId_const__RBX::Network::Replicator::AnimationTrackReplicatedValues____RBX::ContentId_RBX::Network::Replicator::AnimationTrackReplicatedValues_boost::hash_RBX::ContentId__std::equal_to_RBX::ContentId_____::assign_::_1_::dtor_0(
        __int64 a1,
        boost::unordered::detail::assign_nodes<boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::ContentId const ,RBX::Network::Replicator::AnimationTrackReplicatedValues> >,RBX::ContentId,RBX::Network::Replicator::AnimationTrackReplicatedValues,boost::hash<RBX::ContentId>,std::equal_to<RBX::ContentId> > > > *a2)
{
  boost::unordered::detail::assign_nodes<boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::ContentId const,RBX::Network::Replicator::AnimationTrackReplicatedValues>>,RBX::ContentId,RBX::Network::Replicator::AnimationTrackReplicatedValues,boost::hash<RBX::ContentId>,std::equal_to<RBX::ContentId>>>>::~assign_nodes<boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::ContentId const,RBX::Network::Replicator::AnimationTrackReplicatedValues>>,RBX::ContentId,RBX::Network::Replicator::AnimationTrackReplicatedValues,boost::hash<RBX::ContentId>,std::equal_to<RBX::ContentId>>>>(this: a2 + 1); /*0x1431e9517*/
}

// Address: 0x1431e9520 | Name: _RBX::Network::DeserializedDeleteInstanceItem::process_::_1_::dtor$1
void __fastcall RBX::Network::DeserializedDeleteInstanceItem::process_::_1_::dtor_1(
        __int64 a1,
        RBX::ScopedAssign<unsigned __int64> *a2)
{
  RBX::ScopedAssign<unsigned __int64>::~ScopedAssign<unsigned __int64>(this: a2 + 5); /*0x1431e9527*/
}

// Address: 0x1431e9530 | Name: _RBX::Network::Replicator::rakNetBufferIsSufficientlyEmpty_::_1_::dtor$0
void RBX::Network::Replicator::rakNetBufferIsSufficientlyEmpty_::_1_::dtor_0()
{
  Init_thread_abort(pOnce: &_TSS0_525); /*0x1431e9537*/
}

// Address: 0x1431e9540 | Name: _RBX::Network::Replicator::rakNetBufferIsSufficientlyEmpty_::_1_::dtor$1
void RBX::Network::Replicator::rakNetBufferIsSufficientlyEmpty_::_1_::dtor_1()
{
  Init_thread_abort(pOnce: &_TSS1_109); /*0x1431e9547*/
}

// Address: 0x1431e9550 | Name: _RBX::Network::Replicator::checkPossibleDelayInvocationQueueSpam_::_1_::dtor$0
void __fastcall RBX::Network::Replicator::checkPossibleDelayInvocationQueueSpam_::_1_::dtor_0(__int64 a1, __int64 a2)
{
  if ( (*(_DWORD *)(a2 + 352) & 1) != 0 ) /*0x1431e9564*/
  {
    *(_DWORD *)(a2 + 352) &= ~1u; /*0x1431e9566*/
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)(a2 + 112)); /*0x1431e9571*/
  }
}

// Address: 0x1431e9580 | Name: _RBX::Network::Replicator::clusterOutStep_::_1_::catch$1
void __fastcall __noreturn RBX::Network::Replicator::clusterOutStep_::_1_::catch_1(
        __int64 a1,
        std::weak_ptr<UserPluginsModel> *a2)
{
  UserPluginsModel *Ptr; // rdx
  RBX::Network::MegaReplicator *Mysize; // rbx
  std::weak_ptr<RBX::Network::Replicator> *v5; // rax

  if ( FLog::Network != 0 ) /*0x1431e9597*/
    FLog::FastLog( /*0x1431e95a3*/
      level: FLog::Network,
      message: "[FLog::Network] Exception during cluster out step, request disconnect",
      arg0: nullptr);
  Ptr = a2[4]._Ptr; /*0x1431e95a8*/
  Mysize = (RBX::Network::MegaReplicator *)Ptr[17].m_assetDetailsFetcherPerInstallingPlugin._List._Mypair._Myval2._Mysize; /*0x1431e95ac*/
  v5 = (std::weak_ptr<RBX::Network::Replicator> *)RBX::weak_from<RBX::Studio::DebuggerUIService>(result: a2 + 2, r: Ptr); /*0x1431e95b7*/
  RBX::Network::MegaReplicator::addReplicatorToSignalDisconnectQueue(this: Mysize, replicatorToSignal: v5, reason: 262); /*0x1431e95c9*/
  std::weak_ptr<RBX::Soundscape::Sound>::~weak_ptr<RBX::Soundscape::Sound>(this: (std::weak_ptr<PluginPermissionsFetcher> *)&a2[2]); /*0x1431e95d3*/
  throw; /*0x1431e95dc*/
}

// Address: 0x1431e95f0 | Name: _RBX::Network::Replicator::coalesceAnimation_::_1_::dtor$1
void __fastcall RBX::Network::Replicator::coalesceAnimation_::_1_::dtor_1(
        __int64 a1,
        boost::unordered::unordered_map<std::string,JobInfo,boost::hash<std::string >,std::equal_to<std::string >,std::allocator<std::pair<std::string const ,JobInfo> > > *a2)
{
  boost::unordered::unordered_map<std::string,JobInfo,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,JobInfo>>>::~unordered_map<std::string,JobInfo,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,JobInfo>>>(this: a2 + 4); /*0x1431e95f7*/
}

// Address: 0x1431e9600 | Name: _RBX::Network::Replicator::coalesceAnimation_::_1_::dtor$2
void __fastcall RBX::Network::Replicator::coalesceAnimation_::_1_::dtor_2(__int64 a1, __int64 a2)
{
  std::pair<std::shared_ptr<RBX::Animator>,boost::unordered::unordered_map<RBX::ContentId,RBX::Network::Replicator::AnimationTrackReplicatedValues,boost::hash<RBX::ContentId>,std::equal_to<RBX::ContentId>,std::allocator<std::pair<RBX::ContentId const,RBX::Network::Replicator::AnimationTrackReplicatedValues>>>>::~pair<std::shared_ptr<RBX::Animator>,boost::unordered::unordered_map<RBX::ContentId,RBX::Network::Replicator::AnimationTrackReplicatedValues,boost::hash<RBX::ContentId>,std::equal_to<RBX::ContentId>,std::allocator<std::pair<RBX::ContentId const,RBX::Network::Replicator::AnimationTrackReplicatedValues>>>>(this: (std::pair<std::shared_ptr<RBX::Animator>,boost::unordered::unordered_map<RBX::ContentId,RBX::Network::Replicator::AnimationTrackReplicatedValues,boost::hash<RBX::ContentId>,std::equal_to<RBX::ContentId>,std::allocator<std::pair<RBX::ContentId const ,RBX::Network::Replicator::AnimationTrackReplicatedValues> > > > *)(a2 + 96)); /*0x1431e9607*/
}

// Address: 0x1431e9610 | Name: _RBX::Network::Replicator::coalesceAnimation_::_1_::dtor$15
void __fastcall RBX::Network::Replicator::coalesceAnimation_::_1_::dtor_15(__int64 a1, __int64 a2)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::ContentId const,RBX::Network::Replicator::AnimationTrackReplicatedValues>>,RBX::ContentId,RBX::Network::Replicator::AnimationTrackReplicatedValues,boost::hash<RBX::ContentId>,std::equal_to<RBX::ContentId>>>::~table<boost::unordered::detail::map<std::allocator<std::pair<RBX::ContentId const,RBX::Network::Replicator::AnimationTrackReplicatedValues>>,RBX::ContentId,RBX::Network::Replicator::AnimationTrackReplicatedValues,boost::hash<RBX::ContentId>,std::equal_to<RBX::ContentId>>>(this: *(boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<std::string const ,JobInfo> >,std::string,JobInfo,boost::hash<std::string >,std::equal_to<std::string > > > **)(a2 + 352)); /*0x1431e9617*/
}

// Address: 0x1431e9620 | Name: _RBX::Network::Replicator::compressBitStream_::_1_::dtor$0
void __fastcall RBX::Network::Replicator::compressBitStream_::_1_::dtor_0(__int64 a1, __int64 a2)
{
  RBX::DenseSet<RBX::Soundscape::NonBlockingFmodSoundLoader *,RBX::DenseMapInfo<RBX::Soundscape::NonBlockingFmodSoundLoader *>>::~DenseSet<RBX::Soundscape::NonBlockingFmodSoundLoader *,RBX::DenseMapInfo<RBX::Soundscape::NonBlockingFmodSoundLoader *>>(this: (AP4_BitWriter *)(a2 + 264)); /*0x1431e9627*/
}

// Address: 0x1431e9640 | Name: _RBX::Network::Replicator::dataOutStep_::_1_::catch$1
void __fastcall __noreturn RBX::Network::Replicator::dataOutStep_::_1_::catch_1(
        __int64 a1,
        std::weak_ptr<UserPluginsModel> *a2)
{
  UserPluginsModel *Ptr; // rdx
  RBX::Network::MegaReplicator *Mysize; // rbx
  std::weak_ptr<RBX::Network::Replicator> *v5; // rax

  if ( FLog::Network != 0 ) /*0x1431e9657*/
    FLog::FastLog( /*0x1431e9663*/
      level: FLog::Network,
      message: "[FLog::Network] Exception during data out step, request disconnect",
      arg0: nullptr);
  Ptr = a2[4]._Ptr; /*0x1431e9668*/
  Mysize = (RBX::Network::MegaReplicator *)Ptr[17].m_assetDetailsFetcherPerInstallingPlugin._List._Mypair._Myval2._Mysize; /*0x1431e966c*/
  v5 = (std::weak_ptr<RBX::Network::Replicator> *)RBX::weak_from<RBX::Studio::DebuggerUIService>(result: a2 + 2, r: Ptr); /*0x1431e9677*/
  RBX::Network::MegaReplicator::addReplicatorToSignalDisconnectQueue(this: Mysize, replicatorToSignal: v5, reason: 262); /*0x1431e9689*/
  std::weak_ptr<RBX::Soundscape::Sound>::~weak_ptr<RBX::Soundscape::Sound>(this: (std::weak_ptr<PluginPermissionsFetcher> *)&a2[2]); /*0x1431e9693*/
  throw; /*0x1431e969c*/
}

// Address: 0x1431e96b0 | Name: _RBX::Network::Replicator::decayToSharedMap_::_1_::dtor$0
void RBX::Network::Replicator::decayToSharedMap_::_1_::dtor_0()
{
  Init_thread_abort(pOnce: &_TSS0_528); /*0x1431e96b7*/
}

// Address: 0x1431e96c0 | Name: _RBX::Network::Replicator::decompressBitStream_::_1_::dtor$0
void RBX::Network::Replicator::decompressBitStream_::_1_::dtor_0()
{
  Init_thread_abort(pOnce: &_TSS0_529); /*0x1431e96c7*/
}

// Address: 0x1431e96d0 | Name: _RBX::Network::Replicator::decompressBitStream_::_1_::dtor$2
void __fastcall RBX::Network::Replicator::decompressBitStream_::_1_::dtor_2(__int64 a1, AP4_BitWriter *a2)
{
  RBX::DenseSet<RBX::Soundscape::NonBlockingFmodSoundLoader *,RBX::DenseMapInfo<RBX::Soundscape::NonBlockingFmodSoundLoader *>>::~DenseSet<RBX::Soundscape::NonBlockingFmodSoundLoader *,RBX::DenseMapInfo<RBX::Soundscape::NonBlockingFmodSoundLoader *>>(this: a2 + 7); /*0x1431e96d7*/
}

// Address: 0x1431e96e0 | Name: _RBX::Network::Replicator::decompressBitStream_::_1_::dtor$3
void RBX::Network::Replicator::decompressBitStream_::_1_::dtor_3()
{
  Init_thread_abort(pOnce: &_TSS1_110); /*0x1431e96e7*/
}

// Address: 0x1431e9720 | Name: _RBX::Network::Replicator::deserializeStreamAsync_::_1_::dtor$0
void RBX::Network::Replicator::deserializeStreamAsync_::_1_::dtor_0()
{
  Init_thread_abort(pOnce: &_TSS0_531); /*0x1431e9727*/
}

// Address: 0x1431e9730 | Name: _RBX::Network::Replicator::deserializeStreamAsync_::_1_::dtor$2
void RBX::Network::Replicator::deserializeStreamAsync_::_1_::dtor_2()
{
  Init_thread_abort(pOnce: &_TSS1_111); /*0x1431e9737*/
}

// Address: 0x1431e9750 | Name: _RBX::Network::Replicator::deserializeStreamAsync_::_1_::catch$41
__int64 __fastcall RBX::Network::Replicator::deserializeStreamAsync_::_1_::catch_41(__int64 a1, __int64 a2)
{
  RBX::Network::Replicator *v3; // rbx
  __int64 v4; // rax
  const char *v5; // rax
  const char *v7; // rax
  unsigned __int64 v8; // r8
  RakNet::Packet **v9; // rdi
  unsigned __int64 v10; // rdx
  _QWORD *v11; // rcx
  unsigned __int64 v12; // rdx
  _QWORD *v13; // rcx

  v3 = *(RBX::Network::Replicator **)(a2 + 480); /*0x1431e975f*/
  v4 = **(_QWORD **)(a2 + 264); /*0x1431e976d*/
  if ( v3->refactorReceiveQueueCached ) /*0x1431e9770*/
  {
    v5 = (const char *)(*(__int64 (**)(void))(v4 + 8))(); /*0x1431e9779*/
    *(_BYTE *)(a2 + 504) = RBX::Network::Replicator::deserializeStreamError( /*0x1431e97a0*/
                             this: v3,
                             rawPacket: **(RakNet::Packet ***)(a2 + 504),
                             type: "Stream",
                             what: v5,
                             errCode: 260);
    return 0; /*0x1431e97a6*/
  }
  else
  {
    v7 = (const char *)(*(__int64 (**)(void))(v4 + 8))(); /*0x1431e97b5*/
    *(_QWORD *)(a2 + 296) = 0; /*0x1431e97b8*/
    *(_QWORD *)(a2 + 312) = 0; /*0x1431e97c3*/
    *(_QWORD *)(a2 + 320) = 15; /*0x1431e97ce*/
    *(_BYTE *)(a2 + 296) = 0; /*0x1431e97d9*/
    v8 = -1; /*0x1431e97e0*/
    do /*0x1431e97f8*/
      ++v8; /*0x1431e97f0*/
    while ( v7[v8] != 0 ); /*0x1431e97f8*/
    std::string::assign(this: (std::string *)(a2 + 296), _Ptr: v7, _Count: v8); /*0x1431e9804*/
    *(_QWORD *)(a2 + 160) = 0; /*0x1431e980a*/
    *(_QWORD *)(a2 + 184) = 15; /*0x1431e9815*/
    *(_BYTE *)(a2 + 160) = 0; /*0x1431e9820*/
    *(_QWORD *)(a2 + 176) = 6; /*0x1431e9827*/
    memmove_0(a1: (void *)(a2 + 160), Src: "Stream", Size: 6u); /*0x1431e9846*/
    *(_BYTE *)(a2 + 166) = 0; /*0x1431e984b*/
    v9 = *(RakNet::Packet ***)(a2 + 504); /*0x1431e9860*/
    RBX::Network::Replicator::logPacketError( /*0x1431e986d*/
      this: v3,
      packet: *v9,
      type: (const std::string *)(a2 + 160),
      message: (const std::string *)(a2 + 296));
    v10 = *(_QWORD *)(a2 + 184); /*0x1431e9873*/
    if ( v10 >= 0x10 ) /*0x1431e9883*/
    {
      v11 = *(_QWORD **)(a2 + 160); /*0x1431e9888*/
      if ( v10 + 1 >= 0x1000 ) /*0x1431e9896*/
      {
        if ( (unsigned __int64)v11 - *(v11 - 1) - 8 > 0x1F ) /*0x1431e98ab*/
          _invalid_parameter_noinfo_noreturn(); /*0x1431e98b2*/
        v11 = (_QWORD *)*(v11 - 1); /*0x1431e98ad*/
      }
      operator delete(ptr: v11); /*0x1431e98b9*/
    }
    *(_QWORD *)(a2 + 176) = 0; /*0x1431e98be*/
    *(_QWORD *)(a2 + 184) = 15; /*0x1431e98c9*/
    *(_BYTE *)(a2 + 160) = 0; /*0x1431e98d4*/
    v12 = *(_QWORD *)(a2 + 320); /*0x1431e98db*/
    if ( v12 >= 0x10 ) /*0x1431e98eb*/
    {
      v13 = *(_QWORD **)(a2 + 296); /*0x1431e98f0*/
      if ( v12 + 1 >= 0x1000 ) /*0x1431e98fe*/
      {
        if ( (unsigned __int64)v13 - *(v13 - 1) - 8 > 0x1F ) /*0x1431e9913*/
          _invalid_parameter_noinfo_noreturn(); /*0x1431e991a*/
        v13 = (_QWORD *)*(v13 - 1); /*0x1431e9915*/
      }
      operator delete(ptr: v13); /*0x1431e9921*/
    }
    v3->rakPeer._Ptr->peer._Ptr->DeallocatePacket(this: v3->rakPeer._Ptr->peer._Ptr, a2: *v9); /*0x1431e9936*/
    rbx::timestamped_safe_queue<RBX::Network::ProcessingPacket>::clear(this: &v3->deserializedPackets_deprecated); /*0x1431e9943*/
    _InterlockedExchange(&v3->asyncDeserializationError._Storage._Value, 260); /*0x1431e994d*/
    return 1; /*0x1431e9953*/
  }
}

// Address: 0x1431e9970 | Name: _RBX::Network::Replicator::deserializeStreamAsync_::_1_::catch$42
__int64 __fastcall RBX::Network::Replicator::deserializeStreamAsync_::_1_::catch_42(__int64 a1, __int64 a2)
{
  RBX::Network::Replicator *v3; // rbx
  __int64 v4; // rax
  const char *v5; // rax
  const char *v7; // rax
  unsigned __int64 v8; // r8
  RakNet::Packet **v9; // rdi
  unsigned __int64 v10; // rdx
  _QWORD *v11; // rcx
  unsigned __int64 v12; // rdx
  _QWORD *v13; // rcx

  v3 = *(RBX::Network::Replicator **)(a2 + 480); /*0x1431e997f*/
  v4 = **(_QWORD **)(a2 + 272); /*0x1431e998d*/
  if ( v3->refactorReceiveQueueCached ) /*0x1431e9990*/
  {
    v5 = (const char *)(*(__int64 (**)(void))(v4 + 8))(); /*0x1431e9999*/
    *(_BYTE *)(a2 + 504) = RBX::Network::Replicator::deserializeStreamError( /*0x1431e99c0*/
                             this: v3,
                             rawPacket: **(RakNet::Packet ***)(a2 + 504),
                             type: "Stream",
                             what: v5,
                             errCode: 261);
    return 0; /*0x1431e99c6*/
  }
  else
  {
    v7 = (const char *)(*(__int64 (**)(void))(v4 + 8))(); /*0x1431e99d5*/
    *(_QWORD *)(a2 + 328) = 0; /*0x1431e99d8*/
    *(_QWORD *)(a2 + 344) = 0; /*0x1431e99e3*/
    *(_QWORD *)(a2 + 352) = 15; /*0x1431e99ee*/
    *(_BYTE *)(a2 + 328) = 0; /*0x1431e99f9*/
    v8 = -1; /*0x1431e9a00*/
    do /*0x1431e9a18*/
      ++v8; /*0x1431e9a10*/
    while ( v7[v8] != 0 ); /*0x1431e9a18*/
    std::string::assign(this: (std::string *)(a2 + 328), _Ptr: v7, _Count: v8); /*0x1431e9a24*/
    *(_QWORD *)(a2 + 192) = 0; /*0x1431e9a2a*/
    *(_QWORD *)(a2 + 216) = 15; /*0x1431e9a35*/
    *(_BYTE *)(a2 + 192) = 0; /*0x1431e9a40*/
    *(_QWORD *)(a2 + 208) = 6; /*0x1431e9a47*/
    memmove_0(a1: (void *)(a2 + 192), Src: "Stream", Size: 6u); /*0x1431e9a66*/
    *(_BYTE *)(a2 + 198) = 0; /*0x1431e9a6b*/
    v9 = *(RakNet::Packet ***)(a2 + 504); /*0x1431e9a80*/
    RBX::Network::Replicator::logPacketError( /*0x1431e9a8d*/
      this: v3,
      packet: *v9,
      type: (const std::string *)(a2 + 192),
      message: (const std::string *)(a2 + 328));
    v10 = *(_QWORD *)(a2 + 216); /*0x1431e9a93*/
    if ( v10 >= 0x10 ) /*0x1431e9aa3*/
    {
      v11 = *(_QWORD **)(a2 + 192); /*0x1431e9aa8*/
      if ( v10 + 1 >= 0x1000 ) /*0x1431e9ab6*/
      {
        if ( (unsigned __int64)v11 - *(v11 - 1) - 8 > 0x1F ) /*0x1431e9acb*/
          _invalid_parameter_noinfo_noreturn(); /*0x1431e9ad2*/
        v11 = (_QWORD *)*(v11 - 1); /*0x1431e9acd*/
      }
      operator delete(ptr: v11); /*0x1431e9ad9*/
    }
    *(_QWORD *)(a2 + 208) = 0; /*0x1431e9ade*/
    *(_QWORD *)(a2 + 216) = 15; /*0x1431e9ae9*/
    *(_BYTE *)(a2 + 192) = 0; /*0x1431e9af4*/
    v12 = *(_QWORD *)(a2 + 352); /*0x1431e9afb*/
    if ( v12 >= 0x10 ) /*0x1431e9b0b*/
    {
      v13 = *(_QWORD **)(a2 + 328); /*0x1431e9b10*/
      if ( v12 + 1 >= 0x1000 ) /*0x1431e9b1e*/
      {
        if ( (unsigned __int64)v13 - *(v13 - 1) - 8 > 0x1F ) /*0x1431e9b33*/
          _invalid_parameter_noinfo_noreturn(); /*0x1431e9b3a*/
        v13 = (_QWORD *)*(v13 - 1); /*0x1431e9b35*/
      }
      operator delete(ptr: v13); /*0x1431e9b41*/
    }
    v3->rakPeer._Ptr->peer._Ptr->DeallocatePacket(this: v3->rakPeer._Ptr->peer._Ptr, a2: *v9); /*0x1431e9b56*/
    rbx::timestamped_safe_queue<RBX::Network::ProcessingPacket>::clear(this: &v3->deserializedPackets_deprecated); /*0x1431e9b63*/
    _InterlockedExchange(&v3->asyncDeserializationError._Storage._Value, 261); /*0x1431e9b6d*/
    return 1; /*0x1431e9b73*/
  }
}

// Address: 0x1431e9b90 | Name: _RBX::Network::Replicator::deserializeStreamAsync_::_1_::catch$43
__int64 __fastcall RBX::Network::Replicator::deserializeStreamAsync_::_1_::catch_43(__int64 a1, __int64 a2)
{
  RBX::Network::Replicator *v3; // rbx
  __int64 v4; // rax
  const char *v5; // rax
  const char *v7; // rax
  unsigned __int64 v8; // r8
  RakNet::Packet **v9; // rdi
  unsigned __int64 v10; // rdx
  _QWORD *v11; // rcx
  unsigned __int64 v12; // rdx
  _QWORD *v13; // rcx

  v3 = *(RBX::Network::Replicator **)(a2 + 480); /*0x1431e9b9f*/
  v4 = **(_QWORD **)(a2 + 280); /*0x1431e9bad*/
  if ( v3->refactorReceiveQueueCached ) /*0x1431e9bb0*/
  {
    v5 = (const char *)(*(__int64 (**)(void))(v4 + 8))(); /*0x1431e9bb9*/
    *(_BYTE *)(a2 + 504) = RBX::Network::Replicator::deserializeStreamError( /*0x1431e9be0*/
                             this: v3,
                             rawPacket: **(RakNet::Packet ***)(a2 + 504),
                             type: "Other",
                             what: v5,
                             errCode: 260);
    return 0; /*0x1431e9be6*/
  }
  else
  {
    v7 = (const char *)(*(__int64 (**)(void))(v4 + 8))(); /*0x1431e9bf5*/
    *(_QWORD *)(a2 + 360) = 0; /*0x1431e9bf8*/
    *(_QWORD *)(a2 + 376) = 0; /*0x1431e9c03*/
    *(_QWORD *)(a2 + 384) = 15; /*0x1431e9c0e*/
    *(_BYTE *)(a2 + 360) = 0; /*0x1431e9c19*/
    v8 = -1; /*0x1431e9c20*/
    do /*0x1431e9c38*/
      ++v8; /*0x1431e9c30*/
    while ( v7[v8] != 0 ); /*0x1431e9c38*/
    std::string::assign(this: (std::string *)(a2 + 360), _Ptr: v7, _Count: v8); /*0x1431e9c44*/
    *(_QWORD *)(a2 + 224) = 0; /*0x1431e9c4a*/
    *(_QWORD *)(a2 + 248) = 15; /*0x1431e9c55*/
    *(_BYTE *)(a2 + 224) = 0; /*0x1431e9c60*/
    *(_QWORD *)(a2 + 240) = 5; /*0x1431e9c67*/
    memmove_0(a1: (void *)(a2 + 224), Src: "Other", Size: 5u); /*0x1431e9c86*/
    *(_BYTE *)(a2 + 229) = 0; /*0x1431e9c8b*/
    v9 = *(RakNet::Packet ***)(a2 + 504); /*0x1431e9ca0*/
    RBX::Network::Replicator::logPacketError( /*0x1431e9cad*/
      this: v3,
      packet: *v9,
      type: (const std::string *)(a2 + 224),
      message: (const std::string *)(a2 + 360));
    v10 = *(_QWORD *)(a2 + 248); /*0x1431e9cb3*/
    if ( v10 >= 0x10 ) /*0x1431e9cc3*/
    {
      v11 = *(_QWORD **)(a2 + 224); /*0x1431e9cc8*/
      if ( v10 + 1 >= 0x1000 ) /*0x1431e9cd6*/
      {
        if ( (unsigned __int64)v11 - *(v11 - 1) - 8 > 0x1F ) /*0x1431e9ceb*/
          _invalid_parameter_noinfo_noreturn(); /*0x1431e9cf2*/
        v11 = (_QWORD *)*(v11 - 1); /*0x1431e9ced*/
      }
      operator delete(ptr: v11); /*0x1431e9cf9*/
    }
    *(_QWORD *)(a2 + 240) = 0; /*0x1431e9cfe*/
    *(_QWORD *)(a2 + 248) = 15; /*0x1431e9d09*/
    *(_BYTE *)(a2 + 224) = 0; /*0x1431e9d14*/
    v12 = *(_QWORD *)(a2 + 384); /*0x1431e9d1b*/
    if ( v12 >= 0x10 ) /*0x1431e9d2b*/
    {
      v13 = *(_QWORD **)(a2 + 360); /*0x1431e9d30*/
      if ( v12 + 1 >= 0x1000 ) /*0x1431e9d3e*/
      {
        if ( (unsigned __int64)v13 - *(v13 - 1) - 8 > 0x1F ) /*0x1431e9d53*/
          _invalid_parameter_noinfo_noreturn(); /*0x1431e9d5a*/
        v13 = (_QWORD *)*(v13 - 1); /*0x1431e9d55*/
      }
      operator delete(ptr: v13); /*0x1431e9d61*/
    }
    v3->rakPeer._Ptr->peer._Ptr->DeallocatePacket(this: v3->rakPeer._Ptr->peer._Ptr, a2: *v9); /*0x1431e9d76*/
    rbx::timestamped_safe_queue<RBX::Network::ProcessingPacket>::clear(this: &v3->deserializedPackets_deprecated); /*0x1431e9d83*/
    _InterlockedExchange(&v3->asyncDeserializationError._Storage._Value, 260); /*0x1431e9d8d*/
    return 1; /*0x1431e9d93*/
  }
}

// Address: 0x1431e9db0 | Name: _RBX::Network::Replicator::disconnectClusterReplicationData_::_1_::dtor$1
void __fastcall RBX::Network::Replicator::disconnectClusterReplicationData_::_1_::dtor_1(
        __int64 a1,
        RBX::UnboundedCircularBuffer<RBX::Time> *a2)
{
  RBX::UnboundedCircularBuffer<RakNet::Packet *>::~UnboundedCircularBuffer<RakNet::Packet *>(this: a2 + 1); /*0x1431e9db7*/
}

// Address: 0x1431e9dc0 | Name: _RBX::Network::Replicator::disconnectClusterReplicationData_::_1_::dtor$5
void __fastcall RBX::Network::Replicator::disconnectClusterReplicationData_::_1_::dtor_5(__int64 a1, __int64 a2)
{
  std::list<std::pair<RBX::Vector3int32 const,std::vector<RBX::Voxel2::Region>>>::~list<std::pair<RBX::Vector3int32 const,std::vector<RBX::Voxel2::Region>>>(this: (std::list<std::pair<RBX::Vector3int32 const ,std::vector<RBX::Voxel2::Region> >> *)(*(_QWORD *)(a2 + 144) + 8LL)); /*0x1431e9dcb*/
}

// Address: 0x1431e9dd0 | Name: _RBX::Network::Replicator::doDataPingAndStatusChecks_::_1_::dtor$1
void __fastcall RBX::Network::Replicator::doDataPingAndStatusChecks_::_1_::dtor_1(
        __int64 a1,
        RBX::DataModel::scoped_write_request *a2)
{
  RBX::DataModel::scoped_write_request::~scoped_write_request(this: a2 + 20); /*0x1431e9dd7*/
}

// Address: 0x1431e9de0 | Name: _RBX::Network::Replicator::doDataPingAndStatusChecks_::_1_::dtor$3
void __fastcall RBX::Network::Replicator::doDataPingAndStatusChecks_::_1_::dtor_3(__int64 a1, __int64 a2)
{
  RBX::AutoMemPool::Object::operator delete(p: *(void **)(a2 + 32), pool: *(RBX::AutoMemPool **)(a2 + 168)); /*0x1431e9df4*/
}

// Address: 0x1431e9e00 | Name: _RBX::Network::Replicator::doParallelPhysicsReceive_::_1_::dtor$1
void RBX::Network::Replicator::doParallelPhysicsReceive_::_1_::dtor_1()
{
  Init_thread_abort(pOnce: &_TSS0_530); /*0x1431e9e07*/
}

// Address: 0x1431e9e10 | Name: _RBX::Network::Replicator::StatsItem::writeServerScriptProfilingData_::_1_::dtor$2
void __fastcall RBX::Network::Replicator::StatsItem::writeServerScriptProfilingData_::_1_::dtor_2(
        __int64 a1,
        __int64 a2)
{
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)(a2 + 96)); /*0x1431e9e17*/
}

// Address: 0x1431e9e20 | Name: _RBX::Network::Replicator::doParallelPhysicsReceive_::_1_::catch$8
__int64 __fastcall RBX::Network::Replicator::doParallelPhysicsReceive_::_1_::catch_8(__int64 a1, __int64 a2)
{
  __int64 v3; // rcx
  int v4; // ebx
  int v5; // edi
  const char *v6; // rax
  std::vector<RBX::Network::Replicator::MotorAnglesPerPrimitive> *v7; // rcx

  if ( FLog::Network != 0 )
  {
    v3 = **(_QWORD **)(a2 + 216); /*0x1431e9e3f*/
    v4 = **(unsigned __int8 **)(v3 + 56); /*0x1431e9e46*/
    v5 = *(_DWORD *)(v3 + 52); /*0x1431e9e49*/
    v6 = (const char *)(*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)(a2 + 48) + 8LL))(a1: *(_QWORD *)(a2 + 48)); /*0x1431e9e53*/
    FLog::FastLogFormatted(
      level: FLog::Network,
      message: "[FLog::Network] Error while (parallel) processing physics packet (ignored): %s (Packet size: %d, packet type: %d)\n",
      v6,
      v5,
      v4);
  }
  v7 = (std::vector<RBX::Network::Replicator::MotorAnglesPerPrimitive> *)(*(_QWORD *)(a2 + 56) + 7712LL); /*0x1431e9e77*/
  if ( v7->_Mypair._Myval2._Myfirst != *(RBX::Network::Replicator::MotorAnglesPerPrimitive **)(*(_QWORD *)(a2 + 56) /*0x1431e9e8a*/
                                                                                             + 7720LL) )
    std::vector<RBX::Network::Replicator::MotorAnglesPerPrimitive>::pop_back(this: v7); /*0x1431e9e8c*/
  return 0; /*0x1431e9e9c*/
}

// Address: 0x1431e9f10 | Name: _RBX::Network::Replicator::enableDeserializePacketsJob_::_1_::dtor$0
void __fastcall RBX::Network::Replicator::enableDeserializePacketsJob_::_1_::dtor_0(__int64 a1, __int64 a2)
{
  operator delete(ptr: *(void **)(a2 + 240)); /*0x1431e9f25*/
}

// Address: 0x1431e9f30 | Name: _RBX::Network::Replicator::enableDeserializePacketsJob_::_1_::dtor$1
void __fastcall RBX::Network::Replicator::enableDeserializePacketsJob_::_1_::dtor_1(__int64 a1, __int64 a2)
{
  rbx::implementation::timestamped_safe_queue_item<RBX::Network::ProcessingPacket>::~timestamped_safe_queue_item<RBX::Network::ProcessingPacket>(this: (RBX::Network::ProcessingPacket *)(a2 + 112)); /*0x1431e9f37*/
}

// Address: 0x1431e9f40 | Name: _RBX::Network::Replicator::enableDeserializePacketsJob_::_1_::dtor$3
void __fastcall RBX::Network::Replicator::enableDeserializePacketsJob_::_1_::dtor_3(
        __int64 a1,
        boost::detail::spinlock::scoped_lock *a2)
{
  rbx::spin_mutex::scoped_lock::~scoped_lock(this: a2 + 30); /*0x1431e9f47*/
}

// Address: 0x1431e9f50 | Name: _RBX::Network::MegaReplicator::getDefault_::_1_::dtor$1
void __fastcall RBX::Network::MegaReplicator::getDefault_::_1_::dtor_1(__int64 a1, __int64 a2)
{
  RBX::Security::Impersonator::~Impersonator(this: (RBX::Security::Impersonator *)(a2 + 112)); /*0x1431e9f57*/
}

// Address: 0x1431e9f70 | Name: _RBX::Network::Replicator::handlePropertyChanged_::_1_::dtor$0
void __fastcall RBX::Network::Replicator::handlePropertyChanged_::_1_::dtor_0(__int64 a1, __int64 a2)
{
  RBX::AutoMemPool::Object::operator delete(p: *(void **)(a2 + 128), pool: *(RBX::AutoMemPool **)(a2 + 136)); /*0x1431e9f87*/
}

// Address: 0x1431e9fa0 | Name: _RBX::Network::Replicator::handlePropertyChanged_::_1_::dtor$5
void __fastcall RBX::Network::Replicator::handlePropertyChanged_::_1_::dtor_5(__int64 a1, __int64 a2)
{
  RBX::AutoMemPool::Object::operator delete(p: *(void **)(a2 + 128), pool: *(RBX::AutoMemPool **)(a2 + 144)); /*0x1431e9fb7*/
}

// Address: 0x1431e9fd0 | Name: _RBX::Network::Replicator::initializeClusterReplicationData_::_1_::dtor$7
void __fastcall RBX::Network::Replicator::initializeClusterReplicationData_::_1_::dtor_7(__int64 a1, __int64 a2)
{
  if ( (*(_DWORD *)(a2 + 192) & 1) != 0 ) /*0x1431e9fe4*/
  {
    *(_DWORD *)(a2 + 192) &= ~1u; /*0x1431e9fe6*/
    rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)(a2 + 200)); /*0x1431e9ff4*/
  }
}

// Address: 0x1431ea040 | Name: _RBX::Network::Replicator::onServiceProvider_::_1_::dtor$1
void RBX::Network::Replicator::onServiceProvider_::_1_::dtor_1()
{
  Init_thread_abort(pOnce: &_TSS0_526); /*0x1431ea047*/
}

// Address: 0x1431ea050 | Name: _RBX::Network::Replicator::onServiceProvider_::_1_::dtor$2
void __fastcall RBX::Network::Replicator::onServiceProvider_::_1_::dtor_2(__int64 a1, RBX::Profiler::Scope *a2)
{
  RBX::Profiler::Scope::~Scope(this: a2 + 56); /*0x1431ea057*/
}

// Address: 0x1431ea060 | Name: _RBX::Network::Replicator::onServiceProvider_::_1_::dtor$6
void __fastcall RBX::Network::Replicator::onServiceProvider_::_1_::dtor_6(__int64 a1, __int64 a2)
{
  operator delete(ptr: *(void **)(a2 + 1728)); /*0x1431ea075*/
}

// Address: 0x1431ea080 | Name: _RBX::Network::Replicator::onServiceProvider_::_1_::dtor$8
void __fastcall RBX::Network::Replicator::onServiceProvider_::_1_::dtor_8(__int64 a1, __int64 a2)
{
  operator delete(ptr: *(void **)(a2 + 1728)); /*0x1431ea095*/
}

// Address: 0x1431ea0a0 | Name: _RBX::Network::Replicator::onServiceProvider_::_1_::dtor$11
void __fastcall RBX::Network::Replicator::onServiceProvider_::_1_::dtor_11(__int64 a1, __int64 a2)
{
  operator delete(ptr: *(void **)(a2 + 1728)); /*0x1431ea0b5*/
}

// Address: 0x1431ea0c0 | Name: _RBX::Network::Replicator::onServiceProvider_::_1_::dtor$16
void __fastcall RBX::Network::Replicator::onServiceProvider_::_1_::dtor_16(__int64 a1, __int64 a2)
{
  std::pair<Luau::Location,std::shared_ptr<Luau::Scope>>::~pair<Luau::Location,std::shared_ptr<Luau::Scope>>(this: (std::pair<Luau::Location,std::shared_ptr<Luau::Scope> > *)(a2 + 1200)); /*0x1431ea0c7*/
}

// Address: 0x1431ea0e0 | Name: _RBX::Network::Replicator::onServiceProvider_::_1_::dtor$29
void __fastcall RBX::Network::Replicator::onServiceProvider_::_1_::dtor_29(__int64 a1, __int64 a2)
{
  RBX::Analytics::InfluxDb::Points::~Points(this: (RBX::Analytics::InfluxDb::Points *)(a2 + 1088)); /*0x1431ea0e7*/
}

// Address: 0x1431ea0f0 | Name: _RBX::Network::Replicator::onServiceProvider_::_1_::dtor$38
void __fastcall RBX::Network::Replicator::onServiceProvider_::_1_::dtor_38(__int64 a1, __int64 a2)
{
  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: *(std::shared_ptr<RBX::File> **)(a2 + 1728)); /*0x1431ea0f7*/
}

// Address: 0x1431ea100 | Name: _RBX::Network::Replicator::onServiceProvider_::_1_::dtor$63
void __fastcall RBX::Network::Replicator::onServiceProvider_::_1_::dtor_63(__int64 a1, __int64 a2)
{
  RBX::Network::ReplicatorJob::~ReplicatorJob(this: *(RBX::Network::ReplicatorJob **)(a2 + 1728)); /*0x1431ea107*/
}

// Address: 0x1431ea110 | Name: _RBX::Network::Replicator::onServiceProvider_::_1_::dtor$53
void __fastcall RBX::Network::Replicator::onServiceProvider_::_1_::dtor_53(
        __int64 a1,
        std::_Temporary_owner<RBX::Graphics::TextureVulkan::DownloadBuffer> *a2)
{
  RBX::BulletWedgeShapeWrapper::~BulletWedgeShapeWrapper(this: a2 + 89); /*0x1431ea117*/
}

// Address: 0x1431ea120 | Name: _RBX::Network::Replicator::onServiceProvider_::_1_::dtor$58
void __fastcall RBX::Network::Replicator::onServiceProvider_::_1_::dtor_58(
        __int64 a1,
        std::_Temporary_owner<RBX::Graphics::TextureVulkan::DownloadBuffer> *a2)
{
  RBX::BulletWedgeShapeWrapper::~BulletWedgeShapeWrapper(this: a2 + 90); /*0x1431ea127*/
}

// Address: 0x1431ea130 | Name: _RBX::Network::Replicator::onServiceProvider_::_1_::dtor$64
void __fastcall RBX::Network::Replicator::onServiceProvider_::_1_::dtor_64(
        __int64 a1,
        std::_Temporary_owner<RBX::Graphics::TextureVulkan::DownloadBuffer> *a2)
{
  RBX::BulletWedgeShapeWrapper::~BulletWedgeShapeWrapper(this: a2 + 91); /*0x1431ea137*/
}

// Address: 0x1431ea140 | Name: _RBX::Network::Replicator::onServiceProvider_::_1_::dtor$83
void __fastcall RBX::Network::Replicator::onServiceProvider_::_1_::dtor_83(
        __int64 a1,
        RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> *a2)
{
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: a2 + 430); /*0x1431ea147*/
}

// Address: 0x1431ea150 | Name: _RBX::Network::Replicator::onServiceProvider_::_1_::dtor$85
void __fastcall RBX::Network::Replicator::onServiceProvider_::_1_::dtor_85(__int64 a1, __int64 a2)
{
  if ( (*(_DWORD *)(a2 + 1712) & 0x400) != 0 ) /*0x1431ea166*/
  {
    *(_DWORD *)(a2 + 1712) &= ~0x400u; /*0x1431ea168*/
    rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)(a2 + 1736)); /*0x1431ea179*/
  }
}

// Address: 0x1431ea1a0 | Name: _RBX::Network::Replicator::onServiceProvider_::_1_::dtor$149
void __fastcall RBX::Network::Replicator::onServiceProvider_::_1_::dtor_149(__int64 a1, __int64 a2)
{
  RBX::DenseSet<RBX::Soundscape::NonBlockingFmodSoundLoader *,RBX::DenseMapInfo<RBX::Soundscape::NonBlockingFmodSoundLoader *>>::~DenseSet<RBX::Soundscape::NonBlockingFmodSoundLoader *,RBX::DenseMapInfo<RBX::Soundscape::NonBlockingFmodSoundLoader *>>(this: *(AP4_BitWriter **)(a2 + 1720)); /*0x1431ea1a7*/
}

// Address: 0x1431ea1b0 | Name: _RBX::Network::Replicator::onServiceProvider_::_1_::dtor$151
void __fastcall RBX::Network::Replicator::onServiceProvider_::_1_::dtor_151(
        __int64 a1,
        std::unique_ptr<webrtc::QualityScaler::QpSmoother> *a2)
{
  std::unique_ptr<webrtc::StreamSynchronization>::~unique_ptr<webrtc::StreamSynchronization>(this: a2 + 42); /*0x1431ea1b7*/
}

// Address: 0x1431ea1f0 | Name: _RBX::Network::Replicator::processDataPing_::_1_::dtor$8
void __fastcall RBX::Network::Replicator::processDataPing_::_1_::dtor_8(__int64 a1, __int64 a2)
{
  RBX::AutoMemPool::Object::operator delete(p: *(void **)(a2 + 528), pool: *(RBX::AutoMemPool **)(a2 + 520)); /*0x1431ea207*/
}

// Address: 0x1431ea220 | Name: _RBX::Network::Replicator::processDeserializedItemInOrder_deprecated_::_1_::dtor$0
void __fastcall RBX::Network::Replicator::processDeserializedItemInOrder_deprecated_::_1_::dtor_0(
        __int64 a1,
        __int64 a2)
{
  RBX::UnboundedCircularBuffer<RBX::Network::DeserializedNewInstanceItem>::~UnboundedCircularBuffer<RBX::Network::DeserializedNewInstanceItem>(this: (RBX::UnboundedCircularBuffer<RBX::Network::DeserializedNewInstanceItem> *)(a2 + 48)); /*0x1431ea227*/
}

// Address: 0x1431ea230 | Name: _RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::readAnInstance_::_1_::dtor$2
void __fastcall RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::readAnInstance_::_1_::dtor_2(
        __int64 a1,
        __int64 a2)
{
  RBX::Network::DeserializedNewInstanceItem::~DeserializedNewInstanceItem(this: (RBX::Network::DeserializedNewInstanceItem *)(a2 + 80)); /*0x1431ea237*/
}

// Address: 0x1431ea240 | Name: _RBX::Network::Replicator::processDeserializedJoinDataItem_::_1_::dtor$2
void __fastcall RBX::Network::Replicator::processDeserializedJoinDataItem_::_1_::dtor_2(__int64 a1, __int64 a2)
{
  std::queue<std::vector<RBX::Network::DeserializedNewInstanceItem>>::~queue<std::vector<RBX::Network::DeserializedNewInstanceItem>,std::deque<std::vector<RBX::Network::DeserializedNewInstanceItem>>>(this: (std::queue<std::vector<RBX::Network::DeserializedNewInstanceItem>> *)(a2 + 48)); /*0x1431ea247*/
}

// Address: 0x1431ea260 | Name: _RBX::Network::DeserializePacketsJob::stepGranular_::_1_::dtor$18
void __fastcall RBX::Network::DeserializePacketsJob::stepGranular_::_1_::dtor_18(__int64 a1, __int64 a2)
{
  rbx::implementation::timestamped_safe_queue_item<RBX::Network::ProcessingPacket>::~timestamped_safe_queue_item<RBX::Network::ProcessingPacket>(this: (RBX::Network::ProcessingPacket *)(a2 + 80)); /*0x1431ea267*/
}

// Address: 0x1431ea270 | Name: _RBX::Network::Replicator::processNextIncomingPacket_deprecated_::_1_::catch$48
__int64 __fastcall RBX::Network::Replicator::processNextIncomingPacket_deprecated_::_1_::catch_48(
        __int64 a1,
        __int64 a2)
{
  const char *v3; // rax
  unsigned __int64 v4; // r8
  RakNet::Packet *v5; // rdi
  RBX::Network::Replicator *v6; // rbx
  unsigned __int64 v7; // rdx
  _QWORD *v8; // rcx
  unsigned __int64 v9; // rdx
  _QWORD *v10; // rcx

  v3 = (const char *)(*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)(a2 + 176) + 8LL))(a1: *(_QWORD *)(a2 + 176)); /*0x1431ea289*/
  *(_QWORD *)(a2 + 128) = 0; /*0x1431ea28c*/
  *(_QWORD *)(a2 + 144) = 0; /*0x1431ea297*/
  *(_QWORD *)(a2 + 152) = 15; /*0x1431ea2a2*/
  *(_BYTE *)(a2 + 128) = 0; /*0x1431ea2ad*/
  v4 = -1; /*0x1431ea2b4*/
  do /*0x1431ea2c8*/
    ++v4; /*0x1431ea2c0*/
  while ( v3[v4] != 0 ); /*0x1431ea2c8*/
  std::string::assign(this: (std::string *)(a2 + 128), _Ptr: v3, _Count: v4); /*0x1431ea2d4*/
  *(_QWORD *)(a2 + 48) = 0; /*0x1431ea2da*/
  *(_QWORD *)(a2 + 72) = 15; /*0x1431ea2e2*/
  *(_BYTE *)(a2 + 48) = 0; /*0x1431ea2ea*/
  *(_QWORD *)(a2 + 64) = 10; /*0x1431ea2ee*/
  memmove_0(a1: (void *)(a2 + 48), Src: "OutOfRange", Size: 0xAu); /*0x1431ea307*/
  *(_BYTE *)(a2 + 58) = 0; /*0x1431ea30c*/
  v5 = *(RakNet::Packet **)(a2 + 304); /*0x1431ea31b*/
  v6 = *(RBX::Network::Replicator **)(a2 + 288); /*0x1431ea325*/
  RBX::Network::Replicator::logPacketError( /*0x1431ea32f*/
    this: v6,
    packet: v5,
    type: (const std::string *)(a2 + 48),
    message: (const std::string *)(a2 + 128));
  v7 = *(_QWORD *)(a2 + 72); /*0x1431ea335*/
  if ( v7 >= 0x10 ) /*0x1431ea342*/
  {
    v8 = *(_QWORD **)(a2 + 48); /*0x1431ea347*/
    if ( v7 + 1 >= 0x1000 ) /*0x1431ea352*/
    {
      if ( (unsigned __int64)v8 - *(v8 - 1) - 8 > 0x1F ) /*0x1431ea367*/
        _invalid_parameter_noinfo_noreturn(); /*0x1431ea36e*/
      v8 = (_QWORD *)*(v8 - 1); /*0x1431ea369*/
    }
    operator delete(ptr: v8); /*0x1431ea375*/
  }
  *(_QWORD *)(a2 + 64) = 0; /*0x1431ea37a*/
  *(_QWORD *)(a2 + 72) = 15; /*0x1431ea382*/
  *(_BYTE *)(a2 + 48) = 0; /*0x1431ea38a*/
  v9 = *(_QWORD *)(a2 + 152); /*0x1431ea38e*/
  if ( v9 >= 0x10 ) /*0x1431ea39e*/
  {
    v10 = *(_QWORD **)(a2 + 128); /*0x1431ea3a3*/
    if ( v9 + 1 >= 0x1000 ) /*0x1431ea3b1*/
    {
      if ( (unsigned __int64)v10 - *(v10 - 1) - 8 > 0x1F ) /*0x1431ea3c6*/
        _invalid_parameter_noinfo_noreturn(); /*0x1431ea3cd*/
      v10 = (_QWORD *)*(v10 - 1); /*0x1431ea3c8*/
    }
    operator delete(ptr: v10); /*0x1431ea3d4*/
  }
  v6->rakPeer._Ptr->peer._Ptr->DeallocatePacket(this: v6->rakPeer._Ptr->peer._Ptr, a2: v5); /*0x1431ea3e9*/
  RBX::Network::Replicator::requestDisconnectWithSignal(this: v6, reason: 260); /*0x1431ea3f7*/
  return 0; /*0x1431ea407*/
}

// Address: 0x1431ea410 | Name: _RBX::Network::Replicator::processNextIncomingPacket_deprecated_::_1_::catch$49
__int64 __fastcall RBX::Network::Replicator::processNextIncomingPacket_deprecated_::_1_::catch_49(
        __int64 a1,
        __int64 a2)
{
  const char *v3; // rax
  unsigned __int64 v4; // r8
  RakNet::Packet *v5; // rdi
  RBX::Network::Replicator *v6; // rbx
  unsigned __int64 v7; // rdx
  _QWORD *v8; // rcx
  unsigned __int64 v9; // rdx
  _QWORD *v10; // rcx

  v3 = (const char *)(*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)(a2 + 184) + 8LL))(a1: *(_QWORD *)(a2 + 184)); /*0x1431ea429*/
  *(_QWORD *)(a2 + 128) = 0; /*0x1431ea42c*/
  *(_QWORD *)(a2 + 144) = 0; /*0x1431ea437*/
  *(_QWORD *)(a2 + 152) = 15; /*0x1431ea442*/
  *(_BYTE *)(a2 + 128) = 0; /*0x1431ea44d*/
  v4 = -1; /*0x1431ea454*/
  do /*0x1431ea468*/
    ++v4; /*0x1431ea460*/
  while ( v3[v4] != 0 ); /*0x1431ea468*/
  std::string::assign(this: (std::string *)(a2 + 128), _Ptr: v3, _Count: v4); /*0x1431ea474*/
  *(_QWORD *)(a2 + 48) = 0; /*0x1431ea47a*/
  *(_QWORD *)(a2 + 72) = 15; /*0x1431ea482*/
  *(_BYTE *)(a2 + 48) = 0; /*0x1431ea48a*/
  *(_QWORD *)(a2 + 64) = 7; /*0x1431ea48e*/
  memmove_0(a1: (void *)(a2 + 48), Src: "BadCast", Size: 7u); /*0x1431ea4a7*/
  *(_BYTE *)(a2 + 55) = 0; /*0x1431ea4ac*/
  v5 = *(RakNet::Packet **)(a2 + 304); /*0x1431ea4bb*/
  v6 = *(RBX::Network::Replicator **)(a2 + 288); /*0x1431ea4c5*/
  RBX::Network::Replicator::logPacketError( /*0x1431ea4cf*/
    this: v6,
    packet: v5,
    type: (const std::string *)(a2 + 48),
    message: (const std::string *)(a2 + 128));
  v7 = *(_QWORD *)(a2 + 72); /*0x1431ea4d5*/
  if ( v7 >= 0x10 ) /*0x1431ea4e2*/
  {
    v8 = *(_QWORD **)(a2 + 48); /*0x1431ea4e7*/
    if ( v7 + 1 >= 0x1000 ) /*0x1431ea4f2*/
    {
      if ( (unsigned __int64)v8 - *(v8 - 1) - 8 > 0x1F ) /*0x1431ea507*/
        _invalid_parameter_noinfo_noreturn(); /*0x1431ea50e*/
      v8 = (_QWORD *)*(v8 - 1); /*0x1431ea509*/
    }
    operator delete(ptr: v8); /*0x1431ea515*/
  }
  *(_QWORD *)(a2 + 64) = 0; /*0x1431ea51a*/
  *(_QWORD *)(a2 + 72) = 15; /*0x1431ea522*/
  *(_BYTE *)(a2 + 48) = 0; /*0x1431ea52a*/
  v9 = *(_QWORD *)(a2 + 152); /*0x1431ea52e*/
  if ( v9 >= 0x10 ) /*0x1431ea53e*/
  {
    v10 = *(_QWORD **)(a2 + 128); /*0x1431ea543*/
    if ( v9 + 1 >= 0x1000 ) /*0x1431ea551*/
    {
      if ( (unsigned __int64)v10 - *(v10 - 1) - 8 > 0x1F ) /*0x1431ea566*/
        _invalid_parameter_noinfo_noreturn(); /*0x1431ea56d*/
      v10 = (_QWORD *)*(v10 - 1); /*0x1431ea568*/
    }
    operator delete(ptr: v10); /*0x1431ea574*/
  }
  v6->rakPeer._Ptr->peer._Ptr->DeallocatePacket(this: v6->rakPeer._Ptr->peer._Ptr, a2: v5); /*0x1431ea589*/
  RBX::Network::Replicator::requestDisconnectWithSignal(this: v6, reason: 260); /*0x1431ea597*/
  return 0; /*0x1431ea5a7*/
}

// Address: 0x1431ea5b0 | Name: _RBX::Network::Replicator::processNextIncomingPacket_deprecated_::_1_::catch$50
__int64 __fastcall RBX::Network::Replicator::processNextIncomingPacket_deprecated_::_1_::catch_50(
        __int64 a1,
        __int64 a2)
{
  __int64 v3; // rcx
  int v4; // ebx
  int v5; // edi
  const char *v6; // rax
  __int64 v7; // rax

  if ( FLog::Network != 0 )
  {
    v3 = *(_QWORD *)(a2 + 304); /*0x1431ea5c8*/
    v4 = **(unsigned __int8 **)(v3 + 56); /*0x1431ea5d3*/
    v5 = *(_DWORD *)(v3 + 52); /*0x1431ea5d6*/
    v6 = (const char *)(*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)(a2 + 192) + 8LL))(a1: *(_QWORD *)(a2 + 192)); /*0x1431ea5e3*/
    FLog::FastLogFormatted(
      level: FLog::Network,
      message: "[FLog::Network] Error while processing physics packet (ignored): %s (Packet size: %d, packet type: %d)\n",
      v6,
      v5,
      v4);
  }
  v7 = *(_QWORD *)(a2 + 288); /*0x1431ea603*/
  *(_QWORD *)(v7 + 10936) = 0; /*0x1431ea60a*/
  *(_QWORD *)(v7 + 10944) = 0; /*0x1431ea615*/
  return 0; /*0x1431ea62a*/
}

// Address: 0x1431ea640 | Name: _RBX::Network::Replicator::processNextIncomingPacket_deprecated_::_1_::catch$51
__int64 __fastcall RBX::Network::Replicator::processNextIncomingPacket_deprecated_::_1_::catch_51(
        __int64 a1,
        __int64 a2)
{
  const char *v3; // rax
  unsigned __int64 v4; // r8
  RakNet::Packet *v5; // rdi
  RBX::Network::Replicator *v6; // rbx
  unsigned __int64 v7; // rdx
  _QWORD *v8; // rcx
  unsigned __int64 v9; // rdx
  _QWORD *v10; // rcx

  v3 = (const char *)(*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)(a2 + 200) + 8LL))(a1: *(_QWORD *)(a2 + 200)); /*0x1431ea659*/
  *(_QWORD *)(a2 + 128) = 0; /*0x1431ea65c*/
  *(_QWORD *)(a2 + 144) = 0; /*0x1431ea667*/
  *(_QWORD *)(a2 + 152) = 15; /*0x1431ea672*/
  *(_BYTE *)(a2 + 128) = 0; /*0x1431ea67d*/
  v4 = -1; /*0x1431ea684*/
  do /*0x1431ea698*/
    ++v4; /*0x1431ea690*/
  while ( v3[v4] != 0 ); /*0x1431ea698*/
  std::string::assign(this: (std::string *)(a2 + 128), _Ptr: v3, _Count: v4); /*0x1431ea6a4*/
  *(_QWORD *)(a2 + 48) = 0; /*0x1431ea6aa*/
  *(_QWORD *)(a2 + 72) = 15; /*0x1431ea6b2*/
  *(_BYTE *)(a2 + 48) = 0; /*0x1431ea6ba*/
  *(_QWORD *)(a2 + 64) = 6; /*0x1431ea6be*/
  memmove_0(a1: (void *)(a2 + 48), Src: "Stream", Size: 6u); /*0x1431ea6d7*/
  *(_BYTE *)(a2 + 54) = 0; /*0x1431ea6dc*/
  v5 = *(RakNet::Packet **)(a2 + 304); /*0x1431ea6eb*/
  v6 = *(RBX::Network::Replicator **)(a2 + 288); /*0x1431ea6f5*/
  RBX::Network::Replicator::logPacketError( /*0x1431ea6ff*/
    this: v6,
    packet: v5,
    type: (const std::string *)(a2 + 48),
    message: (const std::string *)(a2 + 128));
  v7 = *(_QWORD *)(a2 + 72); /*0x1431ea705*/
  if ( v7 >= 0x10 ) /*0x1431ea712*/
  {
    v8 = *(_QWORD **)(a2 + 48); /*0x1431ea717*/
    if ( v7 + 1 >= 0x1000 ) /*0x1431ea722*/
    {
      if ( (unsigned __int64)v8 - *(v8 - 1) - 8 > 0x1F ) /*0x1431ea737*/
        _invalid_parameter_noinfo_noreturn(); /*0x1431ea73e*/
      v8 = (_QWORD *)*(v8 - 1); /*0x1431ea739*/
    }
    operator delete(ptr: v8); /*0x1431ea745*/
  }
  *(_QWORD *)(a2 + 64) = 0; /*0x1431ea74a*/
  *(_QWORD *)(a2 + 72) = 15; /*0x1431ea752*/
  *(_BYTE *)(a2 + 48) = 0; /*0x1431ea75a*/
  v9 = *(_QWORD *)(a2 + 152); /*0x1431ea75e*/
  if ( v9 >= 0x10 ) /*0x1431ea76e*/
  {
    v10 = *(_QWORD **)(a2 + 128); /*0x1431ea773*/
    if ( v9 + 1 >= 0x1000 ) /*0x1431ea781*/
    {
      if ( (unsigned __int64)v10 - *(v10 - 1) - 8 > 0x1F ) /*0x1431ea796*/
        _invalid_parameter_noinfo_noreturn(); /*0x1431ea79d*/
      v10 = (_QWORD *)*(v10 - 1); /*0x1431ea798*/
    }
    operator delete(ptr: v10); /*0x1431ea7a4*/
  }
  v6->rakPeer._Ptr->peer._Ptr->DeallocatePacket(this: v6->rakPeer._Ptr->peer._Ptr, a2: v5); /*0x1431ea7b9*/
  RBX::Network::Replicator::requestDisconnectWithSignal(this: v6, reason: 261); /*0x1431ea7c7*/
  return 0; /*0x1431ea7d7*/
}

// Address: 0x1431ea7e0 | Name: _RBX::Network::Replicator::processNextIncomingPacket_deprecated_::_1_::catch$52
__int64 __fastcall RBX::Network::Replicator::processNextIncomingPacket_deprecated_::_1_::catch_52(
        __int64 a1,
        __int64 a2)
{
  const char *v3; // rax
  unsigned __int64 v4; // r8
  RakNet::Packet *v5; // rdi
  RBX::Network::Replicator *v6; // rbx
  unsigned __int64 v7; // rdx
  _QWORD *v8; // rcx
  unsigned __int64 v9; // rdx
  _QWORD *v10; // rcx

  v3 = (const char *)(*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)(a2 + 208) + 8LL))(a1: *(_QWORD *)(a2 + 208)); /*0x1431ea7f9*/
  *(_QWORD *)(a2 + 128) = 0; /*0x1431ea7fc*/
  *(_QWORD *)(a2 + 144) = 0; /*0x1431ea807*/
  *(_QWORD *)(a2 + 152) = 15; /*0x1431ea812*/
  *(_BYTE *)(a2 + 128) = 0; /*0x1431ea81d*/
  v4 = -1; /*0x1431ea824*/
  do /*0x1431ea838*/
    ++v4; /*0x1431ea830*/
  while ( v3[v4] != 0 ); /*0x1431ea838*/
  std::string::assign(this: (std::string *)(a2 + 128), _Ptr: v3, _Count: v4); /*0x1431ea844*/
  *(_QWORD *)(a2 + 48) = 0; /*0x1431ea84a*/
  *(_QWORD *)(a2 + 64) = 0; /*0x1431ea852*/
  *(_QWORD *)(a2 + 72) = 15; /*0x1431ea85a*/
  *(_BYTE *)(a2 + 48) = 0; /*0x1431ea862*/
  std::string::assign(this: (std::string *)(a2 + 48), _Ptr: "Other", _Count: 5u); /*0x1431ea877*/
  v5 = *(RakNet::Packet **)(a2 + 304); /*0x1431ea888*/
  v6 = *(RBX::Network::Replicator **)(a2 + 288); /*0x1431ea892*/
  RBX::Network::Replicator::logPacketError( /*0x1431ea89c*/
    this: v6,
    packet: v5,
    type: (const std::string *)(a2 + 48),
    message: (const std::string *)(a2 + 128));
  v7 = *(_QWORD *)(a2 + 72); /*0x1431ea8a2*/
  if ( v7 >= 0x10 ) /*0x1431ea8af*/
  {
    v8 = *(_QWORD **)(a2 + 48); /*0x1431ea8b4*/
    if ( v7 + 1 >= 0x1000 ) /*0x1431ea8bf*/
    {
      if ( (unsigned __int64)v8 - *(v8 - 1) - 8 > 0x1F ) /*0x1431ea8d4*/
        _invalid_parameter_noinfo_noreturn(); /*0x1431ea8db*/
      v8 = (_QWORD *)*(v8 - 1); /*0x1431ea8d6*/
    }
    operator delete(ptr: v8); /*0x1431ea8e2*/
  }
  *(_QWORD *)(a2 + 64) = 0; /*0x1431ea8e7*/
  *(_QWORD *)(a2 + 72) = 15; /*0x1431ea8ef*/
  *(_BYTE *)(a2 + 48) = 0; /*0x1431ea8f7*/
  v9 = *(_QWORD *)(a2 + 152); /*0x1431ea8fb*/
  if ( v9 >= 0x10 ) /*0x1431ea90b*/
  {
    v10 = *(_QWORD **)(a2 + 128); /*0x1431ea910*/
    if ( v9 + 1 >= 0x1000 ) /*0x1431ea91e*/
    {
      if ( (unsigned __int64)v10 - *(v10 - 1) - 8 > 0x1F ) /*0x1431ea933*/
        _invalid_parameter_noinfo_noreturn(); /*0x1431ea93a*/
      v10 = (_QWORD *)*(v10 - 1); /*0x1431ea935*/
    }
    operator delete(ptr: v10); /*0x1431ea941*/
  }
  v6->rakPeer._Ptr->peer._Ptr->DeallocatePacket(this: v6->rakPeer._Ptr->peer._Ptr, a2: v5); /*0x1431ea956*/
  RBX::Network::Replicator::requestDisconnectWithSignal(this: v6, reason: 260); /*0x1431ea964*/
  return 0; /*0x1431ea974*/
}

// Address: 0x1431ea980 | Name: _RBX::Network::Replicator::processNextIncomingPacket_new_::_1_::catch$2
__int64 __fastcall RBX::Network::Replicator::processNextIncomingPacket_new_::_1_::catch_2(__int64 a1, __int64 a2)
{
  const char *v3; // rax

  v3 = (const char *)(*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)(a2 + 120) + 8LL))(a1: *(_QWORD *)(a2 + 120)); /*0x1431ea994*/
  *(_BYTE *)(a2 + 192) = RBX::Network::Replicator::processNextIncomingPacketError( /*0x1431ea9b3*/
                           this: *(RBX::Network::Replicator **)(a2 + 192),
                           msg: "OutOfRange",
                           what: v3,
                           code: 260);
  return 0; /*0x1431ea9c3*/
}

// Address: 0x1431ea9d0 | Name: _RBX::Network::Replicator::processNextIncomingPacket_new_::_1_::catch$3
__int64 __fastcall RBX::Network::Replicator::processNextIncomingPacket_new_::_1_::catch_3(__int64 a1, __int64 a2)
{
  const char *v3; // rax

  v3 = (const char *)(*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)(a2 + 128) + 8LL))(a1: *(_QWORD *)(a2 + 128)); /*0x1431ea9e7*/
  *(_BYTE *)(a2 + 192) = RBX::Network::Replicator::processNextIncomingPacketError( /*0x1431eaa06*/
                           this: *(RBX::Network::Replicator **)(a2 + 192),
                           msg: "BadCast",
                           what: v3,
                           code: 260);
  return 0; /*0x1431eaa16*/
}

// Address: 0x1431eaa20 | Name: _RBX::Network::Replicator::processNextIncomingPacket_new_::_1_::catch$4
__int64 __fastcall RBX::Network::Replicator::processNextIncomingPacket_new_::_1_::catch_4(__int64 a1, __int64 a2)
{
  __int64 v2; // rsi
  __int64 v3; // rcx
  int v4; // ebx
  int v5; // edi
  const char *v6; // rax

  v2 = *(_QWORD *)(a2 + 192); /*0x1431eaa30*/
  if ( FLog::Network != 0 )
  {
    v3 = *(_QWORD *)(v2 + 7856); /*0x1431eaa40*/
    v4 = **(unsigned __int8 **)(v3 + 56); /*0x1431eaa4b*/
    v5 = *(_DWORD *)(v3 + 52); /*0x1431eaa4e*/
    v6 = (const char *)(*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)(a2 + 136) + 8LL))(a1: *(_QWORD *)(a2 + 136)); /*0x1431eaa5b*/
    FLog::FastLogFormatted(
      level: FLog::Network,
      message: "[FLog::Network] Error while processing physics packet (ignored): %s (Packet size: %d, packet type: %d)\n",
      v6,
      v5,
      v4);
  }
  RBX::Network::ProcessingPacket::markFinished(this: (RBX::Network::ProcessingPacket *)(v2 + 7856)); /*0x1431eaa82*/
  return 0; /*0x1431eaa92*/
}

// Address: 0x1431eaaa0 | Name: _RBX::Network::Replicator::processNextIncomingPacket_new_::_1_::catch$5
__int64 __fastcall RBX::Network::Replicator::processNextIncomingPacket_new_::_1_::catch_5(__int64 a1, __int64 a2)
{
  const char *v3; // rax

  v3 = (const char *)(*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)(a2 + 144) + 8LL))(a1: *(_QWORD *)(a2 + 144)); /*0x1431eaab7*/
  *(_BYTE *)(a2 + 192) = RBX::Network::Replicator::processNextIncomingPacketError( /*0x1431eaad6*/
                           this: *(RBX::Network::Replicator **)(a2 + 192),
                           msg: "Stream",
                           what: v3,
                           code: 261);
  return 0; /*0x1431eaae6*/
}

// Address: 0x1431eaaf0 | Name: _RBX::Network::Replicator::processNextIncomingPacket_new_::_1_::catch$6
__int64 __fastcall RBX::Network::Replicator::processNextIncomingPacket_new_::_1_::catch_6(__int64 a1, __int64 a2)
{
  const char *v3; // rax

  v3 = (const char *)(*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)(a2 + 152) + 8LL))(a1: *(_QWORD *)(a2 + 152)); /*0x1431eab07*/
  *(_BYTE *)(a2 + 192) = RBX::Network::Replicator::processNextIncomingPacketError( /*0x1431eab26*/
                           this: *(RBX::Network::Replicator **)(a2 + 192),
                           msg: "Other",
                           what: v3,
                           code: 260);
  return 0; /*0x1431eab36*/
}

// Address: 0x1431eab40 | Name: _RBX::Network::Replicator::processPacket_::_1_::dtor$0
void __fastcall RBX::Network::Replicator::processPacket_::_1_::dtor_0(__int64 a1, __int64 a2)
{
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)(a2 + 48)); /*0x1431eab47*/
}

// Address: 0x1431eab50 | Name: _RBX::Network::Replicator::processPacket_::_1_::catch$7
void __fastcall __noreturn RBX::Network::Replicator::processPacket_::_1_::catch_7(__int64 a1, __int64 a2)
{
  const char *v3; // rax

  v3 = (const char *)(*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)(a2 + 128) + 8LL))(a1: *(_QWORD *)(a2 + 128)); /*0x1431eab67*/
  std::string::string(this: (std::string *)(a2 + 136), _Ptr: v3); /*0x1431eab74*/
  RBX::physics_receiver_exception::physics_receiver_exception( /*0x1431eab88*/
    this: (RBX::physics_receiver_exception *)(a2 + 168),
    m: (const std::string *)(a2 + 136));
  throw (RBX::physics_receiver_exception *)(a2 + 168); /*0x1431eab9b*/
}

// Address: 0x1431eabb0 | Name: _RBX::Network::Replicator::processWorkingPacket_::_1_::dtor$1
void __fastcall RBX::Network::Replicator::processWorkingPacket_::_1_::dtor_1(__int64 a1, __int64 a2)
{
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)(a2 + 80)); /*0x1431eabb7*/
}

// Address: 0x1431eabc0 | Name: _rbx::timestamped_safe_queue_RBX::Network::ProcessingPacket_::push_::_1_::dtor$0
void __fastcall rbx::timestamped_safe_queue_RBX::Network::ProcessingPacket_::push_::_1_::dtor_0(__int64 a1, __int64 a2)
{
  rbx::implementation::timestamped_safe_queue_item<RBX::Network::ProcessingPacket>::~timestamped_safe_queue_item<RBX::Network::ProcessingPacket>(this: (RBX::Network::ProcessingPacket *)(a2 + 32)); /*0x1431eabc7*/
}

// Address: 0x1431eabe0 | Name: _RBX::Network::Replicator::pushIncomingPacket_::_1_::dtor$0
void __fastcall RBX::Network::Replicator::pushIncomingPacket_::_1_::dtor_0(
        __int64 a1,
        RBX::Network::ProcessingPacket *a2)
{
  rbx::implementation::timestamped_safe_queue_item<RBX::Network::ProcessingPacket>::~timestamped_safe_queue_item<RBX::Network::ProcessingPacket>(this: a2 + 1); /*0x1431eabe7*/
}

// Address: 0x1431eabf0 | Name: _RBX::UnboundedCircularBuffer_RBX::Network::DeserializedNewInstanceItem_::push_back_::_1_::dtor$0
void __fastcall RBX::UnboundedCircularBuffer_RBX::Network::DeserializedNewInstanceItem_::push_back_::_1_::dtor_0(
        __int64 a1,
        __int64 a2)
{
  RBX::Network::DeserializedNewInstanceItem::~DeserializedNewInstanceItem(this: *(RBX::Network::DeserializedNewInstanceItem **)(a2 + 104)); /*0x1431eabf7*/
}

// Address: 0x1431eac10 | Name: _RBX::Network::Replicator::queueCoalescedAnimationEvents_::_1_::dtor$2
void __fastcall RBX::Network::Replicator::queueCoalescedAnimationEvents_::_1_::dtor_2(__int64 a1, __int64 a2)
{
  operator delete(ptr: *(void **)(a2 + 440)); /*0x1431eac25*/
}

// Address: 0x1431eac30 | Name: _RBX::Network::Replicator::queueCoalescedAnimationEvents_::_1_::dtor$6
void __fastcall RBX::Network::Replicator::queueCoalescedAnimationEvents_::_1_::dtor_6(__int64 a1, __int64 a2)
{
  operator delete(ptr: *(void **)(a2 + 416)); /*0x1431eac45*/
}

// Address: 0x1431eac60 | Name: _RBX::Network::Replicator::queueCoalescedAnimationEvents_::_1_::dtor$15
void __fastcall RBX::Network::Replicator::queueCoalescedAnimationEvents_::_1_::dtor_15(__int64 a1, __int64 a2)
{
  std::_Uninitialized_backout_al<std::allocator<RBX::Reflection::Variant>>::~_Uninitialized_backout_al<std::allocator<RBX::Reflection::Variant>>(this: (std::_Uninitialized_backout_al<std::allocator<RBX::Reflection::Variant> > *)(a2 + 112)); /*0x1431eac67*/
}

// Address: 0x1431eac70 | Name: _RBX::Network::Replicator::queueCoalescedAnimationEvents_::_1_::dtor$20
void __fastcall RBX::Network::Replicator::queueCoalescedAnimationEvents_::_1_::dtor_20(
        __int64 a1,
        std::_Temporary_owner<RBX::Reflection::Tuple> *a2)
{
  std::_Temporary_owner<RBX::Reflection::Tuple>::~_Temporary_owner<RBX::Reflection::Tuple>(this: a2 + 18); /*0x1431eac77*/
}

// Address: 0x1431eac80 | Name: _RBX::Network::Replicator::readANewSharedString_::_1_::dtor$8
void __fastcall RBX::Network::Replicator::readANewSharedString_::_1_::dtor_8(
        __int64 a1,
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const ,RBX::SharedString> > > > *a2)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::SharedString>>>>::~node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::SharedString>>>>(this: a2 + 3); /*0x1431eac87*/
}

// Address: 0x1431eac90 | Name: _RBX::Network::Replicator::readChangedAttributeItem_::_1_::dtor$2
void __fastcall RBX::Network::Replicator::readChangedAttributeItem_::_1_::dtor_2(__int64 a1, __int64 a2)
{
  RBX::ScopedAssign<RBX::Network::AttributeDebounceInfo>::~ScopedAssign<RBX::Network::AttributeDebounceInfo>(this: (RBX::ScopedAssign<RBX::Network::AttributeDebounceInfo> *)(a2 + 32)); /*0x1431eac97*/
}

// Address: 0x1431eaca0 | Name: _RBX::Network::Replicator::readChangedPropertyItem_::_1_::dtor$2
void __fastcall RBX::Network::Replicator::readChangedPropertyItem_::_1_::dtor_2(__int64 a1, __int64 a2)
{
  RBX::Network::DeserializedItem::~DeserializedItem(this: (RBX::Network::DeserializedItem *)(a2 + 80)); /*0x1431eaca7*/
}

// Address: 0x1431eacb0 | Name: _RBX::Network::Replicator::readEventInvocationItem_::_1_::dtor$0
void __fastcall RBX::Network::Replicator::readEventInvocationItem_::_1_::dtor_0(
        __int64 a1,
        std::vector<RBX::Reflection::SignatureDescriptor::Argument> *a2)
{
  std::vector<RBX::Reflection::SignatureDescriptor::Argument>::~vector<RBX::Reflection::SignatureDescriptor::Argument>(this: a2 + 2); /*0x1431eacb7*/
}

// Address: 0x1431eacc0 | Name: _RBX::Network::Replicator::readEventInvocationItem_::_1_::dtor$2
void __fastcall RBX::Network::Replicator::readEventInvocationItem_::_1_::dtor_2(
        __int64 a1,
        std::_Tidy_guard<std::vector<RBX::Reflection::SignatureDescriptor::Argument> > *a2)
{
  std::_Tidy_guard<std::vector<RBX::Reflection::SignatureDescriptor::Argument>>::~_Tidy_guard<std::vector<RBX::Reflection::SignatureDescriptor::Argument>>(this: a2 + 28); /*0x1431eacc7*/
}

// Address: 0x1431eacd0 | Name: _RBX::Network::Replicator::readEventInvocationItem_::_1_::dtor$3
void __fastcall RBX::Network::Replicator::readEventInvocationItem_::_1_::dtor_3(
        __int64 a1,
        std::_Uninitialized_backout_al<std::allocator<RBX::Reflection::SignatureDescriptor::Argument> > *a2)
{
  std::_Uninitialized_backout_al<std::allocator<RBX::Reflection::SignatureDescriptor::Argument>>::~_Uninitialized_backout_al<std::allocator<RBX::Reflection::SignatureDescriptor::Argument>>(this: a2 + 3); /*0x1431eacd7*/
}

// Address: 0x1431eace0 | Name: _RBX::Network::JoinRxStats::recordJoinInstance_::_1_::dtor$0
void __fastcall RBX::Network::JoinRxStats::recordJoinInstance_::_1_::dtor_0(__int64 a1, __int64 a2)
{
  RBX::CageHSRFetchRequest::CageHSRAsset::~CageHSRAsset(this: (std::pair<RBX::Instance * const,std::shared_ptr<SearchResult> > *)(a2 + 40)); /*0x1431eace7*/
}

// Address: 0x1431ead20 | Name: _RBX::Network::Replicator::registerInstanceForDescendantTracking_::_1_::dtor$2
void __fastcall RBX::Network::Replicator::registerInstanceForDescendantTracking_::_1_::dtor_2(__int64 a1, __int64 a2)
{
  if ( (*(_DWORD *)(a2 + 296) & 2) != 0 ) /*0x1431ead34*/
  {
    *(_DWORD *)(a2 + 296) &= ~2u; /*0x1431ead36*/
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)(a2 + 88)); /*0x1431ead41*/
  }
}

// Address: 0x1431ead60 | Name: _RBX::Network::Replicator::registerInstanceForDescendantTracking_::_1_::dtor$16
void __fastcall RBX::Network::Replicator::registerInstanceForDescendantTracking_::_1_::dtor_16(__int64 a1, __int64 a2)
{
  if ( (*(_DWORD *)(a2 + 296) & 4) != 0 ) /*0x1431ead74*/
  {
    *(_DWORD *)(a2 + 296) &= ~4u; /*0x1431ead76*/
    rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)(a2 + 48)); /*0x1431ead81*/
  }
}

// Address: 0x1431ead90 | Name: _RBX::Network::Replicator::replicateEvent_::_1_::dtor$0
void __fastcall RBX::Network::Replicator::replicateEvent_::_1_::dtor_0(__int64 a1, __int64 a2)
{
  RBX::AutoMemPool::Object::operator delete(p: *(void **)(a2 + 48), pool: *(RBX::AutoMemPool **)(a2 + 112)); /*0x1431eada1*/
}

// Address: 0x1431eadb0 | Name: _RBX::Network::Replicator::reportFrameDataWithJoinData_::_1_::dtor$1
void __fastcall RBX::Network::Replicator::reportFrameDataWithJoinData_::_1_::dtor_1(__int64 a1, __int64 a2)
{
  std::vector<RBX::LSP::SnippetSetting>::_Tidy(this: (std::vector<RBX::Telemetry::EphemeralStatBatchEvent> *)(a2 + 104)); /*0x1431eadb7*/
}

// Address: 0x1431eade0 | Name: _RBX::Network::Replicator::reportRakNetStatistics_::_1_::dtor$33
void __fastcall RBX::Network::Replicator::reportRakNetStatistics_::_1_::dtor_33(__int64 a1, __int64 a2)
{
  RBX::Analytics::InfluxDb::Points::~Points(this: (RBX::Analytics::InfluxDb::Points *)(a2 + 800)); /*0x1431eade7*/
}

// Address: 0x1431eadf0 | Name: _RBX::Network::Replicator::reportRakNetStatistics_::_1_::dtor$40
void __fastcall RBX::Network::Replicator::reportRakNetStatistics_::_1_::dtor_40(__int64 a1, __int64 a2)
{
  if ( (*(_DWORD *)(a2 + 1008) & 1) != 0 ) /*0x1431eae04*/
  {
    *(_DWORD *)(a2 + 1008) &= ~1u; /*0x1431eae06*/
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)(a2 + 112)); /*0x1431eae11*/
  }
}

// Address: 0x1431eae20 | Name: _RBX::Network::Replicator::schemaApplyStoredPropertyToInstance_::_1_::dtor$0
void __fastcall RBX::Network::Replicator::schemaApplyStoredPropertyToInstance_::_1_::dtor_0(__int64 a1, __int64 a2)
{
  RBX::ScopedAssign<unsigned __int64>::~ScopedAssign<unsigned __int64>(this: (RBX::ScopedAssign<unsigned __int64> *)(a2 + 56)); /*0x1431eae27*/
}

// Address: 0x1431eae30 | Name: _RBX::Network::Replicator::schemaReadTopReplicationContainerStateFromStream_::_1_::dtor$0
void RBX::Network::Replicator::schemaReadTopReplicationContainerStateFromStream_::_1_::dtor_0()
{
  Init_thread_abort(pOnce: &_TSS0_532); /*0x1431eae37*/
}

// Address: 0x1431eae50 | Name: _RBX::Network::Replicator::schemaReadTopReplicationContainerStateFromStream_::_1_::dtor$4
void RBX::Network::Replicator::schemaReadTopReplicationContainerStateFromStream_::_1_::dtor_4()
{
  Init_thread_abort(pOnce: &_TSS1_112); /*0x1431eae57*/
}

// Address: 0x1431eae60 | Name: _RBX::Network::Replicator::schemaReadTopReplicationContainerStateFromStream_::_1_::dtor$7
void RBX::Network::Replicator::schemaReadTopReplicationContainerStateFromStream_::_1_::dtor_7()
{
  Init_thread_abort(pOnce: &_TSS2_48); /*0x1431eae67*/
}

// Address: 0x1431eae70 | Name: _RBX::Network::Replicator::schemaReadTopReplicationContainerStateFromStream_::_1_::dtor$31
void __fastcall RBX::Network::Replicator::schemaReadTopReplicationContainerStateFromStream_::_1_::dtor_31(
        __int64 a1,
        __int64 a2)
{
  boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::Network::Replicator,std::weak_ptr<RBX::DataModel>,double>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<RBX::Network::Replicator>>,boost::_bi::value<std::weak_ptr<RBX::DataModel>>,boost::_bi::value<float>>>::~bind_t<void,boost::_mfi::mf2<void,RBX::Network::Replicator,std::weak_ptr<RBX::DataModel>,double>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<RBX::Network::Replicator>>,boost::_bi::value<std::weak_ptr<RBX::DataModel>>,boost::_bi::value<float>>>(this: *(boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::Network::Replicator,std::weak_ptr<RBX::DataModel>,double>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<RBX::Network::Replicator> >,boost::_bi::value<std::weak_ptr<RBX::DataModel> >,boost::_bi::value<float> > > **)(a2 + 160)); /*0x1431eae77*/
}

// Address: 0x1431eae80 | Name: _RBX::Network::Replicator::sendClusterChunkCacheCompressed_::_1_::dtor$0
void __fastcall RBX::Network::Replicator::sendClusterChunkCacheCompressed_::_1_::dtor_0(__int64 a1, __int64 a2)
{
  operator delete(ptr: *(void **)(a2 + 384)); /*0x1431eae95*/
}

// Address: 0x1431eaea0 | Name: _RBX::Network::Replicator::sendClusterChunkCacheCompressed_::_1_::dtor$2
void __fastcall RBX::Network::Replicator::sendClusterChunkCacheCompressed_::_1_::dtor_2(__int64 a1, __int64 a2)
{
  Luau::Variant<Luau::SubtypeConstraint,Luau::PackSubtypeConstraint,Luau::GeneralizationConstraint,Luau::InstantiationConstraint,Luau::UnaryConstraint,Luau::BinaryConstraint,Luau::IterableConstraint,Luau::NameConstraint,Luau::TypeAliasExpansionConstraint,Luau::FunctionCallConstraint,Luau::PrimitiveTypeConstraint,Luau::HasPropConstraint>::fnDtor<Luau::HasPropConstraint>(this: (std::pair<RBX::BatchThumbnailFetcher::WaitingRequestPriority const ,std::string > *)(a2 + 128)); /*0x1431eaea7*/
}

// END _1_ part 1/4, 400 functions
