// Peer -- 2022 Studio + full PDB
// tier 3, 17 functions


// Address: 0x14100a1c0 | Name: ??$Class_getDescriptor@VPeer@Network@RBX@@@@YAAEAVClassDescriptor@Reflection@RBX@@XZ
// attributes: thunk
RBX::Reflection::ClassDescriptor *__fastcall Class_getDescriptor<RBX::Network::Peer>()
{
  return RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Peer>();
}

// Address: 0x14100a6c0 | Name: ??$Class_getDescriptorPtr@VPeer@Network@RBX@@@Reflection@RBX@@YAAEAVClassDescriptor@01@XZ
RBX::ClassRegistrar<RBX::Network::Peer,0> *__fastcall RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Peer>()
{
  RBX::ClassRegistrar<RBX::Network::Peer,0> *result; // rax
  RBX::Reflection::RefPropDescriptor<RBX::Instance,RBX::Instance> *v1; // rcx
  RBX::Reflection::ClassDescriptor *v2; // rax
  RBX::Reflection::ClassDescriptor::Attributes v4; // [rsp+60h] [rbp-28h] BYREF
  RBX::Reflection::ClassDescriptor::Attributes v5; // 0:^40.32

  result = (RBX::ClassRegistrar<RBX::Network::Peer,0> *)ret_87; /*0x14100a6cd*/
  if ( ret_87 == nullptr ) /*0x14100a6d7*/
  {
    if ( _TSS0_513 > *(_DWORD *)(*((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index) + 260LL) ) /*0x14100a703*/
    {
      Init_thread_header(pOnce: &_TSS0_513); /*0x14100a727*/
      if ( _TSS0_513 == -1 ) /*0x14100a733*/
      {
        v5.isDeprecated = false; /*0x14100a735*/
        v5.preferred = nullptr; /*0x14100a73c*/
        v5.threadSafety = Unset; /*0x14100a741*/
        v5.flags = PERSISTENT; /*0x14100a745*/
        __wind /*0xf1c000000000001c*/
        {
          v2 = Class_getDescriptor<RBX::Instance>(this: v1); /*0x14100a74d*/
          v4 = v5; /*0x14100a757*/
          RBX::Reflection::ClassDescriptor::ClassDescriptor( /*0x14100a789*/
            this: &reg_79.desc,
            base: v2,
            name: "NetworkPeer",
            isService: false,
            attributes: &v4,
            security: (RBX::Security::Permissions)0,
            memoryCategory: nullptr);
          atexit(function: RBX::Reflection::Class_getDescriptorPtr_RBX::Network::Peer__::_2_::_dynamic_atexit_destructor_for__reg__); /*0x14100a795*/
        }
        __unwind
        {
          Init_thread_abort(pOnce: &_TSS0_513); /*0x1431e50b7*/
        }
        Init_thread_footer(pOnce: &_TSS0_513); /*0x14100a7a2*/
      }
    }
    ret_87 = (RBX::Reflection::ClassDescriptor *)&reg_79; /*0x14100a705*/
    return &reg_79; /*0x14100a70c*/
  }
  return result; /*0x14100a70f*/
}

// Address: 0x14100ab90 | Name: ??$Class_getNamePtr@VPeer@Network@RBX@@@Reflection@RBX@@YAAEBVName@1@XZ
const RBX::Name *__fastcall RBX::Reflection::Class_getNamePtr<RBX::Network::Peer>()
{
  const RBX::Name *result; // rax

  result = name_43; /*0x14100ab94*/
  if ( name_43 == nullptr ) /*0x14100ab9e*/
  {
    result = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Peer>()->desc.name; /*0x14100aba5*/
    name_43 = result; /*0x14100aba9*/
  }
  return result; /*0x14100abb0*/
}

// Address: 0x14102fad0 | Name: ??0Peer@Network@RBX@@IEAA@XZ
RBX::Network::Peer *__fastcall RBX::Network::Peer::Peer(RBX::Network::Peer *this)
{
  RBX::ClassRegistrar<RBX::Network::Peer,0> *v2; // rax
  long double v3; // xmm6_8
  RBX::RunningAverageTimeInterval<1> *p_interval; // rbx
  RBX::RunningAverageTimeInterval<1> *v5; // rcx
  int v6; // edi
  unsigned __int8 *v7; // rdx
  RBX::Network::Peer *result; // rax

  RBX::Instance::Instance(this); /*0x14102faec*/
  this->__vftable = (RBX::Network::Peer_vtbl *)RBX::Described<RBX::Network::Peer,RBX::Instance>::`vftable'; /*0x14102faf9*/
  __wind /*0xf1c0000000000018*/
  {
    v2 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Peer>(); /*0x14102fafc*/
    this->descriptor = &v2->desc; /*0x14102fb01*/
    this->__vftable = (RBX::Network::Peer_vtbl *)RBX::Network::Peer::`vftable'; /*0x14102fb0c*/
    v3 = RBX::Network::lerp; /*0x14102fb0f*/
    this->rakDutyCycle.time.lerp = RBX::Network::lerp; /*0x14102fb17*/
    v6 = 0; /*0x14102fb1f*/
    this->rakDutyCycle.time.lastSampleValue = 0.0; /*0x14102fb21*/
    this->rakDutyCycle.time.averageValue = 0.0; /*0x14102fb28*/
    this->rakDutyCycle.time.averageVariance = 0.0; /*0x14102fb2f*/
    this->rakDutyCycle.time.firstTime = true; /*0x14102fb36*/
    p_interval = &this->rakDutyCycle.interval; /*0x14102fb3d*/
    v5 = &this->rakDutyCycle.interval; /*0x14102fb44*/
  }
  __unwind
  {
    RBX::Instance::~Instance(this); /*0xf1c0000000000028*/
  }
  __wind /*0xf1c0000000000030*/
  {
    RBX::Time::now<1>(result: &v5->timer.start); /*0x14102fb47*/
    p_interval->firstTime = true; /*0x14102fb4c*/
    p_interval->average.lerp = v3; /*0x14102fb50*/
    p_interval->average.lastSampleValue = 0.0; /*0x14102fb55*/
    p_interval->average.averageValue = 0.0; /*0x14102fb59*/
    p_interval->average.averageVariance = 0.0; /*0x14102fb5d*/
    p_interval->average.firstTime = true; /*0x14102fb61*/
    p_interval->ignoreTimeSinceLastSample = nullptr; /*0x14102fb65*/
    this->rakPeer._Ptr = nullptr; /*0x14102fb69*/
    this->rakPeer._Rep = nullptr; /*0x14102fb70*/
    this->receiveJob._Ptr = nullptr; /*0x14102fb77*/
    this->receiveJob._Rep = nullptr; /*0x14102fb7e*/
    __wind /*0xf1c0000000000048*/
    {
      __wind /*0xf1c0000000000050*/
      {
        RBX::Random::Random(this: &this->randomGenerator); /*0x14102fb8c*/
        this->propertyWhiteList._Ptr = nullptr; /*0x14102fb91*/
        this->propertyWhiteList._Rep = nullptr; /*0x14102fb98*/
        this->eventWhiteList._Ptr = nullptr; /*0x14102fb9f*/
        this->eventWhiteList._Rep = nullptr; /*0x14102fba6*/
        this->packetErrorDelegate._Mypair._Myval2 = nullptr; /*0x14102fbad*/
        v7 = RBX::Network::Peer::aesKey; /*0x14102fbb4*/
        do /*0x14102fbd5*/
          *v7++ = (7 * v6++) ^ 0xFE; /*0x14102fbca*/
        while ( v6 < 16 ); /*0x14102fbd5*/
        this->protocolVersion = 36; /*0x14102fbd7*/
        result = this; /*0x14102fbe1*/
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&this->receiveJob); /*0x1431e6a6e*/
      }
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&this->rakPeer); /*0x1431e6a4e*/
    }
  }
  __unwind
  {
    RBX::Described<RBX::Stats::StatsService,RBX::ServiceInstance>::~Described<RBX::Stats::StatsService,RBX::ServiceInstance>((RBX::Described<RBX::AnimationStreamTrack,RBX::BaseAnimationTrack> *)this); /*0xf1c0000000000040*/
  }
  return result; /*0x14102fbe4*/
}

// Address: 0x14102fcb0 | Name: ??1Peer@Network@RBX@@MEAA@XZ
void __fastcall RBX::Network::Peer::~Peer(RBX::Network::Peer *this)
{
  RBX::Network::Peer::PacketErrorDelegate *Myval2; // rcx
  std::_Ref_count_base *Rep; // rbx
  std::_Ref_count_base *v4; // rbx
  std::_Ref_count_base *v5; // rbx
  std::_Ref_count_base *v6; // rbx

  this->__vftable = (RBX::Network::Peer_vtbl *)RBX::Network::Peer::`vftable'; /*0x14102fcc9*/
  Myval2 = this->packetErrorDelegate._Mypair._Myval2; /*0x14102fccc*/
  if ( Myval2 != nullptr ) /*0x14102fcd6*/
    ((void (__fastcall *)(RBX::Network::Peer::PacketErrorDelegate *, __int64))Myval2->dtr_PacketErrorDelegate)( /*0x14102fce0*/
      a1: Myval2,
      a2: 1);
  Rep = this->eventWhiteList._Rep; /*0x14102fce2*/
  if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x14102fcfd*/
  {
    Rep->_Destroy(this: Rep); /*0x14102fd05*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14102fd11*/
      Rep->_Delete_this(this: Rep); /*0x14102fd19*/
  }
  v4 = this->propertyWhiteList._Rep; /*0x14102fd1c*/
  if ( v4 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v4->_Uses, 0xFFFFFFFF) == 1 ) /*0x14102fd32*/
  {
    v4->_Destroy(this: v4); /*0x14102fd3a*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v4->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14102fd46*/
      v4->_Delete_this(this: v4); /*0x14102fd4e*/
  }
  v5 = this->receiveJob._Rep; /*0x14102fd51*/
  if ( v5 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v5->_Uses, 0xFFFFFFFF) == 1 ) /*0x14102fd67*/
  {
    v5->_Destroy(this: v5); /*0x14102fd6f*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v5->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14102fd7b*/
      v5->_Delete_this(this: v5); /*0x14102fd83*/
  }
  v6 = this->rakPeer._Rep; /*0x14102fd86*/
  if ( v6 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v6->_Uses, 0xFFFFFFFF) == 1 ) /*0x14102fd9c*/
  {
    v6->_Destroy(this: v6); /*0x14102fda4*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v6->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14102fdae*/
      v6->_Delete_this(this: v6); /*0x14102fdb6*/
  }
  RBX::Instance::~Instance(this); /*0x14102fdcb*/
}

// Address: 0x1410301d0 | Name: ?askAddChild@Peer@Network@RBX@@MEBA_NPEBVInstance@3@@Z
bool __fastcall RBX::Network::Peer::askAddChild(RBX::Network::Peer *this, const RBX::Instance *instance)
{
  const RBX::Instance *v2; // rdi
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *v4; // rax

  v2 = instance; /*0x1410301d6*/
  if ( instance == nullptr /*0x14103020d*/
    || (descriptor = instance->descriptor,
        v4 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Replicator>(),
        descriptor->index - (unsigned int)v4->index > v4->descendantCount) )
  {
    v2 = nullptr; /*0x14103020f*/
  }
  return v2 != nullptr; /*0x141030217*/
}

// Address: 0x141030220 | Name: ?decryptDataPart@Peer@Network@RBX@@SAXAEAVNetworkStream@23@@Z
void __fastcall RBX::Network::Peer::decryptDataPart(RBX::Network::NetworkStream *inBitstream)
{
  unsigned __int8 *v2; // rdi
  unsigned int v3; // ebx
  unsigned __int8 *v4; // rax
  QMetaObject::Call v5; // edx
  int v6; // r8d
  void **v7; // r9
  std::runtime_error pExceptionObject; // [rsp+30h] [rbp-288h] BYREF
  DataBlockEncryptor v9; // [rsp+50h] [rbp-268h] BYREF
  unsigned int inputLength; // [rsp+2C0h] [rbp+8h] BYREF

  DataBlockEncryptor::DataBlockEncryptor(this: &v9); /*0x14103023a*/
  __wind /*0xf1c0000000000010*/
  {
    DataBlockEncryptor::SetKey(this: &v9, key: (char *)RBX::Network::Peer::aesKey); /*0x14103024c*/
    inputLength = ((__int64 (__fastcall *)(RBX::Network::NetworkStream *))inBitstream->GetNumberOfBytesUsed)(a1: inBitstream) /*0x14103025c*/
                - 1;
    v2 = inBitstream->GetData(this: inBitstream); /*0x14103026c*/
    v3 = inputLength; /*0x14103026f*/
    v4 = inBitstream->GetData(this: inBitstream); /*0x14103027c*/
    if ( DataBlockEncryptor::Decrypt( /*0x1410302a3*/
           this: &v9,
           input: v4 + 1,
           inputLength: v3,
           output: v2 + 1,
           outputLength: &inputLength) == 0 )
    {
      std::runtime_error::runtime_error( /*0x1410302d0*/
        this: &pExceptionObject,
        _Message: (const char *)&RBX::Reflection::BoundFuncDesc<RBX::Network::Peer,void (int),1>::`vftable'[3]);
      throw &pExceptionObject; /*0x1410302e1*/
    }
  }
  __unwind
  {
    RBX::LSP::ILSPEditor::onSignalQuiescenceResponse(_o: (QObject *)&v9, _c: v5, _id: v6, _a: v7); /*0xf1c0000000000008*/
  }
  RBX::LSP::ILSPEditor::onSignalQuiescenceResponse(_o: (QObject *)&v9, _c: v5, _id: v6, _a: v7); /*0x1410302aa*/
}

// Address: 0x1410302f0 | Name: ?disableTimeout@Peer@Network@RBX@@QEAAXXZ
void __fastcall RBX::Network::Peer::disableTimeout(RBX::Network::Peer *this)
{
  Luau::InternalErrorReporter *v1; // rax
  std::_Func_base<void,char const *> *v2; // r9
  RakNet::SystemAddress v3; // [rsp+20h] [rbp-28h] BYREF

  v1 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x1410302fb*/
  v2 = v1->onInternalError._Mystorage._Ptrs[0]; /*0x141030318*/
  v3 = RakNet::UNASSIGNED_SYSTEM_ADDRESS_17; /*0x14103031e*/
  ((void (__fastcall *)(Luau::InternalErrorReporter *, __int64, RakNet::SystemAddress *))v2[52].__vftable)( /*0x141030328*/
    a1: v1,
    a2: 0x7FFFFFFF,
    a3: &v3);
}

// Address: 0x141030340 | Name: ?encryptDataPart@Peer@Network@RBX@@QEAAXAEAVNetworkStream@23@@Z
void __fastcall RBX::Network::Peer::encryptDataPart(RBX::Network::Peer *this, RBX::Network::NetworkStream *bitStream)
{
  unsigned int v4; // ebx
  unsigned int v5; // eax
  unsigned __int8 *v6; // rdi
  unsigned int v7; // ebx
  unsigned __int8 *v8; // rax
  QMetaObject::Call v9; // edx
  int v10; // r8d
  void **v11; // r9
  DataBlockEncryptor v12; // [rsp+30h] [rbp-268h] BYREF
  unsigned int inputLength; // [rsp+2A0h] [rbp+8h] BYREF

  DataBlockEncryptor::DataBlockEncryptor(this: &v12); /*0x141030363*/
  __wind /*0xf1c0000000000010*/
  {
    DataBlockEncryptor::SetKey(this: &v12, key: (char *)RBX::Network::Peer::aesKey); /*0x141030375*/
    inputLength = ((__int64 (__fastcall *)(RBX::Network::NetworkStream *))bitStream->GetNumberOfBytesUsed)(a1: bitStream) /*0x141030385*/
                - 1;
    v4 = (inputLength + 21) & 0xFFFFFFF0; /*0x141030393*/
    v5 = bitStream->GetNumberOfBytesUsed(this: bitStream); /*0x14103039c*/
    RBX::Network::NetworkStream::AddBytesAndReallocate(this: bitStream, numberOfBytesToWrite: v4 - v5 + 1); /*0x1410303a7*/
    v6 = bitStream->GetData(this: bitStream); /*0x1410303b5*/
    v7 = inputLength; /*0x1410303b8*/
    v8 = bitStream->GetData(this: bitStream); /*0x1410303c5*/
    DataBlockEncryptor::Encrypt( /*0x1410303f1*/
      this: &v12,
      input: v8 + 1,
      inputLength: v7,
      output: v6 + 1,
      outputLength: &inputLength,
      rng: &this->randomGenerator);
    RBX::Network::NetworkStream::SetWriteOffsetBytes( /*0x141030405*/
      this: bitStream,
      byteOffset: inputLength + 1,
      eraseDataToCurrentOffset: false);
  }
  __unwind
  {
    RBX::LSP::ILSPEditor::onSignalQuiescenceResponse(_o: (QObject *)&v12, _c: v9, _id: v10, _a: v11); /*0xf1c0000000000008*/
  }
  RBX::LSP::ILSPEditor::onSignalQuiescenceResponse(_o: (QObject *)&v12, _c: v9, _id: v10, _a: v11); /*0x141030410*/
}

// Address: 0x141030430 | Name: ?encryptDataPartWithKey@Peer@Network@RBX@@QEAAXAEAVNetworkStream@23@PEBE@Z
void __fastcall RBX::Network::Peer::encryptDataPartWithKey(
        RBX::Network::Peer *this,
        RBX::Network::NetworkStream *bitStream,
        char *key)
{
  unsigned int v6; // ebx
  unsigned int v7; // eax
  unsigned __int8 *v8; // rdi
  unsigned int v9; // ebx
  unsigned __int8 *v10; // rax
  QMetaObject::Call v11; // edx
  int v12; // r8d
  void **v13; // r9
  DataBlockEncryptor encryptor; // [rsp+30h] [rbp-268h] BYREF
  unsigned int length; // [rsp+2A0h] [rbp+8h] BYREF

  DataBlockEncryptor::DataBlockEncryptor(this: &encryptor); /*0x141030456*/
  __wind /*0xf1c0000000000010*/
  {
    DataBlockEncryptor::SetKey(this: &encryptor, key); /*0x141030464*/
    length = ((__int64 (__fastcall *)(RBX::Network::NetworkStream *))bitStream->GetNumberOfBytesUsed)(a1: bitStream) - 1; /*0x141030474*/
    v6 = (length + 21) & 0xFFFFFFF0; /*0x141030482*/
    v7 = bitStream->GetNumberOfBytesUsed(this: bitStream); /*0x14103048b*/
    RBX::Network::NetworkStream::AddBytesAndReallocate(this: bitStream, numberOfBytesToWrite: v6 - v7 + 1); /*0x141030496*/
    v8 = bitStream->GetData(this: bitStream); /*0x1410304a4*/
    v9 = length; /*0x1410304a7*/
    v10 = bitStream->GetData(this: bitStream); /*0x1410304b4*/
    DataBlockEncryptor::Encrypt( /*0x1410304e0*/
      this: &encryptor,
      input: v10 + 1,
      inputLength: v9,
      output: v8 + 1,
      outputLength: &length,
      rng: &this->randomGenerator);
    RBX::Network::NetworkStream::SetWriteOffsetBytes( /*0x1410304f4*/
      this: bitStream,
      byteOffset: length + 1,
      eraseDataToCurrentOffset: false);
  }
  __unwind
  {
    RBX::LSP::ILSPEditor::onSignalQuiescenceResponse(_o: (QObject *)&encryptor, _c: v11, _id: v12, _a: v13); /*0xf1c0000000000008*/
  }
  RBX::LSP::ILSPEditor::onSignalQuiescenceResponse(_o: (QObject *)&encryptor, _c: v11, _id: v12, _a: v13); /*0x1410304ff*/
}

// Address: 0x141030560 | Name: ?notifyPacketError@Peer@Network@RBX@@QEAAXVStringView@3@@Z
void __fastcall RBX::Network::Peer::notifyPacketError(RBX::Network::Peer *this, RBX::StringView *packetError)
{
  RBX::Network::Peer::PacketErrorDelegate *Myval2; // rcx
  RBX::Network::Peer::PacketErrorDelegate_vtbl *v3; // rax
  RBX::StringView v4; // [rsp+20h] [rbp-18h] BYREF

  Myval2 = this->packetErrorDelegate._Mypair._Myval2; /*0x141030564*/
  if ( Myval2 != nullptr ) /*0x14103056e*/
  {
    v3 = Myval2->__vftable; /*0x141030573*/
    v4 = *packetError; /*0x14103057b*/
    v3->onPacketError(this: Myval2, a2: &v4); /*0x141030580*/
  }
}

// Address: 0x141030590 | Name: ?onCreateRakPeer@Peer@Network@RBX@@MEAAXXZ
void __fastcall RBX::Network::Peer::onCreateRakPeer(RBX::Network::Peer *this)
{
  Luau::InternalErrorReporter *v2; // rax
  std::_Func_base<void,char const *> *v3; // rdx
  _QWORD *v4; // rax
  Luau::InternalErrorReporter *v5; // rax
  __int64 v6; // rdx
  RakNet::SystemAddress v7; // [rsp+20h] [rbp-28h] BYREF

  v2 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x1410305a0*/
  v3 = v2->onInternalError._Mystorage._Ptrs[0]; /*0x1410305b6*/
  v7 = RakNet::UNASSIGNED_SYSTEM_ADDRESS_17; /*0x1410305b9*/
  v4 = (_QWORD *)((__int64 (__fastcall *)(Luau::InternalErrorReporter *, RakNet::SystemAddress *))v3[49].__vftable)( /*0x1410305cf*/
                   a1: v2,
                   a2: &v7);
  RBX::Random::reseed(this: &this->randomGenerator, seed: (unsigned int)*v4 ^ HIDWORD(*v4)); /*0x1410305e8*/
  v5 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x1410305f4*/
  LOBYTE(v6) = 1; /*0x1410305f9*/
  ((void (__fastcall *)(Luau::InternalErrorReporter *, __int64))v5->onInternalError._Mystorage._Ptrs[0][43].__vftable)( /*0x141030606*/
    a1: v5,
    a2: v6);
}

// Address: 0x141030610 | Name: ?onServiceProvider@Peer@Network@RBX@@MEAAXPEAVServiceProvider@3@0@Z
void __fastcall RBX::Network::Peer::onServiceProvider(
        RBX::Network::Peer *this,
        RBX::ServiceProvider *oldProvider,
        RBX::ServiceProvider *newProvider)
{
  RBX::ServiceProvider *v3; // r15
  RBX::ServiceProvider *v4; // r14
  RBX::Network::Peer *v6; // r13
  unsigned __int64 Myres; // rdx
  __int64 v8; // r8
  RBX::Stats::StatsService *v9; // r9
  RBX::Instance *FirstChildByName; // rax
  std::enable_shared_from_this<RBX::Reflection::DescribedBase> *v11; // r14
  std::_Ref_count_base *Rep; // rdx
  signed __int32 Uses; // eax
  signed __int32 v14; // ett
  RBX::Stats::Item *v15; // r15
  std::_Ref_count_base *v16; // r14
  char v17; // r12
  __int64 v18; // rbx
  char *v19; // rcx
  RBX::Network::PacketReceiveJob *v20; // rax
  volatile signed __int32 *v21; // rcx
  std::_Ref_count_base *v22; // rax
  RBX::File *v23; // rcx
  std::_Ref_count_base *v24; // rbx
  RBX::Network::ConcurrentRakPeer *v25; // rcx
  Luau::InternalErrorReporter *v26; // rax
  std::_Ref_count_base *v27; // rbx
  std::_Ref_count_base *v28; // rbx
  std::_Ref_count_base *v29; // rbx
  RBX::Network::ConcurrentRakPeer *v30; // rax
  RBX::Network::ConcurrentRakPeer *v31; // rbx
  RakNet::RakPeer *v32; // rax
  RBX::Graphics::TextureVulkan::DownloadBuffer *v33; // rax
  RBX::Network::ConcurrentRakPeer *v34; // rbx
  std::_Ref_count_base *v35; // rax
  std::_Ref_count_base *v36; // rbx
  Luau::InternalErrorReporter *v37; // rax
  RBX::Network::PacketReceiveJob *v38; // rax
  std::_Ref_count_base *v39; // rcx
  RBX::Graphics::TextureVulkan::DownloadBuffer *v40; // r14
  std::_Ref_count_base *v41; // rax
  std::_Ref_count_base *v42; // rbx
  unsigned __int64 resourceListIndex; // rax
  RBX::Graphics::Device *v44; // rax
  std::_Ref_count_base *v45; // rdx
  volatile signed __int32 *v46; // rcx
  std::_Ref_count_base *v47; // r14
  std::_Ref_count_base *v48; // rcx
  std::shared_ptr<RBX::Network::StrictNetworkFilter::WhiteList> *PropertyWhitelist; // rax
  RBX::Network::StrictNetworkFilter::WhiteList *v50; // rcx
  std::_Ref_count_base *v51; // rdx
  std::_Ref_count_base *v52; // rbx
  std::_Ref_count_base *v53; // rbx
  std::shared_ptr<RBX::Network::StrictNetworkFilter::WhiteList> *EventWhitelist; // rax
  RBX::Network::StrictNetworkFilter::WhiteList *v55; // rcx
  std::_Ref_count_base *v56; // rdx
  std::_Ref_count_base *v57; // rbx
  std::_Ref_count_base *v58; // rbx
  RBX::Stats::StatsService *v59; // r15
  std::shared_ptr<RBX::Network::PeerStatsItem> *v60; // rax
  RBX::File *v61; // r14
  std::_Ref_count_base *v62; // rsi
  std::_Ref_count_base *v63; // rbx
  void (__fastcall *setName)(struct RBX::File *, const std::string *); // r8
  char *v65; // rcx
  RBX::Network::ConcurrentRakPeer *v66; // [rsp+30h] [rbp-D0h]
  RBX::Network::PacketReceiveJob *v67; // [rsp+30h] [rbp-D0h]
  RakNet::RakPeer *v68; // [rsp+38h] [rbp-C8h]
  std::shared_ptr<RBX::File> v69; // [rsp+40h] [rbp-C0h] BYREF
  std::shared_ptr<RBX::Stats::Item> network; // [rsp+50h] [rbp-B0h] BYREF
  std::shared_ptr<RBX::File> v71; // [rsp+60h] [rbp-A0h] BYREF
  std::string findName; // [rsp+70h] [rbp-90h] BYREF
  std::shared_ptr<RBX::TaskScheduler::Job> v73; // [rsp+90h] [rbp-70h] BYREF
  std::shared_ptr<RBX::File> v74; // [rsp+A0h] [rbp-60h] BYREF
  std::shared_ptr<RBX::TaskScheduler::Job> v75; // [rsp+B0h] [rbp-50h] BYREF
  RBX::Graphics::ProfilerAdorn::Item ptr; // [rsp+C0h] [rbp-40h] BYREF
  __int64 v77; // [rsp+F8h] [rbp-8h]
  std::shared_ptr<std::vector<RBX::Guid> > v78; // [rsp+100h] [rbp+0h] BYREF
  std::shared_ptr<std::vector<RBX::Guid> > v79; // [rsp+110h] [rbp+10h] BYREF
  std::_Temporary_owner<RBX::Network::ConcurrentRakPeer> v80; // [rsp+120h] [rbp+20h] BYREF
  std::_Temporary_owner<RBX::Graphics::TextureVulkan::DownloadBuffer> v81; // [rsp+128h] [rbp+28h] BYREF
  std::shared_ptr<RBX::Network::StrictNetworkFilter::WhiteList> result; // [rsp+130h] [rbp+30h] BYREF
  std::shared_ptr<RBX::Network::StrictNetworkFilter::WhiteList> v83; // [rsp+140h] [rbp+40h] BYREF
  std::shared_ptr<RBX::Network::PeerStatsItem> v84; // [rsp+150h] [rbp+50h] BYREF
  std::function<void __cdecl(void)> v85; // [rsp+160h] [rbp+60h] BYREF
  RBX::Network::Peer *v88; // [rsp+1F8h] [rbp+F8h] BYREF

  v3 = newProvider; /*0x141030639*/
  v4 = oldProvider; /*0x14103063c*/
  v6 = v88; /*0x141030642*/
  LODWORD(v88) = 0; /*0x14103064c*/
  v9 = RBX::ServiceProvider::find<RBX::Stats::StatsService>(serviceProvider: oldProvider); /*0x14103065b*/
  if ( v9 != nullptr ) /*0x141030666*/
  {
    __wind /*0xf1c00000000000ec*/
    {
      findName._Mypair._Myval2._Myres = 15; /*0x141030671*/
      findName._Mypair._Myval2._Mysize = 7; /*0x141030679*/
      qmemcpy(&findName, "Networ", 6); /*0x141030687*/
      *(_WORD *)&findName._Mypair._Myval2._Bx._Alias[6] = (unsigned __int8)aNetwork[6]; /*0x14103069e*/
      FirstChildByName = RBX::Instance::findFirstChildByName(this: v9, &findName, doSecurityCheck: false); /*0x1410306b2*/
      if ( FirstChildByName == nullptr /*0x1410306c3*/
        || (v11 = &FirstChildByName->std::enable_shared_from_this<RBX::Reflection::DescribedBase>,
            FirstChildByName == (RBX::Instance *)-8LL) )
      {
        network._Ptr = nullptr; /*0x14103071b*/
        network._Rep = nullptr; /*0x141030720*/
        v77 = 0; /*0x141030725*/
        v17 = 8; /*0x141030729*/
        v16 = (std::_Ref_count_base *)v6; /*0x14103072f*/
        v15 = nullptr; /*0x141030734*/
      }
      else
      {
        Rep = FirstChildByName->_Wptr._Rep; /*0x1410306c5*/
        if ( Rep == nullptr || (Uses = Rep->_Uses) == 0 ) /*0x1410306d7*/
LABEL_148:
          std::_Throw_bad_weak_ptr(); /*0x14103100d*/
        while ( 1 ) /*0x1410306e3*/
        {
          v14 = Uses; /*0x1410306e3*/
          Uses = _InterlockedCompareExchange((volatile signed __int32 *)&Rep->_Uses, Uses + 1, Uses); /*0x1410306e3*/
          if ( v14 == Uses ) /*0x1410306e8*/
            break; /*0x1410306e8*/
          if ( Uses == 0 ) /*0x1410306ec*/
            goto LABEL_148; /*0x1410306ec*/
        }
        v15 = (RBX::Stats::Item *)v11->_Wptr._Ptr; /*0x1410306f4*/
        v16 = v11->_Wptr._Rep; /*0x1410306f7*/
        if ( v16 != nullptr ) /*0x1410306fe*/
          _InterlockedIncrement((volatile signed __int32 *)&v16->_Uses); /*0x141030700*/
        network._Ptr = v15; /*0x141030705*/
        network._Rep = v16; /*0x14103070a*/
        *(_QWORD *)&ptr.width = 0; /*0x14103070f*/
        v17 = 27; /*0x141030713*/
      }
      if ( (v17 & 2) != 0 ) /*0x14103073b*/
      {
        v17 &= ~2u; /*0x14103073d*/
        if ( *(_QWORD *)&ptr.width != 0 /*0x141030754*/
          && _InterlockedExchangeAdd((volatile signed __int32 *)(*(_QWORD *)&ptr.width + 8LL), 0xFFFFFFFF) == 1 )
        {
          v18 = *(_QWORD *)&ptr.width; /*0x141030756*/
          (***(void (__fastcall ****)(_QWORD))&ptr.width)(a1: *(_QWORD *)&ptr.width); /*0x141030760*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v18 + 12), 0xFFFFFFFF) == 1 ) /*0x14103076c*/
            (*(void (__fastcall **)(_QWORD))(**(_QWORD **)&ptr.width + 8LL))(a1: *(_QWORD *)&ptr.width); /*0x141030775*/
        }
      }
      if ( (v17 & 1) != 0 /*0x14103078e*/
        && v16 != nullptr
        && _InterlockedExchangeAdd((volatile signed __int32 *)&v16->_Uses, 0xFFFFFFFF) == 1 )
      {
        v16->_Destroy(this: v16); /*0x141030796*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v16->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410307a3*/
          v16->_Delete_this(this: v16); /*0x1410307ab*/
      }
      Myres = findName._Mypair._Myval2._Myres; /*0x1410307af*/
      if ( findName._Mypair._Myval2._Myres >= 0x10 ) /*0x1410307b7*/
      {
        v19 = findName._Mypair._Myval2._Bx._Ptr; /*0x1410307bc*/
        if ( findName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410307cb*/
        {
          v19 = *((char **)findName._Mypair._Myval2._Bx._Ptr - 1); /*0x1410307d1*/
          if ( (unsigned __int64)(findName._Mypair._Myval2._Bx._Ptr - v19 - 8) > 0x1F ) /*0x1410307e0*/
            _invalid_parameter_noinfo_noreturn(); /*0x1410307e2*/
        }
        operator delete(ptr: v19); /*0x1410307e9*/
      }
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&findName); /*0xf1c00000000000fc*/
    }
    __wind /*0xf1c0000000000104*/
    {
      findName._Mypair._Myval2._Mysize = 0; /*0x1410307f1*/
      findName._Mypair._Myval2._Myres = 15; /*0x1410307f5*/
      findName._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410307fd*/
      if ( v15 != nullptr ) /*0x141030805*/
      {
        v78 = 0; /*0x14103080a*/
        RBX::Instance::setParentInternal( /*0x141030823*/
          this: v15,
          newParent: nullptr,
          ignoreLock: false,
          destroying: false,
          destroyedGuids: &v78);
      }
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&network); /*0xf1c00000000000e4*/
    }
    if ( network._Rep != nullptr /*0x14103083d*/
      && _InterlockedExchangeAdd((volatile signed __int32 *)&network._Rep->_Uses, 0xFFFFFFFF) == 1 )
    {
      network._Rep->_Destroy(this: network._Rep); /*0x14103084a*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&network._Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141030856*/
        network._Rep->_Delete_this(this: network._Rep); /*0x141030860*/
    }
    v3 = newProvider; /*0x141030863*/
    v4 = oldProvider; /*0x14103086a*/
  }
  v20 = this->receiveJob._Ptr; /*0x141030871*/
  if ( v20 != nullptr ) /*0x14103087b*/
  {
    v20->rakPeer._Ptr = nullptr; /*0x141030881*/
    v21 = (volatile signed __int32 *)v20->rakPeer._Rep; /*0x141030888*/
    v20->rakPeer._Rep = nullptr; /*0x14103088f*/
    if ( v21 != nullptr && _InterlockedExchangeAdd(v21 + 3, 0xFFFFFFFF) == 1 ) /*0x1410308a5*/
      (*(void (__fastcall **)(volatile signed __int32 *, unsigned __int64, __int64, RBX::Stats::StatsService *))(*(_QWORD *)v21 + 8LL))( /*0x1410308aa*/
        a1: v21,
        a2: Myres,
        a3: v8,
        a4: v9);
    v69 = 0; /*0x1410308b0*/
    v22 = this->receiveJob._Rep; /*0x1410308b6*/
    if ( v22 != nullptr ) /*0x1410308c0*/
    {
      _InterlockedIncrement((volatile signed __int32 *)&v22->_Uses); /*0x1410308c2*/
      v22 = this->receiveJob._Rep; /*0x1410308c6*/
    }
    v23 = (RBX::File *)this->receiveJob._Ptr; /*0x1410308cd*/
    v69._Ptr = v23; /*0x1410308d4*/
    v69._Rep = v22; /*0x1410308d9*/
    v85._Mystorage._Ptrs[7] = nullptr; /*0x1410308e8*/
    v73 = 0; /*0x1410308ef*/
    if ( v22 != nullptr ) /*0x1410308f7*/
    {
      _InterlockedIncrement((volatile signed __int32 *)&v22->_Uses); /*0x1410308f9*/
      v22 = v69._Rep; /*0x1410308fd*/
      v23 = v69._Ptr; /*0x141030902*/
    }
    __wind /*0xf1c00000000000d4*/
    {
      v73._Ptr = (RBX::TaskScheduler::Job *)v23; /*0x141030907*/
      v73._Rep = v22; /*0x14103090b*/
      RBX::TaskScheduler::remove(job: &v73, joinJob: false, callbackPing: &v85); /*0x141030919*/
      if ( v69._Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v69._Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x141030933*/
      {
        v69._Rep->_Destroy(this: v69._Rep); /*0x14103093b*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v69._Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141030947*/
          v69._Rep->_Delete_this(this: v69._Rep); /*0x14103094f*/
      }
      this->receiveJob._Ptr = nullptr; /*0x141030952*/
      v24 = this->receiveJob._Rep; /*0x141030959*/
      this->receiveJob._Rep = nullptr; /*0x141030960*/
      if ( v24 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v24->_Uses, 0xFFFFFFFF) == 1 ) /*0x141030976*/
      {
        v24->_Destroy(this: v24); /*0x14103097e*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v24->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14103098a*/
          v24->_Delete_this(this: v24); /*0x141030992*/
      }
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: &v69); /*0xf1c00000000000cc*/
    }
  }
  RBX::Instance::removeAllChildren(this); /*0x141030998*/
  v25 = this->rakPeer._Ptr; /*0x14103099d*/
  if ( v25 != nullptr ) /*0x1410309a7*/
  {
    if ( DFLog::ClientRecvFromRaknet != 0 ) /*0x1410309b2*/
    {
      FLog::FastLog( /*0x1410309c1*/
        level: DFLog::ClientRecvFromRaknet,
        message: "[DFLog::ClientRecvFromRaknet] Raknet rawpeer is detaching Peer plugin",
        arg0: nullptr);
      v25 = this->rakPeer._Ptr; /*0x1410309c6*/
    }
    v26 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)v25); /*0x1410309cd*/
    ((void (__fastcall *)(Luau::InternalErrorReporter *, _QWORD))v26->onInternalError._Mystorage._Ptrs[0][64].__vftable)( /*0x1410309e1*/
      a1: v26,
      a2: 0);
    this->rakPeer._Ptr = nullptr; /*0x1410309e4*/
    v27 = this->rakPeer._Rep; /*0x1410309eb*/
    this->rakPeer._Rep = nullptr; /*0x1410309f2*/
    if ( v27 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v27->_Uses, 0xFFFFFFFF) == 1 ) /*0x141030a08*/
    {
      v27->_Destroy(this: v27); /*0x141030a10*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v27->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141030a1c*/
        v27->_Delete_this(this: v27); /*0x141030a24*/
    }
  }
  RBX::Instance::onServiceProvider(this, oldProvider: v4, newProvider: v3); /*0x141030a30*/
  if ( v4 != nullptr ) /*0x141030a38*/
  {
    this->propertyWhiteList._Ptr = nullptr; /*0x141030a3e*/
    v28 = this->propertyWhiteList._Rep; /*0x141030a45*/
    this->propertyWhiteList._Rep = nullptr; /*0x141030a4c*/
    if ( v28 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v28->_Uses, 0xFFFFFFFF) == 1 ) /*0x141030a62*/
    {
      v28->_Destroy(this: v28); /*0x141030a6a*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v28->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141030a76*/
        v28->_Delete_this(this: v28); /*0x141030a7e*/
    }
    this->eventWhiteList._Ptr = nullptr; /*0x141030a81*/
    v29 = this->eventWhiteList._Rep; /*0x141030a88*/
    this->eventWhiteList._Rep = nullptr; /*0x141030a8f*/
    if ( v29 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v29->_Uses, 0xFFFFFFFF) == 1 ) /*0x141030aa5*/
    {
      v29->_Destroy(this: v29); /*0x141030aad*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v29->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141030ab9*/
        v29->_Delete_this(this: v29); /*0x141030ac1*/
    }
  }
  if ( v3 != nullptr ) /*0x141030ac7*/
  {
    v30 = (RBX::Network::ConcurrentRakPeer *)operator new(size: 0x48u); /*0x141030ad2*/
    v31 = v30; /*0x141030ad7*/
    v66 = v30; /*0x141030ada*/
    __wind /*0xf1c00000000000bc*/
    {
      if ( v30 != nullptr ) /*0x141030ae2*/
      {
        v32 = (RakNet::RakPeer *)operator new(size: 0xD68u); /*0x141030ae9*/
        v68 = v32; /*0x141030aee*/
        __wind /*0xf1c00000000000b0*/
        {
          if ( v32 != nullptr ) /*0x141030af6*/
            v33 = (RBX::Graphics::TextureVulkan::DownloadBuffer *)RakNet::RakPeer::RakPeer(this: v32); /*0x141030afb*/
          else
            v33 = nullptr; /*0x141030b02*/
        }
        __unwind
        {
          operator delete(ptr: v68); /*0x1431e6ab2*/
        }
        v34 = RBX::Network::ConcurrentRakPeer::ConcurrentRakPeer( /*0x141030b14*/
                this: v31,
                peer: v33,
                dataModel: (RBX::DataModel *)&v3[-1].serviceRemovingSignal);
      }
      else
      {
        v34 = nullptr; /*0x141030b19*/
      }
    }
    __unwind
    {
      operator delete(ptr: v66); /*0x14317c002*/
    }
    v80._Ptr = v34; /*0x141030b1c*/
    __wind /*0xf1c000000000008c*/
    {
      v35 = (std::_Ref_count_base *)operator new(size: 0x18u); /*0x141030b25*/
      if ( v35 != nullptr ) /*0x141030b32*/
      {
        *v35 = 0; /*0x141030b37*/
        v35->_Uses = 1; /*0x141030b3a*/
        v35->_Weaks = 1; /*0x141030b41*/
        v35->__vftable = (std::_Ref_count_base_vtbl *)std::_Ref_count<RBX::Network::ConcurrentRakPeer>::`vftable'; /*0x141030b4f*/
        v35[1].__vftable = (std::_Ref_count_base_vtbl *)v34; /*0x141030b52*/
      }
      else
      {
        v35 = nullptr; /*0x141030b58*/
      }
      this->rakPeer._Ptr = v34; /*0x141030b5b*/
      v36 = this->rakPeer._Rep; /*0x141030b62*/
      this->rakPeer._Rep = v35; /*0x141030b69*/
      if ( v36 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v36->_Uses, 0xFFFFFFFF) == 1 ) /*0x141030b7f*/
      {
        v36->_Destroy(this: v36); /*0x141030b87*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v36->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141030b93*/
          v36->_Delete_this(this: v36); /*0x141030b9b*/
      }
    }
    __unwind
    {
      std::_Temporary_owner<RBX::Network::ConcurrentRakPeer>::~_Temporary_owner<RBX::Network::ConcurrentRakPeer>(this: &v80); /*0xf1c0000000000084*/
    }
    if ( DFLog::ClientRecvFromRaknet != 0 ) /*0x141030ba7*/
      FLog::FastLog( /*0x141030bb3*/
        level: DFLog::ClientRecvFromRaknet,
        message: "[DFLog::ClientRecvFromRaknet] Raknet rawpeer is attaching Peer plugin",
        arg0: nullptr);
    v37 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x141030bbf*/
    ((void (__fastcall *)(Luau::InternalErrorReporter *, RBX::Network::Peer *))v37->onInternalError._Mystorage._Ptrs[0][64].__vftable)( /*0x141030bd4*/
      a1: v37,
      a2: this);
    this->onCreateRakPeer(this); /*0x141030bdd*/
    v38 = (RBX::Network::PacketReceiveJob *)operator new(size: 0x190u); /*0x141030be8*/
    v67 = v38; /*0x141030bf0*/
    __wind /*0xf1c0000000000074*/
    {
      if ( v38 != nullptr ) /*0x141030bf8*/
      {
        v74 = 0; /*0x141030c01*/
        v39 = this->rakPeer._Rep; /*0x141030c06*/
        if ( v39 != nullptr ) /*0x141030c10*/
        {
          _InterlockedIncrement((volatile signed __int32 *)&v39->_Uses); /*0x141030c12*/
          v39 = this->rakPeer._Rep; /*0x141030c16*/
        }
        v74._Ptr = (RBX::File *)this->rakPeer._Ptr; /*0x141030c24*/
        v74._Rep = v39; /*0x141030c28*/
        v40 = (RBX::Graphics::TextureVulkan::DownloadBuffer *)RBX::Network::PacketReceiveJob::PacketReceiveJob( /*0x141030c38*/
                                                                this: v38,
                                                                rakPeer: &v74,
                                                                dataModel: (RBX::DataModel *)&v3[-1].serviceRemovingSignal);
      }
      else
      {
        v40 = nullptr; /*0x141030c3d*/
      }
    }
    __unwind
    {
      operator delete(ptr: v67); /*0x143162dd2*/
    }
    v81._Ptr = v40; /*0x141030c40*/
    __wind /*0xf1c000000000005c*/
    {
      v41 = (std::_Ref_count_base *)operator new(size: 0x18u); /*0x141030c49*/
      v42 = v41; /*0x141030c4e*/
      if ( v41 != nullptr ) /*0x141030c59*/
      {
        *v41 = 0; /*0x141030c5e*/
        v41->_Uses = 1; /*0x141030c61*/
        v41->_Weaks = 1; /*0x141030c68*/
        v41->__vftable = (std::_Ref_count_base_vtbl *)std::_Ref_count<RBX::Network::PacketReceiveJob>::`vftable'; /*0x141030c76*/
        v41[1].__vftable = (std::_Ref_count_base_vtbl *)v40; /*0x141030c79*/
      }
      else
      {
        v42 = nullptr; /*0x141030c7f*/
      }
      if ( v40 != nullptr ) /*0x141030c85*/
      {
        resourceListIndex = v40->resourceListIndex; /*0x141030c87*/
        if ( resourceListIndex == 0 || *(_DWORD *)(resourceListIndex + 8) == 0 ) /*0x141030c94*/
        {
          if ( v42 != nullptr ) /*0x141030c99*/
          {
            _InterlockedIncrement((volatile signed __int32 *)&v42->_Uses); /*0x141030c9b*/
            v44 = (RBX::Graphics::Device *)v40; /*0x141030c9f*/
            _InterlockedIncrement((volatile signed __int32 *)&v42->_Weaks); /*0x141030ca2*/
            v45 = v42; /*0x141030ca6*/
          }
          else
          {
            v44 = nullptr; /*0x141030cab*/
            v45 = nullptr; /*0x141030cae*/
          }
          v40->device = v44; /*0x141030cb1*/
          v46 = (volatile signed __int32 *)v40->resourceListIndex; /*0x141030cb5*/
          v40->resourceListIndex = (unsigned __int64)v45; /*0x141030cb9*/
          if ( v46 != nullptr && _InterlockedExchangeAdd(v46 + 3, 0xFFFFFFFF) == 1 ) /*0x141030ccc*/
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v46 + 8LL))(a1: v46); /*0x141030cd1*/
          if ( v42 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v42->_Uses, 0xFFFFFFFF) == 1 ) /*0x141030ce3*/
          {
            v42->_Destroy(this: v42); /*0x141030ceb*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v42->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141030cf7*/
              v42->_Delete_this(this: v42); /*0x141030cff*/
          }
        }
      }
      this->receiveJob._Ptr = (RBX::Network::PacketReceiveJob *)v40; /*0x141030d03*/
      v47 = this->receiveJob._Rep; /*0x141030d0a*/
      this->receiveJob._Rep = v42; /*0x141030d11*/
      if ( v47 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v47->_Uses, 0xFFFFFFFF) == 1 ) /*0x141030d28*/
      {
        v47->_Destroy(this: v47); /*0x141030d30*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v47->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141030d3d*/
          v47->_Delete_this(this: v47); /*0x141030d45*/
      }
      v75 = 0; /*0x141030d4b*/
      v48 = this->receiveJob._Rep; /*0x141030d50*/
      if ( v48 != nullptr ) /*0x141030d5a*/
      {
        _InterlockedIncrement((volatile signed __int32 *)&v48->_Uses); /*0x141030d5c*/
        v48 = this->receiveJob._Rep; /*0x141030d60*/
      }
    }
    __unwind
    {
      RBX::BulletWedgeShapeWrapper::~BulletWedgeShapeWrapper(this: &v81); /*0xf1c0000000000054*/
    }
    v75._Ptr = this->receiveJob._Ptr; /*0x141030d6e*/
    v75._Rep = v48; /*0x141030d72*/
    RBX::TaskScheduler::add(job: &v75); /*0x141030d7a*/
    PropertyWhitelist = RBX::Network::StrictNetworkFilter::makePropertyWhitelist(&result); /*0x141030d83*/
    v50 = PropertyWhitelist->_Ptr; /*0x141030d88*/
    v51 = PropertyWhitelist->_Rep; /*0x141030d8b*/
    PropertyWhitelist->_Ptr = nullptr; /*0x141030d8f*/
    PropertyWhitelist->_Rep = nullptr; /*0x141030d92*/
    this->propertyWhiteList._Ptr = v50; /*0x141030d96*/
    v52 = this->propertyWhiteList._Rep; /*0x141030d9d*/
    this->propertyWhiteList._Rep = v51; /*0x141030da4*/
    if ( v52 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v52->_Uses, 0xFFFFFFFF) == 1 ) /*0x141030dba*/
    {
      v52->_Destroy(this: v52); /*0x141030dc2*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v52->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141030dce*/
        v52->_Delete_this(this: v52); /*0x141030dd6*/
    }
    v53 = result._Rep; /*0x141030dd9*/
    if ( result._Rep != nullptr /*0x141030dec*/
      && _InterlockedExchangeAdd((volatile signed __int32 *)&result._Rep->_Uses, 0xFFFFFFFF) == 1 )
    {
      v53->_Destroy(this: v53); /*0x141030df4*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v53->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141030e00*/
        v53->_Delete_this(this: v53); /*0x141030e08*/
    }
    EventWhitelist = RBX::Network::StrictNetworkFilter::makeEventWhitelist(result: &v83); /*0x141030e0f*/
    v55 = EventWhitelist->_Ptr; /*0x141030e14*/
    v56 = EventWhitelist->_Rep; /*0x141030e17*/
    EventWhitelist->_Ptr = nullptr; /*0x141030e1b*/
    EventWhitelist->_Rep = nullptr; /*0x141030e1e*/
    this->eventWhiteList._Ptr = v55; /*0x141030e22*/
    v57 = this->eventWhiteList._Rep; /*0x141030e29*/
    this->eventWhiteList._Rep = v56; /*0x141030e30*/
    if ( v57 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v57->_Uses, 0xFFFFFFFF) == 1 ) /*0x141030e46*/
    {
      v57->_Destroy(this: v57); /*0x141030e4e*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v57->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141030e5a*/
        v57->_Delete_this(this: v57); /*0x141030e62*/
    }
    v58 = v83._Rep; /*0x141030e65*/
    if ( v83._Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v83._Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x141030e78*/
    {
      v58->_Destroy(this: v58); /*0x141030e80*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v58->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141030e8c*/
        v58->_Delete_this(this: v58); /*0x141030e94*/
    }
  }
  v59 = RBX::ServiceProvider::find<RBX::Stats::StatsService>(serviceProvider: v3); /*0x141030e9f*/
  if ( v59 != nullptr ) /*0x141030ea5*/
  {
    v88 = this; /*0x141030eab*/
    v60 = RBX::Creatable<RBX::Instance>::create<RBX::Network::PeerStatsItem,RBX::Network::Peer *>( /*0x141030ebd*/
            result: &v84,
            <args_0>: &v88);
    v61 = (RBX::File *)v60->_Ptr; /*0x141030ec2*/
    v71._Ptr = (RBX::File *)v60->_Ptr; /*0x141030ec5*/
    v62 = v60->_Rep; /*0x141030eca*/
    v71._Rep = v62; /*0x141030ece*/
    v60->_Ptr = nullptr; /*0x141030ed3*/
    v60->_Rep = nullptr; /*0x141030ed6*/
    __wind /*0xf1c0000000000044*/
    {
      v63 = v84._Rep; /*0x141030eda*/
      if ( v84._Rep != nullptr ) /*0x141030ee1*/
      {
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v84._Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x141030eed*/
        {
          v63->_Destroy(this: v63); /*0x141030ef5*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v63->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141030f01*/
            v63->_Delete_this(this: v63); /*0x141030f09*/
        }
        v62 = v71._Rep; /*0x141030f0c*/
      }
      __wind /*0xf1c0000000000038*/
      {
        setName = v61->setName; /*0x141030f14*/
        ptr.text._Mypair._Myval2._Myres = 15; /*0x141030f1f*/
        ptr.text._Mypair._Myval2._Mysize = 7; /*0x141030f27*/
        qmemcpy(&ptr, "Networ", 6); /*0x141030f35*/
        *(_WORD *)&ptr.text._Mypair._Myval2._Bx._Alias[6] = (unsigned __int8)aNetwork[6]; /*0x141030f4a*/
        setName(this: v61, a2: &ptr.text); /*0x141030f58*/
        if ( ptr.text._Mypair._Myval2._Myres >= 0x10 ) /*0x141030f64*/
        {
          v65 = ptr.text._Mypair._Myval2._Bx._Ptr; /*0x141030f69*/
          if ( ptr.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141030f77*/
          {
            v65 = *((char **)ptr.text._Mypair._Myval2._Bx._Ptr - 1); /*0x141030f7d*/
            if ( (unsigned __int64)(ptr.text._Mypair._Myval2._Bx._Ptr - v65 - 8) > 0x1F ) /*0x141030f8c*/
              _invalid_parameter_noinfo_noreturn(); /*0x141030f8e*/
          }
          operator delete(ptr: v65); /*0x141030f95*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: &ptr); /*0xf1c0000000000030*/
      }
      v79 = 0; /*0x141030f9d*/
      RBX::Instance::setParentInternal( /*0x141030fb9*/
        this: v71._Ptr,
        newParent: v59,
        ignoreLock: false,
        destroying: false,
        destroyedGuids: &v79);
      if ( v62 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v62->_Uses, 0xFFFFFFFF) == 1 ) /*0x141030fce*/
      {
        v71._Rep->_Destroy(this: v71._Rep); /*0x141030fdb*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v71._Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141030fe5*/
          v71._Rep->_Delete_this(this: v71._Rep); /*0x141030fef*/
      }
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: &v71); /*0xf1c0000000000024*/
    }
  }
}

// Address: 0x141031270 | Name: ?recvExtAntiCheatHelper@Peer@Network@RBX@@QEAAXPEAUPacket@RakNet@@AEAW4ExtAntiCheatSubtype@23@AEAIAEAV?$vector@EV?$allocator@E@std@@@std@@@Z
void __fastcall RBX::Network::Peer::recvExtAntiCheatHelper(
        RBX::Network::Peer *this,
        RakNet::Packet *packet,
        RBX::Network::ExtAntiCheatSubtype *subtype,
        unsigned int *sequenceNumber,
        std::vector<unsigned char> *msg)
{
  __int16 v7; // ax
  unsigned int v8; // edi
  unsigned __int8 *Myfirst; // rcx
  RBX::Network::NetworkStream inBitstream; // [rsp+20h] [rbp-48h] BYREF

  RBX::Network::NetworkStream::NetworkStream( /*0x141031290*/
    this: &inBitstream,
    _data: packet->data,
    lengthInBytes: packet->length,
    copyData: false);
  __wind /*0xf1c0000000000010*/
  {
    RBX::Network::NetworkStream::IgnoreBytes(this: &inBitstream, numberOfBytes: 1u); /*0x1410312a0*/
    RBX::Network::NetworkStream::readBytes(this: &inBitstream, inOutByteArray: subtype, numberOfBytesToRead: 1u); /*0x1410312b3*/
    if ( *subtype <= MaxEnum ) /*0x1410312bb*/
    {
      *sequenceNumber = RBX::Network::NetworkStream::readUInt32(this: &inBitstream); /*0x1410312db*/
      if ( *subtype == SendMsg ) /*0x1410312e0*/
      {
        v7 = RBX::Network::NetworkStream::readInt16(this: &inBitstream); /*0x1410312e7*/
        v8 = v7; /*0x1410312ec*/
        std::vector<unsigned char>::resize(this: msg, _Newsize: v7); /*0x1410312fe*/
        RBX::Network::NetworkStream::readBytes( /*0x14103130e*/
          this: &inBitstream,
          inOutByteArray: msg->_Mypair._Myval2._Myfirst,
          numberOfBytesToRead: v8);
      }
    }
    else
    {
      *subtype = MaxEnum; /*0x1410312bd*/
      std::vector<unsigned char>::resize(this: msg, _Newsize: 0); /*0x1410312ca*/
    }
  }
  __unwind
  {
    RBX::Network::NetworkStream::~NetworkStream(this: &inBitstream); /*0xf1c0000000000008*/
  }
  Myfirst = inBitstream.dataVector._Mypair._Myval2._Myfirst; /*0x141031314*/
  if ( inBitstream.dataVector._Mypair._Myval2._Myfirst != nullptr ) /*0x14103131c*/
  {
    if ( (unsigned __int8 *)(inBitstream.dataVector._Mypair._Myval2._Myend /*0x141031330*/
                           - inBitstream.dataVector._Mypair._Myval2._Myfirst) >= (unsigned __int8 *)0x1000 )
    {
      Myfirst = *((unsigned __int8 **)inBitstream.dataVector._Mypair._Myval2._Myfirst - 1); /*0x141031336*/
      if ( (unsigned __int64)(inBitstream.dataVector._Mypair._Myval2._Myfirst - Myfirst - 8) > 0x1F ) /*0x141031345*/
        _invalid_parameter_noinfo_noreturn(); /*0x141031347*/
    }
    operator delete(ptr: Myfirst); /*0x14103134e*/
  }
}

// Address: 0x141031360 | Name: ?sendExtAntiCheatAckHelper@Peer@Network@RBX@@QEAAIUSystemAddress@RakNet@@I@Z
__int64 __fastcall RBX::Network::Peer::sendExtAntiCheatAckHelper(
        RBX::Network::Peer *this,
        RakNet::SystemAddress *addr,
        unsigned int sequenceNumber)
{
  Luau::InternalErrorReporter *v6; // rdi
  std::_Func_base<void,char const *>_vtbl *v7; // rbx
  unsigned int v8; // ebx
  unsigned __int8 *Myfirst; // rcx
  RakNet::RakNetGUID v11; // [rsp+40h] [rbp-78h] BYREF
  RakNet::SystemAddress v12; // [rsp+50h] [rbp-68h] BYREF
  RBX::Network::NetworkStream bitStream; // [rsp+70h] [rbp-48h] BYREF
  unsigned __int8 inOutByteArray; // [rsp+C0h] [rbp+8h] BYREF
  unsigned int inByteArray; // [rsp+D0h] [rbp+18h] BYREF

  RBX::Network::NetworkStream::NetworkStream(this: &bitStream); /*0x141031380*/
  LOBYTE(inByteArray) = -100; /*0x141031386*/
  __wind /*0xf1c0000000000010*/
  {
    RBX::Network::NetworkStream::writeBytes(this: &bitStream, &inByteArray, numberOfBytesToWrite: 1u); /*0x1410313a1*/
    LOBYTE(inByteArray) = 1; /*0x1410313a6*/
    RBX::Network::NetworkStream::writeBytes(this: &bitStream, &inByteArray, numberOfBytesToWrite: 1u); /*0x1410313c1*/
    inByteArray = sequenceNumber; /*0x1410313c6*/
    RBX::Network::NetworkStream::ReverseBytes((unsigned __int8 *)&inByteArray, &inOutByteArray, length: 4u); /*0x1410313e3*/
    RBX::Network::NetworkStream::writeBytes(this: &bitStream, inByteArray: &inOutByteArray, numberOfBytesToWrite: 4u); /*0x1410313fb*/
    v6 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x14103140c*/
    v7 = v6->onInternalError._Mystorage._Ptrs[0][20].__vftable; /*0x141031412*/
    RakNet::RakNetGUID::RakNetGUID(this: &v11); /*0x14103141e*/
    RakNet::SystemAddress::SystemAddress(this: &v12); /*0x141031428*/
    v11 = RakNet::UNASSIGNED_RAKNET_GUID_17; /*0x141031434*/
    RakNet::SystemAddress::operator=(this: &v12, input: addr); /*0x14103144d*/
    v8 = ((__int64 (__fastcall *)(Luau::InternalErrorReporter *, RBX::Network::NetworkStream *, _QWORD, __int64, char, RakNet::RakNetGUID *, _BYTE, _DWORD))v7)( /*0x141031481*/
           a1: v6,
           a2: &bitStream,
           a3: 0,
           a4: 3,
           a5: 1,
           a6: &v11,
           a7: 0,
           a8: 0);
  }
  __unwind
  {
    RBX::Network::NetworkStream::~NetworkStream(this: &bitStream); /*0xf1c0000000000008*/
  }
  Myfirst = bitStream.dataVector._Mypair._Myval2._Myfirst; /*0x141031483*/
  if ( bitStream.dataVector._Mypair._Myval2._Myfirst != nullptr ) /*0x14103148e*/
  {
    if ( (unsigned __int8 *)(bitStream.dataVector._Mypair._Myval2._Myend - bitStream.dataVector._Mypair._Myval2._Myfirst) >= (unsigned __int8 *)0x1000 ) /*0x1410314a5*/
    {
      Myfirst = *((unsigned __int8 **)bitStream.dataVector._Mypair._Myval2._Myfirst - 1); /*0x1410314ab*/
      if ( (unsigned __int64)(bitStream.dataVector._Mypair._Myval2._Myfirst - Myfirst - 8) > 0x1F ) /*0x1410314ba*/
        _invalid_parameter_noinfo_noreturn(); /*0x1410314bc*/
    }
    operator delete(ptr: Myfirst); /*0x1410314c3*/
  }
  return v8; /*0x1410314ca*/
}

// Address: 0x1410314e0 | Name: ?sendExtAntiCheatHelper@Peer@Network@RBX@@QEAAIAEBV?$vector@EV?$allocator@E@std@@@std@@USystemAddress@RakNet@@I@Z
__int64 __fastcall RBX::Network::Peer::sendExtAntiCheatHelper(
        RBX::Network::Peer *this,
        const std::vector<unsigned char> *msg,
        RakNet::SystemAddress *addr,
        unsigned int sequenceNumber)
{
  Luau::InternalErrorReporter *v8; // rdi
  std::_Func_base<void,char const *>_vtbl *v9; // rbx
  unsigned int v10; // ebx
  unsigned __int8 *Myfirst; // rcx
  RakNet::RakNetGUID v13; // [rsp+40h] [rbp-29h] BYREF
  RakNet::SystemAddress v14; // [rsp+50h] [rbp-19h] BYREF
  RBX::Network::NetworkStream bitStream; // [rsp+70h] [rbp+7h] BYREF
  unsigned __int8 inOutByteArray; // [rsp+D0h] [rbp+67h] BYREF
  unsigned int inByteArray; // [rsp+E8h] [rbp+7Fh] BYREF

  RBX::Network::NetworkStream::NetworkStream(this: &bitStream); /*0x14103150a*/
  LOBYTE(inByteArray) = -100; /*0x141031510*/
  __wind /*0xf1c0000000000010*/
  {
    RBX::Network::NetworkStream::writeBytes(this: &bitStream, &inByteArray, numberOfBytesToWrite: 1u); /*0x141031522*/
    LOBYTE(inByteArray) = 0; /*0x141031527*/
    RBX::Network::NetworkStream::writeBytes(this: &bitStream, &inByteArray, numberOfBytesToWrite: 1u); /*0x141031539*/
    inByteArray = sequenceNumber; /*0x14103153e*/
    RBX::Network::NetworkStream::ReverseBytes((unsigned __int8 *)&inByteArray, &inOutByteArray, length: 4u); /*0x14103154f*/
    RBX::Network::NetworkStream::writeBytes(this: &bitStream, inByteArray: &inOutByteArray, numberOfBytesToWrite: 4u); /*0x141031562*/
    LOWORD(inByteArray) = LOWORD(msg->_Mypair._Myval2._Mylast) - LOWORD(msg->_Mypair._Myval2._Myfirst); /*0x14103156e*/
    RBX::Network::NetworkStream::ReverseBytes((unsigned __int8 *)&inByteArray, &inOutByteArray, length: 2u); /*0x141031580*/
    RBX::Network::NetworkStream::writeBytes(this: &bitStream, inByteArray: &inOutByteArray, numberOfBytesToWrite: 2u); /*0x141031593*/
    RBX::Network::NetworkStream::writeBytes( /*0x1410315a6*/
      this: &bitStream,
      inByteArray: msg->_Mypair._Myval2._Myfirst,
      numberOfBytesToWrite: LODWORD(msg->_Mypair._Myval2._Mylast) - LODWORD(msg->_Mypair._Myval2._Myfirst));
    v8 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x1410315b7*/
    v9 = v8->onInternalError._Mystorage._Ptrs[0][20].__vftable; /*0x1410315bd*/
    RakNet::RakNetGUID::RakNetGUID(this: &v13); /*0x1410315c8*/
    RakNet::SystemAddress::SystemAddress(this: &v14); /*0x1410315d1*/
    v13 = RakNet::UNASSIGNED_RAKNET_GUID_17; /*0x1410315dd*/
    RakNet::SystemAddress::operator=(this: &v14, input: addr); /*0x1410315f3*/
    v10 = ((__int64 (__fastcall *)(Luau::InternalErrorReporter *, RBX::Network::NetworkStream *, _QWORD, __int64, char, RakNet::RakNetGUID *, _BYTE, _DWORD))v9)( /*0x141031625*/
            a1: v8,
            a2: &bitStream,
            a3: 0,
            a4: 3,
            a5: 1,
            a6: &v13,
            a7: 0,
            a8: 0);
  }
  __unwind
  {
    RBX::Network::NetworkStream::~NetworkStream(this: &bitStream); /*0xf1c0000000000008*/
  }
  Myfirst = bitStream.dataVector._Mypair._Myval2._Myfirst; /*0x141031627*/
  if ( bitStream.dataVector._Mypair._Myval2._Myfirst != nullptr ) /*0x14103162e*/
  {
    if ( (unsigned __int8 *)(bitStream.dataVector._Mypair._Myval2._Myend - bitStream.dataVector._Mypair._Myval2._Myfirst) >= (unsigned __int8 *)0x1000 ) /*0x141031641*/
    {
      Myfirst = *((unsigned __int8 **)bitStream.dataVector._Mypair._Myval2._Myfirst - 1); /*0x141031647*/
      if ( (unsigned __int64)(bitStream.dataVector._Mypair._Myval2._Myfirst - Myfirst - 8) > 0x1F ) /*0x141031656*/
        _invalid_parameter_noinfo_noreturn(); /*0x141031658*/
    }
    operator delete(ptr: Myfirst); /*0x14103165f*/
  }
  return v10; /*0x141031666*/
}

// Address: 0x141031680 | Name: ?setOutgoingKBPSLimit@Peer@Network@RBX@@QEAAXH@Z
void __fastcall RBX::Network::Peer::setOutgoingKBPSLimit(RBX::Network::Peer *this, int limit)
{
  RBX::Network::ConcurrentRakPeer *Ptr; // rcx
  int v3; // ebx
  Luau::InternalErrorReporter *v4; // rax
  Luau::InternalErrorReporter *v5; // rax
  std::_Func_base<void,char const *>_vtbl *v6; // r8

  Ptr = this->rakPeer._Ptr; /*0x141031686*/
  v3 = limit; /*0x14103168d*/
  if ( limit > 0 ) /*0x141031691*/
  {
    v5 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)Ptr); /*0x1410316ac*/
    v6 = v5->onInternalError._Mystorage._Ptrs[0][70].__vftable; /*0x1410316b4*/
    if ( v3 > 10 ) /*0x1410316be*/
    {
      if ( v3 >= 10000 ) /*0x1410316dd*/
        v3 = 10000; /*0x1410316dd*/
      ((void (__fastcall *)(Luau::InternalErrorReporter *, _QWORD))v6)(a1: v5, a2: (unsigned int)(1000 * v3)); /*0x1410316ee*/
    }
    else
    {
      ((void (__fastcall *)(Luau::InternalErrorReporter *, __int64))v6)(a1: v5, a2: 10000); /*0x1410316d3*/
    }
  }
  else
  {
    v4 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)Ptr); /*0x141031693*/
    ((void (__fastcall *)(Luau::InternalErrorReporter *, _QWORD))v4->onInternalError._Mystorage._Ptrs[0][70].__vftable)( /*0x1410316a5*/
      a1: v4,
      a2: 0);
  }
}

// END Peer part 1/1, 17 functions
