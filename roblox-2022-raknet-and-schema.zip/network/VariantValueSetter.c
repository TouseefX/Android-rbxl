// VariantValueSetter -- 2022 Studio + full PDB
// tier 3, 1 functions


// Address: 0x14104ffe0 | Name: ??$schemaReadValue@VVariantValueSetter@Network@RBX@@@Replicator@Network@RBX@@IEAAXAEAVNetworkStream@12@AEBUType@NetworkSchema@12@_NAEAVVariantValueSetter@12@_KAEAV?$unordered_map@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@V?$vector@UDeferredSharedStringSetter@Network@RBX@@V?$allocator@UDeferredSharedStringSetter@Network@RBX@@@std@@@2@U?$hash@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@boost@@U?$equal_to@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@2@V?$allocator@U?$pair@$$CBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@V?$vector@UDeferredSharedStringSetter@Network@RBX@@V?$allocator@UDeferredSharedStringSetter@Network@RBX@@@std@@@2@@std@@@2@@unordered@boost@@AEAUReplicationVariantSizeLimitsMetaData@12@@Z
// local variable allocation has failed, the output may be wrong!
void __fastcall RBX::Network::Replicator::schemaReadValue<RBX::Network::VariantValueSetter>(
        RBX::Network::Replicator *this,
        RBX::Network::NetworkStream *inBitStream,
        const RBX::Network::NetworkSchema::Type *valueType,
        _BOOL8 useDictionaries,
        RBX::Network::VariantValueSetter *out,
        unsigned __int64 depth,
        boost::unordered::unordered_map<std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string >,std::equal_to<std::string >,std::allocator<std::pair<std::string const ,std::vector<RBX::Network::DeferredSharedStringSetter> > > > *deferredSharedStrings,
        RBX::Network::ReplicationVariantSizeLimitsMetaData *replicationMetaData)
{
  bool v8; // si
  unsigned int readOffset; // r10d
  RBX::Network::ReplicationVariantSizeLimitsMetaData *v14; // r13
  unsigned __int64 v15; // r9
  const RBX::Reflection::EnumDescriptor *localEnumDescriptor; // rcx
  unsigned __int64 v17; // rdi
  _BYTE *v18; // rax
  RBX::UniqueId *v19; // rdx
  RBX::UniqueId *v20; // r10
  RBX::UniqueId *v21; // r8
  unsigned __int64 v22; // r9
  size_t v23; // rsi
  RBX::UniqueId *v24; // r10
  RBX::UniqueId *v25; // rax
  unsigned __int64 v26; // rdi
  __int64 v27; // rdi
  unsigned __int64 v28; // r13
  unsigned __int64 v29; // r12
  boost::unordered::detail::ptr_bucket *v30; // rbx
  boost::unordered::detail::ptr_bucket *v31; // rbx
  boost::unordered::detail::ptr_bucket *v32; // rax
  boost::unordered::detail::ptr_bucket *v33; // rdx
  RBX::UniqueId *v34; // rcx
  char *v35; // rcx
  const RBX::ProtectedString *v36; // rax
  RBX::Network::VariantValueSetter *v37; // rbx
  std::pair<std::string const ,std::vector<RBX::Network::DeferredSharedStringSetter> > *v38; // rax
  RBX::Instance *v39; // rax
  void *v40; // rcx
  unsigned __int64 v41; // rdi
  _BYTE *v42; // rax
  RBX::UniqueId *v43; // rdx
  RBX::UniqueId *v44; // r10
  RBX::UniqueId *v45; // r8
  unsigned __int64 v46; // r9
  size_t v47; // rsi
  RBX::UniqueId *v48; // r10
  RBX::UniqueId *v49; // rax
  unsigned __int64 v50; // rdi
  __int64 v51; // rdi
  unsigned __int64 bucket_count; // r13
  __int64 v53; // r12
  boost::unordered::detail::ptr_bucket *next; // rbx
  boost::unordered::detail::ptr_bucket *v55; // rbx
  boost::unordered::detail::ptr_bucket *v56; // rcx
  boost::unordered::detail::ptr_bucket *v57; // rdx
  RBX::UniqueId *v58; // rcx
  char *Ptr; // rcx
  const RBX::ProtectedString *v60; // rax
  std::pair<std::string const ,std::vector<RBX::Network::DeferredSharedStringSetter> > *v61; // rax
  int PayloadLimit; // eax
  RBX::Reflection::Variant *variant; // rsi
  const rbx::implementation::typed_holder<std::string > *v64; // r12
  const rbx::implementation::type_holder *holder; // rax
  RBX::UniqueId *p_uid; // rdx
  int v67; // eax
  const RBX::SharedString *v68; // rax
  RBX::Reflection::Variant *v69; // rbx
  const rbx::implementation::typed_holder<RBX::BinaryString> *v70; // r12
  const rbx::implementation::type_holder *v71; // rax
  RBX::UniqueId *v72; // rdx
  bool Bool; // di
  RBX::Reflection::Variant *v74; // rbx
  const rbx::implementation::typed_holder<bool> *v75; // rsi
  const rbx::implementation::type_holder *v76; // rax
  RBX::Network::VariantValueSetter *v77; // rcx
  float Float; // xmm6_4
  RBX::Reflection::Variant *v79; // rbx
  const rbx::implementation::typed_holder<float> *v80; // rdi
  const rbx::implementation::type_holder *v81; // rax
  long double Double; // xmm6_8
  RBX::Reflection::Variant *v83; // rbx
  const rbx::implementation::typed_holder<double> *v84; // rdi
  const rbx::implementation::type_holder *v85; // rax
  RBX::UDim *UDim; // rsi
  RBX::Reflection::Variant *v87; // rbx
  const rbx::implementation::typed_holder<RBX::UDim> *v88; // r12
  const rbx::implementation::type_holder *v89; // rax
  RBX::Rect2D *UDim2; // rsi
  RBX::Reflection::Variant *v91; // rbx
  const rbx::implementation::typed_holder<RBX::UDim2> *v92; // rax
  const rbx::implementation::typed_holder<RBX::UDim2> *v93; // r12
  const rbx::implementation::type_holder *v94; // rax
  RBX::PhysicalProperties *Ray; // rsi
  RBX::Reflection::Variant *v96; // rbx
  const rbx::implementation::typed_holder<RBX::PhysicalProperties> *v97; // rax
  const rbx::implementation::typed_holder<RBX::PhysicalProperties> *v98; // r12
  const rbx::implementation::type_holder *v99; // rax
  RBX::Vector2int16 *Faces; // rsi
  RBX::Reflection::Variant *v101; // rbx
  const rbx::implementation::typed_holder<RBX::BrickColor> *v102; // rax
  const rbx::implementation::typed_holder<RBX::BrickColor> *v103; // r12
  const rbx::implementation::type_holder *v104; // rax
  RBX::Vector3 *Region3int16; // rsi
  RBX::Reflection::Variant *v106; // rbx
  const rbx::implementation::typed_holder<RBX::Vector3> *v107; // r12
  const rbx::implementation::type_holder *v108; // rax
  RBX::Color3uint8 *Color3uint8; // rsi
  RBX::Reflection::Variant *v110; // rbx
  const rbx::implementation::typed_holder<RBX::Color3uint8> *v111; // r12
  const rbx::implementation::type_holder *v112; // rax
  RBX::Vector2 *NumberRange; // rsi
  RBX::Reflection::Variant *v114; // rbx
  const rbx::implementation::typed_holder<RBX::Vector2> *v115; // r12
  const rbx::implementation::type_holder *v116; // rax
  RBX::Vector3int16 *Vector3int16; // rsi
  RBX::Reflection::Variant *v118; // rbx
  const rbx::implementation::typed_holder<RBX::Vector3int16> *v119; // r12
  const rbx::implementation::type_holder *v120; // rax
  const RBX::CoordinateFrame *v121; // rax
  const RBX::OptionalCoordinateFrame *OptionalCoordinateFrame; // rax
  RBX::Reflection::Variant *v123; // rsi
  const rbx::implementation::type_holder *v124; // rax
  std::_Ref_count_base *v125; // rbx
  std::_Ref_count_base *v126; // rcx
  RBX::Network::VariantValueSetter *v127; // r13
  RBX::Reflection::RefPropDescriptor<RBX::Instance,RBX::Instance> *optionalPropertyDesc; // r12
  RBX::Instance *optionalInstance; // rbx
  std::_Ref_count_base *Rep; // rdx
  signed __int32 Uses; // eax
  signed __int32 v132; // ett
  RBX::Reflection::DescribedBase *v133; // rsi
  std::_Ref_count_base *v134; // rbx
  RBX::Guid *optionalUnresolvedGuid; // rcx
  RBX::Reflection::Tuple *v136; // rax
  char *v137; // r12
  unsigned int v138; // ebx
  boost::unordered::unordered_map<std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string >,std::equal_to<std::string >,std::allocator<std::pair<std::string const ,std::vector<RBX::Network::DeferredSharedStringSetter> > > > *v139; // r13
  std::_Ref_count_base *v140; // rbx
  RBX::Reflection::Variant *v141; // rsi
  const rbx::implementation::typed_holder<std::shared_ptr<RBX::Reflection::Tuple const > > *v142; // r13
  const rbx::implementation::type_holder *v143; // rax
  std::_Ref_count_base *v144; // rcx
  std::vector<RBX::Reflection::Variant> *v145; // rax
  std::vector<RBX::Reflection::Variant> *v146; // rax
  unsigned int v147; // ebx
  char *v148; // r12
  boost::unordered::unordered_map<std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string >,std::equal_to<std::string >,std::allocator<std::pair<std::string const ,std::vector<RBX::Network::DeferredSharedStringSetter> > > > *v149; // r13
  RBX::Network::ReplicationVariantSizeLimitsMetaData *v150; // rdi
  std::_Ref_count_base *v151; // rbx
  RBX::Reflection::Variant *v152; // rsi
  const rbx::implementation::typed_holder<std::shared_ptr<std::vector<RBX::Reflection::Variant> const > > *v153; // r13
  const rbx::implementation::type_holder *v154; // rax
  std::_Ref_count_base *v155; // rcx
  std::unordered_map<std::string,RBX::Reflection::Variant> *v156; // rax
  std::unordered_map<std::string,RBX::Reflection::Variant> *v157; // rax
  unsigned int v158; // ebx
  boost::unordered::unordered_map<std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string >,std::equal_to<std::string >,std::allocator<std::pair<std::string const ,std::vector<RBX::Network::DeferredSharedStringSetter> > > > *v159; // r12
  unsigned __int64 v160; // rdi
  int v161; // eax
  std::pair<std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *,bool> *v162; // rax
  RBX::Reflection::Variant *v163; // rsi
  const rbx::implementation::typed_holder<std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const > > *v164; // r12
  const rbx::implementation::type_holder *v165; // rax
  std::_Ref_count_base *v166; // rbx
  std::_Ref_count_base *v167; // rcx
  char *v168; // rcx
  std::map<std::string,cricket::RidDescription> *v169; // rax
  std::map<std::string,RBX::Reflection::Variant> *v170; // rax
  unsigned int v171; // ebx
  char *v172; // r12
  boost::unordered::unordered_map<std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string >,std::equal_to<std::string >,std::allocator<std::pair<std::string const ,std::vector<RBX::Network::DeferredSharedStringSetter> > > > *v173; // r13
  RBX::Network::ReplicationVariantSizeLimitsMetaData *v174; // rdi
  int v175; // eax
  std::pair<std::_Tree_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *,bool> *v176; // rax
  std::_Ref_count_base *v177; // rbx
  RBX::Reflection::Variant *v178; // rsi
  const rbx::implementation::typed_holder<std::shared_ptr<std::map<std::string,RBX::Reflection::Variant> const > > *v179; // r13
  const rbx::implementation::type_holder *v180; // rax
  std::_Ref_count_base *v181; // rcx
  char *v182; // rcx
  int v183; // eax
  double sec; // xmm2_8
  unsigned __int64 v185; // r8
  RBX::UniqueId *v186; // rdx
  char *v187; // rcx
  int v188; // ebx
  char *v189; // rcx
  RBX::Reflection::Variant *v190; // rbx
  const rbx::implementation::typed_holder<RBX::ContentId> *v191; // rsi
  const rbx::implementation::type_holder *v192; // rax
  unsigned int peerId; // ebx
  RBX::Reflection::Variant *v194; // rdi
  const rbx::implementation::typed_holder<RBX::SystemAddress> *v195; // rsi
  const rbx::implementation::type_holder *v196; // rax
  const std::vector<RBX::FileMeshFace> *NumberSequence; // r12
  RBX::Reflection::Variant *v198; // rbx
  const rbx::implementation::typed_holder<RBX::NumberSequence> *v199; // r13
  const rbx::implementation::type_holder *v200; // rax
  RBX::ColorSequence *ColorSequence; // r12
  RBX::Reflection::Variant *v202; // rbx
  const rbx::implementation::typed_holder<RBX::ColorSequence> *v203; // r13
  const rbx::implementation::type_holder *v204; // rax
  RBX::ColorSequenceKeypoint *ColorSequenceKeypoint; // rsi
  RBX::Reflection::Variant *v206; // rbx
  const rbx::implementation::typed_holder<RBX::ColorSequenceKeypoint> *v207; // r12
  const rbx::implementation::type_holder *v208; // rax
  RBX::Region3 *Region3; // rsi
  RBX::Reflection::Variant *v210; // rbx
  const rbx::implementation::typed_holder<RBX::Region3> *v211; // r12
  const rbx::implementation::type_holder *v212; // rax
  RBX::UniqueId *v213; // rdx
  const RBX::SharedString *v214; // rbx
  std::pair<std::string const ,std::vector<RBX::Network::DeferredSharedStringSetter> > *v215; // rax
  RBX::Network::NetworkSchema::LocalConformance localConformance; // r8d
  const rtc::webrtc_checks_impl::ToStringVal *Contents; // rax
  rtc::webrtc_checks_impl::ToStringVal *v218; // rax
  char *v219; // rcx
  RBX::DateTime *DateTime; // rsi
  RBX::Reflection::Variant *v221; // rbx
  const rbx::implementation::typed_holder<RBX::DateTime> *v222; // r12
  const rbx::implementation::type_holder *v223; // rax
  unsigned __int8 Byte; // al
  unsigned __int8 v225; // al
  unsigned int v226; // ecx
  const std::string *v227; // rax
  unsigned int v228; // ebx
  RBX::UniqueId *v229; // rdx
  int v230; // eax
  unsigned __int64 UInt64; // rdi
  unsigned int UInt32; // ebx
  unsigned int v233; // esi
  int v234; // eax
  const RBX::PathWaypoint *PathWaypointWithLabel; // rax
  int v236; // eax
  const RBX::Text::FontInfo *Font; // rax
  bool v238; // r8
  bool v239; // r9
  bool v240; // r12
  unsigned int v241; // esi
  bool v242; // di
  bool v243; // bl
  unsigned int replicatedStringDataSizeLimit; // eax
  unsigned int variantCountLimit; // eax
  bool v246; // r10
  bool v247; // r11
  unsigned int replicatedStringDataSizeReportingThreshold; // eax
  unsigned int variantCountReportingThreshold; // eax
  bool v250; // r14
  bool v251; // al
  bool v252; // zf
  RBX::Network::ReplicationVariantSizeLimitsMetaData *v253; // r14
  RBX::Network::ServerReplicator *v254; // rax
  ShareModalAnalytics *v255; // rax
  const std::string *v256; // rax
  unsigned int NumberOfUnreadBytes; // eax
  const std::string *v258; // rax
  const std::string *v259; // rax
  const std::string *v260; // rax
  const std::string *v261; // rax
  RBX::UniqueId uid; // [rsp+40h] [rbp-C0h] BYREF
  size_t Size; // [rsp+50h] [rbp-B0h]
  unsigned __int64 v264; // [rsp+58h] [rbp-A8h]
  std::string instance; // [rsp+60h] [rbp-A0h] OVERLAPPED BYREF
  unsigned int size; // [rsp+80h] [rbp-80h] BYREF
  unsigned int count[3]; // [rsp+84h] [rbp-7Ch] BYREF
  RBX::Vector3 value; // [rsp+90h] [rbp-70h] BYREF
  unsigned int v269; // [rsp+A0h] [rbp-60h] BYREF
  unsigned int v270; // [rsp+A4h] [rbp-5Ch] BYREF
  RBX::Guid data; // [rsp+A8h] [rbp-58h] BYREF
  RBX::Network::DeferredSharedStringSetter v272; // [rsp+B0h] [rbp-50h] BYREF
  std::_Ref_count_base *v273[2]; // [rsp+D0h] [rbp-30h] BYREF
  std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> > v274; // [rsp+E0h] [rbp-20h] BYREF
  std::string keyBuffer; // [rsp+F0h] [rbp-10h] BYREF
  std::string _Keyval; // [rsp+110h] [rbp+10h] BYREF
  RBX::CoordinateFrame cFrame; // [rsp+130h] [rbp+30h] BYREF
  RBX::Analytics::InfluxDb::Points points; // [rsp+170h] [rbp+70h] BYREF
  std::string result; // [rsp+1E0h] [rbp+E0h] BYREF
  std::_String_val<std::_Simple_types<char> >::_Bxty Bx; // [rsp+200h] [rbp+100h] BYREF
  std::_String_val<std::_Simple_types<char> >::_Bxty v281; // [rsp+210h] [rbp+110h] BYREF
  std::_String_val<std::_Simple_types<char> >::_Bxty v282; // [rsp+220h] [rbp+120h] BYREF
  RBX::Guid networkId; // [rsp+288h] [rbp+188h] BYREF
  unsigned int v284; // [rsp+290h] [rbp+190h]

  v8 = useDictionaries; /*0x141050007*/
  readOffset = inBitStream->readOffset; /*0x141050014*/
  v284 = readOffset; /*0x141050018*/
  if ( valueType->valueFormat == NetworkValueFormat_Unsupported )
  {
    RBX::runtime_error(result: (std::runtime_error *)&uid, fmt: "Cannot read value: value sent via unsupported format");
    throw (std::runtime_error *)&uid; /*0x141052536*/
  }
  v14 = replicationMetaData; /*0x14105004a*/
  v15 = depth; /*0x141050051*/
  switch ( valueType->valueFormat )
  {
    case NetworkValueFormat_String_NeverDictionary:
      *(_QWORD *)&uid.sessionId.bits_hi = 0; /*0x1410506a0*/
      Size = 0; /*0x1410506a5*/
      v264 = 15; /*0x1410506aa*/
      PayloadLimit = RBX::Network::Replicator::getReadPayloadLimit(this); /*0x1410506bb*/
      RBX::Network::deserializeString(value: (std::string *)&uid, stream: inBitStream, maxStringReadSize: PayloadLimit); /*0x1410506cb*/
      v14->replicatedStringDataSize += Size; /*0x1410506d4*/
      variant = out->variant; /*0x1410506df*/
      variant->_type = RBX::Reflection::Type::getSingleton<std::string>(); /*0x1410506e8*/
      v64 = rbx::implementation::typed_holder<std::string>::singleton(); /*0x1410506f0*/
      holder = variant->value.holder; /*0x1410506f3*/
      if ( holder == v64 ) /*0x1410506fe*/
      {
        if ( variant->value.data != (char *)&uid ) /*0x141050708*/
        {
          p_uid = &uid; /*0x14105070a*/
          if ( v264 >= 0x10 ) /*0x141050715*/
            p_uid = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x141050715*/
          std::string::assign(this: (std::string *)variant->value.data, _Ptr: (const char *const)p_uid, _Count: Size); /*0x141050723*/
        }
      }
      else
      {
        if ( holder != nullptr ) /*0x14105072d*/
        {
          holder->destruct(a1: variant->value.data); /*0x141050736*/
          variant->value.holder = nullptr; /*0x141050738*/
        }
        std::string::string( /*0x141050744*/
          this: (rtc::webrtc_checks_impl::ToStringVal *)variant->value.data,
          __that: (const rtc::webrtc_checks_impl::ToStringVal *)&uid);
        variant->value.holder = v64; /*0x141050749*/
      }
      if ( v264 < 0x10 ) /*0x141050756*/
        goto LABEL_438; /*0x141050756*/
      v40 = *(void **)&uid.sessionId.bits_hi; /*0x14105075f*/
      if ( v264 + 1 >= 0x1000 ) /*0x14105076e*/
      {
        v40 = *(void **)(*(_QWORD *)&uid.sessionId.bits_hi - 8LL); /*0x141050778*/
        if ( (unsigned __int64)(*(_QWORD *)&uid.sessionId.bits_hi - (_QWORD)v40 - 8LL) > 0x1F ) /*0x141050787*/
          _invalid_parameter_noinfo_noreturn(); /*0x14105078d*/
      }
      goto LABEL_608; /*0x141050787*/
    case NetworkValueFormat_ProtectedStringServerIndexString:
      goto $LN2_10;
    case NetworkValueFormat_ProtectedStringSource:
      v41 = 0; /*0x1410503c6*/
      v42 = operator new(size: 0x20u); /*0x1410503e3*/
      __eh34_enter_wind_state(-1, 0); /*0xf1c00000000003bc*/
      Size = 16; /*0x1410503e8*/
      v264 = 31; /*0x1410503f1*/
      *(_OWORD *)v42 = 0; /*0x1410503fd*/
      v42[16] = 0; /*0x141050400*/
      *(_QWORD *)&uid.sessionId.bits_hi = v42; /*0x141050404*/
      RBX::SharedString::SharedString(this: (RBX::SharedString *)&instance); /*0x14105040e*/
      v43 = &uid; /*0x141050414*/
      if ( v264 >= 0x10 ) /*0x14105041f*/
        v43 = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x14105041f*/
      __eh34_enter_wind_state(0, 1); /*0xf1c00000000003b4*/
      RBX::Network::NetworkStream::readBytes(this: inBitStream, inOutByteArray: (void *)v43, numberOfBytesToRead: 0x10u); /*0x14105042c*/
      v44 = &uid; /*0x141050431*/
      v45 = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x141050436*/
      v46 = v264; /*0x14105043b*/
      if ( v264 >= 0x10 ) /*0x141050444*/
        v44 = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x141050444*/
      v47 = Size; /*0x141050448*/
      v48 = &v44[Size / 0x10]; /*0x14105044d*/
      v49 = &uid; /*0x141050450*/
      if ( v264 >= 0x10 ) /*0x141050459*/
        v49 = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x141050459*/
      if ( v49 != v48 ) /*0x141050460*/
      {
        do /*0x141050495*/
        {
          v41 ^= (v41 >> 2) + 2654435769u + (v41 << 6) + SLOBYTE(v49->sessionId.bits_hi); /*0x14105048c*/
          v49 = (RBX::UniqueId *)((char *)v49 + 1); /*0x14105048f*/
        }
        while ( v49 != v48 ); /*0x141050495*/
        v45 = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x141050497*/
        v46 = v264; /*0x14105049c*/
      }
      v50 = 21 /*0x1410504c9*/
          * ((265 * ((~v41 + (v41 << 21)) ^ ((~v41 + (v41 << 21)) >> 24)))
           ^ ((265 * ((~v41 + (v41 << 21)) ^ ((~v41 + (v41 << 21)) >> 24))) >> 14));
      v51 = 2147483649u * ((v50 >> 28) ^ v50); /*0x1410504dc*/
      bucket_count = this->sharedStringReceiverDictionary.table_.bucket_count_; /*0x1410504e0*/
      v53 = v51 & (bucket_count - 1); /*0x1410504eb*/
      if ( this->sharedStringReceiverDictionary.table_.size_ == 0 ) /*0x1410504f6*/
        goto LABEL_69; /*0x1410504f6*/
      next = this->sharedStringReceiverDictionary.table_.buckets_[v53].next_; /*0x141050503*/
      if ( next == nullptr ) /*0x14105050a*/
        goto LABEL_69; /*0x14105050a*/
      v55 = next->next_; /*0x141050510*/
      if ( v55 == nullptr ) /*0x141050516*/
        goto LABEL_69; /*0x141050516*/
      while ( 2 ) /*0x141050520*/
      {
        v56 = v55[1].next_; /*0x141050520*/
        if ( (boost::unordered::detail::ptr_bucket *)v51 == v56 ) /*0x141050527*/
        {
          v57 = v55 + 2; /*0x14105052d*/
          if ( v55[5].next_ >= (boost::unordered::detail::ptr_bucket *)0x10 ) /*0x14105053a*/
            v57 = v57->next_; /*0x14105053c*/
          v58 = &uid; /*0x14105053f*/
          if ( v46 >= 0x10 ) /*0x141050548*/
            v58 = v45; /*0x141050548*/
          if ( (boost::unordered::detail::ptr_bucket *)v47 == v55[4].next_ /*0x14105055f*/
            && memcmp_0(Buf1: v58, Buf2: v57, Size: v47) == 0 )
          {
            if ( DFFlag::ReportSharedStringBreakdown.value ) /*0x141050574*/
              RBX::PolicyServiceAnalyticsStatReporter::incrementCallbackQueueExceededCount(this: (RBX::RVideo::Mp4IoWriter *)&v55[6]); /*0x14105057a*/
            networkId = (RBX::Guid)v55[6].next_; /*0x141050583*/
            _InterlockedIncrement((volatile signed __int32 *)(*(_QWORD *)&networkId + 48LL)); /*0x14105058a*/
            Ptr = instance._Mypair._Myval2._Bx._Ptr; /*0x14105058e*/
            *(RBX::Guid *)instance._Mypair._Myval2._Bx._Buf = networkId; /*0x14105059a*/
            networkId = (RBX::Guid)Ptr; /*0x14105059f*/
            boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: (boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *)&networkId); /*0x1410505ad*/
            *(_DWORD *)&instance._Mypair._Myval2._Bx._Alias[8] = v55[7].next_; /*0x1410505b5*/
            v60 = RBX::ProtectedString::fromTrustedSharedSource( /*0x1410505c2*/
                    result: (RBX::ProtectedString *)&cFrame,
                    trustedString: (const RBX::SharedString *)&instance);
            __eh34_enter_wind_state(1, 2); /*0xf1c00000000003ac*/
            RBX::Network::VariantValueSetter::assignValue<RBX::ProtectedString>(this: out, value: v60); /*0x1410505d2*/
            if ( __eh34_unwind(2) ) /*0xf1c0000000000398*/
              goto unwind_state_2; /*0xf1c0000000000398*/
            __eh34_exit_wind_state(2, 1); /*0xf1c00000000003a4*/
            boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: (boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *)&cFrame.rotation.elt[1][1]); /*0x1410505dc*/
            boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: (boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *)&cFrame); /*0x1410505e5*/
            if ( __eh34_unwind(1) ) /*0xf1c0000000000384*/
              goto unwind_state_1; /*0xf1c0000000000384*/
LABEL_601:
            __eh34_exit_wind_state(1, 0); /*0xf1c0000000000390*/
            boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: (boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *)&instance); /*0x141050651*/
            if ( v264 >= 0x10 ) /*0x141050660*/
            {
              v40 = *(void **)&uid.sessionId.bits_hi; /*0x141050669*/
              if ( v264 + 1 >= 0x1000 ) /*0x141050678*/
              {
                v40 = *(void **)(*(_QWORD *)&uid.sessionId.bits_hi - 8LL); /*0x141050682*/
                if ( (unsigned __int64)(*(_QWORD *)&uid.sessionId.bits_hi - (_QWORD)v40 - 8LL) > 0x1F ) /*0x141050691*/
                  _invalid_parameter_noinfo_noreturn(); /*0x141050697*/
              }
LABEL_43:
              operator delete(ptr: v40); /*0x1410503bc*/
            }
            goto LABEL_494; /*0x1410503c1*/
          }
        }
        else if ( ((unsigned __int64)v56 & (bucket_count - 1)) != v53 ) /*0x1410505f6*/
        {
LABEL_69:
          v61 = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::vector<RBX::Network::DeferredSharedStringSetter>>>,std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string>,std::equal_to<std::string>>>::operator[]( /*0x14105060f*/
                  this: &deferredSharedStrings->table_,
                  k: (const std::string *)&uid);
          *(_OWORD *)&v272.desc = 0; /*0x141050627*/
          v272.variantOut = out->variant; /*0x141050637*/
          v272.localConformance = LocalConformance_NetworkProtectedStringSource; /*0x14105063b*/
          std::vector<RBX::Network::DeferredSharedStringSetter>::emplace_back<RBX::Network::DeferredSharedStringSetter>( /*0x141050646*/
            this: &v61->second,
            <_Val_0>: &v272);
          goto LABEL_601; /*0xf1c0000000000514*/
        }
        v55 = v55->next_; /*0x1410505f8*/
        if ( v55 != nullptr ) /*0x1410505fe*/
        {
          v45 = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x141050600*/
          v46 = v264; /*0x141050605*/
          continue; /*0x14105060a*/
        }
        goto LABEL_69; /*0x1410505fe*/
      }
    case NetworkValueFormat_Enum_VarInt:
      RBX::Network::deserializeUnsignedVarint(value: (unsigned int *)&networkId, stream: inBitStream); /*0x141050064*/
      localEnumDescriptor = out->valueType->localEnumDescriptor; /*0x141050073*/
      if ( localEnumDescriptor != nullptr ) /*0x14105007a*/
        localEnumDescriptor->convertIntValueToTypedVariantIfValidValue( /*0x14105008d*/
          this: (RBX::Reflection::EnumDescriptor *)localEnumDescriptor,
          a2: networkId.scope.peerId.peerId,
          a3: out->variant);
      goto LABEL_438; /*0x141050090*/
    case NetworkValueFormat_BinaryString:
      __wind /*0xf1c0000000000378*/
      {
        *(_QWORD *)&uid.sessionId.bits_hi = 0; /*0x141050796*/
        Size = 0; /*0x14105079b*/
        v264 = 15; /*0x1410507a0*/
        v67 = RBX::Network::Replicator::getReadPayloadLimit(this); /*0x1410507b1*/
        RBX::Network::deserializeString(value: (std::string *)&uid, stream: inBitStream, maxStringReadSize: v67); /*0x1410507c1*/
        v14->replicatedStringDataSize += Size; /*0x1410507ca*/
        if ( valueType->localConformance == LocalConformance_NetworkBinaryStringLocalSharedString ) /*0x1410507d4*/
        {
          v68 = RBX::SharedString::SharedString(this: (RBX::SharedString *)&instance, contents: (std::string *)&uid); /*0x1410507e0*/
          __wind /*0xf1c000000000036c*/
          {
            RBX::Network::VariantValueSetter::assignValue<RBX::SharedString>(this: out, value: v68); /*0x1410507f0*/
          }
          __unwind
          {
            RBX::SharedString::~SharedString(this: (RBX::SharedString *)&instance); /*0xf1c0000000000364*/
          }
          boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: (boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *)&instance); /*0x1410507fb*/
        }
        else
        {
          v69 = out->variant; /*0x141050809*/
          v69->_type = RBX::Reflection::Type::getSingleton<RBX::BinaryString>(); /*0x141050812*/
          v70 = rbx::implementation::typed_holder<RBX::BinaryString>::singleton(); /*0x14105081a*/
          v71 = v69->value.holder; /*0x14105081d*/
          if ( v71 == v70 ) /*0x141050828*/
          {
            if ( v69->value.data != (char *)&uid ) /*0x141050832*/
            {
              v72 = &uid; /*0x141050834*/
              if ( v264 >= 0x10 ) /*0x14105083f*/
                v72 = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x14105083f*/
              std::string::assign(this: (std::string *)v69->value.data, _Ptr: (const char *const)v72, _Count: Size); /*0x14105084d*/
            }
          }
          else
          {
            if ( v71 != nullptr ) /*0x141050857*/
            {
              v71->destruct(a1: v69->value.data); /*0x141050860*/
              v69->value.holder = nullptr; /*0x141050862*/
            }
            std::string::string( /*0x14105086e*/
              this: (rtc::webrtc_checks_impl::ToStringVal *)v69->value.data,
              __that: (const rtc::webrtc_checks_impl::ToStringVal *)&uid);
            v69->value.holder = v70; /*0x141050873*/
          }
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&uid); /*0xf1c0000000000358*/
      }
      if ( v264 < 0x10 ) /*0x141050880*/
        goto LABEL_438; /*0x141050880*/
      v40 = *(void **)&uid.sessionId.bits_hi; /*0x141050889*/
      if ( v264 + 1 >= 0x1000 ) /*0x141050898*/
      {
        v40 = *(void **)(*(_QWORD *)&uid.sessionId.bits_hi - 8LL); /*0x1410508a2*/
        if ( (unsigned __int64)(*(_QWORD *)&uid.sessionId.bits_hi - (_QWORD)v40 - 8LL) > 0x1F ) /*0x1410508b1*/
          _invalid_parameter_noinfo_noreturn(); /*0x1410508b7*/
      }
      goto LABEL_608; /*0x1410508b1*/
    case NetworkValueFormat_Bool:
      Bool = RBX::Network::NetworkStream::readBool(this: inBitStream); /*0x1410508c6*/
      v74 = out->variant; /*0x1410508d0*/
      v74->_type = RBX::Reflection::Type::getSingleton<bool>(); /*0x1410508d9*/
      v75 = rbx::implementation::typed_holder<bool>::singleton(); /*0x1410508e1*/
      v76 = v74->value.holder; /*0x1410508e4*/
      if ( v76 != v75 ) /*0x1410508eb*/
      {
        if ( v76 != nullptr ) /*0x1410508f0*/
          v76->destruct(a1: v74->value.data); /*0x1410508fa*/
        v74->value.holder = v75; /*0x1410508fc*/
      }
      v74->value.data[0] = Bool; /*0x141050900*/
      goto LABEL_438; /*0x141050904*/
    case NetworkValueFormat_Int:
      RBX::Network::deserializeSignedVarint(value: (int *)&networkId, stream: inBitStream); /*0x141050913*/
      v77 = out; /*0x141050918*/
      if ( valueType->localConformance != LocalConformance_NetworkIntLocalInt64 ) /*0x141050925*/
        goto LABEL_393; /*0x141050925*/
      *(_QWORD *)&value.x = (int)networkId.scope.peerId.peerId; /*0x141050932*/
      goto LABEL_108; /*0x141050932*/
    case NetworkValueFormat_Float:
      Float = RBX::Network::NetworkStream::readFloat(this: inBitStream); /*0x14105094c*/
      v79 = out->variant; /*0x141050956*/
      v79->_type = RBX::Reflection::Type::getSingleton<float>(); /*0x14105095f*/
      v80 = rbx::implementation::typed_holder<float>::singleton(); /*0x141050967*/
      v81 = v79->value.holder; /*0x14105096a*/
      if ( v81 != v80 ) /*0x141050971*/
      {
        if ( v81 != nullptr ) /*0x141050976*/
          v81->destruct(a1: v79->value.data); /*0x141050980*/
        v79->value.holder = v80; /*0x141050982*/
      }
      *(float *)v79->value.data = Float; /*0x141050986*/
      goto LABEL_438; /*0x14105098b*/
    case NetworkValueFormat_Double:
      Double = RBX::Network::NetworkStream::readDouble(this: inBitStream); /*0x141050998*/
      v83 = out->variant; /*0x1410509a2*/
      v83->_type = RBX::Reflection::Type::getSingleton<double>(); /*0x1410509ab*/
      v84 = rbx::implementation::typed_holder<double>::singleton(); /*0x1410509b3*/
      v85 = v83->value.holder; /*0x1410509b6*/
      if ( v85 != v84 ) /*0x1410509bd*/
      {
        if ( v85 != nullptr ) /*0x1410509c2*/
          v85->destruct(a1: v83->value.data); /*0x1410509cc*/
        v83->value.holder = v84; /*0x1410509ce*/
      }
      *(long double *)v83->value.data = Double; /*0x1410509d2*/
      goto LABEL_438; /*0x1410509d7*/
    case NetworkValueFormat_UDim:
      UDim = RBX::Network::NetworkStream::readUDim(this: inBitStream, result: (RBX::UDim *)&networkId); /*0x1410509eb*/
      v87 = out->variant; /*0x1410509f5*/
      v87->_type = RBX::Reflection::Type::getSingleton<RBX::UDim>(); /*0x1410509fe*/
      v88 = rbx::implementation::typed_holder<RBX::UDim>::singleton(); /*0x141050a06*/
      v89 = v87->value.holder; /*0x141050a09*/
      if ( v89 == v88 ) /*0x141050a10*/
      {
        *(float *)v87->value.data = UDim->scale; /*0x141050a14*/
        *(_DWORD *)&v87->value.data[4] = UDim->offset; /*0x141050a1a*/
      }
      else
      {
        if ( v89 != nullptr ) /*0x141050a25*/
        {
          v89->destruct(a1: v87->value.data); /*0x141050a2f*/
          v87->value.holder = nullptr; /*0x141050a33*/
        }
        *(RBX::UDim *)v87->value.data = *UDim; /*0x141050a3a*/
        v87->value.holder = v88; /*0x141050a3e*/
      }
      goto LABEL_438; /*0x141050a1d*/
    case NetworkValueFormat_UDim2:
      UDim2 = (RBX::Rect2D *)RBX::Network::NetworkStream::readUDim2(this: inBitStream, result: (RBX::UDim2 *)&uid); /*0x141050a54*/
      v91 = out->variant; /*0x141050a5e*/
      v91->_type = RBX::Reflection::Type::getSingleton<RBX::UDim2>(); /*0x141050a67*/
      v92 = rbx::implementation::typed_holder<RBX::UDim2>::singleton(); /*0x141050a6a*/
      goto LABEL_125; /*0x141050a6a*/
    case NetworkValueFormat_Ray:
      Ray = (RBX::PhysicalProperties *)RBX::Network::NetworkStream::readRay(this: inBitStream, result: (RBX::Ray *)&uid); /*0x141050ac9*/
      v96 = out->variant; /*0x141050ad3*/
      v96->_type = RBX::Reflection::Type::getSingleton<RBX::Ray>(); /*0x141050adc*/
      v97 = (const rbx::implementation::typed_holder<RBX::PhysicalProperties> *)rbx::implementation::typed_holder<RBX::Ray>::singleton(); /*0x141050adf*/
      goto LABEL_131; /*0x141050adf*/
    case NetworkValueFormat_Faces:
      Faces = (RBX::Vector2int16 *)RBX::Network::NetworkStream::readFaces( /*0x141050b44*/
                                     this: inBitStream,
                                     result: (RBX::Faces *)&networkId);
      v101 = out->variant; /*0x141050b4e*/
      v101->_type = RBX::Reflection::Type::getSingleton<RBX::Faces>(); /*0x141050b57*/
      v102 = (const rbx::implementation::typed_holder<RBX::BrickColor> *)rbx::implementation::typed_holder<RBX::Faces>::singleton(); /*0x141050b5a*/
      goto LABEL_137; /*0x141050b5a*/
    case NetworkValueFormat_Axes:
      Faces = (RBX::Vector2int16 *)RBX::Network::NetworkStream::readFaces( /*0x141050ba7*/
                                     this: inBitStream,
                                     result: (RBX::Faces *)&networkId);
      v101 = out->variant; /*0x141050bb1*/
      v101->_type = RBX::Reflection::Type::getSingleton<RBX::Axes>(); /*0x141050bba*/
      v102 = (const rbx::implementation::typed_holder<RBX::BrickColor> *)rbx::implementation::typed_holder<RBX::Axes>::singleton(); /*0x141050bbd*/
      goto LABEL_137; /*0x141050bc2*/
    case NetworkValueFormat_BrickColor:
      Faces = (RBX::Vector2int16 *)RBX::Network::NetworkStream::readBrickColor( /*0x141050bd3*/
                                     this: inBitStream,
                                     result: (RBX::BrickColor *)&networkId);
      v101 = out->variant; /*0x141050bdd*/
      v101->_type = RBX::Reflection::Type::getSingleton<RBX::BrickColor>(); /*0x141050be6*/
      v102 = rbx::implementation::typed_holder<RBX::BrickColor>::singleton(); /*0x141050be9*/
      goto LABEL_137; /*0x141050bee*/
    case NetworkValueFormat_Color3:
      Region3int16 = RBX::Network::NetworkStream::readVector3(this: inBitStream, result: &value); /*0x141050bff*/
      v106 = out->variant; /*0x141050c09*/
      v106->_type = RBX::Reflection::Type::getSingleton<RBX::Color3>(); /*0x141050c12*/
      v107 = (const rbx::implementation::typed_holder<RBX::Vector3> *)rbx::implementation::typed_holder<RBX::Color3>::singleton(); /*0x141050c1a*/
      v108 = v106->value.holder; /*0x141050c1d*/
      if ( v108 != v107 ) /*0x141050c24*/
        goto LABEL_146; /*0x141050c24*/
      *(float *)v106->value.data = Region3int16->x; /*0x141050c28*/
      *(float *)&v106->value.data[4] = Region3int16->y; /*0x141050c2e*/
      *(float *)&v106->value.data[8] = Region3int16->z; /*0x141050c34*/
      goto LABEL_438; /*0x141050c37*/
    case NetworkValueFormat_Color3uint8:
      Color3uint8 = RBX::Network::NetworkStream::readColor3uint8( /*0x141050c78*/
                      this: inBitStream,
                      result: (RBX::Color3uint8 *)&networkId);
      v110 = out->variant; /*0x141050c82*/
      v110->_type = RBX::Reflection::Type::getSingleton<RBX::Color3uint8>(); /*0x141050c8b*/
      v111 = rbx::implementation::typed_holder<RBX::Color3uint8>::singleton(); /*0x141050c93*/
      v112 = v110->value.holder; /*0x141050c96*/
      if ( v112 == v111 ) /*0x141050c9d*/
      {
        *(_WORD *)v110->value.data = *(_WORD *)&Color3uint8->r; /*0x141050ca2*/
        v110->value.data[2] = Color3uint8->b; /*0x141050caa*/
      }
      else
      {
        if ( v112 != nullptr ) /*0x141050cb5*/
        {
          v112->destruct(a1: v110->value.data); /*0x141050cbf*/
          v110->value.holder = nullptr; /*0x141050cc3*/
        }
        *(_WORD *)v110->value.data = *(_WORD *)&Color3uint8->r; /*0x141050cca*/
        v110->value.data[2] = Color3uint8->b; /*0x141050cd2*/
        v110->value.holder = v111; /*0x141050cd5*/
      }
      goto LABEL_438; /*0x141050cad*/
    case NetworkValueFormat_Vector2:
      NumberRange = RBX::Network::NetworkStream::readNumberRange(this: inBitStream, result: (RBX::Vector2 *)&networkId); /*0x141050ced*/
      v114 = out->variant; /*0x141050cf7*/
      v114->_type = RBX::Reflection::Type::getSingleton<RBX::Vector2>(); /*0x141050d00*/
      v115 = rbx::implementation::typed_holder<RBX::Vector2>::singleton(); /*0x141050d08*/
      v116 = v114->value.holder; /*0x141050d0b*/
      if ( v116 != v115 ) /*0x141050d12*/
        goto LABEL_156; /*0x141050d12*/
      *(float *)v114->value.data = NumberRange->x; /*0x141050d16*/
      *(float *)&v114->value.data[4] = NumberRange->y; /*0x141050d1c*/
      goto LABEL_438; /*0x141050d1f*/
    case NetworkValueFormat_Vector3_Fixed12Bytes:
      Region3int16 = RBX::Network::NetworkStream::readVector3(this: inBitStream, result: &value); /*0x141050d57*/
      v106 = out->variant; /*0x141050d61*/
      v106->_type = RBX::Reflection::Type::getSingleton<RBX::Vector3>(); /*0x141050d6a*/
      v107 = rbx::implementation::typed_holder<RBX::Vector3>::singleton(); /*0x141050d72*/
      v108 = v106->value.holder; /*0x141050d75*/
      if ( v108 != v107 ) /*0x141050d7c*/
        goto LABEL_146; /*0x141050d7c*/
      *(_QWORD *)v106->value.data = *(_QWORD *)&Region3int16->x; /*0x141050d86*/
      *(float *)&v106->value.data[8] = Region3int16->z; /*0x141050d8e*/
      goto LABEL_438; /*0x141050d91*/
    case NetworkValueFormat_Vector2int16:
      Faces = RBX::Network::NetworkStream::readVector2int16(this: inBitStream, result: (RBX::Vector2int16 *)&networkId); /*0x141050da5*/
      v101 = out->variant; /*0x141050daf*/
      v101->_type = RBX::Reflection::Type::getSingleton<RBX::Vector2int16>(); /*0x141050db8*/
      v102 = (const rbx::implementation::typed_holder<RBX::BrickColor> *)rbx::implementation::typed_holder<RBX::Vector2int16>::singleton(); /*0x141050dbb*/
LABEL_137:
      v103 = v102; /*0x141050b5f*/
      v104 = v101->value.holder; /*0x141050b62*/
      if ( v104 == v103 ) /*0x141050b69*/
      {
        *(RBX::Vector2int16 *)v101->value.data = *Faces; /*0x141050b6d*/
      }
      else
      {
        if ( v104 != nullptr ) /*0x141050b78*/
        {
          v104->destruct(a1: v101->value.data); /*0x141050b82*/
          v101->value.holder = nullptr; /*0x141050b86*/
        }
        *(RBX::Vector2int16 *)v101->value.data = *Faces; /*0x141050b8c*/
        v101->value.holder = v103; /*0x141050b8f*/
      }
      goto LABEL_438; /*0x141050b70*/
    case NetworkValueFormat_Vector3int16:
      Vector3int16 = RBX::Network::NetworkStream::readVector3int16( /*0x141050dd4*/
                       this: inBitStream,
                       result: (RBX::Vector3int16 *)&networkId);
      v118 = out->variant; /*0x141050dde*/
      v118->_type = RBX::Reflection::Type::getSingleton<RBX::Vector3int16>(); /*0x141050de7*/
      v119 = rbx::implementation::typed_holder<RBX::Vector3int16>::singleton(); /*0x141050def*/
      v120 = v118->value.holder; /*0x141050df2*/
      if ( v120 == v119 ) /*0x141050df9*/
      {
        *(_DWORD *)v118->value.data = *(_DWORD *)&Vector3int16->x; /*0x141050dfd*/
        *(_WORD *)&v118->value.data[4] = Vector3int16->z; /*0x141050e04*/
      }
      else
      {
        if ( v120 != nullptr ) /*0x141050e10*/
        {
          v120->destruct(a1: v118->value.data); /*0x141050e1a*/
          v118->value.holder = nullptr; /*0x141050e1e*/
        }
        *(_DWORD *)v118->value.data = *(_DWORD *)&Vector3int16->x; /*0x141050e24*/
        *(_WORD *)&v118->value.data[4] = Vector3int16->z; /*0x141050e2b*/
        v118->value.holder = v119; /*0x141050e2f*/
      }
      goto LABEL_438; /*0x141050e08*/
    case NetworkValueFormat_CoordinateFrame_ExactEncoding:
      *(_OWORD *)&cFrame.rotation.elt[0][0] = _xmm; /*0x141050e3f*/
      *(_OWORD *)&cFrame.rotation.elt[1][1] = _xmm; /*0x141050e46*/
      *(_OWORD *)&cFrame.rotation.elt[2][2] = _xmm; /*0x141050e4a*/
      RBX::Network::deserializeCoordinateFrameExact(cframe: &cFrame, bitStream: inBitStream); /*0x141050e55*/
      RBX::Network::VariantValueSetter::assignValue<RBX::CoordinateFrame>(this: out, value: &cFrame); /*0x141050e65*/
      goto LABEL_438; /*0x141050e6a*/
    case NetworkValueFormat_CoordinateFrame_GeneralEncoding:
      v121 = RBX::Network::NetworkStream::readCoordinateFrame(this: inBitStream, result: &cFrame); /*0x141050e76*/
      RBX::Network::VariantValueSetter::assignValue<RBX::CoordinateFrame>(this: out, value: v121); /*0x141050e85*/
      goto LABEL_438; /*0x141050e8a*/
    case NetworkValueFormat_InstanceGuid:
      data = *RBX::Network::IdSerializer::deserializeId(this, result: &networkId, stream: inBitStream); /*0x141050f15*/
      instance._Mypair._Myval2._Bx = 0; /*0x141050f21*/
      __wind /*0xf1c0000000000318*/
      {
        if ( RBX::GuidItem<RBX::Instance>::Registry::lookupByGuid( /*0x141050f37*/
               this: this->guidRegistry.px,
               guid: &data,
               result: (std::shared_ptr<RBX::Instance> *)&instance) )
        {
          v123 = out->variant; /*0x141050f4b*/
          v123->_type = RBX::Reflection::Type::getSingleton<std::shared_ptr<RBX::Instance>>(); /*0x141050f54*/
          if ( __TSS0__1__singleton___typed_holder_V__shared_ptr_VInstance_RBX___std___implementation_rbx__SAPEBV234_XZ_4HA > *(_DWORD *)(*((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index) + 260LL) ) /*0x141050f78*/
          {
            Init_thread_header(pOnce: &__TSS0__1__singleton___typed_holder_V__shared_ptr_VInstance_RBX___std___implementation_rbx__SAPEBV234_XZ_4HA); /*0x141052550*/
            if ( __TSS0__1__singleton___typed_holder_V__shared_ptr_VInstance_RBX___std___implementation_rbx__SAPEBV234_XZ_4HA == -1 ) /*0x14105255c*/
            {
              `rbx::implementation::typed_holder<std::shared_ptr<RBX::Instance>>::singleton'::`2'::s.construct = rbx::implementation::typed_holder<std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant>>>::construct_func; /*0x141052569*/
              `rbx::implementation::typed_holder<std::shared_ptr<RBX::Instance>>::singleton'::`2'::s.moveConstruct = rbx::implementation::typed_holder<std::shared_ptr<RBX::DataStoreSetOptions>>::moveConstruct_func; /*0x141052577*/
              `rbx::implementation::typed_holder<std::shared_ptr<RBX::Instance>>::singleton'::`2'::s.destruct = (void (__fastcall *)(char *))std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>; /*0x141052585*/
              Init_thread_footer(pOnce: &__TSS0__1__singleton___typed_holder_V__shared_ptr_VInstance_RBX___std___implementation_rbx__SAPEBV234_XZ_4HA); /*0x141052593*/
            }
          }
          v124 = v123->value.holder; /*0x141050f7e*/
          if ( v124 == &`rbx::implementation::typed_holder<std::shared_ptr<RBX::Instance>>::singleton'::`2'::s ) /*0x141050f8c*/
          {
            v125 = *(std::_Ref_count_base **)&instance._Mypair._Myval2._Bx._Alias[8]; /*0x141050f8e*/
            if ( *(_QWORD *)&instance._Mypair._Myval2._Bx._Alias[8] != 0 ) /*0x141050f96*/
            {
              _InterlockedIncrement((volatile signed __int32 *)(*(_QWORD *)&instance._Mypair._Myval2._Bx._Alias[8] + 8LL)); /*0x141050f98*/
              v125 = *(std::_Ref_count_base **)&instance._Mypair._Myval2._Bx._Alias[8]; /*0x141050f9c*/
            }
            *(_QWORD *)v123->value.data = instance._Mypair._Myval2._Bx._Ptr; /*0x141050fa6*/
            v126 = *(std::_Ref_count_base **)&v123->value.data[8]; /*0x141050faa*/
            *(_QWORD *)&v123->value.data[8] = v125; /*0x141050fae*/
            if ( v126 != nullptr ) /*0x141050fb5*/
              std::_Ref_count_base::_Decref(this: v126); /*0x141050fbb*/
          }
          else
          {
            if ( v124 != nullptr ) /*0x141050fca*/
            {
              v124->destruct(a1: v123->value.data); /*0x141050fd4*/
              v123->value.holder = nullptr; /*0x141050fd6*/
            }
            *(_QWORD *)v123->value.data = 0; /*0x141050fda*/
            *(_QWORD *)&v123->value.data[8] = 0; /*0x141050fde*/
            v125 = *(std::_Ref_count_base **)&instance._Mypair._Myval2._Bx._Alias[8]; /*0x141050fe2*/
            if ( *(_QWORD *)&instance._Mypair._Myval2._Bx._Alias[8] != 0 ) /*0x141050fea*/
            {
              _InterlockedIncrement((volatile signed __int32 *)(*(_QWORD *)&instance._Mypair._Myval2._Bx._Alias[8] + 8LL)); /*0x141050fec*/
              v125 = *(std::_Ref_count_base **)&instance._Mypair._Myval2._Bx._Alias[8]; /*0x141050ff0*/
            }
            *(_QWORD *)v123->value.data = instance._Mypair._Myval2._Bx._Ptr; /*0x141050ffa*/
            *(_QWORD *)&v123->value.data[8] = v125; /*0x141050ffe*/
            v123->value.holder = &`rbx::implementation::typed_holder<std::shared_ptr<RBX::Instance>>::singleton'::`2'::s; /*0x141051002*/
          }
        }
        else
        {
          uid = 0; /*0x14105100e*/
          __wind /*0xf1c0000000000300*/
          {
            v127 = out; /*0x141051014*/
            optionalPropertyDesc = (RBX::Reflection::RefPropDescriptor<RBX::Instance,RBX::Instance> *)out->optionalPropertyDesc; /*0x14105101b*/
            optionalInstance = out->optionalInstance; /*0x14105101f*/
            if ( optionalInstance != nullptr ) /*0x141051026*/
            {
              Rep = optionalInstance->_Wptr._Rep; /*0x141051028*/
              if ( Rep == nullptr || (Uses = Rep->_Uses) == 0 ) /*0x14105103a*/
LABEL_476:
                std::_Throw_bad_weak_ptr(); /*0x141052513*/
              while ( 1 ) /*0x141051043*/
              {
                v132 = Uses; /*0x141051043*/
                Uses = _InterlockedCompareExchange((volatile signed __int32 *)&Rep->_Uses, Uses + 1, Uses); /*0x141051043*/
                if ( v132 == Uses ) /*0x141051048*/
                  break; /*0x141051048*/
                if ( Uses == 0 ) /*0x14105104c*/
                  goto LABEL_476; /*0x14105104c*/
              }
              v133 = optionalInstance->_Wptr._Ptr; /*0x141051054*/
              v134 = optionalInstance->_Wptr._Rep; /*0x141051058*/
            }
            else
            {
              v134 = nullptr; /*0x141051060*/
              v133 = nullptr; /*0x141051062*/
            }
            optionalUnresolvedGuid = v127->optionalUnresolvedGuid; /*0x141051064*/
            if ( optionalPropertyDesc != nullptr /*0x141051081*/
              && v133 != nullptr
              && optionalPropertyDesc != &RBX::Instance::propParent
              && optionalUnresolvedGuid != nullptr )
            {
              *optionalUnresolvedGuid = data; /*0x141051086*/
            }
            if ( v134 != nullptr ) /*0x141051091*/
              std::_Ref_count_base::_Decref(this: v134); /*0x141051096*/
            v125 = *(std::_Ref_count_base **)&instance._Mypair._Myval2._Bx._Alias[8]; /*0x14105109b*/
          }
          __unwind
          {
            std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&uid); /*0xf1c0000000000310*/
          }
        }
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&instance); /*0xf1c00000000002f8*/
      }
      if ( v125 != nullptr ) /*0x1410510a3*/
        std::_Ref_count_base::_Decref(this: v125); /*0x1410510ac*/
      goto LABEL_438; /*0x1410510b1*/
    case NetworkValueFormat_Tuple:
      if ( depth != 0 ) /*0x1410510b9*/
      {
        v254 = RBX::Reflection::DescribedBase::fastDynamicCast<RBX::Network::ServerReplicator>(instance: this); /*0x1410525a0*/
        if ( v254 != nullptr ) /*0x1410525a8*/
          v254->handleSecurityViolation( /*0x1410525d2*/
            this: v254,
            a2: "codeName",
            a3: kTupleTrick,
            a4: rNormalKick,
            a5: "Tuple",
            a6: nullptr);
        RBX::throw_runtime_error(fmt: "Tuple cannot be received as a member of another container."); /*0x1410525e0*/
      }
      RBX::Network::deserializeUnsignedVarint(value: &size, stream: inBitStream); /*0x1410510c6*/
      RBX::Network::Replicator::checkVariantContainerCountLimit(count: size, type: "Tuple (read)"); /*0x1410510d5*/
      *(double *)&v136 = COERCE_DOUBLE(operator new(size: 0x18u)); /*0x1410510df*/
      networkId = (RBX::Guid)v136; /*0x1410510e4*/
      if ( *(double *)&v136 == 0.0 ) /*0x1410510f0*/
      {
        *(double *)&v136 = 0.0; /*0x1410510ff*/
      }
      else
      {
        v136->values._Mypair._Myval2._Myfirst = nullptr; /*0x1410510f2*/
        v136->values._Mypair._Myval2._Mylast = nullptr; /*0x1410510f5*/
        v136->values._Mypair._Myval2._Myend = nullptr; /*0x1410510f9*/
      }
      std::shared_ptr<RBX::Reflection::Tuple>::shared_ptr<RBX::Reflection::Tuple>( /*0x14105110a*/
        this: (std::shared_ptr<RBX::Reflection::Tuple> *)&instance,
        _Px: v136);
      __wind /*0xf1c00000000002e8*/
      {
        v137 = instance._Mypair._Myval2._Bx._Ptr; /*0x141051113*/
        std::vector<RBX::Reflection::Variant>::resize( /*0x14105111b*/
          this: (std::vector<RBX::Reflection::Variant> *)instance._Mypair._Myval2._Bx._Ptr,
          _Newsize: size);
        v138 = 0; /*0x141051120*/
        if ( size != 0 ) /*0x141051126*/
        {
          v139 = deferredSharedStrings; /*0x141051128*/
          do /*0x141051168*/
            RBX::Network::Replicator::schemaReadVariant( /*0x14105115e*/
              this,
              inBitStream,
              useDictionaries: v8,
              out: (RBX::Reflection::Variant *)(*(_QWORD *)v137 + 80LL * v138++),
              depth: 0,
              deferredSharedStrings: v139,
              replicationMetaData);
          while ( v138 < size ); /*0x141051168*/
        }
        v140 = *(std::_Ref_count_base **)&instance._Mypair._Myval2._Bx._Alias[8]; /*0x14105116a*/
        if ( *(_QWORD *)&instance._Mypair._Myval2._Bx._Alias[8] != 0 ) /*0x141051172*/
        {
          _InterlockedIncrement((volatile signed __int32 *)(*(_QWORD *)&instance._Mypair._Myval2._Bx._Alias[8] + 8LL)); /*0x141051174*/
          v140 = *(std::_Ref_count_base **)&instance._Mypair._Myval2._Bx._Alias[8]; /*0x141051178*/
          v137 = instance._Mypair._Myval2._Bx._Ptr; /*0x14105117d*/
        }
        Bx = instance._Mypair._Myval2._Bx; /*0x141051187*/
        __wind /*0xf1c00000000002dc*/
        {
          v141 = out->variant; /*0x141051196*/
          v141->_type = RBX::Reflection::Type::getSingleton<std::shared_ptr<RBX::Reflection::Tuple const>>(); /*0x14105119f*/
          v142 = rbx::implementation::typed_holder<std::shared_ptr<RBX::Reflection::Tuple const>>::singleton(); /*0x1410511a7*/
          v143 = v141->value.holder; /*0x1410511aa*/
          if ( v143 == v142 ) /*0x1410511b1*/
          {
            if ( v140 != nullptr ) /*0x1410511b6*/
            {
              _InterlockedIncrement((volatile signed __int32 *)&v140->_Uses); /*0x1410511b8*/
              v140 = *(std::_Ref_count_base **)&instance._Mypair._Myval2._Bx._Alias[8]; /*0x1410511bc*/
              v137 = instance._Mypair._Myval2._Bx._Ptr; /*0x1410511c1*/
            }
            *(_QWORD *)v141->value.data = v137; /*0x1410511c6*/
            v144 = *(std::_Ref_count_base **)&v141->value.data[8]; /*0x1410511ca*/
            *(_QWORD *)&v141->value.data[8] = v140; /*0x1410511ce*/
            if ( v144 != nullptr ) /*0x1410511d5*/
              std::_Ref_count_base::_Decref(this: v144); /*0x1410511d7*/
          }
          else
          {
            if ( v143 != nullptr ) /*0x1410511e1*/
            {
              v143->destruct(a1: v141->value.data); /*0x1410511eb*/
              v141->value.holder = nullptr; /*0x1410511ed*/
            }
            *(_QWORD *)v141->value.data = 0; /*0x1410511f1*/
            *(_QWORD *)&v141->value.data[8] = 0; /*0x1410511f5*/
            if ( v140 != nullptr ) /*0x1410511fc*/
            {
              _InterlockedIncrement((volatile signed __int32 *)&v140->_Uses); /*0x1410511fe*/
              v140 = *(std::_Ref_count_base **)&instance._Mypair._Myval2._Bx._Alias[8]; /*0x141051202*/
              v137 = instance._Mypair._Myval2._Bx._Ptr; /*0x141051207*/
            }
            *(_QWORD *)v141->value.data = v137; /*0x14105120c*/
            *(_QWORD *)&v141->value.data[8] = v140; /*0x141051210*/
            v141->value.holder = v142; /*0x141051214*/
          }
        }
        __unwind
        {
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&Bx); /*0xf1c00000000002d4*/
        }
        if ( v140 != nullptr ) /*0x14105121b*/
          std::_Ref_count_base::_Decref(this: v140); /*0x141051220*/
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&instance); /*0x14105122b*/
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&instance); /*0xf1c00000000000a8*/
      }
      goto LABEL_438; /*0xf1c00000000000a4*/
    case NetworkValueFormat_ValueArray:
      RBX::Network::deserializeUnsignedVarint(value: count, stream: inBitStream); /*0x14105123c*/
      RBX::Network::Replicator::checkVariantContainerCountLimit(count: count[0], type: "ValueArray (read)"); /*0x14105124b*/
      v145 = (std::vector<RBX::Reflection::Variant> *)operator new(size: 0x18u); /*0x141051255*/
      *(_QWORD *)&value.x = v145; /*0x14105125a*/
      __wind /*0xf1c00000000002c4*/
      {
        if ( v145 != nullptr ) /*0x141051263*/
          v146 = std::vector<RBX::Reflection::Variant>::vector<RBX::Reflection::Variant>( /*0x141051272*/
                   this: v145,
                   _Count: count[0],
                   _Al: (const std::allocator<RBX::Reflection::Variant> *)&networkId);
        else
          v146 = nullptr; /*0x141051279*/
      }
      __unwind
      {
        operator delete(ptr: *(void **)&value.x); /*0x1431e84c5*/
      }
      std::shared_ptr<std::vector<RBX::Reflection::Variant>>::shared_ptr<std::vector<RBX::Reflection::Variant>>( /*0x141051284*/
        this: (std::shared_ptr<std::vector<RBX::Reflection::Variant> > *)&instance,
        _Px: v146);
      __wind /*0xf1c00000000002ac*/
      {
        v147 = 0; /*0x14105128a*/
        v148 = instance._Mypair._Myval2._Bx._Ptr; /*0x14105128c*/
        if ( count[0] != 0 ) /*0x141051294*/
        {
          v149 = deferredSharedStrings; /*0x141051296*/
          v150 = replicationMetaData; /*0x14105129d*/
          do /*0x1410512e8*/
            RBX::Network::Replicator::schemaReadVariant( /*0x1410512de*/
              this,
              inBitStream,
              useDictionaries: v8,
              out: (RBX::Reflection::Variant *)(*(_QWORD *)v148 + 80LL * v147++),
              depth,
              deferredSharedStrings: v149,
              replicationMetaData: v150);
          while ( v147 < count[0] ); /*0x1410512e8*/
        }
        v151 = *(std::_Ref_count_base **)&instance._Mypair._Myval2._Bx._Alias[8]; /*0x1410512ec*/
        if ( *(_QWORD *)&instance._Mypair._Myval2._Bx._Alias[8] != 0 ) /*0x1410512f4*/
        {
          _InterlockedIncrement((volatile signed __int32 *)(*(_QWORD *)&instance._Mypair._Myval2._Bx._Alias[8] + 8LL)); /*0x1410512f6*/
          v151 = *(std::_Ref_count_base **)&instance._Mypair._Myval2._Bx._Alias[8]; /*0x1410512fa*/
          v148 = instance._Mypair._Myval2._Bx._Ptr; /*0x1410512ff*/
        }
        v281 = instance._Mypair._Myval2._Bx; /*0x141051309*/
        __wind /*0xf1c00000000002a0*/
        {
          v152 = out->variant; /*0x141051318*/
          v152->_type = RBX::Reflection::Type::getSingleton<std::shared_ptr<std::vector<RBX::Reflection::Variant> const>>(); /*0x141051321*/
          v153 = rbx::implementation::typed_holder<std::shared_ptr<std::vector<RBX::Reflection::Variant> const>>::singleton(); /*0x141051329*/
          v154 = v152->value.holder; /*0x14105132c*/
          if ( v154 == v153 ) /*0x141051333*/
          {
            if ( v151 != nullptr ) /*0x141051338*/
            {
              _InterlockedIncrement((volatile signed __int32 *)&v151->_Uses); /*0x14105133a*/
              v151 = *(std::_Ref_count_base **)&instance._Mypair._Myval2._Bx._Alias[8]; /*0x14105133e*/
              v148 = instance._Mypair._Myval2._Bx._Ptr; /*0x141051343*/
            }
            *(_QWORD *)v152->value.data = v148; /*0x141051348*/
            v155 = *(std::_Ref_count_base **)&v152->value.data[8]; /*0x14105134c*/
            *(_QWORD *)&v152->value.data[8] = v151; /*0x141051350*/
            if ( v155 != nullptr ) /*0x141051357*/
              std::_Ref_count_base::_Decref(this: v155); /*0x141051359*/
          }
          else
          {
            if ( v154 != nullptr ) /*0x141051363*/
            {
              v154->destruct(a1: v152->value.data); /*0x14105136d*/
              v152->value.holder = nullptr; /*0x14105136f*/
            }
            *(_QWORD *)v152->value.data = 0; /*0x141051373*/
            *(_QWORD *)&v152->value.data[8] = 0; /*0x141051377*/
            if ( v151 != nullptr ) /*0x14105137e*/
            {
              _InterlockedIncrement((volatile signed __int32 *)&v151->_Uses); /*0x141051380*/
              v151 = *(std::_Ref_count_base **)&instance._Mypair._Myval2._Bx._Alias[8]; /*0x141051384*/
              v148 = instance._Mypair._Myval2._Bx._Ptr; /*0x141051389*/
            }
            *(_QWORD *)v152->value.data = v148; /*0x14105138e*/
            *(_QWORD *)&v152->value.data[8] = v151; /*0x141051392*/
            v152->value.holder = v153; /*0x141051396*/
          }
        }
        __unwind
        {
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&v281); /*0xf1c0000000000298*/
        }
        if ( v151 != nullptr ) /*0x14105139d*/
          std::_Ref_count_base::_Decref(this: v151); /*0x1410513a2*/
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&instance); /*0x1410513ad*/
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&instance); /*0xf1c00000000000b4*/
      }
      goto LABEL_438; /*0xf1c00000000000b0*/
    case NetworkValueFormat_ValueTable:
      RBX::Network::deserializeUnsignedVarint(value: &v269, stream: inBitStream); /*0x1410513be*/
      RBX::Network::Replicator::checkVariantContainerCountLimit(count: v269, type: "ValueTable (read)"); /*0x1410513cd*/
      *(double *)&v156 = COERCE_DOUBLE(operator new(size: 0x40u)); /*0x1410513d7*/
      networkId = (RBX::Guid)v156; /*0x1410513dc*/
      __wind /*0xf1c0000000000288*/
      {
        if ( *(double *)&v156 == 0.0 ) /*0x1410513e8*/
          v157 = nullptr; /*0x1410513f4*/
        else
          v157 = std::unordered_map<std::string,RBX::Reflection::Variant>::unordered_map<std::string,RBX::Reflection::Variant>(this: v156); /*0x1410513ed*/
      }
      __unwind
      {
        operator delete(ptr: *(void **)&networkId); /*0x1431e84e5*/
      }
      std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant>>::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant>>( /*0x1410513fe*/
        this: &v274,
        _Px: v157);
      __wind /*0xf1c0000000000264*/
      {
        keyBuffer._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141051404*/
        keyBuffer._Mypair._Myval2._Mysize = 0; /*0x141051408*/
        keyBuffer._Mypair._Myval2._Myres = 15; /*0x14105140c*/
        v158 = 0; /*0x141051418*/
        if ( v269 != 0 ) /*0x14105141d*/
        {
          v159 = deferredSharedStrings; /*0x14105141f*/
          v160 = depth; /*0x141051426*/
          __eh34_enter_wind_state(14, 15); /*0xf1c000000000025c*/
          do /*0x141051483*/
          {
            v161 = RBX::Network::Replicator::getReadPayloadLimit(this); /*0x141051433*/
            RBX::Network::deserializeString(value: &keyBuffer, stream: inBitStream, maxStringReadSize: v161); /*0x141051442*/
            v162 = std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,0>>::_Try_emplace<std::string const &,>( /*0x141051454*/
                     this: v274._Ptr,
                     result: (std::pair<std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *,bool> *)&uid,
                     _Keyval_arg: &keyBuffer);
            RBX::Network::Replicator::schemaReadVariant( /*0x141051479*/
              this,
              inBitStream,
              useDictionaries: v8,
              out: &v162->first->_Myval.second,
              depth: v160,
              deferredSharedStrings: v159,
              replicationMetaData: v14);
            ++v158; /*0x14105147e*/
          }
          while ( v158 < v269 ); /*0x141051483*/
        }
        else
        {
          __eh34_enter_wind_state(14, 15); /*0xf1c0000000000254*/
        }
        if ( DFFlag::ReplicatorCheckReadTableCollisions.value ) /*0x14105148e*/
          this->analyzeEventVariantArgs(this, a2: &v274); /*0x14105149a*/
        if ( v274._Rep != nullptr ) /*0x1410514a7*/
          _InterlockedIncrement((volatile signed __int32 *)&v274._Rep->_Uses); /*0x1410514a9*/
        *(std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> > *)v273 = v274; /*0x1410514b1*/
        __wind /*0xf1c0000000000248*/
        {
          v163 = out->variant; /*0x1410514bd*/
          v163->_type = RBX::Reflection::Type::getSingleton<std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const>>(); /*0x1410514c6*/
          v164 = rbx::implementation::typed_holder<std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const>>::singleton(); /*0x1410514ce*/
          v165 = v163->value.holder; /*0x1410514d1*/
          if ( v165 == v164 ) /*0x1410514d8*/
          {
            v166 = v273[1]; /*0x1410514da*/
            if ( v273[1] != nullptr ) /*0x1410514e1*/
            {
              _InterlockedIncrement((volatile signed __int32 *)&v273[1]->_Uses); /*0x1410514e3*/
              v166 = v273[1]; /*0x1410514e7*/
            }
            *(std::_Ref_count_base **)v163->value.data = v273[0]; /*0x1410514ef*/
            v167 = *(std::_Ref_count_base **)&v163->value.data[8]; /*0x1410514f3*/
            *(_QWORD *)&v163->value.data[8] = v166; /*0x1410514f7*/
            if ( v167 != nullptr ) /*0x1410514fe*/
              std::_Ref_count_base::_Decref(this: v167); /*0x141051500*/
          }
          else
          {
            if ( v165 != nullptr ) /*0x14105150a*/
            {
              v165->destruct(a1: v163->value.data); /*0x141051514*/
              v163->value.holder = nullptr; /*0x141051516*/
            }
            *(_QWORD *)v163->value.data = 0; /*0x14105151a*/
            *(_QWORD *)&v163->value.data[8] = 0; /*0x14105151e*/
            v166 = v273[1]; /*0x141051522*/
            if ( v273[1] != nullptr ) /*0x141051529*/
            {
              _InterlockedIncrement((volatile signed __int32 *)&v273[1]->_Uses); /*0x14105152b*/
              v166 = v273[1]; /*0x14105152f*/
            }
            *(std::_Ref_count_base **)v163->value.data = v273[0]; /*0x141051537*/
            *(_QWORD *)&v163->value.data[8] = v166; /*0x14105153b*/
            v163->value.holder = v164; /*0x14105153f*/
          }
        }
        __unwind
        {
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)v273); /*0xf1c0000000000240*/
        }
        if ( v166 != nullptr ) /*0x141051546*/
          std::_Ref_count_base::_Decref(this: v166); /*0x14105154b*/
        if ( keyBuffer._Mypair._Myval2._Myres >= 0x10 ) /*0x141051559*/
        {
          v168 = keyBuffer._Mypair._Myval2._Bx._Ptr; /*0x14105155e*/
          if ( keyBuffer._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14105156c*/
          {
            v168 = *((char **)keyBuffer._Mypair._Myval2._Bx._Ptr - 1); /*0x141051572*/
            if ( (unsigned __int64)(keyBuffer._Mypair._Myval2._Bx._Ptr - v168 - 8) > 0x1F ) /*0x141051581*/
              _invalid_parameter_noinfo_noreturn(); /*0x141051583*/
          }
          operator delete(ptr: v168); /*0x14105158a*/
        }
        keyBuffer._Mypair._Myval2._Mysize = 0; /*0x14105158f*/
        keyBuffer._Mypair._Myval2._Myres = 15; /*0x141051593*/
        keyBuffer._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14105159b*/
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&v274); /*0x1410515a3*/
        if ( __eh34_unwind(15) ) /*0xf1c00000000003fc*/
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&keyBuffer); /*0xf1c0000000000400*/
          __eh34_continue_unwinding(15, 14); /*0xf1c0000000000404*/
        }
        __eh34_exit_wind_state(15, 14); /*0xf1c0000000000408*/
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&v274); /*0xf1c0000000000274*/
      }
      goto LABEL_438; /*0xf1c0000000000270*/
    case NetworkValueFormat_ValueMap:
      RBX::Network::deserializeUnsignedVarint(value: &v270, stream: inBitStream); /*0x1410515b4*/
      RBX::Network::Replicator::checkVariantContainerCountLimit(count: v270, type: "ValueMap (read)"); /*0x1410515c3*/
      *(double *)&v169 = COERCE_DOUBLE(operator new(size: 0x10u)); /*0x1410515cd*/
      networkId = (RBX::Guid)v169; /*0x1410515d2*/
      __wind /*0xf1c0000000000230*/
      {
        if ( *(double *)&v169 == 0.0 ) /*0x1410515de*/
          v170 = nullptr; /*0x1410515ea*/
        else
          v170 = (std::map<std::string,RBX::Reflection::Variant> *)std::map<std::string,RBX::Reflection::Variant>::map<std::string,RBX::Reflection::Variant>(this: v169); /*0x1410515e3*/
      }
      __unwind
      {
        operator delete(ptr: *(void **)&networkId); /*0x1431e8505*/
      }
      std::shared_ptr<std::map<std::string,RBX::Reflection::Variant>>::shared_ptr<std::map<std::string,RBX::Reflection::Variant>>( /*0x1410515f5*/
        this: (std::shared_ptr<std::map<std::string,RBX::Reflection::Variant> > *)&instance,
        _Px: v170);
      __wind /*0xf1c000000000020c*/
      {
        _Keyval._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410515fb*/
        _Keyval._Mypair._Myval2._Mysize = 0; /*0x1410515ff*/
        _Keyval._Mypair._Myval2._Myres = 15; /*0x141051603*/
        v171 = 0; /*0x14105160f*/
        v172 = instance._Mypair._Myval2._Bx._Ptr; /*0x141051611*/
        if ( v270 != 0 ) /*0x141051619*/
        {
          v173 = deferredSharedStrings; /*0x14105161b*/
          v174 = replicationMetaData; /*0x141051622*/
          __eh34_enter_wind_state(18, 19); /*0xf1c0000000000204*/
          do /*0x141051689*/
          {
            v175 = RBX::Network::Replicator::getReadPayloadLimit(this); /*0x141051633*/
            RBX::Network::deserializeString(value: &_Keyval, stream: inBitStream, maxStringReadSize: v175); /*0x141051642*/
            v176 = std::map<std::string,RBX::Reflection::Variant>::_Try_emplace<std::string const &,>( /*0x141051653*/
                     this: (std::map<std::string,RBX::Reflection::Variant> *)v172,
                     result: (std::pair<std::_Tree_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *,bool> *)&uid,
                     &_Keyval);
            RBX::Network::Replicator::schemaReadVariant( /*0x14105167f*/
              this,
              inBitStream,
              useDictionaries: v8,
              out: &v176->first->_Myval.second,
              depth,
              deferredSharedStrings: v173,
              replicationMetaData: v174);
            ++v171; /*0x141051684*/
          }
          while ( v171 < v270 ); /*0x141051689*/
        }
        else
        {
          __eh34_enter_wind_state(18, 19); /*0xf1c00000000001fc*/
        }
        v177 = *(std::_Ref_count_base **)&instance._Mypair._Myval2._Bx._Alias[8]; /*0x14105168d*/
        if ( *(_QWORD *)&instance._Mypair._Myval2._Bx._Alias[8] != 0 ) /*0x141051695*/
        {
          _InterlockedIncrement((volatile signed __int32 *)(*(_QWORD *)&instance._Mypair._Myval2._Bx._Alias[8] + 8LL)); /*0x141051697*/
          v177 = *(std::_Ref_count_base **)&instance._Mypair._Myval2._Bx._Alias[8]; /*0x14105169b*/
          v172 = instance._Mypair._Myval2._Bx._Ptr; /*0x1410516a0*/
        }
        v282 = instance._Mypair._Myval2._Bx; /*0x1410516aa*/
        __wind /*0xf1c00000000001f0*/
        {
          v178 = out->variant; /*0x1410516b9*/
          v178->_type = RBX::Reflection::Type::getSingleton<std::shared_ptr<std::map<std::string,RBX::Reflection::Variant> const>>(); /*0x1410516c2*/
          v179 = rbx::implementation::typed_holder<std::shared_ptr<std::map<std::string,RBX::Reflection::Variant> const>>::singleton(); /*0x1410516ca*/
          v180 = v178->value.holder; /*0x1410516cd*/
          if ( v180 == v179 ) /*0x1410516d4*/
          {
            if ( v177 != nullptr ) /*0x1410516d9*/
            {
              _InterlockedIncrement((volatile signed __int32 *)&v177->_Uses); /*0x1410516db*/
              v177 = *(std::_Ref_count_base **)&instance._Mypair._Myval2._Bx._Alias[8]; /*0x1410516df*/
              v172 = instance._Mypair._Myval2._Bx._Ptr; /*0x1410516e4*/
            }
            *(_QWORD *)v178->value.data = v172; /*0x1410516e9*/
            v181 = *(std::_Ref_count_base **)&v178->value.data[8]; /*0x1410516ed*/
            *(_QWORD *)&v178->value.data[8] = v177; /*0x1410516f1*/
            if ( v181 != nullptr ) /*0x1410516f8*/
              std::_Ref_count_base::_Decref(this: v181); /*0x1410516fa*/
          }
          else
          {
            if ( v180 != nullptr ) /*0x141051704*/
            {
              v180->destruct(a1: v178->value.data); /*0x14105170e*/
              v178->value.holder = nullptr; /*0x141051710*/
            }
            *(_QWORD *)v178->value.data = 0; /*0x141051714*/
            *(_QWORD *)&v178->value.data[8] = 0; /*0x141051718*/
            if ( v177 != nullptr ) /*0x14105171f*/
            {
              _InterlockedIncrement((volatile signed __int32 *)&v177->_Uses); /*0x141051721*/
              v177 = *(std::_Ref_count_base **)&instance._Mypair._Myval2._Bx._Alias[8]; /*0x141051725*/
              v172 = instance._Mypair._Myval2._Bx._Ptr; /*0x14105172a*/
            }
            *(_QWORD *)v178->value.data = v172; /*0x14105172f*/
            *(_QWORD *)&v178->value.data[8] = v177; /*0x141051733*/
            v178->value.holder = v179; /*0x141051737*/
          }
        }
        __unwind
        {
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&v282); /*0xf1c00000000001e8*/
        }
        if ( v177 != nullptr ) /*0x14105173e*/
          std::_Ref_count_base::_Decref(this: v177); /*0x141051743*/
        if ( _Keyval._Mypair._Myval2._Myres >= 0x10 ) /*0x141051751*/
        {
          v182 = _Keyval._Mypair._Myval2._Bx._Ptr; /*0x141051756*/
          if ( _Keyval._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141051764*/
          {
            v182 = *((char **)_Keyval._Mypair._Myval2._Bx._Ptr - 1); /*0x14105176a*/
            if ( (unsigned __int64)(_Keyval._Mypair._Myval2._Bx._Ptr - v182 - 8) > 0x1F ) /*0x141051779*/
              _invalid_parameter_noinfo_noreturn(); /*0x14105177b*/
          }
          operator delete(ptr: v182); /*0x141051782*/
        }
        _Keyval._Mypair._Myval2._Mysize = 0; /*0x141051787*/
        _Keyval._Mypair._Myval2._Myres = 15; /*0x14105178b*/
        _Keyval._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141051793*/
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&instance); /*0x14105179c*/
        if ( __eh34_unwind(19) ) /*0xf1c0000000000410*/
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&_Keyval); /*0xf1c0000000000414*/
          __eh34_continue_unwinding(19, 18); /*0xf1c0000000000418*/
        }
        __eh34_exit_wind_state(19, 18); /*0xf1c000000000041c*/
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&instance); /*0xf1c000000000021c*/
      }
      goto LABEL_438; /*0xf1c0000000000218*/
    case NetworkValueFormat_ContentId:
      __eh34_enter_wind_state(-1, 0); /*0xf1c00000000001dc*/
      *(_QWORD *)&uid.sessionId.bits_hi = 0; /*0x1410517a8*/
      Size = 0; /*0x1410517ad*/
      v264 = 15; /*0x1410517b2*/
      if ( v8 ) /*0x1410517c6*/
      {
        RBX::Network::Replicator::readPrefixedContentId(this, inByteStream: inBitStream, contentId: (std::string *)&uid); /*0x1410517d0*/
      }
      else
      {
        v183 = RBX::Network::Replicator::getReadPayloadLimit(this); /*0x1410517d7*/
        RBX::Network::deserializeString(value: (std::string *)&uid, stream: inBitStream, maxStringReadSize: v183); /*0x1410517e7*/
      }
      if ( DFFlag::NetworkReportContentIdLimit.value /*0x14105182d*/
        && this->isServerReplicator(this)
        && !this->isCloudEdit(this)
        && Size > DFInt::NetworkReportContentIdLimitRead )
      {
        RBX::Time::nowFast(result: (RBX::Time *)&networkId); /*0x14105183a*/
        sec = this->lastContentIdLimitReport.sec; /*0x14105183f*/
        if ( sec == 0.0 || *(double *)&networkId - sec >= (double)DFInt::NetworkReportContentIdLimitIntervalSeconds ) /*0x14105186f*/
        {
          RBX::Analytics::InfluxDb::Points::Points( /*0x141051883*/
            this: &points,
            throttleHundredthsPercentage: -1,
            categoryType: kStandardType,
            priorityHundredthsPercentage: 0);
          __wind /*0xf1c00000000001d0*/
          {
            RBX::Analytics::InfluxDb::Points::addPoint(this: &points, name: "Size", value: Size); /*0x141051899*/
            v185 = DFInt::NetworkReportContentIdLimitMax; /*0x14105189e*/
            instance._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410518a5*/
            instance._Mypair._Myval2._Mysize = 0; /*0x1410518aa*/
            instance._Mypair._Myval2._Myres = 15; /*0x1410518af*/
            if ( Size < DFInt::NetworkReportContentIdLimitMax ) /*0x1410518c2*/
              v185 = Size; /*0x1410518c2*/
            v186 = &uid; /*0x1410518c8*/
            if ( v264 >= 0x10 ) /*0x1410518d3*/
              v186 = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x1410518d3*/
            std::string::assign(this: &instance, _Ptr: (const char *const)v186, _Count: v185); /*0x1410518de*/
            __eh34_enter_wind_state(21, 22); /*0xf1c00000000001c8*/
            RBX::Analytics::InfluxDb::Points::addPoint(this: &points, name: "ContentId", value: &instance); /*0x1410518f4*/
            if ( __eh34_unwind(22) ) /*0xf1c00000000001bc*/
            {
unwind_state_22:
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&instance); /*0xf1c00000000001a4*/
              __eh34_continue_unwinding(22, 21); /*0xf1c00000000001a8*/
            }
            __eh34_exit_wind_state(22, 21); /*0xf1c00000000001c0*/
            if ( instance._Mypair._Myval2._Myres >= 0x10 ) /*0x141051903*/
            {
              v187 = instance._Mypair._Myval2._Bx._Ptr; /*0x141051908*/
              if ( instance._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141051917*/
              {
                v187 = *((char **)instance._Mypair._Myval2._Bx._Ptr - 1); /*0x14105191d*/
                if ( (unsigned __int64)(instance._Mypair._Myval2._Bx._Ptr - v187 - 8) > 0x1F ) /*0x14105192c*/
                  _invalid_parameter_noinfo_noreturn(); /*0x14105192e*/
              }
              operator delete(ptr: v187); /*0x141051935*/
            }
            v188 = DFInt::NetworkReportContentIdLimitPerMyriad; /*0x14105193a*/
            instance._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141051940*/
            instance._Mypair._Myval2._Mysize = 0; /*0x141051945*/
            instance._Mypair._Myval2._Myres = 15; /*0x14105194a*/
            std::string::assign(this: &instance, _Ptr: "NetworkStreamContentIdLimit", _Count: 0x1Bu); /*0x14105196a*/
            __eh34_enter_wind_state(21, 22); /*0xf1c00000000001b4*/
            RBX::Analytics::InfluxDb::Points::report( /*0x14105197f*/
              this: &points,
              resource: &instance,
              throttleHundredthsPercentage: v188,
              blocking: false);
            if ( __eh34_unwind(22) ) /*0xf1c00000000001a0*/
              goto unwind_state_22; /*0xf1c00000000001a0*/
            __eh34_exit_wind_state(22, 21); /*0xf1c00000000001ac*/
            if ( instance._Mypair._Myval2._Myres >= 0x10 ) /*0x14105198e*/
            {
              v189 = instance._Mypair._Myval2._Bx._Ptr; /*0x141051993*/
              if ( instance._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410519a2*/
              {
                v189 = *((char **)instance._Mypair._Myval2._Bx._Ptr - 1); /*0x1410519a8*/
                if ( (unsigned __int64)(instance._Mypair._Myval2._Bx._Ptr - v189 - 8) > 0x1F ) /*0x1410519b7*/
                  _invalid_parameter_noinfo_noreturn(); /*0x1410519b9*/
              }
              operator delete(ptr: v189); /*0x1410519c0*/
            }
            this->lastContentIdLimitReport.sec = *(double *)&networkId; /*0x1410519cd*/
            RBX::Analytics::InfluxDb::Points::~Points(this: &points); /*0x1410519da*/
          }
          __unwind
          {
            RBX::Analytics::InfluxDb::Points::~Points(this: &points); /*0xf1c0000000000198*/
          }
        }
      }
      if ( DFFlag::EnableContentIdLengthCheck.value
        && this->isServerReplicator(this)
        && !this->isCloudEdit(this)
        && DFInt::ContentIdMaxLength > 0
        && Size > DFInt::ContentIdMaxLength )
      {
        v255 = boost::multi_index::detail::auto_space<unsigned __int64,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>>>::data(this: (ShareModalController *)&uid); /*0x1410525eb*/
        v256 = RBX::format(result: (std::string *)&v272, fmt: "ContentId read: String too long: %zu", (size_t)v255);
        __eh34_enter_wind_state(0, 23); /*0xf1c0000000000044*/
        RBX::network_stream_exception::network_stream_exception(this: (RBX::network_stream_exception *)&cFrame, m: v256); /*0x14105260b*/
        throw (RBX::network_stream_exception *)&cFrame; /*0x14105261b*/
      }
      std::string::string( /*0x141051a28*/
        this: (rtc::webrtc_checks_impl::ToStringVal *)&instance,
        __that: (const rtc::webrtc_checks_impl::ToStringVal *)&uid);
      RBX::ContentId::CorrectBackslash(id: &instance); /*0x141051a32*/
      __wind /*0xf1c000000000017c*/
      {
        v190 = out->variant; /*0x141051a3f*/
        v190->_type = RBX::Reflection::Type::getSingleton<RBX::ContentId>(); /*0x141051a48*/
        v191 = rbx::implementation::typed_holder<RBX::ContentId>::singleton(); /*0x141051a50*/
        v192 = v190->value.holder; /*0x141051a53*/
        if ( v192 == v191 ) /*0x141051a5a*/
        {
          std::string::operator=(this: (std::string *)v190->value.data, _Right: &instance); /*0x141051a65*/
        }
        else
        {
          if ( v192 != nullptr ) /*0x141051a6f*/
            v192->destruct(a1: v190->value.data); /*0x141051a79*/
          *(std::string *)v190->value.data = instance; /*0x141051a80*/
          *(__m128i *)&instance._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x141051a95*/
          instance._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141051a9b*/
          v190->value.holder = v191; /*0x141051aa0*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&instance); /*0xf1c0000000000174*/
      }
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&instance); /*0x141051aa9*/
      if ( v264 < 0x10 ) /*0x141051ab8*/
        goto LABEL_494; /*0x141051ab8*/
      v40 = *(void **)&uid.sessionId.bits_hi; /*0x141051ac1*/
      if ( v264 + 1 >= 0x1000 ) /*0x141051ad0*/
      {
        v40 = *(void **)(*(_QWORD *)&uid.sessionId.bits_hi - 8LL); /*0x141051ada*/
        if ( (unsigned __int64)(*(_QWORD *)&uid.sessionId.bits_hi - (_QWORD)v40 - 8LL) > 0x1F ) /*0x141051ae9*/
          _invalid_parameter_noinfo_noreturn(); /*0x141051aef*/
      }
      goto LABEL_43; /*0x141051ae9*/
    case NetworkValueFormat_SystemAddress:
      RBX::Network::deserializeUnsignedVarint(value: (unsigned int *)&networkId, stream: inBitStream); /*0x141051b00*/
      peerId = networkId.scope.peerId.peerId; /*0x141051b05*/
      v194 = out->variant; /*0x141051b12*/
      v194->_type = RBX::Reflection::Type::getSingleton<RBX::SystemAddress>(); /*0x141051b1b*/
      v195 = rbx::implementation::typed_holder<RBX::SystemAddress>::singleton(); /*0x141051b23*/
      v196 = v194->value.holder; /*0x141051b26*/
      if ( v196 == v195 ) /*0x141051b2d*/
      {
        *(_DWORD *)v194->value.data = peerId; /*0x141051b2f*/
      }
      else
      {
        if ( v196 != nullptr ) /*0x141051b3a*/
          v196->destruct(a1: v194->value.data); /*0x141051b44*/
        *(_DWORD *)v194->value.data = peerId; /*0x141051b46*/
        v194->value.holder = v195; /*0x141051b49*/
      }
      goto LABEL_438; /*0x141051b32*/
    case NetworkValueFormat_NumberSequence:
      NumberSequence = (const std::vector<RBX::FileMeshFace> *)RBX::Network::NetworkStream::readNumberSequence( /*0x141051b5f*/
                                                                 this: inBitStream,
                                                                 result: (RBX::NumberSequence *)&uid);
      __wind /*0xf1c0000000000164*/
      {
        v198 = out->variant; /*0x141051b69*/
        v198->_type = RBX::Reflection::Type::getSingleton<RBX::NumberSequence>(); /*0x141051b72*/
        v199 = rbx::implementation::typed_holder<RBX::NumberSequence>::singleton(); /*0x141051b7a*/
        v200 = v198->value.holder; /*0x141051b7d*/
        if ( v200 == v199 ) /*0x141051b84*/
        {
          std::vector<RBX::FileMeshFace>::operator=( /*0x141051b8d*/
            this: (std::vector<RBX::FileMeshFace> *)v198->value.data,
            _Right: NumberSequence);
        }
        else
        {
          if ( v200 != nullptr ) /*0x141051b97*/
          {
            v200->destruct(a1: v198->value.data); /*0x141051ba1*/
            v198->value.holder = nullptr; /*0x141051ba5*/
          }
          RBX::NumberSequence::NumberSequence( /*0x141051bc0*/
            this: (RBX::NumberSequence *)v198->value.data,
            r: (const RBX::NumberSequence *)NumberSequence,
            min: -9.9999998e21,
            max: 9.9999998e21);
          v198->value.holder = v199; /*0x141051bc5*/
        }
      }
      __unwind
      {
        std::vector<RBX::HeightmapImporter::VoxelImportInfo>::_Tidy(this: (std::vector<VkVertexInputBindingDescription> *)&uid); /*0xf1c000000000015c*/
      }
      std::vector<RBX::HeightmapImporter::VoxelImportInfo>::_Tidy(this: (std::vector<VkVertexInputBindingDescription> *)&uid); /*0x141051bce*/
      goto LABEL_438; /*0x141051bd3*/
    case NetworkValueFormat_NumberSequenceKeypoint:
      Region3int16 = RBX::Network::NetworkStream::readVector3(this: inBitStream, result: &value); /*0x141051cb6*/
      v106 = out->variant; /*0x141051cc0*/
      v106->_type = RBX::Reflection::Type::getSingleton<RBX::NumberSequenceKeypoint>(); /*0x141051cc9*/
      v107 = (const rbx::implementation::typed_holder<RBX::Vector3> *)rbx::implementation::typed_holder<RBX::NumberSequenceKeypoint>::singleton(); /*0x141051cd1*/
      v108 = v106->value.holder; /*0x141051cd4*/
      if ( v108 != v107 ) /*0x141051cdb*/
        goto LABEL_146; /*0x141051cdb*/
      *(_QWORD *)v106->value.data = *(_QWORD *)&Region3int16->x; /*0x141051ce5*/
      *(float *)&v106->value.data[8] = Region3int16->z; /*0x141051ced*/
      goto LABEL_438; /*0x141051cf0*/
    case NetworkValueFormat_NumberRange:
      NumberRange = RBX::Network::NetworkStream::readNumberRange(this: inBitStream, result: (RBX::Vector2 *)&networkId); /*0x141051be7*/
      v114 = out->variant; /*0x141051bf1*/
      v114->_type = RBX::Reflection::Type::getSingleton<RBX::NumberRange>(); /*0x141051bfa*/
      v115 = (const rbx::implementation::typed_holder<RBX::Vector2> *)rbx::implementation::typed_holder<RBX::NumberRange>::singleton(); /*0x141051c02*/
      v116 = v114->value.holder; /*0x141051c05*/
      if ( v116 == v115 ) /*0x141051c0c*/
      {
        *(RBX::Vector2 *)v114->value.data = *NumberRange; /*0x141051c16*/
      }
      else
      {
LABEL_156:
        if ( v116 != nullptr ) /*0x141050d27*/
        {
          v116->destruct(a1: v114->value.data); /*0x141050d31*/
          v114->value.holder = nullptr; /*0x141050d35*/
        }
        *(RBX::Vector2 *)v114->value.data = *NumberRange; /*0x141050d3d*/
        v114->value.holder = v115; /*0x141050d42*/
      }
      goto LABEL_438; /*0x141051c1b*/
    case NetworkValueFormat_ColorSequence:
      ColorSequence = RBX::Network::NetworkStream::readColorSequence( /*0x141051c2d*/
                        this: inBitStream,
                        result: (RBX::ColorSequence *)&uid);
      __wind /*0xf1c000000000014c*/
      {
        v202 = out->variant; /*0x141051c37*/
        v202->_type = RBX::Reflection::Type::getSingleton<RBX::ColorSequence>(); /*0x141051c40*/
        v203 = rbx::implementation::typed_holder<RBX::ColorSequence>::singleton(); /*0x141051c48*/
        v204 = v202->value.holder; /*0x141051c4b*/
        if ( v204 == v203 ) /*0x141051c56*/
        {
          if ( v202->value.data != (char *)ColorSequence ) /*0x141051c5b*/
            std::vector<RBX::ColorSequenceKeypoint>::_Assign_range<RBX::ColorSequenceKeypoint *>( /*0x141051c71*/
              this: (std::vector<RBX::ColorSequenceKeypoint> *)v202->value.data,
              _First: ColorSequence->m_data._Mypair._Myval2._Myfirst,
              _Last: ColorSequence->m_data._Mypair._Myval2._Mylast,
              __formal: (std::forward_iterator_tag)networkId.scope.peerId.peerId);
        }
        else
        {
          if ( v204 != nullptr ) /*0x141051c7b*/
          {
            v204->destruct(a1: v202->value.data); /*0x141051c84*/
            v202->value.holder = nullptr; /*0x141051c88*/
          }
          RBX::ColorSequence::ColorSequence(this: (RBX::ColorSequence *)v202->value.data, r: ColorSequence); /*0x141051c92*/
          v202->value.holder = v203; /*0x141051c97*/
        }
      }
      __unwind
      {
        std::vector<GradientPoint>::_Tidy(this: (std::vector<webrtc::RtpPacketizerAv1::Packet> *)&uid); /*0xf1c0000000000144*/
      }
      std::vector<GradientPoint>::_Tidy(this: (std::vector<webrtc::RtpPacketizerAv1::Packet> *)&uid); /*0x141051ca0*/
      goto LABEL_438; /*0x141051ca5*/
    case NetworkValueFormat_ColorSequenceKeypoint:
      ColorSequenceKeypoint = RBX::Network::NetworkStream::readColorSequenceKeypoint( /*0x141051d02*/
                                this: inBitStream,
                                result: (RBX::ColorSequenceKeypoint *)&uid);
      v206 = out->variant; /*0x141051d0c*/
      v206->_type = RBX::Reflection::Type::getSingleton<RBX::ColorSequenceKeypoint>(); /*0x141051d15*/
      v207 = rbx::implementation::typed_holder<RBX::ColorSequenceKeypoint>::singleton(); /*0x141051d1d*/
      v208 = v206->value.holder; /*0x141051d20*/
      if ( v208 == v207 ) /*0x141051d27*/
      {
        *(float *)v206->value.data = ColorSequenceKeypoint->time; /*0x141051d2b*/
        *(float *)&v206->value.data[4] = ColorSequenceKeypoint->value.r; /*0x141051d31*/
        *(float *)&v206->value.data[8] = ColorSequenceKeypoint->value.g; /*0x141051d37*/
        *(float *)&v206->value.data[12] = ColorSequenceKeypoint->value.b; /*0x141051d3d*/
        *(float *)&v206->value.data[16] = ColorSequenceKeypoint->envelope; /*0x141051d43*/
      }
      else
      {
        if ( v208 != nullptr ) /*0x141051d4e*/
        {
          v208->destruct(a1: v206->value.data); /*0x141051d58*/
          v206->value.holder = nullptr; /*0x141051d5c*/
        }
        *(_OWORD *)v206->value.data = *(_OWORD *)&ColorSequenceKeypoint->time; /*0x141051d63*/
        *(float *)&v206->value.data[16] = ColorSequenceKeypoint->envelope; /*0x141051d6a*/
        v206->value.holder = v207; /*0x141051d6d*/
      }
      goto LABEL_438; /*0x141051d46*/
    case NetworkValueFormat_Rect2d:
      UDim2 = RBX::Network::NetworkStream::readRect2D(this: inBitStream, result: (RBX::Rect2D *)&uid); /*0x141051d83*/
      v91 = out->variant; /*0x141051d8d*/
      v91->_type = RBX::Reflection::Type::getSingleton<RBX::Rect2D>(); /*0x141051d96*/
      v92 = (const rbx::implementation::typed_holder<RBX::UDim2> *)rbx::implementation::typed_holder<RBX::Rect2D>::singleton(); /*0x141051d99*/
LABEL_125:
      v93 = v92; /*0x141050a6f*/
      v94 = v91->value.holder; /*0x141050a72*/
      if ( v94 == v93 ) /*0x141050a79*/
      {
        *(float *)v91->value.data = UDim2->min.x; /*0x141050a7d*/
        *(float *)&v91->value.data[4] = UDim2->min.y; /*0x141050a83*/
        *(float *)&v91->value.data[8] = UDim2->max.x; /*0x141050a89*/
        *(float *)&v91->value.data[12] = UDim2->max.y; /*0x141050a8f*/
      }
      else
      {
        if ( v94 != nullptr ) /*0x141050a9a*/
        {
          v94->destruct(a1: v91->value.data); /*0x141050aa4*/
          v91->value.holder = nullptr; /*0x141050aa8*/
        }
        *(RBX::Rect2D *)v91->value.data = *UDim2; /*0x141050aaf*/
        v91->value.holder = v93; /*0x141050ab3*/
      }
      goto LABEL_438; /*0x141050a92*/
    case NetworkValueFormat_PhysicalProperties:
      Ray = RBX::Network::NetworkStream::readPhysicalProperties( /*0x141051db0*/
              this: inBitStream,
              result: (RBX::PhysicalProperties *)&uid);
      v96 = out->variant; /*0x141051dba*/
      v96->_type = RBX::Reflection::Type::getSingleton<RBX::PhysicalProperties>(); /*0x141051dc3*/
      v97 = rbx::implementation::typed_holder<RBX::PhysicalProperties>::singleton(); /*0x141051dc6*/
LABEL_131:
      v98 = v97; /*0x141050ae4*/
      v99 = v96->value.holder; /*0x141050ae7*/
      if ( v99 == v98 ) /*0x141050aee*/
      {
        *(_OWORD *)v96->value.data = *(_OWORD *)&Ray->customEnabled; /*0x141050af3*/
        *(_QWORD *)&v96->value.data[16] = *(_QWORD *)&Ray->frictionWeight; /*0x141050afc*/
      }
      else
      {
        if ( v99 != nullptr ) /*0x141050b09*/
        {
          v99->destruct(a1: v96->value.data); /*0x141050b13*/
          v96->value.holder = nullptr; /*0x141050b17*/
        }
        *(_OWORD *)v96->value.data = *(_OWORD *)&Ray->customEnabled; /*0x141050b1e*/
        *(_QWORD *)&v96->value.data[16] = *(_QWORD *)&Ray->frictionWeight; /*0x141050b27*/
        v96->value.holder = v98; /*0x141050b2c*/
      }
      goto LABEL_438; /*0x141050b01*/
    case NetworkValueFormat_Region3:
      Region3 = RBX::Network::NetworkStream::readRegion3(this: inBitStream, result: (RBX::Region3 *)&points); /*0x141051ddc*/
      v210 = out->variant; /*0x141051de6*/
      v210->_type = RBX::Reflection::Type::getSingleton<RBX::Region3>(); /*0x141051def*/
      v211 = rbx::implementation::typed_holder<RBX::Region3>::singleton(); /*0x141051df7*/
      v212 = v210->value.holder; /*0x141051dfa*/
      if ( v212 == v211 ) /*0x141051e01*/
      {
        *(_OWORD *)v210->value.data = *(_OWORD *)&Region3->cframe.rotation.elt[0][0]; /*0x141051e06*/
        *(_OWORD *)&v210->value.data[16] = *(_OWORD *)&Region3->cframe.rotation.elt[1][1]; /*0x141051e0e*/
        *(_OWORD *)&v210->value.data[32] = *(_OWORD *)&Region3->cframe.rotation.elt[2][2]; /*0x141051e16*/
        *(_QWORD *)&v210->value.data[48] = *(_QWORD *)&Region3->size.x; /*0x141051e1f*/
        *(float *)&v210->value.data[56] = Region3->size.z; /*0x141051e27*/
      }
      else
      {
        if ( v212 != nullptr ) /*0x141051e32*/
        {
          v212->destruct(a1: v210->value.data); /*0x141051e3c*/
          v210->value.holder = nullptr; /*0x141051e40*/
        }
        *(_OWORD *)v210->value.data = *(_OWORD *)&Region3->cframe.rotation.elt[0][0]; /*0x141051e47*/
        *(_OWORD *)&v210->value.data[16] = *(_OWORD *)&Region3->cframe.rotation.elt[1][1]; /*0x141051e4f*/
        *(_OWORD *)&v210->value.data[32] = *(_OWORD *)&Region3->cframe.rotation.elt[2][2]; /*0x141051e57*/
        *(_QWORD *)&v210->value.data[48] = *(_QWORD *)&Region3->size.x; /*0x141051e60*/
        *(float *)&v210->value.data[56] = Region3->size.z; /*0x141051e68*/
        v210->value.holder = v211; /*0x141051e6b*/
      }
      goto LABEL_438; /*0x141051e2a*/
    case NetworkValueFormat_Region3int16:
      Region3int16 = (RBX::Vector3 *)RBX::Network::NetworkStream::readRegion3int16( /*0x141051e80*/
                                       this: inBitStream,
                                       result: (RBX::Region3int16 *)&value);
      v106 = out->variant; /*0x141051e8a*/
      v106->_type = RBX::Reflection::Type::getSingleton<RBX::Region3int16>(); /*0x141051e93*/
      v107 = (const rbx::implementation::typed_holder<RBX::Vector3> *)rbx::implementation::typed_holder<RBX::Region3int16>::singleton(); /*0x141051e9b*/
      v108 = v106->value.holder; /*0x141051e9e*/
      if ( v108 == v107 ) /*0x141051ea5*/
      {
        *(_QWORD *)v106->value.data = *(_QWORD *)&Region3int16->x; /*0x141051eaf*/
        *(float *)&v106->value.data[8] = Region3int16->z; /*0x141051eb7*/
      }
      else
      {
LABEL_146:
        if ( v108 != nullptr ) /*0x141050c3f*/
        {
          v108->destruct(a1: v106->value.data); /*0x141050c49*/
          v106->value.holder = nullptr; /*0x141050c4d*/
        }
        *(_QWORD *)v106->value.data = *(_QWORD *)&Region3int16->x; /*0x141050c55*/
        *(float *)&v106->value.data[8] = Region3int16->z; /*0x141050c5d*/
        v106->value.holder = v107; /*0x141050c60*/
      }
      goto LABEL_438; /*0x141051eba*/
    case NetworkValueFormat_Int64:
      RBX::Network::deserializeSignedVarint64((__int64 *)&value, stream: inBitStream); /*0x141051ec6*/
      v77 = out; /*0x141051ecb*/
      if ( valueType->localConformance == LocalConformance_NetworkInt64LocalInt ) /*0x141051ed8*/
      {
        networkId.scope.peerId.peerId = LODWORD(value.x); /*0x141051ee1*/
LABEL_393:
        RBX::Network::VariantValueSetter::assignValue<int>(this: v77, value: (const int *)&networkId); /*0x141051ee7*/
      }
      else
      {
LABEL_108:
        RBX::Network::VariantValueSetter::assignValue<__int64>(this: v77, (const __int64 *)&value); /*0x141050936*/
      }
      goto LABEL_438; /*0x141051ef3*/
    case NetworkValueFormat_SharedString:
      *(_QWORD *)&uid.sessionId.bits_hi = 0; /*0x141051efa*/
      Size = 0; /*0x141051eff*/
      v264 = 15; /*0x141051f04*/
      std::string::assign(this: (std::string *)&uid, _Count: 0x10u, _Ch: 0); /*0x141051f1d*/
      __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000138*/
      v213 = &uid; /*0x141051f23*/
      if ( v264 >= 0x10 ) /*0x141051f2e*/
        v213 = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x141051f2e*/
      RBX::Network::NetworkStream::readBytes( /*0x141051f3b*/
        this: inBitStream,
        inOutByteArray: (void *)v213,
        numberOfBytesToRead: 0x10u);
      boost::unordered::unordered_map<std::string,RBX::SharedString,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::SharedString>>>::find( /*0x141051f53*/
        this: &this->sharedStringReceiverDictionary,
        result: (boost::unordered::iterator_detail::iterator<boost::unordered::detail::ptr_node<std::pair<std::string const ,RBX::SharedString> > > *)&networkId,
        k: (const std::string *)&uid);
      v214 = (const RBX::SharedString *)networkId; /*0x141051f58*/
      if ( *(double *)&networkId == 0.0 ) /*0x141051f62*/
      {
        v215 = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::vector<RBX::Network::DeferredSharedStringSetter>>>,std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string>,std::equal_to<std::string>>>::operator[]( /*0x141051f70*/
                 this: &deferredSharedStrings->table_,
                 k: (const std::string *)&uid);
        localConformance = valueType->localConformance; /*0x141051f79*/
        *(_OWORD *)&v272.desc = 0; /*0x141051f81*/
        v272.variantOut = out->variant; /*0x141051f91*/
        v272.localConformance = localConformance; /*0x141051f95*/
        std::vector<RBX::Network::DeferredSharedStringSetter>::emplace_back<RBX::Network::DeferredSharedStringSetter>( /*0x141051f9d*/
          this: &v215->second,
          <_Val_0>: &v272);
      }
      else
      {
        if ( DFFlag::ReportSharedStringBreakdown.value ) /*0x141051fae*/
          RBX::PolicyServiceAnalyticsStatReporter::incrementCallbackQueueExceededCount(this: (RBX::RVideo::Mp4IoWriter *)(*(_QWORD *)&networkId + 48LL)); /*0x141051fb4*/
        if ( valueType->localConformance == LocalConformance_NetworkSharedStringLocalBinaryString ) /*0x141051fbf*/
        {
          Contents = (const rtc::webrtc_checks_impl::ToStringVal *)RBX::SharedString::getContents(this: (RBX::SharedString *)&v214[3]); /*0x141051fc9*/
          v218 = std::string::string(this: (rtc::webrtc_checks_impl::ToStringVal *)&v272, __that: Contents); /*0x141051fd5*/
          instance = v218->val; /*0x141051fdd*/
          v218->val._Mypair._Myval2._Mysize = 0; /*0x141051feb*/
          v218->val._Mypair._Myval2._Myres = 15; /*0x141051fef*/
          v218->val._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141051ff7*/
          __wind /*0xf1c000000000012c*/
          {
            RBX::Network::VariantValueSetter::assignValue<RBX::BinaryString>( /*0x141052006*/
              this: out,
              value: (const RBX::BinaryString *)&instance);
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&instance); /*0xf1c0000000000124*/
          }
          if ( instance._Mypair._Myval2._Myres >= 0x10 ) /*0x141052015*/
          {
            v219 = instance._Mypair._Myval2._Bx._Ptr; /*0x14105201a*/
            if ( instance._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141052029*/
            {
              v219 = *((char **)instance._Mypair._Myval2._Bx._Ptr - 1); /*0x14105202f*/
              if ( (unsigned __int64)(instance._Mypair._Myval2._Bx._Ptr - v219 - 8) > 0x1F ) /*0x14105203e*/
                _invalid_parameter_noinfo_noreturn(); /*0x141052040*/
            }
            operator delete(ptr: v219); /*0x141052047*/
          }
        }
        else
        {
          RBX::Network::VariantValueSetter::assignValue<RBX::SharedString>(this: out, value: v214 + 3); /*0x141052059*/
        }
      }
      if ( __eh34_unwind(0) ) /*0xf1c0000000000114*/
        goto unwind_state_0; /*0xf1c0000000000114*/
      __eh34_exit_wind_state(0, -1); /*0xf1c0000000000118*/
      if ( v264 < 0x10 ) /*0x141052068*/
        goto LABEL_438; /*0x141052068*/
      v40 = *(void **)&uid.sessionId.bits_hi; /*0x141052071*/
      if ( v264 + 1 >= 0x1000 ) /*0x141052080*/
      {
        v40 = *(void **)(*(_QWORD *)&uid.sessionId.bits_hi - 8LL); /*0x14105208a*/
        if ( (unsigned __int64)(*(_QWORD *)&uid.sessionId.bits_hi - (_QWORD)v40 - 8LL) > 0x1F ) /*0x141052099*/
          _invalid_parameter_noinfo_noreturn(); /*0x14105209f*/
      }
      goto LABEL_608; /*0x141052099*/
    case NetworkValueFormat_ProtectedStringBytecode:
      if ( !DFFlag::ReplicatorReadPSWithout.value && this->sessionCrypto._Ptr == nullptr ) /*0x1410500a6*/
      {
        if ( DFLog::SessionCrypto == 0 ) /*0x1410500b1*/
          goto $LN2_10; /*0x1410500b1*/
        FLog::FastLog( /*0x1410500c1*/
          level: DFLog::SessionCrypto,
          message: "[DFLog::SessionCrypto] Can't recv protected bytecode due to missing SessionCrypto.",
          arg0: nullptr);
        goto LABEL_438; /*0x1410500c6*/
      }
      v17 = 0; /*0x1410500cb*/
      v18 = operator new(size: 0x20u); /*0x1410500e8*/
      Size = 16; /*0x1410500ed*/
      v264 = 31; /*0x1410500f6*/
      *(_OWORD *)v18 = 0; /*0x141050102*/
      v18[16] = 0; /*0x141050105*/
      *(_QWORD *)&uid.sessionId.bits_hi = v18; /*0x141050109*/
      __eh34_enter_wind_state(-1, 0); /*0xf1c00000000003f4*/
      RBX::SharedString::SharedString(this: (RBX::SharedString *)&instance); /*0x141050113*/
      __eh34_enter_wind_state(0, 1); /*0xf1c00000000003ec*/
      v19 = &uid; /*0x141050119*/
      if ( v264 >= 0x10 ) /*0x141050124*/
        v19 = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x141050124*/
      RBX::Network::NetworkStream::readBytes(this: inBitStream, inOutByteArray: (void *)v19, numberOfBytesToRead: 0x10u); /*0x141050131*/
      v20 = &uid; /*0x141050136*/
      v21 = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x14105013b*/
      v22 = v264; /*0x141050140*/
      if ( v264 >= 0x10 ) /*0x141050149*/
        v20 = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x141050149*/
      v23 = Size; /*0x14105014d*/
      v24 = &v20[Size / 0x10]; /*0x141050152*/
      v25 = &uid; /*0x141050155*/
      if ( v264 >= 0x10 ) /*0x14105015e*/
        v25 = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x14105015e*/
      if ( v25 != v24 ) /*0x141050165*/
      {
        do /*0x141050195*/
        {
          v17 ^= (v17 >> 2) + 2654435769u + (v17 << 6) + SLOBYTE(v25->sessionId.bits_hi); /*0x14105018c*/
          v25 = (RBX::UniqueId *)((char *)v25 + 1); /*0x14105018f*/
        }
        while ( v25 != v24 ); /*0x141050195*/
        v21 = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x141050197*/
        v22 = v264; /*0x14105019c*/
      }
      v26 = 21 /*0x1410501c9*/
          * ((265 * ((~v17 + (v17 << 21)) ^ ((~v17 + (v17 << 21)) >> 24)))
           ^ ((265 * ((~v17 + (v17 << 21)) ^ ((~v17 + (v17 << 21)) >> 24))) >> 14));
      v27 = 2147483649u * ((v26 >> 28) ^ v26); /*0x1410501dc*/
      v28 = this->sharedStringReceiverDictionary.table_.bucket_count_ - 1; /*0x1410501e7*/
      v29 = v28 & v27; /*0x1410501ed*/
      if ( this->sharedStringReceiverDictionary.table_.size_ == 0 ) /*0x1410501f8*/
        goto LABEL_34; /*0x1410501f8*/
      v30 = this->sharedStringReceiverDictionary.table_.buckets_[v29].next_; /*0x141050205*/
      if ( v30 == nullptr ) /*0x14105020c*/
        goto LABEL_34; /*0x14105020c*/
      v31 = v30->next_; /*0x141050212*/
      if ( v31 == nullptr ) /*0x141050218*/
        goto LABEL_34; /*0x141050218*/
      while ( 2 ) /*0x141050220*/
      {
        v32 = v31[1].next_; /*0x141050220*/
        if ( (boost::unordered::detail::ptr_bucket *)v27 != v32 ) /*0x141050227*/
        {
          if ( (v28 & (unsigned __int64)v32) != v29 ) /*0x1410502f5*/
          {
LABEL_34:
            v38 = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::vector<RBX::Network::DeferredSharedStringSetter>>>,std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string>,std::equal_to<std::string>>>::operator[]( /*0x14105030e*/
                    this: &deferredSharedStrings->table_,
                    k: (const std::string *)&uid);
            *(_OWORD *)&v272.desc = 0; /*0x141050326*/
            v37 = out; /*0x14105032b*/
            v272.variantOut = out->variant; /*0x141050336*/
            v272.localConformance = LocalConformance_NetworkProtectedStringBytecode; /*0x14105033a*/
            std::vector<RBX::Network::DeferredSharedStringSetter>::emplace_back<RBX::Network::DeferredSharedStringSetter>( /*0x141050345*/
              this: &v38->second,
              <_Val_0>: &v272);
            goto LABEL_35; /*0x141050345*/
          }
LABEL_32:
          v31 = v31->next_; /*0x1410502f7*/
          if ( v31 != nullptr ) /*0x1410502fd*/
          {
            v21 = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x1410502ff*/
            v22 = v264; /*0x141050304*/
            continue; /*0x141050309*/
          }
          goto LABEL_34; /*0x1410502fd*/
        }
        break;
      }
      v33 = v31 + 2; /*0x14105022d*/
      if ( v31[5].next_ >= (boost::unordered::detail::ptr_bucket *)0x10 ) /*0x14105023a*/
        v33 = v33->next_; /*0x14105023c*/
      v34 = &uid; /*0x14105023f*/
      if ( v22 >= 0x10 ) /*0x141050248*/
        v34 = v21; /*0x141050248*/
      if ( (boost::unordered::detail::ptr_bucket *)v23 != v31[4].next_ || memcmp_0(Buf1: v34, Buf2: v33, Size: v23) != 0 ) /*0x14105025f*/
        goto LABEL_32; /*0x14105025f*/
      if ( DFFlag::ReportSharedStringBreakdown.value ) /*0x141050274*/
        RBX::PolicyServiceAnalyticsStatReporter::incrementCallbackQueueExceededCount(this: (RBX::RVideo::Mp4IoWriter *)&v31[6]); /*0x14105027a*/
      networkId = (RBX::Guid)v31[6].next_; /*0x141050283*/
      _InterlockedIncrement((volatile signed __int32 *)(*(_QWORD *)&networkId + 48LL)); /*0x14105028a*/
      v35 = instance._Mypair._Myval2._Bx._Ptr; /*0x14105028e*/
      *(RBX::Guid *)instance._Mypair._Myval2._Bx._Buf = networkId; /*0x14105029a*/
      networkId = (RBX::Guid)v35; /*0x14105029f*/
      boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: (boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *)&networkId); /*0x1410502ad*/
      *(_DWORD *)&instance._Mypair._Myval2._Bx._Alias[8] = v31[7].next_; /*0x1410502b5*/
      v36 = RBX::ProtectedString::fromSharedBytecode( /*0x1410502c2*/
              result: (RBX::ProtectedString *)&cFrame,
              stringRef: (const RBX::SharedString *)&instance);
      __eh34_enter_wind_state(1, 2); /*0xf1c00000000003e4*/
      v37 = out; /*0x1410502cb*/
      RBX::Network::VariantValueSetter::assignValue<RBX::ProtectedString>(this: out, value: v36); /*0x1410502d5*/
      if ( __eh34_unwind(2) ) /*0xf1c00000000003d8*/
      {
unwind_state_2:
        RBX::ProtectedString::~ProtectedString(this: (RBX::Scripting::DebuggerEvalExpression *)&cFrame); /*0xf1c000000000039c*/
        __eh34_continue_unwinding(2, 1); /*0xf1c00000000003a0*/
      }
      __eh34_exit_wind_state(2, 1); /*0xf1c00000000003dc*/
      boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: (boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *)&cFrame.rotation.elt[1][1]); /*0x1410502df*/
      boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: (boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *)&cFrame); /*0x1410502e8*/
LABEL_35:
      v39 = v37->optionalInstance; /*0x14105034a*/
      if ( v39 == nullptr /*0x14105036c*/
        || v39->guid.scope.peerId.peerId == -1
        || v37->optionalNetworkId == RBX::Network::NetworkSchema::kInvalidNetworkId )
      {
        RBX::throw_runtime_error(fmt: "Invalid Bytecode."); /*0x141052543*/
      }
      if ( __eh34_unwind(1) ) /*0xf1c00000000003cc*/
      {
unwind_state_1:
        RBX::SharedString::~SharedString(this: (RBX::SharedString *)&instance); /*0xf1c0000000000388*/
        __eh34_continue_unwinding(1, 0); /*0xf1c000000000038c*/
      }
      __eh34_exit_wind_state(1, 0); /*0xf1c00000000003d0*/
      boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: (boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *)&instance); /*0x141050377*/
      if ( v264 >= 0x10 ) /*0x141050386*/
      {
        v40 = *(void **)&uid.sessionId.bits_hi; /*0x14105038f*/
        if ( v264 + 1 >= 0x1000 ) /*0x14105039e*/
        {
          v40 = *(void **)(*(_QWORD *)&uid.sessionId.bits_hi - 8LL); /*0x1410503a4*/
          if ( (unsigned __int64)(*(_QWORD *)&uid.sessionId.bits_hi - (_QWORD)v40 - 8LL) > 0x1F ) /*0x1410503b3*/
            _invalid_parameter_noinfo_noreturn(); /*0x1410503b5*/
        }
        goto LABEL_43; /*0x1410503b3*/
      }
      if ( __eh34_unwind(0) ) /*0xf1c0000000000090*/
        goto unwind_state_0; /*0xf1c0000000000090*/
LABEL_494:
      __eh34_exit_wind_state(0, -1); /*0xf1c000000000009c*/
LABEL_438:
      readOffset = v284; /*0x141052320*/
      v15 = depth; /*0x141052327*/
$LN2_10: /*0x14105232e*/
      v238 = false; /*0x14105232e*/
      if ( DFInt::ReplicationVariantReportingLimitDepth != 0 ) /*0x14105233f*/
        v238 = v15 > DFInt::ReplicationVariantReportingLimitDepth; /*0x141052348*/
      v239 = false; /*0x14105234c*/
      v240 = false; /*0x14105234f*/
      v241 = inBitStream->readOffset - readOffset; /*0x141052356*/
      if ( DFInt::ReplicationVariantReportingLimitBytes != 0 ) /*0x141052361*/
        v239 = v241 > DFInt::ReplicationVariantReportingLimitBytes; /*0x141052369*/
      if ( DFInt::ReplicationVariantKickLimitBytes != 0 ) /*0x141052375*/
        v240 = v241 > DFInt::ReplicationVariantKickLimitBytes; /*0x14105237d*/
      v242 = false; /*0x141052381*/
      v243 = false; /*0x141052384*/
      replicatedStringDataSizeLimit = replicationMetaData->replicatedStringDataSizeLimit; /*0x14105238d*/
      if ( replicatedStringDataSizeLimit != 0 ) /*0x141052392*/
        v242 = replicationMetaData->replicatedStringDataSize > replicatedStringDataSizeLimit; /*0x14105239a*/
      variantCountLimit = replicationMetaData->variantCountLimit; /*0x14105239d*/
      if ( variantCountLimit != 0 ) /*0x1410523a2*/
        v243 = replicationMetaData->variantCount > variantCountLimit; /*0x1410523aa*/
      v246 = false; /*0x1410523ad*/
      v247 = false; /*0x1410523b0*/
      if ( DFFlag::ReplicatorSeparateVarThresholds.value ) /*0x1410523be*/
      {
        replicatedStringDataSizeReportingThreshold = replicationMetaData->replicatedStringDataSizeReportingThreshold; /*0x1410523c0*/
        if ( replicatedStringDataSizeReportingThreshold != 0 ) /*0x1410523c5*/
          v247 = replicationMetaData->replicatedStringDataSize > replicatedStringDataSizeReportingThreshold; /*0x1410523cd*/
        variantCountReportingThreshold = replicationMetaData->variantCountReportingThreshold; /*0x1410523d1*/
        if ( variantCountReportingThreshold != 0 ) /*0x1410523d6*/
          v246 = replicationMetaData->variantCount > variantCountReportingThreshold; /*0x1410523df*/
      }
      v250 = false; /*0x1410523e3*/
      v251 = DFFlag::EventMetaDataReportingTypeAndMem.value; /*0x1410523e6*/
      if ( DFFlag::EventMetaDataReportingTypeAndMem.value && DFInt::EventMetaDataReportingTotalMemoryRcvThreshold != 0 ) /*0x1410523f8*/
      {
        v250 = replicationMetaData->replicatedStringDataSize + 80 * (unsigned __int64)replicationMetaData->variantCount > DFInt::EventMetaDataReportingTotalMemoryRcvThreshold; /*0x14105241f*/
        v251 = DFFlag::EventMetaDataReportingTypeAndMem.value; /*0x141052423*/
      }
      if ( DFFlag::ReplicatorSeparateVarThresholds.value ) /*0x14105242d*/
      {
        if ( v246 ) /*0x141052432*/
          goto LABEL_467; /*0x141052432*/
        v252 = !v247; /*0x141052434*/
      }
      else
      {
        if ( v242 ) /*0x14105243c*/
          goto LABEL_467; /*0x14105243c*/
        v252 = !v243; /*0x14105243e*/
      }
      if ( v252 && !v239 && !v238 && (!v251 || !v250) ) /*0x141052453*/
      {
        v253 = replicationMetaData; /*0x14105249a*/
        goto LABEL_470; /*0x14105249a*/
      }
LABEL_467:
      std::string::string(this: (std::string *)&v272, _Ptr: "ReplicatorReadVariantLimit"); /*0x141052455*/
      __wind /*0xf1c0000000000084*/
      {
        v253 = replicationMetaData; /*0x14105247f*/
        RBX::Network::Replicator::reportEventParameterLimitReached( /*0x141052489*/
          metaData: replicationMetaData,
          levelNestedStreamSizeBytes: v241,
          table: (const std::string *)&v272,
          evtSerializationReportData: &this->evtDeserializationReportData,
          depth);
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v272); /*0xf1c000000000007c*/
      }
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v272); /*0x141052493*/
LABEL_470:
      if ( DFFlag::ReplicatorKickReadEventStringDataAndVariantLimit.value )
      {
        if ( v242 )
        {
          v259 = RBX::format(
                   &result,
                   fmt: "Replicator read variant: Total string data size exceed limit! (%u)",
                   v253->replicatedStringDataSize);
          __eh34_enter_wind_state(-1, 31); /*0xf1c0000000000034*/
          RBX::network_stream_exception::network_stream_exception( /*0x14105267b*/
            this: (RBX::network_stream_exception *)&points,
            m: v259);
          throw (RBX::network_stream_exception *)&points; /*0x14105268b*/
        }
        if ( v243 )
        {
          v260 = RBX::format(
                   &result,
                   fmt: "Replicator read variant: Variant count exceeded limit! (%u)",
                   v253->variantCount);
          __eh34_enter_wind_state(-1, 31); /*0xf1c000000000002c*/
          RBX::network_stream_exception::network_stream_exception( /*0x1410526b0*/
            this: (RBX::network_stream_exception *)&points,
            m: v260);
          throw (RBX::network_stream_exception *)&points; /*0x1410526c0*/
        }
      }
      if ( DFFlag::ReplicatorKickBigV.value && v240 )
      {
        v261 = RBX::format(&result, fmt: "Replicator read variant: Variant read size exceeded limit! (%u)", v241);
        __eh34_enter_wind_state(-1, 31); /*0xf1c0000000000024*/
        RBX::network_stream_exception::network_stream_exception(this: (RBX::network_stream_exception *)&points, m: v261); /*0x1410526e4*/
        throw (RBX::network_stream_exception *)&points; /*0x1410526f4*/
      }
      return; /*0x1410524cd*/
    case NetworkValueFormat_DateTime:
      DateTime = RBX::Network::NetworkStream::readDateTime(this: inBitStream, result: (RBX::DateTime *)&uid); /*0x1410520b3*/
      v221 = out->variant; /*0x1410520bd*/
      v221->_type = RBX::Reflection::Type::getSingleton<RBX::DateTime>(); /*0x1410520c6*/
      v222 = rbx::implementation::typed_holder<RBX::DateTime>::singleton(); /*0x1410520ce*/
      v223 = v221->value.holder; /*0x1410520d1*/
      if ( v223 == v222 ) /*0x1410520d8*/
      {
        *(_QWORD *)v221->value.data = DateTime->utcTime.time_.time_count_.value_; /*0x1410520dd*/
        *(_QWORD *)&v221->value.data[8] = DateTime->localTime.time_.time_count_.value_; /*0x1410520e5*/
      }
      else
      {
        if ( v223 != nullptr ) /*0x1410520f1*/
        {
          v223->destruct(a1: v221->value.data); /*0x1410520fb*/
          v221->value.holder = nullptr; /*0x1410520ff*/
        }
        *(_QWORD *)v221->value.data = DateTime->utcTime.time_.time_count_.value_; /*0x141052106*/
        *(_QWORD *)&v221->value.data[8] = DateTime->localTime.time_.time_count_.value_; /*0x14105210e*/
        v221->value.holder = v222; /*0x141052112*/
      }
      goto LABEL_438; /*0x1410520e9*/
    case NetworkValueFormat_String_FixedDictionary:
      Byte = RBX::Network::NetworkStream::readByte(this: inBitStream); /*0x14105211e*/
      if ( (Byte & 0x80u) != 0 ) /*0x141052127*/
      {
        v225 = Byte & 0x7F; /*0x141052129*/
        networkId.scope.peerId.peerId = 0; /*0x14105212b*/
        if ( v225 >= 0x7Fu ) /*0x141052133*/
        {
          RBX::Network::deserializeUnsignedVarint(value: (unsigned int *)&networkId, stream: inBitStream); /*0x141052144*/
          v226 = networkId.scope.peerId.peerId + 127; /*0x14105214f*/
        }
        else
        {
          v226 = v225; /*0x141052135*/
        }
        networkId.scope.peerId.peerId = v226; /*0x141052152*/
        v227 = RBX::Network::NetworkSchema::fixedDictionaryStringFromNetworkId( /*0x141052162*/
                 this: this->networkSchema,
                 networkId: v226);
        v14->replicatedStringDataSize += v227->_Mypair._Myval2._Mysize; /*0x14105216b*/
        RBX::Network::VariantValueSetter::assignValue<std::string>(this: out, value: v227); /*0x141052179*/
        goto LABEL_438; /*0x14105217e*/
      }
      *(_QWORD *)&uid.sessionId.bits_hi = 0; /*0x141052183*/
      Size = 0; /*0x141052188*/
      v264 = 15; /*0x14105218d*/
      __eh34_enter_wind_state(-1, 0); /*0xf1c000000000010c*/
      if ( Byte >= 0x7Fu )
      {
        v230 = RBX::Network::Replicator::getReadPayloadLimit(this); /*0x1410521e2*/
        RBX::Network::deserializeString(value: (std::string *)&uid, stream: inBitStream, maxStringReadSize: v230); /*0x1410521f2*/
      }
      else
      {
        v228 = Byte; /*0x14105219f*/
        if ( Byte > inBitStream->numberOfBytesUsed - inBitStream->readOffset )
        {
          NumberOfUnreadBytes = RBX::Network::NetworkStream::GetNumberOfUnreadBytes(this: inBitStream); /*0x141052624*/
          v258 = RBX::format(
                   result: (std::string *)&v272,
                   fmt: "BitStream string read: String too long (%u requested %u available)",
                   v228,
                   NumberOfUnreadBytes);
          __eh34_enter_wind_state(0, 23); /*0xf1c000000000003c*/
          RBX::network_stream_exception::network_stream_exception( /*0x141052647*/
            this: (RBX::network_stream_exception *)&cFrame,
            m: v258);
          throw (RBX::network_stream_exception *)&cFrame; /*0x141052657*/
        }
        std::string::resize(this: (std::string *)&uid, _Newsize: Byte, _Ch: 0); /*0x1410521bc*/
        v229 = &uid; /*0x1410521c1*/
        if ( v264 >= 0x10 ) /*0x1410521cc*/
          v229 = *(RBX::UniqueId **)&uid.sessionId.bits_hi; /*0x1410521cc*/
        RBX::Network::NetworkStream::readBytes( /*0x1410521d8*/
          this: inBitStream,
          inOutByteArray: (void *)v229,
          numberOfBytesToRead: v228);
      }
      v14->replicatedStringDataSize += Size; /*0x1410521fb*/
      RBX::Network::VariantValueSetter::assignValue<std::string>(this: out, value: (const std::string *)&uid); /*0x14105220b*/
      if ( __eh34_unwind(0) ) /*0xf1c00000000000ec*/
      {
unwind_state_0:
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&uid); /*0xf1c0000000000094*/
        __eh34_propagate_exception_into_caller(0, -1); /*0xf1c0000000000098*/
      }
      __eh34_exit_wind_state(0, -1); /*0xf1c00000000000f0*/
      if ( v264 < 0x10 ) /*0x14105221a*/
        goto LABEL_438; /*0x14105221a*/
      v40 = *(void **)&uid.sessionId.bits_hi; /*0x141052223*/
      if ( v264 + 1 >= 0x1000 ) /*0x141052232*/
      {
        v40 = *(void **)(*(_QWORD *)&uid.sessionId.bits_hi - 8LL); /*0x14105223c*/
        if ( (unsigned __int64)(*(_QWORD *)&uid.sessionId.bits_hi - (_QWORD)v40 - 8LL) > 0x1F ) /*0x14105224b*/
          _invalid_parameter_noinfo_noreturn(); /*0x141052251*/
      }
LABEL_608:
      __eh34_enter_wind_state(-1, 0); /*0xf1c00000000003c4*/
      goto LABEL_43; /*0xf1c00000000003c8*/
    case NetworkValueFormat_OptionalCoordinateFrame_ExactEncoding:
      webrtc::AudioNetworkAdaptorImpl::Config::Config(this: (Json::Value::CommentInfo *)&networkId); /*0x141050e96*/
      __eh34_enter_wind_state(-1, 5); /*0xf1c000000000034c*/
      RBX::Network::deserializeOptionalCoordinateFrameExact( /*0x141050ea6*/
        optionalCFrame: (RBX::OptionalCoordinateFrame *)&networkId,
        bitStream: inBitStream);
      RBX::Network::VariantValueSetter::assignValue<RBX::OptionalCoordinateFrame>( /*0x141050eb9*/
        this: out,
        value: (const RBX::OptionalCoordinateFrame *)&networkId);
      if ( __eh34_unwind(5) ) /*0xf1c0000000000340*/
        goto unwind_state_5; /*0xf1c0000000000340*/
      goto LABEL_592; /*0xf1c0000000000340*/
    case NetworkValueFormat_OptionalCoordinateFrame_GeneralEncoding:
      OptionalCoordinateFrame = RBX::Network::NetworkStream::readOptionalCoordinateFrame( /*0x141050eda*/
                                  this: inBitStream,
                                  result: (RBX::OptionalCoordinateFrame *)&networkId);
      __eh34_enter_wind_state(-1, 5); /*0xf1c0000000000338*/
      RBX::Network::VariantValueSetter::assignValue<RBX::OptionalCoordinateFrame>( /*0x141050eea*/
        this: out,
        value: OptionalCoordinateFrame);
      if ( __eh34_unwind(5) ) /*0xf1c0000000000324*/
      {
unwind_state_5:
        RBX::OptionalCoordinateFrame::~OptionalCoordinateFrame(this: (RBX::OptionalCoordinateFrame *)&networkId); /*0xf1c0000000000328*/
        __eh34_propagate_exception_into_caller(5, -1); /*0xf1c000000000032c*/
      }
LABEL_592:
      __eh34_exit_wind_state(5, -1); /*0xf1c0000000000344*/
      RBX::OptionalCoordinateFrame::~OptionalCoordinateFrame(this: (RBX::OptionalCoordinateFrame *)&networkId); /*0x141050ec6*/
      goto LABEL_438; /*0x141050ecb*/
    case NetworkValueFormat_UniqueId:
      UInt64 = RBX::Network::NetworkStream::readUInt64(this: inBitStream); /*0x141052260*/
      UInt32 = RBX::Network::NetworkStream::readUInt32(this: inBitStream); /*0x14105226b*/
      v233 = RBX::Network::NetworkStream::readUInt32(this: inBitStream); /*0x141052275*/
      value = (RBX::Vector3)*RBX::UniqueSessionId::UniqueSessionId( /*0x14105228b*/
                               this: (RBX::UniqueSessionId *)&instance,
                               rawbits: UInt64,
                               timestamp: UInt32);
      RBX::UniqueId::UniqueId(this: &uid, sessionId: (RBX::UniqueSessionId *)&value, index: v233); /*0x1410522a2*/
      RBX::Network::VariantValueSetter::assignValue<RBX::UniqueId>(this: out, value: &uid); /*0x1410522b3*/
      goto LABEL_438; /*0x1410522b8*/
    case NetworkValueFormat_PathWaypointWithLabel:
      v234 = RBX::Network::Replicator::getReadPayloadLimit(this); /*0x1410522bd*/
      PathWaypointWithLabel = RBX::Network::NetworkStream::readPathWaypointWithLabel( /*0x1410522cd*/
                                this: inBitStream,
                                result: (RBX::PathWaypoint *)&uid,
                                readPayloadLimit: v234);
      __wind /*0xf1c00000000000e0*/
      {
        RBX::Network::VariantValueSetter::assignValue<RBX::PathWaypoint>(this: out, value: PathWaypointWithLabel); /*0x1410522dd*/
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&uid); /*0xf1c00000000000d8*/
      }
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&uid); /*0x1410522e8*/
      goto LABEL_438; /*0x1410522ed*/
    case NetworkValueFormat_Font:
      v236 = RBX::Network::Replicator::getReadPayloadLimit(this); /*0x1410522f2*/
      Font = RBX::Network::NetworkStream::readFont( /*0x141052301*/
               this: inBitStream,
               result: (RBX::Text::FontInfo *)&points,
               maxStringReadSize: v236);
      __wind /*0xf1c00000000000c8*/
      {
        RBX::Network::VariantValueSetter::assignValue<RBX::Text::FontInfo>(this: out, value: Font); /*0x141052311*/
      }
      __unwind
      {
        RBX::Text::FontInfo::~FontInfo(this: (RBX::Text::FontInfo *)&points); /*0xf1c00000000000c0*/
      }
      RBX::Text::FontInfo::~FontInfo(this: (RBX::Text::FontInfo *)&points); /*0x14105231b*/
      goto LABEL_438; /*0x14105231b*/
    default:
      RBX::runtime_error(
        result: (std::runtime_error *)&uid,
        fmt: "Cannot read property value: unhandled type",
        valueType,
        useDictionaries);
      throw (std::runtime_error *)&uid; /*0x14105250d*/
  }
}

// END VariantValueSetter part 1/1, 1 functions
