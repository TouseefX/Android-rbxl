// CCRakNetSlidingWindow -- 2022 Studio + full PDB
// tier 3, 14 functions


// Address: 0x1411a2d50 | Name: ?GetIsInSlowStart@CCRakNetSlidingWindow@RakNet@@UEBA_NXZ
bool __fastcall RakNet::CCRakNetSlidingWindow::GetIsInSlowStart(RakNet::CCRakNetSlidingWindow *this)
{
  double ssThresh; // xmm1_8

  ssThresh = this->ssThresh; /*0x1411a2d50*/
  return ssThresh >= this->cwnd || ssThresh == 0.0; /*0x1411a2d69*/
}

// Address: 0x1411a3e20 | Name: ?OnNAK@CCRakNetSlidingWindow@RakNet@@UEAAX_KUuint24_t@2@@Z
unsigned __int8 *__fastcall RakNet::CCRakNetSlidingWindow::OnNAK(webrtc::I420Buffer *this)
{
  return (unsigned __int8 *)this->DataY(this);
}

// Address: 0x1411a62b0 | Name: ??0CCRakNetSlidingWindow@RakNet@@QEAA@XZ
RakNet::CCRakNetSlidingWindow *__fastcall RakNet::CCRakNetSlidingWindow::CCRakNetSlidingWindow(
        RakNet::CCRakNetSlidingWindow *this)
{
  this->__vftable = (RakNet::CCRakNetSlidingWindow_vtbl *)RakNet::CCRakNetSlidingWindow::`vftable'; /*0x1411a62b7*/
  return this; /*0x1411a62bd*/
}

// Address: 0x1411a62f0 | Name: ?GetAndIncrementNextDatagramSequenceNumber@CCRakNetSlidingWindow@RakNet@@UEAA?AUuint24_t@2@XZ
RakNet::uint24_t *__fastcall RakNet::CCRakNetSlidingWindow::GetAndIncrementNextDatagramSequenceNumber(
        RakNet::CCRakNetSlidingWindow *this,
        RakNet::uint24_t *result)
{
  unsigned int val; // eax

  val = this->nextDatagramSequenceNumber.val; /*0x1411a62f0*/
  result->val = val; /*0x1411a62f3*/
  this->nextDatagramSequenceNumber.val = val + 1; /*0x1411a62f7*/
  HIBYTE(this->nextDatagramSequenceNumber.val) = 0; /*0x1411a62fd*/
  return result; /*0x1411a6301*/
}

// Address: 0x1411a6310 | Name: ?GetAvailableTransmissionCapacityBytesWithinWindow@CCRakNetSlidingWindow@RakNet@@UEAAHMM_K0@Z
__int64 __fastcall RakNet::CCRakNetSlidingWindow::GetAvailableTransmissionCapacityBytesWithinWindow(
        RakNet::CCRakNetSlidingWindow *this,
        float ms,
        float percentLoss,
        unsigned __int64 bytesInResendBuffer)
{
  return (unsigned int)(int)(float)((float)(ms * 65536.0) / 1000.0); /*0x1411a6324*/
}

// Address: 0x1411a6330 | Name: ?GetNextDatagramSequenceNumber@CCRakNetSlidingWindow@RakNet@@UEAA?AUuint24_t@2@XZ
RakNet::uint24_t *__fastcall RakNet::CCRakNetSlidingWindow::GetNextDatagramSequenceNumber(
        RakNet::CCRakNetSlidingWindow *this,
        RakNet::uint24_t *result)
{
  result->val = (unsigned int)this->nextDatagramSequenceNumber; /*0x1411a6333*/
  return result; /*0x1411a6338*/
}

// Address: 0x1411a6340 | Name: ?GetRetransmissionBandwidth@CCRakNetSlidingWindow@RakNet@@UEAAH_K0I_NAEAUTxBwInfluencers@2@@Z
__int64 __fastcall RakNet::CCRakNetSlidingWindow::GetRetransmissionBandwidth(
        RakNet::CCRakNetSlidingWindow *this,
        unsigned __int64 curTime,
        unsigned __int64 timeSinceLastTick,
        unsigned int unacknowledgedBytes)
{
  return unacknowledgedBytes; /*0x1411a6343*/
}

// Address: 0x1411a6350 | Name: ?GetTransmissionBandwidth@CCRakNetSlidingWindow@RakNet@@UEAAH_K0I_NAEAUTxBwInfluencers@2@@Z
__int64 __fastcall RakNet::CCRakNetSlidingWindow::GetTransmissionBandwidth(
        RakNet::CCRakNetSlidingWindow *this,
        unsigned __int64 curTime,
        unsigned __int64 timeSinceLastTick,
        int unacknowledgedBytes,
        bool isContinuousSend)
{
  double cwnd; // xmm0_8

  cwnd = this->cwnd; /*0x1411a6358*/
  this->_isContinuousSend = isContinuousSend; /*0x1411a635d*/
  if ( cwnd < (double)unacknowledgedBytes ) /*0x1411a636c*/
    return 0; /*0x1411a6377*/
  else
    return (unsigned int)(int)(cwnd - (double)unacknowledgedBytes); /*0x1411a6372*/
}

// Address: 0x1411a6380 | Name: ?Init@CCRakNetSlidingWindow@RakNet@@UEAAX_KI@Z
void __fastcall RakNet::CCRakNetSlidingWindow::Init(
        RakNet::CCRakNetSlidingWindow *this,
        unsigned __int64 curTime,
        signed int maxDatagramPayload)
{
  this->MAXIMUM_MTU_INCLUDING_UDP_HEADER = maxDatagramPayload; /*0x1411a638a*/
  this->RTT = -1.0; /*0x1411a638e*/
  this->cwnd = (double)maxDatagramPayload; /*0x1411a639d*/
  if ( DFInt::RakNetConnectionStartWindow_HundredthsPercentage != 0 /*0x1411a63b1*/
    && DFInt::RakNetConnectionStartWindow_HundredthsPercentage <= 10000 )
  {
    this->cwnd = (double)DFInt::RakNetConnectionStartWindow_HundredthsPercentage /*0x1411a63d7*/
               / 10000.0
               * (double)FInt::RakNetResendBufferArrayLength
               * (double)maxDatagramPayload;
  }
  *(_QWORD *)&this->nextDatagramSequenceNumber.val = 0; /*0x1411a63de*/
  this->expectedNextSequenceNumber.val = 0; /*0x1411a63e2*/
  HIBYTE(this->nextDatagramSequenceNumber.val) = 0; /*0x1411a63e5*/
  *(_WORD *)((char *)&this->nextCongestionControlBlock.val + 3) = 0; /*0x1411a63e8*/
  *(_WORD *)((char *)&this->expectedNextSequenceNumber.val + 3) = 0; /*0x1411a63ec*/
  this->ssThresh = 0.0; /*0x1411a63f0*/
  this->oldestUnsentAck = 0; /*0x1411a63f4*/
  this->speedUpThisBlock = false; /*0x1411a63f8*/
}

// Address: 0x1411a6400 | Name: ?OnAck@CCRakNetSlidingWindow@RakNet@@UEAAX_K0_NNNN1Uuint24_t@2@@Z
void __fastcall RakNet::CCRakNetSlidingWindow::OnAck(
        RakNet::CCRakNetSlidingWindow *this,
        unsigned __int64 curTime,
        __int64 rtt,
        bool hasBAndAS,
        long double B,
        long double AS,
        long double totalUserDataBytesAcked,
        bool isContinuousSend,
        _DWORD *sequenceNumber)
{
  double v10; // xmm0_8
  unsigned int val; // eax
  char v12; // cl
  double ssThresh; // xmm2_8
  double cwnd; // xmm1_8
  long double v15; // xmm1_8

  if ( rtt < 0 ) /*0x1411a6409*/
    v10 = (double)(int)(rtt & 1 | ((unsigned __int64)rtt >> 1)) + (double)(int)(rtt & 1 | ((unsigned __int64)rtt >> 1)); /*0x1411a6424*/
  else
    v10 = (double)(int)rtt; /*0x1411a640b*/
  this->RTT = v10; /*0x1411a642d*/
  this->_isContinuousSend = isContinuousSend; /*0x1411a6432*/
  if ( isContinuousSend ) /*0x1411a6437*/
  {
    val = this->nextCongestionControlBlock.val; /*0x1411a643d*/
    if ( val == *sequenceNumber || ((val - *sequenceNumber) & 0xFFFFFF) <= 0x7FFFFF ) /*0x1411a645a*/
    {
      ssThresh = this->ssThresh; /*0x1411a6477*/
      v12 = 0; /*0x1411a647c*/
    }
    else
    {
      v12 = 1; /*0x1411a645f*/
      this->nextCongestionControlBlock.val = this->nextDatagramSequenceNumber.val; /*0x1411a6461*/
      ssThresh = 0.0; /*0x1411a6464*/
      *(_WORD *)&this->backoffThisBlock = 0; /*0x1411a6467*/
      this->ssThresh = 0.0; /*0x1411a646d*/
    }
    cwnd = this->cwnd; /*0x1411a647e*/
    if ( ssThresh >= cwnd || ssThresh == 0.0 ) /*0x1411a648f*/
    {
      if ( cwnd < 10000000.0 ) /*0x1411a64bd*/
      {
        v15 = cwnd + cwnd; /*0x1411a64bf*/
        this->cwnd = v15; /*0x1411a64c7*/
        if ( v15 > ssThresh && ssThresh != 0.0 ) /*0x1411a64d4*/
          this->cwnd = (double)(this->MAXIMUM_MTU_INCLUDING_UDP_HEADER * this->MAXIMUM_MTU_INCLUDING_UDP_HEADER) /*0x1411a64ec*/
                     / ssThresh
                     + ssThresh;
      }
    }
    else if ( v12 != 0 ) /*0x1411a6493*/
    {
      this->cwnd = (double)(this->MAXIMUM_MTU_INCLUDING_UDP_HEADER * this->MAXIMUM_MTU_INCLUDING_UDP_HEADER) / cwnd /*0x1411a64ab*/
                 + cwnd;
    }
  }
}

// Address: 0x1411a6500 | Name: ?OnGotPacket@CCRakNetSlidingWindow@RakNet@@UEAA_NUuint24_t@2@_N_KIPEAI@Z
char __fastcall RakNet::CCRakNetSlidingWindow::OnGotPacket(
        RakNet::CCRakNetSlidingWindow *this,
        int *datagramSequenceNumber,
        bool isContinuousSend,
        unsigned __int64 curTime,
        unsigned int sizeInBytes,
        unsigned int *skippedMessageCount)
{
  int v6; // r8d
  unsigned int val; // r9d
  unsigned int v9; // r8d

  if ( this->oldestUnsentAck == 0 ) /*0x1411a6505*/
    this->oldestUnsentAck = curTime; /*0x1411a6507*/
  v6 = *datagramSequenceNumber; /*0x1411a650b*/
  val = this->expectedNextSequenceNumber.val; /*0x1411a650e*/
  if ( *datagramSequenceNumber == val ) /*0x1411a6515*/
  {
    *skippedMessageCount = 0; /*0x1411a651c*/
    this->expectedNextSequenceNumber.val = (*datagramSequenceNumber + 1) & 0xFFFFFF; /*0x1411a652b*/
    return 1; /*0x1411a6530*/
  }
  if ( ((val - v6) & 0xFFFFFF) <= 0x7FFFFF ) /*0x1411a6546*/
  {
    *skippedMessageCount = 0; /*0x1411a657f*/
    return 1; /*0x1411a6585*/
  }
  else
  {
    v9 = (v6 - val) & 0xFFFFFF; /*0x1411a654b*/
    *skippedMessageCount = v9; /*0x1411a6552*/
    if ( v9 > 0x3E8 ) /*0x1411a655c*/
    {
      if ( v9 > 0xC350 ) /*0x1411a6565*/
        return 0; /*0x1411a6569*/
      *skippedMessageCount = 1000; /*0x1411a656a*/
    }
    this->expectedNextSequenceNumber.val = (*datagramSequenceNumber + 1) & 0xFFFFFF; /*0x1411a6579*/
    return 1; /*0x1411a657c*/
  }
}

// Address: 0x1411a6590 | Name: ?OnResend@CCRakNetSlidingWindow@RakNet@@UEAAX_K@Z
void __fastcall RakNet::CCRakNetSlidingWindow::OnResend(RakNet::CCRakNetSlidingWindow *this, unsigned __int64 curTime)
{
  signed int MAXIMUM_MTU_INCLUDING_UDP_HEADER; // r8d
  double cwnd; // xmm3_8
  double v4; // xmm2_8
  double v5; // xmm4_8
  long double v6; // xmm3_8

  if ( this->_isContinuousSend && !this->backoffThisBlock ) /*0x1411a659e*/
  {
    MAXIMUM_MTU_INCLUDING_UDP_HEADER = this->MAXIMUM_MTU_INCLUDING_UDP_HEADER; /*0x1411a65a4*/
    cwnd = this->cwnd; /*0x1411a65ab*/
    if ( cwnd > (double)(2 * MAXIMUM_MTU_INCLUDING_UDP_HEADER) ) /*0x1411a65bd*/
    {
      v4 = (double)MAXIMUM_MTU_INCLUDING_UDP_HEADER; /*0x1411a65cc*/
      if ( (unsigned int)(DFInt::RakNetResendScaleBackFactorHundredthsPercent - 1) > 0x270E ) /*0x1411a65d9*/
      {
        v6 = cwnd * 0.5; /*0x1411a6622*/
        this->ssThresh = v6; /*0x1411a662e*/
        if ( v4 > v6 ) /*0x1411a6633*/
          this->ssThresh = v4; /*0x1411a6635*/
        this->cwnd = v4; /*0x1411a663a*/
        this->backoffThisBlock = true; /*0x1411a663f*/
      }
      else
      {
        v5 = (10000.0 - (double)DFInt::RakNetResendScaleBackFactorHundredthsPercent) / 10000.0 * cwnd; /*0x1411a65f7*/
        this->cwnd = v5; /*0x1411a65ff*/
        if ( v4 <= v5 ) /*0x1411a6604*/
        {
          this->ssThresh = v5; /*0x1411a6615*/
        }
        else
        {
          this->cwnd = v4; /*0x1411a6606*/
          this->ssThresh = v4; /*0x1411a660b*/
        }
        this->backoffThisBlock = true; /*0x1411a6610*/
      }
    }
  }
}

// Address: 0x1411a6650 | Name: ?OnSendAck@CCRakNetSlidingWindow@RakNet@@UEAAX_KI@Z
void __fastcall RakNet::CCRakNetSlidingWindow::OnSendAck(
        RakNet::CCRakNetSlidingWindow *this,
        unsigned __int64 curTime,
        unsigned int numBytes)
{
  this->oldestUnsentAck = 0; /*0x1411a6650*/
}

// Address: 0x1411a6660 | Name: ?ResetCCWindowToDFInt@CCRakNetSlidingWindow@RakNet@@UEAAXI@Z
void __fastcall RakNet::CCRakNetSlidingWindow::ResetCCWindowToDFInt(
        RakNet::CCRakNetSlidingWindow *this,
        unsigned int maxDatagramPayload)
{
  double v2; // xmm1_8

  if ( DFInt::RakNetConnectionStartWindow_HundredthsPercentage != 0 /*0x1411a6673*/
    && DFInt::RakNetConnectionStartWindow_HundredthsPercentage <= 10000 )
  {
    v2 = (double)(int)(FInt::RakNetResendBufferArrayLength * maxDatagramPayload) /*0x1411a6697*/
       * ((double)DFInt::RakNetConnectionStartWindow_HundredthsPercentage
        / 10000.0);
    if ( v2 > this->cwnd ) /*0x1411a66a0*/
      this->cwnd = v2; /*0x1411a66a2*/
  }
}

// END CCRakNetSlidingWindow part 1/1, 14 functions
