// EAUInternalPacket -- 2022 Studio + full PDB
// tier 3, 1 functions


// Address: 0x1410fc5d0 | Name: ??$_Resize_reallocate@PEAUInternalPacket@RakNet@@@?$vector@PEAUInternalPacket@RakNet@@V?$allocator@PEAUInternalPacket@RakNet@@@std@@@std@@AEAAX_KAEBQEAUInternalPacket@RakNet@@@Z
void __fastcall std::vector<RakNet::InternalPacket *>::_Resize_reallocate<RakNet::InternalPacket *>(
        std::vector<unsigned __int64> *this,
        unsigned __int64 _Newsize,
        struct VkImage_T **_Val)
{
  unsigned __int64 v6; // rbx
  signed __int64 v7; // r15
  unsigned __int64 v8; // rcx
  unsigned __int64 v9; // rdx
  struct VkImage_T **v10; // r12
  struct VkImage_T **v11; // rcx
  unsigned __int64 v12; // rdx

  v6 = 0x1FFFFFFFFFFFFFFFLL; /*0x1410fc5ef*/
  if ( _Newsize > 0x1FFFFFFFFFFFFFFFLL ) /*0x1410fc5fc*/
    std::vector<Luau::AstNode *>::_Xlength(); /*0x1410fc6c5*/
  v7 = this->_Mypair._Myval2._Mylast - this->_Mypair._Myval2._Myfirst; /*0x1410fc609*/
  v8 = this->_Mypair._Myval2._Myend - this->_Mypair._Myval2._Myfirst; /*0x1410fc614*/
  v9 = v8 >> 1; /*0x1410fc61b*/
  if ( v8 <= 0x1FFFFFFFFFFFFFFFLL - (v8 >> 1) ) /*0x1410fc627*/
  {
    v6 = v9 + v8; /*0x1410fc629*/
    if ( v9 + v8 < _Newsize ) /*0x1410fc630*/
      v6 = _Newsize; /*0x1410fc630*/
  }
  v10 = std::allocator<void (RBX::Graphics::EnvMapPBR::*)(RBX::Graphics::DeviceContext *,RBX::RenderPassStats &)>::allocate( /*0x1410fc644*/
          (std::allocator<VkImage_T *> *)this,
          _Count: v6);
  v11 = &v10[v7]; /*0x1410fc64c*/
  v12 = _Newsize - v7; /*0x1410fc653*/
  if ( *_Val != nullptr ) /*0x1410fc65a*/
  {
    for ( ; v12 != 0; --v12 ) /*0x1410fc670*/
      *v11++ = *_Val; /*0x1410fc683*/
  }
  else
  {
    memset_0(a1: v11, Val: 0, Size: 8 * v12); /*0x1410fc666*/
  }
  memmove_0( /*0x1410fc69d*/
    a1: v10,
    Src: this->_Mypair._Myval2._Myfirst,
    Size: (char *)this->_Mypair._Myval2._Mylast - (char *)this->_Mypair._Myval2._Myfirst);
  std::vector<RBX::IMoving *>::_Change_array( /*0x1410fc6c0*/
    (std::vector<char const *> *)this,
    _Newvec: (const char **const)v10,
    _Newsize,
    _Newcapacity: v6);
}

// END EAUInternalPacket part 1/1, 1 functions
