// SocketLayer -- 2022 Studio + full PDB
// tier 3, 11 functions


// Address: 0x14118f610 | Name: ?CreateBoundSocket@SocketLayer@RakNet@@SA_KPEAUaddrinfo@@GGG_NPEBDIG@Z
unsigned __int64 __fastcall RakNet::SocketLayer::CreateBoundSocket(
        addrinfo *servInfo,
        unsigned __int16 port,
        unsigned __int16 portLow,
        unsigned __int16 portHigh,
        bool blockingSocket,
        char *forceHostAddress,
        unsigned int sleepOn10048,
        unsigned __int16 socketFamily)
{
  int v9; // r12d
  int v10; // ebp
  int v11; // edi
  unsigned int v12; // esi
  int v13; // ebx
  double v14; // xmm6_8
  int v15; // esi
  unsigned __int64 BoundSocket; // r14
  double v17; // xmm0_8
  double v19; // xmm0_8
  unsigned int v20; // [rsp+40h] [rbp-48h]

  if ( !DFFlag::EnableSocketPortSharding.value || port != 0 || portLow == 0 || portHigh == 0 || portLow >= portHigh ) /*0x14118f64d*/
    return RakNet::SocketLayer::CreateBoundSocket( /*0x14118f801*/
             servinfo: servInfo,
             port,
             blockingSocket,
             forcehostAddress: forceHostAddress,
             sleepOn10048,
             socketFamily);
  v9 = portHigh; /*0x14118f66b*/
  v10 = portLow; /*0x14118f66f*/
  v11 = portHigh - portLow + 1; /*0x14118f67c*/
  v12 = RBX::globalRand() % v11; /*0x14118f68b*/
  v20 = v12; /*0x14118f68d*/
  v13 = 0; /*0x14118f696*/
  v14 = RBX::Time::nowFastSec(); /*0x14118f698*/
  if ( v11 <= 0 ) /*0x14118f69d*/
  {
LABEL_9:
    v17 = (RBX::Time::nowFastSec() - v14) * 1000.0; /*0x14118f6fd*/
    if ( FLog::Network != 0 ) /*0x14118f717*/
      FLog::FastLogFormatted( /*0x14118f737*/
        level: FLog::Network,
        message: "[FLog::Network] Sharding CreateBoundSocket() port=%d, portLow=%d, portHigh=%d, could not find open port after %d"
        " iterations and %.2f ms",
        0,
        v10,
        v9,
        v11,
        v17);
    return -1; /*0x14118f73c*/
  }
  else
  {
    while ( 1 ) /*0x14118f6db*/
    {
      v15 = (int)(v13 + v12) % v11 + v10; /*0x14118f6db*/
      BoundSocket = RakNet::SocketLayer::CreateBoundSocket( /*0x14118f6e6*/
                      servinfo: servInfo,
                      port: v15,
                      blockingSocket,
                      forcehostAddress: forceHostAddress,
                      sleepOn10048,
                      socketFamily);
      if ( BoundSocket != -1 ) /*0x14118f6ed*/
        break; /*0x14118f6ed*/
      v12 = v20; /*0x14118f6f3*/
      if ( ++v13 >= v11 ) /*0x14118f6fb*/
        goto LABEL_9; /*0x14118f6fb*/
    }
    v19 = (RBX::Time::nowFastSec() - v14) * 1000.0; /*0x14118f78e*/
    if ( FLog::Network != 0 ) /*0x14118f798*/
      FLog::FastLogFormatted( /*0x14118f7bc*/
        level: FLog::Network,
        message: "[FLog::Network] Sharding CreateBoundSocket() port=%d, portLow=%d, portHigh=%d, found port=%d after %d iterations and %.2f ms",
        0,
        v10,
        v9,
        v15,
        v13,
        v19);
    return BoundSocket; /*0x14118f7c1*/
  }
}

// Address: 0x14118f810 | Name: ?CreateBoundSocket@SocketLayer@RakNet@@SA_KPEAUaddrinfo@@G_NPEBDIG@Z
SOCKET __fastcall RakNet::SocketLayer::CreateBoundSocket(
        addrinfo *servinfo,
        unsigned __int16 port,
        bool blockingSocket,
        const char *forcehostAddress,
        unsigned int sleepOn10048,
        unsigned __int16 socketFamily)
{
  unsigned int v8; // r14d
  SOCKET v9; // rsi
  sockaddr *ai_addr; // rax
  const char *v11; // r8
  int *v12; // rax
  char *v13; // rdi
  int *v14; // rax

  v8 = port; /*0x14118f831*/
  if ( DFLog::NetworkDetailed != 0 ) /*0x14118f837*/
    FLog::FastLogFormatted( /*0x14118f85c*/
      level: DFLog::NetworkDetailed,
      message: "[DFLog::NetworkDetailed] CreateBoundSocket() port=%d, blockingSocket=%d, forceHostAddress=%s, sleepOn10048=%d, socketFamily=%d",
      port,
      blockingSocket,
      forcehostAddress,
      sleepOn10048,
      socketFamily);
  if ( sleepOn10048 == 0 ) /*0x14118f863*/
    RESTRICTED_QtUtilities::sleep(dwMilliseconds: 0x64u); /*0x14118f868*/
  if ( servinfo == nullptr ) /*0x14118f87f*/
    return -1; /*0x14118f9b4*/
  while ( 1 ) /*0x14118f8a0*/
  {
    v9 = socket(af: servinfo->ai_family, type: servinfo->ai_socktype, protocol: servinfo->ai_protocol); /*0x14118f8a0*/
    if ( v9 != -1 ) /*0x14118f8a7*/
      break; /*0x14118f8a7*/
LABEL_23:
    servinfo = servinfo->ai_next; /*0x14118f984*/
    if ( servinfo == nullptr ) /*0x14118f98b*/
      return -1; /*0x14118f98b*/
  }
  if ( forcehostAddress == nullptr || *forcehostAddress == 0 ) /*0x14118f8b6*/
  {
    ai_addr = servinfo->ai_addr; /*0x14118f8c0*/
    if ( servinfo->ai_family == 2 ) /*0x14118f8c4*/
      *(_DWORD *)&ai_addr->sa_data[2] = 0; /*0x14118f8c6*/
    else
      *(in6_addr *)&ai_addr->sa_data[6] = in6addr_any; /*0x14118f8d3*/
    *(_WORD *)servinfo->ai_addr->sa_data = htons(hostshort: v8); /*0x14118f8e1*/
  }
  if ( RakNet::SocketLayer::SetSocketOptions(listenSocket: v9, socketFamily: servinfo->ai_family) != 0 ) /*0x14118f8f3*/
    return -1; /*0x14118f8f3*/
  if ( FLog::Network != 0 ) /*0x14118f902*/
  {
    v11 = "in6addr_any"; /*0x14118f908*/
    if ( servinfo->ai_family == 2 ) /*0x14118f919*/
      v11 = "inaddr_any"; /*0x14118f919*/
    FLog::FastLogFormatted(level: FLog::Network, message: "[FLog::Network] binding socket on %s:%d\n", v11, v8); /*0x14118f91f*/
  }
  if ( bind(s: v9, name: servinfo->ai_addr, namelen: servinfo->ai_addrlen) < 0 )
  {
    if ( FLog::Network != 0 )
    {
      v12 = _errno(); /*0x14118f942*/
      v13 = strerror(ErrorMessage: *v12); /*0x14118f950*/
      v14 = _errno(); /*0x14118f953*/
      FLog::FastLogFormatted(level: FLog::Network, message: "[FLog::Network] bind failed:Error : %d - %s\n", *v14, v13);
    }
    if ( DFFlag::EnableSocketPortSharding.value ) /*0x14118f979*/
      closesocket(s: v9); /*0x14118f97e*/
    goto LABEL_23; /*0x14118f97e*/
  }
  return v9; /*0x14118f998*/
}

// Address: 0x14118f9c0 | Name: ?GetAddrInfoAllocate@SocketLayer@RakNet@@SAPEAUaddrinfo@@G@Z
addrinfo *__fastcall RakNet::SocketLayer::GetAddrInfoAllocate(unsigned __int16 family)
{
  INT v1; // eax
  addrinfo hints; // [rsp+20h] [rbp-38h] BYREF
  addrinfo *servinfo; // [rsp+68h] [rbp+10h] BYREF

  servinfo = nullptr; /*0x14118f9c4*/
  memset(&hints, 0, sizeof(hints)); /*0x14118f9d0*/
  hints.ai_socktype = 2; /*0x14118f9d5*/
  if ( family != 0 ) /*0x14118f9ea*/
    hints.ai_family = family; /*0x14118f9ef*/
  hints.ai_flags = 3328; /*0x14118f9f8*/
  v1 = getaddrinfo(pNodeName: nullptr, pServiceName: "0", pHints: &hints, ppResult: &servinfo); /*0x14118fa0e*/
  if ( v1 != 0 && FLog::Network != 0 ) /*0x14118fa21*/
    FLog::FastLogFormatted( /*0x14118fa2d*/
      level: FLog::Network,
      message: "[FLog::Network] getaddrinfo(...) failed:Error code - %d\n",
      v1);
  return servinfo; /*0x14118fa37*/
}

// Address: 0x14118fa40 | Name: ?GetMyIP@SocketLayer@RakNet@@SAXQEAUSystemAddress@2@@Z
void __fastcall RakNet::SocketLayer::GetMyIP(RakNet::SystemAddress *addresses)
{
  DWORD LastError; // ebx
  std::string *Ptr; // rax
  char *v4; // rcx
  int v5; // edi
  const char *v6; // rdx
  addrinfo *v7; // r9
  PADDRINFOA v8; // rcx
  __int64 v9; // r8
  RakNet::SystemAddress *v10; // rdx
  sockaddr *ai_addr; // rax
  bool v12; // zf
  RakNet::SystemAddress *v13; // rbx
  __int64 v14; // rdi
  ADDRINFOA pHints; // [rsp+20h] [rbp-A8h] BYREF
  std::string result; // [rsp+50h] [rbp-78h] BYREF
  char name[88]; // [rsp+70h] [rbp-58h] BYREF
  PADDRINFOA ppResult; // [rsp+D8h] [rbp+10h] BYREF

  if ( gethostname(name, namelen: 80) == -1 ) /*0x14118fa63*/
  {
    LastError = GetLastError(); /*0x14118fa76*/
    Ptr = RBX::systemErrorToString(&result, err: LastError); /*0x14118fa78*/
    if ( Ptr->_Mypair._Myval2._Myres >= 0x10 ) /*0x14118fa82*/
      Ptr = (std::string *)Ptr->_Mypair._Myval2._Bx._Ptr; /*0x14118fa84*/
    printf(_Format: "gethostname failed:Error code - %d\n%s\n", LastError, Ptr->_Mypair._Myval2._Bx._Buf); /*0x14118fa93*/
    if ( result._Mypair._Myval2._Myres >= 0x10 ) /*0x14118faa1*/
    {
      v4 = result._Mypair._Myval2._Bx._Ptr; /*0x14118faa7*/
      if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14118fab9*/
      {
        v4 = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x14118fabb*/
        if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - v4 - 8) > 0x1F ) /*0x14118face*/
          _invalid_parameter_noinfo_noreturn(); /*0x14118fad0*/
      }
      operator delete(ptr: v4); /*0x14118fad7*/
    }
  }
  else
  {
    v5 = 0; /*0x14118faf8*/
    memset(&pHints, 0, sizeof(pHints)); /*0x14118fb0e*/
    ppResult = nullptr; /*0x14118fb13*/
    pHints.ai_socktype = 2; /*0x14118fb25*/
    v6 = "0"; /*0x14118fb2d*/
    pHints.ai_flags = 3072; /*0x14118fb39*/
    if ( !DFFlag::FixGetaddrinfoCallParam.value ) /*0x14118fb41*/
      v6 = pass; /*0x14118fb43*/
    getaddrinfo(pNodeName: name, pServiceName: v6, &pHints, &ppResult); /*0x14118fb4a*/
    v7 = ppResult; /*0x14118fb50*/
    v8 = ppResult; /*0x14118fb58*/
    if ( ppResult == nullptr ) /*0x14118fb5e*/
      goto LABEL_18; /*0x14118fb5e*/
    v9 = 0; /*0x14118fb60*/
    v10 = addresses; /*0x14118fb63*/
    do /*0x14118fb9c*/
    {
      if ( v9 >= 10 ) /*0x14118fb6a*/
        break; /*0x14118fb6a*/
      ai_addr = v8->ai_addr; /*0x14118fb6c*/
      v12 = v8->ai_family == 2; /*0x14118fb70*/
      *(sockaddr *)&v10->address.addr6.sin6_family = *ai_addr; /*0x14118fb77*/
      if ( !v12 ) /*0x14118fb7a*/
      {
        *((_QWORD *)&v10->address.addr4 + 2) = *(_QWORD *)&ai_addr[1].sa_family; /*0x14118fb81*/
        v10->address.addr6.sin6_scope_id = *(_DWORD *)&ai_addr[1].sa_data[6]; /*0x14118fb89*/
      }
      v8 = v8->ai_next; /*0x14118fb8c*/
      ++v5; /*0x14118fb90*/
      ++v9; /*0x14118fb92*/
      ++v10; /*0x14118fb95*/
    }
    while ( v8 != nullptr ); /*0x14118fb9c*/
    freeaddrinfo(pAddrInfo: v7); /*0x14118fba1*/
    if ( v5 < 10 ) /*0x14118fbaa*/
    {
LABEL_18:
      v13 = &addresses[v5]; /*0x14118fbb8*/
      v14 = (unsigned int)(10 - v5); /*0x14118fbbd*/
      do /*0x14118fbd7*/
      {
        RakNet::SystemAddress::operator=(this: v13++, input: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_70); /*0x14118fbca*/
        --v14; /*0x14118fbd3*/
      }
      while ( v14 != 0 ); /*0x14118fbd7*/
    }
  }
}

// Address: 0x14118fc00 | Name: ?GetSystemAddress@SocketLayer@RakNet@@SAX_KPEAUSystemAddress@2@@Z
void __fastcall RakNet::SocketLayer::GetSystemAddress(SOCKET s, RakNet::SystemAddress *systemAddressOut)
{
  bool v3; // zf
  unsigned int sin6_scope_id; // eax
  sockaddr_in6 v5; // [rsp+30h] [rbp-28h] BYREF
  int slen; // [rsp+70h] [rbp+18h] BYREF

  slen = 28; /*0x14118fc09*/
  if ( getsockname(s, name: (struct sockaddr *)&v5, namelen: &slen) != 0 ) /*0x14118fc23*/
  {
    RakNet::SystemAddress::FromString(this: systemAddressOut, str: nullptr, portDelineator: 124); /*0x14118fc2d*/
  }
  else
  {
    v3 = v5.sin6_family == 2; /*0x14118fc38*/
    *(_OWORD *)&systemAddressOut->address.addr6.sin6_family = *(_OWORD *)&v5.sin6_family; /*0x14118fc43*/
    if ( v3 ) /*0x14118fc46*/
    {
      systemAddressOut->debugPort = ntohs(netshort: systemAddressOut->address.addr6.sin6_port); /*0x14118fc52*/
      if ( systemAddressOut->address.addr6.sin6_flowinfo == 0 ) /*0x14118fc5a*/
        RakNet::SystemAddress::SetToLoopback(this: systemAddressOut, ipVersion: 4u); /*0x14118fc61*/
    }
    else
    {
      sin6_scope_id = v5.sin6_scope_id; /*0x14118fc72*/
      *((_QWORD *)&systemAddressOut->address.addr4 + 2) = *(_QWORD *)&v5.sin6_addr.u.Word[4]; /*0x14118fc76*/
      systemAddressOut->address.addr6.sin6_scope_id = sin6_scope_id; /*0x14118fc7b*/
      systemAddressOut->debugPort = ntohs(netshort: systemAddressOut->address.addr6.sin6_port); /*0x14118fc8b*/
      if ( *(_OWORD *)systemAddressOut->address.addr4.sin_zero == 0 ) /*0x14118fc9d*/
        RakNet::SystemAddress::SetToLoopback(this: systemAddressOut, ipVersion: 6u); /*0x14118fcaf*/
    }
  }
}

// Address: 0x14118fcc0 | Name: ?RecvFromBlocking@SocketLayer@RakNet@@SAX_KPEAVRakPeer@2@PEADPEAHPEAUSystemAddress@2@PEA_K4@Z
void __fastcall RakNet::SocketLayer::RecvFromBlocking(
        SOCKET s,
        RakNet::RakPeer *rakPeer,
        char *dataOut,
        int *bytesReadOut,
        RakNet::SystemAddress *systemAddressOut,
        unsigned __int64 *timeRead)
{
  int v9; // eax
  unsigned __int64 TimeUS; // rax
  bool v11; // zf
  RakNet::SystemAddress *v12; // rbx
  __int128 v13; // xmm0
  unsigned int sin6_scope_id; // eax
  timeval tv; // [rsp+30h] [rbp-248h] BYREF
  sockaddr_in6 their_addr; // [rsp+38h] [rbp-240h] BYREF
  fd_set readSet; // [rsp+60h] [rbp-218h] BYREF
  int sockLen; // [rsp+280h] [rbp+8h] BYREF

  readSet.fd_array[0] = s; /*0x14118fcef*/
  memset(&their_addr, 0, sizeof(their_addr)); /*0x14118fcfa*/
  sockLen = 28; /*0x14118fd02*/
  readSet.fd_count = 1; /*0x14118fd14*/
  tv.tv_sec = DFInt::RakNetSelectTimeoutMs / 1000; /*0x14118fd2d*/
  tv.tv_usec = 1000 * (DFInt::RakNetSelectTimeoutMs % 1000); /*0x14118fd40*/
  if ( select(nfds: s + 1, readfds: &readSet, writefds: nullptr, exceptfds: nullptr, timeout: &tv) > 0 /*0x14118fd6b*/
    && _WSAFDIsSet_0(fd: s, a2: &readSet) != 0 )
  {
    v9 = recvfrom(s, buf: dataOut, len: 1492, flags: 0, from: (struct sockaddr *)&their_addr, fromlen: &sockLen); /*0x14118fd93*/
    *bytesReadOut = v9; /*0x14118fd99*/
    if ( v9 > 0 ) /*0x14118fd9d*/
    {
      TimeUS = RakNet::GetTimeUS(isNetworkSynced: false); /*0x14118fda1*/
      v11 = their_addr.sin6_family == 2; /*0x14118fda6*/
      v12 = systemAddressOut; /*0x14118fdb4*/
      v13 = *(_OWORD *)&their_addr.sin6_family; /*0x14118fdbc*/
      *timeRead = TimeUS; /*0x14118fdc1*/
      *(_OWORD *)&v12->address.addr6.sin6_family = v13; /*0x14118fdc4*/
      if ( !v11 ) /*0x14118fdc7*/
      {
        sin6_scope_id = their_addr.sin6_scope_id; /*0x14118fdcf*/
        *((_QWORD *)&v12->address.addr4 + 2) = *(_QWORD *)&their_addr.sin6_addr.u.Word[4]; /*0x14118fdd3*/
        v12->address.addr6.sin6_scope_id = sin6_scope_id; /*0x14118fdd8*/
      }
      v12->debugPort = ntohs(netshort: v12->address.addr6.sin6_port); /*0x14118fde5*/
    }
  }
  else
  {
    *bytesReadOut = 0; /*0x14118fdeb*/
  }
}

// Address: 0x14118fe10 | Name: ?SendTo@SocketLayer@RakNet@@SAH_KPEBDHAEBUSystemAddress@2@2_N1J@Z
int __fastcall RakNet::SocketLayer::SendTo(
        SOCKET s,
        const char *data,
        int length,
        const RakNet::SystemAddress *dstAddress,
        const RakNet::SystemAddress *srcAddress,
        bool raknetMetaDataEncrypted)
{
  __int128 v10; // xmm1
  __int128 v11; // xmm0
  __int128 v12; // xmm1
  int result; // eax
  int v14; // eax
  int v15; // ebx
  int *v16; // rax
  char *v17; // rax
  int *v18; // rax
  char *v19; // rax
  int *p_namelen; // r8
  RakNet::SystemAddress *p_name; // rdx
  int *v22; // rax
  int *v23; // rax
  int namelen; // [rsp+30h] [rbp-68h] BYREF
  RakNet::SystemAddress v25; // [rsp+40h] [rbp-58h] BYREF
  RakNet::SystemAddress name; // [rsp+60h] [rbp-38h] BYREF
  int v27; // [rsp+A0h] [rbp+8h] BYREF

  if ( DFLog::RakNetPktTrace != 0 && !raknetMetaDataEncrypted ) /*0x14118fe3d*/
  {
    v10 = *((_OWORD *)&srcAddress->address.addr4 + 1); /*0x14118fe54*/
    *(_OWORD *)&name.address.addr6.sin6_family = *(_OWORD *)&srcAddress->address.addr6.sin6_family; /*0x14118fe5f*/
    v11 = *(_OWORD *)&dstAddress->address.addr6.sin6_family; /*0x14118fe64*/
    *((_OWORD *)&name.address.addr4 + 1) = v10; /*0x14118fe6d*/
    v12 = *((_OWORD *)&dstAddress->address.addr4 + 1); /*0x14118fe72*/
    *(_OWORD *)&v25.address.addr6.sin6_family = v11; /*0x14118fe82*/
    *((_OWORD *)&v25.address.addr4 + 1) = v12; /*0x14118fe87*/
    RakNet::LogPkt(systemAddress: &v25, externalAddress: &name, data, length, direction: "Tx", isDrop: false); /*0x14118fe8c*/
  }
  if ( s == -1 ) /*0x14118fe95*/
    return -1; /*0x14118fe97*/
  while ( 1 )
  {
    v14 = dstAddress->address.addr6.sin6_family == 2
        ? sendto(s, buf: data, len: length, flags: 0, to: (const struct sockaddr *)dstAddress, tolen: 16)
        : sendto(s, buf: data, len: length, flags: 0, to: (const struct sockaddr *)dstAddress, tolen: 28);
    v15 = v14; /*0x14118fedf*/
    if ( v14 < 0 ) /*0x14118fee3*/
      break; /*0x14118fee3*/
    if ( v14 != 0 ) /*0x14118fee5*/
      goto LABEL_21; /*0x14118fee5*/
  }
  if ( DFLog::NetworkSocketSendError != 0 ) /*0x14118fef3*/
  {
    v16 = _errno(); /*0x14118fef5*/
    v17 = strerror(ErrorMessage: *v16); /*0x14118fefd*/
    FLog::FastLogFormatted( /*0x14118ff21*/
      level: DFLog::NetworkSocketSendError,
      message: "[DFLog::NetworkSocketSendError] sendto failed with code %i for char %i and length %i.errno %s",
      v15,
      *data,
      length,
      v17);
  }
  v18 = _errno(); /*0x14118ff26*/
  v19 = strerror(ErrorMessage: *v18); /*0x14118ff2e*/
  printf(_Format: "sendto failed with code %i for char %i and length %i.errno %s\n", v15, *data, length, v19); /*0x14118ff49*/
  if ( dstAddress->address.addr6.sin6_family == 2 ) /*0x14118ff55*/
  {
    v27 = 16; /*0x14118ff57*/
    p_namelen = &v27; /*0x14118ff62*/
    p_name = &v25; /*0x14118ff6a*/
  }
  else
  {
    namelen = 28; /*0x14118ff71*/
    p_namelen = &namelen; /*0x14118ff79*/
    p_name = &name; /*0x14118ff7e*/
  }
  if ( getsockname(s, name: (struct sockaddr *)p_name, namelen: p_namelen) != 0 ) /*0x14118ff8b*/
  {
    if ( DFLog::NetworkSocketSendError != 0 ) /*0x14118ff94*/
    {
      v22 = _errno(); /*0x14118ff96*/
      FLog::FastLogFormatted( /*0x14118ffad*/
        level: DFLog::NetworkSocketSendError,
        message: "[DFLog::NetworkSocketSendError] getsockname returned errno 0x%x",
        *v22);
    }
    v23 = _errno(); /*0x14118ffb2*/
    printf(_Format: "getsockname returned errno 0x%x\n", *v23); /*0x14118ffc1*/
  }
LABEL_21:
  if ( v15 != -1 ) /*0x14118ffd1*/
    return 0; /*0x14118ffd3*/
  result = WSAGetLastError(); /*0x14118ffd7*/
  if ( (result == 10051 || result == 10065) && DFFlag::RakNetDetectNetUnreachable.value ) /*0x14118fff2*/
    return 2; /*0x14118fff4*/
  return result; /*0x14118fff9*/
}

// Address: 0x141190010 | Name: ?SendToAfterDelay@SocketLayer@RakNet@@SAH_KPEAUDelayTransmitStruct@2@@Z
int __fastcall RakNet::SocketLayer::SendToAfterDelay(SOCKET s, RakNet::DelayTransmitStruct *delayTx)
{
  return RakNet::SocketLayer::SendTo( /*0x14119005d*/
           s,
           data: delayTx->data,
           length: delayTx->length,
           dstAddress: &delayTx->dstAddress,
           srcAddress: &delayTx->srcAddress,
           raknetMetaDataEncrypted: delayTx->raknetMetaDataEncrypted);
}

// Address: 0x141190070 | Name: ?SendToOrDelay@SocketLayer@RakNet@@SAHV?$shared_ptr@URakNetSocket@RakNet@@@std@@PEBDHAEBUSystemAddress@2@2_NPEAVRakPeer@2@PEAVReliabilityLayer@2@_K1J@Z
__int64 __fastcall RakNet::SocketLayer::SendToOrDelay(
        std::shared_ptr<RBX::File> *socket,
        const char *data,
        int length,
        const RakNet::SystemAddress *dstAddress,
        const RakNet::SystemAddress *srcAddress,
        bool raknetMetaDataEncrypted,
        RakNet::RakPeer *rakPeer,
        RakNet::ReliabilityLayer *reliabilityLayer,
        unsigned __int64 now,
        char *file,
        int line)
{
  size_t v12; // r15
  unsigned __int64 v15; // r12
  unsigned __int64 TimeUS; // rbp
  RakNet::DelayTransmitStruct *QueueTxPacket; // rdi
  std::_Ref_count_base *Rep; // rcx
  RakNet::RakNetSocket *Ptr; // rax
  std::_Ref_count_base *v20; // rdx
  volatile signed __int32 *v21; // rcx
  std::_Ref_count_base *v22; // rdi
  __int64 result; // rax
  unsigned int v24; // ebp
  std::_Ref_count_base *v25; // rdi

  __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000024*/
  v12 = length; /*0x141190091*/
  v15 = rakPeer->GetArtificialLatencyTx(this: rakPeer); /*0x1411900ae*/
  if ( v15 != 0 ) /*0x1411900b4*/
  {
    TimeUS = now; /*0x1411900ba*/
    if ( now == 0 ) /*0x1411900c5*/
      TimeUS = RakNet::GetTimeUS(isNetworkSynced: false); /*0x1411900ce*/
    QueueTxPacket = RakNet::RakPeer::AllocateQueueTxPacket(this: rakPeer); /*0x1411900d9*/
    Rep = socket->_Rep; /*0x1411900dc*/
    Ptr = nullptr; /*0x1411900e0*/
    v20 = nullptr; /*0x1411900e2*/
    if ( Rep != nullptr ) /*0x1411900e7*/
    {
      Ptr = (RakNet::RakNetSocket *)socket->_Ptr; /*0x1411900e9*/
      _InterlockedIncrement((volatile signed __int32 *)&Rep->_Weaks); /*0x1411900ec*/
      v20 = Rep; /*0x1411900f0*/
    }
    QueueTxPacket->socket._Ptr = Ptr; /*0x1411900f3*/
    v21 = (volatile signed __int32 *)QueueTxPacket->socket._Rep; /*0x1411900f6*/
    QueueTxPacket->socket._Rep = v20; /*0x1411900fa*/
    if ( v21 != nullptr && _InterlockedExchangeAdd(v21 + 3, 0xFFFFFFFF) == 1 ) /*0x141190112*/
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v21 + 8LL))(a1: v21); /*0x141190117*/
    memcpy_0(a1: QueueTxPacket->data, Src: data, Size: v12); /*0x141190129*/
    QueueTxPacket->length = v12; /*0x14119012e*/
    RakNet::SystemAddress::operator=(this: &QueueTxPacket->dstAddress, input: dstAddress); /*0x14119013f*/
    RakNet::SystemAddress::operator=(this: &QueueTxPacket->srcAddress, input: srcAddress); /*0x141190153*/
    QueueTxPacket->raknetMetaDataEncrypted = raknetMetaDataEncrypted; /*0x141190160*/
    QueueTxPacket->file = file; /*0x14119016e*/
    QueueTxPacket->line = line; /*0x14119017c*/
    QueueTxPacket->timeToSend = v15 + TimeUS; /*0x141190186*/
    QueueTxPacket->reliabilityLayer = reliabilityLayer; /*0x141190195*/
    RakNet::RakPeer::QueueTxPacketForDelay(this: rakPeer, txPacket: (RakNet::RakPeer::SocketQueryOutput *)QueueTxPacket); /*0x1411901a2*/
    if ( __eh34_unwind(0) ) /*0xf1c0000000000018*/
      goto unwind_state_0; /*0xf1c0000000000018*/
    __eh34_exit_wind_state(0, -1); /*0xf1c000000000001c*/
    v22 = socket->_Rep; /*0x1411901a8*/
    if ( v22 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v22->_Uses, 0xFFFFFFFF) == 1 ) /*0x1411901bb*/
    {
      v22->_Destroy(this: v22); /*0x1411901c3*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v22->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1411901cd*/
        v22->_Delete_this(this: v22); /*0x1411901d5*/
    }
    return 0; /*0x1411901d8*/
  }
  else
  {
    v24 = RakNet::SocketLayer::SendTo( /*0x141190221*/
            s: (SOCKET)socket->_Ptr->__vftable,
            data,
            length: v12,
            dstAddress,
            srcAddress,
            raknetMetaDataEncrypted);
    v25 = socket->_Rep; /*0x141190223*/
    if ( v25 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v25->_Uses, 0xFFFFFFFF) == 1 ) /*0x14119023b*/
    {
      v25->_Destroy(this: v25); /*0x141190243*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v25->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14119024d*/
        v25->_Delete_this(this: v25); /*0x141190255*/
    }
    result = v24; /*0x141190258*/
    if ( __eh34_unwind(0) ) /*0xf1c0000000000004*/
    {
unwind_state_0:
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: socket); /*0xf1c0000000000008*/
      __eh34_propagate_exception_into_caller(0, -1); /*0xf1c000000000000c*/
    }
    __eh34_exit_wind_state(0, -1); /*0xf1c0000000000010*/
  }
  return result; /*0x14119025a*/
}

// Address: 0x141190280 | Name: ?SetDoNotFragment@SocketLayer@RakNet@@SAX_KHH@Z
void __fastcall RakNet::SocketLayer::SetDoNotFragment(SOCKET listenSocket, int opt, int IPPROTO)
{
  int optval; // [rsp+48h] [rbp+10h] BYREF

  optval = opt; /*0x141190280*/
  setsockopt(s: listenSocket, level: IPPROTO, optname: 14, (const char *)&optval, optlen: 4); /*0x14119029e*/
}

// Address: 0x1411902b0 | Name: ?SetSocketOptions@SocketLayer@RakNet@@CAH_KG@Z
__int64 __fastcall RakNet::SocketLayer::SetSocketOptions(SOCKET listenSocket, unsigned __int16 socketFamily)
{
  DWORD LastError; // eax
  DWORD v5; // ebx
  std::string *Ptr; // rax
  char *v7; // rcx
  DWORD v8; // eax
  DWORD v9; // ebx
  std::string *v10; // rax
  char *v11; // rcx
  DWORD v12; // eax
  DWORD v13; // ebx
  std::string *v14; // rax
  char *v15; // rcx
  DWORD v16; // eax
  DWORD v17; // ebx
  std::string *v18; // rax
  char *v19; // rcx
  __int64 result; // rax
  int no; // [rsp+30h] [rbp-48h] BYREF
  RBX::Graphics::ProfilerAdorn::Item v22; // [rsp+38h] [rbp-40h] BYREF
  int sock_opt; // [rsp+90h] [rbp+18h] BYREF
  linger linger_opt; // [rsp+98h] [rbp+20h] BYREF

  sock_opt = 0x40000; /*0x1411902c4*/
  if ( setsockopt(s: listenSocket, level: 0xFFFF, optname: 4098, optval: (const char *)&sock_opt, optlen: 4) == -1
    && (LastError = GetLastError(), v5 = LastError, FLog::Network != 0) )
  {
    Ptr = RBX::systemErrorToString(result: &v22.text, err: LastError); /*0x141190308*/
    if ( Ptr->_Mypair._Myval2._Myres >= 0x10 ) /*0x141190313*/
      Ptr = (std::string *)Ptr->_Mypair._Myval2._Bx._Ptr; /*0x141190315*/
    __eh34_enter_wind_state(-1, 0); /*0xf1c000000000005c*/
    FLog::FastLogFormatted(
      level: FLog::Network,
      message: "[FLog::Network] setsockopt SO_RCVBUF failed : errno=%d, errString=%s",
      v5,
      Ptr->_Mypair._Myval2._Bx._Buf);
    if ( v22.text._Mypair._Myval2._Myres >= 0x10 ) /*0x14119033b*/
    {
      v7 = v22.text._Mypair._Myval2._Bx._Ptr; /*0x141190340*/
      if ( v22.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14119034f*/
      {
        v7 = *((char **)v22.text._Mypair._Myval2._Bx._Ptr - 1); /*0x141190355*/
        if ( (unsigned __int64)(v22.text._Mypair._Myval2._Bx._Ptr - v7 - 8) > 0x1F ) /*0x141190364*/
          _invalid_parameter_noinfo_noreturn(); /*0x141190366*/
      }
      operator delete(ptr: v7); /*0x14119036d*/
    }
  }
  else
  {
    __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000054*/
  }
  linger_opt = 0; /*0x141190374*/
  if ( setsockopt(s: listenSocket, level: 0xFFFF, optname: 128, optval: (const char *)&linger_opt, optlen: 4) == -1 ) /*0x1411903a2*/
    GetLastError(); /*0x1411903a4*/
  sock_opt = 0x4000; /*0x1411903aa*/
  if ( setsockopt(s: listenSocket, level: 0xFFFF, optname: 4097, optval: (const char *)&sock_opt, optlen: 4) == -1 )
  {
    v8 = GetLastError(); /*0x1411903e2*/
    v9 = v8; /*0x1411903e8*/
    if ( FLog::Network != 0 )
    {
      if ( __eh34_unwind(0) ) /*0xf1c0000000000048*/
      {
unwind_state_0:
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v22); /*0xf1c0000000000008*/
        __eh34_propagate_exception_into_caller(0, -1); /*0xf1c000000000000c*/
      }
      __eh34_exit_wind_state(0, -1); /*0xf1c000000000004c*/
      v10 = RBX::systemErrorToString(result: &v22.text, err: v8); /*0x1411903fa*/
      if ( v10->_Mypair._Myval2._Myres >= 0x10 ) /*0x141190405*/
        v10 = (std::string *)v10->_Mypair._Myval2._Bx._Ptr; /*0x141190407*/
      __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000040*/
      FLog::FastLogFormatted(
        level: FLog::Network,
        message: "[FLog::Network] setsockopt SO_SNDBUF failed : errno=%d, errString=%s",
        v9,
        v10->_Mypair._Myval2._Bx._Buf);
      if ( v22.text._Mypair._Myval2._Myres >= 0x10 ) /*0x14119042d*/
      {
        v11 = v22.text._Mypair._Myval2._Bx._Ptr; /*0x141190432*/
        if ( v22.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141190441*/
        {
          v11 = *((char **)v22.text._Mypair._Myval2._Bx._Ptr - 1); /*0x141190447*/
          if ( (unsigned __int64)(v22.text._Mypair._Myval2._Bx._Ptr - v11 - 8) > 0x1F ) /*0x141190456*/
            _invalid_parameter_noinfo_noreturn(); /*0x141190458*/
        }
        operator delete(ptr: v11); /*0x14119045f*/
      }
    }
  }
  if ( socketFamily == 23 )
  {
    no = 0; /*0x14119046e*/
    if ( setsockopt(s: listenSocket, level: 41, optname: 27, optval: (const char *)&no, optlen: 4) == -1 )
    {
      v12 = GetLastError(); /*0x14119049a*/
      v13 = v12; /*0x1411904a0*/
      if ( FLog::Network != 0 )
      {
        if ( __eh34_unwind(0) ) /*0xf1c0000000000034*/
          goto unwind_state_0; /*0xf1c0000000000034*/
        __eh34_exit_wind_state(0, -1); /*0xf1c0000000000038*/
        v14 = RBX::systemErrorToString(result: &v22.text, err: v12); /*0x1411904b2*/
        if ( v14->_Mypair._Myval2._Myres >= 0x10 ) /*0x1411904bd*/
          v14 = (std::string *)v14->_Mypair._Myval2._Bx._Ptr; /*0x1411904bf*/
        __eh34_enter_wind_state(-1, 0); /*0xf1c000000000002c*/
        FLog::FastLogFormatted(
          level: FLog::Network,
          message: "[FLog::Network] setsockopt IPV6_V6ONLY failed : errno=%d, errString=%s",
          v13,
          v14->_Mypair._Myval2._Bx._Buf);
        if ( v22.text._Mypair._Myval2._Myres >= 0x10 ) /*0x1411904e5*/
        {
          v15 = v22.text._Mypair._Myval2._Bx._Ptr; /*0x1411904ea*/
          if ( v22.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1411904f9*/
          {
            v15 = *((char **)v22.text._Mypair._Myval2._Bx._Ptr - 1); /*0x1411904ff*/
            if ( (unsigned __int64)(v22.text._Mypair._Myval2._Bx._Ptr - v15 - 8) > 0x1F ) /*0x14119050e*/
              _invalid_parameter_noinfo_noreturn(); /*0x141190510*/
          }
          operator delete(ptr: v15); /*0x141190517*/
        }
      }
    }
  }
  sock_opt = 1; /*0x14119051c*/
  if ( setsockopt(s: listenSocket, level: 0xFFFF, optname: 32, optval: (const char *)&sock_opt, optlen: 4) == -1 )
  {
    v16 = GetLastError(); /*0x141190554*/
    v17 = v16; /*0x14119055a*/
    if ( FLog::Network != 0 )
    {
      if ( __eh34_unwind(0) ) /*0xf1c0000000000020*/
        goto unwind_state_0; /*0xf1c0000000000020*/
      __eh34_exit_wind_state(0, -1); /*0xf1c0000000000024*/
      v18 = RBX::systemErrorToString(result: &v22.text, err: v16); /*0x14119056c*/
      if ( v18->_Mypair._Myval2._Myres >= 0x10 ) /*0x141190577*/
        v18 = (std::string *)v18->_Mypair._Myval2._Bx._Ptr; /*0x141190579*/
      __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000018*/
      FLog::FastLogFormatted(
        level: FLog::Network,
        message: "[FLog::Network] setsockopt SO_BROADCAST failed : errno=%d, errString=%s",
        v17,
        v18->_Mypair._Myval2._Bx._Buf);
      if ( v22.text._Mypair._Myval2._Myres >= 0x10 ) /*0x14119059f*/
      {
        v19 = v22.text._Mypair._Myval2._Bx._Ptr; /*0x1411905a4*/
        if ( v22.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1411905b3*/
        {
          v19 = *((char **)v22.text._Mypair._Myval2._Bx._Ptr - 1); /*0x1411905b9*/
          if ( (unsigned __int64)(v22.text._Mypair._Myval2._Bx._Ptr - v19 - 8) > 0x1F ) /*0x1411905c8*/
            _invalid_parameter_noinfo_noreturn(); /*0x1411905ca*/
        }
        operator delete(ptr: v19); /*0x1411905d1*/
      }
    }
  }
  result = 0; /*0x1411905d6*/
  if ( __eh34_unwind(0) ) /*0xf1c0000000000004*/
    goto unwind_state_0; /*0xf1c0000000000004*/
  __eh34_exit_wind_state(0, -1); /*0xf1c0000000000010*/
  return result; /*0x1411905d8*/
}

// END SocketLayer part 1/1, 11 functions
