// AbstractBitStream -- 2022 Studio + full PDB
// tier 3, 1 functions


// Address: 0x14100fc80 | Name: ??1AbstractBitStream@RakNet@@UEAA@XZ
void __fastcall RakNet::AbstractBitStream::~AbstractBitStream(RakNet::AbstractBitStream *this)
{
  this->__vftable = (RakNet::AbstractBitStream_vtbl *)RakNet::AbstractBitStream::`vftable'; /*0x14100fc87*/
}

// END AbstractBitStream part 1/1, 1 functions
