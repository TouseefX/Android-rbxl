// BitStream -- 2022 Studio + full PDB
// tier 3, 32 functions


// Address: 0x1410ae2d0 | Name: ?IsNetworkOrder@BitStream@RakNet@@SA_NXZ
_BOOL8 __fastcall RakNet::BitStream::IsNetworkOrder()
{
  _BOOL8 result; // rax

  if ( __TSS0__1__IsNetworkOrder_BitStream_RakNet__SA_NXZ_4HA <= *(_DWORD *)(*((_QWORD *)NtCurrentTeb()->Reserved1[11] /*0x1410ae2f5*/
                                                                             + (unsigned int)tls_index)
                                                                           + 260LL) )
    return `RakNet::BitStream::IsNetworkOrder'::`2'::r; /*0x1410ae2f5*/
  Init_thread_header(pOnce: &__TSS0__1__IsNetworkOrder_BitStream_RakNet__SA_NXZ_4HA); /*0x1410ae30a*/
  if ( __TSS0__1__IsNetworkOrder_BitStream_RakNet__SA_NXZ_4HA != -1 ) /*0x1410ae316*/
    return `RakNet::BitStream::IsNetworkOrder'::`2'::r; /*0x1410ae2f7*/
  __wind /*0xf1c000000000001c*/
  {
    `RakNet::BitStream::IsNetworkOrder'::`2'::r = RakNet::BitStream::IsNetworkOrderInternal(); /*0x1410ae31d*/
    Init_thread_footer(pOnce: &__TSS0__1__IsNetworkOrder_BitStream_RakNet__SA_NXZ_4HA); /*0x1410ae32a*/
    result = `RakNet::BitStream::IsNetworkOrder'::`2'::r; /*0x1410ae32f*/
  }
  __unwind
  {
    Init_thread_abort(pOnce: &__TSS0__1__IsNetworkOrder_BitStream_RakNet__SA_NXZ_4HA); /*0x1431ec567*/
  }
  return result; /*0x1410ae2fe*/
}

// Address: 0x1410bd800 | Name: ?GetNumberOfBytesUsed@BitStream@RakNet@@UEBAIXZ
__int64 __fastcall RakNet::BitStream::GetNumberOfBytesUsed(RakNet::BitStream *this)
{
  return (this->numberOfBitsUsed + 7) >> 3; /*0x1410bd809*/
}

// Address: 0x14118cbd0 | Name: ??0BitStream@RakNet@@QEAA@I@Z
RakNet::BitStream *__fastcall RakNet::BitStream::BitStream(
        RakNet::BitStream *this,
        unsigned int initialBytesToAllocate)
{
  unsigned int v3; // edi
  unsigned __int8 *stackData; // rax

  this->__vftable = (RakNet::BitStream_vtbl *)RakNet::BitStream::`vftable'; /*0x14118cbe9*/
  this->isJoinData = false; /*0x14118cbec*/
  this->numberOfBitsUsed = 0; /*0x14118cbf2*/
  this->readOffset = 0; /*0x14118cbf5*/
  if ( initialBytesToAllocate > 0x100 ) /*0x14118cbfe*/
  {
    __wind /*0xf1c0000000000010*/
    {
      v3 = 8 * initialBytesToAllocate; /*0x14118cc0b*/
      stackData = (unsigned __int8 *)RBX::Memory::allocate(size: initialBytesToAllocate); /*0x14118cc14*/
    }
    __unwind
    {
      RakNet::AbstractBitStream::~AbstractBitStream(this); /*0xf1c0000000000008*/
    }
  }
  else
  {
    v3 = 2048; /*0x14118cc00*/
    stackData = this->stackData; /*0x14118cc05*/
  }
  this->data = stackData; /*0x14118cc19*/
  this->numberOfBitsAllocated = v3; /*0x14118cc1d*/
  this->copyData = true; /*0x14118cc20*/
  return this; /*0x14118cc27*/
}

// Address: 0x14118cc40 | Name: ??0BitStream@RakNet@@QEAA@PEAEI_N@Z
RakNet::BitStream *__fastcall RakNet::BitStream::BitStream(
        RakNet::BitStream *this,
        unsigned __int8 *_data,
        unsigned int lengthInBytes,
        bool _copyData)
{
  size_t v6; // rdi
  unsigned __int8 *stackData; // rax
  RakNet::BitStream *result; // rax

  __wind /*0xf1c0000000000010*/
  {
    this->__vftable = (RakNet::BitStream_vtbl *)RakNet::BitStream::`vftable'; /*0x14118cc61*/
    this->isJoinData = false; /*0x14118cc64*/
    this->numberOfBitsUsed = 8 * lengthInBytes; /*0x14118cc70*/
    this->readOffset = 0; /*0x14118cc75*/
    this->copyData = _copyData; /*0x14118cc78*/
    this->numberOfBitsAllocated = 8 * lengthInBytes; /*0x14118cc7c*/
    if ( _copyData ) /*0x14118cc82*/
    {
      if ( lengthInBytes != 0 ) /*0x14118cc87*/
      {
        v6 = lengthInBytes; /*0x14118cc89*/
        if ( lengthInBytes >= 0x100 ) /*0x14118cc93*/
        {
          stackData = (unsigned __int8 *)RBX::Memory::allocate(size: lengthInBytes); /*0x14118cca5*/
        }
        else
        {
          this->numberOfBitsAllocated = 2048; /*0x14118cc95*/
          stackData = this->stackData; /*0x14118cc9c*/
        }
        this->data = stackData; /*0x14118ccaa*/
        memcpy_0(a1: stackData, Src: _data, Size: v6); /*0x14118ccb7*/
      }
      else
      {
        this->data = nullptr; /*0x14118ccbe*/
      }
    }
    else
    {
      this->data = _data; /*0x14118ccc4*/
    }
    result = this; /*0x14118ccc8*/
  }
  __unwind
  {
    RakNet::AbstractBitStream::~AbstractBitStream(this); /*0xf1c0000000000008*/
  }
  return result; /*0x14118cccb*/
}

// Address: 0x14118cce0 | Name: ??0BitStream@RakNet@@QEAA@XZ
RakNet::BitStream *__fastcall RakNet::BitStream::BitStream(RakNet::BitStream *this)
{
  this->isJoinData = false; /*0x14118cce7*/
  this->__vftable = (RakNet::BitStream_vtbl *)RakNet::BitStream::`vftable'; /*0x14118cceb*/
  this->numberOfBitsUsed = 0; /*0x14118ccf0*/
  this->data = this->stackData; /*0x14118ccf7*/
  *(_QWORD *)&this->numberOfBitsAllocated = 2048; /*0x14118ccfe*/
  this->copyData = true; /*0x14118cd06*/
  return this; /*0x14118cd0a*/
}

// Address: 0x14118cd10 | Name: ??1BitStream@RakNet@@UEAA@XZ
void __fastcall RakNet::BitStream::~BitStream(RakNet::BitStream *this)
{
  this->__vftable = (RakNet::BitStream_vtbl *)RakNet::BitStream::`vftable'; /*0x14118cd20*/
  if ( this->copyData && this->numberOfBitsAllocated > 0x800 ) /*0x14118cd30*/
  {
    operator delete(ptr: this->data); /*0x14118cd36*/
    this->__vftable = (RakNet::BitStream_vtbl *)RakNet::AbstractBitStream::`vftable'; /*0x14118cd42*/
  }
  else
  {
    this->__vftable = (RakNet::BitStream_vtbl *)RakNet::AbstractBitStream::`vftable'; /*0x14118cd52*/
  }
}

// Address: 0x14118cdc0 | Name: ?AddBitsAndReallocate@BitStream@RakNet@@QEAAXI@Z
void __fastcall RakNet::BitStream::AddBitsAndReallocate(
        RakNet::BitStream *this,
        const unsigned int numberOfBitsToWrite)
{
  unsigned int numberOfBitsUsed; // r9d
  unsigned int v4; // ebx
  int v5; // ecx
  RakNet::BitStream *data; // rcx
  unsigned int v7; // eax
  unsigned __int8 *v8; // rax
  unsigned __int64 v9; // r8

  numberOfBitsUsed = this->numberOfBitsUsed; /*0x14118cdca*/
  v4 = numberOfBitsUsed + numberOfBitsToWrite; /*0x14118cdd1*/
  if ( numberOfBitsUsed + numberOfBitsToWrite != 0 /*0x14118cdf1*/
    && ((this->numberOfBitsAllocated - 1) & 0xFFFFFFF8) < ((v4 - 1) & 0xFFFFFFF8) )
  {
    v5 = 2 * v4; /*0x14118cdf3*/
    v4 += 0x100000; /*0x14118cdfb*/
    if ( v5 - numberOfBitsUsed - numberOfBitsToWrite <= 0x100000 ) /*0x14118ce11*/
      v4 = v5; /*0x14118ce11*/
    data = (RakNet::BitStream *)this->data; /*0x14118ce14*/
    v7 = (v4 + 7) >> 3; /*0x14118ce1b*/
    if ( data == (RakNet::BitStream *)this->stackData ) /*0x14118ce21*/
    {
      if ( v7 > 0x100 ) /*0x14118ce28*/
      {
        v8 = (unsigned __int8 *)RBX::Memory::allocate(size: v7); /*0x14118ce2c*/
        v9 = this->numberOfBitsAllocated + 7; /*0x14118ce38*/
        this->data = v8; /*0x14118ce3c*/
        memcpy_0(a1: v8, Src: this->stackData, Size: v9 >> 3); /*0x14118ce47*/
      }
    }
    else
    {
      this->data = (unsigned __int8 *)RBX::Memory::reallocate(ptr: data, size: v7); /*0x14118ce55*/
    }
  }
  if ( v4 > this->numberOfBitsAllocated ) /*0x14118ce61*/
    this->numberOfBitsAllocated = v4; /*0x14118ce63*/
}

// Address: 0x14118ce80 | Name: ?AssertCopyData@BitStream@RakNet@@QEAAXXZ
void __fastcall RakNet::BitStream::AssertCopyData(RakNet::BitStream *this)
{
  unsigned int numberOfBitsAllocated; // eax
  void *v3; // rbx

  if ( !this->copyData ) /*0x14118ce8d*/
  {
    numberOfBitsAllocated = this->numberOfBitsAllocated; /*0x14118ce8f*/
    this->copyData = true; /*0x14118ce92*/
    if ( numberOfBitsAllocated != 0 ) /*0x14118ce98*/
    {
      v3 = RBX::Memory::allocate(size: (unsigned __int64)(numberOfBitsAllocated + 7) >> 3); /*0x14118cebe*/
      memcpy_0(a1: v3, Src: this->data, Size: (unsigned __int64)(this->numberOfBitsAllocated + 7) >> 3); /*0x14118cec1*/
      this->data = (unsigned __int8 *)v3; /*0x14118cec6*/
    }
    else
    {
      this->data = nullptr; /*0x14118ced5*/
    }
  }
}

// Address: 0x14118cef0 | Name: ?IgnoreBits@BitStream@RakNet@@QEAAXI@Z
void __fastcall RakNet::BitStream::IgnoreBits(RakNet::BitStream *this, const unsigned int numberOfBits)
{
  this->readOffset += numberOfBits; /*0x14118cef0*/
}

// Address: 0x14118cf00 | Name: ?IgnoreBytes@BitStream@RakNet@@QEAAXI@Z
void __fastcall RakNet::BitStream::IgnoreBytes(RakNet::BitStream *this, const unsigned int numberOfBytes)
{
  this->readOffset += 8 * numberOfBytes; /*0x14118cf07*/
}

// Address: 0x14118cf10 | Name: ?IsNetworkOrderInternal@BitStream@RakNet@@SA_NXZ
_BOOL8 __fastcall RakNet::BitStream::IsNetworkOrderInternal()
{
  if ( _TSS0_584 > *(_DWORD *)(*((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index) + 260LL) ) /*0x14118cf35*/
  {
    Init_thread_header(pOnce: &_TSS0_584); /*0x14118cf4a*/
    if ( _TSS0_584 == -1 ) /*0x14118cf56*/
    {
      isNetworkOrder = htonl(hostlong: 0x3039u) == 12345; /*0x14118cf6f*/
      Init_thread_footer(pOnce: &_TSS0_584); /*0x14118cf76*/
    }
  }
  return isNetworkOrder; /*0x14118cf3e*/
}

// Address: 0x14118cf80 | Name: ?PadWithZeroToByteLength@BitStream@RakNet@@QEAAXI@Z
void __fastcall RakNet::BitStream::PadWithZeroToByteLength(RakNet::BitStream *this, unsigned int bytes)
{
  RakNet::BitStream_vtbl *v4; // rax
  unsigned int v5; // edi

  if ( this->GetNumberOfBytesUsed(this) < bytes ) /*0x14118cf97*/
  {
    v4 = this->__vftable; /*0x14118cfaa*/
    this->numberOfBitsUsed = this->numberOfBitsUsed - (((unsigned __int8)this->numberOfBitsUsed - 1) & 7) + 7; /*0x14118cfb1*/
    v5 = bytes - ((__int64 (__fastcall *)(RakNet::BitStream *))v4->GetNumberOfBytesUsed)(a1: this); /*0x14118cfb8*/
    RakNet::BitStream::AddBitsAndReallocate(this, numberOfBitsToWrite: 8 * v5); /*0x14118cfc4*/
    memset_0(a1: &this->data[(unsigned __int64)(this->numberOfBitsUsed + 7) >> 3], Val: 0, Size: v5); /*0x14118cfdc*/
    this->numberOfBitsUsed += 8 * v5; /*0x14118cfe8*/
  }
}

// Address: 0x14118d000 | Name: ?Read@BitStream@RakNet@@QEAA_NPEADI@Z
bool __fastcall RakNet::BitStream::Read(RakNet::BitStream *this, char *outByteArray, const unsigned int numberOfBytes)
{
  unsigned int v4; // edi
  unsigned __int64 readOffset; // rcx

  v4 = 8 * numberOfBytes; /*0x14118d00d*/
  readOffset = this->readOffset; /*0x14118d015*/
  if ( (readOffset & 7) != 0 ) /*0x14118d01e*/
    return RakNet::BitStream::ReadBits( /*0x14118d06e*/
             this,
             inOutByteArray: (unsigned __int8 *)outByteArray,
             numberOfBitsToRead: v4,
             alignBitsToRight: true);
  if ( v4 + (unsigned int)readOffset > this->numberOfBitsUsed ) /*0x14118d026*/
    return false; /*0x14118d028*/
  memcpy_0(a1: outByteArray, Src: &this->data[readOffset >> 3], Size: numberOfBytes); /*0x14118d046*/
  this->readOffset += v4; /*0x14118d04b*/
  return true; /*0x14118d02a*/
}

// Address: 0x14118d080 | Name: ?ReadAlignedBytes@BitStream@RakNet@@QEAA_NPEAEI@Z
char __fastcall RakNet::BitStream::ReadAlignedBytes(
        RakNet::BitStream *this,
        unsigned __int8 *inOutByteArray,
        const unsigned int numberOfBytesToRead)
{
  unsigned int v4; // edi
  unsigned int v5; // r9d

  if ( numberOfBytesToRead == 0 ) /*0x14118d093*/
    return 0; /*0x14118d093*/
  v4 = 8 * numberOfBytesToRead; /*0x14118d099*/
  v5 = this->readOffset - (((unsigned __int8)this->readOffset - 1) & 7) + 7; /*0x14118d0ab*/
  this->readOffset = v5; /*0x14118d0af*/
  if ( v5 + 8 * numberOfBytesToRead > this->numberOfBitsUsed ) /*0x14118d0ba*/
    return 0; /*0x14118d0e7*/
  memcpy_0(a1: inOutByteArray, Src: &this->data[(unsigned __int64)v5 >> 3], Size: numberOfBytesToRead); /*0x14118d0cd*/
  this->readOffset += v4; /*0x14118d0d2*/
  return 1; /*0x14118d0d7*/
}

// Address: 0x14118d0f0 | Name: ?ReadAlignedVar16@BitStream@RakNet@@QEAA_NPEAD@Z
char __fastcall RakNet::BitStream::ReadAlignedVar16(RakNet::BitStream *this, char *inOutByteArray)
{
  bool IsNetworkOrder; // al
  unsigned __int64 readOffset; // rcx
  unsigned __int8 *data; // rdx
  unsigned __int64 v8; // rcx

  if ( this->readOffset + 16 > this->numberOfBitsUsed ) /*0x14118d109*/
    return 0; /*0x14118d10b*/
  IsNetworkOrder = RakNet::BitStream::IsNetworkOrder(); /*0x14118d118*/
  readOffset = this->readOffset; /*0x14118d11d*/
  data = this->data; /*0x14118d120*/
  if ( IsNetworkOrder ) /*0x14118d126*/
  {
    *inOutByteArray = data[readOffset >> 3]; /*0x14118d147*/
    v8 = (this->readOffset >> 3) + 1; /*0x14118d14f*/
  }
  else
  {
    *inOutByteArray = data[((unsigned int)readOffset >> 3) + 1]; /*0x14118d131*/
    v8 = (unsigned __int64)this->readOffset >> 3; /*0x14118d136*/
  }
  inOutByteArray[1] = this->data[v8]; /*0x14118d15b*/
  this->readOffset += 16; /*0x14118d15e*/
  return 1; /*0x14118d10d*/
}

// Address: 0x14118d170 | Name: ?ReadAlignedVar32@BitStream@RakNet@@QEAA_NPEAD@Z
char __fastcall RakNet::BitStream::ReadAlignedVar32(RakNet::BitStream *this, char *inOutByteArray)
{
  bool IsNetworkOrder; // al
  unsigned __int64 readOffset; // rcx
  unsigned __int8 *data; // rdx
  unsigned __int64 v8; // rcx

  if ( this->readOffset + 32 > this->numberOfBitsUsed ) /*0x14118d189*/
    return 0; /*0x14118d18b*/
  IsNetworkOrder = RakNet::BitStream::IsNetworkOrder(); /*0x14118d198*/
  readOffset = this->readOffset; /*0x14118d19d*/
  data = this->data; /*0x14118d1a0*/
  if ( IsNetworkOrder ) /*0x14118d1a6*/
  {
    *inOutByteArray = data[readOffset >> 3]; /*0x14118d1ef*/
    inOutByteArray[1] = this->data[(this->readOffset >> 3) + 1]; /*0x14118d201*/
    inOutByteArray[2] = this->data[(this->readOffset >> 3) + 2]; /*0x14118d215*/
    v8 = (this->readOffset >> 3) + 3; /*0x14118d21e*/
  }
  else
  {
    *inOutByteArray = data[((unsigned int)readOffset >> 3) + 3]; /*0x14118d1b2*/
    inOutByteArray[1] = this->data[(this->readOffset >> 3) + 2]; /*0x14118d1c5*/
    inOutByteArray[2] = this->data[(this->readOffset >> 3) + 1]; /*0x14118d1d8*/
    v8 = (unsigned __int64)this->readOffset >> 3; /*0x14118d1de*/
  }
  inOutByteArray[3] = this->data[v8]; /*0x14118d22b*/
  this->readOffset += 32; /*0x14118d22e*/
  return 1; /*0x14118d18d*/
}

// Address: 0x14118d240 | Name: ?ReadAlignedVar8@BitStream@RakNet@@QEAA_NPEAD@Z
char __fastcall RakNet::BitStream::ReadAlignedVar8(RakNet::BitStream *this, char *inOutByteArray)
{
  unsigned __int64 readOffset; // rcx

  readOffset = this->readOffset; /*0x14118d243*/
  if ( (unsigned int)(readOffset + 8) > this->numberOfBitsUsed ) /*0x14118d24d*/
    return 0; /*0x14118d24f*/
  *inOutByteArray = this->data[readOffset >> 3]; /*0x14118d260*/
  this->readOffset += 8; /*0x14118d262*/
  return 1; /*0x14118d251*/
}

// Address: 0x14118d270 | Name: ?ReadBits@BitStream@RakNet@@QEAA_NPEAEI_N@Z
char __fastcall RakNet::BitStream::ReadBits(
        RakNet::BitStream *this,
        unsigned __int8 *inOutByteArray,
        unsigned int numberOfBitsToRead,
        const bool alignBitsToRight)
{
  unsigned int v4; // edi
  unsigned int readOffset; // ecx
  int v9; // ebp
  int v11; // esi
  unsigned int v12; // ecx
  unsigned int v13; // r10d
  unsigned __int8 *v14; // r9
  unsigned __int8 v15; // r8
  unsigned __int8 v16; // al

  v4 = numberOfBitsToRead; /*0x14118d27e*/
  if ( numberOfBitsToRead == 0 ) /*0x14118d28e*/
    return 0; /*0x14118d28e*/
  readOffset = this->readOffset; /*0x14118d294*/
  if ( readOffset + numberOfBitsToRead > this->numberOfBitsUsed ) /*0x14118d29d*/
    return 0; /*0x14118d3b0*/
  v9 = readOffset & 7; /*0x14118d2aa*/
  if ( (readOffset & 7) != 0 || (numberOfBitsToRead & 7) != 0 ) /*0x14118d2b3*/
  {
    v11 = 0; /*0x14118d2f9*/
    memset_0(a1: inOutByteArray, Val: 0, Size: (unsigned __int64)(numberOfBitsToRead + 7) >> 3); /*0x14118d2fb*/
    v12 = this->readOffset; /*0x14118d300*/
    v13 = 8 - v9; /*0x14118d309*/
    while ( 1 ) /*0x14118d31f*/
    {
      v14 = &inOutByteArray[v11]; /*0x14118d31f*/
      v15 = *v14 | (this->data[(unsigned __int64)v12 >> 3] << v9); /*0x14118d32a*/
      *v14 = v15; /*0x14118d32d*/
      v16 = v15; /*0x14118d330*/
      if ( v9 != 0 && v4 > v13 ) /*0x14118d33b*/
      {
        v16 = v15 | (this->data[((unsigned __int64)this->readOffset >> 3) + 1] >> v13); /*0x14118d353*/
        *v14 = v16; /*0x14118d356*/
      }
      if ( v4 < 8 ) /*0x14118d35f*/
        break; /*0x14118d35f*/
      this->readOffset += 8; /*0x14118d361*/
      v4 -= 8; /*0x14118d365*/
      v12 = this->readOffset; /*0x14118d367*/
      ++v11; /*0x14118d36a*/
      if ( v4 == 0 ) /*0x14118d36e*/
        return 1; /*0x14118d377*/
    }
    if ( alignBitsToRight ) /*0x14118d383*/
      *v14 = v16 >> (8 - v4); /*0x14118d389*/
    this->readOffset += v4; /*0x14118d38c*/
    return 1; /*0x14118d38f*/
  }
  else
  {
    memcpy_0( /*0x14118d2c9*/
      a1: inOutByteArray,
      Src: &this->data[(unsigned __int64)readOffset >> 3],
      Size: (unsigned __int64)numberOfBitsToRead >> 3);
    this->readOffset += v4; /*0x14118d2ce*/
    return 1; /*0x14118d2d1*/
  }
}

// Address: 0x14118d3c0 | Name: ?Reset@BitStream@RakNet@@QEAAXXZ
void __fastcall RakNet::BitStream::Reset(RakNet::BitStream *this)
{
  this->numberOfBitsUsed = 0; /*0x14118d3c2*/
  this->readOffset = 0; /*0x14118d3c5*/
  this->isJoinData = false; /*0x14118d3c8*/
}

// Address: 0x14118d3d0 | Name: ?ResetReadPointer@BitStream@RakNet@@QEAAXXZ
void __fastcall RakNet::BitStream::ResetReadPointer(RakNet::BitStream *this)
{
  this->readOffset = 0; /*0x14118d3d0*/
}

// Address: 0x14118d3e0 | Name: ?ResetWritePointer@BitStream@RakNet@@QEAAXXZ
void __fastcall RakNet::BitStream::ResetWritePointer(RakNet::BitStream *this)
{
  this->numberOfBitsUsed = 0; /*0x14118d3e0*/
}

// Address: 0x14118d3f0 | Name: ?SetWriteOffset@BitStream@RakNet@@QEAAXI_N@Z
void __fastcall RakNet::BitStream::SetWriteOffset(
        RakNet::BitStream *this,
        unsigned int offset,
        bool eraseDataToCurrentOffset)
{
  unsigned int numberOfBitsUsed; // r8d
  unsigned int v6; // esi
  __int64 v7; // r10
  char v8; // cl
  __int64 v9; // r8
  size_t v10; // r8
  int v11; // r11d

  if ( eraseDataToCurrentOffset && (numberOfBitsUsed = this->numberOfBitsUsed, offset < numberOfBitsUsed) ) /*0x14118d40f*/
  {
    v6 = this->numberOfBitsUsed & 7; /*0x14118d422*/
    v7 = offset >> 3; /*0x14118d425*/
    v8 = offset & 7; /*0x14118d429*/
    v9 = numberOfBitsUsed >> 3; /*0x14118d42c*/
    if ( (_DWORD)v9 == (_DWORD)v7 ) /*0x14118d433*/
    {
      v11 = 65280 >> v8; /*0x14118d490*/
      if ( v6 != 0 ) /*0x14118d495*/
        LOBYTE(v11) = (255 >> v6) | v11; /*0x14118d4a2*/
      this->data[v7] &= v11; /*0x14118d4ae*/
      this->numberOfBitsUsed = offset; /*0x14118d4b2*/
    }
    else
    {
      if ( (offset & 7) != 0 ) /*0x14118d437*/
      {
        this->data[v7] &= 65280 >> v8; /*0x14118d446*/
        LODWORD(v7) = v7 + 1; /*0x14118d44a*/
      }
      if ( v6 != 0 ) /*0x14118d44f*/
        this->data[v9] &= 255 >> v6; /*0x14118d460*/
      v10 = (unsigned int)(v9 - v7); /*0x14118d464*/
      if ( (_DWORD)v10 != 0 ) /*0x14118d467*/
        memset_0(a1: &this->data[(unsigned int)v7], Val: 0, Size: v10); /*0x14118d472*/
      this->numberOfBitsUsed = offset; /*0x14118d47c*/
    }
  }
  else
  {
    this->numberOfBitsUsed = offset; /*0x14118d4c5*/
  }
}

// Address: 0x14118d4d0 | Name: ?Write0@BitStream@RakNet@@QEAAXXZ
void __fastcall RakNet::BitStream::Write0(RakNet::BitStream *this)
{
  unsigned int numberOfBitsUsed; // eax

  RakNet::BitStream::AddBitsAndReallocate(this, numberOfBitsToWrite: 1u); /*0x14118d4de*/
  numberOfBitsUsed = this->numberOfBitsUsed; /*0x14118d4e3*/
  if ( (numberOfBitsUsed & 7) != 0 ) /*0x14118d4e8*/
  {
    this->numberOfBitsUsed = numberOfBitsUsed + 1; /*0x14118d503*/
  }
  else
  {
    this->data[(unsigned __int64)numberOfBitsUsed >> 3] = 0; /*0x14118d4f4*/
    ++this->numberOfBitsUsed; /*0x14118d4f8*/
  }
}

// Address: 0x14118d510 | Name: ?Write1@BitStream@RakNet@@QEAAXXZ
void __fastcall RakNet::BitStream::Write1(RakNet::BitStream *this)
{
  unsigned __int8 *data; // r9
  unsigned __int64 v3; // rdx
  unsigned __int8 *v4; // r8
  unsigned int v5; // ecx

  RakNet::BitStream::AddBitsAndReallocate(this, numberOfBitsToWrite: 1u); /*0x14118d51e*/
  data = this->data; /*0x14118d526*/
  v3 = (unsigned __int64)this->numberOfBitsUsed >> 3; /*0x14118d52c*/
  v4 = &data[v3]; /*0x14118d530*/
  v5 = this->numberOfBitsUsed & 7; /*0x14118d534*/
  if ( v5 != 0 ) /*0x14118d537*/
    data[v3] = *v4 | (128 >> v5); /*0x14118d550*/
  else
    *v4 = 0x80; /*0x14118d539*/
  ++this->numberOfBitsUsed; /*0x14118d53d*/
}

// Address: 0x14118d560 | Name: ?Write@BitStream@RakNet@@QEAAXAEAV12@@Z
void __fastcall RakNet::BitStream::Write(RakNet::BitStream *this, RakNet::BitStream *bitStream)
{
  RakNet::BitStream::Write(this, bitStream, numberOfBits: bitStream->numberOfBitsUsed - bitStream->readOffset); /*0x14118d568*/
}

// Address: 0x14118d570 | Name: ?Write@BitStream@RakNet@@QEAAXPEAV12@I@Z
void __fastcall RakNet::BitStream::Write(
        RakNet::BitStream *this,
        RakNet::BitStream *bitStream,
        unsigned int numberOfBits)
{
  unsigned int v4; // ebp
  unsigned int readOffset; // eax
  __int64 v7; // rsi
  unsigned int v8; // edi
  unsigned __int8 *v9; // rax
  unsigned int v10; // ecx
  unsigned __int64 numberOfBitsUsed; // r9
  int v12; // r8d
  unsigned int v13; // r10d

  v4 = numberOfBits; /*0x14118d583*/
  RakNet::BitStream::AddBitsAndReallocate(this, numberOfBitsToWrite: numberOfBits); /*0x14118d58c*/
  readOffset = bitStream->readOffset; /*0x14118d591*/
  if ( (readOffset & 7) == 0 && (this->numberOfBitsUsed & 7) == 0 ) /*0x14118d59d*/
  {
    v7 = readOffset >> 3; /*0x14118d5aa*/
    v8 = v4 >> 3; /*0x14118d5b6*/
    v9 = bitStream->GetData(this: bitStream); /*0x14118d5b9*/
    memcpy_0(a1: &this->data[(unsigned __int64)this->numberOfBitsUsed >> 3], Src: &v9[v7], Size: v4 >> 3); /*0x14118d5ce*/
    v4 -= 8 * (v4 >> 3); /*0x14118d5e2*/
    bitStream->readOffset = 8 * v8 + 8 * v7; /*0x14118d5e9*/
    this->numberOfBitsUsed += 8 * v8; /*0x14118d5ed*/
  }
  for ( ; v4 != 0; ++this->numberOfBitsUsed )
  {
    v10 = bitStream->readOffset; /*0x14118d600*/
    --v4; /*0x14118d604*/
    if ( v10 + 1 > bitStream->numberOfBitsUsed ) /*0x14118d60d*/
      break; /*0x14118d60d*/
    numberOfBitsUsed = this->numberOfBitsUsed; /*0x14118d615*/
    v12 = (128 >> (v10 & 7)) & bitStream->data[(unsigned __int64)v10 >> 3]; /*0x14118d62f*/
    v13 = this->numberOfBitsUsed & 7; /*0x14118d632*/
    if ( v13 != 0 )
    {
      if ( v12 != 0 ) /*0x14118d653*/
        this->data[numberOfBitsUsed >> 3] |= 128 >> v13; /*0x14118d66a*/
    }
    else
    {
      this->data[(unsigned __int64)(unsigned int)numberOfBitsUsed >> 3] = v12 != 0 ? 0x80 : 0;
    }
    ++bitStream->readOffset; /*0x14118d66d*/
  }
}

// Address: 0x14118d690 | Name: ?Write@BitStream@RakNet@@QEAAXPEBDI@Z
void __fastcall RakNet::BitStream::Write(
        RakNet::BitStream *this,
        const char *inputByteArray,
        const unsigned int numberOfBytes)
{
  if ( numberOfBytes != 0 ) /*0x14118d693*/
  {
    if ( (this->numberOfBitsUsed & 7) != 0 ) /*0x14118d6b1*/
    {
      RakNet::BitStream::WriteBits( /*0x14118d6fd*/
        this,
        inByteArray: (const unsigned __int8 *)inputByteArray,
        numberOfBitsToWrite: 8 * numberOfBytes,
        rightAlignedBits: true);
    }
    else
    {
      RakNet::BitStream::AddBitsAndReallocate(this, numberOfBitsToWrite: 8 * numberOfBytes); /*0x14118d6ba*/
      memcpy_0( /*0x14118d6d3*/
        a1: &this->data[(unsigned __int64)(this->numberOfBitsUsed + 7) >> 3],
        Src: inputByteArray,
        Size: numberOfBytes);
      this->numberOfBitsUsed += 8 * numberOfBytes; /*0x14118d6df*/
    }
  }
}

// Address: 0x14118d720 | Name: ?WriteAlignedBytes@BitStream@RakNet@@QEAAXPEBEI@Z
void __fastcall RakNet::BitStream::WriteAlignedBytes(
        RakNet::BitStream *this,
        const unsigned __int8 *inByteArray,
        const unsigned int numberOfBytesToWrite)
{
  unsigned int v6; // r9d

  v6 = this->numberOfBitsUsed - (((unsigned __int8)this->numberOfBitsUsed - 1) & 7) + 7; /*0x14118d746*/
  this->numberOfBitsUsed = v6; /*0x14118d74a*/
  if ( numberOfBytesToWrite != 0 ) /*0x14118d751*/
  {
    if ( (v6 & 7) != 0 ) /*0x14118d757*/
    {
      RakNet::BitStream::WriteBits( /*0x14118d7a3*/
        this,
        inByteArray,
        numberOfBitsToWrite: 8 * numberOfBytesToWrite,
        rightAlignedBits: true);
    }
    else
    {
      RakNet::BitStream::AddBitsAndReallocate(this, numberOfBitsToWrite: 8 * numberOfBytesToWrite); /*0x14118d760*/
      memcpy_0( /*0x14118d779*/
        a1: &this->data[(unsigned __int64)(this->numberOfBitsUsed + 7) >> 3],
        Src: inByteArray,
        Size: numberOfBytesToWrite);
      this->numberOfBitsUsed += 8 * numberOfBytesToWrite; /*0x14118d785*/
    }
  }
}

// Address: 0x14118d7c0 | Name: ?WriteAlignedVar16@BitStream@RakNet@@QEAAXPEBD@Z
void __fastcall RakNet::BitStream::WriteAlignedVar16(RakNet::BitStream *this, const char *inByteArray)
{
  bool IsNetworkOrder; // al
  unsigned __int8 *data; // rdx
  unsigned __int64 v6; // rcx
  unsigned __int8 v7; // al

  RakNet::BitStream::AddBitsAndReallocate(this, numberOfBitsToWrite: 0x10u); /*0x14118d7d5*/
  IsNetworkOrder = RakNet::BitStream::IsNetworkOrder(); /*0x14118d7da*/
  data = this->data; /*0x14118d7e2*/
  v6 = (unsigned __int64)this->numberOfBitsUsed >> 3; /*0x14118d7e6*/
  if ( IsNetworkOrder ) /*0x14118d7ec*/
  {
    data[v6] = *inByteArray; /*0x14118d7fd*/
    v7 = inByteArray[1]; /*0x14118d800*/
  }
  else
  {
    data[v6] = inByteArray[1]; /*0x14118d7f2*/
    v7 = *inByteArray; /*0x14118d7f5*/
  }
  this->data[(this->numberOfBitsUsed >> 3) + 1] = v7; /*0x14118d810*/
  this->numberOfBitsUsed += 16; /*0x14118d813*/
}

// Address: 0x14118d830 | Name: ?WriteAlignedVar32@BitStream@RakNet@@QEAAXPEBD@Z
void __fastcall RakNet::BitStream::WriteAlignedVar32(RakNet::BitStream *this, const char *inByteArray)
{
  bool IsNetworkOrder; // al
  unsigned __int8 *data; // rdx
  unsigned __int64 v6; // rcx
  unsigned __int8 v7; // al

  RakNet::BitStream::AddBitsAndReallocate(this, numberOfBitsToWrite: 0x20u); /*0x14118d845*/
  IsNetworkOrder = RakNet::BitStream::IsNetworkOrder(); /*0x14118d84a*/
  data = this->data; /*0x14118d852*/
  v6 = (unsigned __int64)this->numberOfBitsUsed >> 3; /*0x14118d856*/
  if ( IsNetworkOrder ) /*0x14118d85c*/
  {
    data[v6] = *inByteArray; /*0x14118d894*/
    this->data[(this->numberOfBitsUsed >> 3) + 1] = inByteArray[1]; /*0x14118d8a7*/
    this->data[(this->numberOfBitsUsed >> 3) + 2] = inByteArray[2]; /*0x14118d8bb*/
    v7 = inByteArray[3]; /*0x14118d8be*/
  }
  else
  {
    data[v6] = inByteArray[3]; /*0x14118d862*/
    this->data[(this->numberOfBitsUsed >> 3) + 1] = inByteArray[2]; /*0x14118d875*/
    this->data[(this->numberOfBitsUsed >> 3) + 2] = inByteArray[1]; /*0x14118d889*/
    v7 = *inByteArray; /*0x14118d88c*/
  }
  this->data[(this->numberOfBitsUsed >> 3) + 3] = v7; /*0x14118d8cf*/
  this->numberOfBitsUsed += 32; /*0x14118d8d2*/
}

// Address: 0x14118d8f0 | Name: ?WriteAlignedVar8@BitStream@RakNet@@QEAAXPEBD@Z
void __fastcall RakNet::BitStream::WriteAlignedVar8(RakNet::BitStream *this, const char *inByteArray)
{
  RakNet::BitStream::AddBitsAndReallocate(this, numberOfBitsToWrite: 8u); /*0x14118d905*/
  this->data[(unsigned __int64)this->numberOfBitsUsed >> 3] = *inByteArray; /*0x14118d91e*/
  this->numberOfBitsUsed += 8; /*0x14118d922*/
}

// Address: 0x14118d930 | Name: ?WriteBits@BitStream@RakNet@@QEAAXPEBEI_N@Z
void __fastcall RakNet::BitStream::WriteBits(
        RakNet::BitStream *this,
        unsigned __int8 *inByteArray,
        unsigned int numberOfBitsToWrite,
        const bool rightAlignedBits)
{
  unsigned int v5; // ebx
  unsigned int numberOfBitsUsed; // r10d
  int v9; // r11d
  unsigned __int8 v10; // r8
  unsigned __int8 *v11; // rdx
  unsigned int v12; // eax

  v5 = numberOfBitsToWrite; /*0x14118d947*/
  RakNet::BitStream::AddBitsAndReallocate(this, numberOfBitsToWrite); /*0x14118d954*/
  numberOfBitsUsed = this->numberOfBitsUsed; /*0x14118d959*/
  v9 = numberOfBitsUsed & 7; /*0x14118d960*/
  if ( (numberOfBitsUsed & 7) != 0 || (v5 & 7) != 0 ) /*0x14118d969*/
  {
    if ( v5 != 0 ) /*0x14118d98f*/
    {
      while ( 1 ) /*0x14118d991*/
      {
        v10 = *inByteArray++; /*0x14118d991*/
        if ( v5 < 8 && rightAlignedBits ) /*0x14118d9a1*/
          v10 <<= 8 - v5; /*0x14118d9aa*/
        v11 = &this->data[(unsigned __int64)numberOfBitsUsed >> 3]; /*0x14118d9b4*/
        if ( v9 != 0 ) /*0x14118d9bb*/
        {
          *v11 |= v10 >> v9; /*0x14118d9d1*/
          if ( 8 - v9 < v5 ) /*0x14118d9dd*/
            this->data[((unsigned __int64)this->numberOfBitsUsed >> 3) + 1] = v10 << (8 - v9); /*0x14118d9ed*/
        }
        else
        {
          *v11 = v10; /*0x14118d9bd*/
        }
        v12 = this->numberOfBitsUsed; /*0x14118d9f2*/
        if ( v5 < 8 ) /*0x14118d9f8*/
          break; /*0x14118d9f8*/
        numberOfBitsUsed = v12 + 8; /*0x14118d9fa*/
        this->numberOfBitsUsed = v12 + 8; /*0x14118d9fe*/
        v5 -= 8; /*0x14118da02*/
        if ( v5 == 0 ) /*0x14118da05*/
          return; /*0x14118da05*/
      }
      this->numberOfBitsUsed = v5 + v12; /*0x14118da0b*/
    }
  }
  else
  {
    memcpy_0( /*0x14118d980*/
      a1: &this->data[(unsigned __int64)numberOfBitsUsed >> 3],
      Src: inByteArray,
      Size: (unsigned __int64)v5 >> 3);
    this->numberOfBitsUsed += v5; /*0x14118d985*/
  }
}

// END BitStream part 1/1, 32 functions
