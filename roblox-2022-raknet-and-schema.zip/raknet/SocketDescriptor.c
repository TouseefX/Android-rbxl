// SocketDescriptor -- 2022 Studio + full PDB
// tier 3, 2 functions


// Address: 0x14100cef0 | Name: ??0SocketDescriptor@RakNet@@QEAA@GPEBD@Z
RakNet::SocketDescriptor *__fastcall RakNet::SocketDescriptor::SocketDescriptor(
        RakNet::SocketDescriptor *this,
        unsigned __int16 _port,
        char *_hostAddress)
{
  signed __int64 v3; // rdx
  char v4; // al

  this->port = _port; /*0x14100cef0*/
  if ( _hostAddress != nullptr ) /*0x14100cef6*/
  {
    v3 = (char *)this - _hostAddress; /*0x14100cefb*/
    do /*0x14100cf0f*/
    {
      v4 = *_hostAddress; /*0x14100cf00*/
      _hostAddress[v3 + 2] = *_hostAddress; /*0x14100cf04*/
      ++_hostAddress; /*0x14100cf09*/
    }
    while ( v4 != 0 ); /*0x14100cf0f*/
    this->socketFamily = 0; /*0x14100cf13*/
    return this; /*0x14100cf17*/
  }
  else
  {
    this->hostAddress[0] = 0; /*0x14100cf1d*/
    this->socketFamily = 0; /*0x14100cf21*/
    return this; /*0x14100cf25*/
  }
}

// Address: 0x14100cf30 | Name: ??0SocketDescriptor@RakNet@@QEAA@XZ
RakNet::SocketDescriptor *__fastcall RakNet::SocketDescriptor::SocketDescriptor(RakNet::SocketDescriptor *this)
{
  this->port = 0; /*0x14100cf32*/
  this->hostAddress[0] = 0; /*0x14100cf35*/
  this->socketFamily = 0; /*0x14100cf38*/
  return this; /*0x14100cf3f*/
}

// END SocketDescriptor part 1/1, 2 functions
