// RemoteSystemStruct -- 2022 Studio + full PDB
// tier 3, 2 functions


// Address: 0x1410b7f40 | Name: ??0RemoteSystemStruct@RakPeer@RakNet@@QEAA@XZ
RakNet::RakPeer::RemoteSystemStruct *__fastcall RakNet::RakPeer::RemoteSystemStruct::RemoteSystemStruct(
        RakNet::RakPeer::RemoteSystemStruct *this)
{
  RakNet::SystemAddress *theirInternalSystemAddress; // rdi
  __int64 i; // rbx

  this->isActive._Storage._Value = false; /*0x1410b7f59*/
  this->lowestPing._Storage._Value = 0; /*0x1410b7f5b*/
  RakNet::SystemAddress::SystemAddress(this: &this->systemAddress); /*0x1410b7f63*/
  RakNet::SystemAddress::SystemAddress(this: &this->myExternalSystemAddress); /*0x1410b7f6c*/
  theirInternalSystemAddress = this->theirInternalSystemAddress; /*0x1410b7f71*/
  for ( i = 10; i != 0; --i ) /*0x1410b7f75*/
    RakNet::SystemAddress::SystemAddress(this: theirInternalSystemAddress++); /*0x1410b7f83*/
  RakNet::ReliabilityLayer::ReliabilityLayer(this: (RakNet::ReliabilityLayer *)((char *)&this->reliabilityLayer.rbxSessionCrypto._Ptr /*0x1410b7f99*/
                                                                              + 4));
  __wind /*0xf1c000000000001c*/
  {
    RakNet::RakNetGUID::RakNetGUID(this: &this->guid); /*0x1410b7fa6*/
    this->rakNetSocket._Ptr = nullptr; /*0x1410b7fad*/
    this->rakNetSocket._Rep = nullptr; /*0x1410b7fb4*/
    this->recordJoinDataRxStats._Storage._Value = false; /*0x1410b7fbb*/
    this->joinRequestInitiatedTimeInMS = 0; /*0x1410b7fc1*/
    this->tokenOptions._Has_value = false; /*0x1410b7fc7*/
  }
  __unwind
  {
    RakNet::ReliabilityLayer::~ReliabilityLayer(this: (RakNet::ReliabilityLayer *)((char *)&this->reliabilityLayer.rbxSessionCrypto._Ptr /*0x1431ecd2e*/
                                                                                 + 4));
  }
  return this; /*0x1410b7fd0*/
}

// Address: 0x1410b89c0 | Name: ??1RemoteSystemStruct@RakPeer@RakNet@@QEAA@XZ
void __fastcall RakNet::RakPeer::RemoteSystemStruct::~RemoteSystemStruct(RakNet::RakPeer::RemoteSystemStruct *this)
{
  std::_Ref_count_base *Rep; // rbx

  Rep = this->rakNetSocket._Rep; /*0x1410b89ca*/
  if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410b89ed*/
  {
    Rep->_Destroy(this: Rep); /*0x1410b89f5*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410b89ff*/
      Rep->_Delete_this(this: Rep); /*0x1410b8a07*/
  }
  RakNet::ReliabilityLayer::~ReliabilityLayer(this: (RakNet::ReliabilityLayer *)((char *)&this->reliabilityLayer.rbxSessionCrypto._Ptr /*0x1410b8a20*/
                                                                               + 4));
}

// END RemoteSystemStruct part 1/1, 2 functions
