// EAPEAUPacket -- 2022 Studio + full PDB
// tier 3, 1 functions


// Address: 0x1410b7010 | Name: ??$emplace@AEAPEAUPacket@RakNet@@IAEA_N_K@?$queue@UDeferredQueueInfo@RakPeer@RakNet@@V?$deque@UDeferredQueueInfo@RakPeer@RakNet@@V?$allocator@UDeferredQueueInfo@RakPeer@RakNet@@@std@@@std@@@std@@QEAA?A_TAEAPEAUPacket@RakNet@@$$QEAIAEA_N$$QEA_K@Z
RakNet::RakPeer::DeferredQueueInfo *__fastcall std::queue<RakNet::RakPeer::DeferredQueueInfo>::emplace<RakNet::Packet * &,unsigned int,bool &,unsigned __int64>(
        std::queue<RakNet::RakPeer::DeferredQueueInfo> *this,
        RakNet::Packet **<_Val_0>,
        unsigned int *<_Val_1>,
        bool *<_Val_2>,
        unsigned __int64 *<_Val_3>)
{
  unsigned __int64 Mysize; // rcx
  unsigned __int64 Mapsize; // r10
  RakNet::RakPeer::DeferredQueueInfo **Map; // r9
  unsigned __int64 v12; // rdi
  unsigned int v13; // ecx
  RakNet::RakPeer::DeferredQueueInfo *v14; // r9
  unsigned __int64 v15; // r8
  RakNet::Packet *v16; // rax

  Mysize = this->c._Mypair._Myval2._Mysize; /*0x1410b7030*/
  Mapsize = this->c._Mypair._Myval2._Mapsize; /*0x1410b703a*/
  if ( Mapsize <= Mysize + 1 ) /*0x1410b7045*/
  {
    std::deque<RBX::json::Document>::_Growmap( /*0x1410b704f*/
      (std::deque<webrtc::EncoderOvershootDetector::BitrateUpdate> *)this,
      _Count: 1u);
    Mapsize = this->c._Mypair._Myval2._Mapsize; /*0x1410b7054*/
    Mysize = this->c._Mypair._Myval2._Mysize; /*0x1410b7058*/
  }
  this->c._Mypair._Myval2._Myoff &= Mapsize - 1; /*0x1410b7060*/
  Map = this->c._Mypair._Myval2._Map; /*0x1410b706c*/
  v12 = (Mapsize - 1) & (this->c._Mypair._Myval2._Myoff + Mysize); /*0x1410b7078*/
  if ( Map[v12] == nullptr ) /*0x1410b7080*/
  {
    this->c._Mypair._Myval2._Map[v12] = (RakNet::RakPeer::DeferredQueueInfo *)operator new(size: 0x18u); /*0x1410b7090*/
    Map = this->c._Mypair._Myval2._Map; /*0x1410b7094*/
  }
  v13 = *<_Val_1>; /*0x1410b709b*/
  v14 = Map[v12]; /*0x1410b709e*/
  v15 = *<_Val_3>; /*0x1410b70b6*/
  v16 = *<_Val_0>; /*0x1410b70b9*/
  v14->isJoin = *<_Val_2>; /*0x1410b70bc*/
  v14->packet = v16; /*0x1410b70c0*/
  v14->timeQueued = v13; /*0x1410b70c6*/
  v14->queueLengthAtDefer = v15; /*0x1410b70ca*/
  return this->c._Mypair._Myval2._Map[(this->c._Mypair._Myval2._Myoff + this->c._Mypair._Myval2._Mysize++) /*0x1410b70f0*/
                                    & (this->c._Mypair._Myval2._Mapsize - 1)];
}

// END EAPEAUPacket part 1/1, 1 functions
