// CCRakNetBase -- 2022 Studio + full PDB
// tier 3, 1 functions


// Address: 0x1411a2970 | Name: ??1CCRakNetBase@RakNet@@UEAA@XZ
void __fastcall RakNet::CCRakNetBase::~CCRakNetBase(RakNet::CCRakNetBase *this)
{
  this->__vftable = (RakNet::CCRakNetBase_vtbl *)RakNet::CCRakNetBase::`vftable'; /*0x1411a2977*/
}

// END CCRakNetBase part 1/1, 1 functions
