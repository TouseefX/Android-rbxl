// CCRakNetSlidingWindow2 -- 2022 Studio + full PDB
// tier 3, 33 functions


// Address: 0x1411a2820 | Name: ??0CCRakNetSlidingWindow2@RakNet@@QEAA@XZ
RakNet::CCRakNetSlidingWindow2 *__fastcall RakNet::CCRakNetSlidingWindow2::CCRakNetSlidingWindow2(
        RakNet::CCRakNetSlidingWindow2 *this)
{
  std::_List_node<RakNet::PktInfo,void *> *v2; // rax
  std::_Tree_node<std::pair<unsigned int const ,std::_List_iterator<std::_List_val<std::_List_simple_types<RakNet::PktInfo> > > >,void *> *v3; // rax
  std::_List_node<std::pair<unsigned int const ,std::_List_iterator<std::_List_val<std::_List_simple_types<RakNet::PktInfo> > > >,void *> *v4; // rax
  RakNet::CCRakNetSlidingWindow2 *result; // rax

  this->__vftable = (RakNet::CCRakNetSlidingWindow2_vtbl *)RakNet::CCRakNetSlidingWindow2::`vftable'; /*0x1411a283e*/
  this->ackedSeqence._Mypair._Myval2._Myfirst = nullptr; /*0x1411a2843*/
  this->ackedSeqence._Mypair._Myval2._Mylast = nullptr; /*0x1411a284a*/
  this->ackedSeqence._Mypair._Myval2._Myend = nullptr; /*0x1411a2851*/
  this->pktList._Mypair._Myval2._Myhead = nullptr; /*0x1411a2858*/
  this->pktList._Mypair._Myval2._Mysize = 0; /*0x1411a285f*/
  __wind /*0xf1c00000000000c0*/
  {
    __wind /*0xf1c00000000000c8*/
    {
      v2 = (std::_List_node<RakNet::PktInfo,void *> *)operator new(size: 0x48u); /*0x1411a2869*/
      v2->_Next = v2; /*0x1411a286e*/
      v2->_Prev = v2; /*0x1411a2871*/
      this->pktList._Mypair._Myval2._Myhead = v2; /*0x1411a2875*/
      this->rttRangeQueue.m_buff = nullptr; /*0x1411a287c*/
      this->rttRangeQueue.m_end = nullptr; /*0x1411a2883*/
      this->rttRangeQueue.m_first = nullptr; /*0x1411a288a*/
      this->rttRangeQueue.m_last = nullptr; /*0x1411a2891*/
      this->rttRangeQueue.m_size = 0; /*0x1411a2898*/
      this->lastAck._Ptr = nullptr; /*0x1411a289f*/
      this->pktIds_deprecated._Mypair._Myval2._Myval2._Myhead = nullptr; /*0x1411a28b2*/
      this->pktIds_deprecated._Mypair._Myval2._Myval2._Mysize = 0; /*0x1411a28b5*/
      __wind /*0xf1c00000000000ac*/
      {
        __wind /*0xf1c00000000000b4*/
        {
          v3 = (std::_Tree_node<std::pair<unsigned int const ,std::_List_iterator<std::_List_val<std::_List_simple_types<RakNet::PktInfo> > > >,void *> *)operator new(size: 0x30u); /*0x1411a28bc*/
          v3->_Left = v3; /*0x1411a28c1*/
          v3->_Parent = v3; /*0x1411a28c4*/
          v3->_Right = v3; /*0x1411a28c8*/
          *(_WORD *)&v3->_Color = 257; /*0x1411a28cc*/
          this->pktIds_deprecated._Mypair._Myval2._Myval2._Myhead = v3; /*0x1411a28d2*/
          this->pktIds._Traitsobj._Mypair._Myval2._Myval2 = 0.0; /*0x1411a28e1*/
          this->pktIds._List._Mypair._Myval2._Myhead = nullptr; /*0x1411a28e3*/
          this->pktIds._List._Mypair._Myval2._Mysize = 0; /*0x1411a28e7*/
          __wind /*0xf1c0000000000038*/
          {
            v4 = (std::_List_node<std::pair<unsigned int const ,std::_List_iterator<std::_List_val<std::_List_simple_types<RakNet::PktInfo> > > >,void *> *)operator new(size: 0x20u); /*0x1411a28ee*/
            v4->_Next = v4; /*0x1411a28f3*/
            v4->_Prev = v4; /*0x1411a28f6*/
            this->pktIds._List._Mypair._Myval2._Myhead = v4; /*0x1411a28fa*/
            this->pktIds._Vec._Mypair._Myval2._Myfirst = nullptr; /*0x1411a2902*/
            this->pktIds._Vec._Mypair._Myval2._Mylast = nullptr; /*0x1411a2905*/
            this->pktIds._Vec._Mypair._Myval2._Myend = nullptr; /*0x1411a2909*/
            this->pktIds._Mask = 7; /*0x1411a290d*/
            this->pktIds._Maxidx = 8; /*0x1411a2915*/
            this->pktIds._Traitsobj._Mypair._Myval2._Myval2 = 1.0; /*0x1411a291d*/
            __wind /*0xf1c0000000000080*/
            {
              __wind /*0xf1c0000000000088*/
              {
                std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const,std::shared_ptr<RBX::Graphics::Shader>>>>>>>::_Assign_grow( /*0x1411a292a*/
                  this: (std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> > > > > > > *)&this->pktIds._Vec,
                  _Cells: 0x10u,
                  _Val: (const std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> > > > >)this->pktIds._List._Mypair._Myval2._Myhead);
                this->applicationSpeedTarget._Storage._Value = 0; /*0x1411a2932*/
                this->lastAck._Ptr = this->pktList._Mypair._Myval2._Myhead; /*0x1411a293f*/
                result = this; /*0x1411a2946*/
              }
              __unwind
              {
                std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>::~_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>(this: (std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<__int64 const ,std::vector<RBX::Permission> > > > > > > *)&this->pktIds._Vec); /*0x14315e76b*/
              }
            }
            __unwind
            {
              std::list<std::pair<RBX::StreamRegion::Id const,bool>>::~list<std::pair<RBX::StreamRegion::Id const,bool>>(this: (std::list<std::pair<SearchResult * const,QuickOpenItemWidget *>> *)&this->pktIds._List); /*0x1431d0c0b*/
            }
          }
          __unwind
          {
            std::map<__int64,int>::~map<__int64,int>(this: (std::map<RBX::Reflection::PropertyDescriptor const *,SettingsDialog::PropertyItem *> *)&this->pktIds_deprecated); /*0x1431f337e*/
          }
        }
        __unwind
        {
          boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo>>::~circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo>>(this: &this->rttRangeQueue); /*0x1431f335e*/
        }
      }
      __unwind
      {
        std::list<RakNet::PktInfo>::~list<RakNet::PktInfo>(this: &this->pktList); /*0x1431f333e*/
      }
    }
    __unwind
    {
      std::vector<Luau::Location>::~vector<Luau::Location>(this: (RBX::DenseHashMap<RBX::Graphics::ShaderProgram *,VkPipeline_T *,boost::hash<RBX::Graphics::ShaderProgram *>,std::equal_to<RBX::Graphics::ShaderProgram *> > *)&this->ackedSeqence); /*0x1431bf65e*/
    }
  }
  __unwind
  {
    RakNet::CCRakNetBase::~CCRakNetBase(this); /*0xf1c0000000000078*/
  }
  return result; /*0x1411a2949*/
}

// Address: 0x1411a2bf0 | Name: ?GetAckTimestamps@CCRakNetSlidingWindow2@RakNet@@MEAA_NAEA_K0@Z
bool __fastcall RakNet::CCRakNetSlidingWindow2::GetAckTimestamps(
        RakNet::CCRakNetSlidingWindow2 *this,
        unsigned __int64 *oldestUnsentAck,
        unsigned __int64 *newestUnsentAck)
{
  unsigned __int64 v3; // rax

  *oldestUnsentAck = this->oldestUnsentAck; /*0x1411a2bf4*/
  v3 = this->newestUnsentAck; /*0x1411a2bf7*/
  *newestUnsentAck = v3; /*0x1411a2bfb*/
  return *oldestUnsentAck != 0 && v3 != 0; /*0x1411a2c0b*/
}

// Address: 0x1411a2c10 | Name: ?GetAndIncrementNextDatagramSequenceNumber@CCRakNetSlidingWindow2@RakNet@@UEAA?AUuint24_t@2@XZ
RakNet::uint24_t *__fastcall RakNet::CCRakNetSlidingWindow2::GetAndIncrementNextDatagramSequenceNumber(
        RakNet::CCRakNetSlidingWindow2 *this,
        RakNet::uint24_t *result)
{
  unsigned int val; // eax

  val = this->nextDatagramSequenceNumber.val; /*0x1411a2c10*/
  result->val = val; /*0x1411a2c13*/
  this->nextDatagramSequenceNumber.val = val + 1; /*0x1411a2c17*/
  HIBYTE(this->nextDatagramSequenceNumber.val) = 0; /*0x1411a2c1d*/
  return result; /*0x1411a2c21*/
}

// Address: 0x1411a2c30 | Name: ?GetAvailableTransmissionCapacityBytesWithinWindow@CCRakNetSlidingWindow2@RakNet@@UEAAHMM_K0@Z
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::GetAvailableTransmissionCapacityBytesWithinWindow(
        RakNet::CCRakNetSlidingWindow2 *this,
        float ms,
        float percentLoss,
        unsigned __int64 bytesInResendBuffer)
{
  int v4; // eax
  int v5; // ecx
  __int64 result; // rax

  v4 = (int)(float)((float)((float)this->applicationSpeedTarget._Storage._Value * ms) / 1000.0); /*0x1411a2c4a*/
  v5 = (int)(float)((float)(int)bytesInResendBuffer * percentLoss); /*0x1411a2c5a*/
  if ( v5 > v4 ) /*0x1411a2c60*/
    return 0; /*0x1411a2c62*/
  result = (unsigned int)(v4 - v5); /*0x1411a2c65*/
  if ( (int)result < 0 ) /*0x1411a2c6c*/
    return 0; /*0x1411a2c6c*/
  return result; /*0x1411a2c64*/
}

// Address: 0x1411a2c70 | Name: ?GetCongestionManagerStats@CCRakNetSlidingWindow2@RakNet@@UEAAXAEAUCCRakNetStats@2@@Z
void __fastcall RakNet::CCRakNetSlidingWindow2::GetCongestionManagerStats(
        RakNet::CCRakNetSlidingWindow2 *this,
        RakNet::CCRakNetStats *stats)
{
  stats->transmissionBandwidth = 8 * (this->lastGetTransmissionBandwidthValue / DFInt::RakNetLoopMs / 1000); /*0x1411a2ca5*/
  stats->targetAckSpeed = 8 * (RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(this) / 1000); /*0x1411a2cc5*/
  stats->targetRTT = RakNet::CCRakNetSlidingWindow2::getRttMicroMin(this) / 1000; /*0x1411a2cf0*/
  stats->bytesSent = this->bytesSent / 1000; /*0x1411a2d08*/
  stats->bytesAcked = this->bytesAck / 1000; /*0x1411a2d1b*/
  stats->bytesInFlight = this->bytesSent - this->bytesNak - this->bytesAck; /*0x1411a2d30*/
  stats->isAppLimited = this->appLimitedStart != 0; /*0x1411a2d43*/
}

// Address: 0x1411a2d70 | Name: ?GetNextDatagramSequenceNumber@CCRakNetSlidingWindow2@RakNet@@UEAA?AUuint24_t@2@XZ
RakNet::uint24_t *__fastcall RakNet::CCRakNetSlidingWindow2::GetNextDatagramSequenceNumber(
        RakNet::CCRakNetSlidingWindow2 *this,
        RakNet::uint24_t *result)
{
  result->val = (unsigned int)this->nextDatagramSequenceNumber; /*0x1411a2d73*/
  return result; /*0x1411a2d78*/
}

// Address: 0x1411a2d80 | Name: ?GetRTOForRetransmission@CCRakNetSlidingWindow2@RakNet@@UEBA_KXZ
unsigned __int64 __fastcall RakNet::CCRakNetSlidingWindow2::GetRTOForRetransmission(
        RakNet::CCRakNetSlidingWindow *this)
{
  double RTT; // xmm0_8
  double v2; // xmm2_8
  double v3; // xmm1_8
  unsigned __int64 v4; // rcx
  double v5; // xmm1_8
  unsigned __int64 v6; // rcx
  unsigned __int64 v8; // rax

  RTT = this->RTT; /*0x1411a2d80*/
  if ( RTT == -1.0 ) /*0x1411a2d9d*/
    return DFInt::RakNetResendMaxThresholdTimeInUs; /*0x1411a2d9d*/
  v2 = (double)DFInt::RakNetResendRttMultiple * RTT; /*0x1411a2db6*/
  if ( DFInt::RakNetResendMaxThresholdTimeInUs < 0LL ) /*0x1411a2dbd*/
  {
    v4 = DFInt::RakNetResendMaxThresholdTimeInUs & 1 | ((unsigned __int64)DFInt::RakNetResendMaxThresholdTimeInUs >> 1); /*0x1411a2dd2*/
    v3 = (double)(int)v4 + (double)(int)v4; /*0x1411a2dda*/
  }
  else
  {
    v3 = (double)DFInt::RakNetResendMaxThresholdTimeInUs; /*0x1411a2dbf*/
  }
  if ( v2 > v3 ) /*0x1411a2de2*/
    return DFInt::RakNetResendMaxThresholdTimeInUs; /*0x1411a2e4c*/
  if ( DFInt::RakNetResendMinThresholdTimeInUs < 0LL ) /*0x1411a2dea*/
  {
    v6 = DFInt::RakNetResendMinThresholdTimeInUs & 1 | ((unsigned __int64)DFInt::RakNetResendMinThresholdTimeInUs >> 1); /*0x1411a2dff*/
    v5 = (double)(int)v6 + (double)(int)v6; /*0x1411a2e07*/
  }
  else
  {
    v5 = (double)DFInt::RakNetResendMinThresholdTimeInUs; /*0x1411a2dec*/
  }
  if ( v5 > v2 ) /*0x1411a2e0f*/
    return DFInt::RakNetResendMinThresholdTimeInUs; /*0x1411a2e11*/
  v8 = 0; /*0x1411a2e1d*/
  if ( RTT >= 9.223372036854776e18 ) /*0x1411a2e23*/
  {
    RTT = RTT - 9.223372036854776e18; /*0x1411a2e25*/
    if ( RTT < 9.223372036854776e18 ) /*0x1411a2e2d*/
      v8 = 0x8000000000000000uLL; /*0x1411a2e39*/
  }
  return (v8 + (unsigned int)(int)RTT) * DFInt::RakNetResendRttMultiple; /*0x1411a2e14*/
}

// Address: 0x1411a2e50 | Name: ?GetRTT@CCRakNetSlidingWindow2@RakNet@@UEBANXZ
long double __fastcall RakNet::CCRakNetSlidingWindow2::GetRTT(RakNet::CCRakNetSlidingWindow *this)
{
  long double result; // xmm0_8

  result = this->RTT; /*0x1411a2e50*/
  if ( result == -1.0 ) /*0x1411a2e5f*/
    return 0.0; /*0x1411a2e61*/
  return result; /*0x1411a2e64*/
}

// Address: 0x1411a2e70 | Name: ?GetRetransmissionBandwidth@CCRakNetSlidingWindow2@RakNet@@UEAAH_K0I_NAEAUTxBwInfluencers@2@@Z
int __fastcall RakNet::CCRakNetSlidingWindow2::GetRetransmissionBandwidth(
        RakNet::CCRakNetSlidingWindow2 *this,
        unsigned __int64 curTime,
        unsigned __int64 timeSinceLastTick,
        __int64 unacknowledgedBytes,
        bool isContinuousSend,
        RakNet::TxBwInfluencers *txBwInfluencers)
{
  return ((int (__fastcall *)(RakNet::CCRakNetSlidingWindow2 *, unsigned __int64, unsigned __int64, __int64))this->GetTransmissionBandwidth)(
           a1: this,
           a2: curTime,
           a3: timeSinceLastTick,
           a4: unacknowledgedBytes);
}

// Address: 0x1411a2e90 | Name: ?GetTransmissionBandwidth@CCRakNetSlidingWindow2@RakNet@@UEAAH_K0I_NAEAUTxBwInfluencers@2@@Z
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::GetTransmissionBandwidth(
        RakNet::CCRakNetSlidingWindow2 *this,
        __int64 curTime,
        unsigned __int64 timeSinceLastTick,
        unsigned int unacknowledgedBytes,
        bool isContinuousSend,
        RakNet::TxBwInfluencers *txBwInfluencers)
{
  int v8; // eax
  int lastGetTransmissionBandwidthValue; // edx
  int lastGetTransmissionBandwidthSent; // ecx
  int v11; // eax
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *m_last; // rax
  __int64 RttMicroMin; // r15
  int v14; // esi
  RakNet::CCRakNetSlidingWindow2::OperationState currentState; // ecx
  bool v16; // zf
  RakNet::CCRakNetSlidingWindow2 *v17; // rcx
  int v18; // eax
  int targetSpeed; // edx
  __int64 targetSpeedStartTime; // rax
  __int64 v21; // r9
  int v22; // eax
  bool v23; // r11
  int v24; // eax
  int v25; // r10d
  int v26; // r14d
  int v27; // eax
  int v28; // ebp
  __int64 v29; // rcx
  __int64 v30; // rax
  __int64 v31; // rdx
  RakNet::CCRakNetSlidingWindow2::OperationState v32; // ecx
  __int64 v33; // r10
  int v34; // eax
  int v35; // eax
  int v36; // r11d
  int maxPayload; // eax
  __int64 v38; // r10
  int v39; // r11d
  int v40; // r9d
  __int64 v41; // rax
  __int64 v42; // rcx
  __int64 lastEventTime; // rcx

  this->_isContinuousSend = isContinuousSend; /*0x1411a2eb4*/
  v8 = DFInt::RakNetLoopMs; /*0x1411a2eba*/
  if ( DFInt::RakNetLoopMs < 10 ) /*0x1411a2ec7*/
    v8 = 10; /*0x1411a2ec7*/
  if ( curTime - this->lastGetTransmissionBandwidthTime > (unsigned __int64)(2000LL * v8) ) /*0x1411a2ee2*/
    goto LABEL_10; /*0x1411a2ee2*/
  lastGetTransmissionBandwidthValue = this->lastGetTransmissionBandwidthValue; /*0x1411a2ee4*/
  if ( lastGetTransmissionBandwidthValue <= 0 ) /*0x1411a2eec*/
    goto LABEL_14; /*0x1411a2eec*/
  lastGetTransmissionBandwidthSent = this->lastGetTransmissionBandwidthSent; /*0x1411a2eee*/
  if ( lastGetTransmissionBandwidthSent != 0 /*0x1411a2efd*/
    && this->maxPayload + lastGetTransmissionBandwidthSent >= lastGetTransmissionBandwidthValue )
  {
    v11 = this->appLimitedStartCount + 1; /*0x1411a2f05*/
    this->appLimitedStartCount = v11; /*0x1411a2f07*/
    if ( this->appLimitedStart != 0 && v11 > 2 ) /*0x1411a2f19*/
      this->appLimitedStart = 0; /*0x1411a2f1b*/
  }
  else
  {
LABEL_10:
    this->appLimitedStartCount = 0; /*0x1411a2f24*/
    if ( this->appLimitedStart == 0 ) /*0x1411a2f31*/
    {
      this->appLimitedStart = curTime; /*0x1411a2f33*/
      m_last = this->rttRangeQueue.m_last; /*0x1411a2f3a*/
      if ( m_last == this->rttRangeQueue.m_buff ) /*0x1411a2f48*/
        m_last = this->rttRangeQueue.m_end; /*0x1411a2f4a*/
      m_last[-1].appLimited = true; /*0x1411a2f51*/
    }
  }
LABEL_14:
  this->lastGetTransmissionBandwidthTime = curTime; /*0x1411a2f55*/
  *(_QWORD *)&this->lastGetTransmissionBandwidthValue = 0; /*0x1411a2f5f*/
  RttMicroMin = RakNet::CCRakNetSlidingWindow2::getRttMicroMin(this); /*0x1411a2f71*/
  v14 = this->bytesSent - this->bytesNak - this->bytesAck; /*0x1411a2f7a*/
  currentState = this->currentState; /*0x1411a2f80*/
  if ( currentState == OperationState_start ) /*0x1411a2f85*/
  {
    RakNet::CCRakNetSlidingWindow2::updateStartTargetSpeed(this, curTime); /*0x1411a2f8d*/
    goto LABEL_23; /*0x1411a2f92*/
  }
  v16 = currentState == OperationState_drain; /*0x1411a2f94*/
  v17 = this; /*0x1411a2f97*/
  if ( v16 ) /*0x1411a2f9a*/
  {
    if ( RakNet::CCRakNetSlidingWindow2::calculateDrainSpeed(this, targetAckSpeed: -1) != -1 ) /*0x1411a2fa9*/
      goto LABEL_23; /*0x1411a2fa9*/
    v18 = RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(this); /*0x1411a2fae*/
    if ( v18 == -1 ) /*0x1411a2fb6*/
      v18 = RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(this); /*0x1411a2fbb*/
    *(_QWORD *)&this->currentState = 3; /*0x1411a2fc0*/
    targetSpeed = v18; /*0x1411a2fc8*/
    v17 = this; /*0x1411a2fca*/
  }
  else
  {
    targetSpeed = this->targetSpeed; /*0x1411a2fcf*/
  }
  RakNet::CCRakNetSlidingWindow2::setTargetSpeed(this: v17, newTargetSpeed: targetSpeed); /*0x1411a2fd5*/
LABEL_23:
  targetSpeedStartTime = this->targetSpeedStartTime; /*0x1411a2fda*/
  if ( targetSpeedStartTime != 0 ) /*0x1411a2ff3*/
  {
    v21 = this->targetSpeed * (curTime - targetSpeedStartTime) / 1000000 - this->targetSpeedStartBytes; /*0x1411a3035*/
    if ( !DFFlag::RakNetReportTransmissionBw2.value ) /*0x1411a3043*/
      goto LABEL_33; /*0x1411a3043*/
    ++txBwInfluencers->nonZeroTargetSpeedStartTimeCount; /*0x1411a3045*/
  }
  else
  {
    v21 = this->maxPayload - 12; /*0x1411a3002*/
    if ( !DFFlag::RakNetReportTransmissionBw2.value ) /*0x1411a3005*/
      goto LABEL_33; /*0x1411a3005*/
    ++txBwInfluencers->zeroTargetSpeedStartTimeCount; /*0x1411a3007*/
  }
  if ( DFFlag::RakNetReportTransmissionBw2.value ) /*0x1411a3050*/
  {
    ++txBwInfluencers->totalGetTxBwCount; /*0x1411a3052*/
    v22 = v21; /*0x1411a3055*/
    if ( v21 < 0 ) /*0x1411a305b*/
      v22 = 0; /*0x1411a305b*/
    txBwInfluencers->uncappedByteAllowanceFromTargetSpeed += v22; /*0x1411a305e*/
    if ( this->appLimitedStart != 0 ) /*0x1411a3069*/
      ++txBwInfluencers->bwLimitedByAppCount; /*0x1411a306b*/
  }
LABEL_33:
  v23 = false; /*0x1411a306f*/
  v24 = this->packetsSent - this->packetsNak - this->packetsAck; /*0x1411a308d*/
  v25 = 100 * v24; /*0x1411a3093*/
  v26 = FInt::RakNetResendBufferArrayLength - v24; /*0x1411a3097*/
  v27 = DFInt::RakNetLoopMs; /*0x1411a30a3*/
  if ( v25 < 80 * FInt::RakNetResendBufferArrayLength ) /*0x1411a30a9*/
  {
    if ( DFInt::RakNetLoopMs < 2 ) /*0x1411a3104*/
      v27 = 2; /*0x1411a3104*/
    v31 = 2000 * this->targetSpeed * (__int64)v27 / 1000000; /*0x1411a312d*/
    goto LABEL_43; /*0x1411a312d*/
  }
  v28 = 95 * FInt::RakNetResendBufferArrayLength; /*0x1411a30ab*/
  if ( DFInt::RakNetLoopMs < 1 ) /*0x1411a30b6*/
    v27 = 1; /*0x1411a30b6*/
  v29 = v27; /*0x1411a30ba*/
  v30 = 2000; /*0x1411a30bd*/
  if ( v25 >= v28 ) /*0x1411a30c5*/
    v30 = 1000; /*0x1411a30c5*/
  v31 = this->targetSpeed * v30 * v29 / 1000000; /*0x1411a30e8*/
  if ( DFFlag::RakNetReportTransmissionBw2.value ) /*0x1411a30f2*/
  {
    v23 = v25 >= v28; /*0x1411a30f7*/
LABEL_43:
    if ( DFFlag::RakNetReportTransmissionBw2.value ) /*0x1411a3137*/
      txBwInfluencers->bytesGivenByTargetSpeed += v31; /*0x1411a3139*/
  }
  if ( v21 > v31 ) /*0x1411a3140*/
  {
    v21 = v31; /*0x1411a3149*/
    if ( DFFlag::RakNetReportTransmissionBw2.value ) /*0x1411a314c*/
    {
      if ( v23 ) /*0x1411a3151*/
        ++txBwInfluencers->bwCappedDueToTargetSpeedCount; /*0x1411a3153*/
      else
        ++txBwInfluencers->bwCappedDueTo2xTargetSpeedCount; /*0x1411a3159*/
    }
  }
  if ( v21 > 0 ) /*0x1411a3160*/
  {
    v32 = this->currentState; /*0x1411a3168*/
    v33 = RttMicroMin + DFInt::RakNetUseSlidingWindow2_minRtt / 2; /*0x1411a3173*/
    if ( (unsigned int)(v32 - 4) <= 1 ) /*0x1411a317c*/
    {
      v33 += v33 / 2; /*0x1411a3192*/
    }
    else if ( v32 == OperationState_start ) /*0x1411a3180*/
    {
      v33 *= 2; /*0x1411a3182*/
    }
    v34 = 2 * this->maxPayload - 24; /*0x1411a31b7*/
    if ( v34 < (int)(v33 * this->targetSpeed / 1000000) ) /*0x1411a31c0*/
      v34 = v33 * this->targetSpeed / 1000000; /*0x1411a31c0*/
    v35 = v34 - v14; /*0x1411a31c3*/
    if ( v21 > v35 ) /*0x1411a31cb*/
    {
      v21 = v35; /*0x1411a31d4*/
      if ( DFFlag::RakNetReportTransmissionBw2.value ) /*0x1411a31d7*/
        ++txBwInfluencers->bwcappedDueToMaxBytesInFlightCount; /*0x1411a31d9*/
    }
  }
  v36 = this->maxPayload - 12; /*0x1411a31e0*/
  maxPayload = this->maxPayload; /*0x1411a31f6*/
  v38 = v21 + v36 - 1LL - (v21 + v36 - 1LL) % v36; /*0x1411a31f8*/
  if ( v38 > 0 ) /*0x1411a31fe*/
  {
    v39 = v26 * v36; /*0x1411a3200*/
    if ( v38 > v39 ) /*0x1411a320a*/
    {
      v38 = v39; /*0x1411a3213*/
      if ( DFFlag::RakNetReportTransmissionBw2.value ) /*0x1411a3216*/
      {
        ++txBwInfluencers->bwCappedDueToMaxPacketsInFlightCount; /*0x1411a3218*/
        maxPayload = this->maxPayload; /*0x1411a321c*/
      }
    }
  }
  v40 = DFInt::RakNetUseSlidingWindow2_minRtt; /*0x1411a321f*/
  v41 = 2000000LL * (maxPayload - 12) / this->targetSpeed; /*0x1411a323c*/
  v42 = 80; /*0x1411a323f*/
  if ( DFInt::RakNetUseSlidingWindow2_minRtt < (int)v41 ) /*0x1411a3247*/
    v40 = v41; /*0x1411a3247*/
  if ( this->currentState == OperationState_drain ) /*0x1411a3254*/
    v42 = 120; /*0x1411a3254*/
  if ( v40 < (int)(RttMicroMin * v42 / 100) ) /*0x1411a327c*/
    v40 = RttMicroMin * v42 / 100; /*0x1411a327c*/
  if ( v38 <= 0 ) /*0x1411a3283*/
  {
    lastEventTime = this->lastEventTime; /*0x1411a3285*/
    if ( lastEventTime != 0 ) /*0x1411a328f*/
    {
      if ( v40 > 1000000 ) /*0x1411a3299*/
        v40 = 1000000; /*0x1411a3299*/
      if ( curTime - lastEventTime > v40 ) /*0x1411a32a6*/
      {
        LODWORD(v38) = 1; /*0x1411a32af*/
        if ( DFFlag::RakNetReportTransmissionBw2.value ) /*0x1411a32b2*/
          ++txBwInfluencers->bwCappedDueToAllBytesInFlightLostCount; /*0x1411a32b4*/
      }
    }
  }
  this->lastGetTransmissionBandwidthValue = v38; /*0x1411a32c5*/
  return (unsigned int)v38; /*0x1411a32b8*/
}

// Address: 0x1411a32e0 | Name: ?Init@CCRakNetSlidingWindow2@RakNet@@UEAAX_KI@Z
void __fastcall RakNet::CCRakNetSlidingWindow2::Init(
        RakNet::CCRakNetSlidingWindow2 *this,
        unsigned __int64 curTime,
        int maxDatagramPayload)
{
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> > *p_rttRangeQueue; // rdi
  unsigned __int64 m_size; // rdx
  unsigned __int64 i; // rcx
  std::_List_node<RakNet::PktInfo,void *> *Myhead; // rcx
  std::_List_node<RakNet::PktInfo,void *> *Next; // rcx
  std::_List_node<RakNet::PktInfo,void *> *v9; // rbx
  std::_List_node<RakNet::PktInfo,void *> *v10; // rax
  std::_List_node<RakNet::PktInfo,void *> *v11; // rax
  unsigned __int64 v12; // rdx
  unsigned __int64 v13; // rcx
  unsigned __int64 v14; // r8
  __int64 v15; // rdx
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *v16; // rcx
  __int64 v17; // rcx
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *m_last; // rax
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *v19; // rax
  __int64 TimeUS; // rax
  boost::cb_details::iterator<boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> >,boost::cb_details::nonconst_traits<boost::container::allocator_traits<std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> > > > pos; // [rsp+20h] [rbp-98h] BYREF
  _QWORD v22[16]; // [rsp+30h] [rbp-88h] BYREF
  boost::cb_details::item_wrapper<RakNet::CCRakNetSlidingWindow2::RttRangeInfo const *,RakNet::CCRakNetSlidingWindow2::RttRangeInfo const &> wrapper; // [rsp+C0h] [rbp+8h] BYREF

  this->maxPayload = maxDatagramPayload; /*0x1411a32f4*/
  *(_QWORD *)&this->nextDatagramSequenceNumber.val = 0; /*0x1411a32f8*/
  p_rttRangeQueue = &this->rttRangeQueue; /*0x1411a32fc*/
  this->expectedNextSequenceNumber.val = 0; /*0x1411a3303*/
  this->RTT = -1.0; /*0x1411a3310*/
  this->levelBlocksCount = 0; /*0x1411a3317*/
  this->ssThresh = 0.0; /*0x1411a331d*/
  this->oldestUnsentAck = 0; /*0x1411a3321*/
  this->newestUnsentAck = 0; /*0x1411a3325*/
  HIBYTE(this->nextDatagramSequenceNumber.val) = 0; /*0x1411a3329*/
  *(_WORD *)((char *)&this->nextCongestionControlBlock.val + 3) = 0; /*0x1411a332d*/
  this->speedUpThisBlock = false; /*0x1411a3331*/
  *(_WORD *)((char *)&this->expectedNextSequenceNumber.val + 3) = 0; /*0x1411a3335*/
  this->cwnd = (double)(32 * maxDatagramPayload); /*0x1411a3345*/
  this->targetSpeed = DFInt::RakNetUseSlidingWindow2_startInitSpeed; /*0x1411a3350*/
  this->currentState = OperationState_start; /*0x1411a3356*/
  *(_QWORD *)&this->packetsSentAll = 0; /*0x1411a3359*/
  *(_QWORD *)&this->packetsSent = 0; /*0x1411a3360*/
  *(_QWORD *)&this->packetsSentAll_lastAck = 0; /*0x1411a3367*/
  *(_QWORD *)&this->packetsSent_lastAck = 0; /*0x1411a336e*/
  *(_QWORD *)&this->packetsAck = 0; /*0x1411a3375*/
  *(_QWORD *)&this->packetsNak = 0; /*0x1411a337c*/
  this->bytesSentTotal = 0; /*0x1411a3383*/
  this->bytesAckTotal = 0; /*0x1411a338a*/
  *(_QWORD *)&this->ackCount = 0; /*0x1411a3391*/
  this->rttMicro = 0; /*0x1411a3398*/
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo>>::set_capacity( /*0x1411a33ad*/
    this: &this->rttRangeQueue,
    new_capacity: DFInt::RakNetUseSlidingWindow2_rangeCount + 1);
  m_size = p_rttRangeQueue->m_size; /*0x1411a33b2*/
  for ( i = 0; i < m_size; ++i ) /*0x1411a33b6*/
  {
    if ( ++p_rttRangeQueue->m_first == p_rttRangeQueue->m_end ) /*0x1411a33d0*/
      p_rttRangeQueue->m_first = p_rttRangeQueue->m_buff; /*0x1411a33d5*/
  }
  p_rttRangeQueue->m_size = 0; /*0x1411a33ed*/
  std::_Hash<std::_Umap_traits<unsigned int,std::_List_iterator<std::_List_val<std::_List_simple_types<RakNet::PktInfo>>>,std::_Uhash_compare<unsigned int,std::hash<unsigned int>,std::equal_to<unsigned int>>,std::allocator<std::pair<unsigned int const,std::_List_iterator<std::_List_val<std::_List_simple_types<RakNet::PktInfo>>>>>,0>>::clear(this: (std::_Hash<std::_Umap_traits<enum lm::FacsName,std::pair<float,float>,std::_Uhash_compare<enum lm::FacsName,std::hash<enum lm::FacsName>,std::equal_to<enum lm::FacsName> >,std::allocator<std::pair<enum lm::FacsName const ,std::pair<float,float> > >,0> > *)&this->pktIds); /*0x1411a33f1*/
  Myhead = this->pktList._Mypair._Myval2._Myhead; /*0x1411a33f6*/
  Myhead->_Prev->_Next = nullptr; /*0x1411a3401*/
  Next = Myhead->_Next; /*0x1411a3404*/
  if ( Next != nullptr ) /*0x1411a340a*/
  {
    do /*0x1411a3423*/
    {
      v9 = Next->_Next; /*0x1411a3410*/
      operator delete(ptr: Next); /*0x1411a3418*/
      Next = v9; /*0x1411a341d*/
    }
    while ( v9 != nullptr ); /*0x1411a3423*/
  }
  v10 = this->pktList._Mypair._Myval2._Myhead; /*0x1411a3425*/
  memset(v22, 0, 32); /*0x1411a342f*/
  v10->_Next = v10; /*0x1411a3439*/
  v11 = this->pktList._Mypair._Myval2._Myhead; /*0x1411a343c*/
  memset(&v22[4], 0, 32); /*0x1411a3443*/
  v11->_Prev = v11; /*0x1411a344d*/
  this->pktList._Mypair._Myval2._Mysize = 0; /*0x1411a3451*/
  this->lastAck._Ptr = this->pktList._Mypair._Myval2._Myhead; /*0x1411a345f*/
  v12 = p_rttRangeQueue->m_size; /*0x1411a3466*/
  memset(&v22[8], 0, 64); /*0x1411a346a*/
  if ( v12 == 0 ) /*0x1411a348b*/
  {
    v13 = 0; /*0x1411a349d*/
    if ( p_rttRangeQueue->m_end - p_rttRangeQueue->m_buff == 0 ) /*0x1411a34a7*/
    {
      boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo>>::set_capacity( /*0x1411a34ae*/
        this: p_rttRangeQueue,
        new_capacity: 1u);
      v12 = p_rttRangeQueue->m_size; /*0x1411a34b3*/
      v13 = v12; /*0x1411a34b7*/
    }
    pos.m_buff = p_rttRangeQueue; /*0x1411a34ba*/
    pos.m_it = nullptr; /*0x1411a34bf*/
    if ( 1 != v12 ) /*0x1411a34c4*/
    {
      v14 = p_rttRangeQueue->m_end - p_rttRangeQueue->m_buff - ((__int64)((v12 - v13) << 7) >> 7); /*0x1411a34e3*/
      if ( v14 != 0 ) /*0x1411a34e6*/
      {
        wrapper.m_item = (const RakNet::CCRakNetSlidingWindow2::RttRangeInfo *)v22; /*0x1411a34fc*/
        if ( 1 - v12 <= v14 ) /*0x1411a3504*/
          v14 = 1 - v12; /*0x1411a3504*/
        boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo>>::insert_n<boost::cb_details::item_wrapper<RakNet::CCRakNetSlidingWindow2::RttRangeInfo const *,RakNet::CCRakNetSlidingWindow2::RttRangeInfo const &>>( /*0x1411a3510*/
          this: p_rttRangeQueue,
          &pos,
          n: v14,
          &wrapper);
      }
    }
    goto LABEL_30; /*0x1411a3515*/
  }
  v15 = v12 - 1; /*0x1411a351a*/
  pos.m_buff = p_rttRangeQueue; /*0x1411a351d*/
  pos.m_it = nullptr; /*0x1411a3522*/
  if ( v15 > 0 ) /*0x1411a352a*/
  {
    if ( v15 > p_rttRangeQueue->m_last - p_rttRangeQueue->m_buff ) /*0x1411a3540*/
      v15 -= p_rttRangeQueue->m_end - p_rttRangeQueue->m_buff; /*0x1411a354d*/
    v16 = &p_rttRangeQueue->m_last[-v15]; /*0x1411a3554*/
    pos.m_it = v16; /*0x1411a3557*/
LABEL_26:
    if ( v16 != nullptr ) /*0x1411a35aa*/
    {
      do /*0x1411a35cc*/
      {
        m_last = p_rttRangeQueue->m_last; /*0x1411a35b0*/
        if ( m_last == p_rttRangeQueue->m_buff ) /*0x1411a35b7*/
          m_last = p_rttRangeQueue->m_end; /*0x1411a35b9*/
        v19 = m_last - 1; /*0x1411a35bd*/
        p_rttRangeQueue->m_last = v19; /*0x1411a35c1*/
        --p_rttRangeQueue->m_size; /*0x1411a35c5*/
      }
      while ( v19 != v16 ); /*0x1411a35cc*/
    }
    goto LABEL_30; /*0x1411a35cc*/
  }
  if ( v15 < 0 ) /*0x1411a355e*/
  {
    v17 = -v15; /*0x1411a3563*/
    if ( -v15 >= 0 && v15 != 0 ) /*0x1411a3566*/
    {
      if ( v17 >= (__int64)p_rttRangeQueue->m_end >> 7 ) /*0x1411a3579*/
        v17 -= p_rttRangeQueue->m_end - p_rttRangeQueue->m_buff; /*0x1411a3582*/
      v16 = (RakNet::CCRakNetSlidingWindow2::RttRangeInfo *)(v17 << 7); /*0x1411a3585*/
      pos.m_it = v16; /*0x1411a3589*/
      if ( v16 != p_rttRangeQueue->m_last ) /*0x1411a3592*/
        goto LABEL_26; /*0x1411a3592*/
    }
  }
LABEL_30:
  this->ackedSeqenceTime = 0; /*0x1411a35ce*/
  this->ackedSeqenceTimeLast = 0; /*0x1411a35d7*/
  this->ackedSeqenceLast = -1; /*0x1411a35de*/
  this->targetSpeedStartBytes = 0; /*0x1411a35e8*/
  this->targetSpeedStartTime = 0; /*0x1411a35ef*/
  this->lastKnownPeakSpeed = 0; /*0x1411a35f6*/
  _InterlockedExchange(&this->applicationSpeedTarget._Storage._Value, DFInt::RakNetApplicationFeedbackInitialSpeedBPS); /*0x1411a3602*/
  this->operationState_startT0 = 0; /*0x1411a3608*/
  this->lastUpdateStartTargetSpeed = 0; /*0x1411a360c*/
  *(_QWORD *)&this->lastGetTransmissionBandwidthValue = 0; /*0x1411a3610*/
  this->lastGetTransmissionBandwidthTime = 0; /*0x1411a3617*/
  TimeUS = RakNet::GetTimeUS(isNetworkSynced: false); /*0x1411a361e*/
  this->appLimitedStartCount = 0; /*0x1411a3633*/
  *(_QWORD *)&this->pktCount = 0; /*0x1411a3639*/
  this->lastEventTime = 0; /*0x1411a363d*/
  this->getRttMicroMin_offsetLimit = 0; /*0x1411a3644*/
  this->appLimitedStart = TimeUS; /*0x1411a364b*/
}

// Address: 0x1411a3660 | Name: ?OnAck@CCRakNetSlidingWindow2@RakNet@@UEAAX_K0_NNNN1Uuint24_t@2@@Z
void __fastcall RakNet::CCRakNetSlidingWindow2::OnAck(
        RakNet::CCRakNetSlidingWindow2 *this,
        unsigned __int64 curTime,
        __int64 rtt,
        bool hasBAndAS,
        long double B,
        long double AS,
        long double totalUserDataBytesAcked,
        bool isContinuousSend,
        int *sequenceNumber)
{
  int v11; // r9d
  std::vector<std::pair<__int64,__int64>> *p_ackedSeqence; // rcx
  std::pair<__int64,__int64> *Mylast; // rdx
  std::_List_node<RakNet::PktInfo,void *> *Myhead; // rax
  double v15; // xmm0_8
  unsigned int val; // eax
  char v17; // cl
  double cwnd; // xmm1_8
  double ssThresh; // xmm2_8
  double v20; // xmm0_8
  long double v21; // xmm1_8
  std::pair<__int64,__int64> v22; // [rsp+20h] [rbp-18h] BYREF

  v11 = *sequenceNumber; /*0x1411a367d*/
  this->ackedSeqenceTime = curTime; /*0x1411a3680*/
  this->lastEventTime = curTime; /*0x1411a3687*/
  p_ackedSeqence = (std::vector<std::pair<__int64,__int64>> *)&this->ackedSeqence; /*0x1411a368e*/
  Mylast = (std::pair<__int64,__int64> *)this->ackedSeqence._Mypair._Myval2._Mylast; /*0x1411a3692*/
  Myhead = this->pktList._Mypair._Myval2._Myhead; /*0x1411a3699*/
  LODWORD(v22.first) = v11; /*0x1411a36a0*/
  v22.second = (__int64)Myhead; /*0x1411a36a5*/
  if ( Mylast == (std::pair<__int64,__int64> *)this->ackedSeqence._Mypair._Myval2._Myend ) /*0x1411a36b1*/
  {
    std::vector<std::pair<RBX::GfxPart *,int>>::_Emplace_reallocate<std::pair<RBX::GfxPart *,int>>( /*0x1411a36c7*/
      this: p_ackedSeqence,
      _Whereptr: Mylast,
      <_Val_0>: &v22);
  }
  else
  {
    *Mylast = v22; /*0x1411a36b8*/
    ++p_ackedSeqence->_Mypair._Myval2._Mylast; /*0x1411a36bb*/
  }
  if ( rtt < 0 ) /*0x1411a36d2*/
    v15 = (double)(int)(rtt & 1 | ((unsigned __int64)rtt >> 1)) + (double)(int)(rtt & 1 | ((unsigned __int64)rtt >> 1)); /*0x1411a36ec*/
  else
    v15 = (double)(int)rtt; /*0x1411a36d4*/
  this->RTT = v15; /*0x1411a36f5*/
  this->_isContinuousSend = isContinuousSend; /*0x1411a36fa*/
  if ( isContinuousSend ) /*0x1411a36ff*/
  {
    val = this->nextCongestionControlBlock.val; /*0x1411a3705*/
    if ( val == *sequenceNumber || ((val - *sequenceNumber) & 0xFFFFFF) <= 0x7FFFFF ) /*0x1411a371a*/
    {
      v17 = 0; /*0x1411a372c*/
    }
    else
    {
      v17 = 1; /*0x1411a371f*/
      this->nextCongestionControlBlock.val = this->nextDatagramSequenceNumber.val; /*0x1411a3721*/
      *(_WORD *)&this->backoffThisBlock = 0; /*0x1411a3724*/
    }
    cwnd = this->cwnd; /*0x1411a372e*/
    ssThresh = this->ssThresh; /*0x1411a3736*/
    if ( ssThresh < cwnd && ssThresh != 0.0 ) /*0x1411a3747*/
    {
      if ( v17 == 0 ) /*0x1411a374b*/
        return; /*0x1411a374b*/
      v20 = (double)(this->maxPayload * this->maxPayload) / cwnd + cwnd; /*0x1411a375f*/
      goto LABEL_20; /*0x1411a3763*/
    }
    if ( cwnd < 10000000.0 ) /*0x1411a3771*/
    {
      v21 = cwnd + cwnd; /*0x1411a3773*/
      this->cwnd = v21; /*0x1411a377b*/
      if ( v21 > ssThresh && ssThresh != 0.0 ) /*0x1411a3788*/
      {
        v20 = (double)(this->maxPayload * this->maxPayload) / ssThresh + ssThresh; /*0x1411a379c*/
LABEL_20:
        this->cwnd = v20; /*0x1411a37a0*/
      }
    }
  }
}

// Address: 0x1411a37c0 | Name: ?OnAckEnd@CCRakNetSlidingWindow2@RakNet@@UEAAXII@Z
void __fastcall RakNet::CCRakNetSlidingWindow2::OnAckEnd(
        RakNet::CCRakNetSlidingWindow2 *this,
        unsigned int ackedSeqenceOldestUnsentAck,
        unsigned int ackedSeqenceNewestUnsentAck)
{
  std::pair<unsigned int,std::_List_iterator<std::_List_val<std::_List_simple_types<RakNet::PktInfo> > > > *Myfirst; // r9
  unsigned int v4; // ebp
  unsigned int v5; // r15d
  signed __int64 ackedSeqenceTimeLast; // rsi
  char v8; // di
  unsigned __int64 v9; // r12
  int v10; // r10d
  unsigned __int64 ackedSeqenceTime; // r13
  unsigned int ackedSeqenceLast; // r14d
  __int64 v13; // r8
  std::_List_node<std::pair<unsigned int const ,std::_List_iterator<std::_List_val<std::_List_simple_types<RakNet::PktInfo> > > >,void *> *Myhead; // r11
  std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<unsigned int const ,std::_List_iterator<std::_List_val<std::_List_simple_types<RakNet::PktInfo> > > > > > > *v15; // rdx
  std::_List_node<std::pair<unsigned int const ,std::_List_iterator<std::_List_val<std::_List_simple_types<RakNet::PktInfo> > > >,void *> *Ptr; // rax
  unsigned int first; // ecx
  std::_List_node<std::pair<unsigned int const ,std::_List_iterator<std::_List_val<std::_List_simple_types<RakNet::PktInfo> > > >,void *> *v18; // rdx
  std::pair<unsigned int,std::_List_iterator<std::_List_val<std::_List_simple_types<RakNet::PktInfo> > > > *Mylast; // rdx
  __m128i *v20; // rcx
  std::pair<unsigned int,std::_List_iterator<std::_List_val<std::_List_simple_types<RakNet::PktInfo> > > > *v21; // r10
  signed __int64 v22; // r8
  __int64 v23; // r11
  _QWORD *v24; // rcx
  std::pair<unsigned int,std::_List_iterator<std::_List_val<std::_List_simple_types<RakNet::PktInfo> > > > *v25; // r8
  std::pair<unsigned int,std::_List_iterator<std::_List_val<std::_List_simple_types<RakNet::PktInfo> > > > *v26; // rdx
  std::pair<unsigned int,std::_List_iterator<std::_List_val<std::_List_simple_types<RakNet::PktInfo> > > > *v27; // rdx
  __int64 time; // r14
  std::_List_node<RakNet::PktInfo,void *> *v29; // rcx
  signed __int64 v30; // r15
  RakNet::PktInfo *PktInfo; // rax
  __int64 v32; // r8
  __int64 v33; // rbp
  std::pair<unsigned int,std::_List_iterator<std::_List_val<std::_List_simple_types<RakNet::PktInfo> > > > *v34; // rcx
  unsigned __int64 v35; // r13
  _DWORD *v36; // rax
  __int64 v37; // rcx
  signed __int64 v38; // r10
  int v39; // r8d
  int v40; // r11d
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *m_first; // rdi
  signed __int64 v42; // rdx
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *v43; // rdx
  __int64 v44; // rdx
  __int64 v45; // rax
  __int64 v46; // rdi
  std::_List_node<RakNet::PktInfo,void *> *v47; // rax
  __int64 v48; // rdx
  std::_List_node<RakNet::PktInfo,void *> *v49; // rcx
  std::_List_node<RakNet::PktInfo,void *> *Next; // rdx
  int packetsSentAll_lastAck; // r8d
  int bytesSentAll_lastAck; // r9d
  std::_List_node<RakNet::PktInfo,void *> *v53; // rcx
  RakNet::CCRakNetSlidingWindow2::sortAckedSeqence::__l2::<lambda_b19939354e7d8566f5223cff649a6f96> v54; // [rsp+80h] [rbp+8h]
  unsigned __int64 v55; // [rsp+80h] [rbp+8h]
  __int64 v58; // [rsp+98h] [rbp+20h]

  Myfirst = this->ackedSeqence._Mypair._Myval2._Myfirst; /*0x1411a37d2*/
  v4 = ackedSeqenceNewestUnsentAck; /*0x1411a37d9*/
  v5 = ackedSeqenceOldestUnsentAck; /*0x1411a37dc*/
  if ( Myfirst == this->ackedSeqence._Mypair._Myval2._Mylast ) /*0x1411a37e9*/
    return; /*0x1411a37e9*/
  ackedSeqenceTimeLast = this->ackedSeqenceTimeLast; /*0x1411a37f3*/
  v8 = 0; /*0x1411a37fe*/
  v9 = 0; /*0x1411a3805*/
  v10 = 0; /*0x1411a380c*/
  ackedSeqenceTime = this->ackedSeqenceTime; /*0x1411a380f*/
  ackedSeqenceLast = this->ackedSeqenceLast; /*0x1411a381a*/
  this->ackedSeqenceTimeLast = ackedSeqenceTime; /*0x1411a3821*/
  this->ackedSeqenceLast = this->ackedSeqence._Mypair._Myval2._Mylast[-1].first; /*0x1411a3832*/
  this->ackedSeqenceTime = 0; /*0x1411a3838*/
  if ( (int)(this->ackedSeqence._Mypair._Myval2._Mylast - Myfirst) <= 0 ) /*0x1411a384f*/
    goto LABEL_28; /*0x1411a384f*/
  v13 = 0; /*0x1411a3855*/
  do /*0x1411a3932*/
  {
    Myhead = this->pktIds._List._Mypair._Myval2._Myhead; /*0x1411a387b*/
    v15 = &this->pktIds._Vec._Mypair._Myval2._Myfirst[2 /*0x1411a38b5*/
                                                    * (this->pktIds._Mask
                                                     & (0x100000001B3LL
                                                      * (HIBYTE(Myfirst[v13].first)
                                                       ^ (0x100000001B3LL
                                                        * (BYTE2(Myfirst[v13].first)
                                                         ^ (0x100000001B3LL
                                                          * (BYTE1(Myfirst[v13].first)
                                                           ^ (0x100000001B3LL
                                                            * (LOBYTE(Myfirst[v13].first) ^ 0xCBF29CE484222325uLL)))))))))];
    Ptr = v15[1]._Ptr; /*0x1411a38bc*/
    if ( Ptr != Myhead ) /*0x1411a38c3*/
    {
      first = Myfirst[v13].first; /*0x1411a38c5*/
      v18 = v15->_Ptr; /*0x1411a38c9*/
      if ( first == Ptr->_Myval.first ) /*0x1411a38cf*/
      {
LABEL_8:
        if ( Ptr == nullptr ) /*0x1411a38e2*/
          Ptr = this->pktIds._List._Mypair._Myval2._Myhead; /*0x1411a38e2*/
        if ( Ptr != Myhead ) /*0x1411a38e9*/
        {
          this->ackedSeqence._Mypair._Myval2._Myfirst[v13].second._Ptr = Ptr->_Myval.second._Ptr; /*0x1411a38f6*/
          goto LABEL_13; /*0x1411a38fb*/
        }
      }
      else
      {
        while ( Ptr != v18 ) /*0x1411a38d4*/
        {
          Ptr = Ptr->_Prev; /*0x1411a38d6*/
          if ( first == Ptr->_Myval.first ) /*0x1411a38dd*/
            goto LABEL_8; /*0x1411a38dd*/
        }
      }
    }
    v8 = 1; /*0x1411a3904*/
    this->ackedSeqence._Mypair._Myval2._Myfirst[v13].second._Ptr = this->pktList._Mypair._Myval2._Myhead; /*0x1411a390e*/
LABEL_13:
    Myfirst = this->ackedSeqence._Mypair._Myval2._Myfirst; /*0x1411a3913*/
    ++v10; /*0x1411a391a*/
    ++v13; /*0x1411a3924*/
  }
  while ( v10 < (int)(this->ackedSeqence._Mypair._Myval2._Mylast - Myfirst) ); /*0x1411a3932*/
  v4 = ackedSeqenceNewestUnsentAck; /*0x1411a3938*/
  v5 = ackedSeqenceOldestUnsentAck; /*0x1411a393f*/
  if ( v8 != 0 ) /*0x1411a394a*/
  {
    Mylast = this->ackedSeqence._Mypair._Myval2._Mylast; /*0x1411a3950*/
    if ( Myfirst != Mylast ) /*0x1411a395a*/
    {
      do /*0x1411a398a*/
      {
        if ( (std::_List_node<RakNet::PktInfo,void *> *)_mm_srli_si128(*(__m128i *)Myfirst, 8).m128i_u64[0] == this->pktList._Mypair._Myval2._Myhead ) /*0x1411a3981*/
          break; /*0x1411a3981*/
        ++Myfirst; /*0x1411a3983*/
      }
      while ( Myfirst != Mylast ); /*0x1411a398a*/
      if ( Myfirst != Mylast ) /*0x1411a398f*/
      {
        v20 = (__m128i *)&Myfirst[1]; /*0x1411a3995*/
        if ( &Myfirst[1] != Mylast ) /*0x1411a399c*/
        {
          do /*0x1411a39ce*/
          {
            if ( (std::_List_node<RakNet::PktInfo,void *> *)_mm_srli_si128(*v20, 8).m128i_u64[0] != this->pktList._Mypair._Myval2._Myhead ) /*0x1411a39b4*/
            {
              Myfirst->first = v20->m128i_i32[0]; /*0x1411a39b8*/
              Myfirst->second._Ptr = (std::_List_node<RakNet::PktInfo,void *> *)v20->m128i_i64[1]; /*0x1411a39bf*/
              ++Myfirst; /*0x1411a39c3*/
            }
            ++v20; /*0x1411a39c7*/
          }
          while ( v20 != (__m128i *)Mylast ); /*0x1411a39ce*/
        }
        if ( Myfirst != Mylast ) /*0x1411a39d3*/
        {
          v21 = this->ackedSeqence._Mypair._Myval2._Mylast; /*0x1411a39d5*/
          if ( Mylast != v21 ) /*0x1411a39df*/
          {
            v22 = (char *)Mylast - (char *)Myfirst; /*0x1411a39e7*/
            v23 = (char *)Myfirst - (char *)Mylast + 8; /*0x1411a39ed*/
            do /*0x1411a3a0c*/
            {
              v24 = (_QWORD *)((char *)&Mylast->first + v23); /*0x1411a39f3*/
              Myfirst->first = Mylast->first; /*0x1411a39f7*/
              ++Mylast; /*0x1411a39fa*/
              ++Myfirst; /*0x1411a3a02*/
              *v24 = *(_QWORD *)((char *)v24 + v22); /*0x1411a3a06*/
            }
            while ( Mylast != v21 ); /*0x1411a3a0c*/
          }
          this->ackedSeqence._Mypair._Myval2._Mylast = Myfirst; /*0x1411a3a0e*/
        }
      }
    }
  }
LABEL_28:
  v25 = this->ackedSeqence._Mypair._Myval2._Mylast; /*0x1411a3a15*/
  v26 = this->ackedSeqence._Mypair._Myval2._Myfirst; /*0x1411a3a1c*/
  if ( v26 != v25 ) /*0x1411a3a26*/
  {
    v27 = v26 + 1; /*0x1411a3a2c*/
    if ( v27 != v25 ) /*0x1411a3a33*/
    {
      while ( v27->second._Ptr->_Myval.time >= v27[-1].second._Ptr->_Myval.time ) /*0x1411a3a50*/
      {
        if ( ++v27 == v25 ) /*0x1411a3a59*/
          goto LABEL_34; /*0x1411a3a59*/
      }
      std::_Sort_unchecked_std::pair_unsigned_int_std::_List_iterator_std::_List_val_std::_List_simple_types_RakNet::PktInfo___________lambda_b19939354e7d8566f5223cff649a6f96___( /*0x1411a3a7e*/
        _First: this->ackedSeqence._Mypair._Myval2._Myfirst,
        _Last: this->ackedSeqence._Mypair._Myval2._Mylast,
        _Ideal: this->ackedSeqence._Mypair._Myval2._Mylast - this->ackedSeqence._Mypair._Myval2._Myfirst,
        _Pred: v54);
    }
LABEL_34:
    if ( v5 != 0 && v4 != 0 ) /*0x1411a3a8a*/
    {
      time = this->ackedSeqence._Mypair._Myval2._Myfirst->second._Ptr->_Myval.time; /*0x1411a3a9e*/
      v29 = this->ackedSeqence._Mypair._Myval2._Mylast[-1].second._Ptr; /*0x1411a3aa2*/
      v30 = ackedSeqenceTime - v5; /*0x1411a3aac*/
      ackedSeqenceTime -= v4; /*0x1411a3ab1*/
    }
    else
    {
      if ( ackedSeqenceTimeLast == 0 /*0x1411a3ae0*/
        || (__int64)(ackedSeqenceTime - ackedSeqenceTimeLast) >= 30000
        || (PktInfo = RakNet::CCRakNetSlidingWindow2::findPktInfo(this, id: ackedSeqenceLast)) == nullptr
        || (time = PktInfo->time) == 0 )
      {
        ackedSeqenceTimeLast = ackedSeqenceTime - 10000; /*0x1411a3ae9*/
        time = this->ackedSeqence._Mypair._Myval2._Myfirst->second._Ptr->_Myval.time; /*0x1411a3af4*/
      }
      v30 = time + 1; /*0x1411a3aff*/
      if ( ackedSeqenceTimeLast >= time ) /*0x1411a3b06*/
        v30 = ackedSeqenceTimeLast; /*0x1411a3b06*/
      v29 = this->ackedSeqence._Mypair._Myval2._Mylast[-1].second._Ptr; /*0x1411a3b0a*/
    }
    v32 = v29->_Myval.time; /*0x1411a3b0e*/
    v33 = 0; /*0x1411a3b12*/
    v34 = this->ackedSeqence._Mypair._Myval2._Myfirst; /*0x1411a3b15*/
    v55 = ackedSeqenceTime; /*0x1411a3b26*/
    v35 = 0; /*0x1411a3b32*/
    v58 = v32; /*0x1411a3b35*/
    if ( this->ackedSeqence._Mypair._Myval2._Mylast - v34 != 0 ) /*0x1411a3b40*/
    {
      do /*0x1411a3c94*/
      {
        v36 = (unsigned int *)((char *)&v34->first + v9); /*0x1411a3b50*/
        v37 = *(__int64 *)((char *)&v34->second._Ptr + v9); /*0x1411a3b54*/
        if ( *(_QWORD *)(v37 + 32) != 0 ) /*0x1411a3b5e*/
        {
          *v36 = -1; /*0x1411a3b60*/
        }
        else
        {
          ++this->ackCount; /*0x1411a3b6b*/
          v38 = v30; /*0x1411a3b71*/
          if ( v32 != time ) /*0x1411a3b77*/
            v38 = v30 + (__int64)((v55 - v30) * (*(_QWORD *)(v37 + 24) - time)) / (v32 - time); /*0x1411a3b97*/
          if ( *(_QWORD *)(v37 + 40) != 0 ) /*0x1411a3ba0*/
          {
            *(_QWORD *)(v37 + 40) = 0; /*0x1411a3ba6*/
            --this->packetsNak; /*0x1411a3bae*/
            this->bytesNak -= *(_DWORD *)(v37 + 20); /*0x1411a3bb7*/
            v39 = LODWORD(this->rttRangeQueue.m_size) - 1; /*0x1411a3bc4*/
            v40 = *(_DWORD *)(v37 + 16); /*0x1411a3bc8*/
            if ( v39 >= 0 ) /*0x1411a3bcc*/
            {
              m_first = this->rttRangeQueue.m_first; /*0x1411a3bd5*/
              while ( 1 ) /*0x1411a3be6*/
              {
                v42 = v39; /*0x1411a3be6*/
                if ( v39 >= this->rttRangeQueue.m_end - m_first ) /*0x1411a3bec*/
                  v42 = v39 - (this->rttRangeQueue.m_end - this->rttRangeQueue.m_buff); /*0x1411a3bfc*/
                v43 = &m_first[v42]; /*0x1411a3c03*/
                if ( v43->packetsSent != 0 && v40 >= v43->countStart ) /*0x1411a3c0f*/
                  break; /*0x1411a3c0f*/
                if ( --v39 < 0 ) /*0x1411a3c15*/
                  goto LABEL_61; /*0x1411a3c15*/
              }
              if ( v40 <= v43->countEnd ) /*0x1411a3c1d*/
              {
                --v43->packetsNak; /*0x1411a3c1f*/
                v43->bytesNak -= *(_DWORD *)(v37 + 20); /*0x1411a3c25*/
              }
            }
          }
LABEL_61:
          v44 = *(_QWORD *)(v37 + 24); /*0x1411a3c28*/
          if ( v38 > v44 && (v33 > v38 - v44 || v33 == 0) ) /*0x1411a3c3f*/
            v33 = v38 - v44; /*0x1411a3c41*/
          *(_QWORD *)(v37 + 32) = v38; /*0x1411a3c44*/
          ++this->packetsAck; /*0x1411a3c48*/
          this->bytesAck += *(_DWORD *)(v37 + 20); /*0x1411a3c51*/
          this->bytesAckTotal += *(int *)(v37 + 20); /*0x1411a3c5b*/
          *(_QWORD *)(v37 + 64) = this->bytesAckTotal; /*0x1411a3c69*/
        }
        v34 = this->ackedSeqence._Mypair._Myval2._Myfirst; /*0x1411a3c6d*/
        ++v35; /*0x1411a3c74*/
        v9 += 16LL; /*0x1411a3c7e*/
        v32 = v58; /*0x1411a3c82*/
      }
      while ( v35 < this->ackedSeqence._Mypair._Myval2._Mylast - v34 ); /*0x1411a3c94*/
      v9 = 0; /*0x1411a3c9a*/
    }
    v45 = 1; /*0x1411a3c9d*/
    if ( v33 > 1 ) /*0x1411a3ca5*/
      v45 = v33; /*0x1411a3ca5*/
    this->rttMicro = v45; /*0x1411a3cac*/
    if ( v33 <= 0 ) /*0x1411a3cb8*/
      v33 = 5000; /*0x1411a3cb8*/
    if ( this->ackedSeqence._Mypair._Myval2._Mylast - v34 != 0 ) /*0x1411a3ccd*/
    {
      v46 = 0; /*0x1411a3cd3*/
      while ( v34[v46].first == -1 ) /*0x1411a3cda*/
      {
LABEL_88:
        v34 = this->ackedSeqence._Mypair._Myval2._Myfirst; /*0x1411a3dc8*/
        ++v9; /*0x1411a3dcf*/
        ++v46; /*0x1411a3dd9*/
        if ( v9 >= this->ackedSeqence._Mypair._Myval2._Mylast - v34 ) /*0x1411a3de7*/
          goto LABEL_89; /*0x1411a3de7*/
      }
      v47 = v34[v46].second._Ptr; /*0x1411a3ce0*/
      v48 = v47->_Myval.time; /*0x1411a3ce5*/
      if ( v33 > v47->_Myval.ackTime - v48 ) /*0x1411a3cf3*/
        v47->_Myval.ackTime = v48 + v33; /*0x1411a3cf9*/
      v49 = this->pktList._Mypair._Myval2._Myhead; /*0x1411a3cfd*/
      Next = this->lastAck._Ptr; /*0x1411a3d04*/
      if ( Next == v49 ) /*0x1411a3d0e*/
      {
        Next = v49->_Next; /*0x1411a3d1e*/
        ++this->packetsSentAll_lastAck; /*0x1411a3d21*/
        this->lastAck._Ptr = Next; /*0x1411a3d27*/
        this->bytesSentAll_lastAck += Next->_Myval.size; /*0x1411a3d31*/
        if ( Next->_Myval.id != -1 ) /*0x1411a3d3b*/
        {
          ++this->packetsSent_lastAck; /*0x1411a3d3d*/
          this->bytesSent_lastAck += Next->_Myval.size; /*0x1411a3d46*/
        }
LABEL_82:
        if ( Next != v47 ) /*0x1411a3d4f*/
        {
          packetsSentAll_lastAck = this->packetsSentAll_lastAck; /*0x1411a3d51*/
          bytesSentAll_lastAck = this->bytesSentAll_lastAck; /*0x1411a3d58*/
          do /*0x1411a3d9a*/
          {
            v53 = Next->_Next; /*0x1411a3d60*/
            ++packetsSentAll_lastAck; /*0x1411a3d63*/
            this->lastAck._Ptr = Next->_Next; /*0x1411a3d66*/
            Next = v53; /*0x1411a3d6d*/
            this->packetsSentAll_lastAck = packetsSentAll_lastAck; /*0x1411a3d70*/
            bytesSentAll_lastAck += v53->_Myval.size; /*0x1411a3d77*/
            this->bytesSentAll_lastAck = bytesSentAll_lastAck; /*0x1411a3d7b*/
            if ( v53->_Myval.id != -1 ) /*0x1411a3d86*/
            {
              ++this->packetsSent_lastAck; /*0x1411a3d88*/
              this->bytesSent_lastAck += v53->_Myval.size; /*0x1411a3d91*/
            }
          }
          while ( v53 != v47 ); /*0x1411a3d9a*/
        }
      }
      else if ( v47->_Myval.count > Next->_Myval.count ) /*0x1411a3d16*/
      {
        goto LABEL_82; /*0x1411a3d16*/
      }
      RakNet::CCRakNetSlidingWindow2::updateRangeAck( /*0x1411a3dc3*/
        this,
        rttRangeQueue: &this->rttRangeQueue,
        id: v47->_Myval.id,
        size: v47->_Myval.size,
        time: v47->_Myval.ackTime,
        rttMicro: v47->_Myval.ackTime - v47->_Myval.time);
      goto LABEL_88; /*0x1411a3dc3*/
    }
LABEL_89:
    this->ackedSeqence._Mypair._Myval2._Mylast = v34; /*0x1411a3ded*/
  }
}

// Address: 0x1411a3e30 | Name: ?OnGotPacket@CCRakNetSlidingWindow2@RakNet@@UEAA_NUuint24_t@2@_N_KIPEAI@Z
char __fastcall RakNet::CCRakNetSlidingWindow2::OnGotPacket(
        RakNet::CCRakNetSlidingWindow2 *this,
        int *datagramSequenceNumber,
        bool isContinuousSend,
        unsigned __int64 curTime,
        unsigned int sizeInBytes,
        unsigned int *skippedMessageCount)
{
  int v6; // r8d
  unsigned int val; // r9d
  unsigned int v9; // r8d

  if ( this->oldestUnsentAck == 0 ) /*0x1411a3e35*/
    this->oldestUnsentAck = curTime; /*0x1411a3e37*/
  this->newestUnsentAck = curTime; /*0x1411a3e3b*/
  v6 = *datagramSequenceNumber; /*0x1411a3e3f*/
  val = this->expectedNextSequenceNumber.val; /*0x1411a3e42*/
  if ( *datagramSequenceNumber == val ) /*0x1411a3e49*/
  {
    *skippedMessageCount = 0; /*0x1411a3e50*/
    this->expectedNextSequenceNumber.val = (*datagramSequenceNumber + 1) & 0xFFFFFF; /*0x1411a3e5f*/
    return 1; /*0x1411a3e64*/
  }
  if ( ((val - v6) & 0xFFFFFF) <= 0x7FFFFF ) /*0x1411a3e7a*/
  {
    *skippedMessageCount = 0; /*0x1411a3eb3*/
    return 1; /*0x1411a3eb9*/
  }
  else
  {
    v9 = (v6 - val) & 0xFFFFFF; /*0x1411a3e7f*/
    *skippedMessageCount = v9; /*0x1411a3e86*/
    if ( v9 > 0x3E8 ) /*0x1411a3e90*/
    {
      if ( v9 > 0xC350 ) /*0x1411a3e99*/
        return 0; /*0x1411a3e9d*/
      *skippedMessageCount = 1000; /*0x1411a3e9e*/
    }
    this->expectedNextSequenceNumber.val = (*datagramSequenceNumber + 1) & 0xFFFFFF; /*0x1411a3ead*/
    return 1; /*0x1411a3eb0*/
  }
}

// Address: 0x1411a3ec0 | Name: ?OnNAK@CCRakNetSlidingWindow2@RakNet@@UEAAX_KUuint24_t@2@@Z
void __fastcall RakNet::CCRakNetSlidingWindow2::OnNAK(
        RakNet::CCRakNetSlidingWindow2 *this,
        __int64 curTime,
        signed int *nakSequenceNumber)
{
  signed int v3; // edi
  RakNet::PktInfo *PktInfo; // rax
  __int64 v7; // r8
  RakNet::PktInfo *v8; // r9
  int v9; // edx
  int size; // ebp
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *m_first; // r10
  signed __int64 v12; // rax
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *v13; // rax

  v3 = *nakSequenceNumber; /*0x1411a3ecf*/
  ++this->nakCount; /*0x1411a3ed5*/
  PktInfo = RakNet::CCRakNetSlidingWindow2::findPktInfo(this, id: v3); /*0x1411a3ee0*/
  v8 = PktInfo; /*0x1411a3ee5*/
  if ( PktInfo != nullptr && PktInfo->nakTime == 0 ) /*0x1411a3ef6*/
  {
    PktInfo->nakTime = curTime; /*0x1411a3efc*/
    this->lastEventTime = curTime; /*0x1411a3f00*/
    v9 = LODWORD(this->rttRangeQueue.m_size) - 1; /*0x1411a3f0d*/
    size = PktInfo->size; /*0x1411a3f15*/
    if ( v9 >= 0 ) /*0x1411a3f18*/
    {
      m_first = this->rttRangeQueue.m_first; /*0x1411a3f21*/
      v7 = this->rttRangeQueue.m_end - m_first; /*0x1411a3f2e*/
      while ( 1 ) /*0x1411a3f32*/
      {
        v12 = v9; /*0x1411a3f32*/
        if ( v9 >= v7 ) /*0x1411a3f38*/
          v12 = v9 - (this->rttRangeQueue.m_end - this->rttRangeQueue.m_buff); /*0x1411a3f48*/
        v13 = &m_first[v12]; /*0x1411a3f4f*/
        if ( v13->packetsSent != 0 && v3 >= v13->countStart ) /*0x1411a3f5a*/
          break; /*0x1411a3f5a*/
        if ( --v9 < 0 ) /*0x1411a3f5f*/
          goto LABEL_13; /*0x1411a3f5f*/
      }
      if ( v3 <= v13->countEnd ) /*0x1411a3f66*/
      {
        v13->bytesNak += size; /*0x1411a3f68*/
        ++v13->packetsNak; /*0x1411a3f6b*/
      }
    }
LABEL_13:
    ++this->packetsNak; /*0x1411a3f6e*/
    this->bytesNak += v8->size; /*0x1411a3f78*/
  }
  ((void (__fastcall *)(RakNet::CCRakNetSlidingWindow2 *, __int64, __int64, RakNet::PktInfo *))this->OnResend)( /*0x1411a3f9b*/
    a1: this,
    a2: curTime,
    a3: v7,
    a4: v8);
}

// Address: 0x1411a3fa0 | Name: ?OnResend@CCRakNetSlidingWindow2@RakNet@@UEAAX_K@Z
void __fastcall RakNet::CCRakNetSlidingWindow2::OnResend(
        RakNet::CCRakNetSlidingWindow2 *this,
        unsigned __int64 curTime)
{
  int maxPayload; // edx
  double cwnd; // xmm1_8
  long double v4; // xmm1_8
  double v5; // xmm0_8

  if ( this->_isContinuousSend && !this->backoffThisBlock ) /*0x1411a3faa*/
  {
    maxPayload = this->maxPayload; /*0x1411a3fac*/
    cwnd = this->cwnd; /*0x1411a3faf*/
    if ( cwnd > (double)(2 * maxPayload) ) /*0x1411a3fc3*/
    {
      v4 = cwnd * 0.5; /*0x1411a3fc5*/
      v5 = (double)maxPayload; /*0x1411a3fd1*/
      this->ssThresh = v4; /*0x1411a3fd5*/
      if ( (double)maxPayload > v4 ) /*0x1411a3fde*/
        this->ssThresh = v5; /*0x1411a3fe0*/
      this->cwnd = v5; /*0x1411a3fe5*/
      this->backoffThisBlock = true; /*0x1411a3fea*/
    }
  }
}

// Address: 0x1411a3ff0 | Name: ?OnSendAck@CCRakNetSlidingWindow2@RakNet@@UEAAX_KI@Z
void __fastcall RakNet::CCRakNetSlidingWindow2::OnSendAck(
        RakNet::CCRakNetSlidingWindow2 *this,
        unsigned __int64 curTime,
        unsigned int numBytes)
{
  this->oldestUnsentAck = 0; /*0x1411a3ff2*/
  this->newestUnsentAck = 0; /*0x1411a3ff6*/
}

// Address: 0x1411a4000 | Name: ?OnSendAckGetBAndAS@CCRakNetSlidingWindow2@RakNet@@UEAAX_KPEA_NPEAN2@Z
void __fastcall RakNet::CCRakNetSlidingWindow2::OnSendAckGetBAndAS(
        RakNet::CCRakNetSlidingWindow *this,
        unsigned __int64 curTime,
        bool *hasBAndAS,
        long double *B)
{
  *hasBAndAS = false; /*0x1411a4000*/
}

// Address: 0x1411a4010 | Name: ?OnSendBytes@CCRakNetSlidingWindow2@RakNet@@UEAAX_KPEBDH_N@Z
void __fastcall RakNet::CCRakNetSlidingWindow2::OnSendBytes(
        RakNet::CCRakNetSlidingWindow2 *this,
        __int64 curTime,
        char *data,
        int size,
        unsigned int addCryptoOverhead)
{
  int v7; // ebx
  bool v8; // r14
  bool v9; // r15
  bool v10; // bp
  unsigned int readOffset; // r9d
  char v12; // cl
  unsigned __int8 v13; // r8
  unsigned int v14; // edx
  char v15; // cl
  unsigned __int8 v16; // r8
  unsigned int v17; // r8d
  char v18; // cl
  unsigned __int8 v19; // dl
  int v20; // ecx
  RakNet::BitStream bs; // [rsp+20h] [rbp-148h] BYREF

  v7 = size + 18; /*0x1411a403a*/
  if ( (_BYTE)addCryptoOverhead == 0 ) /*0x1411a4046*/
    v7 = size; /*0x1411a4046*/
  if ( size <= 4 ) /*0x1411a404e*/
    goto LABEL_22; /*0x1411a404e*/
  v8 = false; /*0x1411a4054*/
  v9 = false; /*0x1411a4057*/
  v10 = false; /*0x1411a405a*/
  RakNet::BitStream::BitStream(this: &bs, _data: (unsigned __int8 *)data, lengthInBytes: 4u, _copyData: false); /*0x1411a406c*/
  readOffset = bs.readOffset; /*0x1411a4072*/
  if ( bs.readOffset + 1 <= bs.numberOfBitsUsed ) /*0x1411a408e*/
  {
    v12 = bs.readOffset & 7; /*0x1411a4093*/
    v13 = bs.data[(unsigned __int64)bs.readOffset >> 3]; /*0x1411a409d*/
    readOffset = ++bs.readOffset; /*0x1411a40a2*/
    v8 = ((unsigned __int8)(128 >> v12) & v13) != 0; /*0x1411a40b1*/
  }
  v14 = readOffset + 1; /*0x1411a40b5*/
  if ( readOffset + 1 <= bs.numberOfBitsUsed ) /*0x1411a40bc*/
  {
    v15 = readOffset & 7; /*0x1411a40c1*/
    v16 = bs.data[(unsigned __int64)readOffset++ >> 3]; /*0x1411a40cb*/
    bs.readOffset = v14; /*0x1411a40d3*/
    v9 = ((unsigned __int8)(128 >> v15) & v16) != 0; /*0x1411a40df*/
  }
  v17 = readOffset + 1; /*0x1411a40e3*/
  if ( readOffset + 1 <= bs.numberOfBitsUsed ) /*0x1411a40ea*/
  {
    v18 = readOffset & 7; /*0x1411a40ef*/
    v19 = bs.data[(unsigned __int64)readOffset++ >> 3]; /*0x1411a40f9*/
    bs.readOffset = v17; /*0x1411a4101*/
    v10 = ((unsigned __int8)(128 >> v18) & v19) != 0; /*0x1411a410c*/
  }
  if ( !v8 || v9 || v10 ) /*0x1411a4125*/
  {
    RakNet::BitStream::~BitStream(this: &bs); /*0x1411a4216*/
LABEL_22:
    RakNet::CCRakNetSlidingWindow2::addPkt(this, id: 0xFFFFFFFF, size: v7, time: curTime); /*0x1411a421b*/
    return; /*0x1411a424f*/
  }
  __wind /*0xf1c0000000000010*/
  {
    v20 = readOffset - (((_BYTE)readOffset - 1) & 7) + 7 - (((_BYTE)readOffset - (((_BYTE)readOffset - 1) & 7) + 6) & 7); /*0x1411a413f*/
    bs.readOffset = v20 + 7; /*0x1411a4144*/
    if ( v20 + 31 <= bs.numberOfBitsUsed ) /*0x1411a414e*/
    {
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1411a4154*/
      {
        HIBYTE(addCryptoOverhead) = bs.data[(unsigned __int64)bs.readOffset >> 3]; /*0x1411a41b6*/
        BYTE2(addCryptoOverhead) = bs.data[(bs.readOffset >> 3) + 1]; /*0x1411a41c8*/
        BYTE1(addCryptoOverhead) = bs.data[(bs.readOffset >> 3) + 2]; /*0x1411a41d7*/
        LOBYTE(addCryptoOverhead) = 0; /*0x1411a41de*/
      }
      else
      {
        LOBYTE(addCryptoOverhead) = bs.data[(unsigned __int64)bs.readOffset >> 3]; /*0x1411a4176*/
        BYTE1(addCryptoOverhead) = bs.data[(bs.readOffset >> 3) + 1]; /*0x1411a4188*/
        HIWORD(addCryptoOverhead) = bs.data[(bs.readOffset >> 3) + 2]; /*0x1411a4197*/
      }
      bs.readOffset += 24; /*0x1411a41ea*/
    }
    RakNet::CCRakNetSlidingWindow2::addPkt(this, id: addCryptoOverhead, size: v7, time: curTime); /*0x1411a41ff*/
  }
  __unwind
  {
    RakNet::BitStream::~BitStream(this: &bs); /*0xf1c0000000000008*/
  }
  RakNet::BitStream::~BitStream(this: &bs); /*0x1411a420a*/
}

// Address: 0x1411a4250 | Name: ?ShouldSendACKs@CCRakNetSlidingWindow2@RakNet@@UEAA_N_K0@Z
bool __fastcall RakNet::CCRakNetSlidingWindow2::ShouldSendACKs(
        RakNet::CCRakNetSlidingWindow *this,
        unsigned __int64 curTime,
        unsigned __int64 estimatedTimeToNextTick)
{
  double RTT; // xmm0_8
  double v4; // xmm0_8
  unsigned __int64 v5; // r8

  RTT = this->RTT; /*0x1411a4250*/
  if ( RTT == -1.0 ) /*0x1411a425f*/
    return true; /*0x1411a425f*/
  v4 = RTT + 10000.0; /*0x1411a4261*/
  v5 = 0; /*0x1411a4271*/
  if ( v4 >= 9.223372036854776e18 ) /*0x1411a4278*/
  {
    v4 = v4 - 9.223372036854776e18; /*0x1411a427a*/
    if ( v4 < 9.223372036854776e18 ) /*0x1411a4282*/
      v5 = 0x8000000000000000uLL; /*0x1411a428e*/
  }
  return v5 + (unsigned int)(int)v4 == -1 || curTime >= this->oldestUnsentAck + 10000; /*0x1411a42b0*/
}

// Address: 0x1411a42c0 | Name: ?Update@CCRakNetSlidingWindow2@RakNet@@UEAAX_K@Z
void __fastcall RakNet::CCRakNetSlidingWindow2::Update(
        RakNet::CCRakNetSlidingWindow2 *this,
        unsigned __int64 appLevelBps)
{
  int targetSpeed; // r8d
  unsigned __int64 lastKnownPeakSpeed; // r10

  if ( DFFlag::RakNetCalculateApplicationFeedback2.value ) /*0x1411a42ca*/
  {
    if ( this->appLimitedStart != 0 ) /*0x1411a42d8*/
    {
      lastKnownPeakSpeed = this->lastKnownPeakSpeed; /*0x1411a42ea*/
      if ( (_DWORD)lastKnownPeakSpeed != 0 ) /*0x1411a42f4*/
      {
        targetSpeed = this->lastKnownPeakSpeed; /*0x1411a4306*/
        if ( DFInt::RakNetApplicationFeedbackScaleUpFactorHundredthPercent > 0 /*0x1411a4336*/
          && appLevelBps * DFInt::RakNetApplicationFeedbackScaleUpThresholdPercent / 0x64 >= lastKnownPeakSpeed )
        {
          targetSpeed = lastKnownPeakSpeed /*0x1411a4353*/
                      + DFInt::RakNetApplicationFeedbackScaleUpFactorHundredthPercent * (int)lastKnownPeakSpeed / 10000;
          this->lastKnownPeakSpeed = targetSpeed; /*0x1411a4356*/
        }
      }
      else
      {
        targetSpeed = this->targetSpeed; /*0x1411a42f6*/
      }
    }
    else
    {
      targetSpeed = this->targetSpeed; /*0x1411a42da*/
      this->lastKnownPeakSpeed = targetSpeed; /*0x1411a42e1*/
    }
    if ( DFInt::RakNetApplicationFeedbackMaxSpeedBPS > 0 ) /*0x1411a4365*/
    {
      if ( DFInt::RakNetApplicationFeedbackMaxSpeedBPS < targetSpeed ) /*0x1411a436a*/
        targetSpeed = DFInt::RakNetApplicationFeedbackMaxSpeedBPS; /*0x1411a436a*/
      _InterlockedExchange(&this->applicationSpeedTarget._Storage._Value, targetSpeed); /*0x1411a436e*/
    }
  }
}

// Address: 0x1411a4380 | Name: ?ackSpeed_last4@CCRakNetSlidingWindow2@RakNet@@AEAAHXZ
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(RakNet::CCRakNetSlidingWindow2 *this)
{
  unsigned __int64 m_size; // rax
  int ackSpeed; // edi
  int v4; // r11d
  int v5; // ebx
  unsigned int ackSpeed_last4_offsetLimit; // ecx
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *m_end; // r8
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *m_first; // rsi
  __int64 v9; // rax
  __int64 v10; // r10
  __int64 v11; // r9
  __int64 v12; // r9
  int v13; // ecx

  m_size = this->rttRangeQueue.m_size; /*0x1411a4386*/
  ackSpeed = -1; /*0x1411a4390*/
  if ( m_size >= 2 ) /*0x1411a4399*/
  {
    v4 = 0; /*0x1411a439f*/
    v5 = m_size - 2; /*0x1411a43a2*/
    if ( (int)m_size - 2 >= 0 ) /*0x1411a43a7*/
    {
      do /*0x1411a445f*/
      {
        if ( v4 >= 4 ) /*0x1411a43b6*/
          break; /*0x1411a43b6*/
        ackSpeed_last4_offsetLimit = this->ackSpeed_last4_offsetLimit; /*0x1411a43bc*/
        if ( ackSpeed_last4_offsetLimit != 0 /*0x1411a43cd*/
          && v5 < (int)(LODWORD(this->rttRangeQueue.m_size) - ackSpeed_last4_offsetLimit) )
        {
          break; /*0x1411a43cd*/
        }
        m_end = this->rttRangeQueue.m_end; /*0x1411a43d3*/
        m_first = this->rttRangeQueue.m_first; /*0x1411a43da*/
        v9 = v5; /*0x1411a43e7*/
        v10 = m_end - m_first; /*0x1411a43ea*/
        v11 = v5; /*0x1411a43ee*/
        if ( v5 >= v10 ) /*0x1411a43f4*/
          v11 = v5 - (m_end - this->rttRangeQueue.m_buff); /*0x1411a4404*/
        if ( ackSpeed < m_first[v11].ackSpeed ) /*0x1411a4410*/
        {
          v12 = v5; /*0x1411a4412*/
          if ( v5 >= v10 ) /*0x1411a4418*/
            v12 = v5 - (m_end - this->rttRangeQueue.m_buff); /*0x1411a4428*/
          ackSpeed = m_first[v12].ackSpeed; /*0x1411a442f*/
        }
        if ( v5 >= v10 ) /*0x1411a4437*/
          v9 = v5 - (m_end - this->rttRangeQueue.m_buff); /*0x1411a4444*/
        v13 = v4 - 1; /*0x1411a444b*/
        if ( !m_first[v9].appLimited ) /*0x1411a4454*/
          v13 = v4; /*0x1411a4454*/
        --v5; /*0x1411a4458*/
        v4 = v13 + 1; /*0x1411a445b*/
      }
      while ( v5 >= 0 ); /*0x1411a445f*/
      if ( ackSpeed > 0x8000 ) /*0x1411a4470*/
        ackSpeed -= ackSpeed / 64; /*0x1411a447d*/
    }
  }
  return (unsigned int)ackSpeed; /*0x1411a447f*/
}

// Address: 0x1411a4490 | Name: ?addPkt@CCRakNetSlidingWindow2@RakNet@@AEAAXIH_J@Z
void __fastcall RakNet::CCRakNetSlidingWindow2::addPkt(
        RakNet::CCRakNetSlidingWindow2 *this,
        unsigned int id,
        int size,
        __int64 time)
{
  int v6; // ebp
  __int64 v7; // r8
  std::_List_node<RakNet::PktInfo,void *> *Myhead; // r14
  std::_List_node<RakNet::PktInfo,void *> *v9; // rax
  std::_List_node<RakNet::PktInfo,void *> *Prev; // rcx
  webrtc::RtpRtcp *v11; // rdi
  std::_Hash<std::_Umap_traits<unsigned int,webrtc::RtpRtcp *,std::_Uhash_compare<unsigned int,std::hash<unsigned int>,std::equal_to<unsigned int> >,std::allocator<std::pair<unsigned int const ,webrtc::RtpRtcp *> >,0> > *p_pktIds; // rcx
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *m_last; // rax
  unsigned __int64 m_size; // rdx
  __int64 timeSentFirst; // rsi
  __int64 v16; // rcx
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *m_first; // r10
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *m_end; // rdx
  __int64 v19; // r9
  __int64 v20; // r8
  std::pair<std::_List_node<std::pair<unsigned int const ,webrtc::RtpRtcp *>,void *> *,bool> result; // [rsp+20h] [rbp-78h] BYREF
  RakNet::PktInfo pi; // [rsp+30h] [rbp-68h]
  unsigned int _Keyval_arg; // [rsp+A8h] [rbp+10h] BYREF

  _Keyval_arg = id; /*0x1411a449a*/
  v6 = size + 40; /*0x1411a44b4*/
  if ( id != -1 ) /*0x1411a44bb*/
  {
    this->lastEventTime = time; /*0x1411a44c1*/
    this->lastGetTransmissionBandwidthSent += v6; /*0x1411a44c8*/
    this->targetSpeedStartBytes += v6; /*0x1411a44d1*/
    this->bytesSent += v6; /*0x1411a44d8*/
    v7 = v6 + this->bytesSentTotal; /*0x1411a44e5*/
    this->bytesSentTotal = v7; /*0x1411a44e8*/
    ++this->packetsSent; /*0x1411a44ef*/
    if ( this->targetSpeedStartTime == 0 ) /*0x1411a44fe*/
    {
      this->targetSpeedStartTime = time; /*0x1411a4500*/
      this->targetSpeedStartBytes = 0; /*0x1411a4507*/
      this->operationState_startT0 = 0; /*0x1411a450e*/
    }
    pi.id = id; /*0x1411a4512*/
    pi.size = v6; /*0x1411a4516*/
    pi.time = time; /*0x1411a451a*/
    pi.count = this->pktCount; /*0x1411a4525*/
    this->pktCount = pi.count + 1; /*0x1411a452b*/
    pi.bytesSentTotal = v7; /*0x1411a452e*/
    pi.bytesAckTotal = 0; /*0x1411a4535*/
    Myhead = this->pktList._Mypair._Myval2._Myhead; /*0x1411a4541*/
    if ( this->pktList._Mypair._Myval2._Mysize == 0x38E38E38E38E38ELL ) /*0x1411a4552*/
      std::_Xlength_error(a1: "list too long"); /*0x1411a46f6*/
    result.first = (std::_List_node<std::pair<unsigned int const ,webrtc::RtpRtcp *>,void *> *)&this->pktList; /*0x1411a4558*/
    *(_QWORD *)&result.second = 0; /*0x1411a455d*/
    __wind /*0xf1c0000000000010*/
    {
      v9 = (std::_List_node<RakNet::PktInfo,void *> *)operator new(size: 0x48u); /*0x1411a4567*/
      *(_OWORD *)&v9->_Myval.id = *(_OWORD *)&pi.id; /*0x1411a4571*/
      *(_OWORD *)&v9->_Myval.ackTime = 0; /*0x1411a4575*/
      *(_OWORD *)&v9->_Myval.count = *(_OWORD *)&pi.count; /*0x1411a457e*/
      v9->_Myval.bytesAckTotal = pi.bytesAckTotal; /*0x1411a4588*/
      ++this->pktList._Mypair._Myval2._Mysize; /*0x1411a458d*/
      Prev = Myhead->_Prev; /*0x1411a4591*/
      v9->_Next = Myhead; /*0x1411a4595*/
      v9->_Prev = Prev; /*0x1411a4598*/
      Myhead->_Prev = v9; /*0x1411a459c*/
      Prev->_Next = v9; /*0x1411a45a0*/
      v11 = (webrtc::RtpRtcp *)this->pktList._Mypair._Myval2._Myhead->_Prev; /*0x1411a45a6*/
      p_pktIds = (std::_Hash<std::_Umap_traits<unsigned int,webrtc::RtpRtcp *,std::_Uhash_compare<unsigned int,std::hash<unsigned int>,std::equal_to<unsigned int> >,std::allocator<std::pair<unsigned int const ,webrtc::RtpRtcp *> >,0> > *)&this->pktIds; /*0x1411a45aa*/
    }
    __unwind
    {
      std::_Alloc_construct_ptr<std::allocator<std::_Tree_node<std::pair<std::string const,webrtc::FieldTrialParameterInterface *>,void *>>>::~_Alloc_construct_ptr<std::allocator<std::_Tree_node<std::pair<std::string const,webrtc::FieldTrialParameterInterface *>,void *>>>(this: (std::_Alloc_construct_ptr<std::allocator<std::_List_node<PluginReference,void *> > > *)&result); /*0xf1c0000000000008*/
    }
    std::_Hash<std::_Umap_traits<enum RBX::StudioGameStateType,FindReplaceModel *,std::_Uhash_compare<enum RBX::StudioGameStateType,std::hash<enum RBX::StudioGameStateType>,std::equal_to<enum RBX::StudioGameStateType>>,std::allocator<std::pair<enum RBX::StudioGameStateType const,FindReplaceModel *>>,0>>::_Try_emplace<enum RBX::StudioGameStateType const &,>( /*0x1411a45c6*/
      this: p_pktIds,
      &result,
      &_Keyval_arg)->first->_Myval.second = v11;
    id = _Keyval_arg; /*0x1411a45ca*/
  }
  ++this->packetsSentAll; /*0x1411a45d1*/
  this->bytesSentAll += v6; /*0x1411a45d7*/
  m_last = this->rttRangeQueue.m_last; /*0x1411a45dd*/
  if ( m_last == this->rttRangeQueue.m_buff ) /*0x1411a45eb*/
    m_last = this->rttRangeQueue.m_end; /*0x1411a45ed*/
  ++m_last[-1].packetsSentAll; /*0x1411a45f4*/
  m_last[-1].bytesSentAll += v6; /*0x1411a45f7*/
  if ( id != -1 ) /*0x1411a45fd*/
  {
    ++m_last[-1].packetsSent; /*0x1411a45ff*/
    m_last[-1].bytesSent += v6; /*0x1411a4602*/
    m_last[-1].timeSentLast = time; /*0x1411a4605*/
    m_last[-1].countEnd = id; /*0x1411a4609*/
    if ( m_last[-1].timeSentFirst == 0 ) /*0x1411a4611*/
    {
      m_last[-1].timeSentFirst = time; /*0x1411a4613*/
      m_last[-1].countStart = id; /*0x1411a4617*/
    }
  }
  m_size = this->rttRangeQueue.m_size; /*0x1411a461a*/
  if ( m_size >= 3 ) /*0x1411a4625*/
  {
    timeSentFirst = time - 1000 * DFInt::RakNetUseSlidingWindow2_trackLengthMs; /*0x1411a4638*/
    v16 = m_size - 3; /*0x1411a463b*/
    m_first = this->rttRangeQueue.m_first; /*0x1411a463f*/
    m_end = this->rttRangeQueue.m_end; /*0x1411a4646*/
    v19 = m_end - m_first; /*0x1411a4653*/
    v20 = v16; /*0x1411a4657*/
    if ( v16 >= v19 ) /*0x1411a465d*/
      v20 = v16 - (m_end - this->rttRangeQueue.m_buff); /*0x1411a466d*/
    if ( m_first[v20].timeSentFirst < timeSentFirst ) /*0x1411a4679*/
    {
      if ( v16 >= v19 ) /*0x1411a467e*/
        v16 -= m_end - this->rttRangeQueue.m_buff; /*0x1411a468b*/
      timeSentFirst = m_first[v16].timeSentFirst; /*0x1411a4692*/
    }
    while ( this->pktList._Mypair._Myval2._Mysize != 0 ) /*0x1411a469f*/
    {
      if ( this->pktList._Mypair._Myval2._Myhead->_Next->_Myval.time >= timeSentFirst ) /*0x1411a46be*/
        break; /*0x1411a46be*/
      RakNet::CCRakNetSlidingWindow2::removeFront(this); /*0x1411a46c3*/
    }
  }
}

// Address: 0x1411a4700 | Name: ?calculateDrainSpeed@CCRakNetSlidingWindow2@RakNet@@AEAAHH@Z
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::calculateDrainSpeed(
        RakNet::CCRakNetSlidingWindow2 *this,
        int targetAckSpeed)
{
  int v2; // ebx
  __int64 RttMicroMin; // r9
  __int64 v5; // rdx
  int v6; // r8d
  RakNet::CCRakNetSlidingWindow2::OperationState currentState; // eax
  int v8; // eax
  unsigned __int64 m_size; // rcx
  __int64 v11; // r10
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *m_end; // rdx
  __int64 v13; // rcx
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *m_first; // rsi
  __int64 v15; // r9
  __int64 v16; // r11
  __int64 v17; // rcx

  v2 = targetAckSpeed; /*0x1411a471b*/
  if ( this->packetsSent - this->packetsNak - this->packetsAck < 3 ) /*0x1411a472f*/
    return 0xFFFFFFFFLL; /*0x1411a472f*/
  if ( targetAckSpeed == -1 ) /*0x1411a4734*/
    v2 = RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(this); /*0x1411a473b*/
  RttMicroMin = RakNet::CCRakNetSlidingWindow2::getRttMicroMin(this); /*0x1411a474c*/
  v5 = RttMicroMin * v2 / 1000000; /*0x1411a4788*/
  v6 = this->bytesSent - this->bytesNak - this->bytesAck - v5; /*0x1411a478b*/
  if ( v6 < this->maxPayload + 58 ) /*0x1411a4791*/
    return 0xFFFFFFFFLL; /*0x1411a4791*/
  currentState = this->currentState; /*0x1411a4793*/
  if ( currentState == OperationState_drain ) /*0x1411a4799*/
  {
    v8 = (int)v5 / 16; /*0x1411a47a3*/
  }
  else
  {
    if ( (unsigned int)(currentState - 4) <= 1 ) /*0x1411a47cf*/
    {
      if ( v6 <= (int)v5 / 2 ) /*0x1411a47e2*/
        return 0xFFFFFFFFLL; /*0x1411a47e2*/
      goto LABEL_12; /*0x1411a47e2*/
    }
    v8 = (int)v5 / 4; /*0x1411a47d6*/
  }
  if ( v6 <= v8 ) /*0x1411a47a9*/
    return 0xFFFFFFFFLL; /*0x1411a47c5*/
LABEL_12:
  m_size = this->rttRangeQueue.m_size; /*0x1411a47e4*/
  v11 = RttMicroMin + RttMicroMin / 8; /*0x1411a47fb*/
  if ( m_size > 1 ) /*0x1411a4802*/
  {
    m_end = this->rttRangeQueue.m_end; /*0x1411a4804*/
    v13 = m_size - 1; /*0x1411a480b*/
    m_first = this->rttRangeQueue.m_first; /*0x1411a4816*/
    v15 = v13; /*0x1411a481d*/
    v16 = m_end - m_first; /*0x1411a4823*/
    if ( v13 >= v16 ) /*0x1411a482a*/
      v15 = v13 - (m_end - this->rttRangeQueue.m_buff); /*0x1411a483a*/
    if ( v11 < m_first[v15].rttMicroMin ) /*0x1411a4846*/
    {
      if ( v13 >= v16 ) /*0x1411a484b*/
        v13 -= m_end - this->rttRangeQueue.m_buff; /*0x1411a4858*/
      v11 = m_first[v13].rttMicroMin; /*0x1411a485f*/
    }
  }
  v17 = v11 * v2 / 1000000; /*0x1411a4884*/
  if ( v6 > 3 * (int)v17 / 2 ) /*0x1411a4896*/
    return (unsigned int)(v2 / 8); /*0x1411a48a4*/
  if ( v6 < 3 * (int)v17 / 4 ) /*0x1411a48ba*/
    return v2 - (unsigned int)(v2 * (__int64)v6 / (int)v17); /*0x1411a48e0*/
  return (unsigned int)(v2 / 4); /*0x1411a47b0*/
}

// Address: 0x1411a49c0 | Name: ?findPktInfo@CCRakNetSlidingWindow2@RakNet@@AEAAPEAUPktInfo@2@I@Z
RakNet::PktInfo *__fastcall RakNet::CCRakNetSlidingWindow2::findPktInfo(
        RakNet::CCRakNetSlidingWindow2 *this,
        unsigned int id)
{
  std::_List_node<std::pair<unsigned int const ,std::_List_iterator<std::_List_val<std::_List_simple_types<RakNet::PktInfo> > > >,void *> *Myhead; // r8
  std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<unsigned int const ,std::_List_iterator<std::_List_val<std::_List_simple_types<RakNet::PktInfo> > > > > > > *v3; // rcx
  std::_List_node<std::pair<unsigned int const ,std::_List_iterator<std::_List_val<std::_List_simple_types<RakNet::PktInfo> > > >,void *> *Ptr; // rax
  std::_List_node<std::pair<unsigned int const ,std::_List_iterator<std::_List_val<std::_List_simple_types<RakNet::PktInfo> > > >,void *> *v5; // rcx

  Myhead = this->pktIds._List._Mypair._Myval2._Myhead; /*0x1411a49f3*/
  v3 = &this->pktIds._Vec._Mypair._Myval2._Myfirst[2 /*0x1411a4a23*/
                                                 * ((0x100000001B3LL
                                                   * (((unsigned __int64)id >> 24)
                                                    ^ (0x100000001B3LL
                                                     * (BYTE2(id)
                                                      ^ (0x100000001B3LL
                                                       * (BYTE1(id)
                                                        ^ (0x100000001B3LL
                                                         * ((unsigned __int8)id ^ 0xCBF29CE484222325uLL))))))))
                                                  & this->pktIds._Mask)];
  Ptr = v3[1]._Ptr; /*0x1411a4a2a*/
  if ( Ptr != Myhead ) /*0x1411a4a31*/
  {
    v5 = v3->_Ptr; /*0x1411a4a33*/
    if ( id == Ptr->_Myval.first ) /*0x1411a4a39*/
    {
LABEL_5:
      if ( Ptr == nullptr ) /*0x1411a4a51*/
        Ptr = Myhead; /*0x1411a4a51*/
      if ( Ptr != Myhead ) /*0x1411a4a58*/
        return &Ptr->_Myval.second._Ptr->_Myval; /*0x1411a4a62*/
    }
    else
    {
      while ( Ptr != v5 ) /*0x1411a4a43*/
      {
        Ptr = Ptr->_Prev; /*0x1411a4a45*/
        if ( id == Ptr->_Myval.first ) /*0x1411a4a4c*/
          goto LABEL_5; /*0x1411a4a4c*/
      }
    }
  }
  return nullptr; /*0x1411a4a62*/
}

// Address: 0x1411a4a70 | Name: ?findRange@CCRakNetSlidingWindow2@RakNet@@AEAAPEAURttRangeInfo@12@AEAV?$circular_buffer@URttRangeInfo@CCRakNetSlidingWindow2@RakNet@@V?$allocator@URttRangeInfo@CCRakNetSlidingWindow2@RakNet@@@std@@@boost@@I@Z
RakNet::CCRakNetSlidingWindow2::RttRangeInfo *__fastcall RakNet::CCRakNetSlidingWindow2::findRange(
        RakNet::CCRakNetSlidingWindow2 *this,
        boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> > *rttRangeQueue,
        signed int id)
{
  int v3; // r9d
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *m_first; // r11
  signed __int64 v5; // rax
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *result; // rax

  v3 = LODWORD(rttRangeQueue->m_size) - 1; /*0x1411a4a79*/
  if ( v3 < 0 ) /*0x1411a4a7d*/
    return nullptr; /*0x1411a4a7d*/
  m_first = rttRangeQueue->m_first; /*0x1411a4a83*/
  while ( 1 ) /*0x1411a4a91*/
  {
    v5 = v3; /*0x1411a4a91*/
    if ( v3 >= rttRangeQueue->m_end - m_first ) /*0x1411a4a97*/
      v5 = v3 - (rttRangeQueue->m_end - rttRangeQueue->m_buff); /*0x1411a4aa3*/
    result = &m_first[v5]; /*0x1411a4aaa*/
    if ( result->packetsSent != 0 && id >= result->countStart ) /*0x1411a4ab6*/
      break; /*0x1411a4ab6*/
    if ( --v3 < 0 ) /*0x1411a4abc*/
      return nullptr; /*0x1411a4ac5*/
  }
  if ( id > result->countEnd ) /*0x1411a4aca*/
    return nullptr; /*0x1411a4acc*/
  return result; /*0x1411a4ac0*/
}

// Address: 0x1411a4ae0 | Name: ?getRttMicroMin@CCRakNetSlidingWindow2@RakNet@@AEBA_JXZ
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::getRttMicroMin(RakNet::CCRakNetSlidingWindow2 *this)
{
  __int64 v2; // r8
  unsigned int getRttMicroMin_offsetLimit; // ecx
  unsigned __int64 v4; // rax
  unsigned __int64 m_size; // r10
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *m_first; // rsi
  unsigned __int64 v7; // rdx
  unsigned __int64 v8; // rdx
  __int64 v9; // r9
  __int64 result; // rax

  v2 = 0; /*0x1411a4ae7*/
  getRttMicroMin_offsetLimit = this->getRttMicroMin_offsetLimit; /*0x1411a4aea*/
  v4 = 0; /*0x1411a4aed*/
  m_size = this->rttRangeQueue.m_size; /*0x1411a4af0*/
  if ( getRttMicroMin_offsetLimit == 0 ) /*0x1411a4af9*/
    getRttMicroMin_offsetLimit = 12; /*0x1411a4afb*/
  if ( getRttMicroMin_offsetLimit < m_size ) /*0x1411a4b05*/
    v4 = m_size - getRttMicroMin_offsetLimit; /*0x1411a4b0a*/
  if ( v4 < m_size ) /*0x1411a4b10*/
  {
    m_first = this->rttRangeQueue.m_first; /*0x1411a4b20*/
    do /*0x1411a4b94*/
    {
      v7 = v4; /*0x1411a4b40*/
      if ( (__int64)v4 >= this->rttRangeQueue.m_end - m_first ) /*0x1411a4b46*/
        v7 = v4 - (this->rttRangeQueue.m_end - this->rttRangeQueue.m_buff); /*0x1411a4b56*/
      v8 = v7 << 7; /*0x1411a4b59*/
      v9 = *(__int64 *)((char *)&m_first->rttMicroMin + v8); /*0x1411a4b5d*/
      if ( v9 != 0 /*0x1411a4b89*/
        && (v9 < v2 || v2 == 0)
        && (v4 != m_size - 1
         || *(int *)((char *)&m_first->countAck + v8) > 4
         || *(int *)((char *)&m_first->rttMicroMinPktSize + v8) >= this->maxPayload) )
      {
        v2 = *(__int64 *)((char *)&m_first->rttMicroMin + v8); /*0x1411a4b8b*/
      }
      ++v4; /*0x1411a4b8e*/
    }
    while ( v4 < m_size ); /*0x1411a4b94*/
  }
  result = -1; /*0x1411a4ba7*/
  if ( v2 > 0 ) /*0x1411a4bae*/
    return v2; /*0x1411a4bae*/
  return result; /*0x1411a4bb2*/
}

// Address: 0x1411a4bc0 | Name: ?getSpeedLimit@CCRakNetSlidingWindow2@RakNet@@AEAAHXZ
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::getSpeedLimit(RakNet::CCRakNetSlidingWindow2 *this)
{
  __int64 result; // rax

  result = RakNet::CCRakNetSlidingWindow2::getRttMicroMin(this); /*0x1411a4bc9*/
  if ( result != -1 ) /*0x1411a4bd5*/
  {
    result = 1000000LL * FInt::RakNetResendBufferArrayLength * (this->maxPayload + 58) / (result + 20000); /*0x1411a4bfc*/
    if ( DFInt::RakNetUseSlidingWindow2_maxSpeed != 0 && DFInt::RakNetUseSlidingWindow2_maxSpeed < (int)result ) /*0x1411a4c0b*/
      return (unsigned int)DFInt::RakNetUseSlidingWindow2_maxSpeed; /*0x1411a4c0b*/
  }
  return result; /*0x1411a4bd7*/
}

// Address: 0x1411a4e00 | Name: ?removeFront@CCRakNetSlidingWindow2@RakNet@@AEAAXXZ
void __fastcall RakNet::CCRakNetSlidingWindow2::removeFront(RakNet::CCRakNetSlidingWindow2 *this)
{
  std::_List_node<RakNet::PktInfo,void *> *Myhead; // rcx
  std::_List_node<RakNet::PktInfo,void *> *Ptr; // rdx
  std::_List_node<RakNet::PktInfo,void *> *Next; // rcx
  std::_List_node<RakNet::PktInfo,void *> *v5; // rdx
  std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<unsigned int const ,std::_List_iterator<std::_List_val<std::_List_simple_types<RakNet::PktInfo> > > > > > > *Myfirst; // r10
  std::_List_node<std::pair<unsigned int const ,std::_List_iterator<std::_List_val<std::_List_simple_types<RakNet::PktInfo> > > >,void *> *Prev; // r8
  unsigned __int64 v8; // r9
  std::_List_node<std::pair<unsigned int const ,std::_List_iterator<std::_List_val<std::_List_simple_types<RakNet::PktInfo> > > >,void *> *v9; // r11
  std::_List_node<std::pair<unsigned int const ,std::_List_iterator<std::_List_val<std::_List_simple_types<RakNet::PktInfo> > > >,void *> *v10; // rcx
  std::_List_node<std::pair<unsigned int const ,std::_List_iterator<std::_List_val<std::_List_simple_types<RakNet::PktInfo> > > >,void *> *v11; // rax
  std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<unsigned int const ,std::_List_iterator<std::_List_val<std::_List_simple_types<RakNet::PktInfo> > > > > > > v12; // rdx
  __int128 pi; // [rsp+20h] [rbp-48h]
  __int128 pi_16; // [rsp+30h] [rbp-38h]

  Myhead = this->pktList._Mypair._Myval2._Myhead; /*0x1411a4e12*/
  Ptr = this->lastAck._Ptr; /*0x1411a4e1c*/
  pi = *(_OWORD *)&Myhead->_Next->_Myval.id; /*0x1411a4e2b*/
  pi_16 = *(_OWORD *)&Myhead->_Next->_Myval.ackTime; /*0x1411a4e34*/
  if ( Ptr != Myhead ) /*0x1411a4e3c*/
  {
    if ( Ptr == Myhead->_Next ) /*0x1411a4e41*/
    {
      this->lastAck._Ptr = Myhead; /*0x1411a4e45*/
      *(_QWORD *)&this->packetsSentAll_lastAck = 0; /*0x1411a4e4c*/
      *(_QWORD *)&this->packetsSent_lastAck = 0; /*0x1411a4e53*/
    }
    else
    {
      --this->packetsSentAll_lastAck; /*0x1411a4e61*/
      this->bytesSentAll_lastAck -= DWORD1(pi); /*0x1411a4e6b*/
      if ( (_DWORD)pi != -1 ) /*0x1411a4e74*/
      {
        --this->packetsSent_lastAck; /*0x1411a4e76*/
        this->bytesSent_lastAck -= DWORD1(pi); /*0x1411a4e7c*/
      }
    }
  }
  Next = Myhead->_Next; /*0x1411a4e82*/
  v5 = Next->_Next; /*0x1411a4e85*/
  --this->pktList._Mypair._Myval2._Mysize; /*0x1411a4e88*/
  Next->_Prev->_Next = v5; /*0x1411a4e93*/
  v5->_Prev = Next->_Prev; /*0x1411a4e9a*/
  operator delete(ptr: Next); /*0x1411a4ea3*/
  if ( (_DWORD)pi != -1 ) /*0x1411a4eaf*/
  {
    Myfirst = this->pktIds._Vec._Mypair._Myval2._Myfirst; /*0x1411a4ec4*/
    Prev = this->pktIds._List._Mypair._Myval2._Myhead; /*0x1411a4ed5*/
    v8 = 2 /*0x1411a4f11*/
       * (this->pktIds._Mask
        & (0x100000001B3LL
         * (BYTE3(pi)
          ^ (0x100000001B3LL
           * (BYTE2(pi)
            ^ (0x100000001B3LL * (BYTE1(pi) ^ (0x100000001B3LL * ((unsigned __int8)pi ^ 0xCBF29CE484222325uLL)))))))));
    v9 = Myfirst[2 /*0x1411a4f14*/
               * (this->pktIds._Mask
                & (0x100000001B3LL
                 * (BYTE3(pi)
                  ^ (0x100000001B3LL
                   * (BYTE2(pi)
                    ^ (0x100000001B3LL * (BYTE1(pi) ^ (0x100000001B3LL * ((unsigned __int8)pi ^ 0xCBF29CE484222325uLL)))))))))
               + 1]._Ptr;
    v10 = v9; /*0x1411a4f19*/
    if ( v9 != Prev ) /*0x1411a4f1f*/
    {
      if ( (_DWORD)pi == v9->_Myval.first ) /*0x1411a4f29*/
      {
LABEL_11:
        if ( v10 != nullptr ) /*0x1411a4f41*/
        {
          v11 = Myfirst[2 /*0x1411a4f46*/
                      * (this->pktIds._Mask
                       & (0x100000001B3LL
                        * (BYTE3(pi)
                         ^ (0x100000001B3LL
                          * (BYTE2(pi)
                           ^ (0x100000001B3LL
                            * (BYTE1(pi) ^ (0x100000001B3LL * ((unsigned __int8)pi ^ 0xCBF29CE484222325uLL)))))))))]._Ptr;
          if ( v9 == v10 ) /*0x1411a4f4d*/
          {
            if ( v11 == v10 ) /*0x1411a4f52*/
              Myfirst[2 /*0x1411a4f54*/
                    * (this->pktIds._Mask
                     & (0x100000001B3LL
                      * (BYTE3(pi)
                       ^ (0x100000001B3LL
                        * (BYTE2(pi)
                         ^ (0x100000001B3LL
                          * (BYTE1(pi) ^ (0x100000001B3LL * ((unsigned __int8)pi ^ 0xCBF29CE484222325uLL)))))))))]._Ptr = Prev;
            else
              Prev = v10->_Prev; /*0x1411a4f5f*/
            Myfirst[v8 + 1]._Ptr = Prev; /*0x1411a4f58*/
          }
          else if ( v11 == v10 ) /*0x1411a4f6d*/
          {
            Myfirst[2 /*0x1411a4f72*/
                  * (this->pktIds._Mask
                   & (0x100000001B3LL
                    * (BYTE3(pi)
                     ^ (0x100000001B3LL
                      * (BYTE2(pi)
                       ^ (0x100000001B3LL
                        * (BYTE1(pi) ^ (0x100000001B3LL * ((unsigned __int8)pi ^ 0xCBF29CE484222325uLL)))))))))] = (std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<unsigned int const ,std::_List_iterator<std::_List_val<std::_List_simple_types<RakNet::PktInfo> > > > > > >)v10->_Next;
          }
          v12._Ptr = v10->_Next; /*0x1411a4f76*/
          --this->pktIds._List._Mypair._Myval2._Mysize; /*0x1411a4f79*/
          v10->_Prev->_Next = v12._Ptr; /*0x1411a4f84*/
          v12._Ptr->_Prev = v10->_Prev; /*0x1411a4f8b*/
          operator delete(ptr: v10); /*0x1411a4f94*/
        }
      }
      else
      {
        while ( v10 != Myfirst[2 /*0x1411a4f33*/
                             * (this->pktIds._Mask
                              & (0x100000001B3LL
                               * (BYTE3(pi)
                                ^ (0x100000001B3LL
                                 * (BYTE2(pi)
                                  ^ (0x100000001B3LL
                                   * (BYTE1(pi) ^ (0x100000001B3LL * ((unsigned __int8)pi ^ 0xCBF29CE484222325uLL)))))))))]._Ptr )
        {
          v10 = v10->_Prev; /*0x1411a4f35*/
          if ( (_DWORD)pi == v10->_Myval.first ) /*0x1411a4f3c*/
            goto LABEL_11; /*0x1411a4f3c*/
        }
      }
    }
    --this->packetsSent; /*0x1411a4f99*/
    this->bytesSent -= DWORD1(pi); /*0x1411a4f9f*/
    if ( (_QWORD)pi_16 != 0 ) /*0x1411a4fab*/
    {
      --this->packetsAck; /*0x1411a4fad*/
      this->bytesAck -= DWORD1(pi); /*0x1411a4fb3*/
    }
    if ( *((_QWORD *)&pi_16 + 1) != 0 ) /*0x1411a4fbf*/
    {
      --this->packetsNak; /*0x1411a4fc1*/
      this->bytesNak -= DWORD1(pi); /*0x1411a4fc7*/
    }
  }
  --this->packetsSentAll; /*0x1411a4fcd*/
  this->bytesSentAll -= DWORD1(pi); /*0x1411a4fd3*/
}

// Address: 0x1411a5170 | Name: ?setTargetSpeed@CCRakNetSlidingWindow2@RakNet@@AEAAXH@Z
void __fastcall RakNet::CCRakNetSlidingWindow2::setTargetSpeed(
        RakNet::CCRakNetSlidingWindow2 *this,
        int newTargetSpeed)
{
  __int64 RttMicroMin; // rax
  __int64 v5; // rax
  unsigned int v6; // ebx
  __int64 TimeUS; // rax
  __int64 targetSpeedStartTime; // r9
  __int64 targetSpeedStartBytes; // r10
  __int64 v10; // r11

  RttMicroMin = RakNet::CCRakNetSlidingWindow2::getRttMicroMin(this); /*0x1411a517f*/
  if ( RttMicroMin != -1 ) /*0x1411a518b*/
  {
    v5 = 1000000LL * FInt::RakNetResendBufferArrayLength * (this->maxPayload + 58) / (RttMicroMin + 20000); /*0x1411a51b6*/
    if ( DFInt::RakNetUseSlidingWindow2_maxSpeed != 0 && DFInt::RakNetUseSlidingWindow2_maxSpeed < (int)v5 ) /*0x1411a51bf*/
      LODWORD(v5) = DFInt::RakNetUseSlidingWindow2_maxSpeed; /*0x1411a51bf*/
    if ( (_DWORD)v5 != -1 && (int)v5 < newTargetSpeed ) /*0x1411a51c9*/
      newTargetSpeed = v5; /*0x1411a51c9*/
  }
  if ( newTargetSpeed < DFInt::RakNetUseSlidingWindow2_minSpeed ) /*0x1411a51d2*/
    newTargetSpeed = DFInt::RakNetUseSlidingWindow2_minSpeed; /*0x1411a51d2*/
  v6 = newTargetSpeed & 0xFFFFFF00; /*0x1411a51d9*/
  if ( v6 != this->targetSpeed ) /*0x1411a51e5*/
  {
    if ( this->targetSpeedStartTime != 0 ) /*0x1411a51f3*/
    {
      TimeUS = RakNet::GetTimeUS(isNetworkSynced: false); /*0x1411a5200*/
      targetSpeedStartTime = this->targetSpeedStartTime; /*0x1411a5205*/
      targetSpeedStartBytes = this->targetSpeedStartBytes; /*0x1411a5219*/
      v10 = this->targetSpeed * (TimeUS - targetSpeedStartTime) / 1000000; /*0x1411a5249*/
      if ( targetSpeedStartTime + 1000000 * targetSpeedStartBytes / this->targetSpeed >= TimeUS - 20000 /*0x1411a5273*/
        || targetSpeedStartBytes + 2 * this->maxPayload + 116 >= v10 )
      {
        this->targetSpeedStartTime = TimeUS; /*0x1411a528a*/
        this->targetSpeedStartBytes = targetSpeedStartBytes - v10; /*0x1411a5291*/
      }
      else
      {
        this->targetSpeedStartBytes = 0; /*0x1411a5277*/
        this->targetSpeedStartTime = 0; /*0x1411a527e*/
      }
    }
    this->targetSpeed = v6; /*0x1411a529d*/
  }
}

// Address: 0x1411a54a0 | Name: ?updateLastRecvStats@CCRakNetSlidingWindow2@RakNet@@AEAAXAEAV?$circular_buffer@URttRangeInfo@CCRakNetSlidingWindow2@RakNet@@V?$allocator@URttRangeInfo@CCRakNetSlidingWindow2@RakNet@@@std@@@boost@@@Z
void __fastcall RakNet::CCRakNetSlidingWindow2::updateLastRecvStats(
        RakNet::CCRakNetSlidingWindow2 *this,
        boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> > *rttRangeQueue)
{
  unsigned __int64 m_size; // r13
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *m_end; // rsi
  unsigned __int64 v6; // rdi
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *m_first; // r12
  __int64 v8; // r14
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *v9; // rdi
  RakNet::PktInfo *PktInfo; // rax
  RakNet::PktInfo *v11; // r15
  unsigned __int64 v12; // rcx
  RakNet::PktInfo *v13; // rax
  __int64 v14; // r8
  __int64 v15; // r9
  __int64 v16; // rax
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *m_last; // rax
  __int64 timeAckFirst; // rcx
  __int64 v19; // rcx
  __int64 v20; // r8
  int ackSpeed; // r11d
  RakNet::CCRakNetSlidingWindow2::OperationState v22; // esi
  int bytesSent; // ecx
  int bytesNak; // eax
  __int64 rttMicroMinPktSize; // rcx
  int maxPayload; // eax
  __int64 v27; // r9
  __int64 v28; // rax
  __int64 rttMicroMin; // rax
  __int64 v30; // r8
  int targetSpeed; // r9d
  __int64 v32; // rcx
  bool v33; // zf
  int v34; // eax
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *v35; // r8
  __int64 v36; // rdx
  RakNet::CCRakNetSlidingWindow2::OperationState currentState; // ebp
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *v38; // rdx
  int v39; // eax
  double nakPercentage; // xmm1_8
  double v41; // xmm3_8
  __int64 sendSpeed; // r11
  __int64 v43; // r8
  __int64 v44; // rcx
  int v45; // edi
  int v46; // edx
  int v47; // eax
  __int64 v48; // rcx
  int v49; // [rsp+58h] [rbp+10h]

  m_size = rttRangeQueue->m_size; /*0x1411a54a9*/
  if ( m_size < 2 ) /*0x1411a54b7*/
    return; /*0x1411a54b7*/
  m_end = rttRangeQueue->m_end; /*0x1411a54c2*/
  v6 = m_size - 2; /*0x1411a54cb*/
  m_first = rttRangeQueue->m_first; /*0x1411a54d4*/
  v8 = m_end - m_first; /*0x1411a54e8*/
  if ( (__int64)(m_size - 2) >= v8 ) /*0x1411a54ef*/
    v6 -= m_end - rttRangeQueue->m_buff; /*0x1411a54fb*/
  v9 = &m_first[v6]; /*0x1411a5502*/
  v49 = RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(this); /*0x1411a5510*/
  PktInfo = RakNet::CCRakNetSlidingWindow2::findPktInfo(this, id: v9->countEnd); /*0x1411a5514*/
  v11 = PktInfo; /*0x1411a5519*/
  if ( m_size <= 2 ) /*0x1411a5520*/
  {
    if ( PktInfo != nullptr ) /*0x1411a55c3*/
    {
      m_last = rttRangeQueue->m_last; /*0x1411a55c5*/
      if ( m_last == rttRangeQueue->m_buff ) /*0x1411a55cd*/
      {
        timeAckFirst = m_end[-1].timeAckFirst; /*0x1411a55cf*/
      }
      else
      {
        timeAckFirst = m_last[-1].timeAckFirst; /*0x1411a55d5*/
        m_end = rttRangeQueue->m_last; /*0x1411a55d9*/
      }
      v19 = timeAckFirst - v9->timeAckFirst; /*0x1411a55dc*/
      if ( v19 > 0 && m_end[-1].timeSentFirst - v9->timeSentFirst > 0 ) /*0x1411a55f0*/
      {
        v20 = m_end[-1].timeSentFirst - v9->timeSentFirst; /*0x1411a55e9*/
        v9->sendSpeed = (32 * (v20 + 31250 * v11->bytesSentTotal) / v20) & 0xFFFFFFC0; /*0x1411a5609*/
        v16 = 32 * (v19 + 31250 * v11->bytesAckTotal) / v19; /*0x1411a561d*/
        goto LABEL_19; /*0x1411a561d*/
      }
    }
  }
  else
  {
    v12 = m_size - 3; /*0x1411a5526*/
    if ( (__int64)(m_size - 3) >= v8 ) /*0x1411a552d*/
      v12 -= m_end - rttRangeQueue->m_buff; /*0x1411a5537*/
    v13 = RakNet::CCRakNetSlidingWindow2::findPktInfo(this, id: m_first[v12].countEnd); /*0x1411a5546*/
    if ( v11 != nullptr && v13 != nullptr ) /*0x1411a555a*/
    {
      v14 = v11->ackTime - v13->ackTime; /*0x1411a5564*/
      if ( v14 > 0 && v11->time - v13->time > 0 ) /*0x1411a557c*/
      {
        v15 = v11->time - v13->time; /*0x1411a5575*/
        v9->sendSpeed = (32 * (v15 + 31250 * (v11->bytesSentTotal - v13->bytesSentTotal)) / v15) & 0xFFFFFFC0; /*0x1411a55a0*/
        v16 = 32 * (v14 + 31250 * (v11->bytesAckTotal - v13->bytesAckTotal)) / v14; /*0x1411a55bb*/
LABEL_19:
        v9->ackSpeed = v16 & 0xFFFFFFC0; /*0x1411a5620*/
      }
    }
  }
  ackSpeed = v9->ackSpeed; /*0x1411a5626*/
  v22 = OperationState_drain; /*0x1411a562a*/
  if ( ackSpeed <= 0 ) /*0x1411a5641*/
  {
    v9->ackSpeed = 1; /*0x1411a5643*/
    ackSpeed = 1; /*0x1411a5646*/
  }
  bytesSent = v9->bytesSent; /*0x1411a5649*/
  if ( bytesSent > 0 ) /*0x1411a564e*/
  {
    bytesNak = v9->bytesNak; /*0x1411a5650*/
    if ( bytesNak != 0 ) /*0x1411a5655*/
      v9->nakPercentage = (double)bytesNak * 100.0 / (double)bytesSent; /*0x1411a5673*/
  }
  if ( !v9->appLimited ) /*0x1411a567c*/
  {
    rttMicroMinPktSize = v9->rttMicroMinPktSize; /*0x1411a567e*/
    maxPayload = this->maxPayload; /*0x1411a5682*/
    if ( (int)rttMicroMinPktSize < maxPayload && (int)rttMicroMinPktSize > 0 ) /*0x1411a568b*/
    {
      v27 = maxPayload + 58; /*0x1411a5690*/
      v28 = 1000000 * v27 / (unsigned int)ackSpeed; /*0x1411a56af*/
      if ( v27 * v9->rttMicroMin / rttMicroMinPktSize < v28 ) /*0x1411a56b5*/
        v28 = v27 * v9->rttMicroMin / rttMicroMinPktSize; /*0x1411a56b5*/
      if ( v9->rttMicroMin < v28 ) /*0x1411a56bd*/
        v9->rttMicroMin = v28; /*0x1411a56bf*/
    }
  }
  rttMicroMin = v9->rttMicroMin; /*0x1411a56c3*/
  if ( rttMicroMin != 0 ) /*0x1411a56ca*/
    this->RTT = (double)(int)rttMicroMin; /*0x1411a56d4*/
  if ( rttRangeQueue->m_size < 3 ) /*0x1411a56de*/
    return; /*0x1411a56de*/
  if ( (unsigned int)(v9->state - 3) <= 2 && !v9->appLimited ) /*0x1411a56f7*/
  {
    v30 = RakNet::CCRakNetSlidingWindow2::getRttMicroMin(this); /*0x1411a5708*/
    targetSpeed = v9->targetSpeed; /*0x1411a570b*/
    if ( targetSpeed > 5 * v9->ackSpeed / 4 && targetSpeed > 5 * v9->sendSpeed / 4 ) /*0x1411a5732*/
    {
      v32 = v9->rttMicroMin; /*0x1411a5734*/
      if ( v32 > 5 * v30 / 4 && v32 - v30 > DFInt::RakNetUseSlidingWindow2_minRtt ) /*0x1411a575a*/
      {
        v33 = this->currentState == OperationState_drainRtt; /*0x1411a575c*/
        this->getRttMicroMin_offsetLimit = 2; /*0x1411a5760*/
        if ( !v33 ) /*0x1411a5767*/
        {
          v34 = 3 * v9->ackSpeed / 4; /*0x1411a5775*/
          if ( v34 == -1 ) /*0x1411a577b*/
            v34 = RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(this); /*0x1411a5780*/
          this->currentState = OperationState_drainRtt; /*0x1411a5787*/
          RakNet::CCRakNetSlidingWindow2::setTargetSpeed(this, newTargetSpeed: v34); /*0x1411a5791*/
        }
      }
    }
  }
  v35 = rttRangeQueue->m_first; /*0x1411a579a*/
  v36 = rttRangeQueue->m_size - 3; /*0x1411a57ac*/
  if ( v36 >= rttRangeQueue->m_end - v35 ) /*0x1411a57b3*/
    v36 -= rttRangeQueue->m_end - rttRangeQueue->m_buff; /*0x1411a57bd*/
  currentState = this->currentState; /*0x1411a57c0*/
  v38 = &v35[v36]; /*0x1411a57c7*/
  if ( currentState != OperationState_drainRtt )
  {
    if ( currentState == OperationState_start )
    {
      if ( v9->packetsNak > 1
        && ((nakPercentage = v9->nakPercentage) > 15.0 && nakPercentage > v38->nakPercentage + v38->nakPercentage
         || v38->state == OperationState_start
         && ((v41 = v38->nakPercentage) > 0.0 && v41 < 0.5 && nakPercentage > 3.0
          || v38->nakPercentage < 0.5 && nakPercentage > 6.0))
        || (sendSpeed = v38->sendSpeed, v43 = v9->sendSpeed, 100 * v43 >= 110 * sendSpeed)
        && (int)v43 - (int)sendSpeed > 10000
        && v38->state == OperationState_start
        && (!DFFlag::RakNetUseGrowthPercentInt.value
          ? (v44 = 85 * v43 * v38->ackSpeed)
          : (v44 = v43 * DFInt::RakNetMinAckGrowthPercent * (__int64)v38->ackSpeed),
            100 * sendSpeed * v9->ackSpeed < v44) )
      {
        v45 = RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(this); /*0x1411a5922*/
        v46 = RakNet::CCRakNetSlidingWindow2::calculateDrainSpeed(this, targetAckSpeed: v45); /*0x1411a5929*/
        if ( v46 == -1 ) /*0x1411a592e*/
        {
          v46 = v45; /*0x1411a5930*/
          if ( v45 == -1 ) /*0x1411a5934*/
            v46 = RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(this); /*0x1411a593e*/
          v22 = OperationState_level; /*0x1411a5942*/
          this->levelBlocksCount = 0; /*0x1411a5947*/
        }
        this->currentState = v22; /*0x1411a594a*/
        goto LABEL_101; /*0x1411a594d*/
      }
      return; /*0x1411a590f*/
    }
    v47 = RakNet::CCRakNetSlidingWindow2::calculateDrainSpeed(this, targetAckSpeed: -1); /*0x1411a595a*/
    if ( currentState == OperationState_drain ) /*0x1411a5961*/
    {
      v46 = v47; /*0x1411a5963*/
      if ( v47 != -1 ) /*0x1411a5968*/
      {
LABEL_101:
        RakNet::CCRakNetSlidingWindow2::setTargetSpeed(this, newTargetSpeed: v46); /*0x1411a5a6d*/
        return; /*0x1411a5a70*/
      }
      goto LABEL_78; /*0x1411a5968*/
    }
    if ( v47 != -1 ) /*0x1411a5997*/
    {
      v46 = RakNet::CCRakNetSlidingWindow2::calculateDrainSpeed(this, targetAckSpeed: -1); /*0x1411a59a6*/
      if ( v46 == -1 ) /*0x1411a59ab*/
      {
        v22 = OperationState_level; /*0x1411a59b0*/
        v46 = RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(this); /*0x1411a59b8*/
        if ( currentState != OperationState_level ) /*0x1411a59bc*/
          this->levelBlocksCount = 0; /*0x1411a59c0*/
      }
      this->currentState = v22; /*0x1411a59c3*/
      goto LABEL_101; /*0x1411a59c6*/
    }
    v48 = 100LL * v9->ackSpeed; /*0x1411a59cf*/
    if ( v9->state == OperationState_levelBw ) /*0x1411a59dc*/
    {
      if ( v48 <= 115LL * v49 ) /*0x1411a59e5*/
        goto LABEL_88; /*0x1411a59e5*/
    }
    else if ( v48 <= 120LL * v49 ) /*0x1411a5a1d*/
    {
LABEL_88:
      if ( currentState == OperationState_levelBw ) /*0x1411a59ea*/
      {
        v39 = (int)(3 * RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(this)) / 4; /*0x1411a59fd*/
        if ( v39 == -1 ) /*0x1411a5a03*/
          v39 = RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(this); /*0x1411a5a08*/
        this->currentState = OperationState_levelRtt; /*0x1411a5a0d*/
        goto LABEL_100; /*0x1411a5a14*/
      }
      if ( currentState != OperationState_levelRtt ) /*0x1411a5a46*/
      {
        if ( this->appLimitedStart != 0 || (++this->levelBlocksCount, this->levelBlocksCount != 10) ) /*0x1411a5a5d*/
        {
          v39 = RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(this); /*0x1411a5a66*/
LABEL_100:
          v46 = v39; /*0x1411a5a6b*/
          goto LABEL_101; /*0x1411a5a6b*/
        }
LABEL_51:
        v39 = (int)(5 * RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(this)) / 4; /*0x1411a57fb*/
        if ( v39 == -1 ) /*0x1411a5812*/
          v39 = RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(this); /*0x1411a5817*/
        this->currentState = OperationState_levelBw; /*0x1411a581c*/
        goto LABEL_100; /*0x1411a5823*/
      }
LABEL_78:
      v46 = RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(this); /*0x1411a596e*/
      if ( v46 == -1 ) /*0x1411a597b*/
        v46 = RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(this); /*0x1411a5985*/
      *(_QWORD *)&this->currentState = 3; /*0x1411a5987*/
      goto LABEL_101; /*0x1411a598f*/
    }
    v46 = RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(this); /*0x1411a5a27*/
    if ( v46 == -1 ) /*0x1411a5a2c*/
      v46 = RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(this); /*0x1411a5a36*/
    this->operationState_startT0 = 0; /*0x1411a5a3a*/
    this->currentState = OperationState_start; /*0x1411a5a3e*/
    goto LABEL_101; /*0x1411a5a41*/
  }
  if ( v9->state == OperationState_drainRtt /*0x1411a57f5*/
    && (v9->rttMicroMin >= v38->rttMicroMin || v9->ackSpeed - v9->ackSpeed / 16 <= v9->sendSpeed) )
  {
    goto LABEL_51; /*0x1411a57f5*/
  }
}

// Address: 0x1411a5a90 | Name: ?updateRangeAck@CCRakNetSlidingWindow2@RakNet@@AEAAXAEAV?$circular_buffer@URttRangeInfo@CCRakNetSlidingWindow2@RakNet@@V?$allocator@URttRangeInfo@CCRakNetSlidingWindow2@RakNet@@@std@@@boost@@IH_K_J@Z
void __fastcall RakNet::CCRakNetSlidingWindow2::updateRangeAck(
        RakNet::CCRakNetSlidingWindow2 *this,
        boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo> > *rttRangeQueue,
        signed int id,
        int size,
        __int64 time,
        __int64 rttMicro)
{
  int v7; // r10d
  int v9; // ecx
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *m_end; // r8
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *m_first; // r11
  __int64 v14; // rbx
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *v15; // rbx
  signed int countStart; // ebp
  int v17; // edx
  __int64 v18; // rdi
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *Range; // rdi
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *m_last; // rax
  unsigned __int64 m_size; // rcx
  __int64 v22; // rcx
  RakNet::PktInfo *PktInfo; // rax
  RakNet::PktInfo *v24; // rcx
  __int64 v25; // rax
  int v26; // edx
  RakNet::PktInfo *v27; // rax
  __int64 rttMicroMin; // rcx
  int maxPayload; // eax
  __int64 timeAckLast; // rbp
  __int64 timeSentLast; // r12
  __int64 v32; // r15
  __int64 v33; // rdi
  RakNet::PktInfo *v34; // rax
  __int64 v35; // rdi
  int v36; // ecx
  int v37; // eax
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *v38; // rcx
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *m_buff; // rdx
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *v40; // rax
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *v41; // rax
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *v42; // rax
  unsigned __int64 v43; // rdx
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *v44; // rax
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *v45; // rax
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *v46; // rax
  unsigned int ackSpeed_last4_offsetLimit; // ecx
  unsigned int v48; // ecx
  unsigned int getRttMicroMin_offsetLimit; // ecx
  unsigned int v50; // ecx
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo item; // [rsp+20h] [rbp-A8h] BYREF

  v7 = LODWORD(rttRangeQueue->m_size) - 1; /*0x1411a5aac*/
  v9 = v7; /*0x1411a5ab3*/
  if ( v7 >= 0 )
  {
    m_end = rttRangeQueue->m_end; /*0x1411a5ac2*/
    m_first = rttRangeQueue->m_first; /*0x1411a5ac6*/
    while ( 1 ) /*0x1411a5ae0*/
    {
      v14 = v9; /*0x1411a5ae0*/
      if ( v9 >= m_end - m_first ) /*0x1411a5ae6*/
        v14 = v9 - (m_end - rttRangeQueue->m_buff); /*0x1411a5af2*/
      v15 = &m_first[v14]; /*0x1411a5af9*/
      if ( v15->packetsSent != 0 ) /*0x1411a5b00*/
      {
        countStart = v15->countStart; /*0x1411a5b02*/
        if ( id >= v15->countStart ) /*0x1411a5b07*/
          break; /*0x1411a5b07*/
      }
      if ( --v9 < 0 ) /*0x1411a5b0c*/
        return; /*0x1411a5b0c*/
    }
    if ( id <= v15->countEnd )
    {
      v17 = countStart - 1; /*0x1411a5b37*/
      while ( 1 ) /*0x1411a5b40*/
      {
        v18 = v7; /*0x1411a5b40*/
        if ( v7 >= m_end - m_first ) /*0x1411a5b46*/
          v18 = v7 - (m_end - rttRangeQueue->m_buff); /*0x1411a5b52*/
        Range = &m_first[v18]; /*0x1411a5b5c*/
        if ( Range->packetsSent != 0 && v17 >= Range->countStart ) /*0x1411a5b67*/
          break; /*0x1411a5b67*/
        if ( --v7 < 0 ) /*0x1411a5b6d*/
          goto LABEL_18; /*0x1411a5b6d*/
      }
      if ( v17 > Range->countEnd ) /*0x1411a5b74*/
LABEL_18:
        Range = nullptr; /*0x1411a5b76*/
      m_last = rttRangeQueue->m_last; /*0x1411a5b79*/
      if ( m_last == rttRangeQueue->m_buff ) /*0x1411a5b83*/
        m_last = m_end; /*0x1411a5b83*/
      if ( v15 == &m_last[-1] && v15->timeAckFirst == 0 && Range != nullptr ) /*0x1411a5ba1*/
      {
        if ( Range->countAck != Range->countEnd ) /*0x1411a5bad*/
          goto LABEL_119; /*0x1411a5bad*/
        m_size = rttRangeQueue->m_size; /*0x1411a5baf*/
        if ( m_size > 2 ) /*0x1411a5bb7*/
        {
          v22 = m_size - 3; /*0x1411a5bc0*/
          if ( v22 >= m_end - m_first ) /*0x1411a5bce*/
            v22 -= m_end - rttRangeQueue->m_buff; /*0x1411a5bd7*/
          if ( m_first[v22].timeAckLast >= Range->timeAckLast ) /*0x1411a5be7*/
          {
LABEL_119:
            do /*0x1411a5c5c*/
            {
              PktInfo = RakNet::CCRakNetSlidingWindow2::findPktInfo(this, id: countStart); /*0x1411a5bf5*/
              v24 = PktInfo; /*0x1411a5bfa*/
              if ( PktInfo != nullptr ) /*0x1411a5c00*/
              {
                v25 = PktInfo->time; /*0x1411a5c02*/
                v26 = v24->size; /*0x1411a5c06*/
                ++Range->packetsSentAll; /*0x1411a5c09*/
                Range->bytesSentAll += v26; /*0x1411a5c0c*/
                if ( countStart != -1 ) /*0x1411a5c12*/
                {
                  ++Range->packetsSent; /*0x1411a5c14*/
                  Range->bytesSent += v26; /*0x1411a5c17*/
                  Range->timeSentLast = v25; /*0x1411a5c1a*/
                  Range->countEnd = countStart; /*0x1411a5c1e*/
                  if ( Range->timeSentFirst == 0 ) /*0x1411a5c25*/
                  {
                    Range->timeSentFirst = v25; /*0x1411a5c27*/
                    Range->countStart = countStart; /*0x1411a5c2b*/
                  }
                }
                --v15->packetsSent; /*0x1411a5c2d*/
                --v15->packetsSentAll; /*0x1411a5c30*/
                v15->bytesSent -= v24->size; /*0x1411a5c36*/
                v15->bytesSentAll -= v24->size; /*0x1411a5c3c*/
                if ( v24->nakTime != 0 ) /*0x1411a5c43*/
                {
                  v15->bytesNak -= v24->size; /*0x1411a5c48*/
                  --v15->packetsNak; /*0x1411a5c4b*/
                  Range->bytesNak += v24->size; /*0x1411a5c51*/
                  ++Range->packetsNak; /*0x1411a5c54*/
                }
              }
              ++countStart; /*0x1411a5c57*/
            }
            while ( countStart <= id ); /*0x1411a5c5c*/
            if ( id >= v15->countEnd ) /*0x1411a5c62*/
            {
              v15->timeSentLast = 0; /*0x1411a5c86*/
              v15->timeSentFirst = 0; /*0x1411a5c8a*/
              *(_QWORD *)&v15->countStart = 0; /*0x1411a5c8e*/
            }
            else
            {
              v27 = RakNet::CCRakNetSlidingWindow2::findPktInfo(this, id: id + 1); /*0x1411a5c6b*/
              if ( v27 != nullptr ) /*0x1411a5c76*/
              {
                v15->timeSentFirst = v27->time; /*0x1411a5c7c*/
                v15->countStart = v27->id; /*0x1411a5c82*/
              }
            }
            v15 = Range; /*0x1411a5c9d*/
            Range = RakNet::CCRakNetSlidingWindow2::findRange(this, rttRangeQueue, id: Range->countStart - 1); /*0x1411a5ca5*/
          }
        }
      }
      v15->bytesAck += size; /*0x1411a5ca8*/
      ++v15->packetsAck; /*0x1411a5cac*/
      if ( id > v15->countAck ) /*0x1411a5cb3*/
        v15->countAck = id; /*0x1411a5cb5*/
      if ( v15->timeAckFirst != 0 ) /*0x1411a5cc6*/
      {
        if ( rttMicro > v15->rttMicroMax ) /*0x1411a5cea*/
          v15->rttMicroMax = rttMicro; /*0x1411a5cec*/
        rttMicroMin = v15->rttMicroMin; /*0x1411a5cf0*/
        if ( rttMicro >= rttMicroMin || size < this->maxPayload / 4 && v15->rttMicroMinPktSize >= this->maxPayload ) /*0x1411a5d12*/
        {
          maxPayload = this->maxPayload; /*0x1411a5d14*/
          if ( size < maxPayload || v15->rttMicroMinPktSize >= maxPayload / 4 ) /*0x1411a5d29*/
            goto LABEL_54; /*0x1411a5d29*/
        }
        v15->rttMicroMin = rttMicro; /*0x1411a5d2b*/
        rttMicroMin = rttMicro; /*0x1411a5d2f*/
      }
      else
      {
        rttMicroMin = rttMicro; /*0x1411a5cc8*/
        v15->rttMicroMax = rttMicro; /*0x1411a5cd0*/
        v15->rttMicroMin = rttMicro; /*0x1411a5cd4*/
        v15->timeAckFirst = time; /*0x1411a5cd8*/
      }
      v15->rttMicroMinPktSize = size; /*0x1411a5d32*/
LABEL_54:
      v15->timeAckLast = time; /*0x1411a5d36*/
      if ( (unsigned __int64)(rttMicroMin - 2) <= 0xBB5 && this->targetSpeed < 500000 ) /*0x1411a5d51*/
        RakNet::CCRakNetSlidingWindow2::setTargetSpeed(this, newTargetSpeed: 10000000); /*0x1411a5d5b*/
      if ( Range != nullptr ) /*0x1411a5d63*/
      {
        timeAckLast = Range->timeAckLast; /*0x1411a5d65*/
        timeSentLast = Range->timeSentLast; /*0x1411a5d69*/
      }
      else
      {
        timeAckLast = v15->timeAckFirst; /*0x1411a5d6f*/
        timeSentLast = v15->timeSentFirst; /*0x1411a5d73*/
      }
      if ( v15->state == OperationState_start /*0x1411a5d9e*/
        && this->currentState == OperationState_start
        && v15->rttMicroMin >= 100000
        && v15->packetsAck > 20 )
      {
        v32 = v15->timeAckLast; /*0x1411a5da4*/
        v33 = v32 - timeAckLast; /*0x1411a5dab*/
        if ( v32 - timeAckLast > 30000 ) /*0x1411a5db5*/
        {
          v34 = RakNet::CCRakNetSlidingWindow2::findPktInfo(this, id); /*0x1411a5dc5*/
          if ( v34 != nullptr /*0x1411a5df0*/
            && (2 * (v34->time - timeSentLast) < v33 || 4 * v15->bytesNak > v15->bytesAck)
            && v32 != timeAckLast )
          {
            v35 = 1000000LL * v15->bytesAck / v33; /*0x1411a5e02*/
            if ( (_DWORD)v35 == -1 ) /*0x1411a5e08*/
              LODWORD(v35) = RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(this); /*0x1411a5e12*/
            v36 = RakNet::CCRakNetSlidingWindow2::calculateDrainSpeed(this, targetAckSpeed: v35); /*0x1411a5e1e*/
            if ( v36 == -1 ) /*0x1411a5e23*/
            {
              if ( (_DWORD)v35 == -1 ) /*0x1411a5e27*/
                LODWORD(v35) = RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(this); /*0x1411a5e31*/
              this->levelBlocksCount = 0; /*0x1411a5e3c*/
              this->currentState = OperationState_level; /*0x1411a5e43*/
              RakNet::CCRakNetSlidingWindow2::setTargetSpeed(this, newTargetSpeed: v35); /*0x1411a5e47*/
            }
            else
            {
              this->currentState = OperationState_drain; /*0x1411a5e57*/
              RakNet::CCRakNetSlidingWindow2::setTargetSpeed(this, newTargetSpeed: v36); /*0x1411a5e60*/
            }
          }
        }
      }
      if ( v15->state == OperationState_drainRtt /*0x1411a5ea0*/
        && this->currentState == OperationState_drainRtt
        && this->bytesSent - this->bytesNak - this->bytesAck < 2 * this->maxPayload + 116 )
      {
        v37 = RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(this); /*0x1411a5ea5*/
        if ( v37 == -1 ) /*0x1411a5ead*/
          v37 = RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(this); /*0x1411a5eb2*/
        *(_QWORD *)&this->currentState = 3; /*0x1411a5eb9*/
        RakNet::CCRakNetSlidingWindow2::setTargetSpeed(this, newTargetSpeed: v37); /*0x1411a5ec4*/
        this->levelBlocksCount = 9; /*0x1411a5ec9*/
      }
      v38 = rttRangeQueue->m_last; /*0x1411a5ed1*/
      m_buff = rttRangeQueue->m_buff; /*0x1411a5ed5*/
      if ( v38 == rttRangeQueue->m_buff ) /*0x1411a5edb*/
        v40 = rttRangeQueue->m_end; /*0x1411a5edd*/
      else
        v40 = rttRangeQueue->m_last; /*0x1411a5ee3*/
      if ( v15 == &v40[-1] )
      {
        v41 = v38 == m_buff ? rttRangeQueue->m_end : rttRangeQueue->m_last;
        if ( time - v41[-1].timeSentFirst >= (unsigned __int64)DFInt::RakNetUseSlidingWindow2_minRtt )
        {
          v42 = v38 == m_buff ? rttRangeQueue->m_end : rttRangeQueue->m_last;
          if ( v42[-1].packetsSent > 2 ) /*0x1411a5f27*/
            goto LABEL_97; /*0x1411a5f27*/
          if ( v38 == m_buff ) /*0x1411a5f2c*/
            v38 = rttRangeQueue->m_end; /*0x1411a5f2e*/
          if ( v38[-1].bytesSent > (this->maxPayload - 12) / 2 ) /*0x1411a5f41*/
          {
LABEL_97:
            RakNet::CCRakNetSlidingWindow2::updateLastRecvStats(this, rttRangeQueue); /*0x1411a5f4d*/
            v43 = rttRangeQueue->m_size + 1; /*0x1411a5f5e*/
            memset(&item, 0, sizeof(item)); /*0x1411a5f64*/
            boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo>>::resize( /*0x1411a5f92*/
              this: rttRangeQueue,
              new_size: v43,
              &item);
            v44 = rttRangeQueue->m_last; /*0x1411a5f97*/
            if ( v44 == rttRangeQueue->m_buff ) /*0x1411a5fa2*/
              v44 = rttRangeQueue->m_end; /*0x1411a5fa4*/
            v44[-1].state = this->currentState; /*0x1411a5fa8*/
            v45 = rttRangeQueue->m_last; /*0x1411a5fab*/
            if ( v45 == rttRangeQueue->m_buff ) /*0x1411a5fb9*/
              v45 = rttRangeQueue->m_end; /*0x1411a5fbb*/
            v45[-1].targetSpeed = this->targetSpeed; /*0x1411a5fbf*/
            if ( this->appLimitedStart != 0 ) /*0x1411a5fca*/
            {
              v46 = rttRangeQueue->m_last; /*0x1411a5fcc*/
              if ( v46 == rttRangeQueue->m_buff ) /*0x1411a5fd3*/
                v46 = rttRangeQueue->m_end; /*0x1411a5fd5*/
              v46[-1].appLimited = true; /*0x1411a5fd9*/
            }
            if ( SLODWORD(rttRangeQueue->m_size) > DFInt::RakNetUseSlidingWindow2_rangeCount ) /*0x1411a5fe6*/
            {
              if ( ++rttRangeQueue->m_first == rttRangeQueue->m_end ) /*0x1411a5ff5*/
                rttRangeQueue->m_first = rttRangeQueue->m_buff; /*0x1411a5ffa*/
              --rttRangeQueue->m_size; /*0x1411a5ffe*/
            }
            ackSpeed_last4_offsetLimit = this->ackSpeed_last4_offsetLimit; /*0x1411a6002*/
            if ( ackSpeed_last4_offsetLimit != 0 ) /*0x1411a6008*/
            {
              v48 = ackSpeed_last4_offsetLimit + 1; /*0x1411a600a*/
              this->ackSpeed_last4_offsetLimit = v48; /*0x1411a600c*/
              if ( v48 >= rttRangeQueue->m_size ) /*0x1411a6016*/
                v48 = 0; /*0x1411a6016*/
              this->ackSpeed_last4_offsetLimit = v48; /*0x1411a6019*/
            }
            getRttMicroMin_offsetLimit = this->getRttMicroMin_offsetLimit; /*0x1411a601d*/
            if ( getRttMicroMin_offsetLimit != 0 ) /*0x1411a6023*/
            {
              v50 = getRttMicroMin_offsetLimit + 1; /*0x1411a6025*/
              this->getRttMicroMin_offsetLimit = v50; /*0x1411a6027*/
              if ( v50 >= rttRangeQueue->m_size ) /*0x1411a6031*/
                v50 = 0; /*0x1411a6031*/
              this->getRttMicroMin_offsetLimit = v50; /*0x1411a6034*/
            }
          }
        }
      }
    }
  }
}

// Address: 0x1411a6060 | Name: ?updateStartTargetSpeed@CCRakNetSlidingWindow2@RakNet@@AEAAX_J@Z
void __fastcall RakNet::CCRakNetSlidingWindow2::updateStartTargetSpeed(
        RakNet::CCRakNetSlidingWindow2 *this,
        __int64 curTime)
{
  __int64 targetSpeedStartTime; // rcx
  int v4; // edi
  int v5; // r9d
  unsigned __int64 m_size; // rsi
  unsigned __int64 v7; // r8
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *m_first; // r10
  __int64 RttMicroMin; // rcx
  int v10; // edx
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *m_end; // r8
  unsigned __int64 v12; // r10
  RakNet::CCRakNetSlidingWindow2::RttRangeInfo *v13; // r11
  __int64 v14; // r9
  unsigned __int64 v15; // rax
  __int64 v16; // rax
  double v17; // xmm6_8
  int SpeedLimit; // eax

  targetSpeedStartTime = this->targetSpeedStartTime; /*0x1411a6070*/
  v4 = curTime; /*0x1411a6077*/
  if ( targetSpeedStartTime == 0 /*0x1411a60af*/
    || 1000000 * (this->targetSpeedStartBytes + this->maxPayload - 12) / this->targetSpeed
     + targetSpeedStartTime
     + 20000 < curTime )
  {
    this->targetSpeedStartTime = 0; /*0x1411a60b1*/
    this->targetSpeedStartBytes = 0; /*0x1411a60b8*/
    this->operationState_startT0 = 0; /*0x1411a60bf*/
  }
  if ( this->appLimitedStart != 0 ) /*0x1411a60ca*/
  {
    this->operationState_startT0 = 0; /*0x1411a60cc*/
  }
  else if ( this->operationState_startT0 != 0 ) /*0x1411a60df*/
  {
    v5 = DFInt::RakNetUseSlidingWindow2_startUpdateMs; /*0x1411a60fd*/
    m_size = this->rttRangeQueue.m_size; /*0x1411a6109*/
    if ( m_size > 1 ) /*0x1411a6114*/
    {
      v7 = m_size - 2; /*0x1411a611d*/
      m_first = this->rttRangeQueue.m_first; /*0x1411a6121*/
      if ( (__int64)(m_size - 2) >= this->rttRangeQueue.m_end - m_first ) /*0x1411a6135*/
        v7 -= this->rttRangeQueue.m_end - this->rttRangeQueue.m_buff; /*0x1411a6142*/
      if ( m_first[v7].rttMicroMin < 2 * DFInt::RakNetUseSlidingWindow2_minRtt ) /*0x1411a6159*/
        v5 = DFInt::RakNetUseSlidingWindow2_startUpdateMs / 2; /*0x1411a6163*/
    }
    if ( curTime - this->lastUpdateStartTargetSpeed >= 1000LL * v5 ) /*0x1411a617a*/
    {
      this->lastUpdateStartTargetSpeed = curTime; /*0x1411a6188*/
      RttMicroMin = RakNet::CCRakNetSlidingWindow2::getRttMicroMin(this); /*0x1411a6191*/
      if ( RttMicroMin > 0 || (RttMicroMin = this->rttMicro) > 0 ) /*0x1411a61a3*/
      {
        v10 = RttMicroMin; /*0x1411a61b5*/
        if ( RttMicroMin < DFInt::RakNetUseSlidingWindow2_minRtt ) /*0x1411a61bb*/
        {
          RttMicroMin = DFInt::RakNetUseSlidingWindow2_minRtt; /*0x1411a61bd*/
          v10 = DFInt::RakNetUseSlidingWindow2_minRtt; /*0x1411a61c0*/
        }
      }
      else
      {
        RttMicroMin = 250000; /*0x1411a61a5*/
        v10 = 250000; /*0x1411a61aa*/
      }
      if ( m_size > 2 ) /*0x1411a61c7*/
      {
        m_end = this->rttRangeQueue.m_end; /*0x1411a61c9*/
        v12 = m_size - 3; /*0x1411a61d0*/
        v13 = this->rttRangeQueue.m_first; /*0x1411a61d4*/
        v14 = m_end - v13; /*0x1411a61e1*/
        if ( (__int64)(m_size - 3) >= v14 ) /*0x1411a61e8*/
          v12 -= m_end - this->rttRangeQueue.m_buff; /*0x1411a61f8*/
        v15 = m_size - 2; /*0x1411a61fb*/
        if ( (__int64)(m_size - 2) >= v14 ) /*0x1411a6202*/
          v15 -= m_end - this->rttRangeQueue.m_buff; /*0x1411a620f*/
        v16 = v13[v15].timeAckLast - v13[v12].timeAckLast; /*0x1411a621f*/
        if ( RttMicroMin < v16 ) /*0x1411a6227*/
          v10 = v16; /*0x1411a6227*/
      }
      v17 = pow_0( /*0x1411a626b*/
              X: (double)DFInt::RakNetUseSlidingWindow2_startFactor / 100.0,
              Y: (double)(v4 - LODWORD(this->operationState_startT0)) / (double)v10)
          * (double)this->operationState_startSpeed0;
      SpeedLimit = RakNet::CCRakNetSlidingWindow2::getSpeedLimit(this); /*0x1411a626f*/
      if ( SpeedLimit != -1 ) /*0x1411a6277*/
        v17 = fmin((double)SpeedLimit, v17); /*0x1411a6285*/
      RakNet::CCRakNetSlidingWindow2::setTargetSpeed(this, newTargetSpeed: (int)v17); /*0x1411a628f*/
    }
  }
  else
  {
    this->operationState_startSpeed0 = this->targetSpeed; /*0x1411a60e7*/
    this->operationState_startT0 = curTime; /*0x1411a60ea*/
    this->lastUpdateStartTargetSpeed = curTime; /*0x1411a60ee*/
  }
}

// END CCRakNetSlidingWindow2 part 1/1, 33 functions
