// BufferedCommandStruct -- 2022 Studio + full PDB
// tier 3, 2 functions


// Address: 0x1410b7420 | Name: ??0BufferedCommandStruct@RakPeer@RakNet@@QEAA@$$QEAU012@@Z
RakNet::RakPeer::BufferedCommandStruct *__fastcall RakNet::RakPeer::BufferedCommandStruct::BufferedCommandStruct(
        RakNet::RakPeer::BufferedCommandStruct *this,
        RakNet::RakPeer::BufferedCommandStruct *__that)
{
  RakNet::AddressOrGUID *p_systemIdentifier; // rcx

  this->stream._Ptr = nullptr; /*0x1410b7442*/
  this->stream._Rep = nullptr; /*0x1410b7445*/
  this->stream = __that->stream; /*0x1410b744c*/
  __that->stream._Ptr = nullptr; /*0x1410b7457*/
  __that->stream._Rep = nullptr; /*0x1410b745a*/
  this->numberOfBitsToSend = __that->numberOfBitsToSend; /*0x1410b7461*/
  this->priority = __that->priority; /*0x1410b7468*/
  this->reliability = __that->reliability; /*0x1410b746f*/
  this->orderingChannel = __that->orderingChannel; /*0x1410b7477*/
  p_systemIdentifier = &this->systemIdentifier; /*0x1410b747b*/
  __wind /*0xf1c0000000000010*/
  {
    RakNet::RakNetGUID::RakNetGUID(this: &p_systemIdentifier->rakNetGuid); /*0x1410b747f*/
    RakNet::SystemAddress::SystemAddress(this: &this->systemIdentifier.systemAddress); /*0x1410b7488*/
    this->systemIdentifier.rakNetGuid.g = __that->systemIdentifier.rakNetGuid.g; /*0x1410b7491*/
    this->systemIdentifier.rakNetGuid.systemIndex = __that->systemIdentifier.rakNetGuid.systemIndex; /*0x1410b7499*/
    RakNet::SystemAddress::operator=( /*0x1410b74a6*/
      this: &this->systemIdentifier.systemAddress,
      input: &__that->systemIdentifier.systemAddress);
    this->broadcast = __that->broadcast; /*0x1410b74af*/
    this->connectionMode = __that->connectionMode; /*0x1410b74b6*/
    this->networkID = __that->networkID; /*0x1410b74be*/
    this->blockingCommand = __that->blockingCommand; /*0x1410b74c6*/
    this->data = __that->data; /*0x1410b74ce*/
    this->haveRakNetCloseSocket = __that->haveRakNetCloseSocket; /*0x1410b74d6*/
    this->connectionSocketIndex = __that->connectionSocketIndex; /*0x1410b74dd*/
    this->socket = __that->socket; /*0x1410b74e5*/
    this->port = __that->port; /*0x1410b74f0*/
    this->receipt = __that->receipt; /*0x1410b74fe*/
    this->isJoinData = __that->isJoinData; /*0x1410b750c*/
    this->queueTime = __that->queueTime; /*0x1410b751a*/
    this->command = __that->command; /*0x1410b7527*/
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>((std::shared_ptr<RBX::File> *)this); /*0xf1c0000000000008*/
  }
  return this; /*0x1410b7531*/
}

// Address: 0x1410b7550 | Name: ??0BufferedCommandStruct@RakPeer@RakNet@@QEAA@AEBU012@@Z
RakNet::RakPeer::BufferedCommandStruct *__fastcall RakNet::RakPeer::BufferedCommandStruct::BufferedCommandStruct(
        RakNet::RakPeer::BufferedCommandStruct *this,
        const RakNet::RakPeer::BufferedCommandStruct *__that)
{
  std::_Ref_count_base *Rep; // rax
  RakNet::AddressOrGUID *p_systemIdentifier; // rcx

  this->stream._Ptr = nullptr; /*0x1410b7572*/
  this->stream._Rep = nullptr; /*0x1410b7575*/
  Rep = __that->stream._Rep; /*0x1410b7579*/
  if ( Rep != nullptr ) /*0x1410b7580*/
    _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x1410b7582*/
  this->stream = __that->stream; /*0x1410b7589*/
  this->numberOfBitsToSend = __that->numberOfBitsToSend; /*0x1410b7597*/
  this->priority = __that->priority; /*0x1410b759d*/
  this->reliability = __that->reliability; /*0x1410b75a3*/
  this->orderingChannel = __that->orderingChannel; /*0x1410b75aa*/
  p_systemIdentifier = &this->systemIdentifier; /*0x1410b75ad*/
  __wind /*0xf1c0000000000010*/
  {
    RakNet::RakNetGUID::RakNetGUID(this: &p_systemIdentifier->rakNetGuid); /*0x1410b75b1*/
    RakNet::SystemAddress::SystemAddress(this: &this->systemIdentifier.systemAddress); /*0x1410b75ba*/
    this->systemIdentifier.rakNetGuid.g = __that->systemIdentifier.rakNetGuid.g; /*0x1410b75c3*/
    this->systemIdentifier.rakNetGuid.systemIndex = __that->systemIdentifier.rakNetGuid.systemIndex; /*0x1410b75cc*/
    RakNet::SystemAddress::operator=( /*0x1410b75d8*/
      this: &this->systemIdentifier.systemAddress,
      input: &__that->systemIdentifier.systemAddress);
    this->broadcast = __that->broadcast; /*0x1410b75e2*/
    this->connectionMode = __that->connectionMode; /*0x1410b75e9*/
    this->networkID = __that->networkID; /*0x1410b75f0*/
    this->blockingCommand = __that->blockingCommand; /*0x1410b75f9*/
    this->data = __that->data; /*0x1410b7600*/
    this->haveRakNetCloseSocket = __that->haveRakNetCloseSocket; /*0x1410b7609*/
    this->connectionSocketIndex = __that->connectionSocketIndex; /*0x1410b7610*/
    this->socket = __that->socket; /*0x1410b7617*/
    this->port = __that->port; /*0x1410b7623*/
    this->receipt = __that->receipt; /*0x1410b7631*/
    this->isJoinData = __that->isJoinData; /*0x1410b763f*/
    this->queueTime = __that->queueTime; /*0x1410b764c*/
    this->command = __that->command; /*0x1410b765a*/
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>((std::shared_ptr<RBX::File> *)this); /*0xf1c0000000000008*/
  }
  return this; /*0x1410b7663*/
}

// END BufferedCommandStruct part 1/1, 2 functions
