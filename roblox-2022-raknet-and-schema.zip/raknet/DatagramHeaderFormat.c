// DatagramHeaderFormat -- 2022 Studio + full PDB
// tier 3, 2 functions


// Address: 0x1410fedd0 | Name: ?Deserialize@DatagramHeaderFormat@RakNet@@QEAAXPEAVBitStream@2@_N111@Z
void __fastcall RakNet::DatagramHeaderFormat::Deserialize(
        RakNet::DatagramHeaderFormat *this,
        RakNet::BitStream *b,
        bool includeTimestamp,
        bool avoidPacketSizeCapable,
        bool readJoinDataBit,
        bool readResentBit)
{
  unsigned int readOffset; // r10d
  unsigned int numberOfBitsUsed; // ecx
  unsigned int v11; // r9d
  unsigned int v12; // ecx
  unsigned int v13; // ecx
  unsigned int v14; // r9d
  unsigned int v15; // ecx
  unsigned int timeMS; // [rsp+40h] [rbp+8h] BYREF
  unsigned __int8 inOutByteArray; // [rsp+48h] [rbp+10h] BYREF

  readOffset = b->readOffset; /*0x1410feddc*/
  numberOfBitsUsed = b->numberOfBitsUsed; /*0x1410fede3*/
  if ( readOffset + 1 <= numberOfBitsUsed ) /*0x1410fedfd*/
  {
    this->isValid = (b->data[(unsigned __int64)readOffset >> 3] & (unsigned __int8)(128 >> (readOffset & 7))) != 0; /*0x1410fee22*/
    readOffset = ++b->readOffset; /*0x1410fee28*/
    numberOfBitsUsed = b->numberOfBitsUsed; /*0x1410fee2c*/
  }
  if ( readOffset + 1 <= numberOfBitsUsed ) /*0x1410fee35*/
  {
    this->isACK = (b->data[(unsigned __int64)readOffset >> 3] & (unsigned __int8)(128 >> (readOffset & 7))) != 0; /*0x1410fee58*/
    readOffset = ++b->readOffset; /*0x1410fee5e*/
  }
  if ( this->isACK ) /*0x1410fee62*/
  {
    this->isNAK = false; /*0x1410fee6c*/
    v11 = b->readOffset; /*0x1410fee70*/
    v12 = b->numberOfBitsUsed; /*0x1410fee74*/
    if ( v11 + 1 <= v12 ) /*0x1410fee7d*/
    {
      this->hasBAndAS = (b->data[(unsigned __int64)v11 >> 3] & (unsigned __int8)(128 >> (v11 & 7))) != 0; /*0x1410feea2*/
      v11 = ++b->readOffset; /*0x1410feea8*/
      v12 = b->numberOfBitsUsed; /*0x1410feeac*/
    }
    if ( v11 + 1 <= v12 ) /*0x1410feeb5*/
    {
      this->hasAckTimestamps = (b->data[(unsigned __int64)v11 >> 3] & (unsigned __int8)(128 >> (v11 & 7))) != 0; /*0x1410feed7*/
      v11 = b->readOffset + 1; /*0x1410feede*/
    }
    b->readOffset = v11 - (((_BYTE)v11 - 1) & 7) + 7; /*0x1410feeef*/
    if ( includeTimestamp ) /*0x1410feef6*/
    {
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410feef8*/
      {
        RakNet::BitStream::ReadBits( /*0x1410fef37*/
          this: b,
          inOutByteArray: (unsigned __int8 *)&timeMS,
          numberOfBitsToRead: 0x20u,
          alignBitsToRight: true);
      }
      else if ( RakNet::BitStream::ReadBits(this: b, &inOutByteArray, numberOfBitsToRead: 0x20u, alignBitsToRight: true) != 0 ) /*0x1410fef19*/
      {
        RBX::Network::NetworkStream::ReverseBytes( /*0x1410fef2b*/
          inByteArray: &inOutByteArray,
          inOutByteArray: (unsigned __int8 *)&timeMS,
          length: 4u);
      }
      this->sourceSystemTime = timeMS; /*0x1410fef40*/
    }
    if ( this->hasBAndAS ) /*0x1410fef43*/
    {
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410fef49*/
      {
        RakNet::BitStream::ReadBits( /*0x1410fef86*/
          this: b,
          inOutByteArray: (unsigned __int8 *)&this->AS,
          numberOfBitsToRead: 0x20u,
          alignBitsToRight: true);
      }
      else if ( RakNet::BitStream::ReadBits( /*0x1410fef6a*/
                  this: b,
                  inOutByteArray: (unsigned __int8 *)&timeMS,
                  numberOfBitsToRead: 0x20u,
                  alignBitsToRight: true) != 0 )
      {
        RBX::Network::NetworkStream::ReverseBytes( /*0x1410fef7b*/
          inByteArray: (unsigned __int8 *)&timeMS,
          inOutByteArray: (unsigned __int8 *)&this->AS,
          length: 4u);
      }
    }
    if ( avoidPacketSizeCapable ) /*0x1410fef8e*/
      goto LABEL_48; /*0x1410fef8e*/
  }
  else
  {
    if ( readOffset + 1 <= b->numberOfBitsUsed ) /*0x1410fefa0*/
    {
      this->isNAK = (b->data[(unsigned __int64)readOffset >> 3] & (unsigned __int8)(128 >> (readOffset & 7))) != 0; /*0x1410fefc3*/
      readOffset = ++b->readOffset; /*0x1410fefc9*/
    }
    if ( this->isNAK ) /*0x1410fefcd*/
    {
      if ( !avoidPacketSizeCapable ) /*0x1410ff140*/
        return; /*0x1410ff140*/
      b->readOffset = readOffset - (((_BYTE)readOffset - 1) & 7) + 7; /*0x1410ff150*/
      goto LABEL_48; /*0x1410ff150*/
    }
    v13 = readOffset; /*0x1410fefdc*/
    if ( readJoinDataBit && readOffset + 1 <= b->numberOfBitsUsed ) /*0x1410fefe8*/
    {
      this->isJoinData = (b->data[(unsigned __int64)readOffset >> 3] & (unsigned __int8)(128 >> (readOffset & 7))) != 0; /*0x1410ff00b*/
      v13 = ++b->readOffset; /*0x1410ff011*/
    }
    v14 = v13; /*0x1410ff019*/
    if ( readResentBit && v13 + 1 <= b->numberOfBitsUsed ) /*0x1410ff024*/
    {
      this->isResentData = (b->data[(unsigned __int64)v13 >> 3] & (unsigned __int8)(128 >> (v13 & 7))) != 0; /*0x1410ff043*/
      v14 = ++b->readOffset; /*0x1410ff049*/
    }
    v15 = b->numberOfBitsUsed; /*0x1410ff04d*/
    if ( v14 + 1 <= v15 ) /*0x1410ff056*/
      b->readOffset = ++v14; /*0x1410ff058*/
    if ( v14 + 1 <= v15 ) /*0x1410ff064*/
    {
      this->isContinuousSend = (b->data[(unsigned __int64)v14 >> 3] & (unsigned __int8)(128 >> (v14 & 7))) != 0; /*0x1410ff089*/
      v14 = ++b->readOffset; /*0x1410ff08f*/
      v15 = b->numberOfBitsUsed; /*0x1410ff093*/
    }
    if ( v14 + 1 <= v15 ) /*0x1410ff09c*/
    {
      this->needsBAndAs = (b->data[(unsigned __int64)v14 >> 3] & (unsigned __int8)(128 >> (v14 & 7))) != 0; /*0x1410ff0be*/
      v14 = b->readOffset + 1; /*0x1410ff0c5*/
    }
    b->readOffset = v14 - (((_BYTE)v14 - 1) & 7) + 7; /*0x1410ff0d6*/
    if ( includeTimestamp ) /*0x1410ff0dd*/
    {
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410ff0df*/
      {
        RakNet::BitStream::ReadBits( /*0x1410ff11e*/
          this: b,
          inOutByteArray: (unsigned __int8 *)&timeMS,
          numberOfBitsToRead: 0x20u,
          alignBitsToRight: true);
      }
      else if ( RakNet::BitStream::ReadBits(this: b, &inOutByteArray, numberOfBitsToRead: 0x20u, alignBitsToRight: true) != 0 ) /*0x1410ff100*/
      {
        RBX::Network::NetworkStream::ReverseBytes( /*0x1410ff112*/
          inByteArray: &inOutByteArray,
          inOutByteArray: (unsigned __int8 *)&timeMS,
          length: 4u);
      }
      this->sourceSystemTime = timeMS; /*0x1410ff127*/
    }
    RakNet::BitStream::Read<RakNet::uint24_t>(this: b, outTemplateVar: &this->datagramNumber); /*0x1410ff131*/
    if ( avoidPacketSizeCapable ) /*0x1410ff139*/
LABEL_48:
      RakNet::BitStream::Read<unsigned short>(this: b, outTemplateVar: &this->extraPadding); /*0x1410ff154*/
  }
}

// Address: 0x141105270 | Name: ?Serialize@DatagramHeaderFormat@RakNet@@QEAAXPEAVBitStream@2@_NAEAI111@Z
void __fastcall RakNet::DatagramHeaderFormat::Serialize(
        RakNet::DatagramHeaderFormat *this,
        RakNet::BitStream *b,
        bool includeTimestamp,
        unsigned int *paddingLocation,
        unsigned __int8 avoidPacketSizeCapable,
        bool sendJoinDataBit,
        bool writeResentBit)
{
  unsigned __int8 *p_timeMSLow; // rdx
  unsigned __int8 *v12; // rdx
  unsigned __int8 *p_extraPadding; // rdx
  unsigned __int8 inOutByteArray[24]; // [rsp+20h] [rbp-18h] BYREF
  unsigned int timeMSLow; // [rsp+40h] [rbp+8h] BYREF

  RakNet::BitStream::Write1(this: b); /*0x141105295*/
  if ( this->isACK ) /*0x14110529a*/
  {
    RakNet::BitStream::Write1(this: b); /*0x1411052a7*/
    if ( this->hasBAndAS ) /*0x1411052ac*/
      RakNet::BitStream::Write1(this: b); /*0x1411052b5*/
    else
      RakNet::BitStream::Write0(this: b); /*0x1411052bc*/
    if ( this->hasAckTimestamps ) /*0x1411052c1*/
      RakNet::BitStream::Write1(this: b); /*0x1411052ca*/
    else
      RakNet::BitStream::Write0(this: b); /*0x1411052d1*/
    b->numberOfBitsUsed = b->numberOfBitsUsed - (((unsigned __int8)b->numberOfBitsUsed - 1) & 7) + 7; /*0x1411052e4*/
    if ( includeTimestamp ) /*0x1411052ea*/
    {
      timeMSLow = this->sourceSystemTime; /*0x1411052ee*/
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1411052f2*/
      {
        p_timeMSLow = (unsigned __int8 *)&timeMSLow; /*0x141105317*/
      }
      else
      {
        RBX::Network::NetworkStream::ReverseBytes( /*0x14110530b*/
          inByteArray: (unsigned __int8 *)&timeMSLow,
          inOutByteArray,
          length: 4u);
        p_timeMSLow = inOutByteArray; /*0x141105310*/
      }
      RakNet::BitStream::WriteBits( /*0x141105328*/
        this: b,
        inByteArray: p_timeMSLow,
        numberOfBitsToWrite: 0x20u,
        rightAlignedBits: true);
    }
    if ( this->hasBAndAS ) /*0x14110532d*/
    {
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x141105337*/
      {
        RakNet::BitStream::WriteBits( /*0x14110537f*/
          this: b,
          inByteArray: (unsigned __int8 *)&this->AS,
          numberOfBitsToWrite: 0x20u,
          rightAlignedBits: true);
      }
      else
      {
        RBX::Network::NetworkStream::ReverseBytes( /*0x14110534f*/
          inByteArray: (unsigned __int8 *)&this->AS,
          inOutByteArray: (unsigned __int8 *)&timeMSLow,
          length: 4u);
        RakNet::BitStream::WriteBits( /*0x141105365*/
          this: b,
          inByteArray: (unsigned __int8 *)&timeMSLow,
          numberOfBitsToWrite: 0x20u,
          rightAlignedBits: true);
      }
    }
    goto LABEL_40; /*0x14110536a*/
  }
  if ( !this->isNAK ) /*0x14110538d*/
  {
    RakNet::BitStream::Write0(this: b); /*0x1411053bd*/
    RakNet::BitStream::Write0(this: b); /*0x1411053c5*/
    if ( sendJoinDataBit ) /*0x1411053cf*/
    {
      if ( this->isJoinData ) /*0x1411053d1*/
        RakNet::BitStream::Write1(this: b); /*0x1411053da*/
      else
        RakNet::BitStream::Write0(this: b); /*0x1411053e1*/
    }
    if ( writeResentBit ) /*0x1411053eb*/
    {
      if ( this->isResentData ) /*0x1411053ed*/
        RakNet::BitStream::Write1(this: b); /*0x1411053f6*/
      else
        RakNet::BitStream::Write0(this: b); /*0x1411053fd*/
    }
    RakNet::BitStream::Write0(this: b); /*0x141105405*/
    if ( this->isContinuousSend ) /*0x14110540a*/
      RakNet::BitStream::Write1(this: b); /*0x141105413*/
    else
      RakNet::BitStream::Write0(this: b); /*0x14110541a*/
    if ( this->needsBAndAs ) /*0x14110541f*/
      RakNet::BitStream::Write1(this: b); /*0x141105428*/
    else
      RakNet::BitStream::Write0(this: b); /*0x14110542f*/
    b->numberOfBitsUsed = b->numberOfBitsUsed - (((unsigned __int8)b->numberOfBitsUsed - 1) & 7) + 7; /*0x141105442*/
    if ( includeTimestamp ) /*0x141105448*/
    {
      timeMSLow = this->sourceSystemTime; /*0x14110544c*/
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x141105450*/
      {
        v12 = (unsigned __int8 *)&timeMSLow; /*0x141105475*/
      }
      else
      {
        RBX::Network::NetworkStream::ReverseBytes( /*0x141105469*/
          inByteArray: (unsigned __int8 *)&timeMSLow,
          inOutByteArray,
          length: 4u);
        v12 = inOutByteArray; /*0x14110546e*/
      }
      RakNet::BitStream::WriteBits(this: b, inByteArray: v12, numberOfBitsToWrite: 0x20u, rightAlignedBits: true); /*0x141105486*/
    }
    RakNet::BitStream::Write<RakNet::uint24_t>(this: b, inTemplateVar: &this->datagramNumber); /*0x141105492*/
LABEL_40:
    if ( avoidPacketSizeCapable == 0 ) /*0x14110549c*/
      return; /*0x14110549c*/
    goto LABEL_41; /*0x14110549c*/
  }
  RakNet::BitStream::Write0(this: b); /*0x14110538f*/
  RakNet::BitStream::Write1(this: b); /*0x141105397*/
  if ( avoidPacketSizeCapable == 0 ) /*0x1411053a1*/
    return; /*0x1411053a1*/
  b->numberOfBitsUsed = b->numberOfBitsUsed - (((unsigned __int8)b->numberOfBitsUsed - 1) & 7) + 7; /*0x1411053b5*/
LABEL_41:
  *paddingLocation = b->numberOfBitsUsed; /*0x14110549e*/
  if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1411054a4*/
  {
    p_extraPadding = (unsigned __int8 *)&this->extraPadding; /*0x1411054c8*/
  }
  else
  {
    RBX::Network::NetworkStream::ReverseBytes( /*0x1411054bc*/
      inByteArray: (unsigned __int8 *)&this->extraPadding,
      inOutByteArray: &avoidPacketSizeCapable,
      length: 2u);
    p_extraPadding = &avoidPacketSizeCapable; /*0x1411054c1*/
  }
  RakNet::BitStream::WriteBits(this: b, inByteArray: p_extraPadding, numberOfBitsToWrite: 0x10u, rightAlignedBits: true); /*0x1411054d8*/
}

// END DatagramHeaderFormat part 1/1, 2 functions
