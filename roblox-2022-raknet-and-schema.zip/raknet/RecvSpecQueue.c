// RecvSpecQueue -- 2022 Studio + full PDB
// tier 3, 1 functions


// Address: 0x1410b80c0 | Name: ??1RecvSpecQueue@RakPeer@RakNet@@QEAA@XZ
void __fastcall RakNet::RakPeer::RecvSpecQueue::~RecvSpecQueue(RakNet::RakPeer::RecvSpecQueue *this)
{
  __int64 v2; // rcx
  __int64 v3; // [rsp+0h] [rbp-28h] BYREF

  RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &this->queueMutex.criticalSection); /*0x1410b80cd*/
  if ( this->queue.allocation_size != 0 ) /*0x1410b80d6*/
    operator delete(ptr: this->queue.array); /*0x1410b80dc*/
  RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &this->memoryPoolMutex.criticalSection); /*0x1410b80e5*/
  __wind /*0xf1c0000000000020*/
  {
    DataStructures::MemoryPool<RakNet::RemoteSystemIndex>::Clear( /*0x1410b80fb*/
      (DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode> *)this,
      file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\DS_MemoryPool.h",
      line: 0x51u);
  }
  __unwind
  {
    __std_terminate(a1: v2, a2: &v3); /*0x142f39fa8*/
  }
}

// END RecvSpecQueue part 1/1, 1 functions
