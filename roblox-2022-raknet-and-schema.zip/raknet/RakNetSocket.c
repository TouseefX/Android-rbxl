// RakNetSocket -- 2022 Studio + full PDB
// tier 3, 2 functions


// Address: 0x14118f560 | Name: ??0RakNetSocket@RakNet@@QEAA@XZ
RakNet::RakNetSocket *__fastcall RakNet::RakNetSocket::RakNetSocket(RakNet::RakNetSocket *this)
{
  RakNet::SystemAddress::SystemAddress(this: &this->boundAddress); /*0x14118f56d*/
  this->s = -1; /*0x14118f575*/
  this->recvEvent = (void *)-1LL; /*0x14118f57c*/
  return this; /*0x14118f584*/
}

// Address: 0x14118f590 | Name: ??1RakNetSocket@RakNet@@QEAA@XZ
void __fastcall RakNet::RakNetSocket::~RakNetSocket(RakNet::RakNetSocket *this)
{
  void *recvEvent; // rcx
  char addressBuffer[1048]; // [rsp+30h] [rbp-418h] BYREF

  RakNet::SystemAddress::ToStringN( /*0x14118f5b2*/
    this: &this->boundAddress,
    writePort: true,
    dest: addressBuffer,
    size: 1025,
    portDelineator: 124);
  if ( DFLog::NetworkAudit != 0 )
    FLog::FastLog(
      level: DFLog::NetworkAudit,
      message: "[DFLog::NetworkAudit] RakNet Socket Close: %s",
      arg0: addressBuffer);
  if ( this->s != -1 ) /*0x14118f5da*/
    closesocket(s: this->s); /*0x14118f5dc*/
  recvEvent = this->recvEvent; /*0x14118f5e2*/
  if ( recvEvent != (void *)-1LL ) /*0x14118f5ea*/
  {
    CloseHandle(hObject: recvEvent); /*0x14118f5ec*/
    this->recvEvent = (void *)-1LL; /*0x14118f5f2*/
  }
  this->s = -1; /*0x14118f5fa*/
}

// END RakNetSocket part 1/1, 2 functions
