// ReliabilityLayer -- 2022 Studio + full PDB
// tier 3, 55 functions


// Address: 0x140735dd0 | Name: ?SetSplitMessageProgressInterval@ReliabilityLayer@RakNet@@QEAAXH@Z
void __fastcall RakNet::ReliabilityLayer::SetSplitMessageProgressInterval(RakNet::ReliabilityLayer *this, int interval)
{
  this->splitMessageProgressInterval = interval; /*0x140735dd0*/
}

// Address: 0x1410d1480 | Name: ?setAvoidedPacketSizes@ReliabilityLayer@RakNet@@QEAAXAEAV?$vector@HV?$allocator@H@std@@@std@@@Z
void __fastcall RakNet::ReliabilityLayer::setAvoidedPacketSizes(
        RakNet::ReliabilityLayer *this,
        std::vector<int> *packetSizes)
{
  std::vector<int> *p_avoidedPacketSizes; // rbx
  int *Myfirst; // rbp
  signed __int64 v4; // rsi
  int *v5; // rdi

  p_avoidedPacketSizes = &this->avoidedPacketSizes; /*0x1410d1486*/
  if ( &this->avoidedPacketSizes != packetSizes ) /*0x1410d1490*/
  {
    Myfirst = packetSizes->_Mypair._Myval2._Myfirst; /*0x1410d149b*/
    v4 = (char *)packetSizes->_Mypair._Myval2._Mylast - (char *)packetSizes->_Mypair._Myval2._Myfirst; /*0x1410d14a7*/
    v5 = p_avoidedPacketSizes->_Mypair._Myval2._Myfirst; /*0x1410d14af*/
    if ( v4 >> 2 > (unsigned __int64)(this->avoidedPacketSizes._Mypair._Myval2._Myend /*0x1410d14c3*/
                                    - p_avoidedPacketSizes->_Mypair._Myval2._Myfirst) )
    {
      std::vector<webrtc::RtpPacket::ExtensionInfo>::_Clear_and_reserve_geometric( /*0x1410d14c8*/
        this: (std::vector<webrtc::RtpPacket::ExtensionInfo> *)&this->avoidedPacketSizes,
        _Newsize: v4 >> 2);
      v5 = p_avoidedPacketSizes->_Mypair._Myval2._Myfirst; /*0x1410d14cd*/
    }
    memmove_0(a1: v5, Src: Myfirst, Size: v4); /*0x1410d14d9*/
    p_avoidedPacketSizes->_Mypair._Myval2._Mylast = (int *)((char *)v5 + v4); /*0x1410d14f1*/
  }
}

// Address: 0x1410fc7c0 | Name: ??0ReliabilityLayer@RakNet@@QEAA@XZ
RakNet::ReliabilityLayer *__fastcall RakNet::ReliabilityLayer::ReliabilityLayer(RakNet::ReliabilityLayer *this)
{
  std::map<RakNet::uint24_t,RakNet::InternalPacket *> *p_resendBuffer2; // rbx
  std::_Tree_node<std::pair<RakNet::uint24_t const ,RakNet::InternalPacket *>,void *> *v3; // rax
  RakNet::CCRakNetSlidingWindow2 *v4; // rax
  RakNet::CCRakNetSlidingWindow *v5; // rax
  RakNet::CCRakNetSlidingWindow *v6; // rax
  RakNet::InternalPacket **Mylast; // rbp
  RakNet::InternalPacket **Myfirst; // rdx
  unsigned __int64 v9; // rcx
  RakNet::InternalPacket **v10; // rax
  size_t v11; // rbx
  std::map<RakNet::uint24_t,RakNet::InternalPacket *> *_Val; // [rsp+58h] [rbp+10h] BYREF

  __wind /*0xf1c000000000023c*/
  {
    __wind /*0xf1c0000000000244*/
    {
      __wind /*0xf1c000000000024c*/
      {
        __wind /*0xf1c0000000000254*/
        {
          __wind /*0xf1c000000000025c*/
          {
            __wind /*0xf1c0000000000264*/
            {
              __wind /*0xf1c000000000026c*/
              {
                __wind /*0xf1c0000000000274*/
                {
                  this->rbxSessionCrypto._Ptr = nullptr; /*0x1410fc7dd*/
                  this->rbxSessionCrypto._Rep = nullptr; /*0x1410fc7e0*/
                  this->tLibTestClientStats.finished._Storage._Value = false; /*0x1410fc7e4*/
                  this->tLibTestClientStats.startTime._Storage._Value = 0; /*0x1410fc7e8*/
                  this->tLibTestClientStats.finishedTime._Storage._Value = 0; /*0x1410fc7ec*/
                  this->tLibTestClientStats.bytesSent._Storage._Value = 0; /*0x1410fc7f0*/
                  this->tLibTestClientStats.bytesToSend._Storage._Value = 0; /*0x1410fc7f4*/
                  this->tLibTestClientStats.bytesReceived._Storage._Value = 0; /*0x1410fc7f8*/
                  this->tLibTestClientStats.bytesToReceive._Storage._Value = 0; /*0x1410fc7fc*/
                  this->tLibTestClientStats.address._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410fc800*/
                  this->tLibTestClientStats.address._Mypair._Myval2._Mysize = 0; /*0x1410fc804*/
                  this->tLibTestClientStats.address._Mypair._Myval2._Myres = 15; /*0x1410fc808*/
                  *(_QWORD *)&this->outputQueue.tail = 0; /*0x1410fc810*/
                  this->outputQueue.array = nullptr; /*0x1410fc814*/
                  this->outputQueue.head = 0; /*0x1410fc818*/
                  *(_QWORD *)&this->datagramHistory.tail = 0; /*0x1410fc81c*/
                  this->datagramHistory.array = nullptr; /*0x1410fc823*/
                  this->datagramHistory.head = 0; /*0x1410fc82a*/
                  *(_QWORD *)&this->datagramHistoryMessagePool.availablePagesSize = 0; /*0x1410fc831*/
                  this->datagramHistoryMessagePool.memoryPoolPageSize = 0x4000; /*0x1410fc838*/
                  *(_QWORD *)&this->unreliableWithAckReceiptHistory.list_size = 0; /*0x1410fc842*/
                  this->unreliableWithAckReceiptHistory.listArray = nullptr; /*0x1410fc849*/
                  *(_QWORD *)&this->internalPacketPool.availablePagesSize = 0; /*0x1410fc850*/
                  this->internalPacketPool.memoryPoolPageSize = 0x4000; /*0x1410fc857*/
                  this->resendBuffer._Mypair._Myval2._Myfirst = nullptr; /*0x1410fc861*/
                  this->resendBuffer._Mypair._Myval2._Mylast = nullptr; /*0x1410fc868*/
                  this->resendBuffer._Mypair._Myval2._Myend = nullptr; /*0x1410fc86f*/
                  p_resendBuffer2 = &this->resendBuffer2; /*0x1410fc876*/
                  _Val = &this->resendBuffer2; /*0x1410fc87d*/
                  this->resendBuffer2._Mypair._Myval2._Myval2._Myhead = nullptr; /*0x1410fc882*/
                  this->resendBuffer2._Mypair._Myval2._Myval2._Mysize = 0; /*0x1410fc885*/
                  v3 = (std::_Tree_node<std::pair<RakNet::uint24_t const ,RakNet::InternalPacket *>,void *> *)operator new(size: 0x30u); /*0x1410fc88d*/
                  __wind /*0xf1c0000000000220*/
                  {
                    __wind /*0xf1c0000000000228*/
                    {
                      __wind /*0xf1c0000000000230*/
                      {
                        v3->_Left = v3; /*0x1410fc892*/
                        v3->_Parent = v3; /*0x1410fc895*/
                        v3->_Right = v3; /*0x1410fc899*/
                        *(_WORD *)&v3->_Color = 257; /*0x1410fc89d*/
                        p_resendBuffer2->_Mypair._Myval2._Myval2._Myhead = v3; /*0x1410fc8a3*/
                        *(_QWORD *)&this->outgoingPacketBuffer.heap.list_size = 0; /*0x1410fc8a6*/
                        this->outgoingPacketBuffer.heap.listArray = nullptr; /*0x1410fc8ad*/
                        this->outgoingPacketBuffer.optimizeNextSeriesPush = false; /*0x1410fc8b4*/
                        *(_QWORD *)&this->splitPacketChannelList.orderedList.list_size = 0; /*0x1410fc8bb*/
                        this->splitPacketChannelList.orderedList.listArray = nullptr; /*0x1410fc8c2*/
                        *(_OWORD *)this->statistics.valueOverLastSecond = 0; /*0x1410fc8ce*/
                        *(_OWORD *)&this->statistics.valueOverLastSecond[2] = 0; /*0x1410fc8d5*/
                        *(_OWORD *)&this->statistics.valueOverLastSecond[4] = 0; /*0x1410fc8dc*/
                        this->statistics.valueOverLastSecond[6] = 0; /*0x1410fc8e3*/
                        *(_OWORD *)&this->statistics.ds.totalBytesRakPeerSent = 0; /*0x1410fc8ea*/
                        *(_OWORD *)&this->statistics.ds.totalBytesReceived = 0; /*0x1410fc8f1*/
                        *(_OWORD *)&this->statistics.ds.totalJoinDataRakPeerSent = 0; /*0x1410fc8f8*/
                        *(_OWORD *)&this->statistics.ds.totalJoinDataSent = 0; /*0x1410fc8ff*/
                        *(_OWORD *)&this->statistics.ds.totalJoinDataSentCount = 0; /*0x1410fc906*/
                        *(_OWORD *)&this->statistics.ds.joinInternalResentRTOCount = 0; /*0x1410fc90d*/
                        this->statistics.ds.totalJoinDataNakSize_DEPRECATED = 0; /*0x1410fc914*/
                        *(_QWORD *)&this->statistics.perSecTxBw_deprecated.availableCapacity = 0; /*0x1410fc91b*/
                        *(_QWORD *)&this->statistics.perSecTxBw_deprecated.reliablePacketBytes = 0; /*0x1410fc922*/
                        *(_QWORD *)&this->statistics.perSecTxBw_deprecated.reliablePacketBytesRe = 0; /*0x1410fc929*/
                        *(_QWORD *)&this->statistics.perSecTxBw_deprecated.unreliablePacketBytes = 0; /*0x1410fc930*/
                        *(_QWORD *)&this->statistics.perSecTxBwData.availableCapacity = 0; /*0x1410fc937*/
                        *(_QWORD *)&this->statistics.perSecTxBwData.allBytes = 0; /*0x1410fc93e*/
                        *(_QWORD *)&this->statistics.perSecTxBwData.reliablePackets = 0; /*0x1410fc945*/
                        *(_QWORD *)&this->statistics.perSecTxBwData.reliablePacketsRe = 0; /*0x1410fc94c*/
                        *(_QWORD *)&this->statistics.perSecTxBwData.unreliablePackets = 0; /*0x1410fc953*/
                        *(_QWORD *)&this->statistics.perSecTxBwData.txBwInfluencers.bwLimitedByAppCount = 0; /*0x1410fc95a*/
                        *(_QWORD *)&this->statistics.perSecTxBwData.txBwInfluencers.nonZeroTargetSpeedStartTimeCount = 0; /*0x1410fc961*/
                        *(_QWORD *)&this->statistics.perSecTxBwData.txBwInfluencers.bytesGivenByTargetSpeed = 0; /*0x1410fc968*/
                        *(_QWORD *)&this->statistics.perSecTxBwData.txBwInfluencers.bwCappedDueTo2xTargetSpeedCount = 0; /*0x1410fc96f*/
                        *(_QWORD *)&this->statistics.perSecTxBwData.txBwInfluencers.bwCappedDueToMaxPacketsInFlightCount = 0; /*0x1410fc976*/
                        *(_QWORD *)&this->perSecTxBwCounters_deprecated.availableCapacity = 0; /*0x1410fc97d*/
                        *(_QWORD *)&this->perSecTxBwCounters_deprecated.reliablePacketBytes = 0; /*0x1410fc984*/
                        *(_QWORD *)&this->perSecTxBwCounters_deprecated.reliablePacketBytesRe = 0; /*0x1410fc98b*/
                        *(_QWORD *)&this->perSecTxBwCounters_deprecated.unreliablePacketBytes = 0; /*0x1410fc992*/
                        *(_QWORD *)&this->influxTxBwCounters_deprecated.availableCapacity = 0; /*0x1410fc999*/
                        *(_QWORD *)&this->influxTxBwCounters_deprecated.reliablePacketBytes = 0; /*0x1410fc9a0*/
                        *(_QWORD *)&this->influxTxBwCounters_deprecated.reliablePacketBytesRe = 0; /*0x1410fc9a7*/
                        *(_QWORD *)&this->influxTxBwCounters_deprecated.unreliablePacketBytes = 0; /*0x1410fc9ae*/
                        *(_QWORD *)&this->perSecTxBwData.availableCapacity = 0; /*0x1410fc9b5*/
                        *(_QWORD *)&this->perSecTxBwData.allBytes = 0; /*0x1410fc9bc*/
                        *(_QWORD *)&this->perSecTxBwData.reliablePackets = 0; /*0x1410fc9c3*/
                        *(_QWORD *)&this->perSecTxBwData.reliablePacketsRe = 0; /*0x1410fc9ca*/
                        *(_QWORD *)&this->perSecTxBwData.unreliablePackets = 0; /*0x1410fc9d1*/
                        *(_QWORD *)&this->perSecTxBwData.txBwInfluencers.bwLimitedByAppCount = 0; /*0x1410fc9d8*/
                        *(_QWORD *)&this->perSecTxBwData.txBwInfluencers.nonZeroTargetSpeedStartTimeCount = 0; /*0x1410fc9df*/
                        *(_QWORD *)&this->perSecTxBwData.txBwInfluencers.bytesGivenByTargetSpeed = 0; /*0x1410fc9e6*/
                        *(_QWORD *)&this->perSecTxBwData.txBwInfluencers.bwCappedDueTo2xTargetSpeedCount = 0; /*0x1410fc9ed*/
                        *(_QWORD *)&this->perSecTxBwData.txBwInfluencers.bwCappedDueToMaxPacketsInFlightCount = 0; /*0x1410fc9f4*/
                        *(_QWORD *)&this->influxTxBwData.availableCapacity = 0; /*0x1410fc9fb*/
                        *(_QWORD *)&this->influxTxBwData.allBytes = 0; /*0x1410fca02*/
                        *(_QWORD *)&this->influxTxBwData.reliablePackets = 0; /*0x1410fca09*/
                        *(_QWORD *)&this->influxTxBwData.reliablePacketsRe = 0; /*0x1410fca10*/
                        *(_QWORD *)&this->influxTxBwData.unreliablePackets = 0; /*0x1410fca17*/
                        *(_QWORD *)&this->influxTxBwData.txBwInfluencers.bwLimitedByAppCount = 0; /*0x1410fca1e*/
                        *(_QWORD *)&this->influxTxBwData.txBwInfluencers.nonZeroTargetSpeedStartTimeCount = 0; /*0x1410fca25*/
                        *(_QWORD *)&this->influxTxBwData.txBwInfluencers.bytesGivenByTargetSpeed = 0; /*0x1410fca2c*/
                        *(_QWORD *)&this->influxTxBwData.txBwInfluencers.bwCappedDueTo2xTargetSpeedCount = 0; /*0x1410fca33*/
                        *(_QWORD *)&this->influxTxBwData.txBwInfluencers.bwCappedDueToMaxPacketsInFlightCount = 0; /*0x1410fca3a*/
                        *(_QWORD *)&this->joinRxStats.totalRxBytes = 0; /*0x1410fca41*/
                        *(_QWORD *)&this->joinRxStats.totalRxIgnoredBytes = 0; /*0x1410fca48*/
                        *(_QWORD *)&this->raknetJoinRxStats.bytes = 0; /*0x1410fca4f*/
                        *(_QWORD *)&this->raknetJoinRxStats.reBytes = 0; /*0x1410fca56*/
                        *(_QWORD *)&this->raknetJoinRxStats.ignoredBytes = 0; /*0x1410fca5d*/
                        *(_QWORD *)&this->raknetJoinRxStats.timeFirstJoinPacketReceivedMs = 0; /*0x1410fca64*/
                        this->raknetJoinRxStats.timeLastNonReTxJoinPacketReceivedMs = 0; /*0x1410fca6b*/
                        this->highWaterMarkFortotalAvailableCapacityKBps = 0.0; /*0x1410fca72*/
                        this->highWaterMarkForBwFromTargetSpeedKBps = 0.0; /*0x1410fca79*/
                        `eh vector constructor iterator'( /*0x1410fcaa2*/
                          ptr: this->orderingHeaps,
                          size: 0x18u,
                          count: 0x20u,
                          constructor: (void (__fastcall *)(void *))DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::Heap<unsigned __int64,RakNet::InternalPacket *,0>,
                          destructor: (void (__fastcall *)(void *))DataStructures::List<bool>::~List<bool>);
                        __wind /*0xf1c0000000000280*/
                        {
                          __wind /*0xf1c0000000000288*/
                          {
                            __wind /*0xf1c0000000000290*/
                            {
                              __wind /*0xf1c0000000000298*/
                              {
                                __wind /*0xf1c00000000002a0*/
                                {
                                  __wind /*0xf1c00000000002a8*/
                                  {
                                    __wind /*0xf1c00000000002b0*/
                                    {
                                      __wind /*0xf1c00000000002b8*/
                                      {
                                        __wind /*0xf1c00000000002c0*/
                                        {
                                          __wind /*0xf1c00000000002c8*/
                                          {
                                            *(_QWORD *)&this->hasReceivedPacketQueue.tail = 0; /*0x1410fcaa8*/
                                            this->hasReceivedPacketQueue.array = nullptr; /*0x1410fcaaf*/
                                            this->hasReceivedPacketQueue.head = 0; /*0x1410fcab6*/
                                            *(_QWORD *)&this->packetsToSendThisUpdate.list_size = 0; /*0x1410fcabd*/
                                            this->packetsToSendThisUpdate.listArray = nullptr; /*0x1410fcac4*/
                                            *(_QWORD *)&this->packetsToDeallocThisUpdate.list_size = 0; /*0x1410fcacb*/
                                            this->packetsToDeallocThisUpdate.listArray = nullptr; /*0x1410fcad2*/
                                            *(_QWORD *)&this->packetsToSendThisUpdateDatagramBoundaries.list_size = 0; /*0x1410fcad9*/
                                            this->packetsToSendThisUpdateDatagramBoundaries.listArray = nullptr; /*0x1410fcae0*/
                                            *(_QWORD *)&this->datagramSizesInBytes.list_size = 0; /*0x1410fcae7*/
                                            this->datagramSizesInBytes.listArray = nullptr; /*0x1410fcaee*/
                                            *(_QWORD *)&this->incomingAcks.ranges.orderedList.list_size = 0; /*0x1410fcaf5*/
                                            this->incomingAcks.ranges.orderedList.listArray = nullptr; /*0x1410fcafc*/
                                            *(_QWORD *)&this->acknowlegements.ranges.orderedList.list_size = 0; /*0x1410fcb03*/
                                            this->acknowlegements.ranges.orderedList.listArray = nullptr; /*0x1410fcb0a*/
                                            *(_QWORD *)&this->NAKs.ranges.orderedList.list_size = 0; /*0x1410fcb11*/
                                            this->NAKs.ranges.orderedList.listArray = nullptr; /*0x1410fcb18*/
                                            *(_QWORD *)&this->refCountedDataPool.availablePagesSize = 0; /*0x1410fcb1f*/
                                            this->refCountedDataPool.memoryPoolPageSize = 0x4000; /*0x1410fcb26*/
                                            `eh vector constructor iterator'( /*0x1410fcb53*/
                                              ptr: this->bpsMetrics,
                                              size: 0x88u,
                                              count: 7u,
                                              constructor: (void (__fastcall *)(void *))RakNet::BPSTracker::BPSTracker,
                                              destructor: (void (__fastcall *)(void *))RakNet::BPSTracker::~BPSTracker);
                                            __wind /*0xf1c00000000000f8*/
                                            {
                                              __wind /*0xf1c0000000000100*/
                                              {
                                                this->paddedPacketsPercentage.lerp = 0.05; /*0x1410fcb63*/
                                                this->paddedPacketsPercentage.lastSampleValue = 0.0; /*0x1410fcb6a*/
                                                this->paddedPacketsPercentage.averageValue = 0.0; /*0x1410fcb71*/
                                                this->paddedPacketsPercentage.averageVariance = 0.0; /*0x1410fcb78*/
                                                this->paddedPacketsPercentage.firstTime = true; /*0x1410fcb7f*/
                                                this->commonCapabilities = 0; /*0x1410fcb86*/
                                                this->avoidedPacketSizes._Mypair._Myval2._Myfirst = nullptr; /*0x1410fcb8d*/
                                                this->avoidedPacketSizes._Mypair._Myval2._Mylast = nullptr; /*0x1410fcb94*/
                                                this->avoidedPacketSizes._Mypair._Myval2._Myend = nullptr; /*0x1410fcb9b*/
                                                this->incompleteDatagramBytes = 0; /*0x1410fcba2*/
                                                this->incompleteDatagramByteCapExceeded = false; /*0x1410fcba9*/
                                                if ( DFFlag::RakNetUseSlidingWindow4.value ) /*0x1410fcbb7*/
                                                {
                                                  v4 = (RakNet::CCRakNetSlidingWindow2 *)operator new(size: 0x1D8u); /*0x1410fcbbe*/
                                                  __wind /*0xf1c00000000000ec*/
                                                  {
                                                    _Val = (std::map<RakNet::uint24_t,RakNet::InternalPacket *> *)v4; /*0x1410fcbc3*/
                                                    if ( v4 != nullptr ) /*0x1410fcbcb*/
                                                      v5 = (RakNet::CCRakNetSlidingWindow *)RakNet::CCRakNetSlidingWindow2::CCRakNetSlidingWindow2(this: v4); /*0x1410fcbd0*/
                                                    else
                                                      v5 = nullptr; /*0x1410fcbd7*/
                                                  }
                                                  __unwind
                                                  {
                                                    operator delete(ptr: _Val); /*0x1431eef82*/
                                                  }
                                                }
                                                else
                                                {
                                                  v6 = (RakNet::CCRakNetSlidingWindow *)operator new(size: 0x48u); /*0x1410fcbe1*/
                                                  _Val = (std::map<RakNet::uint24_t,RakNet::InternalPacket *> *)v6; /*0x1410fcbe6*/
                                                  if ( v6 != nullptr ) /*0x1410fcbee*/
                                                  {
                                                    __wind /*0xf1c00000000000e0*/
                                                    {
                                                      v5 = RakNet::CCRakNetSlidingWindow::CCRakNetSlidingWindow(this: v6); /*0x1410fcbf3*/
                                                    }
                                                    __unwind
                                                    {
                                                      operator delete(ptr: _Val); /*0x1431649e2*/
                                                    }
                                                  }
                                                  else
                                                  {
                                                    v5 = nullptr; /*0x1410fcbfa*/
                                                  }
                                                }
                                                this->congestionManager = v5; /*0x1410fcbfd*/
                                                Mylast = this->resendBuffer._Mypair._Myval2._Mylast; /*0x1410fcc12*/
                                                Myfirst = this->resendBuffer._Mypair._Myval2._Myfirst; /*0x1410fcc16*/
                                                v9 = Mylast - Myfirst; /*0x1410fcc1f*/
                                                if ( FInt::RakNetResendBufferArrayLength < v9 ) /*0x1410fcc26*/
                                                {
                                                  v10 = &Myfirst[FInt::RakNetResendBufferArrayLength]; /*0x1410fcc28*/
LABEL_15:
                                                  this->resendBuffer._Mypair._Myval2._Mylast = v10; /*0x1410fcc6e*/
                                                  goto LABEL_16; /*0x1410fcc6e*/
                                                }
                                                if ( FInt::RakNetResendBufferArrayLength > v9 ) /*0x1410fcc2e*/
                                                {
                                                  if ( FInt::RakNetResendBufferArrayLength <= (unsigned __int64)(this->resendBuffer._Mypair._Myval2._Myend - Myfirst) ) /*0x1410fcc3e*/
                                                  {
                                                    v11 = FInt::RakNetResendBufferArrayLength - v9; /*0x1410fcc55*/
                                                    memset_0( /*0x1410fcc65*/
                                                      a1: this->resendBuffer._Mypair._Myval2._Mylast,
                                                      Val: 0,
                                                      Size: v11 * 8);
                                                    v10 = &Mylast[v11]; /*0x1410fcc6a*/
                                                    goto LABEL_15; /*0x1410fcc6a*/
                                                  }
                                                  std::vector<Luau::TypePackVar const *>::_Resize_reallocate<std::_Value_init_tag>( /*0x1410fcc4b*/
                                                    this: (std::vector<Luau::TypeVar const *> *)&this->resendBuffer,
                                                    _Newsize: FInt::RakNetResendBufferArrayLength,
                                                    (const std::_Value_init_tag *)&_Val);
                                                }
LABEL_16:
                                                this->timeoutTime = 10000; /*0x1410fcc72*/
                                                this->maxRxPayloadSize = &DFInt::MaxDataPayloadSize; /*0x1410fcc83*/
                                                *(_QWORD *)&this->minExtraPing = 0; /*0x1410fcc8a*/
                                                this->packetloss = 0.0; /*0x1410fcc91*/
                                                RakNet::ReliabilityLayer::InitializeVariables(this); /*0x1410fcc9b*/
                                                this->datagramHistoryMessagePool.memoryPoolPageSize = 2048; /*0x1410fcca0*/
                                                this->internalPacketPool.memoryPoolPageSize = 2112; /*0x1410fccaa*/
                                                this->refCountedDataPool.memoryPoolPageSize = 512; /*0x1410fccb4*/
                                                *(_QWORD *)&this->timeInMsSinceLastTxByteCounterUpdates = 0; /*0x1410fccbe*/
                                              }
                                              __unwind
                                              {
                                                std::vector<std::pair<unsigned short,unsigned short>>::~vector<std::pair<unsigned short,unsigned short>>(this: (std::vector<enum VkPresentModeKHR> *)&this->avoidedPacketSizes); /*0x1431eef5e*/
                                              }
                                            }
                                            __unwind
                                            {
                                              `eh vector destructor iterator'( /*0x1431eef36*/
                                                ptr: this->bpsMetrics,
                                                size: 0x88u,
                                                count: 7u,
                                                destructor: (void (__fastcall *)(void *))RakNet::BPSTracker::~BPSTracker);
                                            }
                                          }
                                          __unwind
                                          {
                                            DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>::~MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>(this: (DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode> *)&this->refCountedDataPool); /*0x1431eeefe*/
                                          }
                                        }
                                        __unwind
                                        {
                                          DataStructures::RangeList<RakNet::uint24_t>::~RangeList<RakNet::uint24_t>(this: &this->NAKs); /*0x1431eeede*/
                                        }
                                      }
                                      __unwind
                                      {
                                        DataStructures::RangeList<RakNet::uint24_t>::~RangeList<RakNet::uint24_t>(this: &this->acknowlegements); /*0x1431eeebe*/
                                      }
                                    }
                                    __unwind
                                    {
                                      DataStructures::RangeList<RakNet::uint24_t>::~RangeList<RakNet::uint24_t>(this: &this->incomingAcks); /*0x1431eee9e*/
                                    }
                                  }
                                  __unwind
                                  {
                                    DataStructures::List<bool>::~List<bool>(this: (DataStructures::List<bool> *)&this->datagramSizesInBytes); /*0x1431eee7e*/
                                  }
                                }
                                __unwind
                                {
                                  DataStructures::List<bool>::~List<bool>(this: (DataStructures::List<bool> *)&this->packetsToSendThisUpdateDatagramBoundaries); /*0x1431eee5e*/
                                }
                              }
                              __unwind
                              {
                                DataStructures::List<bool>::~List<bool>(this: &this->packetsToDeallocThisUpdate); /*0x1431eee3e*/
                              }
                            }
                            __unwind
                            {
                              DataStructures::List<bool>::~List<bool>(this: (DataStructures::List<bool> *)&this->packetsToSendThisUpdate); /*0x1431eee1e*/
                            }
                          }
                          __unwind
                          {
                            DataStructures::Queue<RakNet::RakPeer::SocketQueryOutput *>::~Queue<RakNet::RakPeer::SocketQueryOutput *>(this: &this->hasReceivedPacketQueue); /*0x1431eedfe*/
                          }
                        }
                        __unwind
                        {
                          `eh vector destructor iterator'( /*0x1431eedd6*/
                            ptr: this->orderingHeaps,
                            size: 0x18u,
                            count: 0x20u,
                            destructor: (void (__fastcall *)(void *))DataStructures::List<bool>::~List<bool>);
                        }
                      }
                      __unwind
                      {
                        DataStructures::OrderedList<unsigned short,RakNet::SplitPacketChannel *,&int RakNet::SplitPacketChannelComp(unsigned short const &,RakNet::SplitPacketChannel * const &)>::~OrderedList<unsigned short,RakNet::SplitPacketChannel *,&int RakNet::SplitPacketChannelComp(unsigned short const &,RakNet::SplitPacketChannel * const &)>(this: &this->splitPacketChannelList); /*0x1431eed9e*/
                      }
                    }
                    __unwind
                    {
                      DataStructures::List<bool>::~List<bool>(this: (DataStructures::List<bool> *)&this->outgoingPacketBuffer); /*0x1431eed7e*/
                    }
                  }
                  __unwind
                  {
                    std::map<__int64,int>::~map<__int64,int>(this: (std::map<RBX::Reflection::PropertyDescriptor const *,SettingsDialog::PropertyItem *> *)&this->resendBuffer2); /*0x1431eed5e*/
                  }
                }
                __unwind
                {
                  std::vector<Luau::AstExpr *>::~vector<Luau::AstExpr *>(this: (std::vector<RBX::Graphics::FramebufferVulkan *> *)&this->resendBuffer); /*0x1431eed3e*/
                }
              }
              __unwind
              {
                DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>::~MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>(this: (DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode> *)&this->internalPacketPool); /*0x1431eed1e*/
              }
            }
            __unwind
            {
              DataStructures::List<bool>::~List<bool>(this: (DataStructures::List<bool> *)&this->unreliableWithAckReceiptHistory); /*0x1431eecfe*/
            }
          }
          __unwind
          {
            DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>::~MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>(this: &this->datagramHistoryMessagePool); /*0x1431eecde*/
          }
        }
        __unwind
        {
          DataStructures::Queue<RakNet::RakPeer::SocketQueryOutput *>::~Queue<RakNet::RakPeer::SocketQueryOutput *>(this: (DataStructures::Queue<bool> *)&this->datagramHistory); /*0x1431eecbe*/
        }
      }
      __unwind
      {
        DataStructures::Queue<RakNet::RakPeer::SocketQueryOutput *>::~Queue<RakNet::RakPeer::SocketQueryOutput *>(this: (DataStructures::Queue<bool> *)&this->outputQueue); /*0x1431eecab*/
      }
    }
    __unwind
    {
      std::_Ref_count_obj2<RBX::PathWaypoint::WayPointData>::_Destroy(this: (webrtc::AudioReceiveStream::Stats *)&this->tLibTestClientStats); /*0x1431eec9b*/
    }
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>((std::shared_ptr<RBX::File> *)this); /*0xf1c0000000000218*/
  }
  return this; /*0x1410fccc8*/
}

// Address: 0x1410fce20 | Name: ??1ReliabilityLayer@RakNet@@QEAA@XZ
void __fastcall RakNet::ReliabilityLayer::~ReliabilityLayer(RakNet::ReliabilityLayer *this)
{
  RakNet::CCRakNetBase *congestionManager; // rcx
  int *Myfirst; // rcx
  __int64 v4; // rcx
  std::_Tree_node<std::pair<RakNet::uint24_t const ,RakNet::InternalPacket *>,void *> *Myhead; // rcx
  std::_Tree_node<std::pair<RakNet::uint24_t const ,RakNet::InternalPacket *>,void *> *Parent; // rdi
  std::_Tree_node<std::pair<RakNet::uint24_t const ,RakNet::InternalPacket *>,void *> *v7; // rcx
  RakNet::InternalPacket **v8; // rcx
  std::_Ref_count_base *Rep; // rbx
  __int64 v10; // [rsp+0h] [rbp-28h] BYREF

  RakNet::ReliabilityLayer::FreeThreadSafeMemory(this); /*0x1410fce37*/
  congestionManager = this->congestionManager; /*0x1410fce3c*/
  if ( congestionManager != nullptr ) /*0x1410fce46*/
    ((void (__fastcall *)(RakNet::CCRakNetBase *, __int64))congestionManager->dtr_CCRakNetBase)( /*0x1410fce50*/
      a1: congestionManager,
      a2: 1);
  Myfirst = this->avoidedPacketSizes._Mypair._Myval2._Myfirst; /*0x1410fce52*/
  if ( Myfirst != nullptr ) /*0x1410fce5e*/
  {
    if ( (unsigned __int64)(4 * (this->avoidedPacketSizes._Mypair._Myval2._Myend - Myfirst)) >= 0x1000 ) /*0x1410fce7d*/
    {
      if ( (unsigned __int64)Myfirst - *((_QWORD *)Myfirst - 1) - 8 > 0x1F ) /*0x1410fce92*/
        goto LABEL_41; /*0x1410fce92*/
      Myfirst = *((int **)Myfirst - 1); /*0x1410fce98*/
    }
    operator delete(ptr: Myfirst); /*0x1410fce9b*/
    this->avoidedPacketSizes._Mypair._Myval2._Myfirst = nullptr; /*0x1410fcea0*/
    this->avoidedPacketSizes._Mypair._Myval2._Mylast = nullptr; /*0x1410fcea7*/
    this->avoidedPacketSizes._Mypair._Myval2._Myend = nullptr; /*0x1410fceae*/
  }
  `eh vector destructor iterator'( /*0x1410fcece*/
    ptr: this->bpsMetrics,
    size: 0x88u,
    count: 7u,
    destructor: (void (__fastcall *)(void *))RakNet::BPSTracker::~BPSTracker);
  __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000050*/
  DataStructures::MemoryPool<RakNet::RemoteSystemIndex>::Clear( /*0x1410fcee8*/
    this: (DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode> *)&this->refCountedDataPool,
    file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\DS_MemoryPool.h",
    line: 0x51u);
  if ( __eh34_unwind(0) ) /*0xf1c0000000000044*/
unwind_state_0:
    __std_terminate(a1: v4, a2: &v10); /*0xf1c0000000000018*/
  __eh34_exit_wind_state(0, -1); /*0xf1c0000000000048*/
  DataStructures::RangeList<RakNet::uint24_t>::~RangeList<RakNet::uint24_t>(this: &this->NAKs); /*0x1410fcef5*/
  DataStructures::RangeList<RakNet::uint24_t>::~RangeList<RakNet::uint24_t>(this: &this->acknowlegements); /*0x1410fcf01*/
  DataStructures::RangeList<RakNet::uint24_t>::~RangeList<RakNet::uint24_t>(this: &this->incomingAcks); /*0x1410fcf0d*/
  if ( this->datagramSizesInBytes.allocation_size != 0 ) /*0x1410fcf19*/
    operator delete(ptr: this->datagramSizesInBytes.listArray); /*0x1410fcf22*/
  if ( this->packetsToSendThisUpdateDatagramBoundaries.allocation_size != 0 ) /*0x1410fcf2e*/
    operator delete(ptr: this->packetsToSendThisUpdateDatagramBoundaries.listArray); /*0x1410fcf37*/
  if ( this->packetsToDeallocThisUpdate.allocation_size != 0 ) /*0x1410fcf43*/
    operator delete(ptr: this->packetsToDeallocThisUpdate.listArray); /*0x1410fcf4c*/
  if ( this->packetsToSendThisUpdate.allocation_size != 0 ) /*0x1410fcf58*/
    operator delete(ptr: this->packetsToSendThisUpdate.listArray); /*0x1410fcf61*/
  if ( this->hasReceivedPacketQueue.allocation_size != 0 ) /*0x1410fcf6d*/
    operator delete(ptr: this->hasReceivedPacketQueue.array); /*0x1410fcf76*/
  `eh vector destructor iterator'( /*0x1410fcf92*/
    ptr: this->orderingHeaps,
    size: 0x18u,
    count: 0x20u,
    destructor: (void (__fastcall *)(void *))DataStructures::List<bool>::~List<bool>);
  if ( this->splitPacketChannelList.orderedList.allocation_size != 0 ) /*0x1410fcf9e*/
  {
    operator delete(ptr: this->splitPacketChannelList.orderedList.listArray); /*0x1410fcfa7*/
    *(_QWORD *)&this->splitPacketChannelList.orderedList.list_size = 0; /*0x1410fcfac*/
    this->splitPacketChannelList.orderedList.listArray = nullptr; /*0x1410fcfb3*/
  }
  if ( this->outgoingPacketBuffer.heap.allocation_size != 0 ) /*0x1410fcfc1*/
    operator delete(ptr: this->outgoingPacketBuffer.heap.listArray); /*0x1410fcfca*/
  Myhead = this->resendBuffer2._Mypair._Myval2._Myval2._Myhead; /*0x1410fcfcf*/
  Parent = Myhead->_Parent; /*0x1410fcfd6*/
  if ( Parent->_Isnil == 0 ) /*0x1410fcfde*/
  {
    do /*0x1410fd00b*/
    {
      std::_Tree_val<std::_Tree_simple_types<std::pair<webrtc::Resource const * const,int>>>::_Erase_tree<std::allocator<std::_Tree_node<std::pair<webrtc::Resource const * const,int>,void *>>>( /*0x1410fcff2*/
        this: (std::_Tree_val<std::_Tree_simple_types<std::pair<RBX::Reflection::PropertyDescriptor const * const,SettingsDialog::PropertyItem *> > > *)&this->resendBuffer2,
        _Al: (std::allocator<std::_Tree_node<std::pair<RBX::Reflection::PropertyDescriptor const * const,SettingsDialog::PropertyItem *>,void *> > *)&this->resendBuffer2,
        _Rootnode: (std::_Tree_node<std::pair<RBX::Reflection::PropertyDescriptor const * const,SettingsDialog::PropertyItem *>,void *> *)Parent->_Right);
      v7 = Parent; /*0x1410fcff7*/
      Parent = Parent->_Left; /*0x1410fcffa*/
      operator delete(ptr: v7); /*0x1410fd002*/
    }
    while ( Parent->_Isnil == 0 ); /*0x1410fd00b*/
    Myhead = this->resendBuffer2._Mypair._Myval2._Myval2._Myhead; /*0x1410fd00d*/
  }
  operator delete(ptr: Myhead); /*0x1410fd019*/
  v8 = this->resendBuffer._Mypair._Myval2._Myfirst; /*0x1410fd01e*/
  if ( v8 != nullptr ) /*0x1410fd028*/
  {
    if ( (unsigned __int64)(8 * (this->resendBuffer._Mypair._Myval2._Myend - v8)) < 0x1000 ) /*0x1410fd047*/
    {
LABEL_30:
      operator delete(ptr: v8); /*0x1410fd065*/
      this->resendBuffer._Mypair._Myval2._Myfirst = nullptr; /*0x1410fd06a*/
      this->resendBuffer._Mypair._Myval2._Mylast = nullptr; /*0x1410fd071*/
      this->resendBuffer._Mypair._Myval2._Myend = nullptr; /*0x1410fd078*/
      goto LABEL_48; /*0xf1c0000000000064*/
    }
    if ( (unsigned __int64)((char *)v8 - (char *)*(v8 - 1) - 8) <= 0x1F ) /*0x1410fd05c*/
    {
      v8 = (RakNet::InternalPacket **)*(v8 - 1); /*0x1410fd062*/
      goto LABEL_30; /*0x1410fd062*/
    }
LABEL_41:
    _invalid_parameter_noinfo_noreturn(); /*0x1410fd141*/
  }
LABEL_48:
  __eh34_enter_wind_state(-1, 0); /*0xf1c000000000003c*/
  DataStructures::MemoryPool<RakNet::RemoteSystemIndex>::Clear( /*0x1410fd093*/
    this: (DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode> *)&this->internalPacketPool,
    file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\DS_MemoryPool.h",
    line: 0x51u);
  if ( __eh34_unwind(0) ) /*0xf1c0000000000030*/
    goto unwind_state_0; /*0xf1c0000000000030*/
  __eh34_exit_wind_state(0, -1); /*0xf1c0000000000034*/
  if ( this->unreliableWithAckReceiptHistory.allocation_size != 0 ) /*0x1410fd0a0*/
    operator delete(ptr: this->unreliableWithAckReceiptHistory.listArray); /*0x1410fd0a9*/
  __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000028*/
  DataStructures::MemoryPool<RakNet::RemoteSystemIndex>::Clear( /*0x1410fd0c3*/
    this: &this->datagramHistoryMessagePool,
    file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\DS_MemoryPool.h",
    line: 0x51u);
  if ( this->datagramHistory.allocation_size != 0 ) /*0x1410fd0d0*/
    operator delete(ptr: this->datagramHistory.array); /*0x1410fd0d9*/
  if ( this->outputQueue.allocation_size != 0 ) /*0x1410fd0e2*/
    operator delete(ptr: this->outputQueue.array); /*0x1410fd0e8*/
  std::_Ref_count_obj2<RBX::PathWaypoint::WayPointData>::_Destroy(this: (webrtc::AudioReceiveStream::Stats *)&this->tLibTestClientStats); /*0x1410fd0f1*/
  Rep = this->rbxSessionCrypto._Rep; /*0x1410fd0f6*/
  if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410fd10e*/
  {
    Rep->_Destroy(this: Rep); /*0x1410fd116*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410fd120*/
      Rep->_Delete_this(this: Rep); /*0x1410fd128*/
  }
  if ( __eh34_unwind(0) ) /*0xf1c0000000000014*/
    goto unwind_state_0; /*0xf1c0000000000014*/
  __eh34_exit_wind_state(0, -1); /*0xf1c0000000000020*/
}

// Address: 0x1410fd9a0 | Name: ?AckTimeout@ReliabilityLayer@RakNet@@QEAA_N_K@Z
bool __fastcall RakNet::ReliabilityLayer::AckTimeout(RakNet::ReliabilityLayer *this, unsigned __int64 curTime)
{
  return this->timeLastDatagramArrived - curTime > 0x2710 && curTime - this->timeLastDatagramArrived > this->timeoutTime; /*0x1410fd9c5*/
}

// Address: 0x1410fd9d0 | Name: ?AllocInternalPacketData@ReliabilityLayer@RakNet@@AEAAXPEAUInternalPacket@2@PEAPEAUInternalPacketRefCountedData@2@PEAE2@Z
void __fastcall RakNet::ReliabilityLayer::AllocInternalPacketData(
        RakNet::ReliabilityLayer *this,
        RakNet::InternalPacket *internalPacket,
        RakNet::InternalPacketRefCountedData **refCounter,
        unsigned __int8 *externallyAllocatedPtr,
        unsigned __int8 *ourOffset)
{
  DataStructures::MemoryPool<RakNet::InternalPacketRefCountedData>::Page *v9; // r9
  __int64 v10; // rcx
  DataStructures::MemoryPool<RakNet::InternalPacketRefCountedData>::MemoryWithPage **v11; // rax
  RakNet::InternalPacketRefCountedData *p_userMemory; // r8
  int unavailablePagesSize; // ecx
  DataStructures::MemoryPool<RakNet::InternalPacketRefCountedData>::Page *v14; // rax
  DataStructures::MemoryPool<RakNet::InternalPacketRefCountedData>::Page *v15; // rbx
  unsigned __int64 memoryPoolPageSize; // rcx
  unsigned __int64 v17; // r15
  DataStructures::MemoryPool<RakNet::InternalPacketRefCountedData>::MemoryWithPage *v18; // rax
  DataStructures::MemoryPool<RakNet::InternalPacketRefCountedData>::MemoryWithPage **v19; // rax
  DataStructures::MemoryPool<RakNet::InternalPacketRefCountedData>::MemoryWithPage *block; // rcx
  __int64 v21; // r8
  DataStructures::MemoryPool<RakNet::InternalPacketRefCountedData>::Page *availablePages; // rdx
  __int64 availableStackSize; // rcx
  DataStructures::MemoryPool<RakNet::InternalPacketRefCountedData>::MemoryWithPage **availableStack; // r8

  internalPacket->data = ourOffset; /*0x1410fd9e6*/
  internalPacket->allocationScheme = REF_COUNTED; /*0x1410fd9ed*/
  if ( *refCounter == nullptr ) /*0x1410fda00*/
  {
    if ( this->refCountedDataPool.availablePagesSize <= 0 ) /*0x1410fda0c*/
    {
      v14 = (DataStructures::MemoryPool<RakNet::InternalPacketRefCountedData>::Page *)RBX::Memory::allocate(size: 0x28u); /*0x1410fdaca*/
      this->refCountedDataPool.availablePages = v14; /*0x1410fdacf*/
      v15 = v14; /*0x1410fdad6*/
      if ( v14 != nullptr ) /*0x1410fdadc*/
      {
        memoryPoolPageSize = this->refCountedDataPool.memoryPoolPageSize; /*0x1410fdae3*/
        v17 = memoryPoolPageSize / 0x18; /*0x1410fdb04*/
        this->refCountedDataPool.availablePagesSize = 1; /*0x1410fdb08*/
        v18 = (DataStructures::MemoryPool<RakNet::InternalPacketRefCountedData>::MemoryWithPage *)RBX::Memory::allocate(size: memoryPoolPageSize); /*0x1410fdb12*/
        v15->block = v18; /*0x1410fdb17*/
        if ( v18 != nullptr ) /*0x1410fdb1e*/
        {
          v19 = (DataStructures::MemoryPool<RakNet::InternalPacketRefCountedData>::MemoryWithPage **)RBX::Memory::allocate(size: 8LL * (int)v17); /*0x1410fdb2b*/
          block = v15->block; /*0x1410fdb30*/
          v15->availableStack = v19; /*0x1410fdb37*/
          if ( v19 != nullptr ) /*0x1410fdb3d*/
          {
            if ( (int)v17 > 0 ) /*0x1410fdb80*/
            {
              v21 = 0; /*0x1410fdb82*/
              do /*0x1410fdba5*/
              {
                block->parentPage = v15; /*0x1410fdb93*/
                v19[v21++] = block++; /*0x1410fdb97*/
              }
              while ( v21 < (int)v17 ); /*0x1410fdba5*/
            }
            v15->availableStackSize = v17; /*0x1410fdba7*/
            v15->next = this->refCountedDataPool.availablePages; /*0x1410fdbb2*/
            v15->prev = v15; /*0x1410fdbb6*/
            availablePages = this->refCountedDataPool.availablePages; /*0x1410fdbba*/
            availableStackSize = availablePages->availableStackSize; /*0x1410fdbc1*/
            availableStack = availablePages->availableStack; /*0x1410fdbc5*/
            availablePages->availableStackSize = availableStackSize - 1; /*0x1410fdbcb*/
            p_userMemory = &availableStack[availableStackSize - 1]->userMemory; /*0x1410fdbce*/
            goto LABEL_13; /*0x1410fdbd3*/
          }
          operator delete(ptr: block); /*0x1410fdb3f*/
        }
        p_userMemory = nullptr; /*0x1410fdb44*/
      }
      else
      {
        p_userMemory = nullptr; /*0x1410fdade*/
      }
    }
    else
    {
      v9 = this->refCountedDataPool.availablePages; /*0x1410fda12*/
      v10 = v9->availableStackSize; /*0x1410fda1d*/
      v11 = v9->availableStack; /*0x1410fda23*/
      v9->availableStackSize = v10 - 1; /*0x1410fda26*/
      p_userMemory = &v11[v10 - 1]->userMemory; /*0x1410fda2a*/
      if ( (_DWORD)v10 == 1 ) /*0x1410fda31*/
      {
        --this->refCountedDataPool.availablePagesSize; /*0x1410fda37*/
        this->refCountedDataPool.availablePages = v9->next; /*0x1410fda41*/
        v9->next->prev = v9->prev; /*0x1410fda50*/
        v9->prev->next = v9->next; /*0x1410fda5c*/
        unavailablePagesSize = this->refCountedDataPool.unavailablePagesSize; /*0x1410fda60*/
        this->refCountedDataPool.unavailablePagesSize = unavailablePagesSize + 1; /*0x1410fda69*/
        if ( unavailablePagesSize != 0 ) /*0x1410fda71*/
        {
          v9->next = this->refCountedDataPool.unavailablePages; /*0x1410fda8e*/
          v9->prev = this->refCountedDataPool.unavailablePages->prev; /*0x1410fda9d*/
          this->refCountedDataPool.unavailablePages->prev->next = v9; /*0x1410fdaac*/
          this->refCountedDataPool.unavailablePages->prev = v9; /*0x1410fdab7*/
        }
        else
        {
          this->refCountedDataPool.unavailablePages = v9; /*0x1410fda73*/
          v9->next = v9; /*0x1410fda7a*/
          v9->prev = v9; /*0x1410fda7e*/
        }
      }
    }
LABEL_13:
    *refCounter = p_userMemory; /*0x1410fdb56*/
    p_userMemory->refCount = 1; /*0x1410fdb59*/
    (*refCounter)->sharedDataBlock = externallyAllocatedPtr; /*0x1410fdb64*/
    internalPacket->refCountedData = *refCounter; /*0x1410fdb6a*/
    return; /*0x1410fdb7c*/
  }
  ++(*refCounter)->refCount; /*0x1410fdbd8*/
  internalPacket->refCountedData = *refCounter; /*0x1410fdbe3*/
}

// Address: 0x1410fdc00 | Name: ?AllocateFromInternalPacketPool@ReliabilityLayer@RakNet@@AEAAPEAUInternalPacket@2@XZ
DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *__fastcall RakNet::ReliabilityLayer::AllocateFromInternalPacketPool(
        RakNet::ReliabilityLayer *this)
{
  DataStructures::MemoryPool<RakNet::InternalPacket>::Page *availablePages; // r10
  __int64 availableStackSize; // rdx
  DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage **availableStack; // rax
  DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *v5; // r9
  int unavailablePagesSize; // ecx
  DataStructures::MemoryPool<RakNet::InternalPacket>::Page *v7; // rax
  DataStructures::MemoryPool<RakNet::InternalPacket>::Page *v8; // rdi
  unsigned __int64 memoryPoolPageSize; // rcx
  unsigned __int64 v10; // rbp
  DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *v11; // rax
  DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage **v12; // rax
  DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *block; // rcx
  __int64 v15; // rdx
  DataStructures::MemoryPool<RakNet::InternalPacket>::Page *v16; // rdx
  __int64 v17; // rcx
  DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage **v18; // r8

  if ( this->internalPacketPool.availablePagesSize > 0 ) /*0x1410fdc18*/
  {
    availablePages = this->internalPacketPool.availablePages; /*0x1410fdc1e*/
    availableStackSize = availablePages->availableStackSize; /*0x1410fdc29*/
    availableStack = availablePages->availableStack; /*0x1410fdc30*/
    availablePages->availableStackSize = availableStackSize - 1; /*0x1410fdc33*/
    v5 = availableStack[availableStackSize - 1]; /*0x1410fdc37*/
    if ( (_DWORD)availableStackSize == 1 ) /*0x1410fdc3f*/
    {
      --this->internalPacketPool.availablePagesSize; /*0x1410fdc45*/
      this->internalPacketPool.availablePages = availablePages->next; /*0x1410fdc4f*/
      availablePages->next->prev = availablePages->prev; /*0x1410fdc5e*/
      availablePages->prev->next = availablePages->next; /*0x1410fdc6a*/
      unavailablePagesSize = this->internalPacketPool.unavailablePagesSize; /*0x1410fdc6e*/
      this->internalPacketPool.unavailablePagesSize = unavailablePagesSize + 1; /*0x1410fdc77*/
      if ( unavailablePagesSize != 0 ) /*0x1410fdc7f*/
      {
        availablePages->next = this->internalPacketPool.unavailablePages; /*0x1410fdc9c*/
        availablePages->prev = this->internalPacketPool.unavailablePages->prev; /*0x1410fdcab*/
        this->internalPacketPool.unavailablePages->prev->next = availablePages; /*0x1410fdcba*/
        this->internalPacketPool.unavailablePages->prev = availablePages; /*0x1410fdcc5*/
      }
      else
      {
        this->internalPacketPool.unavailablePages = availablePages; /*0x1410fdc81*/
        availablePages->next = availablePages; /*0x1410fdc88*/
        availablePages->prev = availablePages; /*0x1410fdc8c*/
      }
    }
    goto LABEL_12; /*0x1410fdc90*/
  }
  v7 = (DataStructures::MemoryPool<RakNet::InternalPacket>::Page *)RBX::Memory::allocate(size: 0x28u); /*0x1410fdcd8*/
  this->internalPacketPool.availablePages = v7; /*0x1410fdcdd*/
  v8 = v7; /*0x1410fdce4*/
  if ( v7 == nullptr ) /*0x1410fdcea*/
  {
    v5 = nullptr; /*0x1410fdcec*/
    goto LABEL_12; /*0x1410fdcef*/
  }
  memoryPoolPageSize = this->internalPacketPool.memoryPoolPageSize; /*0x1410fdcf1*/
  this->internalPacketPool.availablePagesSize = 1; /*0x1410fdd12*/
  v10 = memoryPoolPageSize / 0x110; /*0x1410fdd1c*/
  v11 = (DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *)RBX::Memory::allocate(size: memoryPoolPageSize); /*0x1410fdd20*/
  v8->block = v11; /*0x1410fdd25*/
  if ( v11 == nullptr ) /*0x1410fdd2c*/
  {
LABEL_11:
    v5 = nullptr; /*0x1410fdd52*/
    goto LABEL_12; /*0x1410fdd52*/
  }
  v12 = (DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage **)RBX::Memory::allocate(size: 8LL * (int)v10); /*0x1410fdd39*/
  block = v8->block; /*0x1410fdd3e*/
  v8->availableStack = v12; /*0x1410fdd45*/
  if ( v12 == nullptr ) /*0x1410fdd4b*/
  {
    operator delete(ptr: block); /*0x1410fdd4d*/
    goto LABEL_11; /*0x1410fdd4d*/
  }
  if ( (int)v10 > 0 ) /*0x1410fdd99*/
  {
    v15 = 0; /*0x1410fdd9b*/
    do /*0x1410fddbb*/
    {
      block->parentPage = v8; /*0x1410fdda3*/
      v12[v15++] = block++; /*0x1410fddaa*/
    }
    while ( v15 < (int)v10 ); /*0x1410fddbb*/
  }
  v8->availableStackSize = v10; /*0x1410fddbd*/
  v8->next = this->internalPacketPool.availablePages; /*0x1410fddc7*/
  v8->prev = v8; /*0x1410fddcb*/
  v16 = this->internalPacketPool.availablePages; /*0x1410fddcf*/
  v17 = v16->availableStackSize; /*0x1410fddd6*/
  v18 = v16->availableStack; /*0x1410fddda*/
  v16->availableStackSize = v17 - 1; /*0x1410fdde0*/
  v5 = v18[v17 - 1]; /*0x1410fdde3*/
LABEL_12:
  v5->userMemory.reliableMessageNumber.val = 0xFFFFFF; /*0x1410fdd64*/
  v5->userMemory.messageNumberAssigned = false; /*0x1410fdd73*/
  v5->userMemory.nextActionTime = 0; /*0x1410fdd77*/
  v5->userMemory.splitPacketCount = 0; /*0x1410fdd7b*/
  v5->userMemory.allocationScheme = 0; /*0x1410fdd7f*/
  v5->userMemory.data = nullptr; /*0x1410fdd83*/
  *(_WORD *)&v5->userMemory.timesSent = 0; /*0x1410fdd87*/
  v5->userMemory.isJoinData = false; /*0x1410fdd8c*/
  return v5; /*0x1410fdd90*/
}

// Address: 0x1410fddf0 | Name: ?AreAcksWaiting@ReliabilityLayer@RakNet@@QEAA_NXZ
bool __fastcall RakNet::ReliabilityLayer::AreAcksWaiting(RakNet::ReliabilityLayer *this)
{
  return this->acknowlegements.ranges.orderedList.list_size != 0; /*0x1410fddfa*/
}

// Address: 0x1410fde00 | Name: ?BuildPacketFromSplitPacketList@ReliabilityLayer@RakNet@@AEAAPEAUInternalPacket@2@G_KV?$shared_ptr@URakNetSocket@RakNet@@@std@@AEBUSystemAddress@2@AEAVBitStream@2@AEBV?$shared_ptr@VRupp@1Network@RBX@@@5@2@Z
RakNet::InternalPacket *__fastcall RakNet::ReliabilityLayer::BuildPacketFromSplitPacketList(
        RakNet::ReliabilityLayer *this,
        unsigned __int64 splitPacketId,
        unsigned __int64 time,
        std::shared_ptr<RBX::File> *socket,
        const RakNet::SystemAddress *systemAddress,
        RakNet::BitStream *updateBitStream,
        const std::shared_ptr<RBX::Network::Rupp::Rupp> *ruppHeader,
        const RakNet::SystemAddress *udmuxAddress)
{
  unsigned __int64 v9; // r15
  __int64 v10; // r9
  signed int list_size; // eax
  unsigned int v13; // ebx
  int v14; // r10d
  RakNet::SplitPacketChannel **listArray; // r11
  int v16; // ecx
  signed int v17; // eax
  RakNet::SplitPacketChannel *v18; // rbp
  std::_Ref_count_base *Rep; // rcx
  RakNet::InternalPacket *v20; // rbp
  unsigned int v21; // edx
  __int64 v22; // r8
  std::_Ref_count_base *v23; // rbx
  std::_Ref_count_base *v25; // rbx
  std::shared_ptr<RakNet::RakNetSocket> v26; // [rsp+40h] [rbp-38h] BYREF

  v9 = time; /*0x1410fde18*/
  v10 = (unsigned __int16)splitPacketId; /*0x1410fde1b*/
  list_size = this->splitPacketChannelList.orderedList.list_size; /*0x1410fde22*/
  v13 = 0; /*0x1410fde2d*/
  if ( list_size != 0 ) /*0x1410fde31*/
  {
    v14 = list_size - 1; /*0x1410fde33*/
    time = (unsigned int)(list_size / 2); /*0x1410fde3c*/
    listArray = this->splitPacketChannelList.orderedList.listArray; /*0x1410fde3f*/
    do /*0x1410fde53*/
    {
      splitPacketId = (unsigned __int64)listArray[(unsigned int)time]; /*0x1410fde53*/
      if ( (unsigned int)v10 >= *(_DWORD *)(splitPacketId + 56) ) /*0x1410fde5b*/
      {
        if ( (_DWORD)v10 == *(_DWORD *)(splitPacketId + 56) ) /*0x1410fde61*/
        {
          v13 = time; /*0x1410fde8e*/
          break; /*0x1410fde8e*/
        }
        v16 = 1; /*0x1410fde63*/
      }
      else
      {
        v16 = -1; /*0x1410fde5d*/
      }
      if ( v16 >= 0 ) /*0x1410fde6e*/
        v13 = time + 1; /*0x1410fde6e*/
      v17 = time - 1; /*0x1410fde71*/
      if ( v16 >= 0 ) /*0x1410fde75*/
        v17 = v14; /*0x1410fde75*/
      v14 = v17; /*0x1410fde79*/
      splitPacketId = (unsigned int)((int)(v17 - v13) >> 31); /*0x1410fde7e*/
      time = v13 + (int)(v17 - v13) / 2; /*0x1410fde83*/
    }
    while ( (int)v13 <= v17 ); /*0x1410fde53*/
  }
  v18 = this->splitPacketChannelList.orderedList.listArray[v13]; /*0x1410fde91*/
  if ( v18->newSplitList.uniqueFilled == v18->splitPacketCount ) /*0x1410fdea4*/
  {
    v26 = 0; /*0x1410fdead*/
    Rep = socket->_Rep; /*0x1410fdeb3*/
    if ( Rep != nullptr ) /*0x1410fdeba*/
    {
      _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x1410fdebc*/
      Rep = socket->_Rep; /*0x1410fdec0*/
    }
    v26._Ptr = (RakNet::RakNetSocket *)socket->_Ptr; /*0x1410fdec7*/
    v26._Rep = Rep; /*0x1410fdecc*/
    __wind /*0xf1c0000000000010*/
    {
      RakNet::ReliabilityLayer::SendACKs( /*0x1410fdf0b*/
        this,
        socket: &v26,
        systemAddress,
        time: v9,
        updateBitStream,
        ruppHeader,
        udmuxAddress);
      v20 = RakNet::ReliabilityLayer::BuildPacketFromSplitPacketList(this, splitPacketChannel: v18, time: v9); /*0x1410fdf1e*/
      v21 = this->splitPacketChannelList.orderedList.list_size; /*0x1410fdf21*/
      if ( v13 < v21 ) /*0x1410fdf29*/
      {
        if ( v13 < v21 - 1 ) /*0x1410fdf30*/
        {
          do /*0x1410fdf56*/
          {
            v22 = v13 + 1; /*0x1410fdf32*/
            this->splitPacketChannelList.orderedList.listArray[v13++] = this->splitPacketChannelList.orderedList.listArray[v22]; /*0x1410fdf43*/
            v21 = this->splitPacketChannelList.orderedList.list_size; /*0x1410fdf4a*/
          }
          while ( (unsigned int)v22 < v21 - 1 ); /*0x1410fdf56*/
        }
        this->splitPacketChannelList.orderedList.list_size = v21 - 1; /*0x1410fdf5b*/
      }
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: socket); /*0xf1c0000000000008*/
    }
    v23 = socket->_Rep; /*0x1410fdf61*/
    if ( v23 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v23->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410fdf74*/
    {
      v23->_Destroy(this: v23); /*0x1410fdf7c*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v23->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410fdf86*/
        v23->_Delete_this(this: v23); /*0x1410fdf8e*/
    }
    return v20; /*0x1410fdf91*/
  }
  else
  {
    v25 = socket->_Rep; /*0x1410fdf96*/
    if ( v25 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v25->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410fdfa9*/
    {
      ((void (__fastcall *)(std::_Ref_count_base *, unsigned __int64, unsigned __int64, __int64))v25->_Destroy)( /*0x1410fdfb1*/
        a1: v25,
        a2: splitPacketId,
        a3: time,
        a4: v10);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v25->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410fdfbb*/
        v25->_Delete_this(this: v25); /*0x1410fdfc3*/
    }
    return nullptr; /*0x1410fdfc6*/
  }
}

// Address: 0x1410fdfe0 | Name: ?BuildPacketFromSplitPacketList@ReliabilityLayer@RakNet@@AEAAPEAUInternalPacket@2@PEAUSplitPacketChannel@2@_K@Z
DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *__fastcall RakNet::ReliabilityLayer::BuildPacketFromSplitPacketList(
        RakNet::ReliabilityLayer *this,
        RakNet::SplitPacketChannel *splitPacketChannel,
        unsigned __int64 time)
{
  RakNet::InternalPacket **Myfirst; // rsi
  RakNet::InternalPacket *v7; // rsi
  DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *v8; // rdi
  __int64 v9; // rdx
  unsigned int dataBitLength; // eax
  RakNet::InternalPacket **v11; // r8
  unsigned __int64 v12; // rcx
  unsigned int v13; // r8d
  unsigned int v14; // r9d
  RakNet::InternalPacket **v15; // rcx
  int v16; // r15d
  unsigned int i; // esi
  RakNet::InternalPacket **v18; // rdx
  __int64 v19; // rdx
  unsigned int j; // esi
  RakNet::InternalPacket **v21; // rdx
  __int64 v22; // rcx
  RakNet::InternalPacket **v23; // rdx
  RakNet::InternalPacket **v24; // rcx
  const std::string *v26; // rax
  __int64 k; // rdi
  RakNet::InternalPacket **v28; // rdx
  __int64 v29; // rcx
  RakNet::InternalPacket **v30; // rdx
  std::string v31; // [rsp+20h] [rbp-88h] BYREF
  RBX::network_stream_exception pExceptionObject; // [rsp+40h] [rbp-68h] BYREF

  try /*0xf1c0000000000048*/
  {
    Myfirst = splitPacketChannel->newSplitList.internalList._Mypair._Myval2._Myfirst; /*0x1410fe00d*/
    if ( splitPacketChannel->newSplitList.internalList._Mypair._Myval2._Mylast - Myfirst == 0 ) /*0x1410fe01f*/
      std::vector<std::pair<std::string,dtl::eleminfo>>::_Xrange(a1: this, a2: splitPacketChannel); /*0x1410fe22e*/
    v7 = *Myfirst; /*0x1410fe025*/
    v8 = RakNet::ReliabilityLayer::AllocateFromInternalPacketPool(this); /*0x1410fe02d*/
    v8->userMemory.data = nullptr; /*0x1410fe033*/
    v8->userMemory.dataBitLength = 0; /*0x1410fe037*/
    v8->userMemory.creationTime = time; /*0x1410fe03b*/
    v8->userMemory.nextActionTime = 0; /*0x1410fe03f*/
    v8->userMemory.orderingIndex.val = v7->orderingIndex.val; /*0x1410fe046*/
    v8->userMemory.sequencingIndex.val = v7->sequencingIndex.val; /*0x1410fe04c*/
    v8->userMemory.orderingChannel = v7->orderingChannel; /*0x1410fe053*/
    v8->userMemory.reliableMessageNumber.val = v7->reliableMessageNumber.val; /*0x1410fe058*/
    v8->userMemory.priority = v7->priority; /*0x1410fe05d*/
    v8->userMemory.reliability = v7->reliability; /*0x1410fe063*/
    v9 = 0; /*0x1410fe066*/
    dataBitLength = 0; /*0x1410fe069*/
    while ( (unsigned int)v9 < splitPacketChannel->newSplitList.uniqueFilled ) /*0x1410fe073*/
    {
      v11 = splitPacketChannel->newSplitList.internalList._Mypair._Myval2._Myfirst; /*0x1410fe077*/
      if ( splitPacketChannel->newSplitList.internalList._Mypair._Myval2._Mylast - v11 <= (unsigned __int64)(unsigned int)v9 ) /*0x1410fe089*/
        std::vector<std::pair<std::string,dtl::eleminfo>>::_Xrange(a1: (unsigned int)v9, a2: v9); /*0x1410fe234*/
      v8->userMemory.dataBitLength += v11[(unsigned int)v9]->dataBitLength; /*0x1410fe096*/
      dataBitLength = v8->userMemory.dataBitLength; /*0x1410fe099*/
      v9 = (unsigned int)(v9 + 1); /*0x1410fe09c*/
    }
    v12 = dataBitLength + 7; /*0x1410fe0a0*/
    v13 = (dataBitLength + 7) >> 3; /*0x1410fe0a6*/
    v14 = *this->maxRxPayloadSize; /*0x1410fe0b1*/
    if ( v13 > v14 ) /*0x1410fe0b7*/
    {
      v26 = RBX::format(result: &v31, fmt: "Reconstructed packet too large %u > %u", v13, v14); /*0x1410fe245*/
      __wind /*0xf1c0000000000020*/
      {
        RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, m: v26); /*0x1410fe253*/
        throw &pExceptionObject; /*0x1410fe264*/
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v31); /*0xf1c0000000000030*/
      }
    }
    v8->userMemory.data = (unsigned __int8 *)RBX::Memory::allocate(size: v12 >> 3); /*0x1410fe0c6*/
    v8->userMemory.allocationScheme = 0; /*0x1410fe0ca*/
    v16 = 0; /*0x1410fe0ce*/
    for ( i = 0; i < splitPacketChannel->newSplitList.uniqueFilled; ++i ) /*0x1410fe0d1*/
    {
      v18 = splitPacketChannel->newSplitList.internalList._Mypair._Myval2._Myfirst; /*0x1410fe0dc*/
      if ( splitPacketChannel->newSplitList.internalList._Mypair._Myval2._Mylast - v18 <= (unsigned __int64)i ) /*0x1410fe0ee*/
        std::vector<std::pair<std::string,dtl::eleminfo>>::_Xrange(a1: v15, a2: v18); /*0x1410fe26a*/
      memcpy_0( /*0x1410fe114*/
        a1: &v8->userMemory.data[(unsigned __int64)(unsigned int)(v16 + 7) >> 3],
        Src: v18[i]->data,
        Size: (unsigned __int64)(v18[i]->dataBitLength + 7) >> 3);
      v15 = splitPacketChannel->newSplitList.internalList._Mypair._Myval2._Myfirst; /*0x1410fe119*/
      if ( splitPacketChannel->newSplitList.internalList._Mypair._Myval2._Mylast - v15 <= (unsigned __int64)i ) /*0x1410fe12b*/
        std::vector<std::pair<std::string,dtl::eleminfo>>::_Xrange(a1: v15, a2: v19); /*0x1410fe26f*/
      v16 += v15[i]->dataBitLength; /*0x1410fe135*/
    }
    for ( j = 0; j < splitPacketChannel->newSplitList.uniqueFilled; ++j ) /*0x1410fe13d*/
    {
      v21 = splitPacketChannel->newSplitList.internalList._Mypair._Myval2._Myfirst; /*0x1410fe148*/
      if ( splitPacketChannel->newSplitList.internalList._Mypair._Myval2._Mylast - v21 <= (unsigned __int64)j ) /*0x1410fe15a*/
        std::vector<std::pair<std::string,dtl::eleminfo>>::_Xrange(a1: v15, a2: v21); /*0x1410fe274*/
      RakNet::ReliabilityLayer::FreeInternalPacketData( /*0x1410fe174*/
        this,
        internalPacket: v21[j],
        file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
        line: 0xEF5u);
      v23 = splitPacketChannel->newSplitList.internalList._Mypair._Myval2._Myfirst; /*0x1410fe179*/
      if ( splitPacketChannel->newSplitList.internalList._Mypair._Myval2._Mylast - v23 <= (unsigned __int64)j ) /*0x1410fe18b*/
        std::vector<std::pair<std::string,dtl::eleminfo>>::_Xrange(a1: v22, a2: v23); /*0x1410fe279*/
      RakNet::ReliabilityLayer::ReleaseToInternalPacketPool(this, ip: v23[j]); /*0x1410fe198*/
    }
  }
  catch ( std::exception )
  {
    for ( k = 0; (unsigned int)k < splitPacketChannel->newSplitList.uniqueFilled; k = (unsigned int)(k + 1) ) /*0x1431eefb5*/
    {
      v28 = splitPacketChannel->newSplitList.internalList._Mypair._Myval2._Myfirst; /*0x1431eefc2*/
      if ( splitPacketChannel->newSplitList.internalList._Mypair._Myval2._Mylast - v28 <= (unsigned __int64)(unsigned int)k ) /*0x1431eefd4*/
        std::vector<std::pair<std::string,dtl::eleminfo>>::_Xrange(a1: v15, a2: v28); /*0x1431ef01e*/
      RakNet::ReliabilityLayer::FreeInternalPacketData( /*0x1431eefea*/
        this,
        internalPacket: v28[k],
        file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
        line: 0xEFEu);
      v30 = splitPacketChannel->newSplitList.internalList._Mypair._Myval2._Myfirst; /*0x1431eefef*/
      if ( splitPacketChannel->newSplitList.internalList._Mypair._Myval2._Mylast - v30 <= (unsigned __int64)(unsigned int)k ) /*0x1431ef001*/
        std::vector<std::pair<std::string,dtl::eleminfo>>::_Xrange(a1: v29, a2: v30); /*0x1431ef018*/
      RakNet::ReliabilityLayer::ReleaseToInternalPacketPool(this, ip: v30[k]); /*0x1431ef00a*/
    }
    RakNet::SplitPacketChannel::`scalar deleting destructor'(this: splitPacketChannel, a2: 1); /*0x1431ef02c*/
    this->deadConnection = true; /*0x1431ef031*/
    return nullptr; /*0xf1c000000000005c*/
  }
  v24 = splitPacketChannel->newSplitList.internalList._Mypair._Myval2._Myfirst; /*0x1410fe1a1*/
  if ( v24 != nullptr ) /*0x1410fe1a8*/
  {
    if ( (((char *)splitPacketChannel->newSplitList.internalList._Mypair._Myval2._Myend - (char *)v24) /*0x1410fe1bc*/
        & 0xFFFFFFFFFFFFFFF8uLL) >= 0x1000 )
    {
      if ( (unsigned __int64)((char *)v24 - (char *)*(v24 - 1) - 8) > 0x1F ) /*0x1410fe1d1*/
        _invalid_parameter_noinfo_noreturn(); /*0x1410fe208*/
      v24 = (RakNet::InternalPacket **)*(v24 - 1); /*0x1410fe1d3*/
    }
    operator delete(ptr: v24); /*0x1410fe1d6*/
    splitPacketChannel->newSplitList.internalList._Mypair._Myval2._Myfirst = nullptr; /*0x1410fe1db*/
    splitPacketChannel->newSplitList.internalList._Mypair._Myval2._Mylast = nullptr; /*0x1410fe1df*/
    splitPacketChannel->newSplitList.internalList._Mypair._Myval2._Myend = nullptr; /*0x1410fe1e3*/
  }
  if ( splitPacketChannel->splitPacketList.allocation_size != 0 ) /*0x1410fe1eb*/
    operator delete(ptr: splitPacketChannel->splitPacketList.listArray); /*0x1410fe1f1*/
  operator delete(ptr: splitPacketChannel); /*0x1410fe1fe*/
  return v8; /*0x1410fe211*/
}

// Address: 0x1410fe4c0 | Name: ?ClearPacketsAndDatagrams@ReliabilityLayer@RakNet@@AEAAXXZ
void __fastcall RakNet::ReliabilityLayer::ClearPacketsAndDatagrams(RakNet::ReliabilityLayer *this)
{
  unsigned int i; // edi
  __int64 v3; // rsi
  RakNet::InternalPacket *v4; // r8
  PacketReliability reliability; // eax
  RakNet::InternalPacket *unreliableNext; // rax
  unsigned int allocation_size; // eax

  for ( i = 0; i < this->packetsToDeallocThisUpdate.list_size; ++i ) /*0x1410fe4dc*/
  {
    if ( this->packetsToDeallocThisUpdate.listArray[i] ) /*0x1410fe4f9*/
    {
      v3 = i; /*0x1410fe50a*/
      v4 = this->packetsToSendThisUpdate.listArray[v3]; /*0x1410fe512*/
      reliability = v4->reliability; /*0x1410fe516*/
      if ( (reliability & 0xFFFFFFFA) == 0 && reliability != RELIABLE_SEQUENCED ) /*0x1410fe524*/
      {
        v4->unreliablePrev->unreliableNext = v4->unreliableNext; /*0x1410fe531*/
        v4->unreliableNext->unreliablePrev = v4->unreliablePrev; /*0x1410fe543*/
        if ( this->unreliableLinkedListHead == v4 ) /*0x1410fe551*/
        {
          unreliableNext = v4->unreliableNext; /*0x1410fe553*/
          this->unreliableLinkedListHead = unreliableNext; /*0x1410fe55a*/
          if ( unreliableNext == v4 ) /*0x1410fe564*/
            this->unreliableLinkedListHead = nullptr; /*0x1410fe566*/
        }
      }
      RakNet::ReliabilityLayer::FreeInternalPacketData( /*0x1410fe588*/
        this,
        internalPacket: this->packetsToSendThisUpdate.listArray[v3],
        file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
        line: 0x1080u);
      RakNet::ReliabilityLayer::ReleaseToInternalPacketPool(this, ip: this->packetsToSendThisUpdate.listArray[v3]); /*0x1410fe59b*/
    }
  }
  allocation_size = this->packetsToDeallocThisUpdate.allocation_size; /*0x1410fe5b3*/
  if ( allocation_size != 0 ) /*0x1410fe5c0*/
  {
    if ( allocation_size > 0x200 ) /*0x1410fe5c7*/
    {
      operator delete(ptr: this->packetsToDeallocThisUpdate.listArray); /*0x1410fe5d0*/
      this->packetsToDeallocThisUpdate.allocation_size = 0; /*0x1410fe5d5*/
      this->packetsToDeallocThisUpdate.listArray = nullptr; /*0x1410fe5db*/
    }
    this->packetsToDeallocThisUpdate.list_size = 0; /*0x1410fe5e2*/
  }
}

// Address: 0x1410fe600 | Name: ?CreateInternalPacketFromBitStream@ReliabilityLayer@RakNet@@AEAAPEAUInternalPacket@2@PEAVBitStream@2@_K@Z
DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *__fastcall RakNet::ReliabilityLayer::CreateInternalPacketFromBitStream(
        RakNet::ReliabilityLayer *this,
        RakNet::BitStream *bitStream,
        unsigned __int64 time)
{
  bool v3; // r12
  DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *v7; // rax
  DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *v8; // rbx
  unsigned __int64 readOffset; // rcx
  unsigned int v10; // r9d
  char AlignedVar8; // bp
  PacketReliability reliability; // ecx
  unsigned __int8 *p_orderingChannel; // r14
  unsigned int dataBitLength; // ecx
  unsigned int splitPacketCount; // eax
  unsigned __int64 v16; // rcx
  unsigned __int8 *v17; // rax
  RakNet::InternalPacket::AllocationScheme allocationScheme; // eax
  RakNet::InternalPacketRefCountedData *refCountedData; // rax
  RakNet::InternalPacketRefCountedData *v21; // rcx
  DataStructures::MemoryPool<RakNet::InternalPacketRefCountedData>::MemoryWithPage *v22; // rcx
  DataStructures::MemoryPool<RakNet::InternalPacketRefCountedData>::Page *parentPage; // rdi
  __int64 availableStackSize; // rax
  DataStructures::MemoryPool<RakNet::InternalPacketRefCountedData>::MemoryWithPage **availableStack; // rdx
  DataStructures::MemoryPool<RakNet::InternalPacketRefCountedData>::Page *unavailablePages; // rax
  int availablePagesSize; // ecx
  unsigned __int8 *data; // rcx
  unsigned __int8 tempChar; // [rsp+68h] [rbp+10h] BYREF
  unsigned __int16 s; // [rsp+78h] [rbp+20h] BYREF

  v3 = false; /*0x1410fe60e*/
  if ( bitStream->numberOfBitsUsed - bitStream->readOffset < 0x20 ) /*0x1410fe620*/
    return nullptr; /*0x1410fe620*/
  v7 = RakNet::ReliabilityLayer::AllocateFromInternalPacketPool(this); /*0x1410fe626*/
  v8 = v7; /*0x1410fe62b*/
  if ( v7 == nullptr ) /*0x1410fe631*/
    return nullptr; /*0x1410fea08*/
  v7->userMemory.creationTime = time; /*0x1410fe637*/
  bitStream->readOffset = bitStream->readOffset - (((unsigned __int8)bitStream->readOffset - 1) & 7) + 7; /*0x1410fe661*/
  RakNet::BitStream::ReadBits( /*0x1410fe667*/
    this: bitStream,
    inOutByteArray: &tempChar,
    numberOfBitsToRead: 3u,
    alignBitsToRight: true);
  v8->userMemory.reliability = tempChar; /*0x1410fe671*/
  readOffset = bitStream->readOffset; /*0x1410fe674*/
  v10 = readOffset + 1; /*0x1410fe677*/
  if ( (unsigned int)(readOffset + 1) <= bitStream->numberOfBitsUsed ) /*0x1410fe67f*/
  {
    AlignedVar8 = 1; /*0x1410fe697*/
    v3 = (bitStream->data[readOffset >> 3] & (unsigned __int8)(128 >> (readOffset & 7))) != 0; /*0x1410fe6a9*/
  }
  else
  {
    AlignedVar8 = 0; /*0x1410fe681*/
    v10 = bitStream->readOffset; /*0x1410fe684*/
  }
  bitStream->readOffset = v10 - (((_BYTE)v10 - 1) & 7) + 7; /*0x1410fe6c3*/
  RakNet::BitStream::ReadAlignedVar16(this: bitStream, inOutByteArray: (char *)&s); /*0x1410fe6c7*/
  v8->userMemory.dataBitLength = s; /*0x1410fe6d1*/
  if ( (unsigned int)(v8->userMemory.reliability - 2) <= 2 ) /*0x1410fe6dd*/
    RakNet::BitStream::Read<RakNet::uint24_t>(this: bitStream, outTemplateVar: &v8->userMemory.reliableMessageNumber); /*0x1410fe6ed*/
  else
    v8->userMemory.reliableMessageNumber.val = 0xFFFFFF; /*0x1410fe6df*/
  bitStream->readOffset = bitStream->readOffset - (((unsigned __int8)bitStream->readOffset - 1) & 7) + 7; /*0x1410fe705*/
  reliability = v8->userMemory.reliability; /*0x1410fe708*/
  if ( (reliability == UNRELIABLE_SEQUENCED || reliability == RELIABLE_SEQUENCED) /*0x1410fe736*/
    && (RakNet::BitStream::Read<RakNet::uint24_t>(this: bitStream, outTemplateVar: &v8->userMemory.sequencingIndex),
        (reliability = v8->userMemory.reliability) == UNRELIABLE_SEQUENCED)
    || ((reliability - 3) & 0xFFFFFFFA) == 0 && reliability != NUMBER_OF_RELIABILITIES )
  {
    RakNet::BitStream::Read<RakNet::uint24_t>(this: bitStream, outTemplateVar: &v8->userMemory.orderingIndex); /*0x1410fe749*/
    p_orderingChannel = &v8->userMemory.orderingChannel; /*0x1410fe74e*/
    AlignedVar8 = RakNet::BitStream::ReadAlignedVar8( /*0x1410fe764*/
                    this: bitStream,
                    inOutByteArray: (char *)&v8->userMemory.orderingChannel);
    if ( DFFlag::TransportLibraryTest.value && v8->userMemory.reliability == RELIABLE_ORDERED ) /*0x1410fe76d*/
      RakNet::TransportLibraryTestClientStats::checkTestComplete( /*0x1410fe77c*/
        this: &this->tLibTestClientStats,
        bytes: (v8->userMemory.dataBitLength + 7) >> 3);
  }
  else
  {
    p_orderingChannel = &v8->userMemory.orderingChannel; /*0x1410fe738*/
    v8->userMemory.orderingChannel = 0; /*0x1410fe73c*/
  }
  if ( v3 ) /*0x1410fe787*/
  {
    RakNet::BitStream::ReadAlignedVar32(this: bitStream, inOutByteArray: (char *)&v8->userMemory.splitPacketCount); /*0x1410fe790*/
    RakNet::BitStream::ReadAlignedVar16(this: bitStream, inOutByteArray: (char *)&v8->userMemory.splitPacketId); /*0x1410fe79c*/
    AlignedVar8 = RakNet::BitStream::ReadAlignedVar32( /*0x1410fe7ad*/
                    this: bitStream,
                    inOutByteArray: (char *)&v8->userMemory.splitPacketIndex);
  }
  else
  {
    v8->userMemory.splitPacketCount = 0; /*0x1410fe7b2*/
  }
  if ( AlignedVar8 != 0 ) /*0x1410fe7b9*/
  {
    dataBitLength = v8->userMemory.dataBitLength; /*0x1410fe7bb*/
    if ( dataBitLength != 0 && v8->userMemory.reliability < NUMBER_OF_RELIABILITIES && *p_orderingChannel < 0x20u ) /*0x1410fe7cc*/
    {
      if ( !v3 /*0x1410fe7e0*/
        || (splitPacketCount = v8->userMemory.splitPacketCount, v8->userMemory.splitPacketIndex < splitPacketCount)
        && splitPacketCount <= 0x7A120 )
      {
        v16 = (dataBitLength + 7) >> 3; /*0x1410fe7ec*/
        if ( (unsigned int)v16 <= *this->maxRxPayloadSize ) /*0x1410fe7f1*/
        {
          v8->userMemory.allocationScheme = 0; /*0x1410fe7f3*/
          v17 = (unsigned __int8 *)RBX::Memory::allocate(size: v16); /*0x1410fe7f7*/
          v8->userMemory.data = v17; /*0x1410fe7fc*/
          if ( v17 != nullptr ) /*0x1410fe803*/
          {
            v17[((v8->userMemory.dataBitLength + 7) >> 3) - 1] = 0; /*0x1410fe848*/
            if ( RakNet::BitStream::ReadAlignedBytes( /*0x1410fe866*/
                   this: bitStream,
                   inOutByteArray: v8->userMemory.data,
                   numberOfBytesToRead: (v8->userMemory.dataBitLength + 7) >> 3) != 0 )
              return v8; /*0x1410fea03*/
            allocationScheme = v8->userMemory.allocationScheme; /*0x1410fe86c*/
            if ( allocationScheme == REF_COUNTED ) /*0x1410fe872*/
            {
              refCountedData = v8->userMemory.refCountedData; /*0x1410fe878*/
              if ( refCountedData != nullptr ) /*0x1410fe87f*/
              {
                --refCountedData->refCount; /*0x1410fe881*/
                v21 = v8->userMemory.refCountedData; /*0x1410fe884*/
                if ( v21->refCount == 0 ) /*0x1410fe88c*/
                {
                  operator delete(ptr: v21->sharedDataBlock); /*0x1410fe891*/
                  v8->userMemory.refCountedData->sharedDataBlock = nullptr; /*0x1410fe89a*/
                  v22 = (DataStructures::MemoryPool<RakNet::InternalPacketRefCountedData>::MemoryWithPage *)v8->userMemory.refCountedData; /*0x1410fe89d*/
                  parentPage = v22->parentPage; /*0x1410fe8a1*/
                  availableStackSize = parentPage->availableStackSize; /*0x1410fe8a5*/
                  availableStack = parentPage->availableStack; /*0x1410fe8a9*/
                  if ( (_DWORD)availableStackSize != 0 ) /*0x1410fe8ae*/
                  {
                    availableStack[availableStackSize] = v22; /*0x1410fe960*/
                    if ( ++parentPage->availableStackSize == (unsigned int)(this->refCountedDataPool.memoryPoolPageSize /*0x1410fe98b*/
                                                                          / 0x18uLL)
                      && this->refCountedDataPool.availablePagesSize >= 4 )
                    {
                      if ( parentPage == this->refCountedDataPool.availablePages ) /*0x1410fe994*/
                        this->refCountedDataPool.availablePages = parentPage->next; /*0x1410fe99a*/
                      parentPage->prev->next = parentPage->next; /*0x1410fe9a9*/
                      parentPage->next->prev = parentPage->prev; /*0x1410fe9b5*/
                      --this->refCountedDataPool.availablePagesSize; /*0x1410fe9b9*/
                      operator delete(ptr: parentPage->availableStack); /*0x1410fe9c2*/
                      operator delete(ptr: parentPage->block); /*0x1410fe9cb*/
                      operator delete(ptr: parentPage); /*0x1410fe9d3*/
                    }
                    v8->userMemory.refCountedData = nullptr; /*0x1410fe9d8*/
                  }
                  else
                  {
                    *availableStack = v22; /*0x1410fe8b4*/
                    ++parentPage->availableStackSize; /*0x1410fe8b7*/
                    --this->refCountedDataPool.unavailablePagesSize; /*0x1410fe8ba*/
                    parentPage->next->prev = parentPage->prev; /*0x1410fe8c8*/
                    parentPage->prev->next = parentPage->next; /*0x1410fe8d4*/
                    if ( this->refCountedDataPool.unavailablePagesSize > 0 ) /*0x1410fe8df*/
                    {
                      unavailablePages = this->refCountedDataPool.unavailablePages; /*0x1410fe8e1*/
                      if ( parentPage == unavailablePages ) /*0x1410fe8eb*/
                        this->refCountedDataPool.unavailablePages = unavailablePages->next; /*0x1410fe8f1*/
                    }
                    availablePagesSize = this->refCountedDataPool.availablePagesSize; /*0x1410fe8f8*/
                    this->refCountedDataPool.availablePagesSize = availablePagesSize + 1; /*0x1410fe901*/
                    if ( availablePagesSize != 0 ) /*0x1410fe909*/
                    {
                      parentPage->next = this->refCountedDataPool.availablePages; /*0x1410fe92a*/
                      parentPage->prev = this->refCountedDataPool.availablePages->prev; /*0x1410fe939*/
                      this->refCountedDataPool.availablePages->prev->next = parentPage; /*0x1410fe948*/
                      this->refCountedDataPool.availablePages->prev = parentPage; /*0x1410fe953*/
                    }
                    else
                    {
                      this->refCountedDataPool.availablePages = parentPage; /*0x1410fe90b*/
                      parentPage->next = parentPage; /*0x1410fe912*/
                      parentPage->prev = parentPage; /*0x1410fe916*/
                    }
                    v8->userMemory.refCountedData = nullptr; /*0x1410fe91a*/
                  }
                }
              }
              goto LABEL_31; /*0x1410fe91e*/
            }
            if ( allocationScheme == 0 ) /*0x1410fe9e3*/
            {
              data = v8->userMemory.data; /*0x1410fe9e5*/
              if ( data == nullptr ) /*0x1410fe9ec*/
                goto LABEL_31; /*0x1410fe9ec*/
              operator delete(ptr: data); /*0x1410fe9f2*/
            }
            v8->userMemory.data = nullptr; /*0x1410fe9f7*/
            goto LABEL_31; /*0x1410fe9fb*/
          }
          RakNet::notifyOutOfMemory( /*0x1410fe811*/
            file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
            line: 3398);
        }
      }
    }
  }
LABEL_31:
  RakNet::ReliabilityLayer::ReleaseToInternalPacketPool(this, ip: &v8->userMemory); /*0x1410fe816*/
  return nullptr; /*0x1410fe832*/
}

// Address: 0x1410ff170 | Name: ?DropOldDatagramHistory@ReliabilityLayer@RakNet@@AEAAXXZ
void __fastcall RakNet::ReliabilityLayer::DropOldDatagramHistory(RakNet::ReliabilityLayer *this)
{
  unsigned int head; // r8d
  unsigned int tail; // ecx
  int v4; // ecx
  unsigned int allocation_size; // ecx
  RakNet::uint24_t datagramNumber; // [rsp+30h] [rbp+8h] BYREF

  head = this->datagramHistory.head; /*0x1410ff176*/
  tail = this->datagramHistory.tail; /*0x1410ff180*/
  if ( head > tail ) /*0x1410ff189*/
    v4 = this->datagramHistory.allocation_size - head + tail; /*0x1410ff199*/
  else
    v4 = tail - head; /*0x1410ff18b*/
  if ( v4 >= FInt::RakNetDatagramMessageIdArrayLength ) /*0x1410ff1a5*/
  {
    allocation_size = this->datagramHistory.allocation_size; /*0x1410ff1a7*/
    if ( head >= allocation_size ) /*0x1410ff1bc*/
      head -= allocation_size; /*0x1410ff1bc*/
    if ( this->datagramHistory.array[head].head == nullptr /*0x1410ff1d4*/
      || this->unreliableDatagramHistoryCount >= FInt::RakNetDatagramMessageIdArrayLength )
    {
      datagramNumber.val = this->datagramHistoryPopCount.val; /*0x1410ff1e4*/
      RakNet::ReliabilityLayer::RemoveFromDatagramHistory(this, (RakNet::uint24_t)&datagramNumber); /*0x1410ff1e8*/
      if ( ++this->datagramHistory.head == this->datagramHistory.allocation_size ) /*0x1410ff1ff*/
        this->datagramHistory.head = 0; /*0x1410ff201*/
      ++this->datagramHistoryPopCount.val; /*0x1410ff20b*/
      HIBYTE(this->datagramHistoryPopCount.val) = 0; /*0x1410ff211*/
    }
  }
}

// Address: 0x1410ff220 | Name: ?FreeAllPacketFragmentsInChannels@ReliabilityLayer@RakNet@@AEAAXXZ
void __fastcall RakNet::ReliabilityLayer::FreeAllPacketFragmentsInChannels(RakNet::ReliabilityLayer *this)
{
  unsigned int i; // r15d
  unsigned int v3; // esi
  unsigned __int64 v4; // r14
  RakNet::SplitPacketChannel **listArray; // rax
  RakNet::SplitPacketChannel *v6; // rcx
  int uniqueFilled; // ebp
  RakNet::SplitPacketChannel **v8; // rdx
  RakNet::SplitPacketChannel **v9; // r8
  RakNet::SplitPacketChannel *v10; // rax
  RakNet::InternalPacket **Myfirst; // rdx
  unsigned __int64 v12; // rcx
  RakNet::InternalPacket *v13; // rdx
  RakNet::SplitPacketChannel *v14; // rbx
  char *v15; // rcx

  for ( i = 0; i < this->splitPacketChannelList.orderedList.list_size; ++i ) /*0x1410ff24e*/
  {
    v3 = 0; /*0x1410ff263*/
    v4 = i; /*0x1410ff266*/
    listArray = this->splitPacketChannelList.orderedList.listArray; /*0x1410ff26e*/
    v6 = listArray[v4]; /*0x1410ff275*/
    uniqueFilled = v6->newSplitList.uniqueFilled; /*0x1410ff279*/
    if ( v6->newSplitList.intendedSize != 0 ) /*0x1410ff280*/
    {
      v8 = this->splitPacketChannelList.orderedList.listArray; /*0x1410ff286*/
      do /*0x1410ff321*/
      {
        v9 = listArray; /*0x1410ff290*/
        listArray = v8; /*0x1410ff293*/
        if ( uniqueFilled <= 0 ) /*0x1410ff298*/
          break; /*0x1410ff298*/
        v10 = v8[v4]; /*0x1410ff29e*/
        Myfirst = v10->newSplitList.internalList._Mypair._Myval2._Myfirst; /*0x1410ff2a4*/
        v12 = v10->newSplitList.internalList._Mypair._Myval2._Mylast - Myfirst; /*0x1410ff2af*/
        if ( v12 <= v3 ) /*0x1410ff2b6*/
          goto LABEL_24; /*0x1410ff2b6*/
        v13 = Myfirst[v3]; /*0x1410ff2bc*/
        listArray = v9; /*0x1410ff2c0*/
        if ( v13 != nullptr ) /*0x1410ff2c6*/
        {
          --uniqueFilled; /*0x1410ff2d8*/
          RakNet::ReliabilityLayer::FreeInternalPacketData( /*0x1410ff2da*/
            this,
            internalPacket: v13,
            file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
            line: 0x2B5u);
          v12 = (unsigned __int64)this->splitPacketChannelList.orderedList.listArray[v4]; /*0x1410ff2e6*/
          Myfirst = *(RakNet::InternalPacket ***)(v12 + 24); /*0x1410ff2ea*/
          if ( (__int64)(*(_QWORD *)(v12 + 32) - (_QWORD)Myfirst) >> 3 <= (unsigned __int64)v3 ) /*0x1410ff2fc*/
LABEL_24:
            std::vector<std::pair<std::string,dtl::eleminfo>>::_Xrange(a1: v12, a2: Myfirst); /*0x1410ff3ef*/
          RakNet::ReliabilityLayer::ReleaseToInternalPacketPool(this, ip: Myfirst[v3]); /*0x1410ff309*/
          listArray = this->splitPacketChannelList.orderedList.listArray; /*0x1410ff30e*/
        }
        ++v3; /*0x1410ff319*/
        v8 = listArray; /*0x1410ff31b*/
      }
      while ( v3 < listArray[v4]->newSplitList.intendedSize ); /*0x1410ff321*/
    }
    v14 = listArray[v4]; /*0x1410ff327*/
    if ( v14 != nullptr ) /*0x1410ff32e*/
    {
      v15 = (char *)v14->newSplitList.internalList._Mypair._Myval2._Myfirst; /*0x1410ff330*/
      if ( v15 != nullptr ) /*0x1410ff337*/
      {
        if ( (((char *)v14->newSplitList.internalList._Mypair._Myval2._Myend - v15) & 0xFFFFFFFFFFFFFFF8uLL) >= 0x1000 ) /*0x1410ff34b*/
        {
          if ( (unsigned __int64)&v15[-*((_QWORD *)v15 - 1) - 8] > 0x1F ) /*0x1410ff360*/
            _invalid_parameter_noinfo_noreturn(); /*0x1410ff3e8*/
          v15 = *((char **)v15 - 1); /*0x1410ff366*/
        }
        operator delete(ptr: v15); /*0x1410ff369*/
        v14->newSplitList.internalList._Mypair._Myval2._Myfirst = nullptr; /*0x1410ff36e*/
        v14->newSplitList.internalList._Mypair._Myval2._Mylast = nullptr; /*0x1410ff372*/
        v14->newSplitList.internalList._Mypair._Myval2._Myend = nullptr; /*0x1410ff376*/
      }
      if ( v14->splitPacketList.allocation_size != 0 ) /*0x1410ff37e*/
        operator delete(ptr: v14->splitPacketList.listArray); /*0x1410ff384*/
      operator delete(ptr: v14); /*0x1410ff391*/
    }
  }
  if ( this->splitPacketChannelList.orderedList.allocation_size != 0 ) /*0x1410ff3ad*/
  {
    operator delete(ptr: this->splitPacketChannelList.orderedList.listArray); /*0x1410ff3b6*/
    *(_QWORD *)&this->splitPacketChannelList.orderedList.list_size = 0; /*0x1410ff3bb*/
    this->splitPacketChannelList.orderedList.listArray = nullptr; /*0x1410ff3c2*/
  }
}

// Address: 0x1410ff400 | Name: ?FreeInternalPacketData@ReliabilityLayer@RakNet@@AEAAXPEAUInternalPacket@2@PEBDI@Z
void __fastcall RakNet::ReliabilityLayer::FreeInternalPacketData(
        RakNet::ReliabilityLayer *this,
        RakNet::InternalPacket *internalPacket,
        const char *file,
        unsigned int line)
{
  RakNet::InternalPacket::AllocationScheme allocationScheme; // eax
  RakNet::InternalPacketRefCountedData *refCountedData; // rax
  RakNet::InternalPacketRefCountedData *v8; // rcx
  RakNet::InternalPacketRefCountedData *v9; // rcx
  DataStructures::MemoryPool<RakNet::InternalPacketRefCountedData>::Page *sharedDataBlock; // rbx
  __int64 availableStackSize; // rax
  _QWORD *availableStack; // rdx
  DataStructures::MemoryPool<RakNet::InternalPacketRefCountedData>::Page *unavailablePages; // rax
  int availablePagesSize; // ecx
  unsigned __int8 *data; // rcx

  if ( internalPacket != nullptr ) /*0x1410ff403*/
  {
    allocationScheme = internalPacket->allocationScheme; /*0x1410ff413*/
    if ( allocationScheme == REF_COUNTED ) /*0x1410ff41f*/
    {
      refCountedData = internalPacket->refCountedData; /*0x1410ff425*/
      if ( refCountedData != nullptr ) /*0x1410ff42c*/
      {
        --refCountedData->refCount; /*0x1410ff432*/
        v8 = internalPacket->refCountedData; /*0x1410ff435*/
        if ( v8->refCount == 0 ) /*0x1410ff43d*/
        {
          operator delete(ptr: v8->sharedDataBlock); /*0x1410ff44b*/
          internalPacket->refCountedData->sharedDataBlock = nullptr; /*0x1410ff454*/
          v9 = internalPacket->refCountedData; /*0x1410ff45b*/
          sharedDataBlock = (DataStructures::MemoryPool<RakNet::InternalPacketRefCountedData>::Page *)v9[1].sharedDataBlock; /*0x1410ff45f*/
          availableStackSize = sharedDataBlock->availableStackSize; /*0x1410ff463*/
          availableStack = sharedDataBlock->availableStack; /*0x1410ff467*/
          if ( (_DWORD)availableStackSize != 0 ) /*0x1410ff46c*/
          {
            availableStack[availableStackSize] = v9; /*0x1410ff53c*/
            if ( ++sharedDataBlock->availableStackSize == (unsigned int)(this->refCountedDataPool.memoryPoolPageSize /*0x1410ff567*/
                                                                       / 0x18uLL)
              && this->refCountedDataPool.availablePagesSize >= 4 )
            {
              if ( sharedDataBlock == this->refCountedDataPool.availablePages ) /*0x1410ff570*/
                this->refCountedDataPool.availablePages = sharedDataBlock->next; /*0x1410ff576*/
              sharedDataBlock->prev->next = sharedDataBlock->next; /*0x1410ff585*/
              sharedDataBlock->next->prev = sharedDataBlock->prev; /*0x1410ff591*/
              --this->refCountedDataPool.availablePagesSize; /*0x1410ff595*/
              operator delete(ptr: sharedDataBlock->availableStack); /*0x1410ff59e*/
              operator delete(ptr: sharedDataBlock->block); /*0x1410ff5a7*/
              operator delete(ptr: sharedDataBlock); /*0x1410ff5af*/
            }
            internalPacket->refCountedData = nullptr; /*0x1410ff5b9*/
          }
          else
          {
            *availableStack = v9; /*0x1410ff472*/
            ++sharedDataBlock->availableStackSize; /*0x1410ff475*/
            --this->refCountedDataPool.unavailablePagesSize; /*0x1410ff478*/
            sharedDataBlock->next->prev = sharedDataBlock->prev; /*0x1410ff486*/
            sharedDataBlock->prev->next = sharedDataBlock->next; /*0x1410ff492*/
            if ( this->refCountedDataPool.unavailablePagesSize > 0 ) /*0x1410ff49d*/
            {
              unavailablePages = this->refCountedDataPool.unavailablePages; /*0x1410ff49f*/
              if ( sharedDataBlock == unavailablePages ) /*0x1410ff4a9*/
                this->refCountedDataPool.unavailablePages = unavailablePages->next; /*0x1410ff4af*/
            }
            availablePagesSize = this->refCountedDataPool.availablePagesSize; /*0x1410ff4b6*/
            this->refCountedDataPool.availablePagesSize = availablePagesSize + 1; /*0x1410ff4bf*/
            if ( availablePagesSize != 0 ) /*0x1410ff4c7*/
            {
              sharedDataBlock->next = this->refCountedDataPool.availablePages; /*0x1410ff4f7*/
              sharedDataBlock->prev = this->refCountedDataPool.availablePages->prev; /*0x1410ff506*/
              this->refCountedDataPool.availablePages->prev->next = sharedDataBlock; /*0x1410ff515*/
              this->refCountedDataPool.availablePages->prev = sharedDataBlock; /*0x1410ff520*/
            }
            else
            {
              this->refCountedDataPool.availablePages = sharedDataBlock; /*0x1410ff4c9*/
              sharedDataBlock->next = sharedDataBlock; /*0x1410ff4d0*/
              sharedDataBlock->prev = sharedDataBlock; /*0x1410ff4d4*/
            }
            internalPacket->refCountedData = nullptr; /*0x1410ff4dd*/
          }
        }
      }
    }
    else if ( allocationScheme != 0 ) /*0x1410ff5ce*/
    {
      internalPacket->data = nullptr; /*0x1410ff5f1*/
    }
    else
    {
      data = internalPacket->data; /*0x1410ff5d0*/
      if ( data != nullptr ) /*0x1410ff5d7*/
      {
        operator delete(ptr: data); /*0x1410ff5d9*/
        internalPacket->data = nullptr; /*0x1410ff5de*/
      }
    }
  }
}

// Address: 0x1410ff610 | Name: ?FreeThreadSafeMemory@ReliabilityLayer@RakNet@@AEAAXXZ
void __fastcall RakNet::ReliabilityLayer::FreeThreadSafeMemory(RakNet::ReliabilityLayer *this)
{
  unsigned int i; // r15d
  unsigned int v3; // ebp
  unsigned __int64 v4; // rsi
  RakNet::SplitPacketChannel **listArray; // rcx
  RakNet::SplitPacketChannel *v6; // rdx
  RakNet::InternalPacket **v7; // rax
  RakNet::InternalPacket *v8; // rdx
  RakNet::SplitPacketChannel *v9; // rbx
  RakNet::InternalPacket **Myfirst; // rcx
  unsigned int head; // edx
  unsigned int tail; // ecx
  unsigned int v13; // ecx
  unsigned int v14; // eax
  unsigned int allocation_size; // ecx
  RakNet::InternalPacket **array; // rdx
  __int64 v17; // rax
  RakNet::InternalPacket *v18; // rbx
  __int64 v19; // r14
  unsigned int *p_allocation_size; // rsi
  unsigned int j; // ebp
  RakNet::InternalPacket **v22; // rcx
  __int64 v23; // rax
  RakNet::InternalPacket **v24; // rsi
  RakNet::InternalPacket *resendLinkedListHead; // rbx
  RakNet::InternalPacket *v26; // rdx
  std::_Tree_node<std::pair<RakNet::uint24_t const ,RakNet::InternalPacket *>,void *> *Left; // rbx
  std::_Tree_node<std::pair<RakNet::uint24_t const ,RakNet::InternalPacket *>,void *> *Right; // rax
  std::_Tree_node<std::pair<RakNet::uint24_t const ,RakNet::InternalPacket *>,void *> *k; // rax
  std::_Tree_node<std::pair<RakNet::uint24_t const ,RakNet::InternalPacket *>,void *> *m; // rcx
  std::_Tree_node<std::pair<RakNet::uint24_t const ,RakNet::InternalPacket *>,void *> *Myhead; // rsi
  std::_Tree_node<std::pair<RakNet::uint24_t const ,RakNet::InternalPacket *>,void *> *Parent; // rbx
  std::_Tree_node<std::pair<RakNet::uint24_t const ,RakNet::InternalPacket *>,void *> *v33; // rcx
  unsigned int n; // esi
  DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::HeapNode *v35; // rdx
  unsigned int v36; // eax
  DataStructures::List<RakNet::InternalPacket *> *p_packetsToSendThisUpdate; // rbx
  unsigned int v38; // esi
  unsigned int ii; // eax
  RakNet::InternalPacket **v40; // rbp
  RakNet::InternalPacket **v41; // rcx
  unsigned int v42; // r8d
  DataStructures::List<bool> *p_packetsToDeallocThisUpdate; // rbx
  unsigned int jj; // eax
  bool *v45; // r14
  bool *v46; // rcx
  unsigned int v47; // r8d
  DataStructures::List<unsigned int> *v48; // rbx
  unsigned int kk; // eax
  unsigned int *v50; // rbp
  unsigned int *v51; // rcx
  unsigned int v52; // r8d
  DataStructures::List<unsigned int> *p_datagramSizesInBytes; // rbx
  unsigned int *v54; // rsi
  unsigned int *v55; // rcx
  unsigned int v56; // r8d
  unsigned int v57; // edx
  unsigned int v58; // ecx
  unsigned int v59; // ecx
  DataStructures::RangeNode<RakNet::uint24_t> *v60; // rcx
  unsigned int v61; // eax
  DataStructures::RangeNode<RakNet::uint24_t> *v62; // rbx
  unsigned int v63; // eax
  DataStructures::RangeNode<RakNet::uint24_t> *v64; // rbx
  __int64 v65; // [rsp+0h] [rbp-48h] BYREF
  RakNet::uint24_t datagramNumber; // [rsp+58h] [rbp+10h] BYREF

  RakNet::ReliabilityLayer::ClearPacketsAndDatagrams(this); /*0x1410ff62f*/
  if ( DFFlag::CLI56776.value ) /*0x1410ff63e*/
  {
    RakNet::ReliabilityLayer::FreeAllPacketFragmentsInChannels(this); /*0x1410ff643*/
  }
  else
  {
    for ( i = 0; i < this->splitPacketChannelList.orderedList.list_size; ++i ) /*0x1410ff657*/
    {
      v3 = 0; /*0x1410ff660*/
      v4 = i; /*0x1410ff666*/
      listArray = this->splitPacketChannelList.orderedList.listArray; /*0x1410ff66e*/
      if ( listArray[v4]->splitPacketList.list_size != 0 ) /*0x1410ff67d*/
      {
        do /*0x1410ff718*/
        {
          v6 = listArray[v4]; /*0x1410ff683*/
          if ( v6 != nullptr && (v7 = v6->splitPacketList.listArray)[v3] != nullptr ) /*0x1410ff6a1*/
          {
            RakNet::ReliabilityLayer::FreeInternalPacketData( /*0x1410ff6b6*/
              this,
              internalPacket: v7[v3],
              file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
              line: 0x2D2u);
            v8 = this->splitPacketChannelList.orderedList.listArray[v4]->splitPacketList.listArray[v3]; /*0x1410ff6ca*/
          }
          else
          {
            RakNet::ReliabilityLayer::FreeInternalPacketData( /*0x1410ff6e8*/
              this,
              internalPacket: v6->splitPacketList.listArray[v3],
              file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
              line: 0x2D7u);
            v8 = this->splitPacketChannelList.orderedList.listArray[v4]->splitPacketList.listArray[v3]; /*0x1410ff6fc*/
          }
          RakNet::ReliabilityLayer::ReleaseToInternalPacketPool(this, ip: v8); /*0x1410ff703*/
          ++v3; /*0x1410ff708*/
          listArray = this->splitPacketChannelList.orderedList.listArray; /*0x1410ff70a*/
        }
        while ( v3 < listArray[i]->splitPacketList.list_size ); /*0x1410ff718*/
      }
      v9 = listArray[v4]; /*0x1410ff71e*/
      if ( v9 != nullptr ) /*0x1410ff725*/
      {
        Myfirst = v9->newSplitList.internalList._Mypair._Myval2._Myfirst; /*0x1410ff727*/
        if ( Myfirst != nullptr ) /*0x1410ff72e*/
        {
          if ( (unsigned __int64)(8 * (v9->newSplitList.internalList._Mypair._Myval2._Myend - Myfirst)) >= 0x1000 ) /*0x1410ff74a*/
          {
            if ( (unsigned __int64)((char *)Myfirst - (char *)*(Myfirst - 1) - 8) > 0x1F ) /*0x1410ff75f*/
              _invalid_parameter_noinfo_noreturn(); /*0x1410ff7d2*/
            Myfirst = (RakNet::InternalPacket **)*(Myfirst - 1); /*0x1410ff761*/
          }
          operator delete(ptr: Myfirst); /*0x1410ff764*/
          v9->newSplitList.internalList._Mypair._Myval2._Myfirst = nullptr; /*0x1410ff769*/
          v9->newSplitList.internalList._Mypair._Myval2._Mylast = nullptr; /*0x1410ff76d*/
          v9->newSplitList.internalList._Mypair._Myval2._Myend = nullptr; /*0x1410ff771*/
        }
        if ( v9->splitPacketList.allocation_size != 0 ) /*0x1410ff779*/
          operator delete(ptr: v9->splitPacketList.listArray); /*0x1410ff77f*/
        operator delete(ptr: v9); /*0x1410ff78c*/
      }
    }
    if ( this->splitPacketChannelList.orderedList.allocation_size != 0 ) /*0x1410ff7a8*/
    {
      operator delete(ptr: this->splitPacketChannelList.orderedList.listArray); /*0x1410ff7b1*/
      *(_QWORD *)&this->splitPacketChannelList.orderedList.list_size = 0; /*0x1410ff7b6*/
      this->splitPacketChannelList.orderedList.listArray = nullptr; /*0x1410ff7bd*/
    }
  }
  while ( 1 )
  {
    head = this->outputQueue.head; /*0x1410ff7c4*/
    tail = this->outputQueue.tail; /*0x1410ff7c7*/
    v13 = head > tail ? this->outputQueue.allocation_size - head + tail : tail - head;
    if ( v13 == 0 ) /*0x1410ff7e2*/
      break; /*0x1410ff7e2*/
    v14 = head + 1; /*0x1410ff7e4*/
    this->outputQueue.head = head + 1; /*0x1410ff7e7*/
    allocation_size = this->outputQueue.allocation_size; /*0x1410ff7ea*/
    array = this->outputQueue.array; /*0x1410ff7ed*/
    if ( v14 == allocation_size ) /*0x1410ff7f3*/
    {
      this->outputQueue.head = 0; /*0x1410ff7f5*/
      v17 = allocation_size - 1; /*0x1410ff7f9*/
    }
    else if ( v14 != 0 ) /*0x1410ff800*/
    {
      v17 = v14 - 1; /*0x1410ff807*/
    }
    else
    {
      v17 = allocation_size - 1; /*0x1410ff802*/
    }
    v18 = array[v17]; /*0x1410ff809*/
    RakNet::ReliabilityLayer::FreeInternalPacketData( /*0x1410ff820*/
      this,
      internalPacket: v18,
      file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
      line: 0x2EAu);
    RakNet::ReliabilityLayer::ReleaseToInternalPacketPool(this, ip: v18); /*0x1410ff82b*/
  }
  operator delete(ptr: this->outputQueue.array); /*0x1410ff836*/
  this->outputQueue.array = (RakNet::InternalPacket **)operator new(size: 0x100u); /*0x1410ff845*/
  v19 = 32; /*0x1410ff849*/
  this->outputQueue.allocation_size = 32; /*0x1410ff84f*/
  *(_QWORD *)&this->outputQueue.head = 0; /*0x1410ff853*/
  p_allocation_size = &this->orderingHeaps[0].heap.allocation_size; /*0x1410ff857*/
  do /*0x1410ff8d4*/
  {
    for ( j = 0; j < *(p_allocation_size - 1); ++j ) /*0x1410ff867*/
    {
      RakNet::ReliabilityLayer::FreeInternalPacketData( /*0x1410ff88e*/
        this,
        internalPacket: *(RakNet::InternalPacket **)(*(_QWORD *)(p_allocation_size - 3) + 16LL * j + 8),
        file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
        line: 0x30Cu);
      RakNet::ReliabilityLayer::ReleaseToInternalPacketPool( /*0x1410ff89f*/
        this,
        ip: *(RakNet::InternalPacket **)(*(_QWORD *)(p_allocation_size - 3) + 16LL * j + 8));
    }
    if ( *p_allocation_size != 0 ) /*0x1410ff8af*/
    {
      if ( *p_allocation_size > 0x200 ) /*0x1410ff8b6*/
      {
        operator delete(ptr: *(void **)(p_allocation_size - 3)); /*0x1410ff8bc*/
        *p_allocation_size = 0; /*0x1410ff8c1*/
        *(_QWORD *)(p_allocation_size - 3) = 0; /*0x1410ff8c4*/
      }
      *(p_allocation_size - 1) = 0; /*0x1410ff8c8*/
    }
    p_allocation_size += 6; /*0x1410ff8cc*/
    --v19; /*0x1410ff8d0*/
  }
  while ( v19 != 0 ); /*0x1410ff8d4*/
  v22 = this->resendBuffer._Mypair._Myval2._Myfirst; /*0x1410ff8d6*/
  v23 = this->resendBuffer._Mypair._Myval2._Mylast - v22; /*0x1410ff8e7*/
  v24 = &v22[v23]; /*0x1410ff8f3*/
  memset_0(a1: v22, Val: 0, Size: 8 * v23); /*0x1410ff8fd*/
  this->resendBuffer._Mypair._Myval2._Mylast = v24; /*0x1410ff902*/
  this->statistics.messagesInResendBuffer = 0; /*0x1410ff909*/
  this->statistics.bytesInResendBuffer = 0; /*0x1410ff910*/
  resendLinkedListHead = this->resendLinkedListHead; /*0x1410ff917*/
  if ( resendLinkedListHead != nullptr ) /*0x1410ff921*/
  {
    while ( 1 ) /*0x1410ff923*/
    {
      if ( resendLinkedListHead->data != nullptr ) /*0x1410ff927*/
        RakNet::ReliabilityLayer::FreeInternalPacketData( /*0x1410ff93c*/
          this,
          internalPacket: resendLinkedListHead,
          file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
          line: 0x31Fu);
      v26 = resendLinkedListHead; /*0x1410ff941*/
      resendLinkedListHead = resendLinkedListHead->resendNext; /*0x1410ff944*/
      if ( resendLinkedListHead == this->resendLinkedListHead ) /*0x1410ff952*/
        break; /*0x1410ff952*/
      RakNet::ReliabilityLayer::ReleaseToInternalPacketPool(this, ip: v26); /*0x1410ff954*/
    }
    RakNet::ReliabilityLayer::ReleaseToInternalPacketPool(this, ip: v26); /*0x1410ff95b*/
    this->resendLinkedListHead = nullptr; /*0x1410ff960*/
  }
  if ( DFFlag::GameLoadDataStatistics.value ) /*0x1410ff96e*/
  {
    Left = this->resendBuffer2._Mypair._Myval2._Myval2._Myhead->_Left; /*0x1410ff97b*/
    while ( Left->_Isnil == 0 ) /*0x1410ff982*/
    {
      RakNet::ReliabilityLayer::ReleaseToInternalPacketPool(this, ip: Left->_Myval.second); /*0x1410ff98b*/
      Right = Left->_Right; /*0x1410ff990*/
      if ( Right->_Isnil != 0 ) /*0x1410ff998*/
      {
        for ( k = Left->_Parent; k->_Isnil == 0; k = k->_Parent ) /*0x1410ff9a2*/
        {
          if ( Left != k->_Right ) /*0x1410ff9a8*/
            break; /*0x1410ff9a8*/
          Left = k; /*0x1410ff9aa*/
        }
        Left = k; /*0x1410ff9b7*/
      }
      else
      {
        Left = Left->_Right; /*0x1410ff9bc*/
        for ( m = Right->_Left; m->_Isnil == 0; m = m->_Left ) /*0x1410ff9c6*/
          Left = m; /*0x1410ff9d0*/
      }
    }
    Myhead = this->resendBuffer2._Mypair._Myval2._Myval2._Myhead; /*0x1410ff9e5*/
    Parent = Myhead->_Parent; /*0x1410ff9ec*/
    while ( Parent->_Isnil == 0 ) /*0x1410ff9f4*/
    {
      std::_Tree_val<std::_Tree_simple_types<std::pair<webrtc::Resource const * const,int>>>::_Erase_tree<std::allocator<std::_Tree_node<std::pair<webrtc::Resource const * const,int>,void *>>>( /*0x1410ffa12*/
        this: (std::_Tree_val<std::_Tree_simple_types<std::pair<RBX::Reflection::PropertyDescriptor const * const,SettingsDialog::PropertyItem *> > > *)&this->resendBuffer2,
        _Al: (std::allocator<std::_Tree_node<std::pair<RBX::Reflection::PropertyDescriptor const * const,SettingsDialog::PropertyItem *>,void *> > *)&this->resendBuffer2,
        _Rootnode: (std::_Tree_node<std::pair<RBX::Reflection::PropertyDescriptor const * const,SettingsDialog::PropertyItem *>,void *> *)Parent->_Right);
      v33 = Parent; /*0x1410ffa17*/
      Parent = Parent->_Left; /*0x1410ffa1a*/
      operator delete(ptr: v33); /*0x1410ffa22*/
    }
    Myhead->_Parent = Myhead; /*0x1410ffa2d*/
    Myhead->_Left = Myhead; /*0x1410ffa31*/
    Myhead->_Right = Myhead; /*0x1410ffa34*/
    this->resendBuffer2._Mypair._Myval2._Myval2._Mysize = 0; /*0x1410ffa38*/
    this->resendLinkedListHead2 = nullptr; /*0x1410ffa3f*/
  }
  *(_QWORD *)&this->unacknowledgedBytes = 0; /*0x1410ffa46*/
  for ( n = 0; n < this->outgoingPacketBuffer.heap.list_size; ++n ) /*0x1410ffa57*/
  {
    v35 = this->outgoingPacketBuffer.heap.listArray; /*0x1410ffa65*/
    if ( v35[n].data->data != nullptr ) /*0x1410ffa75*/
    {
      RakNet::ReliabilityLayer::FreeInternalPacketData( /*0x1410ffa8a*/
        this,
        internalPacket: v35[n].data,
        file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
        line: 0x33Au);
      v35 = this->outgoingPacketBuffer.heap.listArray; /*0x1410ffa8f*/
    }
    RakNet::ReliabilityLayer::ReleaseToInternalPacketPool(this, ip: v35[n].data); /*0x1410ffa9e*/
  }
  v36 = this->outgoingPacketBuffer.heap.allocation_size; /*0x1410ffaad*/
  if ( v36 != 0 ) /*0x1410ffab5*/
  {
    if ( v36 > 0x200 ) /*0x1410ffabc*/
    {
      operator delete(ptr: this->outgoingPacketBuffer.heap.listArray); /*0x1410ffac5*/
      this->outgoingPacketBuffer.heap.allocation_size = 0; /*0x1410ffaca*/
      this->outgoingPacketBuffer.heap.listArray = nullptr; /*0x1410ffad1*/
    }
    this->outgoingPacketBuffer.heap.list_size = 0; /*0x1410ffad8*/
  }
  if ( this->unreliableWithAckReceiptHistory.allocation_size != 0 ) /*0x1410ffae6*/
  {
    operator delete(ptr: this->unreliableWithAckReceiptHistory.listArray); /*0x1410ffaef*/
    *(_QWORD *)&this->unreliableWithAckReceiptHistory.list_size = 0; /*0x1410ffaf4*/
    this->unreliableWithAckReceiptHistory.listArray = nullptr; /*0x1410ffafb*/
  }
  p_packetsToSendThisUpdate = &this->packetsToSendThisUpdate; /*0x1410ffb02*/
  if ( this->packetsToSendThisUpdate.allocation_size != 0 ) /*0x1410ffb0d*/
  {
    operator delete(ptr: p_packetsToSendThisUpdate->listArray); /*0x1410ffb12*/
    *(_QWORD *)&this->packetsToSendThisUpdate.list_size = 0; /*0x1410ffb17*/
    p_packetsToSendThisUpdate->listArray = nullptr; /*0x1410ffb1b*/
  }
  v38 = 16; /*0x1410ffb21*/
  for ( ii = 16; ii < 0x200; ii *= 2 ) /*0x1410ffb26*/
    ; /*0x1410ffb30*/
  if ( this->packetsToSendThisUpdate.allocation_size < ii ) /*0x1410ffb43*/
  {
    this->packetsToSendThisUpdate.allocation_size = ii; /*0x1410ffb45*/
    v40 = (RakNet::InternalPacket **)operator new(size: saturated_mul((int)ii, 8u)); /*0x1410ffb68*/
    v41 = p_packetsToSendThisUpdate->listArray; /*0x1410ffb6b*/
    if ( p_packetsToSendThisUpdate->listArray != nullptr ) /*0x1410ffb71*/
    {
      v42 = 0; /*0x1410ffb73*/
      if ( this->packetsToSendThisUpdate.list_size != 0 ) /*0x1410ffb7a*/
      {
        do /*0x1410ffb9d*/
        {
          v40[v42] = p_packetsToSendThisUpdate->listArray[v42]; /*0x1410ffb92*/
          ++v42; /*0x1410ffb96*/
        }
        while ( v42 < this->packetsToSendThisUpdate.list_size ); /*0x1410ffb9d*/
        v41 = p_packetsToSendThisUpdate->listArray; /*0x1410ffb9f*/
      }
      operator delete(ptr: v41); /*0x1410ffba2*/
    }
    p_packetsToSendThisUpdate->listArray = v40; /*0x1410ffba7*/
  }
  p_packetsToDeallocThisUpdate = &this->packetsToDeallocThisUpdate; /*0x1410ffbaa*/
  if ( this->packetsToDeallocThisUpdate.allocation_size != 0 ) /*0x1410ffbb5*/
  {
    operator delete(ptr: p_packetsToDeallocThisUpdate->listArray); /*0x1410ffbba*/
    *(_QWORD *)&this->packetsToDeallocThisUpdate.list_size = 0; /*0x1410ffbbf*/
    p_packetsToDeallocThisUpdate->listArray = nullptr; /*0x1410ffbc3*/
  }
  for ( jj = 16; jj < 0x200; jj *= 2 ) /*0x1410ffbc9*/
    ; /*0x1410ffbd0*/
  if ( this->packetsToDeallocThisUpdate.allocation_size < jj ) /*0x1410ffbdc*/
  {
    this->packetsToDeallocThisUpdate.allocation_size = jj; /*0x1410ffbde*/
    v45 = (bool *)operator new(size: (int)jj); /*0x1410ffbf2*/
    v46 = p_packetsToDeallocThisUpdate->listArray; /*0x1410ffbf5*/
    if ( p_packetsToDeallocThisUpdate->listArray != nullptr ) /*0x1410ffbfb*/
    {
      v47 = 0; /*0x1410ffbfd*/
      if ( this->packetsToDeallocThisUpdate.list_size != 0 ) /*0x1410ffc04*/
      {
        do /*0x1410ffc25*/
        {
          v45[v47] = p_packetsToDeallocThisUpdate->listArray[v47]; /*0x1410ffc1a*/
          ++v47; /*0x1410ffc1e*/
        }
        while ( v47 < this->packetsToDeallocThisUpdate.list_size ); /*0x1410ffc25*/
        v46 = p_packetsToDeallocThisUpdate->listArray; /*0x1410ffc27*/
      }
      operator delete(ptr: v46); /*0x1410ffc2a*/
    }
    p_packetsToDeallocThisUpdate->listArray = v45; /*0x1410ffc2f*/
  }
  v48 = &this->packetsToSendThisUpdateDatagramBoundaries; /*0x1410ffc32*/
  if ( this->packetsToSendThisUpdateDatagramBoundaries.allocation_size != 0 ) /*0x1410ffc3d*/
  {
    operator delete(ptr: v48->listArray); /*0x1410ffc42*/
    *(_QWORD *)&this->packetsToSendThisUpdateDatagramBoundaries.list_size = 0; /*0x1410ffc47*/
    v48->listArray = nullptr; /*0x1410ffc4b*/
  }
  for ( kk = 16; kk < 0x80; kk *= 2 ) /*0x1410ffc51*/
    ; /*0x1410ffc53*/
  if ( this->packetsToSendThisUpdateDatagramBoundaries.allocation_size < kk ) /*0x1410ffc5f*/
  {
    this->packetsToSendThisUpdateDatagramBoundaries.allocation_size = kk; /*0x1410ffc61*/
    v50 = (unsigned int *)operator new(size: saturated_mul((int)kk, 4u)); /*0x1410ffc84*/
    v51 = v48->listArray; /*0x1410ffc87*/
    if ( v48->listArray != nullptr ) /*0x1410ffc8d*/
    {
      v52 = 0; /*0x1410ffc8f*/
      if ( this->packetsToSendThisUpdateDatagramBoundaries.list_size != 0 ) /*0x1410ffc96*/
      {
        do /*0x1410ffcbb*/
        {
          v50[v52] = v48->listArray[v52]; /*0x1410ffcb1*/
          ++v52; /*0x1410ffcb4*/
        }
        while ( v52 < this->packetsToSendThisUpdateDatagramBoundaries.list_size ); /*0x1410ffcbb*/
        v51 = v48->listArray; /*0x1410ffcbd*/
      }
      operator delete(ptr: v51); /*0x1410ffcc0*/
    }
    v48->listArray = v50; /*0x1410ffcc5*/
  }
  p_datagramSizesInBytes = &this->datagramSizesInBytes; /*0x1410ffcc8*/
  if ( this->datagramSizesInBytes.allocation_size != 0 ) /*0x1410ffcd3*/
  {
    operator delete(ptr: p_datagramSizesInBytes->listArray); /*0x1410ffcd8*/
    *(_QWORD *)&this->datagramSizesInBytes.list_size = 0; /*0x1410ffcdd*/
    p_datagramSizesInBytes->listArray = nullptr; /*0x1410ffce1*/
  }
  do /*0x1410ffcf8*/
    v38 *= 2; /*0x1410ffcf0*/
  while ( v38 < 0x80 ); /*0x1410ffcf8*/
  if ( this->datagramSizesInBytes.allocation_size < v38 ) /*0x1410ffcfd*/
  {
    this->datagramSizesInBytes.allocation_size = v38; /*0x1410ffcff*/
    v54 = (unsigned int *)operator new(size: saturated_mul((int)v38, 4u)); /*0x1410ffd22*/
    v55 = p_datagramSizesInBytes->listArray; /*0x1410ffd25*/
    if ( p_datagramSizesInBytes->listArray != nullptr ) /*0x1410ffd2b*/
    {
      v56 = 0; /*0x1410ffd2d*/
      if ( this->datagramSizesInBytes.list_size != 0 ) /*0x1410ffd34*/
      {
        do /*0x1410ffd5b*/
        {
          v54[v56] = p_datagramSizesInBytes->listArray[v56]; /*0x1410ffd51*/
          ++v56; /*0x1410ffd54*/
        }
        while ( v56 < this->datagramSizesInBytes.list_size ); /*0x1410ffd5b*/
        v55 = p_datagramSizesInBytes->listArray; /*0x1410ffd5d*/
      }
      operator delete(ptr: v55); /*0x1410ffd60*/
    }
    p_datagramSizesInBytes->listArray = v54; /*0x1410ffd65*/
  }
  DataStructures::MemoryPool<RakNet::RemoteSystemIndex>::Clear( /*0x1410ffd7c*/
    this: (DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode> *)&this->internalPacketPool,
    file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
    line: 0x34Bu);
  DataStructures::MemoryPool<RakNet::RemoteSystemIndex>::Clear( /*0x1410ffd95*/
    this: (DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode> *)&this->refCountedDataPool,
    file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
    line: 0x34Du);
  while ( 1 )
  {
    v57 = this->datagramHistory.head; /*0x1410ffda0*/
    v58 = this->datagramHistory.tail; /*0x1410ffda6*/
    v59 = v57 > v58 ? this->datagramHistory.allocation_size - v57 + v58 : v58 - v57;
    if ( v59 == 0 ) /*0x1410ffdc0*/
      break; /*0x1410ffdc0*/
    datagramNumber.val = this->datagramHistoryPopCount.val; /*0x1410ffdc8*/
    RakNet::ReliabilityLayer::RemoveFromDatagramHistory(this, (RakNet::uint24_t)&datagramNumber); /*0x1410ffdd4*/
    if ( ++this->datagramHistory.head == this->datagramHistory.allocation_size ) /*0x1410ffdeb*/
      this->datagramHistory.head = 0; /*0x1410ffded*/
    ++this->datagramHistoryPopCount.val; /*0x1410ffdf4*/
    HIBYTE(this->datagramHistoryPopCount.val) = 0; /*0x1410ffdfa*/
  }
  DataStructures::MemoryPool<RakNet::RemoteSystemIndex>::Clear( /*0x1410ffe17*/
    this: &this->datagramHistoryMessagePool,
    file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
    line: 0x362u);
  this->datagramHistoryPopCount.val = 0; /*0x1410ffe1c*/
  HIBYTE(this->datagramHistoryPopCount.val) = 0; /*0x1410ffe23*/
  this->unreliableDatagramHistoryCount = 0; /*0x1410ffe2a*/
  v61 = this->acknowlegements.ranges.orderedList.allocation_size; /*0x1410ffe31*/
  if ( v61 != 0 ) /*0x1410ffe39*/
  {
    if ( v61 > 0x200 ) /*0x1410ffe40*/
    {
      v60 = this->acknowlegements.ranges.orderedList.listArray; /*0x1410ffe42*/
      if ( v60 != nullptr ) /*0x1410ffe4c*/
      {
        __eh34_enter_wind_state(-1, 0); /*0xf1c000000000003c*/
        v62 = v60 - 1; /*0x1410ffe4e*/
        `eh vector destructor iterator'( /*0x1410ffe61*/
          ptr: v60,
          size: 8u,
          count: *(_QWORD *)&v60[-1],
          destructor: (void (__fastcall *)(void *))RBX::LSP::ILSPEditor::onSignalQuiescenceResponse);
        operator delete(ptr: v62); /*0x1410ffe74*/
        if ( __eh34_unwind(0) ) /*0xf1c0000000000030*/
unwind_state_0:
          __std_terminate(a1: v60, a2: &v65); /*0xf1c0000000000018*/
        __eh34_exit_wind_state(0, -1); /*0xf1c0000000000034*/
      }
      this->acknowlegements.ranges.orderedList.allocation_size = 0; /*0x1410ffe7a*/
      this->acknowlegements.ranges.orderedList.listArray = nullptr; /*0x1410ffe81*/
    }
    this->acknowlegements.ranges.orderedList.list_size = 0; /*0x1410ffe88*/
  }
  __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000028*/
  v63 = this->NAKs.ranges.orderedList.allocation_size; /*0x1410ffe8f*/
  if ( v63 != 0 ) /*0x1410ffe97*/
  {
    if ( v63 > 0x200 ) /*0x1410ffe9e*/
    {
      v60 = this->NAKs.ranges.orderedList.listArray; /*0x1410ffea0*/
      if ( v60 != nullptr ) /*0x1410ffeaa*/
      {
        v64 = v60 - 1; /*0x1410ffeac*/
        `eh vector destructor iterator'( /*0x1410ffebf*/
          ptr: v60,
          size: 8u,
          count: *(_QWORD *)&v60[-1],
          destructor: (void (__fastcall *)(void *))RBX::LSP::ILSPEditor::onSignalQuiescenceResponse);
        operator delete(ptr: v64); /*0x1410ffed2*/
      }
      this->NAKs.ranges.orderedList.allocation_size = 0; /*0x1410ffed8*/
      this->NAKs.ranges.orderedList.listArray = nullptr; /*0x1410ffedf*/
    }
    this->NAKs.ranges.orderedList.list_size = 0; /*0x1410ffee6*/
  }
  this->unreliableLinkedListHead = nullptr; /*0x1410ffeed*/
  if ( __eh34_unwind(0) ) /*0xf1c0000000000014*/
    goto unwind_state_0; /*0xf1c0000000000014*/
  __eh34_exit_wind_state(0, -1); /*0xf1c0000000000020*/
}

// Address: 0x1410fff20 | Name: ?GetBandwidthManagerFeedback@ReliabilityLayer@RakNet@@QEBAXAEAUBandwidthManagerFeedbackData@2@@Z
void __fastcall RakNet::ReliabilityLayer::GetBandwidthManagerFeedback(
        RakNet::ReliabilityLayer *this,
        RakNet::BandwidthManagerFeedbackData *feedbackData)
{
  RakNet::CCRakNetBase *congestionManager; // rcx
  int transmissionBandwidth; // eax
  int targetAckSpeed; // eax
  int targetRTT; // eax
  int bytesSent; // eax
  int bytesAcked; // eax
  int bytesInFlight; // eax
  RakNet::CCRakNetStats congestionStats; // [rsp+20h] [rbp-28h] BYREF

  congestionManager = this->congestionManager; /*0x1410fff2a*/
  memset(&congestionStats, 0, 25); /*0x1410fff39*/
  congestionManager->GetCongestionManagerStats(this: congestionManager, a2: &congestionStats); /*0x1410fff51*/
  transmissionBandwidth = congestionStats.transmissionBandwidth; /*0x1410fff57*/
  if ( congestionStats.transmissionBandwidth < 0 ) /*0x1410fff5d*/
    transmissionBandwidth = 0; /*0x1410fff5d*/
  feedbackData->transmissionBandwidth = transmissionBandwidth; /*0x1410fff60*/
  targetAckSpeed = congestionStats.targetAckSpeed; /*0x1410fff62*/
  if ( congestionStats.targetAckSpeed < 0 ) /*0x1410fff68*/
    targetAckSpeed = 0; /*0x1410fff68*/
  feedbackData->targetAckSpeed = targetAckSpeed; /*0x1410fff6b*/
  targetRTT = congestionStats.targetRTT; /*0x1410fff6e*/
  if ( congestionStats.targetRTT < 0 ) /*0x1410fff74*/
    targetRTT = 0; /*0x1410fff74*/
  feedbackData->targetRTT = targetRTT; /*0x1410fff77*/
  bytesSent = congestionStats.bytesSent; /*0x1410fff7a*/
  if ( congestionStats.bytesSent < 0 ) /*0x1410fff80*/
    bytesSent = 0; /*0x1410fff80*/
  feedbackData->bytesSent = bytesSent; /*0x1410fff83*/
  bytesAcked = congestionStats.bytesAcked; /*0x1410fff86*/
  if ( congestionStats.bytesAcked < 0 ) /*0x1410fff8c*/
    bytesAcked = 0; /*0x1410fff8c*/
  feedbackData->bytesAcked = bytesAcked; /*0x1410fff8f*/
  bytesInFlight = congestionStats.bytesInFlight; /*0x1410fff92*/
  if ( congestionStats.bytesInFlight < 0 ) /*0x1410fff98*/
    bytesInFlight = 0; /*0x1410fff98*/
  feedbackData->bytesInFlight = bytesInFlight; /*0x1410fff9b*/
  feedbackData->isAppLimited = congestionStats.isAppLimited; /*0x1410fffa3*/
}

// Address: 0x141100080 | Name: ?GetMaxDatagramSizeExcludingMessageHeaderBytes@ReliabilityLayer@RakNet@@AEAAII@Z
__int64 __fastcall RakNet::ReliabilityLayer::GetMaxDatagramSizeExcludingMessageHeaderBytes(
        RakNet::ReliabilityLayer *this,
        unsigned int ruppLength)
{
  bool v4; // bl
  unsigned int v5; // eax
  RBX::Security::RakPeerCrypto *Ptr; // rcx
  int v7; // r8d
  unsigned int v8; // ebp

  v4 = this->congestionManager->includeTimestampWithDatagrams(this: this->congestionManager); /*0x1411000b0*/
  v5 = this->congestionManager->GetMTU(this: this->congestionManager); /*0x1411000b6*/
  Ptr = this->rbxSessionCrypto._Ptr; /*0x1411000bd*/
  v7 = -9; /*0x1411000c4*/
  if ( v4 ) /*0x1411000cf*/
    v7 = -13; /*0x1411000cf*/
  v8 = v7 - ruppLength + v5; /*0x1411000d6*/
  if ( Ptr != nullptr && RBX::Security::SessionCrypto::getEnabledForRaknet(this: Ptr) ) /*0x1411000de*/
    v8 -= 18; /*0x1411000e7*/
  return v8; /*0x1411000ea*/
}

// Address: 0x141100110 | Name: ?GetMessageNumberNodeByDatagramNumber@ReliabilityLayer@RakNet@@AEAAPEAUMessageNumberNode@12@Uuint24_t@2@PEA_K@Z
RakNet::ReliabilityLayer::MessageNumberNode *__fastcall RakNet::ReliabilityLayer::GetMessageNumberNodeByDatagramNumber(
        RakNet::ReliabilityLayer *this,
        int *datagramNumber,
        unsigned __int64 *timeSent)
{
  unsigned int head; // r11d
  unsigned int tail; // r10d
  unsigned int val; // r9d
  int v8; // eax
  unsigned int v9; // eax
  unsigned int v10; // r10d
  unsigned int allocation_size; // ecx
  unsigned int v12; // r8d
  unsigned int v13; // r11d
  unsigned int v14; // r8d
  unsigned int v15; // ecx
  unsigned int v16; // r9d
  unsigned int v17; // r8d

  head = this->datagramHistory.head; /*0x14110011a*/
  tail = this->datagramHistory.tail; /*0x141100124*/
  if ( head == tail ) /*0x141100131*/
    return nullptr; /*0x141100131*/
  val = this->datagramHistoryPopCount.val; /*0x141100137*/
  v8 = *datagramNumber; /*0x14110013e*/
  if ( val != *datagramNumber && ((val - v8) & 0xFFFFFF) < 0x7FFFFF ) /*0x141100156*/
    return nullptr; /*0x141100156*/
  v9 = (v8 - val) & 0xFFFFFF; /*0x14110015f*/
  v10 = head > tail ? this->datagramHistory.allocation_size - head + tail : tail - head;
  if ( v9 >= v10 ) /*0x14110017d*/
    return nullptr; /*0x1411001ea*/
  allocation_size = this->datagramHistory.allocation_size; /*0x14110017f*/
  v12 = head + v9; /*0x141100185*/
  v13 = v9 + head - allocation_size; /*0x141100193*/
  if ( v12 >= allocation_size ) /*0x141100199*/
    v12 = v13; /*0x141100199*/
  *timeSent = this->datagramHistory.array[v12].timeSent; /*0x1411001a8*/
  v14 = this->datagramHistory.head; /*0x1411001ab*/
  v15 = this->datagramHistory.allocation_size; /*0x1411001b2*/
  v16 = v14 + v9; /*0x1411001bf*/
  v17 = v9 + v14 - v15; /*0x1411001c6*/
  if ( v16 >= v15 ) /*0x1411001cc*/
    v16 = v17; /*0x1411001cc*/
  return this->datagramHistory.array[v16].head; /*0x1411001da*/
}

// Address: 0x141100200 | Name: ?GetNextWeight@ReliabilityLayer@RakNet@@AEAA_KH@Z
RBX::Security::RakPeerCrypto *__fastcall RakNet::ReliabilityLayer::GetNextWeight(
        RakNet::ReliabilityLayer *this,
        int priorityLevel)
{
  __int64 v3; // rbx
  RBX::Security::RakPeerCrypto **v4; // rdi
  unsigned __int64 v5; // r10
  unsigned __int64 v6; // rdx
  RBX::Security::RakPeerCrypto *result; // rax

  v3 = priorityLevel; /*0x141100214*/
  v4 = &this->rbxSessionCrypto._Ptr + priorityLevel; /*0x141100217*/
  v5 = (unsigned __int64)v4[45]; /*0x14110021b*/
  if ( this->outgoingPacketBuffer.heap.list_size != 0 ) /*0x141100222*/
  {
    v6 = this->outgoingPacketBuffer.heap.listArray->weight /*0x141100244*/
       + (int)this->outgoingPacketBuffer.heap.listArray->data->priority
       - (__int64)(int)(this->outgoingPacketBuffer.heap.listArray->data->priority << this->outgoingPacketBuffer.heap.listArray->data->priority);
    if ( v5 < v6 ) /*0x14110024a*/
      v5 = v6 + v3 + (priorityLevel << priorityLevel); /*0x14110025a*/
    v4[45] = (RBX::Security::RakPeerCrypto *)(v5 + v3 + ((priorityLevel + 1) << priorityLevel)); /*0x141100272*/
    return (RBX::Security::RakPeerCrypto *)v5; /*0x141100266*/
  }
  else
  {
    result = v4[45]; /*0x141100289*/
    this->outgoingPacketBufferNextWeights[0] = 0; /*0x141100291*/
    this->outgoingPacketBufferNextWeights[1] = 3; /*0x14110029c*/
    this->outgoingPacketBufferNextWeights[2] = 10; /*0x1411002a7*/
    this->outgoingPacketBufferNextWeights[3] = 27; /*0x1411002b2*/
  }
  return result; /*0x141100279*/
}

// Address: 0x1411002c0 | Name: ?GetStatistics@ReliabilityLayer@RakNet@@QEAAPEAURakNetStatistics@2@PEAU32@@Z
RakNet::RakNetStatistics *__fastcall RakNet::ReliabilityLayer::GetStatistics(
        RakNet::ReliabilityLayer *this,
        RakNet::RakNetStatistics *rns)
{
  unsigned __int64 *runningTotal; // r8
  __int64 v5; // rcx
  RakNet::BPSTracker *bpsMetrics; // r9
  __int64 v7; // rbp
  _Mtx_internal_imp_t *p_dataQueueMutex; // rsi
  int v9; // eax
  unsigned __int64 v10; // rbx
  unsigned __int64 v11; // rdi
  RakNet::RakNetStatistics *v12; // rax
  RakNet::RakNetStatistics *p_statistics; // rcx
  __int64 i; // rdx
  __int128 v15; // xmm0
  __int64 v16; // rcx
  __int64 v17; // rdx
  double v18; // xmm0_8
  unsigned __int64 v19; // rax
  double v20; // xmm1_8
  float v21; // xmm2_4
  __int64 v22; // r8
  __int64 v23; // rcx
  double v24; // xmm2_8
  double v25; // xmm1_8
  unsigned __int64 v26; // rax
  double v27; // xmm1_8

  if ( FFlag::FixBPSTracker.value || (RakNet::GetTimeUS(isNetworkSynced: false), FFlag::FixBPSTracker.value) ) /*0x1411002f5*/
  {
    v7 = 0; /*0x141100334*/
    p_dataQueueMutex = (_Mtx_internal_imp_t *)&this->bpsMetrics[0].dataQueueMutex; /*0x141100336*/
    do /*0x14110037c*/
    {
      v9 = Mtx_lock_0(a1: p_dataQueueMutex); /*0x141100343*/
      if ( v9 != 0 ) /*0x14110034a*/
      {
        std::_Throw_C_error(a1: v9); /*0x141100530*/
        JUMPOUT(0x141100535LL); /*0x141100535*/
      }
      v10 = *((_QWORD *)p_dataQueueMutex - 1); /*0x141100350*/
      v11 = *((_QWORD *)p_dataQueueMutex - 2); /*0x141100357*/
      Mtx_unlock_0(a1: p_dataQueueMutex); /*0x14110035b*/
      this->statistics.valueOverLastSecond[v7] = v10; /*0x141100360*/
      p_dataQueueMutex = (_Mtx_internal_imp_t *)((char *)p_dataQueueMutex + 136); /*0x141100368*/
      this->statistics.runningTotal[v7] = v11; /*0x14110036f*/
      v7 = (unsigned int)(v7 + 1); /*0x141100377*/
    }
    while ( (unsigned int)v7 < 7 ); /*0x14110037c*/
  }
  else
  {
    runningTotal = this->statistics.runningTotal; /*0x1411002f7*/
    v5 = 7; /*0x1411002fe*/
    bpsMetrics = this->bpsMetrics; /*0x141100303*/
    do /*0x141100330*/
    {
      *(runningTotal - 7) = bpsMetrics->lastSec1._Storage._Value; /*0x141100315*/
      *runningTotal++ = bpsMetrics->total1._Storage._Value; /*0x141100321*/
      ++bpsMetrics; /*0x141100325*/
      --v5; /*0x14110032c*/
    }
    while ( v5 != 0 ); /*0x141100330*/
  }
  v12 = rns; /*0x14110037e*/
  p_statistics = &this->statistics; /*0x141100381*/
  for ( i = 3; i != 0; --i ) /*0x141100388*/
  {
    v12 = (RakNet::RakNetStatistics *)((char *)v12 + 128); /*0x141100390*/
    v15 = *(_OWORD *)p_statistics->valueOverLastSecond; /*0x141100397*/
    p_statistics = (RakNet::RakNetStatistics *)((char *)p_statistics + 128); /*0x14110039a*/
    *(_OWORD *)&v12[-1].ds.totalJoinDataNakSize_DEPRECATED = v15; /*0x1411003a1*/
    *(_OWORD *)&v12[-1].perSecTxBw_deprecated.reliablePacketBytes = *(_OWORD *)&p_statistics[-1].perSecTxBw_deprecated.reliablePacketBytes; /*0x1411003a9*/
    *(_OWORD *)&v12[-1].perSecTxBw_deprecated.unreliablePacketBytes = *(_OWORD *)&p_statistics[-1].perSecTxBw_deprecated.unreliablePacketBytes; /*0x1411003b1*/
    *(_OWORD *)&v12[-1].perSecTxBwData.allBytes = *(_OWORD *)&p_statistics[-1].perSecTxBwData.allBytes; /*0x1411003b9*/
    *(_OWORD *)&v12[-1].perSecTxBwData.reliablePacketsRe = *(_OWORD *)&p_statistics[-1].perSecTxBwData.reliablePacketsRe; /*0x1411003c1*/
    *(_OWORD *)&v12[-1].perSecTxBwData.txBwInfluencers.bwLimitedByAppCount = *(_OWORD *)&p_statistics[-1].perSecTxBwData.txBwInfluencers.bwLimitedByAppCount; /*0x1411003c9*/
    *(_OWORD *)&v12[-1].perSecTxBwData.txBwInfluencers.bytesGivenByTargetSpeed = *(_OWORD *)&p_statistics[-1].perSecTxBwData.txBwInfluencers.bytesGivenByTargetSpeed; /*0x1411003d1*/
    *(_OWORD *)&v12[-1].perSecTxBwData.txBwInfluencers.bwCappedDueToMaxPacketsInFlightCount = *(_OWORD *)&p_statistics[-1].perSecTxBwData.txBwInfluencers.bwCappedDueToMaxPacketsInFlightCount; /*0x1411003d9*/
  }
  *(_OWORD *)v12->valueOverLastSecond = *(_OWORD *)p_statistics->valueOverLastSecond; /*0x1411003e6*/
  *(_OWORD *)&v12->valueOverLastSecond[2] = *(_OWORD *)&p_statistics->valueOverLastSecond[2]; /*0x1411003ed*/
  *(_OWORD *)&v12->valueOverLastSecond[4] = *(_OWORD *)&p_statistics->valueOverLastSecond[4]; /*0x1411003f5*/
  *(_OWORD *)&v12->valueOverLastSecond[6] = *(_OWORD *)&p_statistics->valueOverLastSecond[6]; /*0x1411003fd*/
  v16 = rns->valueOverLastSecond[2]; /*0x141100401*/
  v17 = rns->valueOverLastSecond[1]; /*0x141100405*/
  if ( v17 + v16 != 0 ) /*0x141100410*/
  {
    if ( v16 < 0 ) /*0x141100418*/
    {
      v19 = rns->valueOverLastSecond[2] & 1 | (rns->valueOverLastSecond[2] >> 1); /*0x14110042a*/
      v18 = (double)(int)v19 + (double)(int)v19; /*0x141100432*/
    }
    else
    {
      v18 = (double)(int)v16; /*0x14110041a*/
    }
    if ( v17 < 0 ) /*0x14110043c*/
      v20 = (double)(int)(v17 & 1 | ((unsigned __int64)v17 >> 1)) /*0x141100466*/
          + (double)(int)(v17 & 1 | ((unsigned __int64)v17 >> 1))
          + v18;
    else
      v20 = (double)(int)v17 + v18; /*0x141100443*/
    v21 = v18 / v20; /*0x14110044b*/
  }
  else
  {
    v21 = 0.0; /*0x141100474*/
  }
  rns->packetlossLastSecond = v21; /*0x141100477*/
  v22 = rns->runningTotal[2]; /*0x141100480*/
  rns->packetlossTotal = 0.0; /*0x141100484*/
  v23 = rns->runningTotal[1]; /*0x14110048f*/
  if ( v23 + v22 != 0 && v23 / (unsigned __int64)(v23 + v22) != 0 ) /*0x1411004a7*/
  {
    if ( v22 < 0 ) /*0x1411004af*/
      v24 = (double)(int)(v22 & 1 | ((unsigned __int64)v22 >> 1)) /*0x1411004ca*/
          + (double)(int)(v22 & 1 | ((unsigned __int64)v22 >> 1));
    else
      v24 = (double)(int)v22; /*0x1411004b1*/
    if ( v23 < 0 ) /*0x1411004d4*/
    {
      v26 = rns->runningTotal[1] & 1 | (rns->runningTotal[1] >> 1); /*0x1411004e6*/
      v25 = (double)(int)v26 + (double)(int)v26; /*0x1411004ee*/
    }
    else
    {
      v25 = (double)(int)v23; /*0x1411004d6*/
    }
    v27 = v25 + v24; /*0x1411004f2*/
    if ( v27 != 0.0 ) /*0x1411004ff*/
      rns->packetlossTotal = v24 / v27; /*0x141100509*/
  }
  return rns; /*0x141100512*/
}

// Address: 0x141100540 | Name: ?GetTimeoutTime@ReliabilityLayer@RakNet@@QEAAIXZ
__int64 __fastcall RakNet::ReliabilityLayer::GetTimeoutTime(RakNet::ReliabilityLayer *this)
{
  return this->timeoutTime; /*0x141100546*/
}

// Address: 0x141100550 | Name: ?HandleSendFailure@ReliabilityLayer@RakNet@@QEAAXH@Z
void __fastcall RakNet::ReliabilityLayer::HandleSendFailure(RakNet::ReliabilityLayer *this, int sendResult)
{
  if ( sendResult == 2 ) /*0x14110055c*/
  {
    if ( DFFlag::RakNetDetectNetUnreachable.value ) /*0x141100565*/
    {
      if ( DFLog::NetworkTrace != 0 ) /*0x141100570*/
        FLog::FastLog( /*0x14110057c*/
          level: DFLog::NetworkTrace,
          message: "[DFLog::NetworkTrace] Could not send data to server/client, network/host unreachable!",
          arg0: nullptr);
      this->deadConnection = true; /*0x141100581*/
    }
  }
  else if ( sendResult == 1 && DFLog::NetworkTrace != 0 ) /*0x14110059c*/
  {
    FLog::FastLog( /*0x1411005ad*/
      level: DFLog::NetworkTrace,
      message: "[DFLog::NetworkTrace] Could not send data, poor connection?",
      arg0: nullptr);
  }
}

// Address: 0x1411005c0 | Name: ?HandleSocketReceiveFromConnectedPlayer@ReliabilityLayer@RakNet@@QEAA_NPEBDIAEBUSystemAddress@2@HV?$shared_ptr@URakNetSocket@RakNet@@@std@@_KAEAVBitStream@2@_NAEBV?$shared_ptr@VRupp@1Network@RBX@@@5@1@Z
// local variable allocation has failed, the output may be wrong!
bool __fastcall RakNet::ReliabilityLayer::HandleSocketReceiveFromConnectedPlayer(
        RakNet::ReliabilityLayer *this,
        char *buffer,
        unsigned int length,
        RakNet::SystemAddress *systemAddress,
        int MTUSize,
        std::shared_ptr<RBX::File> *socket,
        unsigned __int64 timeRead,
        RakNet::BitStream *updateBitStream,
        RakNet::uint24_t recordJoinDataRxStats,
        const std::shared_ptr<RBX::Network::Rupp::Rupp> *ruppHeader,
        const RakNet::SystemAddress *udmuxAddress)
{
  unsigned __int64 v11; // r12
  unsigned __int64 v14; // r14
  char val; // r13
  unsigned int v16; // r12d
  bool readResentBit; // di
  bool v18; // bl
  bool v19; // si
  bool v20; // al
  unsigned __int64 commonCapabilities; // r8
  unsigned __int64 v22; // rcx
  RakNet::InternalPacket *v23; // rbx
  double v24; // xmm0_8
  unsigned __int64 v25; // rax
  DataStructures::RangeList<RakNet::uint24_t> *p_incomingAcks; // rbx
  unsigned int v27; // edi
  unsigned int listArray_high; // esi
  unsigned int v29; // eax
  RBX::File *Ptr; // r13
  DataStructures::RangeNode<RakNet::uint24_t> *listArray; // rdx
  unsigned int v32; // ebx
  RakNet::InternalPacket *p_userMemory; // rdi
  unsigned int v34; // r12d
  DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *v35; // r14
  unsigned __int8 *v36; // rax
  unsigned int list_size; // edx
  __int64 v38; // rcx
  unsigned int v39; // r8d
  RakNet::ReliabilityLayer::UnreliableWithAckReceiptNode *v40; // rax
  RakNet::ReliabilityLayer::UnreliableWithAckReceiptNode *v41; // rdx
  RakNet::ReliabilityLayer::UnreliableWithAckReceiptNode *v42; // rcx
  RakNet::ReliabilityLayer::MessageNumberNode *MessageNumberNodeByDatagramNumber; // r14
  unsigned __int64 v44; // r12
  unsigned __int64 v45; // r8
  RakNet::CCRakNetBase *congestionManager; // rcx
  void (__fastcall *OnAck)(RakNet::CCRakNetBase *, unsigned __int64, unsigned __int64, bool, long double, long double, long double, bool, RakNet::uint24_t); // r10
  long double totalUserDataBytesAcked; // xmm0_8
  unsigned __int64 v49; // r12
  RakNet::SystemAddress *v50; // r13
  char *v51; // rdi
  int sourceSystemTime_high; // eax
  void *v53; // rbx
  __int64 v54; // rcx
  char *v55; // r13
  __int64 v56; // rax
  unsigned int v57; // ebx
  RakNet::CCRakNetBase *v58; // rcx
  RakNet::CCRakNetBase_vtbl *v59; // rax
  RakNet::ReliabilityLayer::MessageNumberNode *v60; // r14
  unsigned __int64 v61; // r13
  unsigned int v62; // eax
  RakNet::InternalPacket **Myfirst; // rdi
  __int64 v64; // rcx
  __int64 v65; // rdx
  RakNet::InternalPacket *v66; // rdi
  __int64 v67; // rsi
  unsigned __int64 v68; // rcx
  double v69; // xmm0_8
  unsigned __int64 v70; // rax
  int v71; // eax
  int v72; // eax
  RakNet::CCRakNetBase *v73; // rcx
  bool (__fastcall *OnGotPacket)(RakNet::CCRakNetBase *, RakNet::uint24_t, bool, unsigned __int64, unsigned int, unsigned int *); // r10
  int i; // ebx
  DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *InternalPacketFromBitStream; // r12
  PacketReliability reliability; // ecx
  unsigned int v78; // r9d
  unsigned int v79; // r9d
  unsigned int v80; // ebx
  unsigned int v81; // edx
  unsigned int v82; // ecx
  unsigned int v83; // r8d
  unsigned int v84; // ecx
  unsigned int v85; // eax
  unsigned int head; // ecx
  unsigned int tail; // edx
  unsigned int v88; // edx
  unsigned int v89; // r11d
  unsigned int v90; // r9d
  bool *array; // r10
  unsigned int v92; // edx
  bool *v93; // r8
  unsigned int allocation_size; // ecx
  unsigned int v95; // edx
  __int64 v96; // r8
  unsigned int v97; // eax
  bool *v98; // rax
  unsigned int v99; // eax
  bool *v100; // rdi
  unsigned int j; // r9d
  bool *v102; // rax
  unsigned int v103; // eax
  unsigned int v104; // ecx
  bool *v105; // rbx
  unsigned int v106; // r9d
  unsigned int v107; // eax
  __int64 v108; // rdx
  unsigned int v109; // ecx
  int v110; // ecx
  unsigned int v111; // eax
  unsigned int v112; // r9d
  unsigned int v113; // r8d
  unsigned int v114; // ecx
  unsigned int v115; // eax
  DataStructures::Queue<bool> *p_hasReceivedPacketQueue; // rsi
  unsigned int v117; // ebx
  unsigned int v118; // eax
  bool *v119; // r14
  __int64 k; // rdi
  unsigned int v121; // ecx
  unsigned int v122; // eax
  unsigned int v123; // eax
  PacketReliability v124; // ecx
  unsigned int v125; // ebx
  std::shared_ptr<RBX::File> *v126; // rax
  std::_Ref_count_base *v127; // rcx
  RakNet::InternalPacket *v128; // rax
  RakNet::RakPeer *rakPeer; // rdx
  int *p_maxBytesIncompleteDatagrams; // rax
  _WORD *v131; // rax
  char *v132; // rcx
  unsigned int v133; // eax
  unsigned int v134; // ecx
  PacketReliability v135; // edx
  __int64 orderingChannel; // r9
  unsigned int v137; // r8d
  unsigned int v138; // ecx
  __int64 v139; // rax
  __int64 v140; // rcx
  __int64 v141; // r8
  DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0> *v142; // rcx
  RakNet::InternalPacket *v143; // rbx
  __int64 v144; // rax
  unsigned int v145; // edx
  unsigned int v146; // ecx
  unsigned __int64 v147; // rbx
  PacketReliability v148; // eax
  unsigned __int64 v149; // rbx
  DataStructures::List<DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::HeapNode> *v150; // rdi
  unsigned int v151; // esi
  unsigned int v152; // ecx
  DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::HeapNode *v153; // r8
  DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::HeapNode v154; // xmm1
  bool result; // al
  std::_Ref_count_base *Rep; // rbx
  __int64 v157; // [rsp+8h] [rbp-100h] BYREF
  __int64 v158; // [rsp+40h] [rbp-C8h]
  RakNet::InternalPacket *internalPacket; // [rsp+58h] [rbp-B0h] BYREF
  DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *skippedMessageCount; // [rsp+60h] [rbp-A8h] OVERLAPPED BYREF
  DataStructures::RangeList<RakNet::uint24_t> incomingNAKs; // [rsp+68h] [rbp-A0h] BYREF
  RakNet::DatagramHeaderFormat dhf; // [rsp+78h] [rbp-90h] BYREF
  unsigned __int16 v163; // [rsp+98h] [rbp-70h]
  __int16 v164; // [rsp+9Ah] [rbp-6Eh]
  unsigned __int64 v165; // [rsp+A0h] [rbp-68h]
  std::shared_ptr<RBX::File> v166; // [rsp+A8h] [rbp-60h] BYREF
  std::shared_ptr<RBX::File> *v167; // [rsp+B8h] [rbp-50h]
  RBX::MutableArrayView<unsigned char> input; // [rsp+C8h] [rbp-40h] BYREF
  RBX::Graphics::ProfilerAdorn::Item counterName; // [rsp+D8h] [rbp-30h] BYREF
  int v170; // [rsp+118h] [rbp+10h]
  char systemAddressString[1040]; // [rsp+230h] [rbp+128h] BYREF
  RakNet::uint24_t newestUnsentAck; // [rsp+698h] [rbp+590h] BYREF
  unsigned int v173; // [rsp+6A8h] [rbp+5A0h]
  RakNet::SystemAddress *v174; // [rsp+6B0h] [rbp+5A8h]

  v174 = systemAddress; /*0x1411005c7*/
  __eh34_enter_wind_state(-1, 0); /*0xf1c00000000000f0*/
  v11 = length; /*0x1411005eb*/
  v14 = timeRead; /*0x1411005f4*/
  v165 = timeRead; /*0x1411005fb*/
  if ( DFLog::NetworkTrace != 0 ) /*0x141100606*/
    RakNet::SystemAddress::ToStringN( /*0x14110061f*/
      this: systemAddress,
      writePort: true,
      dest: &systemAddressString[8],
      size: 1025,
      portDelineator: 124);
  this->statistics.ds.totalBytesReceived += v11; /*0x141100627*/
  RakNet::BPSTracker::Push1(this: &this->bpsMetrics[6], time: v14, value1: v11); /*0x14110063b*/
  val = recordJoinDataRxStats.val; /*0x141100640*/
  if ( LOBYTE(recordJoinDataRxStats.val) != 0 ) /*0x14110064b*/
  {
    this->joinRxStats.totalRxBytes += v11; /*0x14110064d*/
    ++this->joinRxStats.totalRxPackets; /*0x141100654*/
  }
  if ( (unsigned int)v11 <= 2 || buffer == nullptr )
  {
    if ( DFLog::NetworkTrace != 0 )
      FLog::FastLogFormatted(
        level: DFLog::NetworkTrace,
        message: "[DFLog::NetworkTrace] Incoming packet error: length <= 2 || buffer == 0, length=%d, address=%s",
        8 * v11,
        &systemAddressString[8]);
    if ( __eh34_unwind(0) ) /*0xf1c0000000000034*/
    {
unwind_state_0:
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: socket); /*0xf1c0000000000018*/
      __eh34_propagate_exception_into_caller(0, -1); /*0xf1c000000000001c*/
    }
    __eh34_exit_wind_state(0, -1); /*0xf1c0000000000038*/
    Rep = socket->_Rep; /*0x141101f18*/
    if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x141101f30*/
    {
      Rep->_Destroy(this: Rep); /*0x141101f38*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141101f42*/
        Rep->_Delete_this(this: Rep); /*0x141101f4a*/
    }
    return true; /*0x141101f4a*/
  }
  this->timeLastDatagramArrived = RakNet::GetTimeMS(); /*0x141100673*/
  if ( this->rbxSessionCrypto._Ptr != nullptr
    && RBX::Security::SessionCrypto::getEnabledForRaknet(this: this->rbxSessionCrypto._Ptr) )
  {
    input.buffer = (const unsigned __int8 *)buffer; /*0x141100693*/
    input.length = v11; /*0x141100697*/
    if ( RBX::Security::SessionCrypto::decryptRakDataInPlace(this: this->rbxSessionCrypto._Ptr, boxToMessage: &input) )
    {
      v16 = v11 - 18; /*0x1411006af*/
      v173 = v16; /*0x1411006b3*/
      RakNet::BitStream::BitStream( /*0x1411006c7*/
        this: (RakNet::BitStream *)&counterName.color,
        _data: (unsigned __int8 *)buffer,
        lengthInBytes: v16,
        _copyData: false);
      __eh34_enter_wind_state(0, 1); /*0xf1c00000000000e8*/
      v164 = 0; /*0x1411006cd*/
      readResentBit = (this->commonCapabilities & 0x800000) != 0; /*0x1411006e1*/
      v18 = (this->commonCapabilities & 0x200000) != 0; /*0x1411006ec*/
      v19 = (this->commonCapabilities & 0x8000) != 0; /*0x1411006f3*/
      v20 = this->congestionManager->includeTimestampWithDatagrams(this: this->congestionManager); /*0x141100701*/
      RakNet::DatagramHeaderFormat::Deserialize( /*0x141100721*/
        this: (RakNet::DatagramHeaderFormat *)&dhf.datagramNumber,
        b: (RakNet::BitStream *)&counterName.color,
        includeTimestamp: v20,
        avoidPacketSizeCapable: v19,
        readJoinDataBit: v18,
        readResentBit);
      commonCapabilities = this->commonCapabilities; /*0x141100726*/
      if ( (commonCapabilities & 0x200000) != 0 && (_BYTE)v164 != 0 ) /*0x141100738*/
      {
        v22 = v14 / 0x3E8; /*0x141100753*/
        if ( this->raknetJoinRxStats.timeFirstJoinPacketReceivedMs == 0 ) /*0x14110075f*/
          this->raknetJoinRxStats.timeFirstJoinPacketReceivedMs = v22; /*0x141100761*/
        this->raknetJoinRxStats.timeLastJoinPacketReceivedMs = v22; /*0x141100768*/
        this->raknetJoinRxStats.bytes += v16; /*0x14110076f*/
        ++this->raknetJoinRxStats.packets; /*0x141100776*/
        if ( (commonCapabilities & 0x800000) != 0 ) /*0x141100782*/
        {
          if ( HIBYTE(v164) != 0 ) /*0x141100788*/
          {
            this->raknetJoinRxStats.reBytes += v16; /*0x14110078a*/
            ++this->raknetJoinRxStats.rePackets; /*0x141100791*/
          }
          else
          {
            this->raknetJoinRxStats.timeLastNonReTxJoinPacketReceivedMs = v22; /*0x14110079a*/
          }
        }
      }
      if ( (commonCapabilities & 0x8000) != 0 ) /*0x1411007a6*/
      {
        RakNet::BitStream::SetWriteOffset( /*0x1411007bb*/
          this: (RakNet::BitStream *)&counterName.color,
          offset: v170 - 8 * v163,
          eraseDataToCurrentOffset: false);
        v16 -= v163; /*0x1411007c4*/
        v173 = v16; /*0x1411007c7*/
      }
      if ( !*(&dhf.isResentData + 2) )
      {
        if ( DFLog::NetworkTrace != 0 )
          FLog::FastLogFormatted(
            level: DFLog::NetworkTrace,
            message: "[DFLog::NetworkTrace] Incoming packet error: dhf.isValid==false, length=%d, address=%s",
            8 * v16,
            &systemAddressString[8]);
        if ( __eh34_unwind(1) ) /*0xf1c00000000000dc*/
          goto unwind_state_1; /*0xf1c00000000000dc*/
        __eh34_exit_wind_state(1, 0); /*0xf1c00000000000e0*/
        RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)&counterName.color); /*0x141100801*/
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: socket); /*0x14110080e*/
        goto LABEL_324; /*0x141100813*/
      }
      v167 = socket; /*0x14110081f*/
      if ( LOBYTE(dhf.extraPadding) != 0 )
      {
        skippedMessageCount = nullptr; /*0x141100830*/
        if ( this->congestionManager->includeTimestampWithDatagrams(this: this->congestionManager) ) /*0x14110083f*/
        {
          v23 = (RakNet::InternalPacket *)((unsigned int)v14 - *(_QWORD *)&dhf.datagramNumber.val); /*0x14110084c*/
          skippedMessageCount = (DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *)v23; /*0x141100851*/
          if ( (unsigned __int64)v23 > 0x989680 ) /*0x14110085d*/
          {
            v24 = this->congestionManager->GetRTT(this: this->congestionManager); /*0x141100869*/
            v25 = 0; /*0x14110086f*/
            if ( v24 >= 9.223372036854776e18 ) /*0x14110087d*/
            {
              v24 = v24 - 9.223372036854776e18; /*0x14110087f*/
              if ( v24 < 9.223372036854776e18 ) /*0x141100887*/
              {
                v25 = 0x8000000000000000uLL; /*0x141100893*/
                v16 = v173; /*0x141100896*/
              }
            }
            v23 = (RakNet::InternalPacket *)(v25 + (unsigned int)(int)v24); /*0x1411008a2*/
            skippedMessageCount = (DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *)v23; /*0x1411008a5*/
          }
          this->ackPing = (unsigned __int64)v23; /*0x1411008aa*/
        }
        p_incomingAcks = &this->incomingAcks; /*0x1411008b1*/
        DataStructures::RangeList<RakNet::uint24_t>::Clear(this: &this->incomingAcks); /*0x1411008bb*/
        if ( DataStructures::RangeList<RakNet::uint24_t>::Deserialize(
               this: &this->incomingAcks,
               out: (RakNet::BitStream *)&counterName.color) == 0 )
        {
          if ( DFLog::NetworkTrace != 0 )
            FLog::FastLogFormatted(
              level: DFLog::NetworkTrace,
              message: "[DFLog::NetworkTrace] Incoming packet error: incomingAcks.Deserialize failed, length=%d, address=%s",
              8 * v16,
              &systemAddressString[8]);
          goto LABEL_335; /*0x1411008fc*/
        }
        v27 = 0; /*0x141100901*/
        incomingNAKs.ranges.orderedList.listArray = nullptr; /*0x141100904*/
        recordJoinDataRxStats.val = 0; /*0x141100909*/
        listArray_high = 0; /*0x141100910*/
        newestUnsentAck.val = 0; /*0x141100918*/
        if ( *(&dhf.isResentData + 3) ) /*0x141100923*/
        {
          RakNet::BitStream::Read<RakNet::uint24_t>( /*0x141100930*/
            this: (RakNet::BitStream *)&counterName.color,
            outTemplateVar: &recordJoinDataRxStats);
          RakNet::BitStream::Read<RakNet::uint24_t>( /*0x141100940*/
            this: (RakNet::BitStream *)&counterName.color,
            outTemplateVar: &newestUnsentAck);
          v27 = recordJoinDataRxStats.val; /*0x141100945*/
          incomingNAKs.ranges.orderedList.listArray = (DataStructures::RangeNode<RakNet::uint24_t> *)__PAIR64__(newestUnsentAck.val, recordJoinDataRxStats.val); /*0x14110094b*/
          listArray_high = newestUnsentAck.val; /*0x14110094f*/
        }
        v29 = 0; /*0x141100959*/
        newestUnsentAck.val = 0; /*0x14110095c*/
        if ( this->incomingAcks.ranges.orderedList.list_size != 0 )
        {
          while ( 1 )
          {
            Ptr = (RBX::File *)v29; /*0x141100972*/
            v166._Ptr = (RBX::File *)v29; /*0x141100975*/
            listArray = p_incomingAcks->ranges.orderedList.listArray; /*0x141100979*/
            v32 = p_incomingAcks->ranges.orderedList.listArray[v29].minIndex.val; /*0x14110097c*/
            if ( listArray[v29].maxIndex.val == 0xFFFFFF || v32 > listArray[v29].maxIndex.val ) /*0x141100985*/
              break; /*0x141100996*/
            p_userMemory = &skippedMessageCount->userMemory; /*0x14110099c*/
            do
            {
              if ( v32 > listArray[(_QWORD)Ptr].maxIndex.val ) /*0x1411009a8*/
                break; /*0x1411009a8*/
              *(_QWORD *)&incomingNAKs.ranges.orderedList.list_size = 0; /*0x1411009ae*/
              if ( this->unreliableWithAckReceiptHistory.list_size != 0 ) /*0x1411009ba*/
              {
                v34 = 0; /*0x1411009c0*/
                do /*0x141100aa6*/
                {
                  if ( this->unreliableWithAckReceiptHistory.listArray[v34].datagramNumber.val == v32 ) /*0x1411009d4*/
                  {
                    v35 = RakNet::ReliabilityLayer::AllocateFromInternalPacketPool(this); /*0x1411009e2*/
                    input.buffer = (const unsigned __int8 *)v35; /*0x1411009e5*/
                    v35->userMemory.allocationScheme = 0; /*0x1411009e9*/
                    v36 = (unsigned __int8 *)RBX::Memory::allocate(size: 5u); /*0x1411009f1*/
                    v35->userMemory.data = v36; /*0x1411009f6*/
                    v35->userMemory.dataBitLength = 40; /*0x1411009fa*/
                    *v36 = 14; /*0x141100a02*/
                    *(_DWORD *)(v35->userMemory.data + 1) = this->unreliableWithAckReceiptHistory.listArray[v34].sendReceiptSerial; /*0x141100a15*/
                    DataStructures::Queue<RakNet::RakPeer::RequestedConnectionStruct *>::Push( /*0x141100a2d*/
                      this: &this->outputQueue,
                      (RakNet::InternalPacket **)&input,
                      file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
                      line: 0x464u);
                    list_size = this->unreliableWithAckReceiptHistory.list_size; /*0x141100a32*/
                    if ( v34 < list_size ) /*0x141100a3c*/
                    {
                      v38 = v34; /*0x141100a3e*/
                      if ( v34 < list_size - 1 ) /*0x141100a47*/
                      {
                        do /*0x141100a8e*/
                        {
                          v39 = v38 + 1; /*0x141100a50*/
                          v40 = this->unreliableWithAckReceiptHistory.listArray; /*0x141100a54*/
                          v41 = &v40[(unsigned int)(v38 + 1)]; /*0x141100a62*/
                          v42 = &v40[v38]; /*0x141100a69*/
                          v42->datagramNumber.val = v41->datagramNumber.val; /*0x141100a6e*/
                          v42->sendReceiptSerial = v41->sendReceiptSerial; /*0x141100a73*/
                          v42->nextActionTime = v41->nextActionTime; /*0x141100a7a*/
                          v38 = v39; /*0x141100a7e*/
                          list_size = this->unreliableWithAckReceiptHistory.list_size; /*0x141100a81*/
                        }
                        while ( v39 < list_size - 1 ); /*0x141100a8e*/
                      }
                      this->unreliableWithAckReceiptHistory.list_size = list_size - 1; /*0x141100a93*/
                    }
                  }
                  else
                  {
                    ++v34; /*0x141100a9c*/
                  }
                }
                while ( v34 < this->unreliableWithAckReceiptHistory.list_size ); /*0x141100aa6*/
                Ptr = v166._Ptr; /*0x141100aac*/
              }
              recordJoinDataRxStats.val = v32; /*0x141100ab0*/
              MessageNumberNodeByDatagramNumber = RakNet::ReliabilityLayer::GetMessageNumberNodeByDatagramNumber( /*0x141100aca*/
                                                    this,
                                                    datagramNumber: (int *)&recordJoinDataRxStats,
                                                    timeSent: (unsigned __int64 *)&incomingNAKs.ranges.orderedList.list_size);
              v44 = *(_QWORD *)&incomingNAKs.ranges.orderedList.list_size; /*0x141100acd*/
              if ( MessageNumberNodeByDatagramNumber != nullptr
                || *(_QWORD *)&incomingNAKs.ranges.orderedList.list_size != 0 )
              {
                if ( this->congestionManager->includeTimestampWithDatagrams(this: this->congestionManager) )
                  v45 = (unsigned __int64)p_userMemory; /*0x141100af4*/
                else
                  v45 = v165 <= v44 ? 0LL : v165 - v44;
                congestionManager = this->congestionManager; /*0x141100b0d*/
                OnAck = congestionManager->OnAck; /*0x141100b17*/
                LODWORD(internalPacket) = v32; /*0x141100b1b*/
                totalUserDataBytesAcked = this->totalUserDataBytesAcked; /*0x141100b27*/
                LOBYTE(v158) = this->bandwidthExceededStatistic; /*0x141100b42*/
                v49 = v165; /*0x141100b5d*/
                ((void (__fastcall *)(RakNet::CCRakNetBase *, unsigned __int64, unsigned __int64, bool, _QWORD, _QWORD, _QWORD, _DWORD, RakNet::InternalPacket **))OnAck)( /*0x141100b64*/
                  a1: congestionManager,
                  a2: v165,
                  a3: v45,
                  a4: dhf.isJoinData,
                  a5: 0,
                  a6: *(float *)&dhf.needsBAndAs,
                  a7: *(_QWORD *)&totalUserDataBytesAcked,
                  a8: v158,
                  a9: &internalPacket);
                if ( MessageNumberNodeByDatagramNumber != nullptr ) /*0x141100b6a*/
                {
                  v50 = v174; /*0x141100b6c*/
                  do /*0x141100ba5*/
                  {
                    recordJoinDataRxStats.val = MessageNumberNodeByDatagramNumber->messageNumber.val; /*0x141100b83*/
                    RakNet::ReliabilityLayer::RemovePacketFromResendListAndDeleteOlderReliableSequenced( /*0x141100b99*/
                      this,
                      messageNumber: (const RakNet::uint24_t)&recordJoinDataRxStats,
                      time: v49,
                      systemAddress: v50);
                    MessageNumberNodeByDatagramNumber = MessageNumberNodeByDatagramNumber->next; /*0x141100b9e*/
                  }
                  while ( MessageNumberNodeByDatagramNumber != nullptr ); /*0x141100ba5*/
                  recordJoinDataRxStats.val = v32; /*0x141100ba7*/
                  RakNet::ReliabilityLayer::RemoveFromDatagramHistory( /*0x141100bb7*/
                    this,
                    datagramNumber: (RakNet::uint24_t)&recordJoinDataRxStats);
                  Ptr = v166._Ptr; /*0x141100bbc*/
                }
              }
              v32 = (v32 + 1) & 0xFFFFFF; /*0x141100bc2*/
              listArray = this->incomingAcks.ranges.orderedList.listArray; /*0x141100bc8*/
            }
            while ( v32 >= listArray[(_QWORD)Ptr].minIndex.val );
            v29 = newestUnsentAck.val + 1; /*0x141100bdf*/
            newestUnsentAck.val = v29; /*0x141100be1*/
            v27 = (unsigned int)incomingNAKs.ranges.orderedList.listArray; /*0x141100bee*/
            listArray_high = HIDWORD(incomingNAKs.ranges.orderedList.listArray); /*0x141100bf2*/
            p_incomingAcks = &this->incomingAcks; /*0x141100bf6*/
            if ( v29 >= this->incomingAcks.ranges.orderedList.list_size ) /*0x141100bfd*/
              goto LABEL_63; /*0x141100bfd*/
          }
          if ( DFLog::NetworkTrace != 0 )
            FLog::FastLogFormatted(
              level: DFLog::NetworkTrace,
              message: "[DFLog::NetworkTrace] Incoming packet error: incomingAcks minIndex > maxIndex, length=%d, address=%s",
              8 * v173,
              &systemAddressString[8]);
          goto LABEL_335; /*0x141100c6a*/
        }
LABEL_63:
        this->congestionManager->OnAckEnd(this: this->congestionManager, a2: v27, a3: listArray_high); /*0x141100c03*/
LABEL_64:
        ++this->receivePacketCount; /*0x141100c18*/
        if ( __eh34_unwind(1) ) /*0xf1c00000000000d0*/
          goto unwind_state_1; /*0xf1c00000000000d0*/
        __eh34_exit_wind_state(1, 0); /*0xf1c00000000000d4*/
        RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)&counterName.color); /*0x141100c23*/
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: v167); /*0x141100c2d*/
        if ( __eh34_unwind(0) ) /*0xf1c0000000000028*/
          goto unwind_state_0; /*0xf1c0000000000028*/
LABEL_324:
        __eh34_exit_wind_state(0, -1); /*0xf1c000000000002c*/
        return true; /*0x141101f71*/
      }
      if ( HIBYTE(dhf.extraPadding) != 0 )
      {
        __eh34_enter_wind_state(1, 2); /*0xf1c00000000000c8*/
        v51 = nullptr; /*0x141100c79*/
        dhf.sourceSystemTime = 0; /*0x141100c7b*/
        *(_QWORD *)&incomingNAKs.ranges.orderedList.list_size = 0; /*0x141100c80*/
        if ( DataStructures::RangeList<RakNet::uint24_t>::Deserialize(
               this: (DataStructures::RangeList<RakNet::uint24_t> *)&incomingNAKs.ranges.orderedList.list_size,
               out: (RakNet::BitStream *)&counterName.color) == 0 )
        {
          if ( DFLog::NetworkTrace != 0 )
            FLog::FastLogFormatted(
              level: DFLog::NetworkTrace,
              message: "[DFLog::NetworkTrace] Incoming packet error: incomingNAKs.Deserialize failed, length=%d, address=%s",
              8 * v16,
              &systemAddressString[8]);
          if ( __eh34_unwind(2) ) /*0xf1c00000000000bc*/
            goto unwind_state_2; /*0xf1c00000000000bc*/
          __eh34_exit_wind_state(2, 1); /*0xf1c00000000000c0*/
          sourceSystemTime_high = HIDWORD(dhf.sourceSystemTime); /*0x141100cc4*/
          if ( HIDWORD(dhf.sourceSystemTime) <= 0x200 ) /*0x141100cca*/
          {
            v51 = *(char **)&incomingNAKs.ranges.orderedList.list_size; /*0x141100d0d*/
          }
          else
          {
            if ( *(_QWORD *)&incomingNAKs.ranges.orderedList.list_size != 0 ) /*0x141100cdb*/
            {
              __eh34_enter_wind_state(1, 3); /*0xf1c00000000000b4*/
              v53 = (void *)(*(_QWORD *)&incomingNAKs.ranges.orderedList.list_size - 8LL); /*0x141100cdd*/
              `eh vector destructor iterator'( /*0x141100cf0*/
                ptr: *(void **)&incomingNAKs.ranges.orderedList.list_size,
                size: 8u,
                count: *(_QWORD *)(*(_QWORD *)&incomingNAKs.ranges.orderedList.list_size - 8LL),
                destructor: (void (__fastcall *)(void *))RBX::LSP::ILSPEditor::onSignalQuiescenceResponse);
              operator delete(ptr: v53); /*0x141100d03*/
              if ( __eh34_unwind(3) ) /*0xf1c00000000000a8*/
                goto unwind_state_3; /*0xf1c00000000000a8*/
              __eh34_exit_wind_state(3, 1); /*0xf1c00000000000ac*/
            }
            sourceSystemTime_high = 0; /*0x141100d09*/
          }
          if ( sourceSystemTime_high != 0 && v51 != nullptr ) /*0x141100d1d*/
          {
            `eh vector destructor iterator'( /*0x141100d36*/
              ptr: v51,
              size: 8u,
              count: *((_QWORD *)v51 - 1),
              destructor: (void (__fastcall *)(void *))RBX::LSP::ILSPEditor::onSignalQuiescenceResponse);
            operator delete(ptr: v51 - 8); /*0x141100d4b*/
          }
          goto LABEL_335; /*0x141100d51*/
        }
        v54 = 0; /*0x141100d56*/
        newestUnsentAck.val = 0; /*0x141100d58*/
        v55 = *(char **)&incomingNAKs.ranges.orderedList.list_size; /*0x141100d5e*/
        if ( LODWORD(dhf.sourceSystemTime) == 0 ) /*0x141100d67*/
        {
          if ( __eh34_unwind(2) ) /*0xf1c0000000000094*/
            goto unwind_state_2; /*0xf1c0000000000094*/
LABEL_340:
          __eh34_exit_wind_state(2, 1); /*0xf1c00000000000a0*/
          v71 = HIDWORD(dhf.sourceSystemTime); /*0x141100f49*/
          if ( HIDWORD(dhf.sourceSystemTime) != 0 ) /*0x141100f4f*/
          {
            if ( HIDWORD(dhf.sourceSystemTime) > 0x200 ) /*0x141100f5a*/
            {
              if ( v55 != nullptr ) /*0x141100f5f*/
              {
                __eh34_enter_wind_state(1, 3); /*0xf1c000000000008c*/
                `eh vector destructor iterator'( /*0x141100f74*/
                  ptr: v55,
                  size: 8u,
                  count: *((_QWORD *)v55 - 1),
                  destructor: (void (__fastcall *)(void *))RBX::LSP::ILSPEditor::onSignalQuiescenceResponse);
                operator delete(ptr: v55 - 8); /*0x141100f89*/
                if ( __eh34_unwind(3) ) /*0xf1c0000000000078*/
                  goto unwind_state_3; /*0xf1c0000000000078*/
                __eh34_exit_wind_state(3, 1); /*0xf1c0000000000084*/
              }
              v55 = nullptr; /*0x141100f8f*/
              v71 = 0; /*0x141100f92*/
            }
            if ( v71 != 0 && v55 != nullptr ) /*0x141100f9f*/
            {
              `eh vector destructor iterator'( /*0x141100fb8*/
                ptr: v55,
                size: 8u,
                count: *((_QWORD *)v55 - 1),
                destructor: (void (__fastcall *)(void *))RBX::LSP::ILSPEditor::onSignalQuiescenceResponse);
              operator delete(ptr: v55 - 8); /*0x141100fcd*/
            }
          }
          goto LABEL_64; /*0x141100fd3*/
        }
LABEL_80:
        v56 = (unsigned int)v54; /*0x141100d80*/
        v57 = *(_DWORD *)&v55[8 * (unsigned int)v54]; /*0x141100d82*/
        recordJoinDataRxStats.val = v57; /*0x141100d87*/
        if ( v57 > *(_DWORD *)&v55[8 * (unsigned int)v54 + 4] )
        {
          if ( DFLog::NetworkTrace != 0 )
            FLog::FastLogFormatted(
              level: DFLog::NetworkTrace,
              message: "[DFLog::NetworkTrace] Incoming packet error: incomingNAKs minIndex>maxIndex, length=%d, address=%s",
              8 * v173,
              &systemAddressString[8]);
          if ( __eh34_unwind(2) ) /*0xf1c0000000000104*/
          {
unwind_state_2:
            DataStructures::RangeList<RakNet::uint24_t>::~RangeList<RakNet::uint24_t>(this: (DataStructures::RangeList<RakNet::uint24_t> *)&incomingNAKs.ranges.orderedList.list_size); /*0xf1c0000000000098*/
            __eh34_continue_unwinding(2, 1); /*0xf1c000000000009c*/
          }
          __eh34_exit_wind_state(2, 1); /*0xf1c0000000000108*/
          __eh34_enter_wind_state(1, 3); /*0xf1c000000000010c*/
          v72 = HIDWORD(dhf.sourceSystemTime); /*0x141101008*/
          if ( HIDWORD(dhf.sourceSystemTime) != 0 ) /*0x14110100e*/
          {
            if ( HIDWORD(dhf.sourceSystemTime) > 0x200 ) /*0x141101015*/
            {
              if ( v55 != nullptr ) /*0x14110101a*/
              {
                `eh vector destructor iterator'( /*0x14110102f*/
                  ptr: v55,
                  size: 8u,
                  count: *((_QWORD *)v55 - 1),
                  destructor: (void (__fastcall *)(void *))RBX::LSP::ILSPEditor::onSignalQuiescenceResponse);
                operator delete(ptr: v55 - 8); /*0x141101044*/
              }
              v72 = 0; /*0x14110104a*/
              v55 = nullptr; /*0x14110104c*/
            }
            if ( v72 != 0 && v55 != nullptr ) /*0x141101056*/
            {
              `eh vector destructor iterator'( /*0x14110106b*/
                ptr: v55,
                size: 8u,
                count: *((_QWORD *)v55 - 1),
                destructor: (void (__fastcall *)(void *))RBX::LSP::ILSPEditor::onSignalQuiescenceResponse);
              operator delete(ptr: v55 - 8); /*0x141101080*/
            }
          }
          if ( __eh34_unwind(3) ) /*0xf1c00000000000f8*/
unwind_state_3:
            __std_terminate(a1: v54, a2: &v157); /*0xf1c000000000007c*/
          __eh34_exit_wind_state(3, 1); /*0xf1c00000000000fc*/
          if ( __eh34_unwind(1) ) /*0xf1c000000000006c*/
            goto unwind_state_1; /*0xf1c000000000006c*/
LABEL_335:
          __eh34_exit_wind_state(1, 0); /*0xf1c0000000000070*/
          RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)&counterName.color); /*0x14110108a*/
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: socket); /*0x141101097*/
          result = false; /*0x14110109c*/
          goto LABEL_321; /*0x14110109e*/
        }
LABEL_81:
        if ( v57 > *(_DWORD *)&v55[8 * v56 + 4] ) /*0x141100da5*/
          goto LABEL_110; /*0x141100da5*/
        v58 = this->congestionManager; /*0x141100dab*/
        v59 = v58->__vftable; /*0x141100db2*/
        LODWORD(internalPacket) = v57; /*0x141100db5*/
        ((void (__fastcall *)(RakNet::CCRakNetBase *, unsigned __int64, RakNet::InternalPacket **))v59->OnNAK)( /*0x141100dc1*/
          a1: v58,
          a2: v14,
          a3: &internalPacket);
        HIDWORD(incomingNAKs.ranges.orderedList.listArray) = v57; /*0x141100dc4*/
        v60 = RakNet::ReliabilityLayer::GetMessageNumberNodeByDatagramNumber( /*0x141100dd9*/
                this,
                datagramNumber: (int *)&incomingNAKs.ranges.orderedList.listArray + 1,
                timeSent: (unsigned __int64 *)&input);
        if ( v60 == nullptr ) /*0x141100ddf*/
          goto LABEL_109; /*0x141100ddf*/
        v61 = v165; /*0x141100de5*/
        while ( 1 ) /*0x141100df3*/
        {
          v62 = v60->messageNumber.val; /*0x141100df3*/
          Myfirst = this->resendBuffer._Mypair._Myval2._Myfirst; /*0x141100df6*/
          v64 = this->resendBuffer._Mypair._Myval2._Mylast - Myfirst; /*0x141100e07*/
          if ( (((_DWORD)v64 - 1) & (unsigned int)v64) != 0 ) /*0x141100e10*/
            v65 = v62 % (unsigned int)v64; /*0x141100e18*/
          else
            v65 = v62 & ((_DWORD)v64 - 1); /*0x141100e12*/
          v66 = Myfirst[v65]; /*0x141100e1a*/
          if ( v66 != nullptr ) /*0x141100e21*/
          {
            if ( v66->nextActionTime != 0 ) /*0x141100e2c*/
              break; /*0x141100e2c*/
LABEL_104:
            if ( !DFFlag::RCCJoinTransmissionStats.value ) /*0x141100ed5*/
            {
LABEL_105:
              if ( v66->isJoinData ) /*0x141100ed7*/
                this->statistics.ds.totalJoinDataNakSize_DEPRECATED += ((v66->headerLength + 7) >> 3) /*0x141100ef1*/
                                                                     + ((v66->dataBitLength + 7) >> 3);
            }
          }
          v60 = v60->next; /*0x141100ef8*/
          if ( v60 == nullptr ) /*0x141100eff*/
          {
            v57 = recordJoinDataRxStats.val; /*0x141100f05*/
            v55 = *(char **)&incomingNAKs.ranges.orderedList.list_size; /*0x141100f0b*/
LABEL_109:
            v57 = (v57 + 1) & 0xFFFFFF; /*0x141100f10*/
            recordJoinDataRxStats.val = v57; /*0x141100f18*/
            LODWORD(v54) = newestUnsentAck; /*0x141100f1e*/
            v56 = newestUnsentAck.val; /*0x141100f24*/
            v14 = v165; /*0x141100f2b*/
            if ( v57 < *(_DWORD *)&v55[8 * newestUnsentAck.val] ) /*0x141100f2f*/
            {
LABEL_110:
              v54 = (unsigned int)(v54 + 1); /*0x141100f35*/
              newestUnsentAck.val = v54; /*0x141100f37*/
              if ( (unsigned int)v54 >= LODWORD(dhf.sourceSystemTime) ) /*0x141100f41*/
                goto LABEL_340; /*0x141100f41*/
              goto LABEL_80; /*0x141100f41*/
            }
            goto LABEL_81; /*0x141100f2f*/
          }
        }
        v67 = DFInt::RakNetNakResendDelayRttPercent; /*0x141100e38*/
        if ( DFInt::RakNetNakResendDelayMs != 0 ) /*0x141100e41*/
        {
          if ( DFInt::RakNetNakResendDelayMs == -1 ) /*0x141100e50*/
            goto LABEL_102; /*0x141100e50*/
        }
        else if ( DFInt::RakNetNakResendDelayRttPercent == 0 ) /*0x141100e45*/
        {
          v66->nextActionTime = v61; /*0x141100e47*/
LABEL_102:
          if ( !DFFlag::RCCJoinTransmissionStats.value ) /*0x141100ec8*/
            goto LABEL_105; /*0x141100ec8*/
          v66->nextActionTimeSetByNak = true; /*0x141100eca*/
          goto LABEL_104; /*0x141100eca*/
        }
        LODWORD(v68) = 1000 * DFInt::RakNetNakResendDelayMs; /*0x141100e52*/
        if ( 1000 * DFInt::RakNetNakResendDelayMs == 0 && DFInt::RakNetNakResendDelayRttPercent > 0 ) /*0x141100e5e*/
        {
          v69 = this->congestionManager->GetRTT(this: this->congestionManager); /*0x141100e6a*/
          v70 = 0; /*0x141100e70*/
          if ( v69 >= 9.223372036854776e18 ) /*0x141100e76*/
          {
            v69 = v69 - 9.223372036854776e18; /*0x141100e78*/
            if ( v69 < 9.223372036854776e18 ) /*0x141100e80*/
              v70 = 0x8000000000000000uLL; /*0x141100e82*/
          }
          v68 = v67 * (v70 + (unsigned int)(int)v69) / 0x64; /*0x141100ea0*/
          if ( 1000 * DFInt::RakNetNakResendDelayMsMax != 0 && (int)v68 > 1000 * DFInt::RakNetNakResendDelayMsMax ) /*0x141100eb4*/
            LODWORD(v68) = 1000 * DFInt::RakNetNakResendDelayMsMax; /*0x141100eb4*/
        }
        v66->nextActionTime = v61 + (int)v68; /*0x141100ebd*/
        goto LABEL_102; /*0x141100ebd*/
      }
      v73 = this->congestionManager; /*0x1411010a3*/
      OnGotPacket = v73->OnGotPacket; /*0x1411010ad*/
      newestUnsentAck.val = *(_DWORD *)&dhf.isACK; /*0x1411010b4*/
      if ( ((unsigned __int8 (__fastcall *)(RakNet::CCRakNetBase *, RakNet::uint24_t *, bool, unsigned __int64, unsigned int, DataStructures::RangeList<RakNet::uint24_t> *))OnGotPacket)(
             a1: v73,
             a2: &newestUnsentAck,
             a3: dhf.isResentData,
             a4: v14,
             a5: v16,
             a6: &incomingNAKs) == 0 )
      {
        if ( DFLog::NetworkTrace != 0 )
          FLog::FastLogFormatted(
            level: DFLog::NetworkTrace,
            message: "[DFLog::NetworkTrace] Incoming packet error: congestionManager->OnGotPacket failed, length=%d, address=%s",
            8 * v16,
            &systemAddressString[8]);
        if ( __eh34_unwind(1) ) /*0xf1c0000000000058*/
        {
unwind_state_1:
          RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)&counterName.color); /*0xf1c000000000005c*/
          __eh34_continue_unwinding(1, 0); /*0xf1c0000000000060*/
        }
LABEL_332:
        __eh34_exit_wind_state(1, 0); /*0xf1c0000000000064*/
        RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)&counterName.color); /*0x1411011d8*/
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: socket); /*0x1411011e5*/
        goto LABEL_324; /*0x1411011ea*/
      }
      for ( i = (int)incomingNAKs.ranges.orderedList.listArray; i != 0; --i ) /*0x141101108*/
      {
        recordJoinDataRxStats.val = *(_DWORD *)&dhf.isACK - i; /*0x141101115*/
        HIBYTE(recordJoinDataRxStats.val) = 0; /*0x14110111b*/
        DataStructures::RangeList<RakNet::uint24_t>::Insert(this: &this->NAKs, index: &recordJoinDataRxStats.val); /*0x141101130*/
      }
      this->remoteSystemNeedsBAndAS = *(&dhf.isResentData + 1); /*0x14110113e*/
      if ( this->congestionManager->includeTimestampWithDatagrams(this: this->congestionManager) ) /*0x14110114f*/
        this->nextAckTimeToSend = *(_QWORD *)&dhf.datagramNumber.val; /*0x14110116c*/
      else
        this->nextAckTimeToSend = 0; /*0x141101175*/
      LODWORD(internalPacket) = *(_DWORD *)&dhf.isACK; /*0x14110117f*/
      DataStructures::RangeList<RakNet::uint24_t>::Insert( /*0x141101183*/
        this: &this->acknowlegements,
        index: (unsigned int *)&internalPacket);
      InternalPacketFromBitStream = RakNet::ReliabilityLayer::CreateInternalPacketFromBitStream( /*0x141101197*/
                                      this,
                                      bitStream: (RakNet::BitStream *)&counterName.color,
                                      time: v14);
      skippedMessageCount = InternalPacketFromBitStream; /*0x14110119a*/
      if ( InternalPacketFromBitStream == nullptr )
      {
        if ( DFLog::NetworkTrace != 0 )
          FLog::FastLogFormatted(
            level: DFLog::NetworkTrace,
            message: "[DFLog::NetworkTrace] Incoming packet error: CreateInternalPacketFromBitStream failed, length=%d, address=%s",
            8 * v173,
            &systemAddressString[8]);
        goto LABEL_332; /*0xf1c0000000000120*/
      }
      while ( 1 )
      {
        if ( this->resetReceivedPackets ) /*0x1411011f0*/
        {
          operator delete(ptr: this->hasReceivedPacketQueue.array); /*0x141101201*/
          this->hasReceivedPacketQueue.array = (bool *)operator new(size: 0x200u); /*0x141101210*/
          this->hasReceivedPacketQueue.allocation_size = 512; /*0x141101217*/
          *(_QWORD *)&this->hasReceivedPacketQueue.head = 0; /*0x141101222*/
          this->receivedPacketsBaseIndex.val = 0; /*0x14110122d*/
          *(_WORD *)((char *)&this->receivedPacketsBaseIndex.val + 3) = 0; /*0x141101234*/
        }
        reliability = InternalPacketFromBitStream->userMemory.reliability; /*0x14110123e*/
        if ( ((reliability - 1) & 0xFFFFFFFC) != 0
          || reliability == RELIABLE
          || InternalPacketFromBitStream->userMemory.orderingChannel < 0x20u )
        {
          if ( (unsigned int)(reliability - 2) <= 2 )
          {
            v79 = this->receivedPacketsBaseIndex.val; /*0x14110132f*/
            v80 = (InternalPacketFromBitStream->userMemory.reliableMessageNumber.val - v79) & 0xFFFFFF; /*0x14110133d*/
            if ( v80 != 0 )
            {
              if ( v80 > 0x7FFFFF ) /*0x14110139b*/
              {
                RakNet::BPSTracker::Push1( /*0x1411013b4*/
                  this: &this->bpsMetrics[4],
                  time: v14,
                  value1: (unsigned __int64)(InternalPacketFromBitStream->userMemory.dataBitLength + 7) >> 3);
                if ( val != 0 ) /*0x1411013bc*/
                {
                  this->joinRxStats.totalRxIgnoredBytes += (InternalPacketFromBitStream->userMemory.dataBitLength + 7) >> 3; /*0x1411013c9*/
                  ++this->joinRxStats.totalRxIgnoredPackets; /*0x1411013d0*/
                }
                if ( (this->commonCapabilities & 0x200000) != 0 && (_BYTE)v164 != 0 ) /*0x1411013e9*/
                {
                  this->raknetJoinRxStats.ignoredBytes += (InternalPacketFromBitStream->userMemory.dataBitLength + 7) >> 3; /*0x1411013f6*/
                  ++this->raknetJoinRxStats.ignoredPackets; /*0x1411013fd*/
                }
                v78 = 1360; /*0x141101404*/
                goto LABEL_154; /*0x14110140a*/
              }
              head = this->hasReceivedPacketQueue.head; /*0x14110140f*/
              tail = this->hasReceivedPacketQueue.tail; /*0x141101416*/
              if ( head > tail ) /*0x14110141f*/
                v88 = this->hasReceivedPacketQueue.allocation_size - head + tail; /*0x14110142e*/
              else
                v88 = tail - head; /*0x141101421*/
              if ( v80 >= v88 )
              {
                if ( v80 > 0xF4240 )
                {
                  if ( DFLog::NetworkTrace != 0 )
                    FLog::FastLogFormatted(
                      level: DFLog::NetworkTrace,
                      message: "[DFLog::NetworkTrace] Incoming packet error: holeCount > 1000000, length=%d, address=%s",
                      8 * v173,
                      &systemAddressString[8]);
                  RakNet::BPSTracker::Push1( /*0x141101542*/
                    this: &this->bpsMetrics[4],
                    time: v14,
                    value1: (unsigned __int64)(InternalPacketFromBitStream->userMemory.dataBitLength + 7) >> 3);
                  if ( val != 0 ) /*0x14110154a*/
                  {
                    this->joinRxStats.totalRxIgnoredBytes += (InternalPacketFromBitStream->userMemory.dataBitLength + 7) >> 3; /*0x141101557*/
                    ++this->joinRxStats.totalRxIgnoredPackets; /*0x14110155e*/
                  }
                  if ( (this->commonCapabilities & 0x200000) != 0 && (_BYTE)v164 != 0 ) /*0x141101577*/
                  {
                    this->raknetJoinRxStats.ignoredBytes += (InternalPacketFromBitStream->userMemory.dataBitLength + 7) >> 3; /*0x141101584*/
                    ++this->raknetJoinRxStats.ignoredPackets; /*0x14110158b*/
                  }
                  v78 = 1420; /*0x141101592*/
                  goto LABEL_154; /*0x141101598*/
                }
LABEL_198:
                allocation_size = this->hasReceivedPacketQueue.allocation_size; /*0x14110159d*/
                while ( 1 )
                {
                  v95 = this->hasReceivedPacketQueue.head; /*0x1411015b0*/
                  v96 = this->hasReceivedPacketQueue.tail; /*0x1411015b7*/
                  v97 = v95 > (unsigned int)v96
                      ? v96 + this->hasReceivedPacketQueue.allocation_size - v95
                      : (unsigned int)v96 - v95;
                  if ( v80 <= v97 ) /*0x1411015d8*/
                    break; /*0x1411015d8*/
                  if ( this->hasReceivedPacketQueue.allocation_size != 0 ) /*0x1411015e6*/
                  {
                    this->hasReceivedPacketQueue.array[v96] = true; /*0x141101627*/
                    v99 = this->hasReceivedPacketQueue.tail + 1; /*0x141101633*/
                    this->hasReceivedPacketQueue.tail = v99; /*0x141101635*/
                    allocation_size = this->hasReceivedPacketQueue.allocation_size; /*0x14110163c*/
                    if ( v99 == allocation_size ) /*0x141101647*/
                    {
                      this->hasReceivedPacketQueue.tail = 0; /*0x141101649*/
                      v99 = 0; /*0x141101650*/
                    }
                    if ( v99 == this->hasReceivedPacketQueue.head && 2 * allocation_size != 0 ) /*0x141101664*/
                    {
                      v100 = (bool *)operator new(size: (int)(2 * allocation_size)); /*0x141101672*/
                      allocation_size = this->hasReceivedPacketQueue.allocation_size; /*0x141101675*/
                      if ( v100 != nullptr ) /*0x14110167f*/
                      {
                        for ( j = 0; j < allocation_size; allocation_size = this->hasReceivedPacketQueue.allocation_size ) /*0x14110168a*/
                        {
                          v100[j] = this->hasReceivedPacketQueue.array[(j + this->hasReceivedPacketQueue.head) /*0x1411016b1*/
                                                                     % this->hasReceivedPacketQueue.allocation_size];
                          ++j; /*0x1411016b4*/
                        }
                        this->hasReceivedPacketQueue.head = 0; /*0x1411016c3*/
                        this->hasReceivedPacketQueue.tail = allocation_size; /*0x1411016ca*/
                        this->hasReceivedPacketQueue.allocation_size = 2 * allocation_size; /*0x1411016d4*/
                        operator delete(ptr: this->hasReceivedPacketQueue.array); /*0x1411016e2*/
                        this->hasReceivedPacketQueue.array = v100; /*0x1411016e7*/
                        goto LABEL_198; /*0x1411016ee*/
                      }
                    }
                  }
                  else
                  {
                    v98 = (bool *)operator new(size: 0x10u); /*0x1411015ed*/
                    this->hasReceivedPacketQueue.array = v98; /*0x1411015f2*/
                    this->hasReceivedPacketQueue.head = 0; /*0x1411015f9*/
                    this->hasReceivedPacketQueue.tail = 1; /*0x141101600*/
                    *v98 = true; /*0x14110160b*/
                    this->hasReceivedPacketQueue.allocation_size = 16; /*0x14110160e*/
                    allocation_size = 16; /*0x141101619*/
                  }
                }
                if ( allocation_size != 0 ) /*0x1411016f5*/
                {
                  this->hasReceivedPacketQueue.array[v96] = false; /*0x141101734*/
                  v103 = this->hasReceivedPacketQueue.tail + 1; /*0x141101740*/
                  this->hasReceivedPacketQueue.tail = v103; /*0x141101742*/
                  v104 = this->hasReceivedPacketQueue.allocation_size; /*0x141101749*/
                  if ( v103 == v104 ) /*0x141101752*/
                  {
                    this->hasReceivedPacketQueue.tail = 0; /*0x141101754*/
                    v103 = 0; /*0x14110175b*/
                  }
                  if ( v103 == this->hasReceivedPacketQueue.head && 2 * v104 != 0 ) /*0x14110176f*/
                  {
                    v105 = (bool *)operator new(size: (int)(2 * v104)); /*0x141101779*/
                    if ( v105 != nullptr ) /*0x14110177f*/
                    {
                      v106 = 0; /*0x141101781*/
                      v107 = this->hasReceivedPacketQueue.allocation_size; /*0x141101784*/
                      if ( v107 != 0 ) /*0x14110178d*/
                      {
                        do /*0x1411017c1*/
                        {
                          v105[v106] = this->hasReceivedPacketQueue.array[(v106 + this->hasReceivedPacketQueue.head) /*0x1411017b1*/
                                                                        % this->hasReceivedPacketQueue.allocation_size];
                          ++v106; /*0x1411017b4*/
                          v107 = this->hasReceivedPacketQueue.allocation_size; /*0x1411017b7*/
                        }
                        while ( v106 < v107 ); /*0x1411017c1*/
                      }
                      this->hasReceivedPacketQueue.head = 0; /*0x1411017c3*/
                      this->hasReceivedPacketQueue.tail = v107; /*0x1411017ca*/
                      this->hasReceivedPacketQueue.allocation_size = 2 * v107; /*0x1411017d3*/
                      operator delete(ptr: this->hasReceivedPacketQueue.array); /*0x1411017e1*/
                      this->hasReceivedPacketQueue.array = v105; /*0x1411017e6*/
                    }
                  }
                }
                else
                {
                  v102 = (bool *)operator new(size: 0x10u); /*0x1411016fc*/
                  this->hasReceivedPacketQueue.array = v102; /*0x141101701*/
                  this->hasReceivedPacketQueue.head = 0; /*0x141101708*/
                  this->hasReceivedPacketQueue.tail = 1; /*0x14110170f*/
                  *v102 = false; /*0x14110171a*/
                  this->hasReceivedPacketQueue.allocation_size = 16; /*0x14110171d*/
                }
              }
              else
              {
                v89 = head + v80; /*0x141101438*/
                v90 = this->hasReceivedPacketQueue.allocation_size; /*0x14110143c*/
                array = this->hasReceivedPacketQueue.array; /*0x141101443*/
                if ( head + v80 < v90 ) /*0x14110144f*/
                {
                  v93 = &array[v89]; /*0x141101460*/
                  v92 = head - v90; /*0x141101463*/
                }
                else
                {
                  v92 = head - v90; /*0x141101451*/
                  v93 = &array[head - v90 + v80]; /*0x141101458*/
                }
                if ( !*v93 ) /*0x14110146a*/
                {
                  RakNet::BPSTracker::Push1( /*0x141101496*/
                    this: &this->bpsMetrics[4],
                    time: v14,
                    value1: (unsigned __int64)(InternalPacketFromBitStream->userMemory.dataBitLength + 7) >> 3);
                  if ( val != 0 ) /*0x14110149e*/
                  {
                    this->joinRxStats.totalRxIgnoredBytes += (InternalPacketFromBitStream->userMemory.dataBitLength + 7) >> 3; /*0x1411014ab*/
                    ++this->joinRxStats.totalRxIgnoredPackets; /*0x1411014b2*/
                  }
                  if ( (this->commonCapabilities & 0x200000) != 0 && (_BYTE)v164 != 0 ) /*0x1411014cb*/
                  {
                    this->raknetJoinRxStats.ignoredBytes += (InternalPacketFromBitStream->userMemory.dataBitLength + 7) >> 3; /*0x1411014d8*/
                    ++this->raknetJoinRxStats.ignoredPackets; /*0x1411014df*/
                  }
                  v78 = 1391; /*0x1411014e6*/
                  goto LABEL_154; /*0x1411014ec*/
                }
                if ( v89 >= v90 ) /*0x14110146f*/
                  head = v92; /*0x14110146f*/
                array[head + v80] = false; /*0x141101475*/
              }
            }
            else
            {
              v81 = this->hasReceivedPacketQueue.head; /*0x141101345*/
              v82 = this->hasReceivedPacketQueue.tail; /*0x14110134c*/
              v83 = this->hasReceivedPacketQueue.allocation_size; /*0x141101353*/
              if ( v81 > v82 ) /*0x14110135c*/
                v84 = v83 - v81 + v82; /*0x141101367*/
              else
                v84 = v82 - v81; /*0x14110135e*/
              if ( v84 != 0 ) /*0x14110136b*/
              {
                v85 = v81 + 1; /*0x14110136d*/
                if ( v81 + 1 == v83 ) /*0x141101373*/
                  v85 = 0; /*0x141101373*/
                this->hasReceivedPacketQueue.head = v85; /*0x141101376*/
              }
              this->receivedPacketsBaseIndex.val = v79 + 1; /*0x141101381*/
              HIBYTE(this->receivedPacketsBaseIndex.val) = 0; /*0x141101388*/
            }
            while ( 1 )
            {
              v108 = this->hasReceivedPacketQueue.head; /*0x1411017f0*/
              v109 = this->hasReceivedPacketQueue.tail; /*0x1411017f7*/
              v110 = (unsigned int)v108 > v109
                   ? this->hasReceivedPacketQueue.allocation_size - v108 + v109
                   : v109 - (unsigned int)v108;
              if ( v110 == 0 || this->hasReceivedPacketQueue.array[v108] ) /*0x14110181c*/
                break; /*0x141101820*/
              v111 = v108 + 1; /*0x141101822*/
              this->hasReceivedPacketQueue.head = v108 + 1; /*0x141101825*/
              if ( (_DWORD)v108 + 1 == this->hasReceivedPacketQueue.allocation_size ) /*0x141101833*/
                v111 = 0; /*0x141101833*/
              this->hasReceivedPacketQueue.head = v111; /*0x141101836*/
              ++this->receivedPacketsBaseIndex.val; /*0x14110183d*/
              HIBYTE(this->receivedPacketsBaseIndex.val) = 0; /*0x141101844*/
            }
          }
          v112 = this->hasReceivedPacketQueue.allocation_size; /*0x14110184e*/
          if ( v112 > 0x200 ) /*0x14110185c*/
          {
            v113 = this->hasReceivedPacketQueue.head; /*0x141101862*/
            v114 = this->hasReceivedPacketQueue.tail; /*0x141101869*/
            v115 = v114 + v112 - v113; /*0x14110187b*/
            if ( v113 <= v114 ) /*0x141101880*/
              v115 = this->hasReceivedPacketQueue.tail - v113; /*0x141101880*/
            if ( v112 > 3 * v115 ) /*0x141101889*/
            {
              p_hasReceivedPacketQueue = &this->hasReceivedPacketQueue; /*0x14110188f*/
              v117 = 1; /*0x141101896*/
              v118 = DataStructures::Queue<bool>::Size(this: &this->hasReceivedPacketQueue); /*0x14110189e*/
              if ( v118 == 0 ) /*0x1411018a5*/
                goto LABEL_239; /*0x1411018a5*/
              do /*0x1411018ab*/
                v117 *= 2; /*0x1411018a7*/
              while ( v117 <= v118 ); /*0x1411018ab*/
              if ( v117 != 0 ) /*0x1411018af*/
LABEL_239:
                v119 = (bool *)operator new(size: (int)v117); /*0x1411018be*/
              else
                v119 = nullptr; /*0x1411018b1*/
              for ( k = 0; /*0x1411018cd*/
                    (unsigned int)k < (unsigned int)DataStructures::Queue<bool>::Size(this: &this->hasReceivedPacketQueue);
                    k = (unsigned int)(k + 1) )
              {
                v119[k] = p_hasReceivedPacketQueue->array[(unsigned int)(k + this->hasReceivedPacketQueue.head) /*0x1411018e9*/
                                                        % this->hasReceivedPacketQueue.allocation_size];
              }
              v121 = this->hasReceivedPacketQueue.head; /*0x1411018fb*/
              v122 = this->hasReceivedPacketQueue.tail; /*0x141101902*/
              if ( v121 > v122 ) /*0x14110190b*/
                v123 = this->hasReceivedPacketQueue.allocation_size + v122 - v121; /*0x141101913*/
              else
                v123 = v122 - v121; /*0x14110190d*/
              this->hasReceivedPacketQueue.tail = v123; /*0x14110191a*/
              this->hasReceivedPacketQueue.allocation_size = v117; /*0x141101921*/
              this->hasReceivedPacketQueue.head = 0; /*0x141101928*/
              operator delete(ptr: p_hasReceivedPacketQueue->array); /*0x141101936*/
              p_hasReceivedPacketQueue->array = v119; /*0x14110193b*/
              v14 = v165; /*0x14110193e*/
            }
          }
          if ( InternalPacketFromBitStream->userMemory.splitPacketCount != 0 )
          {
            v124 = InternalPacketFromBitStream->userMemory.reliability; /*0x141101950*/
            if ( ((v124 - 1) & 0xFFFFFFFC) != 0 || v124 == RELIABLE ) /*0x141101962*/
              InternalPacketFromBitStream->userMemory.orderingChannel = -1; /*0x141101964*/
            v125 = 0; /*0x14110196a*/
            if ( DFFlag::CLI57133.value ) /*0x141101973*/
              v125 = (InternalPacketFromBitStream->userMemory.dataBitLength + 7) >> 3; /*0x14110197d*/
            RakNet::ReliabilityLayer::InsertIntoSplitPacketList( /*0x141101989*/
              this,
              internalPacket: &InternalPacketFromBitStream->userMemory,
              time: v14);
            v166 = 0; /*0x141101991*/
            v126 = v167; /*0x141101996*/
            v127 = v167->_Rep; /*0x14110199a*/
            if ( v127 != nullptr ) /*0x1411019a1*/
            {
              _InterlockedIncrement((volatile signed __int32 *)&v127->_Uses); /*0x1411019a3*/
              v127 = v126->_Rep; /*0x1411019a7*/
              InternalPacketFromBitStream = skippedMessageCount; /*0x1411019ab*/
            }
            v166._Ptr = v126->_Ptr; /*0x1411019b3*/
            v166._Rep = v127; /*0x1411019b7*/
            v128 = RakNet::ReliabilityLayer::BuildPacketFromSplitPacketList( /*0x1411019fb*/
                     this,
                     splitPacketId: InternalPacketFromBitStream->userMemory.splitPacketId,
                     time: v14,
                     socket: &v166,
                     systemAddress: v174,
                     updateBitStream,
                     ruppHeader,
                     udmuxAddress);
            InternalPacketFromBitStream = (DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *)v128; /*0x141101a00*/
            skippedMessageCount = (DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *)v128; /*0x141101a03*/
            if ( v128 == nullptr )
            {
              if ( DFFlag::CLI57133.value )
              {
                this->incompleteDatagramBytes += v125; /*0x141101a24*/
                rakPeer = this->rakPeer; /*0x141101a2a*/
                p_maxBytesIncompleteDatagrams = &rakPeer->bytesInQueueStats.maxBytesIncompleteDatagrams; /*0x141101a31*/
                if ( rakPeer->bytesInQueueStats.maxBytesIncompleteDatagrams < this->incompleteDatagramBytes ) /*0x141101a38*/
                  p_maxBytesIncompleteDatagrams = &this->incompleteDatagramBytes; /*0x141101a38*/
                rakPeer->bytesInQueueStats.maxBytesIncompleteDatagrams = *p_maxBytesIncompleteDatagrams; /*0x141101a3e*/
                if ( this->incompleteDatagramBytes >= DFInt::CLI57133B )
                {
                  ++this->rakPeer->bytesInQueueStats.peersExceededByteCapIncompleteDatagrams; /*0x141101a57*/
                  if ( !this->incompleteDatagramByteCapExceeded )
                  {
                    this->incompleteDatagramByteCapExceeded = true; /*0x141101a67*/
                    if ( FLog::Network != 0 )
                      FLog::FastLogFormatted(
                        level: FLog::Network,
                        message: "[FLog::Network] Rx: Peer %s exceeded total incomplete datagram byte cap of %d",
                        &systemAddressString[8],
                        DFInt::CLI57133B);
                    counterName.text._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141101a96*/
                    counterName.text._Mypair._Myval2._Mysize = 0; /*0x141101a9a*/
                    counterName.text._Mypair._Myval2._Myres = 15; /*0x141101a9e*/
                    v131 = operator new(size: 0x30u); /*0x141101aaf*/
                    counterName.text._Mypair._Myval2._Mysize = 41; /*0x141101ab4*/
                    counterName.text._Mypair._Myval2._Myres = 47; /*0x141101abc*/
                    qmemcpy(v131, "RakNetRxIncompleteDatagramByteCapExceede", 40); /*0x141101acb*/
                    v131[20] = (unsigned __int8)aRaknetrxincomp[40]; /*0x141101aed*/
                    counterName.text._Mypair._Myval2._Bx._Ptr = (char *)v131; /*0x141101af4*/
                    __wind /*0xf1c000000000004c*/
                    {
                      RBX::Analytics::EphemeralCounter::reportCounter( /*0x141101b03*/
                        counterName: &counterName.text,
                        amount: 1,
                        blocking: false);
                    }
                    __unwind
                    {
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: &counterName); /*0xf1c0000000000044*/
                    }
                    if ( counterName.text._Mypair._Myval2._Myres >= 0x10 ) /*0x141101b11*/
                    {
                      v132 = counterName.text._Mypair._Myval2._Bx._Ptr; /*0x141101b16*/
                      if ( counterName.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141101b24*/
                      {
                        v132 = *((char **)counterName.text._Mypair._Myval2._Bx._Ptr - 1); /*0x141101b2a*/
                        if ( (unsigned __int64)(counterName.text._Mypair._Myval2._Bx._Ptr - v132 - 8) > 0x1F ) /*0x141101b39*/
                          _invalid_parameter_noinfo_noreturn(); /*0x141101ec9*/
                      }
                      operator delete(ptr: v132); /*0x141101b3f*/
                    }
                  }
                  if ( DFFlag::CLI57133D.value ) /*0x141101b4b*/
                    this->deadConnection = true; /*0x141101b51*/
                }
              }
              goto $CONTINUE_SOCKET_DATA_PARSE_LOOP; /*0x141101b59*/
            }
            if ( DFFlag::CLI57133.value ) /*0x141101b65*/
            {
              v133 = (v128->dataBitLength + 7) >> 3; /*0x141101b6d*/
              v134 = 0; /*0x141101b70*/
              if ( v133 != 0 ) /*0x141101b74*/
                v134 = v133; /*0x141101b74*/
              this->incompleteDatagramBytes -= v134; /*0x141101b77*/
            }
          }
          v135 = InternalPacketFromBitStream->userMemory.reliability; /*0x141101b7e*/
          if ( ((v135 - 1) & 0xFFFFFFFC) != 0 || v135 == RELIABLE ) /*0x141101b94*/
            goto LABEL_292; /*0x141101b94*/
          orderingChannel = InternalPacketFromBitStream->userMemory.orderingChannel; /*0x141101b9a*/
          v137 = InternalPacketFromBitStream->userMemory.orderingIndex.val; /*0x141101ba0*/
          v138 = this->orderedReadIndex[orderingChannel].val; /*0x141101ba5*/
          if ( v137 == v138 ) /*0x141101bb0*/
          {
            if ( v135 != RELIABLE_SEQUENCED && v135 != UNRELIABLE_SEQUENCED ) /*0x141101bc2*/
            {
              RakNet::BPSTracker::Push1( /*0x141101bdf*/
                this: &this->bpsMetrics[3],
                time: v14,
                value1: (unsigned __int64)(InternalPacketFromBitStream->userMemory.dataBitLength + 7) >> 3);
              DataStructures::Queue<RakNet::RakPeer::RequestedConnectionStruct *>::Push( /*0x141101bfa*/
                this: &this->outputQueue,
                input: (RakNet::InternalPacket **)&skippedMessageCount,
                file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
                line: 0x62Eu);
              v139 = InternalPacketFromBitStream->userMemory.orderingChannel; /*0x141101bff*/
              ++this->orderedReadIndex[v139].val; /*0x141101c05*/
              HIBYTE(this->orderedReadIndex[v139].val) = 0; /*0x141101c0d*/
              this->highestSequencedReadIndex[InternalPacketFromBitStream->userMemory.orderingChannel].val = 0; /*0x141101c1c*/
              v140 = InternalPacketFromBitStream->userMemory.orderingChannel; /*0x141101c28*/
              if ( this->orderingHeaps[v140].heap.list_size != 0 ) /*0x141101c3b*/
              {
                do /*0x141101cfd*/
                {
                  v141 = (unsigned __int8)v140; /*0x141101c50*/
                  v142 = (DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0> *)((char *)this->orderingHeaps /*0x141101c5c*/
                                                                                             + 16
                                                                                             * (unsigned __int8)v140
                                                                                             + 8 * (unsigned __int8)v140);
                  if ( v142->heap.listArray->data->orderingIndex.val != this->orderedReadIndex[v141].val ) /*0x141101c72*/
                    break; /*0x141101c72*/
                  v143 = DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::Pop( /*0x141101c7f*/
                           this: v142,
                           startingIndex: 0);
                  skippedMessageCount = (DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *)v143; /*0x141101c82*/
                  RakNet::BPSTracker::Push1( /*0x141101c9d*/
                    this: &this->bpsMetrics[3],
                    time: v14,
                    value1: (unsigned __int64)(v143->dataBitLength + 7) >> 3);
                  DataStructures::Queue<RakNet::RakPeer::RequestedConnectionStruct *>::Push( /*0x141101cb8*/
                    this: &this->outputQueue,
                    input: (RakNet::InternalPacket **)&skippedMessageCount,
                    file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
                    line: 0x65Eu);
                  if ( v143->reliability == RELIABLE_ORDERED ) /*0x141101cc1*/
                  {
                    v144 = v143->orderingChannel; /*0x141101cc3*/
                    ++this->orderedReadIndex[v144].val; /*0x141101cc7*/
                    HIBYTE(this->orderedReadIndex[v144].val) = 0; /*0x141101ccf*/
                  }
                  else
                  {
                    this->highestSequencedReadIndex[v143->orderingChannel].val = v143->sequencingIndex.val; /*0x141101ce1*/
                  }
                  LOBYTE(v140) = v143->orderingChannel; /*0x141101ced*/
                }
                while ( this->orderingHeaps[(unsigned __int8)v140].heap.list_size != 0 ); /*0x141101cfd*/
              }
              goto $CONTINUE_SOCKET_DATA_PARSE_LOOP; /*0x141101cfd*/
            }
            v145 = this->highestSequencedReadIndex[orderingChannel].val; /*0x141101d08*/
            v146 = InternalPacketFromBitStream->userMemory.sequencingIndex.val; /*0x141101d10*/
            if ( v145 <= 0x7FFFFF ) /*0x141101d1b*/
            {
              if ( v146 < ((v145 - 0x800000) & 0xFFFFFF) && v146 >= v145 ) /*0x141101d4c*/
              {
LABEL_291:
                this->highestSequencedReadIndex[orderingChannel].val = v146; /*0x141101d4e*/
LABEL_292:
                RakNet::BPSTracker::Push1( /*0x141101d56*/
                  this: &this->bpsMetrics[3],
                  time: v14,
                  value1: (unsigned __int64)(InternalPacketFromBitStream->userMemory.dataBitLength + 7) >> 3);
                DataStructures::Queue<RakNet::RakPeer::RequestedConnectionStruct *>::Push( /*0x141101d88*/
                  this: &this->outputQueue,
                  input: (RakNet::InternalPacket **)&skippedMessageCount,
                  file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
                  line: 0x69Bu);
                goto $CONTINUE_SOCKET_DATA_PARSE_LOOP; /*0x141101d88*/
              }
            }
            else if ( v146 < ((v145 - 8388606) & 0xFFFFFF) || v146 >= v145 ) /*0x141101d2e*/
            {
              goto LABEL_291; /*0x141101d2e*/
            }
            v78 = 1572; /*0x141101d30*/
          }
          else
          {
            if ( v138 <= 0x7FFFFF ) /*0x141101dba*/
            {
              if ( v137 < ((v138 - 0x800000) & 0xFFFFFF) && v137 >= v138 ) /*0x141101def*/
              {
LABEL_301:
                if ( this->orderingHeaps[orderingChannel].heap.list_size == 0 ) /*0x141101dfe*/
                {
                  this->heapIndexOffsets[orderingChannel].val = v138; /*0x141101e00*/
                  LOBYTE(orderingChannel) = InternalPacketFromBitStream->userMemory.orderingChannel; /*0x141101e08*/
                }
                v147 = (unsigned __int64)((InternalPacketFromBitStream->userMemory.orderingIndex.val /*0x141101e25*/
                                         - this->heapIndexOffsets[(unsigned __int8)orderingChannel].val)
                                        & 0xFFFFFF) << 20;
                v148 = InternalPacketFromBitStream->userMemory.reliability; /*0x141101e29*/
                if ( v148 == RELIABLE_SEQUENCED || v148 == UNRELIABLE_SEQUENCED ) /*0x141101e36*/
                  v149 = InternalPacketFromBitStream->userMemory.sequencingIndex.val + v147; /*0x141101e46*/
                else
                  v149 = v147 + 0xFFFFF; /*0x141101e38*/
                v150 = (DataStructures::List<DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::HeapNode> *)((char *)this + 24 * (unsigned __int8)orderingChannel); /*0x141101e4d*/
                v151 = v150[106].list_size; /*0x141101e51*/
                *(_QWORD *)&counterName.x = v149; /*0x141101e57*/
                *(_QWORD *)&counterName.width = InternalPacketFromBitStream; /*0x141101e5b*/
                DataStructures::List<DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::HeapNode>::Insert( /*0x141101e77*/
                  this: v150 + 106,
                  input: (const DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::HeapNode *)&counterName.x,
                  file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
                  line: 0x67Eu);
                if ( v151 != 0 ) /*0x141101e7e*/
                {
                  do /*0x141101ec2*/
                  {
                    v152 = (v151 - 1) >> 1; /*0x141101e87*/
                    v153 = v150[106].listArray; /*0x141101e8e*/
                    if ( v153[v152].weight <= v149 ) /*0x141101e99*/
                      break; /*0x141101e99*/
                    v154 = v153[v151]; /*0x141101ea4*/
                    v153[v151] = v153[(v151 - 1) >> 1]; /*0x141101eae*/
                    v150[106].listArray[(v151 - 1) >> 1] = v154; /*0x141101eba*/
                    v151 = (v151 - 1) >> 1; /*0x141101ebe*/
                  }
                  while ( v152 != 0 ); /*0x141101ec2*/
                }
                goto $CONTINUE_SOCKET_DATA_PARSE_LOOP; /*0x141101ec2*/
              }
            }
            else if ( v137 < ((v138 - 8388606) & 0xFFFFFF) || v137 >= v138 ) /*0x141101dcf*/
            {
              goto LABEL_301; /*0x141101dcf*/
            }
            v78 = 1680; /*0x141101dd1*/
          }
        }
        else
        {
          if ( DFLog::NetworkTrace != 0 )
            FLog::FastLogFormatted(
              level: DFLog::NetworkTrace,
              message: "[DFLog::NetworkTrace] Incoming packet error: internalPacket->orderingChannel >= NUMBER_OF_ORDERED_STREAMS,"
              " length=%d, address=%s",
              8 * v173,
              &systemAddressString[8]);
          RakNet::BPSTracker::Push1( /*0x1411012ab*/
            this: &this->bpsMetrics[4],
            time: v14,
            value1: (unsigned __int64)(InternalPacketFromBitStream->userMemory.dataBitLength + 7) >> 3);
          if ( val != 0 ) /*0x1411012b3*/
          {
            this->joinRxStats.totalRxIgnoredBytes += (InternalPacketFromBitStream->userMemory.dataBitLength + 7) >> 3; /*0x1411012c0*/
            ++this->joinRxStats.totalRxIgnoredPackets; /*0x1411012c7*/
          }
          if ( (this->commonCapabilities & 0x200000) != 0 && (_BYTE)v164 != 0 ) /*0x1411012e0*/
          {
            this->raknetJoinRxStats.ignoredBytes += (InternalPacketFromBitStream->userMemory.dataBitLength + 7) >> 3; /*0x1411012ed*/
            ++this->raknetJoinRxStats.ignoredPackets; /*0x1411012f4*/
          }
          v78 = 1315; /*0x1411012fb*/
        }
LABEL_154:
        RakNet::ReliabilityLayer::FreeInternalPacketData( /*0x141101301*/
          this,
          internalPacket: &InternalPacketFromBitStream->userMemory,
          file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
          line: v78);
        RakNet::ReliabilityLayer::ReleaseToInternalPacketPool(this, ip: &InternalPacketFromBitStream->userMemory); /*0x141101319*/
$CONTINUE_SOCKET_DATA_PARSE_LOOP: /*0x141101d8d*/
        InternalPacketFromBitStream = RakNet::ReliabilityLayer::CreateInternalPacketFromBitStream( /*0x141101d8d*/
                                        this,
                                        bitStream: (RakNet::BitStream *)&counterName.color,
                                        time: v14);
        skippedMessageCount = InternalPacketFromBitStream; /*0x141101d9f*/
        if ( InternalPacketFromBitStream == nullptr ) /*0x141101da7*/
          goto LABEL_64; /*0x141101da7*/
      }
    }
  }
  else
  {
    this->deadConnection = true; /*0x141101ed0*/
  }
  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: socket); /*0x141101edf*/
  result = false; /*0x141101ee4*/
  if ( __eh34_unwind(0) ) /*0xf1c0000000000014*/
    goto unwind_state_0; /*0xf1c0000000000014*/
LABEL_321:
  __eh34_exit_wind_state(0, -1); /*0xf1c0000000000020*/
  return result; /*0x141101f4f*/
}

// Address: 0x141101f80 | Name: ?InitializeVariables@ReliabilityLayer@RakNet@@AEAAXXZ
void __fastcall RakNet::ReliabilityLayer::InitializeVariables(RakNet::ReliabilityLayer *this)
{
  __int64 v2; // rsi
  unsigned int *p_allocation_size; // rdi
  int v4; // eax
  char *v5; // rcx
  char *v6; // rbx
  __int64 v7; // rcx
  char *v8; // rcx
  char *v9; // rbx
  __int64 v10; // [rsp+0h] [rbp-28h] BYREF

  memset_0(a1: this->orderedWriteIndex, Val: 0, Size: 0x200u); /*0x141101fac*/
  memset_0(a1: &this->statistics, Val: 0, Size: sizeof(this->statistics)); /*0x141101fc0*/
  *(_OWORD *)&this->heapIndexOffsets[0].val = 0; /*0x141101fc8*/
  *(_OWORD *)&this->heapIndexOffsets[4].val = 0; /*0x141101fcf*/
  *(_OWORD *)&this->heapIndexOffsets[8].val = 0; /*0x141101fd6*/
  *(_OWORD *)&this->heapIndexOffsets[12].val = 0; /*0x141101fdd*/
  *(_OWORD *)&this->heapIndexOffsets[16].val = 0; /*0x141101fe4*/
  *(_OWORD *)&this->heapIndexOffsets[20].val = 0; /*0x141101feb*/
  *(_OWORD *)&this->heapIndexOffsets[24].val = 0; /*0x141101ff2*/
  *(_OWORD *)&this->heapIndexOffsets[28].val = 0; /*0x141101ff9*/
  this->statistics.connectionStartTime = RakNet::GetTimeUS(isNetworkSynced: false); /*0x141102007*/
  this->splitPacketId = 0; /*0x141102011*/
  this->elapsedTimeSinceLastUpdate = 0; /*0x141102019*/
  this->throughputCapCountdown = 0; /*0x141102020*/
  *(_QWORD *)&this->sendReliableMessageNumberIndex.val = 0; /*0x141102027*/
  HIBYTE(this->sendReliableMessageNumberIndex.val) = 0; /*0x14110202e*/
  HIBYTE(this->internalOrderIndex.val) = 0; /*0x141102035*/
  this->timeToNextUnreliableCull = 0; /*0x14110203c*/
  this->unreliableLinkedListHead = nullptr; /*0x141102043*/
  this->lastUpdateTime = RakNet::GetTimeUS(isNetworkSynced: false); /*0x141102051*/
  this->bandwidthExceededStatistic = false; /*0x141102058*/
  this->remoteSystemTime = 0; /*0x14110205f*/
  this->unreliableTimeout = 0; /*0x141102066*/
  this->lastBpsClear = 0; /*0x14110206d*/
  this->nextAllowedThroughputSample = 0; /*0x141102074*/
  *(_WORD *)&this->deadConnection = 0; /*0x14110207b*/
  this->timeOfLastContinualSend = 0; /*0x141102083*/
  this->timeLastDatagramArrived = RakNet::GetTimeMS(); /*0x14110208f*/
  this->statistics.messagesInResendBuffer = 0; /*0x141102095*/
  this->statistics.bytesInResendBuffer = 0; /*0x14110209c*/
  this->receivedPacketsBaseIndex.val = 0; /*0x1411020a3*/
  *(_WORD *)((char *)&this->receivedPacketsBaseIndex.val + 3) = 256; /*0x1411020aa*/
  this->receivePacketCount = 0; /*0x1411020b3*/
  this->timeBetweenPackets = 350000; /*0x1411020ba*/
  this->ackPingIndex = 0; /*0x1411020c5*/
  this->ackPingSum = 0; /*0x1411020cc*/
  this->nextSendTime = this->lastUpdateTime; /*0x1411020da*/
  *(_QWORD *)&this->unacknowledgedBytes = 0; /*0x1411020e1*/
  this->resendLinkedListHead = nullptr; /*0x1411020e8*/
  this->resendLinkedListHead2 = nullptr; /*0x1411020ef*/
  this->totalUserDataBytesAcked = 0.0; /*0x1411020f6*/
  this->datagramHistoryPopCount.val = 0; /*0x1411020fd*/
  HIBYTE(this->datagramHistoryPopCount.val) = 0; /*0x141102104*/
  this->unreliableDatagramHistoryCount = 0; /*0x14110210b*/
  if ( DFFlag::CLI57133.value ) /*0x141102119*/
  {
    this->incompleteDatagramBytes = 0; /*0x14110211b*/
    this->incompleteDatagramByteCapExceeded = false; /*0x141102122*/
  }
  this->outgoingPacketBufferNextWeights[0] = 0; /*0x141102130*/
  this->outgoingPacketBufferNextWeights[1] = 3; /*0x141102137*/
  this->outgoingPacketBufferNextWeights[2] = 10; /*0x141102142*/
  this->outgoingPacketBufferNextWeights[3] = 27; /*0x14110214d*/
  *(_QWORD *)this->statistics.messageInSendBuffer = 0; /*0x141102158*/
  this->statistics.bytesInSendBuffer[0] = 0.0; /*0x14110215f*/
  this->statistics.bytesInSendBuffer[1] = 0.0; /*0x141102166*/
  *(_QWORD *)&this->statistics.messageInSendBuffer[2] = 0; /*0x14110216d*/
  this->statistics.bytesInSendBuffer[2] = 0.0; /*0x141102174*/
  this->statistics.bytesInSendBuffer[3] = 0.0; /*0x14110217b*/
  v2 = 0; /*0x141102182*/
  p_allocation_size = &this->bpsMetrics[0].dataQueue.allocation_size; /*0x141102185*/
  do /*0x141102267*/
  {
    if ( FFlag::FixBPSTracker.value ) /*0x141102197*/
    {
      v4 = Mtx_lock_0(a1: (_Mtx_t)(p_allocation_size - 24)); /*0x14110219d*/
      if ( v4 != 0 ) /*0x1411021a4*/
      {
        std::_Throw_C_error(a1: v4); /*0x14110228a*/
        __debugbreak(); /*0x14110228f*/
      }
      *((_QWORD *)p_allocation_size - 13) = 0; /*0x1411021aa*/
      *((_QWORD *)p_allocation_size - 14) = 0; /*0x1411021ae*/
      if ( *p_allocation_size != 0 ) /*0x1411021b6*/
      {
        if ( *p_allocation_size > 0x20 ) /*0x1411021bb*/
        {
          v5 = *((char **)p_allocation_size - 2); /*0x1411021bd*/
          if ( v5 != nullptr ) /*0x1411021c4*/
          {
            __eh34_enter_wind_state(-1, 0); /*0xf1c000000000003c*/
            v6 = v5 - 8; /*0x1411021c6*/
            `eh vector destructor iterator'( /*0x1411021d9*/
              ptr: v5,
              size: 0x10u,
              count: *((_QWORD *)v5 - 1),
              destructor: (void (__fastcall *)(void *))RBX::LSP::ILSPEditor::onSignalQuiescenceResponse);
            operator delete(ptr: v6); /*0x1411021ec*/
            if ( __eh34_unwind(0) ) /*0xf1c0000000000030*/
              goto unwind_state_0; /*0xf1c0000000000030*/
            __eh34_exit_wind_state(0, -1); /*0xf1c0000000000034*/
          }
          *p_allocation_size = 0; /*0x1411021f2*/
        }
        *((_QWORD *)p_allocation_size - 1) = 0; /*0x1411021f5*/
      }
      Mtx_unlock_0(a1: (_Mtx_t)(p_allocation_size - 24)); /*0x1411021fd*/
    }
    else
    {
      _InterlockedExchange64((volatile __int64 *)p_allocation_size - 15, 0); /*0x141102207*/
      _InterlockedExchange64((volatile __int64 *)p_allocation_size - 16, 0); /*0x14110220e*/
      if ( *p_allocation_size != 0 ) /*0x141102216*/
      {
        if ( *p_allocation_size > 0x20 ) /*0x14110221b*/
        {
          v8 = *((char **)p_allocation_size - 2); /*0x14110221d*/
          if ( v8 != nullptr ) /*0x141102224*/
          {
            __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000028*/
            v9 = v8 - 8; /*0x141102226*/
            `eh vector destructor iterator'( /*0x141102239*/
              ptr: v8,
              size: 0x10u,
              count: *((_QWORD *)v8 - 1),
              destructor: (void (__fastcall *)(void *))RBX::LSP::ILSPEditor::onSignalQuiescenceResponse);
            operator delete(ptr: v9); /*0x14110224c*/
            if ( __eh34_unwind(0) ) /*0xf1c0000000000014*/
unwind_state_0:
              __std_terminate(a1: v7, a2: &v10); /*0xf1c0000000000018*/
            __eh34_exit_wind_state(0, -1); /*0xf1c0000000000020*/
          }
          *p_allocation_size = 0; /*0x141102252*/
        }
        *((_QWORD *)p_allocation_size - 1) = 0; /*0x141102255*/
      }
    }
    ++v2; /*0x141102259*/
    p_allocation_size += 34; /*0x14110225c*/
  }
  while ( v2 < 7 ); /*0x141102267*/
}

// Address: 0x141102aa0 | Name: ?InsertIntoSplitPacketList@ReliabilityLayer@RakNet@@AEAAXPEAUInternalPacket@2@_K@Z
void __fastcall RakNet::ReliabilityLayer::InsertIntoSplitPacketList(
        RakNet::ReliabilityLayer *this,
        RakNet::InternalPacket *internalPacket,
        unsigned __int64 time)
{
  unsigned __int64 v3; // rbx
  RakNet::ReliabilityLayer *v5; // r13
  DataStructures::OrderedList<unsigned short,RakNet::SplitPacketChannel *,&RakNet::SplitPacketChannelComp> *p_splitPacketChannelList; // r15
  signed int list_size; // eax
  int v8; // r10d
  signed int v9; // r9d
  unsigned int v10; // edi
  unsigned int splitPacketId; // r8d
  RakNet::SplitPacketChannel *v12; // rcx
  int v13; // ecx
  signed int v14; // eax
  RakNet::SplitPacketChannel *v15; // rax
  RakNet::SplitPacketChannel *v16; // rbx
  unsigned int v17; // eax
  unsigned int splitPacketCount; // ebp
  unsigned int uniqueFilled; // eax
  void **p_Myfirst; // r14
  RakNet::InternalPacket **Mylast; // r12
  RakNet::InternalPacket **Myfirst; // r13
  unsigned __int64 v23; // rdx
  char *v24; // rbp
  size_t v25; // r12
  RakNet::InternalPacket **v26; // rcx
  __int64 v27; // r14
  RakNet::SplitPacketChannel *v28; // rcx
  __int64 splitPacketIndex; // rdx
  unsigned int intendedSize; // eax
  __int64 v31; // rdx
  RakNet::InternalPacket **v32; // rax
  RakNet::SplitPacketChannel *v33; // rax
  unsigned int v34; // ebp
  unsigned int splitMessageProgressInterval; // ecx
  RakNet::InternalPacket *firstPacket; // rax
  DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *v37; // rdi
  unsigned int v38; // ebx
  RakNet::InternalPacket *v39; // rdx
  RakNet::SplitPacketList newPacketList; // [rsp+40h] [rbp-58h] BYREF
  RakNet::InternalPacket *progressIndicator; // [rsp+A0h] [rbp+8h] BYREF
  unsigned __int64 v42; // [rsp+B0h] [rbp+18h]
  RakNet::SplitPacketChannel *newChannel; // [rsp+B8h] [rbp+20h] BYREF

  v42 = time; /*0x141102aa5*/
  progressIndicator = (RakNet::InternalPacket *)this; /*0x141102aaa*/
  v3 = time; /*0x141102abe*/
  v5 = this; /*0x141102ac4*/
  p_splitPacketChannelList = &this->splitPacketChannelList; /*0x141102ac7*/
  list_size = this->splitPacketChannelList.orderedList.list_size; /*0x141102ace*/
  if ( list_size != 0 ) /*0x141102ade*/
  {
    v8 = list_size - 1; /*0x141102ae0*/
    v9 = 0; /*0x141102ae4*/
    v10 = list_size / 2; /*0x141102aec*/
    splitPacketId = internalPacket->splitPacketId; /*0x141102af1*/
    do /*0x141102b40*/
    {
      v12 = p_splitPacketChannelList->orderedList.listArray[v10]; /*0x141102b02*/
      if ( splitPacketId >= v12->splitPacketId ) /*0x141102b0a*/
      {
        if ( splitPacketId == v12->splitPacketId ) /*0x141102b13*/
          goto LABEL_32; /*0x141102b13*/
        v13 = 1; /*0x141102b19*/
      }
      else
      {
        v13 = -1; /*0x141102b0c*/
      }
      if ( v13 >= 0 ) /*0x141102b23*/
        v9 = v10 + 1; /*0x141102b23*/
      v14 = v10 - 1; /*0x141102b27*/
      if ( v13 >= 0 ) /*0x141102b2a*/
        v14 = v8; /*0x141102b2a*/
      v8 = v14; /*0x141102b2e*/
      v10 = v9 + (v14 - v9) / 2; /*0x141102b39*/
    }
    while ( v9 <= v14 ); /*0x141102b40*/
  }
  v15 = (RakNet::SplitPacketChannel *)operator new(size: 0x48u); /*0x141102b47*/
  v16 = v15; /*0x141102b4c*/
  newChannel = v15; /*0x141102b4f*/
  if ( v15 != nullptr ) /*0x141102b5a*/
  {
    *(_QWORD *)&v15->splitPacketList.list_size = 0; /*0x141102b5c*/
    v15->splitPacketList.listArray = nullptr; /*0x141102b60*/
    v15->newSplitList.internalList._Mypair._Myval2._Myfirst = nullptr; /*0x141102b64*/
    v15->newSplitList.internalList._Mypair._Myval2._Mylast = nullptr; /*0x141102b68*/
    v15->newSplitList.internalList._Mypair._Myval2._Myend = nullptr; /*0x141102b6c*/
    *(_QWORD *)&v15->newSplitList.uniqueFilled = 0; /*0x141102b70*/
  }
  else
  {
    v16 = nullptr; /*0x141102b76*/
  }
  newChannel = v16; /*0x141102b79*/
  v16->firstPacket = nullptr; /*0x141102b81*/
  v17 = DataStructures::OrderedList<unsigned short,RakNet::SplitPacketChannel *,&int RakNet::SplitPacketChannelComp(unsigned short const &,RakNet::SplitPacketChannel * const &)>::Insert( /*0x141102bb0*/
          this: p_splitPacketChannelList,
          key: &internalPacket->splitPacketId,
          data: &newChannel,
          assertOnDuplicate: true,
          file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
          line: 0xE38u,
          cf: (int (__fastcall *)(const unsigned __int16 *, RakNet::SplitPacketChannel *const *))RakNet::SplitPacketChannelComp);
  v10 = v17; /*0x141102bb5*/
  splitPacketCount = internalPacket->splitPacketCount; /*0x141102bb7*/
  memset(&newPacketList, 0, 24); /*0x141102bbd*/
  __wind /*0xf1c0000000000010*/
  {
    if ( splitPacketCount > 0x80000000 ) /*0x141102bcf*/
      splitPacketCount = 0x80000000; /*0x141102bcf*/
    newChannel = nullptr; /*0x141102bd2*/
    if ( splitPacketCount != 0 ) /*0x141102bde*/
      std::vector<RakNet::InternalPacket *>::_Resize_reallocate<RakNet::InternalPacket *>( /*0x141102bed*/
        this: (std::vector<unsigned __int64> *)&newPacketList,
        _Newsize: splitPacketCount,
        _Val: (struct VkImage_T **)&newChannel);
    uniqueFilled = 0; /*0x141102c00*/
    newPacketList.uniqueFilled = 0; /*0x141102c03*/
    newPacketList.intendedSize = splitPacketCount; /*0x141102c07*/
  }
  __unwind
  {
    std::vector<Luau::AstExpr *>::~vector<Luau::AstExpr *>(this: (std::vector<RBX::Graphics::FramebufferVulkan *> *)&newPacketList); /*0xf1c0000000000020*/
  }
  __wind /*0xf1c0000000000028*/
  {
    p_Myfirst = (void **)&v16->newSplitList.internalList._Mypair._Myval2._Myfirst; /*0x141102c0b*/
    if ( &v16->newSplitList != &newPacketList ) /*0x141102c17*/
    {
      Mylast = newPacketList.internalList._Mypair._Myval2._Mylast; /*0x141102c19*/
      Myfirst = newPacketList.internalList._Mypair._Myval2._Myfirst; /*0x141102c1e*/
      v23 = newPacketList.internalList._Mypair._Myval2._Mylast - newPacketList.internalList._Mypair._Myval2._Myfirst; /*0x141102c29*/
      v24 = (char *)*p_Myfirst; /*0x141102c2d*/
      if ( v23 > v16->newSplitList.internalList._Mypair._Myval2._Myend /*0x141102c3e*/
               - v16->newSplitList.internalList._Mypair._Myval2._Myfirst )
      {
        std::vector<webrtc::rtcp::TargetBitrate::BitrateItem>::_Clear_and_reserve_geometric( /*0x141102c43*/
          this: (std::vector<char const *> *)&v16->newSplitList,
          _Newsize: v23);
        v24 = (char *)*p_Myfirst; /*0x141102c48*/
      }
      v25 = (char *)Mylast - (char *)Myfirst; /*0x141102c4b*/
      memmove_0(a1: v24, Src: Myfirst, Size: v25); /*0x141102c57*/
      v16->newSplitList.internalList._Mypair._Myval2._Mylast = (RakNet::InternalPacket **)&v24[v25]; /*0x141102c60*/
      uniqueFilled = newPacketList.uniqueFilled; /*0x141102c64*/
      v5 = (RakNet::ReliabilityLayer *)progressIndicator; /*0x141102c68*/
    }
    v16->newSplitList.uniqueFilled = uniqueFilled; /*0x141102c73*/
    v16->newSplitList.intendedSize = newPacketList.intendedSize; /*0x141102c7b*/
    v16->splitPacketId = internalPacket->splitPacketId; /*0x141102c83*/
    v16->splitPacketCount = internalPacket->splitPacketCount; /*0x141102c89*/
  }
  __unwind
  {
    std::vector<Luau::AstExpr *>::~vector<Luau::AstExpr *>(this: (std::vector<RBX::Graphics::FramebufferVulkan *> *)&newPacketList); /*0xf1c0000000000008*/
  }
  v26 = newPacketList.internalList._Mypair._Myval2._Myfirst; /*0x141102c8c*/
  if ( newPacketList.internalList._Mypair._Myval2._Myfirst != nullptr ) /*0x141102c94*/
  {
    if ( (((char *)newPacketList.internalList._Mypair._Myval2._Myend /*0x141102cac*/
         - (char *)newPacketList.internalList._Mypair._Myval2._Myfirst)
        & 0xFFFFFFFFFFFFFFF8uLL) >= 0x1000 )
    {
      v26 = *((RakNet::InternalPacket ***)newPacketList.internalList._Mypair._Myval2._Myfirst - 1); /*0x141102cb2*/
      if ( (unsigned __int64)((char *)newPacketList.internalList._Mypair._Myval2._Myfirst - (char *)v26 - 8) > 0x1F ) /*0x141102cc1*/
        _invalid_parameter_noinfo_noreturn(); /*0x141102cc3*/
    }
    operator delete(ptr: v26); /*0x141102cca*/
    memset(&newPacketList, 0, 24); /*0x141102cd2*/
  }
  v3 = v42; /*0x141102ce4*/
LABEL_32:
  v27 = v10; /*0x141102cec*/
  v28 = p_splitPacketChannelList->orderedList.listArray[v27]; /*0x141102cf9*/
  splitPacketIndex = internalPacket->splitPacketIndex; /*0x141102cfd*/
  intendedSize = v28->newSplitList.intendedSize; /*0x141102d00*/
  if ( (unsigned int)splitPacketIndex < intendedSize && internalPacket->splitPacketCount == intendedSize ) /*0x141102d0e*/
  {
    v31 = splitPacketIndex; /*0x141102d14*/
    v32 = v28->newSplitList.internalList._Mypair._Myval2._Myfirst; /*0x141102d1c*/
    if ( v32[v31] == nullptr ) /*0x141102d25*/
      ++v28->newSplitList.uniqueFilled; /*0x141102d27*/
    v32[v31] = internalPacket; /*0x141102d2a*/
    p_splitPacketChannelList->orderedList.listArray[v27]->lastUpdateTime = v3; /*0x141102d35*/
    if ( internalPacket->splitPacketIndex == 0 ) /*0x141102d3c*/
      p_splitPacketChannelList->orderedList.listArray[v27]->firstPacket = internalPacket; /*0x141102d45*/
    v33 = p_splitPacketChannelList->orderedList.listArray[v27]; /*0x141102d4c*/
    v34 = v33->newSplitList.uniqueFilled; /*0x141102d50*/
    splitMessageProgressInterval = v5->splitMessageProgressInterval; /*0x141102d53*/
    if ( splitMessageProgressInterval != 0 ) /*0x141102d5c*/
    {
      firstPacket = v33->firstPacket; /*0x141102d62*/
      if ( firstPacket != nullptr && v34 != firstPacket->splitPacketCount && v34 % splitMessageProgressInterval == 0 ) /*0x141102d80*/
      {
        v37 = RakNet::ReliabilityLayer::AllocateFromInternalPacketPool(this: v5); /*0x141102d8e*/
        progressIndicator = &v37->userMemory; /*0x141102d91*/
        v38 = ((p_splitPacketChannelList->orderedList.listArray[v27]->firstPacket->dataBitLength + 7) >> 3) + 13; /*0x141102dad*/
        v37->userMemory.allocationScheme = 0; /*0x141102db0*/
        v37->userMemory.data = (unsigned __int8 *)RBX::Memory::allocate(size: v38); /*0x141102dbb*/
        v37->userMemory.dataBitLength = 8 * v38; /*0x141102dc6*/
        *v37->userMemory.data = 30; /*0x141102dcd*/
        *(_DWORD *)(v37->userMemory.data + 1) = v34; /*0x141102dd4*/
        *(_DWORD *)(v37->userMemory.data + 5) = internalPacket->splitPacketCount; /*0x141102dde*/
        *(_DWORD *)(v37->userMemory.data + 9) = (p_splitPacketChannelList->orderedList.listArray[v27]->firstPacket->dataBitLength /*0x141102df9*/
                                               + 7) >> 3;
        v39 = p_splitPacketChannelList->orderedList.listArray[v27]->firstPacket; /*0x141102e03*/
        memcpy_0(a1: v37->userMemory.data + 13, Src: v39->data, Size: (unsigned __int64)(v39->dataBitLength + 7) >> 3); /*0x141102e1f*/
        DataStructures::Queue<RakNet::RakPeer::RequestedConnectionStruct *>::Push( /*0x141102e3d*/
          this: &v5->outputQueue,
          input: &progressIndicator,
          file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
          line: 0xEBFu);
      }
    }
  }
  else
  {
    RakNet::ReliabilityLayer::FreeInternalPacketData( /*0x141102e53*/
      this: v5,
      internalPacket,
      file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
      line: 0xE98u);
    RakNet::ReliabilityLayer::ReleaseToInternalPacketPool(this: v5, ip: internalPacket); /*0x141102e5e*/
  }
}

// Address: 0x141102e90 | Name: ?IsOutgoingDataWaiting@ReliabilityLayer@RakNet@@QEAA_NXZ
bool __fastcall RakNet::ReliabilityLayer::IsOutgoingDataWaiting(RakNet::ReliabilityLayer *this)
{
  return this->outgoingPacketBuffer.heap.list_size != 0 || this->statistics.messagesInResendBuffer != 0; /*0x141102e9b*/
}

// Address: 0x141103420 | Name: ?PushPacket@ReliabilityLayer@RakNet@@AEAAX_KPEAUInternalPacket@2@_N@Z
void __fastcall RakNet::ReliabilityLayer::PushPacket(
        RakNet::ReliabilityLayer *this,
        unsigned __int64 time,
        RakNet::InternalPacket *internalPacket,
        bool isReliable)
{
  unsigned int v5; // edi
  unsigned int v6; // esi
  unsigned int list_size; // edx
  int v11; // ebp
  unsigned int allocation_size; // eax
  signed int v13; // eax
  RakNet::InternalPacket **v14; // rax
  RakNet::InternalPacket **listArray; // r14
  RakNet::InternalPacket **v16; // rcx
  unsigned int v17; // r8d
  __int64 v18; // rax
  bool v19; // zf
  unsigned int v20; // edx
  unsigned int v21; // eax
  bool *v22; // rax
  bool *v23; // rbp
  bool *v24; // rcx
  __int64 v25; // rdx
  unsigned int v26; // esi
  unsigned int v27; // esi

  v5 = 0; /*0x141103453*/
  v6 = ((internalPacket->headerLength + 7) & 0xFFFFFFF8) + ((internalPacket->dataBitLength + 7) & 0xFFFFFFF8); /*0x141103455*/
  this->datagramSizeSoFar += v6; /*0x14110345b*/
  this->allDatagramSizesSoFar += v6; /*0x141103464*/
  list_size = this->packetsToSendThisUpdate.list_size; /*0x14110346d*/
  v11 = 16; /*0x141103473*/
  allocation_size = this->packetsToSendThisUpdate.allocation_size; /*0x141103478*/
  if ( list_size != allocation_size ) /*0x141103480*/
  {
    listArray = this->packetsToSendThisUpdate.listArray; /*0x14110351a*/
    goto LABEL_14; /*0x14110351a*/
  }
  if ( allocation_size != 0 ) /*0x141103488*/
  {
    v19 = 2 * allocation_size == 0; /*0x14110350b*/
    v13 = 2 * allocation_size; /*0x14110350b*/
    this->packetsToSendThisUpdate.allocation_size = v13; /*0x14110350d*/
    if ( v19 ) /*0x141103513*/
    {
      listArray = nullptr; /*0x141103515*/
      goto LABEL_5; /*0x141103518*/
    }
  }
  else
  {
    this->packetsToSendThisUpdate.allocation_size = 16; /*0x14110348e*/
    v13 = 16; /*0x141103494*/
  }
  v14 = (RakNet::InternalPacket **)operator new(size: saturated_mul(v13, 8u)); /*0x1411034af*/
  list_size = this->packetsToSendThisUpdate.list_size; /*0x1411034b4*/
  listArray = v14; /*0x1411034ba*/
LABEL_5:
  v16 = this->packetsToSendThisUpdate.listArray; /*0x1411034bd*/
  if ( v16 != nullptr ) /*0x1411034c7*/
  {
    v17 = 0; /*0x1411034c9*/
    if ( list_size != 0 ) /*0x1411034ce*/
    {
      do /*0x1411034f4*/
      {
        v18 = v17++; /*0x1411034d0*/
        listArray[v18] = this->packetsToSendThisUpdate.listArray[v18]; /*0x1411034e9*/
      }
      while ( v17 < this->packetsToSendThisUpdate.list_size ); /*0x1411034f4*/
      v16 = this->packetsToSendThisUpdate.listArray; /*0x1411034f6*/
    }
    operator delete(ptr: v16); /*0x1411034fd*/
  }
  this->packetsToSendThisUpdate.listArray = listArray; /*0x141103502*/
LABEL_14:
  listArray[this->packetsToSendThisUpdate.list_size++] = internalPacket; /*0x141103521*/
  v20 = this->packetsToDeallocThisUpdate.list_size; /*0x141103539*/
  v21 = this->packetsToDeallocThisUpdate.allocation_size; /*0x14110353f*/
  if ( v20 != v21 ) /*0x141103547*/
  {
    v23 = this->packetsToDeallocThisUpdate.listArray; /*0x1411035c1*/
    goto LABEL_27; /*0x1411035c1*/
  }
  if ( v21 != 0 ) /*0x14110354f*/
  {
    v11 = 2 * v21; /*0x1411035af*/
    this->packetsToDeallocThisUpdate.allocation_size = 2 * v21; /*0x1411035b2*/
    if ( 2 * v21 == 0 ) /*0x1411035ba*/
    {
      v23 = nullptr; /*0x1411035bc*/
      goto LABEL_18; /*0x1411035bf*/
    }
  }
  else
  {
    this->packetsToDeallocThisUpdate.allocation_size = 16; /*0x141103551*/
  }
  v22 = (bool *)operator new(size: v11); /*0x14110355a*/
  v20 = this->packetsToDeallocThisUpdate.list_size; /*0x14110355f*/
  v23 = v22; /*0x141103565*/
LABEL_18:
  v24 = this->packetsToDeallocThisUpdate.listArray; /*0x141103568*/
  if ( v24 != nullptr ) /*0x141103572*/
  {
    if ( v20 != 0 ) /*0x141103576*/
    {
      do /*0x141103598*/
      {
        v25 = v5++; /*0x141103587*/
        v23[v25] = this->packetsToDeallocThisUpdate.listArray[v25]; /*0x14110358f*/
      }
      while ( v5 < this->packetsToDeallocThisUpdate.list_size ); /*0x141103598*/
      v24 = this->packetsToDeallocThisUpdate.listArray; /*0x14110359a*/
    }
    operator delete(ptr: v24); /*0x1411035a1*/
  }
  this->packetsToDeallocThisUpdate.listArray = v23; /*0x1411035a6*/
LABEL_27:
  v23[this->packetsToDeallocThisUpdate.list_size++] = !isReliable; /*0x1411035c8*/
  if ( !DFFlag::RakNetUseSlidingWindow4.value || !DFFlag::RakNetReportTransmissionBw2.value ) /*0x1411035e8*/
  {
    if ( !DFFlag::RakNetComputeTxBw.value ) /*0x14110362a*/
      goto LABEL_41; /*0x14110362a*/
    v27 = v6 >> 3; /*0x14110362c*/
    if ( internalPacket->timesSent != 0 ) /*0x141103634*/
    {
      ++this->perSecTxBwCounters_deprecated.reliablePacketsRe; /*0x141103636*/
      this->perSecTxBwCounters_deprecated.reliablePacketBytesRe += v27; /*0x14110363c*/
      goto LABEL_41; /*0x141103642*/
    }
    if ( DFFlag::RakNetCountUnreliableBytesForStats.value ) /*0x14110364b*/
    {
      if ( !isReliable ) /*0x141103650*/
      {
        this->perSecTxBwCounters_deprecated.unreliablePacketBytes += v27; /*0x141103652*/
LABEL_40:
        ++this->perSecTxBwCounters_deprecated.unreliablePackets; /*0x141103658*/
        goto LABEL_41; /*0x141103658*/
      }
    }
    else if ( !isReliable ) /*0x1411036a7*/
    {
      goto LABEL_40; /*0x1411036a7*/
    }
    this->perSecTxBwCounters_deprecated.reliablePacketBytes += v27; /*0x1411036a9*/
    ++this->perSecTxBwCounters_deprecated.reliablePackets; /*0x1411036af*/
    goto LABEL_41; /*0x1411036b5*/
  }
  v26 = v6 >> 3; /*0x1411035ea*/
  if ( internalPacket->timesSent != 0 ) /*0x1411035f2*/
  {
    ++this->perSecTxBwData.reliablePacketsRe; /*0x1411035f4*/
    this->perSecTxBwData.reliablePacketBytesRe += v26; /*0x1411035fa*/
  }
  else if ( isReliable ) /*0x141103605*/
  {
    this->perSecTxBwData.reliablePacketBytes += v26; /*0x141103607*/
    ++this->perSecTxBwData.reliablePackets; /*0x14110360d*/
  }
  else
  {
    this->perSecTxBwData.unreliablePacketBytes += v26; /*0x141103615*/
    ++this->perSecTxBwData.unreliablePackets; /*0x14110361b*/
  }
LABEL_41:
  this->congestionManager->OnSendBytes_2( /*0x14110365e*/
    this: this->congestionManager,
    a2: time,
    a3: ((internalPacket->headerLength + 7) >> 3) + ((internalPacket->dataBitLength + 7) >> 3));
}

// Address: 0x1411036c0 | Name: ?Receive@ReliabilityLayer@RakNet@@QEAAIPEAPEAE@Z
__int64 __fastcall RakNet::ReliabilityLayer::Receive(RakNet::ReliabilityLayer *this, unsigned __int8 **data)
{
  unsigned int head; // ecx
  unsigned int tail; // r8d
  unsigned int v6; // r8d
  RakNet::InternalPacket **array; // rdx
  unsigned int v8; // eax
  unsigned int allocation_size; // ecx
  __int64 v10; // rax
  RakNet::InternalPacket *v11; // rdx
  unsigned int dataBitLength; // ebx

  head = this->outputQueue.head; /*0x1411036ca*/
  tail = this->outputQueue.tail; /*0x1411036cd*/
  if ( head > tail ) /*0x1411036d4*/
    v6 = this->outputQueue.allocation_size - head + tail; /*0x1411036e1*/
  else
    v6 = tail - head; /*0x1411036d6*/
  if ( v6 == 0 ) /*0x1411036e7*/
    return 0; /*0x14110373b*/
  array = this->outputQueue.array; /*0x1411036e9*/
  v8 = head + 1; /*0x1411036ed*/
  allocation_size = this->outputQueue.allocation_size; /*0x1411036f0*/
  this->outputQueue.head = v8; /*0x1411036f9*/
  if ( v8 == allocation_size ) /*0x1411036ff*/
  {
    this->outputQueue.head = 0; /*0x141103701*/
    v10 = allocation_size - 1; /*0x141103709*/
  }
  else if ( v8 != 0 ) /*0x141103710*/
  {
    v10 = v8 - 1; /*0x141103717*/
  }
  else
  {
    v10 = allocation_size - 1; /*0x141103712*/
  }
  v11 = array[v10]; /*0x141103719*/
  *data = v11->data; /*0x141103724*/
  dataBitLength = v11->dataBitLength; /*0x141103727*/
  RakNet::ReliabilityLayer::ReleaseToInternalPacketPool(this, ip: v11); /*0x14110372a*/
  return dataBitLength; /*0x141103736*/
}

// Address: 0x141103750 | Name: ?ReleaseToInternalPacketPool@ReliabilityLayer@RakNet@@AEAAXPEAUInternalPacket@2@@Z
void __fastcall RakNet::ReliabilityLayer::ReleaseToInternalPacketPool(
        RakNet::ReliabilityLayer *this,
        DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *ip)
{
  DataStructures::MemoryPool<RakNet::InternalPacket>::Page *parentPage; // rbx
  __int64 availableStackSize; // rax
  DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage **availableStack; // rcx
  DataStructures::MemoryPool<RakNet::InternalPacket>::Page *unavailablePages; // rax
  int availablePagesSize; // ecx

  parentPage = ip->parentPage; /*0x141103756*/
  availableStackSize = parentPage->availableStackSize; /*0x141103760*/
  availableStack = parentPage->availableStack; /*0x141103764*/
  if ( (_DWORD)availableStackSize != 0 ) /*0x141103769*/
  {
    availableStack[availableStackSize] = ip; /*0x141103819*/
    if ( ++parentPage->availableStackSize == (unsigned int)(this->internalPacketPool.memoryPoolPageSize / 0x110uLL) /*0x141103845*/
      && this->internalPacketPool.availablePagesSize >= 4 )
    {
      if ( parentPage == this->internalPacketPool.availablePages ) /*0x14110384e*/
        this->internalPacketPool.availablePages = parentPage->next; /*0x141103854*/
      parentPage->prev->next = parentPage->next; /*0x141103863*/
      parentPage->next->prev = parentPage->prev; /*0x14110386f*/
      --this->internalPacketPool.availablePagesSize; /*0x141103873*/
      operator delete(ptr: parentPage->availableStack); /*0x14110387d*/
      operator delete(ptr: parentPage->block); /*0x141103886*/
      operator delete(ptr: parentPage); /*0x141103893*/
    }
  }
  else
  {
    *availableStack = ip; /*0x14110376f*/
    ++parentPage->availableStackSize; /*0x141103772*/
    --this->internalPacketPool.unavailablePagesSize; /*0x141103775*/
    parentPage->next->prev = parentPage->prev; /*0x141103784*/
    parentPage->prev->next = parentPage->next; /*0x141103790*/
    if ( this->internalPacketPool.unavailablePagesSize > 0 ) /*0x14110379c*/
    {
      unavailablePages = this->internalPacketPool.unavailablePages; /*0x14110379e*/
      if ( parentPage == unavailablePages ) /*0x1411037a8*/
        this->internalPacketPool.unavailablePages = unavailablePages->next; /*0x1411037ae*/
    }
    availablePagesSize = this->internalPacketPool.availablePagesSize; /*0x1411037b5*/
    this->internalPacketPool.availablePagesSize = availablePagesSize + 1; /*0x1411037bf*/
    if ( availablePagesSize != 0 ) /*0x1411037c8*/
    {
      parentPage->next = this->internalPacketPool.availablePages; /*0x1411037e6*/
      parentPage->prev = this->internalPacketPool.availablePages->prev; /*0x1411037f5*/
      this->internalPacketPool.availablePages->prev->next = parentPage; /*0x141103804*/
      this->internalPacketPool.availablePages->prev = parentPage; /*0x14110380f*/
    }
    else
    {
      this->internalPacketPool.availablePages = parentPage; /*0x1411037ca*/
      parentPage->next = parentPage; /*0x1411037d1*/
      parentPage->prev = parentPage; /*0x1411037d5*/
    }
  }
}

// Address: 0x1411038a0 | Name: ?RemoveFromDatagramHistory@ReliabilityLayer@RakNet@@AEAAXUuint24_t@2@@Z
void __fastcall RakNet::ReliabilityLayer::RemoveFromDatagramHistory(
        RakNet::ReliabilityLayer *this,
        _DWORD *datagramNumber)
{
  unsigned int allocation_size; // eax
  unsigned int v4; // ebx
  unsigned int head; // edx
  RakNet::ReliabilityLayer::DatagramHistoryNode *array; // r9
  unsigned int v7; // r8d
  unsigned int v8; // edx
  RakNet::ReliabilityLayer::MessageNumberNode *v9; // rcx
  DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>::Page *v10; // rdi
  RakNet::ReliabilityLayer::MessageNumberNode *next; // rbp
  __int64 availableStackSize; // rax
  DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>::MemoryWithPage **availableStack; // rdx
  DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>::Page *unavailablePages; // rax
  int availablePagesSize; // ecx
  unsigned int v16; // eax
  unsigned int v17; // ecx
  unsigned int v18; // edx
  unsigned int v19; // ecx

  allocation_size = this->datagramHistory.allocation_size; /*0x1411038b5*/
  v4 = (*datagramNumber - this->datagramHistoryPopCount.val) & 0xFFFFFF; /*0x1411038bb*/
  head = this->datagramHistory.head; /*0x1411038c1*/
  array = this->datagramHistory.array; /*0x1411038c7*/
  v7 = head + v4; /*0x1411038ce*/
  v8 = v4 + head - allocation_size; /*0x1411038d4*/
  if ( v7 >= allocation_size ) /*0x1411038d9*/
    v7 = v8; /*0x1411038d9*/
  v9 = array[v7].head; /*0x1411038e3*/
  if ( v9 != nullptr ) /*0x1411038ea*/
  {
    do /*0x141103a4f*/
    {
      v10 = *(DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>::Page **)&v9[1].messageNumber.val; /*0x141103920*/
      next = v9->next; /*0x141103924*/
      availableStackSize = v10->availableStackSize; /*0x141103928*/
      availableStack = v10->availableStack; /*0x14110392c*/
      if ( (_DWORD)availableStackSize != 0 ) /*0x141103931*/
      {
        availableStack[availableStackSize] = (DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>::MemoryWithPage *)v9; /*0x1411039d8*/
        if ( ++v10->availableStackSize == (unsigned int)(this->datagramHistoryMessagePool.memoryPoolPageSize / 0x18uLL) /*0x1411039fc*/
          && this->datagramHistoryMessagePool.availablePagesSize >= 4 )
        {
          if ( v10 == this->datagramHistoryMessagePool.availablePages ) /*0x141103a05*/
            this->datagramHistoryMessagePool.availablePages = v10->next; /*0x141103a0b*/
          v10->prev->next = v10->next; /*0x141103a1a*/
          v10->next->prev = v10->prev; /*0x141103a26*/
          --this->datagramHistoryMessagePool.availablePagesSize; /*0x141103a2a*/
          operator delete(ptr: v10->availableStack); /*0x141103a33*/
          operator delete(ptr: v10->block); /*0x141103a3c*/
          operator delete(ptr: v10); /*0x141103a44*/
        }
      }
      else
      {
        *availableStack = (DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>::MemoryWithPage *)v9; /*0x141103937*/
        ++v10->availableStackSize; /*0x14110393a*/
        --this->datagramHistoryMessagePool.unavailablePagesSize; /*0x14110393d*/
        v10->next->prev = v10->prev; /*0x14110394b*/
        v10->prev->next = v10->next; /*0x141103957*/
        if ( this->datagramHistoryMessagePool.unavailablePagesSize > 0 ) /*0x141103962*/
        {
          unavailablePages = this->datagramHistoryMessagePool.unavailablePages; /*0x141103964*/
          if ( v10 == unavailablePages ) /*0x14110396e*/
            this->datagramHistoryMessagePool.unavailablePages = unavailablePages->next; /*0x141103974*/
        }
        availablePagesSize = this->datagramHistoryMessagePool.availablePagesSize; /*0x14110397b*/
        this->datagramHistoryMessagePool.availablePagesSize = availablePagesSize + 1; /*0x141103984*/
        if ( availablePagesSize != 0 ) /*0x14110398c*/
        {
          v10->next = this->datagramHistoryMessagePool.availablePages; /*0x1411039a9*/
          v10->prev = this->datagramHistoryMessagePool.availablePages->prev; /*0x1411039b8*/
          this->datagramHistoryMessagePool.availablePages->prev->next = v10; /*0x1411039c7*/
          this->datagramHistoryMessagePool.availablePages->prev = v10; /*0x1411039d2*/
        }
        else
        {
          this->datagramHistoryMessagePool.availablePages = v10; /*0x14110398e*/
          v10->next = v10; /*0x141103995*/
          v10->prev = v10; /*0x141103999*/
        }
      }
      v9 = next; /*0x141103a49*/
    }
    while ( next != nullptr ); /*0x141103a4f*/
    array = this->datagramHistory.array; /*0x141103a55*/
  }
  else if ( DFFlag::RakNetFixBwCollapse.value ) /*0x1411038f2*/
  {
    --this->unreliableDatagramHistoryCount; /*0x1411038f8*/
  }
  v16 = this->datagramHistory.allocation_size; /*0x141103a6b*/
  v17 = this->datagramHistory.head; /*0x141103a71*/
  v18 = v17 + v4; /*0x141103a77*/
  v19 = v4 + v17 - v16; /*0x141103a7c*/
  if ( v18 >= v16 ) /*0x141103a85*/
    v18 = v19; /*0x141103a85*/
  array[v18].head = nullptr; /*0x141103a8d*/
}

// Address: 0x141103aa0 | Name: ?RemovePacketFromResendListAndDeleteOlderReliableSequenced@ReliabilityLayer@RakNet@@AEAAIUuint24_t@2@_KAEBUSystemAddress@2@@Z
RakNet::InternalPacket *__fastcall RakNet::ReliabilityLayer::RemovePacketFromResendListAndDeleteOlderReliableSequenced(
        RakNet::ReliabilityLayer *this,
        unsigned int *messageNumber,
        unsigned __int64 time,
        const RakNet::SystemAddress *systemAddress)
{
  unsigned int v7; // r9d
  RakNet::InternalPacket **Myfirst; // rdi
  __int64 v9; // rcx
  __int64 v10; // rdx
  RakNet::InternalPacket *v11; // rdi
  unsigned int v12; // eax
  RakNet::InternalPacket **v13; // r8
  __int64 v14; // rcx
  __int64 v15; // rdx
  int reliability; // ecx
  unsigned int splitPacketCount; // edx
  DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *v18; // rbx
  unsigned __int8 *v19; // rax
  bool v20; // r8
  std::_Tree_node<std::pair<RakNet::uint24_t const ,RakNet::InternalPacket *>,void *> *Myhead; // r14
  std::_Tree_node<std::pair<RakNet::uint24_t const ,RakNet::InternalPacket *>,void *> *Parent; // rax
  std::_Tree_node<std::pair<std::string const ,std::shared_ptr<std::string const > >,void *> *inserted; // rbx
  unsigned int val; // ecx
  unsigned int v25; // eax
  std::_Tree_node<std::pair<std::string const ,std::shared_ptr<std::string const > >,void *> *v26; // rax
  RakNet::InternalPacket *v27; // rdx
  RakNet::InternalPacket *result; // rax
  RakNet::InternalPacket *resendPrev; // rcx
  std::_Tree_node<std::pair<RakNet::uint24_t const ,RakNet::InternalPacket *>,void *> *v30; // rax
  std::_Tree_node<std::pair<RakNet::uint24_t const ,RakNet::InternalPacket *>,void *> *v31; // r8
  DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *second; // rbx
  unsigned __int8 timesAck; // al
  RakNet::InternalPacket *resendNext; // rax
  std::_Alloc_construct_ptr<std::allocator<std::_List_node<std::pair<__int64 const ,std::vector<RBX::Permission> >,void *> > > v35; // [rsp+20h] [rbp-58h] BYREF
  std::_Alloc_construct_ptr<std::allocator<std::_List_node<std::pair<__int64 const ,std::vector<RBX::Permission> >,void *> > > v36; // [rsp+30h] [rbp-48h]
  RakNet::InternalPacket *ackReceipt; // [rsp+80h] [rbp+8h] BYREF

  v7 = *messageNumber; /*0x141103abf*/
  Myfirst = this->resendBuffer._Mypair._Myval2._Myfirst; /*0x141103ac2*/
  v9 = this->resendBuffer._Mypair._Myval2._Mylast - Myfirst; /*0x141103ad3*/
  if ( (((_DWORD)v9 - 1) & (unsigned int)v9) != 0 ) /*0x141103adc*/
    v10 = v7 % (unsigned int)v9; /*0x141103ae8*/
  else
    v10 = v7 & ((_DWORD)v9 - 1); /*0x141103ade*/
  v11 = Myfirst[v10]; /*0x141103aea*/
  if ( v11 != nullptr && v11->reliableMessageNumber.val == v7 ) /*0x141103afa*/
  {
    ++v11->timesAck; /*0x141103b00*/
    if ( v11->isJoinData ) /*0x141103b03*/
      --this->statistics.ds.totalJoinPacketsPendingCount; /*0x141103b09*/
    v12 = *messageNumber; /*0x141103b0f*/
    v13 = this->resendBuffer._Mypair._Myval2._Myfirst; /*0x141103b12*/
    v14 = this->resendBuffer._Mypair._Myval2._Mylast - v13; /*0x141103b23*/
    if ( (((_DWORD)v14 - 1) & (unsigned int)v14) != 0 ) /*0x141103b2c*/
      v15 = v12 % (unsigned int)v14; /*0x141103b34*/
    else
      v15 = v12 & ((_DWORD)v14 - 1); /*0x141103b2e*/
    v13[v15] = nullptr; /*0x141103b38*/
    --this->statistics.messagesInResendBuffer; /*0x141103b3c*/
    this->statistics.bytesInResendBuffer -= (unsigned __int64)(v11->dataBitLength + 7) >> 3; /*0x141103b4c*/
    if ( !DFFlag::RCCJoinTransmissionStats.value && v11->isJoinData ) /*0x141103b5c*/
      this->statistics.ds.totalJoinDataAckSize_DEPRECATED += ((v11->headerLength + 7) >> 3) /*0x141103b76*/
                                                           + ((v11->dataBitLength + 7) >> 3);
    this->totalUserDataBytesAcked = (double)((v11->headerLength + v11->dataBitLength + 7) >> 3) /*0x141103b99*/
                                  + this->totalUserDataBytesAcked;
    if ( DFFlag::TransportLibraryTest.value && this->tLibTestClientStats.bytesToSend._Storage._Value != 0 ) /*0x141103bb2*/
      RakNet::TransportLibraryTestClientStats::checkTestComplete( /*0x141103bc1*/
        this: &this->tLibTestClientStats,
        bytes: (v11->dataBitLength + 7) >> 3);
    reliability = v11->reliability; /*0x141103bc6*/
    if ( reliability >= 6 ) /*0x141103bcc*/
    {
      splitPacketCount = v11->splitPacketCount; /*0x141103bce*/
      if ( splitPacketCount != 0 && v11->splitPacketIndex + 1 != splitPacketCount ) /*0x141103bdc*/
      {
LABEL_24:
        if ( (unsigned int)(reliability - 6) > 1 ) /*0x141103c4e*/
        {
          v20 = false; /*0x141103c50*/
LABEL_27:
          RakNet::ReliabilityLayer::ResendListRemove(this, internalPacket: v11, modifyUnacknowledgedBytes: v20); /*0x141103c58*/
          RakNet::ReliabilityLayer::FreeInternalPacketData( /*0x141103c76*/
            this,
            internalPacket: v11,
            file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
            line: 0xC10u);
          if ( !DFFlag::GameLoadDataStatistics.value || v11->timesAck == v11->timesSent ) /*0x141103c8f*/
          {
            RakNet::ReliabilityLayer::ReleaseToInternalPacketPool( /*0x141103de1*/
              this,
              ip: (DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *)v11);
            return nullptr; /*0x141103de6*/
          }
          else
          {
            Myhead = this->resendBuffer2._Mypair._Myval2._Myval2._Myhead; /*0x141103c9c*/
            Parent = Myhead->_Parent; /*0x141103c9f*/
            v36._Al = (std::allocator<std::_List_node<std::pair<__int64 const ,std::vector<RBX::Permission> >,void *> > *)Parent; /*0x141103ca3*/
            LODWORD(v36._Ptr) = 0; /*0x141103ca8*/
            inserted = (std::_Tree_node<std::pair<std::string const ,std::shared_ptr<std::string const > >,void *> *)Myhead; /*0x141103cac*/
            if ( Parent->_Isnil == 0 ) /*0x141103cb3*/
            {
              val = v11->reliableMessageNumber.val; /*0x141103cb5*/
              do /*0x141103ce6*/
              {
                v36._Al = (std::allocator<std::_List_node<std::pair<__int64 const ,std::vector<RBX::Permission> >,void *> > *)Parent; /*0x141103cc0*/
                if ( Parent->_Myval.first.val >= val ) /*0x141103cc8*/
                {
                  LODWORD(v36._Ptr) = 1; /*0x141103cd4*/
                  inserted = (std::_Tree_node<std::pair<std::string const ,std::shared_ptr<std::string const > >,void *> *)Parent; /*0x141103cdc*/
                  Parent = Parent->_Left; /*0x141103cdf*/
                }
                else
                {
                  LODWORD(v36._Ptr) = 0; /*0x141103cca*/
                  Parent = Parent->_Right; /*0x141103cce*/
                }
              }
              while ( Parent->_Isnil == 0 ); /*0x141103ce6*/
            }
            if ( inserted->_Isnil != 0 /*0x141103cf3*/
              || (v25 = *(_DWORD *)inserted->_Myval.first._Mypair._Myval2._Bx._Buf, v11->reliableMessageNumber.val < v25) )
            {
              if ( this->resendBuffer2._Mypair._Myval2._Myval2._Mysize == 0x555555555555555LL ) /*0x141103d03*/
                std::_Throw_tree_length_error(); /*0x141103f01*/
              v35._Al = (std::allocator<std::_List_node<std::pair<__int64 const ,std::vector<RBX::Permission> >,void *> > *)&this->resendBuffer2; /*0x141103d09*/
              __wind /*0xf1c0000000000010*/
              {
                v35._Ptr = nullptr; /*0x141103d0e*/
                v26 = (std::_Tree_node<std::pair<std::string const ,std::shared_ptr<std::string const > >,void *> *)operator new(size: 0x30u); /*0x141103d18*/
              }
              __unwind
              {
                std::_Alloc_construct_ptr<std::allocator<std::_List_node<std::pair<RBX::Primitive * const,RBX::StreamRegion::IdExtents>,void *>>>::~_Alloc_construct_ptr<std::allocator<std::_List_node<std::pair<RBX::Primitive * const,RBX::StreamRegion::IdExtents>,void *>>>(this: &v35); /*0xf1c0000000000008*/
              }
              *(_DWORD *)v26->_Myval.first._Mypair._Myval2._Bx._Buf = v11->reliableMessageNumber.val; /*0x141103d20*/
              *(_QWORD *)&v26->_Myval.first._Mypair._Myval2._Bx._Alias[8] = 0; /*0x141103d23*/
              v26->_Left = (std::_Tree_node<std::pair<std::string const ,std::shared_ptr<std::string const > >,void *> *)Myhead; /*0x141103d27*/
              v26->_Parent = (std::_Tree_node<std::pair<std::string const ,std::shared_ptr<std::string const > >,void *> *)Myhead; /*0x141103d2a*/
              v26->_Right = (std::_Tree_node<std::pair<std::string const ,std::shared_ptr<std::string const > >,void *> *)Myhead; /*0x141103d2e*/
              *(_WORD *)&v26->_Color = 0; /*0x141103d32*/
              v35 = v36; /*0x141103d3d*/
              inserted = std::_Tree_val<std::_Tree_simple_types<std::pair<RBX::Assembly * const,int>>>::_Insert_node( /*0x141103d52*/
                           this: (std::_Tree_val<std::_Tree_simple_types<std::pair<std::string const ,std::shared_ptr<std::string const > > > > *)&this->resendBuffer2,
                           _Loc: (const std::_Tree_id<std::_Tree_node<std::pair<std::string const ,std::shared_ptr<std::string const > >,void *> *> *)&v35,
                           _Newnode: v26);
            }
            v27 = *(RakNet::InternalPacket **)&inserted->_Myval.first._Mypair._Myval2._Bx._Alias[8]; /*0x141103d55*/
            if ( v27 != nullptr ) /*0x141103d5c*/
            {
              ListRemove(linkedListHead: &this->resendLinkedListHead2, internalPacket: v27); /*0x141103d65*/
              RakNet::ReliabilityLayer::ReleaseToInternalPacketPool( /*0x141103d71*/
                this,
                ip: *(DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage **)&inserted->_Myval.first._Mypair._Myval2._Bx._Alias[8]);
            }
            *(_QWORD *)&inserted->_Myval.first._Mypair._Myval2._Bx._Alias[8] = v11; /*0x141103d76*/
            v11->nextActionTime = time /*0x141103d8e*/
                                + 2
                                * (__int64)this->congestionManager->GetRTOForRetransmission(this: this->congestionManager);
            result = this->resendLinkedListHead2; /*0x141103d92*/
            if ( result != nullptr ) /*0x141103d9c*/
            {
              v11->resendNext = result; /*0x141103db2*/
              resendPrev = this->resendLinkedListHead2->resendPrev; /*0x141103dbd*/
              v11->resendPrev = resendPrev; /*0x141103dc1*/
              resendPrev->resendNext = v11; /*0x141103dc5*/
              this->resendLinkedListHead2->resendPrev = v11; /*0x141103dd0*/
              return nullptr; /*0x141103dd4*/
            }
            else
            {
              v11->resendNext = v11; /*0x141103d9e*/
              v11->resendPrev = v11; /*0x141103da2*/
              this->resendLinkedListHead2 = v11; /*0x141103da6*/
            }
          }
          return result; /*0x141103dad*/
        }
LABEL_26:
        v20 = true; /*0x141103c55*/
        goto LABEL_27; /*0x141103c55*/
      }
      v18 = RakNet::ReliabilityLayer::AllocateFromInternalPacketPool(this); /*0x141103be6*/
      ackReceipt = &v18->userMemory; /*0x141103be9*/
      v18->userMemory.allocationScheme = 0; /*0x141103bf1*/
      v19 = (unsigned __int8 *)RBX::Memory::allocate(size: 5u); /*0x141103bf9*/
      v18->userMemory.data = v19; /*0x141103bfe*/
      v18->userMemory.dataBitLength = 40; /*0x141103c02*/
      *v19 = 14; /*0x141103c09*/
      *(_DWORD *)(v18->userMemory.data + 1) = v11->sendReceiptSerial; /*0x141103c13*/
      DataStructures::Queue<RakNet::RakPeer::RequestedConnectionStruct *>::Push( /*0x141103c2f*/
        this: &this->outputQueue,
        input: &ackReceipt,
        file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
        line: 0xC03u);
      reliability = v11->reliability; /*0x141103c34*/
    }
    if ( reliability == 2 || reliability == 4 || reliability == 3 ) /*0x141103c46*/
      goto LABEL_26; /*0x141103c46*/
    goto LABEL_24; /*0x141103c46*/
  }
  if ( DFFlag::GameLoadDataStatistics.value ) /*0x141103df4*/
  {
    v30 = this->resendBuffer2._Mypair._Myval2._Myval2._Myhead->_Parent; /*0x141103e01*/
    v31 = this->resendBuffer2._Mypair._Myval2._Myval2._Myhead; /*0x141103e05*/
    while ( v30->_Isnil == 0 ) /*0x141103e0f*/
    {
      if ( v30->_Myval.first.val >= v7 ) /*0x141103e15*/
      {
        v31 = v30; /*0x141103e1d*/
        v30 = v30->_Left; /*0x141103e20*/
      }
      else
      {
        v30 = v30->_Right; /*0x141103e17*/
      }
    }
    if ( v31->_Isnil == 0 && v7 >= v31->_Myval.first.val && v31 != this->resendBuffer2._Mypair._Myval2._Myval2._Myhead ) /*0x141103e43*/
    {
      second = (DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *)v31->_Myval.second; /*0x141103e49*/
      timesAck = second->userMemory.timesAck + 1; /*0x141103e51*/
      second->userMemory.timesAck = timesAck; /*0x141103e53*/
      if ( !DFFlag::RCCJoinTransmissionStats.value && second->userMemory.isJoinData ) /*0x141103e5f*/
      {
        this->statistics.ds.totalJoinDataAckSize_DEPRECATED += ((second->userMemory.headerLength + 7) >> 3) /*0x141103e79*/
                                                             + ((second->userMemory.dataBitLength + 7) >> 3);
        timesAck = second->userMemory.timesAck; /*0x141103e80*/
      }
      if ( timesAck == second->userMemory.timesSent ) /*0x141103e87*/
      {
        std::_Tree<std::_Tset_traits<RBX::HttpRequestPrio,std::less<RBX::HttpRequestPrio>,std::allocator<RBX::HttpRequestPrio>,0>>::erase( /*0x141103e98*/
          this: (std::_Tree<std::_Tmap_traits<unsigned int,cricket::WebRtcVideoChannel::WebRtcVideoReceiveStream *,std::less<unsigned int>,std::allocator<std::pair<unsigned int const ,cricket::WebRtcVideoChannel::WebRtcVideoReceiveStream *> >,0> > *)&this->resendBuffer2,
          result: (std::_Tree_iterator<std::_Tree_val<std::_Tree_simple_types<std::pair<unsigned int const ,cricket::WebRtcVideoChannel::WebRtcVideoReceiveStream *> > > > *)&ackReceipt,
          _Where: (std::_Tree_iterator<std::_Tree_val<std::_Tree_simple_types<std::pair<unsigned int const ,cricket::WebRtcVideoChannel::WebRtcVideoReceiveStream *> > > >)v31);
        second->userMemory.resendPrev->resendNext = second->userMemory.resendNext; /*0x141103ea5*/
        second->userMemory.resendNext->resendPrev = second->userMemory.resendPrev; /*0x141103eb1*/
        if ( (DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *)this->resendLinkedListHead2 == second ) /*0x141103ebf*/
        {
          resendNext = second->userMemory.resendNext; /*0x141103ec1*/
          this->resendLinkedListHead2 = resendNext; /*0x141103ec5*/
          if ( resendNext == (RakNet::InternalPacket *)second ) /*0x141103ecf*/
            this->resendLinkedListHead2 = nullptr; /*0x141103ed1*/
        }
        RakNet::ReliabilityLayer::ReleaseToInternalPacketPool(this, ip: second); /*0x141103ede*/
      }
    }
  }
  return (RakNet::InternalPacket *)0xFFFFFFFFLL; /*0x141103ee8*/
}

// Address: 0x141103f10 | Name: ?ResendListRemove@ReliabilityLayer@RakNet@@AEAAXPEAUInternalPacket@2@_N@Z
void __fastcall RakNet::ReliabilityLayer::ResendListRemove(
        RakNet::ReliabilityLayer *this,
        RakNet::InternalPacket *internalPacket,
        bool modifyUnacknowledgedBytes)
{
  RakNet::InternalPacket *resendNext; // rax
  unsigned int unacknowledgedDataGrams; // eax

  internalPacket->resendPrev->resendNext = internalPacket->resendNext; /*0x141103f26*/
  internalPacket->resendNext->resendPrev = internalPacket->resendPrev; /*0x141103f34*/
  if ( this->resendLinkedListHead == internalPacket ) /*0x141103f4c*/
  {
    resendNext = internalPacket->resendNext; /*0x141103f4e*/
    this->resendLinkedListHead = resendNext; /*0x141103f52*/
    if ( resendNext == internalPacket ) /*0x141103f5c*/
      this->resendLinkedListHead = nullptr; /*0x141103f5e*/
  }
  if ( modifyUnacknowledgedBytes ) /*0x141103f6c*/
  {
    unacknowledgedDataGrams = this->unacknowledgedDataGrams; /*0x141103f74*/
    this->unacknowledgedBytes -= (internalPacket->headerLength + internalPacket->dataBitLength + 7) >> 3; /*0x141103f83*/
    if ( unacknowledgedDataGrams != 0 ) /*0x141103f8c*/
      this->unacknowledgedDataGrams = unacknowledgedDataGrams - 1; /*0x141103f90*/
  }
}

// Address: 0x141104030 | Name: ?Reset@ReliabilityLayer@RakNet@@QEAAX_NH0@Z
void __fastcall RakNet::ReliabilityLayer::Reset(
        RakNet::ReliabilityLayer *this,
        bool resetVariables,
        int MTUSize,
        bool _useSecurity)
{
  RakNet::CCRakNetBase *congestionManager; // rdi
  void (__fastcall *Init)(RakNet::CCRakNetBase *, unsigned __int64, unsigned int); // rbx
  unsigned __int64 TimeUS; // rax

  RakNet::ReliabilityLayer::FreeThreadSafeMemory(this); /*0x141104048*/
  if ( resetVariables ) /*0x14110404f*/
  {
    RakNet::ReliabilityLayer::InitializeVariables(this); /*0x141104054*/
  }
  else if ( !DFFlag::RakNetUseSlidingWindow4.value ) /*0x141104062*/
  {
    return; /*0x141104062*/
  }
  congestionManager = this->congestionManager; /*0x141104064*/
  Init = congestionManager->Init; /*0x141104070*/
  TimeUS = RakNet::GetTimeUS(isNetworkSynced: false); /*0x141104074*/
  Init(this: congestionManager, a2: TimeUS, a3: MTUSize - 58); /*0x141104083*/
}

// Address: 0x1411040a0 | Name: ?Send@ReliabilityLayer@RakNet@@QEAA_NPEADIW4PacketPriority@@W4PacketReliability@@E_NH_KIH3@Z
char __fastcall RakNet::ReliabilityLayer::Send(
        RakNet::ReliabilityLayer *this,
        char *data,
        unsigned int numberOfBitsToSend,
        unsigned int priority,
        unsigned int reliability,
        unsigned __int8 orderingChannel,
        bool makeDataCopy,
        int MTUSize,
        unsigned __int64 currentTime,
        unsigned int receipt,
        unsigned int ruppLength,
        bool isJoinData)
{
  unsigned int v12; // eax
  unsigned __int8 v15; // r15
  unsigned int v16; // r14d
  DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *v18; // rdi
  unsigned __int8 *stackData; // rax
  int v20; // ebx
  unsigned int v21; // eax
  unsigned int v22; // r8d
  PacketReliability v23; // ecx
  PacketReliability v24; // eax
  unsigned int v25; // eax
  unsigned int v26; // eax
  PacketReliability v27; // eax
  RakNet::InternalPacket *unreliableLinkedListHead; // rax
  RakNet::InternalPacket *unreliablePrev; // rcx
  RBX::Security::RakPeerCrypto *NextWeight; // rax
  unsigned int list_size; // ebx
  RBX::Security::RakPeerCrypto *v32; // rbp
  DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::HeapNode *listArray; // r8
  unsigned int v34; // ecx
  DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::HeapNode v35; // xmm0
  __int64 v36; // rax
  DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::HeapNode v37; // xmm1
  DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::HeapNode input; // [rsp+20h] [rbp-48h] BYREF
  unsigned int v40; // [rsp+88h] [rbp+20h]
  PacketReliability v41; // [rsp+90h] [rbp+28h]

  v12 = reliability; /*0x1411040b0*/
  if ( reliability > 7 ) /*0x1411040c9*/
    v12 = 2; /*0x1411040c9*/
  v41 = v12; /*0x1411040d0*/
  if ( priority > 4 ) /*0x1411040dc*/
    priority = 1; /*0x1411040dc*/
  v15 = 0; /*0x1411040e8*/
  v40 = priority; /*0x1411040eb*/
  if ( orderingChannel < 0x20u ) /*0x1411040f5*/
    v15 = orderingChannel; /*0x1411040f5*/
  v16 = (numberOfBitsToSend + 7) >> 3; /*0x1411040f9*/
  if ( numberOfBitsToSend == 0 ) /*0x141104100*/
    return 0; /*0x141104102*/
  v18 = RakNet::ReliabilityLayer::AllocateFromInternalPacketPool(this); /*0x14110411d*/
  if ( v18 != nullptr ) /*0x141104123*/
  {
    if ( isJoinData ) /*0x141104167*/
      this->statistics.ds.totalJoinDataRakPeerSent += v16; /*0x141104169*/
    this->statistics.ds.totalBytesRakPeerSent += v16; /*0x14110417f*/
    RakNet::BPSTracker::Push1(this: this->bpsMetrics, time: currentTime, value1: v16); /*0x14110418c*/
    v18->userMemory.creationTime = currentTime; /*0x141104199*/
    if ( makeDataCopy ) /*0x14110419d*/
    {
      if ( v16 > 0x80 ) /*0x1411041a6*/
      {
        v18->userMemory.allocationScheme = 0; /*0x1411041bb*/
        stackData = (unsigned __int8 *)RBX::Memory::allocate(size: v16); /*0x1411041c2*/
      }
      else
      {
        v18->userMemory.allocationScheme = STACK; /*0x1411041a8*/
        stackData = v18->userMemory.stackData; /*0x1411041af*/
      }
      v18->userMemory.data = stackData; /*0x1411041ca*/
      memcpy_0(a1: stackData, Src: data, Size: v16); /*0x1411041d4*/
    }
    else
    {
      v18->userMemory.allocationScheme = 0; /*0x1411041db*/
      v18->userMemory.data = (unsigned __int8 *)data; /*0x1411041e2*/
    }
    v20 = dword_1451BE378; /*0x1411041f6*/
    v18->userMemory.dataBitLength = numberOfBitsToSend; /*0x1411041fc*/
    v21 = this->internalOrderIndex.val++ & 0xFFFFFF; /*0x141104207*/
    HIBYTE(this->internalOrderIndex.val) = 0; /*0x141104217*/
    v18->userMemory.messageInternalOrder.val = v21; /*0x14110421e*/
    v18->userMemory.priority = v40; /*0x141104228*/
    v18->userMemory.reliability = v41; /*0x141104232*/
    v18->userMemory.sendReceiptSerial = receipt; /*0x14110423c*/
    v18->userMemory.isJoinData = isJoinData; /*0x14110423f*/
    v22 = RakNet::ReliabilityLayer::GetMaxDatagramSizeExcludingMessageHeaderBytes(this, ruppLength) /*0x141104256*/
        - ((unsigned int)(v20 + 7) >> 3);
    if ( v16 > v22 ) /*0x14110425c*/
    {
      v23 = v18->userMemory.reliability; /*0x14110425e*/
      if ( v23 != UNRELIABLE ) /*0x141104263*/
      {
        if ( v23 == UNRELIABLE_WITH_ACK_RECEIPT ) /*0x141104271*/
        {
          v18->userMemory.reliability = RELIABLE_WITH_ACK_RECEIPT; /*0x141104273*/
        }
        else if ( v23 == UNRELIABLE_SEQUENCED ) /*0x14110427f*/
        {
          v18->userMemory.reliability = RELIABLE_SEQUENCED; /*0x141104281*/
        }
      }
      else
      {
        v18->userMemory.reliability = RELIABLE; /*0x141104265*/
      }
    }
    v24 = v18->userMemory.reliability; /*0x141104288*/
    if ( v24 == RELIABLE_SEQUENCED || v24 == UNRELIABLE_SEQUENCED ) /*0x141104293*/
    {
      v18->userMemory.orderingChannel = v15; /*0x1411042d6*/
      v18->userMemory.orderingIndex.val = this->orderedWriteIndex[v15].val; /*0x1411042e5*/
      v26 = this->sequencedWriteIndex[v15].val++ & 0xFFFFFF; /*0x1411042f1*/
      HIBYTE(this->sequencedWriteIndex[v15].val) = 0; /*0x1411042ff*/
      v18->userMemory.sequencingIndex.val = v26; /*0x141104307*/
    }
    else if ( ((v24 - 3) & 0xFFFFFFFB) == 0 ) /*0x14110429d*/
    {
      v18->userMemory.orderingChannel = v15; /*0x1411042a3*/
      v25 = this->orderedWriteIndex[v15].val++ & 0xFFFFFF; /*0x1411042b0*/
      HIBYTE(this->orderedWriteIndex[v15].val) = 0; /*0x1411042be*/
      v18->userMemory.orderingIndex.val = v25; /*0x1411042c6*/
      this->sequencedWriteIndex[v15].val = 0; /*0x1411042c9*/
    }
    if ( v16 <= v22 ) /*0x14110430d*/
    {
      v27 = v18->userMemory.reliability; /*0x141104322*/
      if ( (v27 & 0xFFFFFFFA) == 0 && v27 != RELIABLE_SEQUENCED ) /*0x14110432f*/
      {
        unreliableLinkedListHead = this->unreliableLinkedListHead; /*0x141104331*/
        if ( unreliableLinkedListHead != nullptr ) /*0x14110433b*/
        {
          v18->userMemory.unreliableNext = unreliableLinkedListHead; /*0x141104351*/
          unreliablePrev = this->unreliableLinkedListHead->unreliablePrev; /*0x14110435f*/
          v18->userMemory.unreliablePrev = unreliablePrev; /*0x141104363*/
          unreliablePrev->unreliableNext = &v18->userMemory; /*0x141104367*/
          this->unreliableLinkedListHead->unreliablePrev = &v18->userMemory; /*0x141104375*/
        }
        else
        {
          v18->userMemory.unreliableNext = &v18->userMemory; /*0x14110433d*/
          v18->userMemory.unreliablePrev = &v18->userMemory; /*0x141104344*/
          this->unreliableLinkedListHead = &v18->userMemory; /*0x141104348*/
        }
      }
      NextWeight = RakNet::ReliabilityLayer::GetNextWeight(this, priorityLevel: v18->userMemory.priority); /*0x14110437f*/
      list_size = this->outgoingPacketBuffer.heap.list_size; /*0x141104384*/
      input.weight = (unsigned __int64)NextWeight; /*0x141104397*/
      input.data = &v18->userMemory; /*0x1411043a1*/
      v32 = NextWeight; /*0x1411043ad*/
      DataStructures::List<DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::HeapNode>::Insert( /*0x1411043b0*/
        this: &this->outgoingPacketBuffer.heap,
        &input,
        file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
        line: 0x75Bu);
      if ( list_size != 0 ) /*0x1411043b7*/
      {
        do /*0x1411043fa*/
        {
          listArray = this->outgoingPacketBuffer.heap.listArray; /*0x1411043c0*/
          v34 = (list_size - 1) >> 1; /*0x1411043ca*/
          if ( listArray[v34].weight <= (unsigned __int64)v32 ) /*0x1411043d5*/
            break; /*0x1411043d5*/
          v35 = listArray[(list_size - 1) >> 1]; /*0x1411043d7*/
          v36 = list_size; /*0x1411043dc*/
          list_size = (list_size - 1) >> 1; /*0x1411043de*/
          v36 *= 2; /*0x1411043e0*/
          v37 = *(DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::HeapNode *)((char *)listArray /*0x1411043e3*/
                                                                                               + 8 * v36);
          *(DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::HeapNode *)((char *)listArray + 8 * v36) = v35; /*0x1411043e8*/
          this->outgoingPacketBuffer.heap.listArray[v34] = v37; /*0x1411043f4*/
        }
        while ( v34 != 0 ); /*0x1411043fa*/
      }
      ++this->statistics.messageInSendBuffer[v18->userMemory.priority]; /*0x141104403*/
      this->statistics.bytesInSendBuffer[v18->userMemory.priority] = (double)((v18->userMemory.dataBitLength + 7) >> 3) /*0x141104425*/
                                                                   + this->statistics.bytesInSendBuffer[v18->userMemory.priority];
    }
    else
    {
      RakNet::ReliabilityLayer::SplitPacket(this, internalPacket: &v18->userMemory, ruppLength); /*0x141104318*/
    }
    return 1; /*0x141104433*/
  }
  else
  {
    RakNet::notifyOutOfMemory( /*0x141104131*/
      file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
      line: 1778);
    return 0; /*0x14110413b*/
  }
}

// Address: 0x141104450 | Name: ?SendACKs@ReliabilityLayer@RakNet@@AEAAXV?$shared_ptr@URakNetSocket@RakNet@@@std@@AEBUSystemAddress@2@_KAEAVBitStream@2@AEBV?$shared_ptr@VRupp@1Network@RBX@@@4@1@Z
void __fastcall RakNet::ReliabilityLayer::SendACKs(
        RakNet::ReliabilityLayer *this,
        std::shared_ptr<RBX::File> *socket,
        const RakNet::SystemAddress *systemAddress,
        unsigned __int64 time,
        RakNet::BitStream *updateBitStream,
        const std::shared_ptr<RBX::Network::Rupp::Rupp> *ruppHeader,
        const RakNet::SystemAddress *udmuxAddress)
{
  unsigned __int64 v7; // r14
  std::shared_ptr<RakNet::RakNetSocket> *v8; // r15
  const std::shared_ptr<RBX::Network::Rupp::Rupp> *v10; // rdi
  unsigned int HeaderTotalByteLength; // edx
  unsigned int v12; // ebx
  bool v13; // r12
  RakNet::BitStream *v14; // rsi
  bool v15; // al
  unsigned __int64 sourceSystemTime; // rcx
  bool v17; // di
  bool v18; // bl
  bool v19; // r15
  bool v20; // r14
  unsigned __int8 *v21; // rdx
  unsigned __int8 *v22; // rdx
  unsigned int numberOfBitsUsed; // edi
  unsigned __int64 v24; // rbx
  unsigned __int64 v25; // rcx
  bool IsNetworkOrder; // al
  unsigned __int8 *v27; // rcx
  unsigned __int8 v28; // al
  unsigned __int8 v29; // bl
  bool v30; // al
  unsigned __int8 *v31; // rcx
  unsigned __int8 v32; // al
  std::_Ref_count_base *Rep; // rcx
  RakNet::CCRakNetBase *congestionManager; // rdi
  void (__fastcall *OnSendAck)(RakNet::CCRakNetBase *, unsigned __int64, unsigned int); // rbx
  unsigned int v36; // eax
  volatile signed __int32 *v37; // rbx
  int v38; // [rsp+44h] [rbp-7Dh]
  unsigned __int8 v39[8]; // [rsp+48h] [rbp-79h] BYREF
  RakNet::DatagramHeaderFormat dhf; // [rsp+50h] [rbp-71h] BYREF
  unsigned __int8 inByteArray[4]; // [rsp+70h] [rbp-51h] BYREF
  unsigned __int8 v42[4]; // [rsp+74h] [rbp-4Dh] BYREF
  unsigned int paddingLocation; // [rsp+78h] [rbp-49h]
  unsigned int maxBits; // [rsp+7Ch] [rbp-45h]
  unsigned __int8 inOutByteArray[4]; // [rsp+80h] [rbp-41h] BYREF
  unsigned __int8 v46[4]; // [rsp+84h] [rbp-3Dh] BYREF
  unsigned __int8 v47[8]; // [rsp+88h] [rbp-39h] BYREF
  unsigned __int64 newestUnsentAck; // [rsp+90h] [rbp-31h] BYREF
  unsigned __int64 oldestUnsentAck; // [rsp+98h] [rbp-29h] BYREF
  std::shared_ptr<RakNet::RakNetSocket> v50; // [rsp+A0h] [rbp-21h] BYREF
  double AS; // [rsp+B0h] [rbp-11h] BYREF
  long double B[9]; // [rsp+B8h] [rbp-9h] BYREF
  bool hasBAndAS; // [rsp+110h] [rbp+4Fh] BYREF
  std::shared_ptr<RakNet::RakNetSocket> *v54; // [rsp+118h] [rbp+57h]
  const RakNet::SystemAddress *v55; // [rsp+120h] [rbp+5Fh]
  unsigned __int64 v56; // [rsp+128h] [rbp+67h]

  v56 = time; /*0x141104450*/
  v55 = systemAddress; /*0x141104455*/
  v54 = (std::shared_ptr<RakNet::RakNetSocket> *)socket; /*0x14110445a*/
  __wind /*0xf1c0000000000010*/
  {
    v7 = time; /*0x141104477*/
    v8 = (std::shared_ptr<RakNet::RakNetSocket> *)socket; /*0x14110447a*/
    v10 = ruppHeader; /*0x141104480*/
    if ( DFFlag::RuppHeaderFromClientEnabled3.value && ruppHeader->_Ptr != nullptr ) /*0x141104493*/
      HeaderTotalByteLength = RBX::Network::Rupp::Rupp::getHeaderTotalByteLength(this: ruppHeader->_Ptr); /*0x14110449a*/
    else
      HeaderTotalByteLength = 0; /*0x14110449f*/
    v12 = 8 /*0x1411044ab*/
        * RakNet::ReliabilityLayer::GetMaxDatagramSizeExcludingMessageHeaderBytes(
            this,
            ruppLength: HeaderTotalByteLength);
    maxBits = v12; /*0x1411044ae*/
    v13 = this->congestionManager->GetAckTimestamps( /*0x1411044cd*/
            this: this->congestionManager,
            a2: &oldestUnsentAck,
            a3: &newestUnsentAck);
    if ( v13 ) /*0x1411044d3*/
      maxBits = v12 - 6; /*0x1411044d8*/
    if ( this->acknowlegements.ranges.orderedList.list_size != 0 ) /*0x1411044e3*/
    {
      v14 = updateBitStream; /*0x1411044e9*/
      while ( 1 ) /*0x1411044f3*/
      {
        RakNet::BitStream::Reset(this: v14); /*0x1411044f3*/
        if ( DFFlag::RuppHeaderFromClientEnabled3.value && v10->_Ptr != nullptr ) /*0x141104507*/
          RBX::Network::Rupp::Rupp::serialize(this: v10->_Ptr, b: v14); /*0x14110450c*/
        *(_WORD *)&dhf.isJoinData = 0; /*0x141104511*/
        *(_WORD *)&dhf.isACK = 1; /*0x141104517*/
        dhf.hasAckTimestamps = v13; /*0x14110451d*/
        v15 = this->congestionManager->includeTimestampWithDatagrams(this: this->congestionManager); /*0x14110452b*/
        sourceSystemTime = dhf.sourceSystemTime; /*0x141104531*/
        if ( v15 ) /*0x141104537*/
          sourceSystemTime = v7; /*0x141104537*/
        dhf.sourceSystemTime = sourceSystemTime; /*0x14110453b*/
        if ( this->remoteSystemNeedsBAndAS ) /*0x14110453f*/
        {
          this->congestionManager->OnSendAckGetBAndAS( /*0x141104567*/
            this: this->congestionManager,
            a2: v7,
            a3: &hasBAndAS,
            a4: B,
            a5: &AS);
          dhf.AS = AS; /*0x141104576*/
          dhf.hasBAndAS = hasBAndAS; /*0x14110457f*/
        }
        else
        {
          dhf.hasBAndAS = false; /*0x141104584*/
        }
        if ( this->congestionManager->includeTimestampWithDatagrams(this: this->congestionManager) ) /*0x141104592*/
          dhf.sourceSystemTime = this->nextAckTimeToSend; /*0x1411045a3*/
        if ( !DFFlag::RuppHeaderFromClientEnabled3.value ) /*0x1411045ae*/
          RakNet::BitStream::Reset(this: v14); /*0x1411045b3*/
        v17 = (this->commonCapabilities & 0x800000) != 0; /*0x1411045c6*/
        v18 = (this->commonCapabilities & 0x200000) != 0; /*0x1411045d1*/
        v19 = (this->commonCapabilities & 0x8000) != 0; /*0x1411045d8*/
        v20 = this->congestionManager->includeTimestampWithDatagrams(this: this->congestionManager); /*0x1411045ec*/
        RakNet::BitStream::Write1(this: v14); /*0x1411045f3*/
        if ( dhf.isACK ) /*0x1411045ff*/
          break; /*0x1411045ff*/
        if ( !dhf.isNAK ) /*0x1411046e5*/
        {
          RakNet::BitStream::Write0(this: v14); /*0x141104713*/
          RakNet::BitStream::Write0(this: v14); /*0x14110471b*/
          if ( v18 ) /*0x141104722*/
          {
            if ( dhf.isJoinData ) /*0x14110472b*/
              RakNet::BitStream::Write1(this: v14); /*0x14110472d*/
            else
              RakNet::BitStream::Write0(this: v14); /*0x141104734*/
          }
          if ( v17 ) /*0x14110473c*/
          {
            if ( dhf.isResentData ) /*0x141104745*/
              RakNet::BitStream::Write1(this: v14); /*0x141104747*/
            else
              RakNet::BitStream::Write0(this: v14); /*0x14110474e*/
          }
          RakNet::BitStream::Write0(this: v14); /*0x141104756*/
          if ( dhf.isContinuousSend ) /*0x141104762*/
            RakNet::BitStream::Write1(this: v14); /*0x141104764*/
          else
            RakNet::BitStream::Write0(this: v14); /*0x14110476b*/
          if ( dhf.needsBAndAs ) /*0x141104777*/
            RakNet::BitStream::Write1(this: v14); /*0x141104779*/
          else
            RakNet::BitStream::Write0(this: v14); /*0x141104780*/
          v14->numberOfBitsUsed = v14->numberOfBitsUsed - (((unsigned __int8)v14->numberOfBitsUsed - 1) & 7) + 7; /*0x141104793*/
          if ( v20 ) /*0x141104799*/
          {
            *(_DWORD *)v42 = dhf.sourceSystemTime; /*0x14110479e*/
            if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1411047a1*/
            {
              v22 = v42; /*0x1411047c3*/
            }
            else
            {
              RBX::Network::NetworkStream::ReverseBytes(inByteArray: v42, inOutByteArray: v47, length: 4u); /*0x1411047b8*/
              v22 = v47; /*0x1411047bd*/
            }
            RakNet::BitStream::WriteBits( /*0x1411047d3*/
              this: v14,
              inByteArray: v22,
              numberOfBitsToWrite: 0x20u,
              rightAlignedBits: true);
          }
          RakNet::BitStream::Write<RakNet::uint24_t>(this: v14, inTemplateVar: &dhf.datagramNumber); /*0x1411047df*/
LABEL_61:
          if ( v19 ) /*0x1411047e7*/
            goto LABEL_62; /*0x1411047e7*/
          goto LABEL_65; /*0x1411047e7*/
        }
        RakNet::BitStream::Write0(this: v14); /*0x1411046e7*/
        RakNet::BitStream::Write1(this: v14); /*0x1411046ef*/
        if ( v19 ) /*0x1411046f7*/
        {
          v14->numberOfBitsUsed = v14->numberOfBitsUsed - (((unsigned __int8)v14->numberOfBitsUsed - 1) & 7) + 7; /*0x14110470b*/
LABEL_62:
          numberOfBitsUsed = v14->numberOfBitsUsed; /*0x1411047e9*/
          paddingLocation = numberOfBitsUsed; /*0x1411047ec*/
          if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1411047ef*/
          {
            RakNet::BitStream::WriteBits( /*0x141104832*/
              this: v14,
              inByteArray: (unsigned __int8 *)&dhf.extraPadding,
              numberOfBitsToWrite: 0x10u,
              rightAlignedBits: true);
          }
          else
          {
            RBX::Network::NetworkStream::ReverseBytes( /*0x141104806*/
              inByteArray: (unsigned __int8 *)&dhf.extraPadding,
              inOutByteArray: v39,
              length: 2u);
            RakNet::BitStream::WriteBits( /*0x14110481b*/
              this: v14,
              inByteArray: v39,
              numberOfBitsToWrite: 0x10u,
              rightAlignedBits: true);
          }
          goto LABEL_66; /*0x141104820*/
        }
LABEL_65:
        numberOfBitsUsed = paddingLocation; /*0x141104839*/
LABEL_66:
        DataStructures::RangeList<RakNet::uint24_t>::Serialize( /*0x14110483c*/
          this: &this->acknowlegements,
          in: v14,
          maxBits,
          clearSerialized: 1u);
        v7 = v56; /*0x141104852*/
        if ( v13 && this->acknowlegements.ranges.orderedList.list_size == 0 ) /*0x141104867*/
        {
          v24 = v56 - oldestUnsentAck; /*0x141104870*/
          oldestUnsentAck = v24; /*0x141104874*/
          v25 = v56 - newestUnsentAck; /*0x14110487b*/
          newestUnsentAck = v56 - newestUnsentAck; /*0x14110487f*/
          if ( v24 - 1 <= 0xFFFFFE && v25 - 1 <= 0xFFFFFE ) /*0x14110489d*/
          {
            v14->numberOfBitsUsed = v14->numberOfBitsUsed - (((unsigned __int8)v14->numberOfBitsUsed - 1) & 7) + 7; /*0x1411048bb*/
            RakNet::BitStream::AddBitsAndReallocate(this: v14, numberOfBitsToWrite: 0x18u); /*0x1411048c6*/
            IsNetworkOrder = RakNet::BitStream::IsNetworkOrder(); /*0x1411048cb*/
            v27 = &v14->data[(unsigned __int64)v14->numberOfBitsUsed >> 3]; /*0x1411048d7*/
            if ( IsNetworkOrder ) /*0x1411048dd*/
            {
              *v27 = BYTE3(v24); /*0x1411048fe*/
              v14->data[(v14->numberOfBitsUsed >> 3) + 1] = BYTE2(v24); /*0x141104910*/
              v28 = BYTE1(v24); /*0x141104913*/
            }
            else
            {
              *v27 = v24; /*0x1411048df*/
              v14->data[(v14->numberOfBitsUsed >> 3) + 1] = BYTE1(v24); /*0x1411048f1*/
              v28 = BYTE2(v24); /*0x1411048f4*/
            }
            v14->data[(v14->numberOfBitsUsed >> 3) + 2] = v28; /*0x141104924*/
            v29 = newestUnsentAck; /*0x141104930*/
            v38 = newestUnsentAck & 0xFFFFFF; /*0x141104936*/
            v14->numberOfBitsUsed = v14->numberOfBitsUsed + 24 - ((LOBYTE(v14->numberOfBitsUsed) + 23) & 7) + 7; /*0x141104944*/
            RakNet::BitStream::AddBitsAndReallocate(this: v14, numberOfBitsToWrite: 0x18u); /*0x14110494f*/
            v30 = RakNet::BitStream::IsNetworkOrder(); /*0x141104954*/
            v31 = &v14->data[(unsigned __int64)v14->numberOfBitsUsed >> 3]; /*0x141104960*/
            if ( v30 ) /*0x141104966*/
            {
              *v31 = HIBYTE(v38); /*0x141104987*/
              v14->data[(v14->numberOfBitsUsed >> 3) + 1] = BYTE2(v38); /*0x141104999*/
              v32 = BYTE1(v38); /*0x14110499c*/
            }
            else
            {
              *v31 = v29; /*0x141104968*/
              v14->data[(v14->numberOfBitsUsed >> 3) + 1] = BYTE1(v38); /*0x14110497a*/
              v32 = BYTE2(v38); /*0x14110497d*/
            }
            v14->data[(v14->numberOfBitsUsed >> 3) + 2] = v32; /*0x1411049ad*/
            v14->numberOfBitsUsed += 24; /*0x1411049b0*/
          }
        }
        v13 = false; /*0x1411049b4*/
        v50 = 0; /*0x1411049ba*/
        v8 = v54; /*0x1411049bf*/
        Rep = v54->_Rep; /*0x1411049c3*/
        if ( Rep != nullptr ) /*0x1411049ca*/
        {
          _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x1411049cc*/
          Rep = v8->_Rep; /*0x1411049d0*/
        }
        v50._Ptr = v8->_Ptr; /*0x1411049d7*/
        v50._Rep = Rep; /*0x1411049db*/
        RakNet::ReliabilityLayer::SendBitStream( /*0x141104a08*/
          this,
          socket: &v50,
          systemAddress: v55,
          bitStream: v14,
          currentTime: v7,
          ruppHeader,
          udmuxAddress,
          paddingLocation: numberOfBitsUsed);
        congestionManager = this->congestionManager; /*0x141104a0d*/
        OnSendAck = congestionManager->OnSendAck; /*0x141104a17*/
        v36 = v14->GetNumberOfBytesUsed(this: v14); /*0x141104a24*/
        OnSendAck(this: congestionManager, a2: v7, a3: v36); /*0x141104a30*/
        v10 = ruppHeader; /*0x141104a3a*/
        if ( this->acknowlegements.ranges.orderedList.list_size == 0 ) /*0x141104a3e*/
          goto LABEL_86; /*0x141104a3e*/
      }
      RakNet::BitStream::Write1(this: v14); /*0x141104605*/
      if ( dhf.hasBAndAS ) /*0x141104611*/
        RakNet::BitStream::Write1(this: v14); /*0x141104613*/
      else
        RakNet::BitStream::Write0(this: v14); /*0x14110461a*/
      if ( dhf.hasAckTimestamps ) /*0x141104626*/
        RakNet::BitStream::Write1(this: v14); /*0x141104628*/
      else
        RakNet::BitStream::Write0(this: v14); /*0x14110462f*/
      v14->numberOfBitsUsed = v14->numberOfBitsUsed - (((unsigned __int8)v14->numberOfBitsUsed - 1) & 7) + 7; /*0x141104642*/
      if ( v20 ) /*0x141104648*/
      {
        *(_DWORD *)inByteArray = dhf.sourceSystemTime; /*0x14110464d*/
        if ( RakNet::BitStream::IsNetworkOrder() ) /*0x141104650*/
        {
          v21 = inByteArray; /*0x141104672*/
        }
        else
        {
          RBX::Network::NetworkStream::ReverseBytes(inByteArray, inOutByteArray, length: 4u); /*0x141104667*/
          v21 = inOutByteArray; /*0x14110466c*/
        }
        RakNet::BitStream::WriteBits(this: v14, inByteArray: v21, numberOfBitsToWrite: 0x20u, rightAlignedBits: true); /*0x141104682*/
      }
      if ( dhf.hasBAndAS ) /*0x14110468b*/
      {
        if ( RakNet::BitStream::IsNetworkOrder() ) /*0x141104691*/
        {
          RakNet::BitStream::WriteBits( /*0x1411046d7*/
            this: v14,
            inByteArray: (unsigned __int8 *)&dhf.AS,
            numberOfBitsToWrite: 0x20u,
            rightAlignedBits: true);
        }
        else
        {
          RBX::Network::NetworkStream::ReverseBytes( /*0x1411046a8*/
            inByteArray: (unsigned __int8 *)&dhf.AS,
            inOutByteArray: v46,
            length: 4u);
          RakNet::BitStream::WriteBits(this: v14, inByteArray: v46, numberOfBitsToWrite: 0x20u, rightAlignedBits: true); /*0x1411046bd*/
        }
      }
      goto LABEL_61; /*0x1411046c2*/
    }
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)v54); /*0xf1c0000000000008*/
  }
LABEL_86:
  v37 = (volatile signed __int32 *)v8->_Rep; /*0x141104a44*/
  if ( v37 != nullptr && _InterlockedExchangeAdd(v37 + 2, 0xFFFFFFFF) == 1 ) /*0x141104a5c*/
  {
    (**(void (__fastcall ***)(volatile signed __int32 *))v37)(a1: v37); /*0x141104a64*/
    if ( _InterlockedExchangeAdd(v37 + 3, 0xFFFFFFFF) == 1 ) /*0x141104a6e*/
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v37 + 8LL))(a1: v37); /*0x141104a76*/
  }
}

// Address: 0x141104a90 | Name: ?SendBitStream@ReliabilityLayer@RakNet@@AEAAXV?$shared_ptr@URakNetSocket@RakNet@@@std@@AEBUSystemAddress@2@PEAVBitStream@2@_KAEBV?$shared_ptr@VRupp@1Network@RBX@@@4@1I@Z
void __fastcall RakNet::ReliabilityLayer::SendBitStream(
        RakNet::ReliabilityLayer *this,
        std::shared_ptr<RBX::File> *socket,
        const RakNet::SystemAddress *systemAddress,
        RakNet::BitStream *bitStream,
        unsigned __int64 currentTime,
        const std::shared_ptr<RBX::Network::Rupp::Rupp> *ruppHeader,
        const RakNet::SystemAddress *udmuxAddress,
        int paddingLocation)
{
  const RakNet::SystemAddress *v9; // r15
  std::shared_ptr<RakNet::RakNetSocket> *v10; // rbx
  __int64 v12; // rbp
  char v13; // di
  RakNet::BitStream_vtbl *v14; // rax
  __int64 v15; // r15
  int v16; // eax
  long double v17; // xmm1_8
  RakNet::CCRakNetBase *congestionManager; // rdi
  void (__fastcall *OnSendBytes)(RakNet::CCRakNetBase *, unsigned __int64, const char *, int, bool); // rbx
  unsigned __int8 *v20; // rax
  unsigned __int16 HeaderTotalByteLength; // r12
  RakNet::BitStream_vtbl *v22; // rax
  RakNet::RakPeer *rakPeer; // rdi
  const char *v24; // r10
  std::_Ref_count_base *Rep; // rcx
  int v26; // eax
  const unsigned __int8 *v27; // r13
  unsigned __int64 v28; // r15
  __int64 v29; // r12
  int v30; // eax
  int v31; // eax
  long double v32; // xmm1_8
  RakNet::CCRakNetBase *v33; // rdi
  void (__fastcall *v34)(RakNet::CCRakNetBase *, unsigned __int64, const char *, int, bool); // rbx
  unsigned __int8 *v35; // rax
  const char *v36; // rax
  int v37; // r15d
  RakNet::CCRakNetBase *v38; // rdi
  void (__fastcall *v39)(RakNet::CCRakNetBase *, unsigned __int64, const char *, int, bool); // rbx
  unsigned __int8 *v40; // rax
  volatile signed __int32 *v41; // rbx
  BOOL srcAddress; // [rsp+20h] [rbp-A8h]
  std::shared_ptr<RakNet::RakNetSocket> v43; // [rsp+60h] [rbp-68h] BYREF
  RBX::MutableArrayView<unsigned char> v44[5]; // [rsp+70h] [rbp-58h] BYREF
  char v45; // [rsp+D0h] [rbp+8h]

  __wind /*0xf1c0000000000010*/
  {
    v9 = systemAddress; /*0x141104ab0*/
    v10 = (std::shared_ptr<RakNet::RakNetSocket> *)socket; /*0x141104ab3*/
    v12 = bitStream->GetNumberOfBytesUsed(this: bitStream); /*0x141104ac2*/
    if ( this->rbxSessionCrypto._Ptr != nullptr /*0x141104ad0*/
      && RBX::Security::SessionCrypto::getEnabledForRaknet(this: this->rbxSessionCrypto._Ptr) )
    {
      v13 = 1; /*0x141104add*/
      v45 = 1; /*0x141104ae0*/
      v14 = bitStream->__vftable; /*0x141104ae8*/
      if ( DFFlag::RuppHeaderRakCryptoFix.value ) /*0x141104af5*/
      {
        v15 = (__int64)v14->GetData(this: bitStream); /*0x141104afe*/
        RakNet::BitStream::PadWithZeroToByteLength(this: bitStream, bytes: v12 + 18); /*0x141104b07*/
        if ( (this->commonCapabilities & 0x8000) != 0 ) /*0x141104b17*/
        {
          v16 = this->congestionManager->GetMTU(this: this->congestionManager); /*0x141104b23*/
          if ( RakNet::ReliabilityLayer::modifyForAvoidedPacketSizes(this, bs: bitStream, mtu: v16, paddingLocation) != 0 ) /*0x141104b48*/
            v17 = 1.0; /*0x141104b4a*/
          else
            v17 = 0.0; /*0x141104b54*/
          RBX::RunningAverage<double,double>::sample(this: &this->paddedPacketsPercentage, value: v17); /*0x141104b57*/
        }
        LODWORD(v12) = bitStream->GetNumberOfBytesUsed(this: bitStream); /*0x141104b65*/
        if ( DFFlag::RakNetUseSlidingWindow4.value ) /*0x141104b6e*/
        {
          congestionManager = this->congestionManager; /*0x141104b70*/
          OnSendBytes = congestionManager->OnSendBytes; /*0x141104b7a*/
          v20 = bitStream->GetData(this: bitStream); /*0x141104b84*/
          OnSendBytes(this: congestionManager, a2: currentTime, a3: (const char *)v20, a4: v12 - 18, a5: true); /*0x141104b9e*/
          v10 = (std::shared_ptr<RakNet::RakNetSocket> *)socket; /*0x141104ba0*/
          v13 = 1; /*0x141104ba8*/
        }
        HeaderTotalByteLength = 0; /*0x141104bab*/
        if ( DFFlag::RuppHeaderFromClientEnabled3.value && ruppHeader->_Ptr != nullptr ) /*0x141104bc5*/
          HeaderTotalByteLength = RBX::Network::Rupp::Rupp::getHeaderTotalByteLength(this: ruppHeader->_Ptr); /*0x141104bcc*/
        v44[0].buffer = (const unsigned __int8 *)(v15 + HeaderTotalByteLength); /*0x141104bd7*/
        v44[0].length = (unsigned int)v12 - HeaderTotalByteLength; /*0x141104be6*/
        RBX::Security::SessionCrypto::encryptRakDataInPlace(this: this->rbxSessionCrypto._Ptr, messageToBox: v44); /*0x141104bf3*/
LABEL_16:
        v9 = systemAddress; /*0x141104bf8*/
        goto LABEL_17; /*0x141104bf8*/
      }
      v27 = v14->GetData(this: bitStream); /*0x141104cbc*/
      v28 = v12 + 18; /*0x141104cbf*/
      LOWORD(v29) = 0; /*0x141104cc3*/
      if ( DFFlag::RuppHeaderFromClientEnabled3.value && ruppHeader->_Ptr != nullptr ) /*0x141104cdd*/
      {
        v29 = RBX::Network::Rupp::Rupp::getHeaderTotalByteLength(this: ruppHeader->_Ptr); /*0x141104ce4*/
        v27 += v29; /*0x141104ce8*/
        v28 -= v29; /*0x141104ceb*/
      }
      RakNet::BitStream::PadWithZeroToByteLength(this: bitStream, bytes: v28); /*0x141104cf4*/
      if ( (this->commonCapabilities & 0x8000) != 0 ) /*0x141104d04*/
      {
        v30 = this->congestionManager->GetMTU(this: this->congestionManager); /*0x141104d10*/
        v31 = RakNet::ReliabilityLayer::modifyForAvoidedPacketSizes(this, bs: bitStream, mtu: v30, paddingLocation); /*0x141104d27*/
        v28 += v31; /*0x141104d2f*/
        LODWORD(v12) = v31 + v12; /*0x141104d32*/
        if ( v31 != 0 ) /*0x141104d3d*/
          v32 = 1.0; /*0x141104d3f*/
        else
          v32 = 0.0; /*0x141104d49*/
        RBX::RunningAverage<double,double>::sample(this: &this->paddedPacketsPercentage, value: v32); /*0x141104d4c*/
      }
      if ( DFFlag::RakNetUseSlidingWindow4.value ) /*0x141104d58*/
      {
        v33 = this->congestionManager; /*0x141104d5a*/
        v34 = v33->OnSendBytes; /*0x141104d64*/
        v35 = bitStream->GetData(this: bitStream); /*0x141104d6e*/
        v34(this: v33, a2: currentTime, a3: (const char *)v35, a4: v12, a5: true); /*0x141104d87*/
        v10 = (std::shared_ptr<RakNet::RakNetSocket> *)socket; /*0x141104d89*/
        v13 = 1; /*0x141104d91*/
      }
      v44[0].buffer = v27; /*0x141104d94*/
      v44[0].length = v28; /*0x141104d99*/
      RBX::Security::SessionCrypto::encryptRakDataInPlace(this: this->rbxSessionCrypto._Ptr, messageToBox: v44); /*0x141104da6*/
      LODWORD(v12) = v28; /*0x141104dab*/
      if ( !DFFlag::RuppHeaderFromClientEnabled3.value ) /*0x141104db5*/
        goto LABEL_16; /*0x141104db5*/
      v9 = systemAddress; /*0x141104dc3*/
      if ( ruppHeader->_Ptr != nullptr ) /*0x141104dcf*/
        LODWORD(v12) = (unsigned __int16)v29 + (_DWORD)v12; /*0x141104dd9*/
    }
    else
    {
      v13 = 0; /*0x141104de0*/
      v45 = 0; /*0x141104de3*/
      this->deadConnection = true; /*0x141104deb*/
    }
LABEL_17:
    RakNet::BPSTracker::Push1(this: &this->bpsMetrics[5], time: currentTime, value1: (unsigned int)v12); /*0x141104c00*/
    v22 = bitStream->__vftable; /*0x141104c1d*/
    if ( FFlag::CLI52064Experiment2.value ) /*0x141104c2a*/
    {
      rakPeer = this->rakPeer; /*0x141104c30*/
      v24 = (const char *)v22->GetData(this: bitStream); /*0x141104c3a*/
      v43 = 0; /*0x141104c40*/
      Rep = v10->_Rep; /*0x141104c46*/
      if ( Rep != nullptr ) /*0x141104c4d*/
      {
        _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x141104c4f*/
        Rep = v10->_Rep; /*0x141104c53*/
      }
      v43._Ptr = v10->_Ptr; /*0x141104c5a*/
      v43._Rep = Rep; /*0x141104c5f*/
      v26 = RakNet::SocketLayer::SendToOrDelay( /*0x141104ca7*/
              socket: &v43,
              data: v24,
              length: v12,
              dstAddress: v9,
              srcAddress: udmuxAddress,
              raknetMetaDataEncrypted: true,
              rakPeer,
              reliabilityLayer: this,
              now: currentTime,
              file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
              line: 2890);
      v13 = v45; /*0x141104cac*/
    }
    else
    {
      v36 = (const char *)v22->GetData(this: bitStream); /*0x141104df7*/
      v26 = RakNet::SocketLayer::SendTo( /*0x141104e2f*/
              s: v10->_Ptr->s,
              data: v36,
              length: v12,
              dstAddress: v9,
              srcAddress: udmuxAddress,
              raknetMetaDataEncrypted: true,
              file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
              line: 2894);
    }
    v37 = v26; /*0x141104e34*/
    if ( DFFlag::RakNetUseSlidingWindow4.value && v13 == 0 ) /*0x141104e43*/
    {
      v38 = this->congestionManager; /*0x141104e45*/
      v39 = v38->OnSendBytes; /*0x141104e4f*/
      v40 = bitStream->GetData(this: bitStream); /*0x141104e59*/
      LOBYTE(srcAddress) = 0; /*0x141104e5c*/
      v39(this: v38, a2: currentTime, a3: (const char *)v40, a4: v12, a5: srcAddress); /*0x141104e6d*/
      v10 = (std::shared_ptr<RakNet::RakNetSocket> *)socket; /*0x141104e6f*/
    }
    if ( bitStream->isJoinData ) /*0x141104e77*/
      this->statistics.ds.totalJoinDataSocketSent += (unsigned int)v12; /*0x141104e7e*/
    if ( DFFlag::RakNetUseSlidingWindow4.value && DFFlag::RakNetReportTransmissionBw2.value ) /*0x141104e95*/
    {
      this->perSecTxBwData.allBytes += v12; /*0x141104e97*/
    }
    else if ( DFFlag::RakNetComputeTxBw.value ) /*0x141104ea6*/
    {
      this->perSecTxBwCounters_deprecated.allBytes += v12; /*0x141104ea8*/
    }
    if ( FFlag::CLI52064Experiment2.value ) /*0x141104eb5*/
    {
      if ( v37 != 1 ) /*0x141104ebb*/
      {
        if ( v37 != 2 ) /*0x141104ec5*/
        {
LABEL_49:
          this->statistics.ds.totalBytesSocketSent += (unsigned int)v12; /*0x141104ec7*/
          goto LABEL_63; /*0xf1c000000000001c*/
        }
        goto LABEL_56; /*0x141104ec5*/
      }
    }
    else
    {
      if ( v37 == 2 ) /*0x141104f1b*/
      {
LABEL_56:
        if ( !DFFlag::RakNetDetectNetUnreachable.value ) /*0x141104f24*/
          goto LABEL_49; /*0x141104f24*/
        if ( DFLog::NetworkTrace != 0 ) /*0x141104f2f*/
          FLog::FastLog( /*0x141104f3b*/
            level: DFLog::NetworkTrace,
            message: "[DFLog::NetworkTrace] Could not send data to server/client, network/host unreachable!",
            arg0: nullptr);
        this->deadConnection = true; /*0x141104f40*/
        goto LABEL_63; /*0x141104f47*/
      }
      if ( v37 != 1 ) /*0x141104f4d*/
        goto LABEL_49; /*0x141104f4d*/
    }
    if ( DFLog::NetworkTrace != 0 ) /*0x141104f5c*/
      FLog::FastLog( /*0x141104f6c*/
        level: DFLog::NetworkTrace,
        message: "[DFLog::NetworkTrace] Could not send data, poor connection?",
        arg0: nullptr);
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: socket); /*0xf1c0000000000008*/
  }
LABEL_63:
  v41 = (volatile signed __int32 *)v10->_Rep; /*0x141104ece*/
  if ( v41 != nullptr && _InterlockedExchangeAdd(v41 + 2, 0xFFFFFFFF) == 1 ) /*0x141104ee6*/
  {
    (**(void (__fastcall ***)(volatile signed __int32 *))v41)(a1: v41); /*0x141104eee*/
    if ( _InterlockedExchangeAdd(v41 + 3, 0xFFFFFFFF) == 1 ) /*0x141104ef8*/
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v41 + 8LL))(a1: v41); /*0x141104f00*/
  }
}

// Address: 0x141105500 | Name: ?SetMaxRxPayloadSizePtr@ReliabilityLayer@RakNet@@QEAAXPEAH@Z
void __fastcall RakNet::ReliabilityLayer::SetMaxRxPayloadSizePtr(
        RakNet::ReliabilityLayer *this,
        int *maxRxPayloadDataSize)
{
  this->maxRxPayloadSize = maxRxPayloadDataSize; /*0x141105500*/
}

// Address: 0x141105510 | Name: ?SetTimeoutTime@ReliabilityLayer@RakNet@@QEAAXI@Z
void __fastcall RakNet::ReliabilityLayer::SetTimeoutTime(RakNet::ReliabilityLayer *this, unsigned int time)
{
  this->timeoutTime = time; /*0x141105510*/
}

// Address: 0x141105520 | Name: ?SetUnreliableTimeout@ReliabilityLayer@RakNet@@QEAAXI@Z
void __fastcall RakNet::ReliabilityLayer::SetUnreliableTimeout(RakNet::ReliabilityLayer *this, unsigned int timeoutMS)
{
  this->unreliableTimeout = 1000LL * timeoutMS; /*0x141105529*/
}

// Address: 0x141105560 | Name: ?SnapshotTxBwCounters_deprecated@ReliabilityLayer@RakNet@@AEAAXI@Z
void __fastcall RakNet::ReliabilityLayer::SnapshotTxBwCounters_deprecated(
        RakNet::ReliabilityLayer *this,
        unsigned int timeMs)
{
  unsigned int timeInMsSinceLastTxByteCounterUpdates; // ecx
  char *Ptr; // rcx
  std::string resource; // [rsp+50h] [rbp-98h] BYREF
  RBX::Analytics::InfluxDb::Points points; // [rsp+70h] [rbp-78h] BYREF

  timeInMsSinceLastTxByteCounterUpdates = this->timeInMsSinceLastTxByteCounterUpdates; /*0x141105577*/
  if ( timeInMsSinceLastTxByteCounterUpdates != 0 )
  {
    if ( timeMs - timeInMsSinceLastTxByteCounterUpdates < 0x3E8 ) /*0x141105595*/
      return; /*0x141105595*/
    *(_OWORD *)&this->statistics.perSecTxBw_deprecated.availableCapacity = *(_OWORD *)&this->perSecTxBwCounters_deprecated.availableCapacity; /*0x1411055a2*/
    *(_OWORD *)&this->statistics.perSecTxBw_deprecated.reliablePacketBytesRe = *(_OWORD *)&this->perSecTxBwCounters_deprecated.reliablePacketBytesRe; /*0x1411055b0*/
    if ( DFInt::RaknetInfluxHundredthsPercentage != 0 ) /*0x1411055bf*/
    {
      this->influxTxBwCounters_deprecated.availableCapacity += this->perSecTxBwCounters_deprecated.availableCapacity; /*0x1411055cb*/
      this->influxTxBwCounters_deprecated.allBytes += this->perSecTxBwCounters_deprecated.allBytes; /*0x1411055d7*/
      this->influxTxBwCounters_deprecated.reliablePacketBytes += this->perSecTxBwCounters_deprecated.reliablePacketBytes; /*0x1411055e3*/
      this->influxTxBwCounters_deprecated.reliablePackets += this->perSecTxBwCounters_deprecated.reliablePackets; /*0x1411055ef*/
      this->influxTxBwCounters_deprecated.reliablePacketBytesRe += this->perSecTxBwCounters_deprecated.reliablePacketBytesRe; /*0x1411055fb*/
      this->influxTxBwCounters_deprecated.reliablePacketsRe += this->perSecTxBwCounters_deprecated.reliablePacketsRe; /*0x141105607*/
      this->influxTxBwCounters_deprecated.unreliablePacketBytes += this->perSecTxBwCounters_deprecated.unreliablePacketBytes; /*0x141105613*/
      this->influxTxBwCounters_deprecated.unreliablePackets += this->perSecTxBwCounters_deprecated.unreliablePackets; /*0x14110561f*/
      if ( timeMs - this->timeInMsSinceLastTxStatsReportToInflux >= 1000 /*0x141105639*/
                                                                  * DFInt::RaknetBwStatsInfluxReportDurationInSeconds )
      {
        RBX::Analytics::InfluxDb::Points::Points( /*0x141105650*/
          this: &points,
          throttleHundredthsPercentage: DFInt::RaknetInfluxHundredthsPercentage,
          categoryType: kStandardType,
          priorityHundredthsPercentage: 0);
        __wind /*0xf1c0000000000028*/
        {
          RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105669*/
            this: &points,
            name: "availableCapacity",
            value: this->influxTxBwCounters_deprecated.availableCapacity);
          RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105681*/
            this: &points,
            name: "allBytes",
            value: this->influxTxBwCounters_deprecated.allBytes);
          RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105699*/
            this: &points,
            name: "reliablePacketBytes",
            value: this->influxTxBwCounters_deprecated.reliablePacketBytes);
          RBX::Analytics::InfluxDb::Points::addPoint( /*0x1411056b1*/
            this: &points,
            name: "reliablePackets",
            value: this->influxTxBwCounters_deprecated.reliablePackets);
          RBX::Analytics::InfluxDb::Points::addPoint( /*0x1411056c9*/
            this: &points,
            name: "reliablePacketBytesRe",
            value: this->influxTxBwCounters_deprecated.reliablePacketBytesRe);
          RBX::Analytics::InfluxDb::Points::addPoint( /*0x1411056e1*/
            this: &points,
            name: "reliablePacketsRe",
            value: this->influxTxBwCounters_deprecated.reliablePacketsRe);
          RBX::Analytics::InfluxDb::Points::addPoint( /*0x1411056f9*/
            this: &points,
            name: "unreliablePacketBytes",
            value: this->influxTxBwCounters_deprecated.unreliablePacketBytes);
          RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105711*/
            this: &points,
            name: "unreliablePackets",
            value: this->influxTxBwCounters_deprecated.unreliablePackets);
          RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105729*/
            this: &points,
            name: "collectionDurationInSeconds",
            value: DFInt::RaknetBwStatsInfluxReportDurationInSeconds);
          resource._Mypair._Myval2._Myres = 15; /*0x14110572e*/
          resource._Mypair._Myval2._Mysize = 14; /*0x141105737*/
          strcpy(resource._Mypair._Myval2._Bx._Buf, "RccRakPeerTxBw"); /*0x141105748*/
          __wind /*0xf1c000000000001c*/
          {
            RBX::Analytics::InfluxDb::Points::report( /*0x14110577d*/
              this: &points,
              &resource,
              throttleHundredthsPercentage: DFInt::RaknetInfluxHundredthsPercentage,
              blocking: false);
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&resource); /*0xf1c0000000000014*/
          }
          if ( resource._Mypair._Myval2._Myres >= 0x10 ) /*0x14110578c*/
          {
            Ptr = resource._Mypair._Myval2._Bx._Ptr; /*0x141105791*/
            if ( resource._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1411057a0*/
            {
              Ptr = *((char **)resource._Mypair._Myval2._Bx._Ptr - 1); /*0x1411057a6*/
              if ( (unsigned __int64)(resource._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x1411057b5*/
                _invalid_parameter_noinfo_noreturn(); /*0x1411057b7*/
            }
            operator delete(ptr: Ptr); /*0x1411057be*/
          }
          *(_QWORD *)&this->influxTxBwCounters_deprecated.availableCapacity = 0; /*0x1411057c3*/
          *(_QWORD *)&this->influxTxBwCounters_deprecated.reliablePacketBytes = 0; /*0x1411057ca*/
          *(_QWORD *)&this->influxTxBwCounters_deprecated.reliablePacketBytesRe = 0; /*0x1411057d1*/
          *(_QWORD *)&this->influxTxBwCounters_deprecated.unreliablePacketBytes = 0; /*0x1411057d8*/
          this->timeInMsSinceLastTxStatsReportToInflux = timeMs; /*0x1411057df*/
          RBX::Analytics::InfluxDb::Points::~Points(this: &points); /*0x1411057ea*/
        }
        __unwind
        {
          RBX::Analytics::InfluxDb::Points::~Points(this: &points); /*0xf1c0000000000008*/
        }
      }
    }
    *(_QWORD *)&this->perSecTxBwCounters_deprecated.availableCapacity = 0; /*0x1411057ef*/
    *(_QWORD *)&this->perSecTxBwCounters_deprecated.reliablePacketBytes = 0; /*0x1411057f6*/
    *(_QWORD *)&this->perSecTxBwCounters_deprecated.reliablePacketBytesRe = 0; /*0x1411057fd*/
    *(_QWORD *)&this->perSecTxBwCounters_deprecated.unreliablePacketBytes = 0; /*0x141105804*/
    if ( DFLog::TxBwStatLog != 0 )
      FLog::FastLogFormatted(
        level: DFLog::TxBwStatLog,
        message: "[DFLog::TxBwStatLog] TxBwStats : availableCapacity = %d; allBytes = %d; reliablePacketBytes = %d; reliablePacket"
        "s = %d; reliablePacketBytesRe = %d; reliablePacketsRe = %d; unreliablePacketBytes = %d; unreliablePackets = %d;",
        this->statistics.perSecTxBw_deprecated.availableCapacity,
        this->statistics.perSecTxBw_deprecated.allBytes,
        this->statistics.perSecTxBw_deprecated.reliablePacketBytes,
        this->statistics.perSecTxBw_deprecated.reliablePackets,
        this->statistics.perSecTxBw_deprecated.reliablePacketBytesRe,
        this->statistics.perSecTxBw_deprecated.reliablePacketsRe,
        this->statistics.perSecTxBw_deprecated.unreliablePacketBytes,
        this->statistics.perSecTxBw_deprecated.unreliablePackets);
  }
  else
  {
    this->timeInMsSinceLastTxStatsReportToInflux = timeMs; /*0x141105581*/
  }
  this->timeInMsSinceLastTxByteCounterUpdates = timeMs; /*0x14110586c*/
}

// Address: 0x141105890 | Name: ?SnapshotTxBwData@ReliabilityLayer@RakNet@@AEAAXI@Z
void __fastcall RakNet::ReliabilityLayer::SnapshotTxBwData(RakNet::ReliabilityLayer *this, unsigned int timeMs)
{
  unsigned int timeInMsSinceLastTxByteCounterUpdates; // ecx
  double v5; // xmm6_8
  double v6; // xmm2_8
  long double *v7; // rbx
  long double *p_bwGivenByTargetSpeedKBps; // rax
  double v9; // xmm2_8
  long double *p_highWaterMarkForBwFromTargetSpeedKBps; // rbx
  long double *v11; // rax
  char *Ptr; // rcx
  double v13; // xmm12_8
  signed int totalGetTxBwCount; // edx
  signed int totalAvailableCapacity; // r9d
  unsigned int unreliablePacketBytes; // r10d
  signed int reliablePacketBytesRe; // r11d
  unsigned int reliablePacketBytes; // ebx
  double v19; // xmm2_8
  RBX::Analytics::InfluxDb::Points points; // [rsp+D0h] [rbp-80h] BYREF
  RBX::Graphics::ProfilerAdorn::Item resource[2]; // [rsp+140h] [rbp-10h] BYREF
  double bwGivenByTargetSpeedKBps; // [rsp+1F0h] [rbp+A0h] BYREF

  timeInMsSinceLastTxByteCounterUpdates = this->timeInMsSinceLastTxByteCounterUpdates; /*0x1411058d5*/
  if ( timeInMsSinceLastTxByteCounterUpdates == 0 ) /*0x1411058dd*/
  {
    this->timeInMsSinceLastTxStatsReportToInflux = timeMs; /*0x1411058df*/
LABEL_25:
    this->timeInMsSinceLastTxByteCounterUpdates = timeMs; /*0x1411062d7*/
    return; /*0x1411062d7*/
  }
  if ( timeMs - timeInMsSinceLastTxByteCounterUpdates >= 0x3E8
    && this->perSecTxBwData.txBwInfluencers.totalGetTxBwCount != 0 )
  {
    *(_OWORD *)&this->statistics.perSecTxBwData.availableCapacity = *(_OWORD *)&this->perSecTxBwData.availableCapacity; /*0x14110590e*/
    *(_OWORD *)&this->statistics.perSecTxBwData.reliablePackets = *(_OWORD *)&this->perSecTxBwData.reliablePackets; /*0x14110591c*/
    *(_OWORD *)&this->statistics.perSecTxBwData.unreliablePackets = *(_OWORD *)&this->perSecTxBwData.unreliablePackets; /*0x14110592a*/
    *(_OWORD *)&this->statistics.perSecTxBwData.txBwInfluencers.nonZeroTargetSpeedStartTimeCount = *(_OWORD *)&this->perSecTxBwData.txBwInfluencers.nonZeroTargetSpeedStartTimeCount; /*0x141105938*/
    *(_OWORD *)&this->statistics.perSecTxBwData.txBwInfluencers.bwCappedDueTo2xTargetSpeedCount = *(_OWORD *)&this->perSecTxBwData.txBwInfluencers.bwCappedDueTo2xTargetSpeedCount; /*0x141105946*/
    if ( DFInt::RaknetInfluxHundredthsPercentage != 0 ) /*0x141105955*/
    {
      this->influxTxBwData.availableCapacity += this->perSecTxBwData.availableCapacity; /*0x141105961*/
      this->influxTxBwData.totalAvailableCapacity += this->perSecTxBwData.totalAvailableCapacity; /*0x14110596d*/
      this->influxTxBwData.allBytes += this->perSecTxBwData.allBytes; /*0x141105979*/
      this->influxTxBwData.reliablePacketBytes += this->perSecTxBwData.reliablePacketBytes; /*0x141105985*/
      this->influxTxBwData.reliablePackets += this->perSecTxBwData.reliablePackets; /*0x141105991*/
      this->influxTxBwData.reliablePacketBytesRe += this->perSecTxBwData.reliablePacketBytesRe; /*0x14110599d*/
      this->influxTxBwData.reliablePacketsRe += this->perSecTxBwData.reliablePacketsRe; /*0x1411059a9*/
      this->influxTxBwData.unreliablePacketBytes += this->perSecTxBwData.unreliablePacketBytes; /*0x1411059b5*/
      this->influxTxBwData.unreliablePackets += this->perSecTxBwData.unreliablePackets; /*0x1411059c1*/
      this->influxTxBwData.txBwInfluencers.totalGetTxBwCount += this->perSecTxBwData.txBwInfluencers.totalGetTxBwCount; /*0x1411059cd*/
      this->influxTxBwData.txBwInfluencers.bwLimitedByAppCount += this->perSecTxBwData.txBwInfluencers.bwLimitedByAppCount; /*0x1411059d9*/
      this->influxTxBwData.txBwInfluencers.zeroTargetSpeedStartTimeCount += this->perSecTxBwData.txBwInfluencers.zeroTargetSpeedStartTimeCount; /*0x1411059e5*/
      this->influxTxBwData.txBwInfluencers.nonZeroTargetSpeedStartTimeCount += this->perSecTxBwData.txBwInfluencers.nonZeroTargetSpeedStartTimeCount; /*0x1411059f1*/
      this->influxTxBwData.txBwInfluencers.uncappedByteAllowanceFromTargetSpeed += this->perSecTxBwData.txBwInfluencers.uncappedByteAllowanceFromTargetSpeed; /*0x1411059fd*/
      this->influxTxBwData.txBwInfluencers.bytesGivenByTargetSpeed += this->perSecTxBwData.txBwInfluencers.bytesGivenByTargetSpeed; /*0x141105a09*/
      this->influxTxBwData.txBwInfluencers.bwCappedDueToTargetSpeedCount += this->perSecTxBwData.txBwInfluencers.bwCappedDueToTargetSpeedCount; /*0x141105a15*/
      this->influxTxBwData.txBwInfluencers.bwCappedDueTo2xTargetSpeedCount += this->perSecTxBwData.txBwInfluencers.bwCappedDueTo2xTargetSpeedCount; /*0x141105a21*/
      this->influxTxBwData.txBwInfluencers.bwcappedDueToMaxBytesInFlightCount += this->perSecTxBwData.txBwInfluencers.bwcappedDueToMaxBytesInFlightCount; /*0x141105a2d*/
      this->influxTxBwData.txBwInfluencers.bwCappedDueToMaxPacketsInFlightCount += this->perSecTxBwData.txBwInfluencers.bwCappedDueToMaxPacketsInFlightCount; /*0x141105a39*/
      this->influxTxBwData.txBwInfluencers.bwCappedDueToAllBytesInFlightLostCount += this->perSecTxBwData.txBwInfluencers.bwCappedDueToAllBytesInFlightLostCount; /*0x141105a45*/
      if ( DFInt::RaknetBwStatsInfluxReportDurationInSeconds > 0 /*0x141105a6a*/
        && timeMs - this->timeInMsSinceLastTxStatsReportToInflux >= 1000
                                                                  * DFInt::RaknetBwStatsInfluxReportDurationInSeconds )
      {
        if ( rand() % 10000 < DFInt::RaknetInfluxHundredthsPercentage ) /*0x141105a9b*/
        {
          RBX::Analytics::InfluxDb::Points::Points( /*0x141105aae*/
            this: &points,
            throttleHundredthsPercentage: -1,
            categoryType: kStandardType,
            priorityHundredthsPercentage: 0);
          __wind /*0xf1c0000000000028*/
          {
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105ac6*/
              this: &points,
              name: "availableCapacity",
              value: this->influxTxBwData.availableCapacity);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105add*/
              this: &points,
              name: "totalAvailableCapacity",
              value: this->influxTxBwData.totalAvailableCapacity);
            v5 = (double)(int)(timeMs - this->timeInMsSinceLastTxStatsReportToInflux); /*0x141105aee*/
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105b10*/
              this: &points,
              name: "availableCapacityKBps",
              value: (double)(int)this->influxTxBwData.availableCapacity / v5);
            v6 = (double)(int)this->influxTxBwData.totalAvailableCapacity / v5; /*0x141105b23*/
            bwGivenByTargetSpeedKBps = v6; /*0x141105b27*/
            v7 = &this->highWaterMarkFortotalAvailableCapacityKBps; /*0x141105b2f*/
            p_bwGivenByTargetSpeedKBps = &bwGivenByTargetSpeedKBps; /*0x141105b36*/
            if ( v6 <= this->highWaterMarkFortotalAvailableCapacityKBps ) /*0x141105b41*/
              p_bwGivenByTargetSpeedKBps = &this->highWaterMarkFortotalAvailableCapacityKBps; /*0x141105b41*/
            *v7 = *p_bwGivenByTargetSpeedKBps; /*0x141105b48*/
            RBX::Analytics::InfluxDb::Points::addPoint(this: &points, name: "totalAvailableCapacityKBps", value: v6); /*0x141105b56*/
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105b6a*/
              this: &points,
              name: "highWaterMarkFortotalAvailableCapacityKBps",
              value: *v7);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105b8c*/
              this: &points,
              name: "actualRawBwUsedKBps",
              value: (double)(int)this->influxTxBwData.allBytes / v5);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105bba*/
              this: &points,
              name: "actualBwUsedForAllTransmissionsKBps",
              value: (double)(this->influxTxBwData.reliablePacketBytes
                     + this->influxTxBwData.unreliablePacketBytes
                     + this->influxTxBwData.reliablePacketBytesRe)
            / v5);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105be2*/
              this: &points,
              name: "actualBwUsedForNewTransmissionsKBps",
              value: (double)(this->influxTxBwData.reliablePacketBytes + this->influxTxBwData.unreliablePacketBytes) / v5);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105c04*/
              this: &points,
              name: "actualBwUsedForReTransmissionKBps",
              value: (double)(int)this->influxTxBwData.reliablePacketBytesRe / v5);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105c38*/
              this: &points,
              name: "unusedAvailableBwKBps",
              value: (double)(this->influxTxBwData.totalAvailableCapacity
                     - this->influxTxBwData.reliablePacketBytesRe
                     - this->influxTxBwData.unreliablePacketBytes
                     - this->influxTxBwData.reliablePacketBytes)
            / v5);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105c53*/
              this: &points,
              name: "collectionDurationInSeconds",
              value: v5 / 1000.0);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105c6a*/
              this: &points,
              name: "allBytes",
              value: this->influxTxBwData.allBytes);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105c81*/
              this: &points,
              name: "reliablePacketBytes",
              value: this->influxTxBwData.reliablePacketBytes);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105c98*/
              this: &points,
              name: "reliablePackets",
              value: this->influxTxBwData.reliablePackets);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105caf*/
              this: &points,
              name: "reliablePacketBytesRe",
              value: this->influxTxBwData.reliablePacketBytesRe);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105cc6*/
              this: &points,
              name: "reliablePacketsRe",
              value: this->influxTxBwData.reliablePacketsRe);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105cdd*/
              this: &points,
              name: "unreliablePacketBytes",
              value: this->influxTxBwData.unreliablePacketBytes);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105cf4*/
              this: &points,
              name: "unreliablePackets",
              value: this->influxTxBwData.unreliablePackets);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105d0b*/
              this: &points,
              name: "actualTotalGetTxBwCount",
              value: this->influxTxBwData.txBwInfluencers.totalGetTxBwCount);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105d3b*/
              this: &points,
              name: "bwLimitedByAppCountToTotalCount",
              value: (double)(int)this->influxTxBwData.txBwInfluencers.bwLimitedByAppCount
            / (double)(int)this->influxTxBwData.txBwInfluencers.totalGetTxBwCount);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105d6b*/
              this: &points,
              name: "zeroTargetSpeedStartTimeCountToTotalCount",
              value: (double)(int)this->influxTxBwData.txBwInfluencers.zeroTargetSpeedStartTimeCount
            / (double)(int)this->influxTxBwData.txBwInfluencers.totalGetTxBwCount);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105d9b*/
              this: &points,
              name: "nonZeroTargetSpeedStartTimeCountToTotalCount",
              value: (double)(int)this->influxTxBwData.txBwInfluencers.nonZeroTargetSpeedStartTimeCount
            / (double)(int)this->influxTxBwData.txBwInfluencers.totalGetTxBwCount);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105dbd*/
              this: &points,
              name: "uncappedByteAllowanceFromTargetSpeedInKBps",
              value: (double)(int)this->influxTxBwData.txBwInfluencers.uncappedByteAllowanceFromTargetSpeed / v5);
            v9 = (double)(int)this->influxTxBwData.txBwInfluencers.bytesGivenByTargetSpeed / v5; /*0x141105dd0*/
            bwGivenByTargetSpeedKBps = v9; /*0x141105dd4*/
            p_highWaterMarkForBwFromTargetSpeedKBps = &this->highWaterMarkForBwFromTargetSpeedKBps; /*0x141105ddc*/
            v11 = &bwGivenByTargetSpeedKBps; /*0x141105de3*/
            if ( v9 <= this->highWaterMarkForBwFromTargetSpeedKBps ) /*0x141105dee*/
              v11 = &this->highWaterMarkForBwFromTargetSpeedKBps; /*0x141105dee*/
            *p_highWaterMarkForBwFromTargetSpeedKBps = *v11; /*0x141105df5*/
            RBX::Analytics::InfluxDb::Points::addPoint(this: &points, name: "bwGivenByTargetSpeedKBps", value: v9); /*0x141105e03*/
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105e17*/
              this: &points,
              name: "highWaterMarkForBwFromTargetSpeedKBps",
              value: *p_highWaterMarkForBwFromTargetSpeedKBps);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105e47*/
              this: &points,
              name: "bwCappedDueToTargetSpeedCountToTotalCount",
              value: (double)(int)this->influxTxBwData.txBwInfluencers.bwCappedDueToTargetSpeedCount
            / (double)(int)this->influxTxBwData.txBwInfluencers.totalGetTxBwCount);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105e77*/
              this: &points,
              name: "bwCappedDueTo2xTargetSpeedCountToTotalCount",
              value: (double)(int)this->influxTxBwData.txBwInfluencers.bwCappedDueTo2xTargetSpeedCount
            / (double)(int)this->influxTxBwData.txBwInfluencers.totalGetTxBwCount);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105ea7*/
              this: &points,
              name: "bwcappedDueToMaxBytesInFlightCountToTotalCount",
              value: (double)(int)this->influxTxBwData.txBwInfluencers.bwcappedDueToMaxBytesInFlightCount
            / (double)(int)this->influxTxBwData.txBwInfluencers.totalGetTxBwCount);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105ed7*/
              this: &points,
              name: "bwCappedDueToMaxPacketsInFlightCountToTotalCount",
              value: (double)(int)this->influxTxBwData.txBwInfluencers.bwCappedDueToMaxPacketsInFlightCount
            / (double)(int)this->influxTxBwData.txBwInfluencers.totalGetTxBwCount);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x141105f07*/
              this: &points,
              name: "bwCappedDueToAllBytesInFlightLostCountToTotalCount",
              value: (double)(int)this->influxTxBwData.txBwInfluencers.bwCappedDueToAllBytesInFlightLostCount
            / (double)(int)this->influxTxBwData.txBwInfluencers.totalGetTxBwCount);
            resource[0].text._Mypair._Myval2._Myres = 15; /*0x141105f0c*/
            resource[0].text._Mypair._Myval2._Mysize = 14; /*0x141105f14*/
            strcpy(resource[0].text._Mypair._Myval2._Bx._Buf, "RccRakPeerTxBw"); /*0x141105f24*/
            __wind /*0xf1c000000000001c*/
            {
              RBX::Analytics::InfluxDb::Points::report( /*0x141105f52*/
                this: &points,
                resource: &resource[0].text,
                throttleHundredthsPercentage: 10000,
                blocking: false);
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: resource); /*0xf1c0000000000014*/
            }
            if ( resource[0].text._Mypair._Myval2._Myres >= 0x10 ) /*0x141105f60*/
            {
              Ptr = resource[0].text._Mypair._Myval2._Bx._Ptr; /*0x141105f65*/
              if ( resource[0].text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141105f73*/
              {
                Ptr = *((char **)resource[0].text._Mypair._Myval2._Bx._Ptr - 1); /*0x141105f79*/
                if ( (unsigned __int64)(resource[0].text._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x141105f88*/
                  _invalid_parameter_noinfo_noreturn(); /*0x141105f8a*/
              }
              operator delete(ptr: Ptr); /*0x141105f91*/
            }
            RBX::Analytics::InfluxDb::Points::~Points(this: &points); /*0x141105f9b*/
          }
          __unwind
          {
            RBX::Analytics::InfluxDb::Points::~Points(this: &points); /*0xf1c0000000000008*/
          }
        }
        *(_QWORD *)&this->influxTxBwData.availableCapacity = 0; /*0x141105fa0*/
        *(_QWORD *)&this->influxTxBwData.allBytes = 0; /*0x141105fa7*/
        *(_QWORD *)&this->influxTxBwData.reliablePackets = 0; /*0x141105fae*/
        *(_QWORD *)&this->influxTxBwData.reliablePacketsRe = 0; /*0x141105fb5*/
        *(_QWORD *)&this->influxTxBwData.unreliablePackets = 0; /*0x141105fbc*/
        *(_QWORD *)&this->influxTxBwData.txBwInfluencers.bwLimitedByAppCount = 0; /*0x141105fc3*/
        *(_QWORD *)&this->influxTxBwData.txBwInfluencers.nonZeroTargetSpeedStartTimeCount = 0; /*0x141105fca*/
        *(_QWORD *)&this->influxTxBwData.txBwInfluencers.bytesGivenByTargetSpeed = 0; /*0x141105fd1*/
        *(_QWORD *)&this->influxTxBwData.txBwInfluencers.bwCappedDueTo2xTargetSpeedCount = 0; /*0x141105fd8*/
        *(_QWORD *)&this->influxTxBwData.txBwInfluencers.bwCappedDueToMaxPacketsInFlightCount = 0; /*0x141105fdf*/
        this->timeInMsSinceLastTxStatsReportToInflux = timeMs; /*0x141105fe6*/
      }
    }
    *(_QWORD *)&this->perSecTxBwData.availableCapacity = 0; /*0x141105fed*/
    *(_QWORD *)&this->perSecTxBwData.allBytes = 0; /*0x141105ff4*/
    *(_QWORD *)&this->perSecTxBwData.reliablePackets = 0; /*0x141105ffb*/
    *(_QWORD *)&this->perSecTxBwData.reliablePacketsRe = 0; /*0x141106002*/
    *(_QWORD *)&this->perSecTxBwData.unreliablePackets = 0; /*0x141106009*/
    *(_QWORD *)&this->perSecTxBwData.txBwInfluencers.bwLimitedByAppCount = 0; /*0x141106010*/
    *(_QWORD *)&this->perSecTxBwData.txBwInfluencers.nonZeroTargetSpeedStartTimeCount = 0; /*0x141106017*/
    *(_QWORD *)&this->perSecTxBwData.txBwInfluencers.bytesGivenByTargetSpeed = 0; /*0x14110601e*/
    *(_QWORD *)&this->perSecTxBwData.txBwInfluencers.bwCappedDueTo2xTargetSpeedCount = 0; /*0x141106025*/
    *(_QWORD *)&this->perSecTxBwData.txBwInfluencers.bwCappedDueToMaxPacketsInFlightCount = 0; /*0x14110602c*/
    v13 = (double)(int)(timeMs - this->timeInMsSinceLastTxByteCounterUpdates); /*0x141106040*/
    if ( DFLog::TxBwStatLog != 0 )
    {
      totalGetTxBwCount = this->statistics.perSecTxBwData.txBwInfluencers.totalGetTxBwCount; /*0x141106052*/
      totalAvailableCapacity = this->statistics.perSecTxBwData.totalAvailableCapacity; /*0x141106060*/
      unreliablePacketBytes = this->statistics.perSecTxBwData.unreliablePacketBytes; /*0x141106067*/
      reliablePacketBytesRe = this->statistics.perSecTxBwData.reliablePacketBytesRe; /*0x14110606e*/
      reliablePacketBytes = this->statistics.perSecTxBwData.reliablePacketBytes; /*0x141106075*/
      FLog::FastLogFormatted(
        level: DFLog::TxBwStatLog,
        message: "[DFLog::TxBwStatLog] TxBwStats#1 : availableCapacity = %d; totalAvailableCapacity = %d; availableCapacityKBps=%."
        "2f; totalAvailableCapacityKBps=%.2f; highWaterMarkFortotalAvailableCapacityKBps=%.2f; allBytes = %d; reliablePac"
        "ketBytes = %d; reliablePackets = %d; reliablePacketBytesRe = %d; reliablePacketsRe = %d; unreliablePacketBytes ="
        " %d; unreliablePackets = %d; actualRawBwUsedKBps = %.2f; actualBwUsedForAllTransmissionKBps = %.2f; actualBwUsed"
        "ForNewTransmissionsKBps = %.2f; actualBwUsedForReTransmissionKBps = %.2f; collectionDurationInSeconds = %.2f; un"
        "usedAvailableBwKBps = %.2f actualTotalGetTxBwCount=%d; bwLimitedByAppCountToTotalCount=%.2f zeroTargetSpeedStart"
        "TimeCountToTotalCount=%.2f; nonZeroTargetSpeedStartTimeCountToTotalCount=%.2f; uncappedByteAllowanceFromTargetSpeedInKBps=%.2f;",
        this->statistics.perSecTxBwData.availableCapacity,
        totalAvailableCapacity,
        (double)(int)this->statistics.perSecTxBwData.availableCapacity / v13,
        (double)totalAvailableCapacity / v13,
        (double)this->highWaterMarkFortotalAvailableCapacityKBps,
        this->statistics.perSecTxBwData.allBytes,
        reliablePacketBytes,
        this->statistics.perSecTxBwData.reliablePackets,
        reliablePacketBytesRe,
        this->statistics.perSecTxBwData.reliablePacketsRe,
        unreliablePacketBytes,
        this->statistics.perSecTxBwData.unreliablePackets,
        (double)(int)this->statistics.perSecTxBwData.allBytes / v13,
        (double)(int)(unreliablePacketBytes + reliablePacketBytes + reliablePacketBytesRe) / v13,
        (double)(int)(reliablePacketBytes + unreliablePacketBytes) / v13,
        (double)reliablePacketBytesRe / v13,
        v13 / 1000.0,
        (double)(int)(totalAvailableCapacity - reliablePacketBytes - reliablePacketBytesRe - unreliablePacketBytes)
      / v13,
        totalGetTxBwCount,
        (double)(int)this->statistics.perSecTxBwData.txBwInfluencers.bwLimitedByAppCount / (double)totalGetTxBwCount,
        (double)(int)this->statistics.perSecTxBwData.txBwInfluencers.zeroTargetSpeedStartTimeCount
      / (double)totalGetTxBwCount,
        (double)(int)this->statistics.perSecTxBwData.txBwInfluencers.nonZeroTargetSpeedStartTimeCount
      / (double)totalGetTxBwCount,
        (double)(int)this->statistics.perSecTxBwData.txBwInfluencers.uncappedByteAllowanceFromTargetSpeed / v13);
      if ( DFLog::TxBwStatLog != 0 )
      {
        v19 = (double)(int)this->statistics.perSecTxBwData.txBwInfluencers.totalGetTxBwCount; /*0x141106229*/
        FLog::FastLogFormatted(
          level: DFLog::TxBwStatLog,
          message: "[DFLog::TxBwStatLog] TxBwStats#2 : bwGivenByTargetSpeedKBps=%.2f; highWaterMarkForBwFromTargetSpeedKBps=%.2f; "
          "bwCappedDueToTargetSpeedCountToTotalCount=%.2f; bwCappedDueTo2xTargetSpeedCountToTotalCount=%.2f; bwcappedDueT"
          "oMaxBytesInFlightCountToTotalCount=%.2f; bwCappedDueToMaxPacketsInFlightCountToTotalCount=%.2f; bwCappedDueToA"
          "llBytesInFlightLostCountToTotalCount=%.2f",
          (double)(int)this->statistics.perSecTxBwData.txBwInfluencers.bytesGivenByTargetSpeed / v13,
          this->highWaterMarkForBwFromTargetSpeedKBps,
          (double)(int)this->statistics.perSecTxBwData.txBwInfluencers.bwCappedDueToTargetSpeedCount / v19,
          (double)(int)this->statistics.perSecTxBwData.txBwInfluencers.bwCappedDueTo2xTargetSpeedCount / v19,
          (double)(int)this->statistics.perSecTxBwData.txBwInfluencers.bwcappedDueToMaxBytesInFlightCount / v19,
          (double)(int)this->statistics.perSecTxBwData.txBwInfluencers.bwCappedDueToMaxPacketsInFlightCount / v19,
          (double)(int)this->statistics.perSecTxBwData.txBwInfluencers.bwCappedDueToAllBytesInFlightLostCount / v19);
      }
    }
    goto LABEL_25; /*0x1411062d2*/
  }
}

// Address: 0x141106320 | Name: ?SplitPacket@ReliabilityLayer@RakNet@@AEAAXPEAUInternalPacket@2@H@Z
void __fastcall RakNet::ReliabilityLayer::SplitPacket(
        RakNet::ReliabilityLayer *this,
        DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *internalPacket,
        unsigned int ruppLength)
{
  PacketReliability reliability; // ecx
  int v6; // r9d
  signed int v7; // r14d
  int v8; // ebx
  signed int v9; // r15d
  signed int splitPacketCount; // edx
  unsigned __int64 v11; // rcx
  __int64 v12; // rax
  void *v13; // rsp
  void **p_ptr; // rax
  signed int v15; // ebx
  void **v16; // rsi
  DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *v17; // rax
  unsigned int v18; // eax
  __int64 v19; // rsi
  int v20; // r13d
  RakNet::InternalPacket **v21; // rdx
  signed int v22; // r12d
  DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *v23; // r12
  int v24; // ecx
  signed int v25; // r13d
  RakNet::InternalPacket **v26; // r15
  RakNet::InternalPacket *v27; // rdx
  PacketReliability v28; // eax
  RakNet::InternalPacket *unreliableLinkedListHead; // rax
  RakNet::InternalPacket *unreliablePrev; // rcx
  RBX::Security::RakPeerCrypto *NextWeight; // rax
  RBX::Security::RakPeerCrypto *v32; // r14
  unsigned int v33; // ebx
  unsigned int v34; // ecx
  DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::HeapNode *v35; // rdx
  unsigned int v36; // eax
  signed int v37; // eax
  DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::HeapNode *v38; // rsi
  DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::HeapNode *v39; // rcx
  unsigned int v40; // edx
  unsigned int v41; // eax
  signed int v42; // eax
  DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::HeapNode *v43; // rsi
  unsigned int v44; // eax
  DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::HeapNode *v45; // rcx
  unsigned int v46; // edx
  bool v47; // zf
  unsigned int v48; // ecx
  DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::HeapNode *v49; // r8
  DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::HeapNode v50; // xmm1
  unsigned int list_size; // r8d
  unsigned int allocation_size; // eax
  signed int v53; // eax
  DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::HeapNode *v54; // rbx
  DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::HeapNode *listArray; // rcx
  unsigned int v56; // edx
  void *ptr; // [rsp+30h] [rbp+0h] BYREF
  DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::HeapNode refCounter; // [rsp+38h] [rbp+8h] BYREF
  DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::HeapNode v59; // [rsp+48h] [rbp+18h]
  DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::HeapNode v60; // [rsp+58h] [rbp+28h]
  char v61; // [rsp+B0h] [rbp+80h]
  int v63; // [rsp+C8h] [rbp+98h]

  internalPacket->userMemory.splitPacketCount = 1; /*0x141106346*/
  reliability = internalPacket->userMemory.reliability; /*0x14110634d*/
  v6 = 24; /*0x141106350*/
  if ( (unsigned int)(reliability - 2) <= 2 || (unsigned int)(reliability - 6) <= 1 ) /*0x141106364*/
    v6 = 48; /*0x141106366*/
  if ( (reliability == UNRELIABLE_SEQUENCED || reliability == RELIABLE_SEQUENCED) /*0x14110638c*/
    && (v6 += 24, reliability == UNRELIABLE_SEQUENCED)
    || ((reliability - 3) & 0xFFFFFFFA) == 0 && reliability != NUMBER_OF_RELIABILITIES )
  {
    v6 += 32; /*0x14110638e*/
  }
  v63 = v6 + 80; /*0x141106396*/
  v7 = (internalPacket->userMemory.dataBitLength + 7) >> 3; /*0x1411063a4*/
  v8 = dword_1451BE378; /*0x1411063a8*/
  v9 = RakNet::ReliabilityLayer::GetMaxDatagramSizeExcludingMessageHeaderBytes(this, ruppLength) /*0x1411063c2*/
     - ((unsigned int)(v8 + 7) >> 3);
  splitPacketCount = (v7 - 1) / (unsigned int)v9 + 1; /*0x1411063d0*/
  internalPacket->userMemory.splitPacketCount = splitPacketCount; /*0x1411063d2*/
  v61 = 0; /*0x1411063d6*/
  v11 = 8LL * (unsigned int)splitPacketCount; /*0x1411063df*/
  if ( v11 >= 0x186A0 ) /*0x1411063ea*/
  {
    p_ptr = (void **)RBX::Memory::allocate(size: v11); /*0x141106419*/
    splitPacketCount = internalPacket->userMemory.splitPacketCount; /*0x14110641e*/
  }
  else
  {
    v12 = v11 + 15; /*0x1411063ec*/
    if ( v11 + 15 < v11 ) /*0x1411063f3*/
      v12 = 0xFFFFFFFFFFFFFF0LL; /*0x1411063f5*/
    v13 = alloca(v12 & 0xFFFFFFFFFFFFFFF0uLL); /*0x141106408*/
    p_ptr = &ptr; /*0x14110640b*/
    v61 = 1; /*0x141106410*/
  }
  ptr = p_ptr; /*0x141106422*/
  v15 = 0; /*0x141106426*/
  if ( splitPacketCount > 0 ) /*0x14110642a*/
  {
    v16 = p_ptr; /*0x14110642c*/
    do /*0x14110647b*/
    {
      v17 = RakNet::ReliabilityLayer::AllocateFromInternalPacketPool(this); /*0x141106433*/
      *v16 = v17; /*0x141106438*/
      RakNet::InternalPacket::operator=(this: &v17->userMemory, __that: &internalPacket->userMemory); /*0x141106441*/
      *((_BYTE *)*v16 + 36) = 0; /*0x141106449*/
      if ( v15 != 0 ) /*0x14110644f*/
      {
        v18 = this->internalOrderIndex.val++ & 0xFFFFFF; /*0x141106459*/
        HIBYTE(this->internalOrderIndex.val) = 0; /*0x141106466*/
        internalPacket->userMemory.messageInternalOrder.val = v18; /*0x14110646d*/
      }
      ++v15; /*0x141106471*/
      ++v16; /*0x141106473*/
    }
    while ( v15 < (signed int)internalPacket->userMemory.splitPacketCount ); /*0x14110647b*/
  }
  v19 = 0; /*0x14110647d*/
  refCounter.weight = 0; /*0x14110647f*/
  v20 = 0; /*0x141106483*/
  v21 = (RakNet::InternalPacket **)ptr; /*0x141106486*/
  do /*0x141106529*/
  {
    v22 = v9; /*0x141106490*/
    if ( v7 <= v9 ) /*0x141106496*/
      v22 = v7; /*0x141106496*/
    RakNet::ReliabilityLayer::AllocInternalPacketData( /*0x1411064bb*/
      this,
      internalPacket: v21[v19],
      (RakNet::InternalPacketRefCountedData **)&refCounter,
      externallyAllocatedPtr: internalPacket->userMemory.data,
      ourOffset: &internalPacket->userMemory.data[v20]);
    v21 = (RakNet::InternalPacket **)ptr; /*0x1411064c0*/
    if ( v22 == v9 ) /*0x1411064c7*/
    {
      v24 = 8 * v22; /*0x1411064e4*/
      v23 = internalPacket; /*0x1411064ec*/
    }
    else
    {
      v23 = internalPacket; /*0x1411064d4*/
      v24 = internalPacket->userMemory.dataBitLength - v19 * 8 * v9; /*0x1411064e0*/
    }
    *(_DWORD *)(*((_QWORD *)ptr + v19) + 24LL) = v24; /*0x1411064f7*/
    v21[v19]->splitPacketIndex = v19; /*0x1411064fe*/
    v21[v19]->splitPacketId = this->splitPacketId; /*0x14110650c*/
    v21[v19]->splitPacketCount = v23->userMemory.splitPacketCount; /*0x141106519*/
    v19 = (unsigned int)(v19 + 1); /*0x14110651c*/
    v20 += v9; /*0x14110651e*/
    v7 -= v9; /*0x141106521*/
  }
  while ( (unsigned int)v19 < v23->userMemory.splitPacketCount ); /*0x141106529*/
  ++this->splitPacketId; /*0x14110652f*/
  this->outgoingPacketBuffer.optimizeNextSeriesPush = false; /*0x141106536*/
  v25 = 0; /*0x14110653d*/
  if ( (int)v23->userMemory.splitPacketCount > 0 ) /*0x141106545*/
  {
    v26 = v21; /*0x14110654b*/
    while ( 1 ) /*0x141106569*/
    {
      (*v26)->headerLength = v63; /*0x141106569*/
      v27 = *v26; /*0x14110656c*/
      v28 = (*v26)->reliability; /*0x14110656f*/
      if ( (v28 & 0xFFFFFFFA) == 0 && v28 != RELIABLE_SEQUENCED ) /*0x14110657c*/
      {
        unreliableLinkedListHead = this->unreliableLinkedListHead; /*0x14110657e*/
        if ( unreliableLinkedListHead != nullptr ) /*0x141106588*/
        {
          v27->unreliableNext = unreliableLinkedListHead; /*0x14110659e*/
          unreliablePrev = this->unreliableLinkedListHead->unreliablePrev; /*0x1411065ac*/
          v27->unreliablePrev = unreliablePrev; /*0x1411065b0*/
          unreliablePrev->unreliableNext = v27; /*0x1411065b4*/
          this->unreliableLinkedListHead->unreliablePrev = v27; /*0x1411065c2*/
        }
        else
        {
          v27->unreliableNext = v27; /*0x14110658a*/
          v27->unreliablePrev = v27; /*0x141106591*/
          this->unreliableLinkedListHead = v27; /*0x141106595*/
        }
      }
      NextWeight = RakNet::ReliabilityLayer::GetNextWeight(this, priorityLevel: (*v26)->priority); /*0x1411065cf*/
      v32 = NextWeight; /*0x1411065d4*/
      if ( this->outgoingPacketBuffer.optimizeNextSeriesPush ) /*0x1411065d7*/
      {
        v60.weight = (unsigned __int64)NextWeight; /*0x141106840*/
        v60.data = *v26; /*0x141106847*/
        list_size = this->outgoingPacketBuffer.heap.list_size; /*0x14110684b*/
        allocation_size = this->outgoingPacketBuffer.heap.allocation_size; /*0x141106852*/
        if ( list_size == allocation_size ) /*0x14110685b*/
        {
          if ( allocation_size == 0 ) /*0x141106863*/
          {
            this->outgoingPacketBuffer.heap.allocation_size = 16; /*0x141106869*/
            v53 = 16; /*0x141106873*/
            goto LABEL_73; /*0x141106873*/
          }
          v47 = 2 * allocation_size == 0; /*0x1411068f3*/
          v53 = 2 * allocation_size; /*0x1411068f3*/
          this->outgoingPacketBuffer.heap.allocation_size = v53; /*0x1411068f5*/
          if ( v47 ) /*0x1411068fb*/
          {
            v54 = nullptr; /*0x141106901*/
          }
          else
          {
LABEL_73:
            v54 = (DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::HeapNode *)operator new( /*0x14110688e*/
                                                                                                   size: saturated_mul(
                                                                                                     v53,
                                                                                                     0x10u));
            list_size = this->outgoingPacketBuffer.heap.list_size; /*0x1411068a0*/
          }
          listArray = this->outgoingPacketBuffer.heap.listArray; /*0x1411068a7*/
          if ( listArray != nullptr ) /*0x1411068b1*/
          {
            v56 = 0; /*0x1411068b3*/
            if ( list_size != 0 ) /*0x1411068b8*/
            {
              do /*0x1411068dc*/
              {
                v54[v56] = this->outgoingPacketBuffer.heap.listArray[v56]; /*0x1411068d0*/
                ++v56; /*0x1411068d4*/
              }
              while ( v56 < this->outgoingPacketBuffer.heap.list_size ); /*0x1411068dc*/
              listArray = this->outgoingPacketBuffer.heap.listArray; /*0x1411068de*/
            }
            operator delete(ptr: listArray); /*0x1411068e5*/
          }
          this->outgoingPacketBuffer.heap.listArray = v54; /*0x1411068ea*/
        }
        else
        {
          v54 = this->outgoingPacketBuffer.heap.listArray; /*0x141106905*/
        }
        v54[this->outgoingPacketBuffer.heap.list_size++] = v60; /*0x141106919*/
        goto LABEL_84; /*0x14110691d*/
      }
      v33 = this->outgoingPacketBuffer.heap.list_size; /*0x1411065e4*/
      if ( v33 != 0 ) /*0x1411065ec*/
      {
        v34 = (v33 - 1) >> 1; /*0x1411065f1*/
        if ( v34 < v33 ) /*0x1411065f5*/
        {
          v35 = this->outgoingPacketBuffer.heap.listArray; /*0x1411065f7*/
          while ( (unsigned __int64)NextWeight >= v35[v34].weight ) /*0x141106609*/
          {
            if ( ++v34 >= v33 ) /*0x141106613*/
              goto LABEL_40; /*0x141106613*/
          }
          refCounter.weight = (unsigned __int64)NextWeight; /*0x1411066f2*/
          refCounter.data = *v26; /*0x1411066f9*/
          v41 = this->outgoingPacketBuffer.heap.allocation_size; /*0x1411066fd*/
          if ( v33 == v41 ) /*0x141106705*/
          {
            if ( v41 == 0 ) /*0x14110670d*/
            {
              this->outgoingPacketBuffer.heap.allocation_size = 16; /*0x141106713*/
              v42 = 16; /*0x14110671d*/
              goto LABEL_54; /*0x14110671d*/
            }
            v47 = 2 * v41 == 0; /*0x1411067bb*/
            v42 = 2 * v41; /*0x1411067bb*/
            this->outgoingPacketBuffer.heap.allocation_size = v42; /*0x1411067bd*/
            if ( v47 ) /*0x1411067c3*/
            {
              v43 = nullptr; /*0x1411067c9*/
              v44 = v33; /*0x1411067cb*/
            }
            else
            {
LABEL_54:
              v43 = (DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::HeapNode *)operator new(size: saturated_mul(v42, 0x10u)); /*0x141106738*/
              v44 = this->outgoingPacketBuffer.heap.list_size; /*0x14110674a*/
            }
            v45 = this->outgoingPacketBuffer.heap.listArray; /*0x141106750*/
            if ( v45 != nullptr ) /*0x14110675a*/
            {
              v46 = 0; /*0x14110675c*/
              if ( v44 != 0 ) /*0x141106760*/
              {
                do /*0x14110678c*/
                {
                  v43[v46] = this->outgoingPacketBuffer.heap.listArray[v46]; /*0x141106780*/
                  ++v46; /*0x141106784*/
                }
                while ( v46 < this->outgoingPacketBuffer.heap.list_size ); /*0x14110678c*/
                v45 = this->outgoingPacketBuffer.heap.listArray; /*0x14110678e*/
              }
              operator delete(ptr: v45); /*0x141106795*/
            }
            this->outgoingPacketBuffer.heap.listArray = v43; /*0x14110679a*/
            v43[this->outgoingPacketBuffer.heap.list_size] = refCounter; /*0x1411067ae*/
          }
          else
          {
            v35[this->outgoingPacketBuffer.heap.list_size] = refCounter; /*0x1411067dc*/
          }
          ++this->outgoingPacketBuffer.heap.list_size; /*0x1411067e0*/
          do /*0x141106824*/
          {
            v48 = (v33 - 1) >> 1; /*0x1411067e9*/
            v49 = this->outgoingPacketBuffer.heap.listArray; /*0x1411067f0*/
            if ( v49[v48].weight <= (unsigned __int64)v32 ) /*0x1411067fb*/
              break; /*0x1411067fb*/
            v50 = v49[v33]; /*0x141106806*/
            v49[v33] = v49[(v33 - 1) >> 1]; /*0x141106810*/
            this->outgoingPacketBuffer.heap.listArray[(v33 - 1) >> 1] = v50; /*0x14110681c*/
            v33 = (v33 - 1) >> 1; /*0x141106820*/
          }
          while ( v48 != 0 ); /*0x141106824*/
          goto LABEL_84; /*0x141106824*/
        }
      }
LABEL_40:
      v59.weight = (unsigned __int64)NextWeight; /*0x141106615*/
      v59.data = *v26; /*0x14110661c*/
      v36 = this->outgoingPacketBuffer.heap.allocation_size; /*0x141106620*/
      if ( v33 == v36 ) /*0x141106628*/
        break; /*0x141106628*/
LABEL_50:
      this->outgoingPacketBuffer.heap.listArray[this->outgoingPacketBuffer.heap.list_size++] = v59; /*0x1411066c8*/
      this->outgoingPacketBuffer.optimizeNextSeriesPush = true; /*0x1411066e6*/
LABEL_84:
      ++this->statistics.messageInSendBuffer[(*v26)->priority]; /*0x141106923*/
      this->statistics.bytesInSendBuffer[(*v26)->priority] = (double)(((*v26)->dataBitLength + 7) >> 3) /*0x141106952*/
                                                           + this->statistics.bytesInSendBuffer[(*v26)->priority];
      ++v25; /*0x14110695b*/
      ++v26; /*0x14110695e*/
      if ( v25 >= (signed int)v23->userMemory.splitPacketCount ) /*0x141106967*/
        goto LABEL_85; /*0x141106967*/
    }
    if ( v36 != 0 ) /*0x141106630*/
    {
      v47 = 2 * v36 == 0; /*0x14110682b*/
      v37 = 2 * v36; /*0x14110682b*/
      this->outgoingPacketBuffer.heap.allocation_size = v37; /*0x14110682d*/
      if ( v47 ) /*0x141106833*/
      {
        v38 = nullptr; /*0x141106839*/
        goto LABEL_44; /*0x14110683b*/
      }
    }
    else
    {
      this->outgoingPacketBuffer.heap.allocation_size = 16; /*0x141106636*/
      v37 = 16; /*0x141106640*/
    }
    v38 = (DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::HeapNode *)operator new(size: saturated_mul(v37, 0x10u)); /*0x141106663*/
    v33 = this->outgoingPacketBuffer.heap.list_size; /*0x14110666d*/
LABEL_44:
    v39 = this->outgoingPacketBuffer.heap.listArray; /*0x141106673*/
    if ( v39 != nullptr ) /*0x14110667d*/
    {
      v40 = 0; /*0x14110667f*/
      if ( v33 != 0 ) /*0x141106683*/
      {
        do /*0x1411066ac*/
        {
          v38[v40] = this->outgoingPacketBuffer.heap.listArray[v40]; /*0x1411066a0*/
          ++v40; /*0x1411066a4*/
        }
        while ( v40 < this->outgoingPacketBuffer.heap.list_size ); /*0x1411066ac*/
        v39 = this->outgoingPacketBuffer.heap.listArray; /*0x1411066ae*/
      }
      operator delete(ptr: v39); /*0x1411066b5*/
    }
    this->outgoingPacketBuffer.heap.listArray = v38; /*0x1411066ba*/
    goto LABEL_50; /*0x1411066ba*/
  }
LABEL_85:
  RakNet::ReliabilityLayer::ReleaseToInternalPacketPool(this, ip: v23); /*0x14110696d*/
  if ( v61 == 0 ) /*0x14110697f*/
    operator delete(ptr); /*0x141106985*/
}

// Address: 0x1411069d0 | Name: ?Update@ReliabilityLayer@RakNet@@QEAAIV?$shared_ptr@URakNetSocket@RakNet@@@std@@AEAUSystemAddress@2@H_KIAEAVBitStream@2@AEBV?$shared_ptr@VRupp@1Network@RBX@@@4@AEBU52@@Z
__int64 __fastcall RakNet::ReliabilityLayer::Update(
        RakNet::ReliabilityLayer *this,
        std::shared_ptr<RBX::File> *socket,
        RakNet::SystemAddress *systemAddress,
        __int64 MTUSize,
        unsigned __int64 time,
        unsigned int bitsPerSecondLimit,
        RakNet::BitStream *updateBitStream,
        const std::shared_ptr<RBX::Network::Rupp::Rupp> *ruppHeader,
        const RakNet::SystemAddress *udmuxAddress)
{
  unsigned __int64 v12; // rsi
  std::_Ref_count_base *v13; // rdi
  unsigned __int64 v15; // r13
  unsigned __int64 unreliableTimeout; // rcx
  unsigned __int64 timeToNextUnreliableCull; // rax
  RakNet::InternalPacket *unreliableLinkedListHead; // rbx
  RakNet::InternalPacket *unreliablePrev; // r14
  RakNet::InternalPacket *unreliableNext; // rdx
  PacketReliability reliability; // eax
  RakNet::InternalPacket *v22; // rcx
  unsigned __int64 v23; // rax
  __int64 timeLastDatagramArrived; // rdx
  const std::shared_ptr<RBX::Network::Rupp::Rupp> *v25; // r14
  std::_Ref_count_base *Rep; // rcx
  int HeaderTotalByteLength; // edx
  std::_Ref_count_base *v28; // rcx
  unsigned int list_size; // ecx
  unsigned __int64 v30; // rdx
  RakNet::BPSTracker *bpsMetrics; // rbx
  __int64 i; // rsi
  unsigned int v33; // esi
  DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *v34; // rbx
  unsigned __int8 *v35; // rax
  unsigned int v36; // edx
  __int64 v37; // rcx
  unsigned int v38; // r8d
  RakNet::ReliabilityLayer::UnreliableWithAckReceiptNode *listArray; // rax
  RakNet::ReliabilityLayer::UnreliableWithAckReceiptNode *v40; // rdx
  RakNet::ReliabilityLayer::UnreliableWithAckReceiptNode *v41; // rcx
  DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *j; // rbx
  std::_Tree_node<std::pair<RakNet::uint24_t const ,RakNet::InternalPacket *>,void *> *Parent; // rax
  std::_Tree_node<std::pair<RakNet::uint24_t const ,RakNet::InternalPacket *>,void *> *Myhead; // rdx
  std::_Tree_node<std::pair<std::string const ,std::shared_ptr<std::string const > >,void *> *v45; // rax
  RakNet::InternalPacket *resendNext; // rcx
  std::_Ref_count_base *v47; // rcx
  unsigned int v48; // esi
  std::_Ref_count_base *v49; // rdi
  RakNet::InternalPacket *input; // [rsp+60h] [rbp-59h] BYREF
  std::shared_ptr<RBX::File> v51; // [rsp+68h] [rbp-51h] BYREF
  std::shared_ptr<RakNet::RakNetSocket> v52; // [rsp+78h] [rbp-41h] BYREF
  std::shared_ptr<RakNet::RakNetSocket> v53; // [rsp+88h] [rbp-31h] BYREF
  RakNet::DatagramHeaderFormat dhf; // [rsp+98h] [rbp-21h] BYREF
  int v55; // [rsp+100h] [rbp+47h]
  char v58; // [rsp+120h] [rbp+67h]

  v12 = time / 0x3E8; /*0x141106a19*/
  if ( time > this->lastUpdateTime )
  {
    __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000024*/
    if ( DFFlag::RakNetUseSlidingWindow4.value && DFFlag::RakNetReportTransmissionBw2.value ) /*0x141106a7d*/
    {
      RakNet::ReliabilityLayer::SnapshotTxBwData(this, timeMs: v12); /*0x141106a81*/
    }
    else if ( DFFlag::RakNetComputeTxBw.value ) /*0x141106a8f*/
    {
      RakNet::ReliabilityLayer::SnapshotTxBwCounters_deprecated(this, timeMs: v12); /*0x141106a93*/
    }
    v15 = time - this->lastUpdateTime; /*0x141106a9b*/
    this->lastUpdateTime = time; /*0x141106aa2*/
    if ( v15 > 0x186A0 ) /*0x141106ab1*/
      v15 = 100000; /*0x141106ab1*/
    unreliableTimeout = this->unreliableTimeout; /*0x141106ab5*/
    if ( unreliableTimeout != 0 ) /*0x141106abf*/
    {
      timeToNextUnreliableCull = this->timeToNextUnreliableCull; /*0x141106ac5*/
      if ( v15 < timeToNextUnreliableCull ) /*0x141106acf*/
      {
        v23 = timeToNextUnreliableCull - v15; /*0x141106ba0*/
      }
      else
      {
        unreliableLinkedListHead = this->unreliableLinkedListHead; /*0x141106ad5*/
        if ( unreliableLinkedListHead != nullptr ) /*0x141106adf*/
        {
          unreliablePrev = unreliableLinkedListHead->unreliablePrev; /*0x141106ae5*/
          if ( time > unreliableLinkedListHead->creationTime + unreliableTimeout ) /*0x141106af0*/
          {
            do /*0x141106b8e*/
            {
              RakNet::ReliabilityLayer::FreeInternalPacketData( /*0x141106b13*/
                this,
                internalPacket: unreliableLinkedListHead,
                file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
                line: 0x82Fu);
              unreliableLinkedListHead->data = nullptr; /*0x141106b1b*/
              unreliableNext = unreliableLinkedListHead->unreliableNext; /*0x141106b1f*/
              reliability = unreliableLinkedListHead->reliability; /*0x141106b26*/
              if ( (reliability & 0xFFFFFFFA) == 0 && reliability != RELIABLE_SEQUENCED ) /*0x141106b33*/
              {
                unreliableLinkedListHead->unreliablePrev->unreliableNext = unreliableNext; /*0x141106b39*/
                unreliableLinkedListHead->unreliableNext->unreliablePrev = unreliableLinkedListHead->unreliablePrev; /*0x141106b4b*/
                v22 = unreliableLinkedListHead->unreliableNext; /*0x141106b4f*/
                if ( this->unreliableLinkedListHead == unreliableLinkedListHead ) /*0x141106b60*/
                {
                  this->unreliableLinkedListHead = v22; /*0x141106b62*/
                  if ( v22 == unreliableLinkedListHead ) /*0x141106b6f*/
                    this->unreliableLinkedListHead = nullptr; /*0x141106b71*/
                }
              }
              if ( unreliableLinkedListHead == unreliablePrev ) /*0x141106b7b*/
                break; /*0x141106b7b*/
              unreliableLinkedListHead = unreliableNext; /*0x141106b7d*/
            }
            while ( time > this->unreliableTimeout + unreliableNext->creationTime ); /*0x141106b8e*/
          }
        }
        v23 = this->unreliableTimeout >> 1; /*0x141106b9b*/
      }
      this->timeToNextUnreliableCull = v23; /*0x141106ba3*/
    }
    if ( this->statistics.messagesInResendBuffer != 0
      && (timeLastDatagramArrived = this->timeLastDatagramArrived) - (unsigned __int64)(unsigned int)v12 > 0x2710
      && (unsigned __int64)(unsigned int)v12 - timeLastDatagramArrived > this->timeoutTime )
    {
      if ( FLog::Network != 0 )
        FLog::FastLogFormatted(
          level: FLog::Network,
          message: "[FLog::Network] AckTimeout: Last Packet received time: %d ms",
          v12 - timeLastDatagramArrived);
      this->deadConnection = true; /*0x141106bf4*/
      if ( __eh34_unwind(0) ) /*0xf1c0000000000018*/
        goto unwind_state_0; /*0xf1c0000000000018*/
      __eh34_exit_wind_state(0, -1); /*0xf1c000000000001c*/
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: socket); /*0x141106bfe*/
      return 1; /*0x141106c03*/
    }
    else
    {
      v25 = ruppHeader; /*0x141106c27*/
      if ( this->congestionManager->ShouldSendACKs(this: this->congestionManager, a2: time, a3: v15) ) /*0x141106c1d*/
      {
        v51 = 0; /*0x141106c36*/
        Rep = socket->_Rep; /*0x141106c3b*/
        if ( Rep != nullptr ) /*0x141106c43*/
        {
          _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x141106c45*/
          Rep = socket->_Rep; /*0x141106c49*/
        }
        v51._Ptr = socket->_Ptr; /*0x141106c52*/
        v51._Rep = Rep; /*0x141106c56*/
        RakNet::ReliabilityLayer::SendACKs( /*0x141106c77*/
          this,
          socket: &v51,
          systemAddress,
          time,
          updateBitStream,
          ruppHeader,
          udmuxAddress);
      }
      if ( DFFlag::RuppHeaderFromClientEnabled3.value && ruppHeader->_Ptr != nullptr ) /*0x141106c8b*/
        HeaderTotalByteLength = RBX::Network::Rupp::Rupp::getHeaderTotalByteLength(this: ruppHeader->_Ptr); /*0x141106c92*/
      else
        HeaderTotalByteLength = 0; /*0x141106c97*/
      v55 = HeaderTotalByteLength; /*0x141106c99*/
      v52 = 0; /*0x141106c9f*/
      v28 = socket->_Rep; /*0x141106ca4*/
      if ( v28 != nullptr ) /*0x141106cac*/
      {
        _InterlockedIncrement((volatile signed __int32 *)&v28->_Uses); /*0x141106cae*/
        v28 = socket->_Rep; /*0x141106cb2*/
      }
      v52._Ptr = (RakNet::RakNetSocket *)socket->_Ptr; /*0x141106cbb*/
      v52._Rep = v28; /*0x141106cbf*/
      RakNet::ReliabilityLayer::checkSendNak( /*0x141106ce4*/
        this,
        socket: &v52,
        systemAddress,
        time,
        updateBitStream,
        ruppHeader,
        udmuxAddress,
        ruppLength: HeaderTotalByteLength);
      *(_WORD *)&dhf.isJoinData = 0; /*0x141106ce9*/
      dhf.needsBAndAs = this->congestionManager->GetIsInSlowStart(this: this->congestionManager); /*0x141106cff*/
      dhf.isContinuousSend = this->bandwidthExceededStatistic; /*0x141106d09*/
      list_size = this->outgoingPacketBuffer.heap.list_size; /*0x141106d0c*/
      this->bandwidthExceededStatistic = list_size != 0; /*0x141106d17*/
      if ( this->resendLinkedListHead != nullptr || (v58 = 0, list_size != 0) ) /*0x141106d2d*/
        v58 = 1; /*0x141106d2f*/
      if ( DFFlag::RakNetCalculateApplicationFeedback2.value ) /*0x141106d44*/
        v30 = this->statistics.valueOverLastSecond[0]; /*0x141106d46*/
      else
        v30 = 0; /*0x141106d4f*/
      this->congestionManager->Update(this: this->congestionManager, a2: v30); /*0x141106d51*/
      this->statistics.BPSLimitByOutgoingBandwidthLimit = (unsigned __int64)(bitsPerSecondLimit + 7) >> 3; /*0x141106d5e*/
      this->statistics.BPSLimitByCongestionControl = this->congestionManager->GetBytesPerSecondLimitByCongestionControl(this: this->congestionManager); /*0x141106d75*/
      if ( time > this->lastBpsClear + 100000 ) /*0x141106d8c*/
      {
        bpsMetrics = this->bpsMetrics; /*0x141106d8e*/
        for ( i = 7; i != 0; --i ) /*0x141106d95*/
          RakNet::BPSTracker::ClearExpired1(this: bpsMetrics++, time); /*0x141106da6*/
        this->lastBpsClear = time; /*0x141106db8*/
      }
      if ( this->unreliableWithAckReceiptHistory.list_size != 0 ) /*0x141106dc6*/
      {
        v33 = 0; /*0x141106dcc*/
        do /*0x141106eb2*/
        {
          if ( this->unreliableWithAckReceiptHistory.listArray[v33].nextActionTime >= time ) /*0x141106de2*/
          {
            ++v33; /*0x141106eaa*/
          }
          else
          {
            v34 = RakNet::ReliabilityLayer::AllocateFromInternalPacketPool(this); /*0x141106df0*/
            input = &v34->userMemory; /*0x141106df3*/
            v34->userMemory.allocationScheme = 0; /*0x141106df7*/
            v35 = (unsigned __int8 *)RBX::Memory::allocate(size: 5u); /*0x141106e03*/
            v34->userMemory.data = v35; /*0x141106e08*/
            v34->userMemory.dataBitLength = 40; /*0x141106e0c*/
            *v35 = 15; /*0x141106e13*/
            *(_DWORD *)(v34->userMemory.data + 1) = this->unreliableWithAckReceiptHistory.listArray[v33].sendReceiptSerial; /*0x141106e26*/
            DataStructures::Queue<RakNet::RakPeer::RequestedConnectionStruct *>::Push( /*0x141106e3e*/
              this: &this->outputQueue,
              &input,
              file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
              line: 0x88Au);
            v36 = this->unreliableWithAckReceiptHistory.list_size; /*0x141106e43*/
            if ( v33 < v36 ) /*0x141106e4b*/
            {
              v37 = v33; /*0x141106e4d*/
              if ( v33 < v36 - 1 ) /*0x141106e54*/
              {
                do /*0x141106e9d*/
                {
                  v38 = v37 + 1; /*0x141106e60*/
                  listArray = this->unreliableWithAckReceiptHistory.listArray; /*0x141106e64*/
                  v40 = &listArray[(unsigned int)(v37 + 1)]; /*0x141106e72*/
                  v41 = &listArray[v37]; /*0x141106e79*/
                  v41->datagramNumber.val = v40->datagramNumber.val; /*0x141106e7e*/
                  v41->sendReceiptSerial = v40->sendReceiptSerial; /*0x141106e83*/
                  v41->nextActionTime = v40->nextActionTime; /*0x141106e8a*/
                  v37 = v38; /*0x141106e8e*/
                  v36 = this->unreliableWithAckReceiptHistory.list_size; /*0x141106e91*/
                }
                while ( v38 < v36 - 1 ); /*0x141106e9d*/
              }
              this->unreliableWithAckReceiptHistory.list_size = v36 - 1; /*0x141106ea2*/
            }
          }
        }
        while ( v33 < this->unreliableWithAckReceiptHistory.list_size ); /*0x141106eb2*/
        v25 = ruppHeader; /*0x141106eb8*/
      }
      if ( DFFlag::GameLoadDataStatistics.value ) /*0x141106ec3*/
      {
        for ( j = (DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *)this->resendLinkedListHead2; /*0x141106ed3*/
              j != nullptr;
              j = (DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *)this->resendLinkedListHead2 )
        {
          if ( j->userMemory.nextActionTime >= time ) /*0x141106ee4*/
            break; /*0x141106ee4*/
          Parent = this->resendBuffer2._Mypair._Myval2._Myval2._Myhead->_Parent; /*0x141106ef1*/
          Myhead = this->resendBuffer2._Mypair._Myval2._Myval2._Myhead; /*0x141106ef5*/
          while ( Parent->_Isnil == 0 ) /*0x141106efc*/
          {
            if ( Parent->_Myval.first.val >= j->userMemory.reliableMessageNumber.val ) /*0x141106f03*/
            {
              Myhead = Parent; /*0x141106f0b*/
              Parent = Parent->_Left; /*0x141106f0e*/
            }
            else
            {
              Parent = Parent->_Right; /*0x141106f05*/
            }
          }
          if ( Myhead->_Isnil != 0 || j->userMemory.reliableMessageNumber.val < Myhead->_Myval.first.val ) /*0x141106f22*/
            Myhead = this->resendBuffer2._Mypair._Myval2._Myval2._Myhead; /*0x141106f24*/
          v45 = std::_Tree_val<std::_Tree_simple_types<std::pair<std::string const,std::_Tree_iterator<std::_Tree_val<std::_Tree_simple_types<std::pair<RBX::CacheableContentProvider::PriorityKey const,RBX::CacheableContentProvider::ContentProviderTask>>>>>>>::_Extract( /*0x141106f2e*/
                  this: (std::_Tree_val<std::_Tree_simple_types<std::pair<std::string const ,std::shared_ptr<std::string const > > > > *)&this->resendBuffer2,
                  _Where: (std::_Tree_unchecked_const_iterator<std::_Tree_val<std::_Tree_simple_types<std::pair<std::string const ,std::shared_ptr<std::string const > > > >,std::_Iterator_base0>)Myhead);
          operator delete(ptr: v45); /*0x141106f3b*/
          j->userMemory.resendPrev->resendNext = j->userMemory.resendNext; /*0x141106f48*/
          j->userMemory.resendNext->resendPrev = j->userMemory.resendPrev; /*0x141106f54*/
          resendNext = j->userMemory.resendNext; /*0x141106f58*/
          if ( (DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *)this->resendLinkedListHead2 == j ) /*0x141106f66*/
          {
            this->resendLinkedListHead2 = resendNext; /*0x141106f68*/
            if ( resendNext == (RakNet::InternalPacket *)j ) /*0x141106f75*/
              this->resendLinkedListHead2 = nullptr; /*0x141106f77*/
          }
          RakNet::ReliabilityLayer::ReleaseToInternalPacketPool(this, ip: j); /*0x141106f88*/
        }
      }
      if ( v58 != 0 ) /*0x141106fa1*/
      {
        v53 = 0; /*0x141106fa6*/
        v47 = socket->_Rep; /*0x141106fab*/
        if ( v47 != nullptr ) /*0x141106fb3*/
        {
          _InterlockedIncrement((volatile signed __int32 *)&v47->_Uses); /*0x141106fb5*/
          v47 = socket->_Rep; /*0x141106fb9*/
        }
        v53._Ptr = (RakNet::RakNetSocket *)socket->_Ptr; /*0x141106fc2*/
        v53._Rep = v47; /*0x141106fc6*/
        RakNet::ReliabilityLayer::fillSendData( /*0x14110700e*/
          this,
          socket: &v53,
          systemAddress,
          time,
          bitsPerSecondLimit,
          updateBitStream,
          ruppHeader: v25,
          udmuxAddress,
          timeSinceLastTick: v15,
          ruppLength: v55,
          &dhf);
      }
      v48 = this->outgoingPacketBuffer.heap.list_size; /*0x141107013*/
      if ( __eh34_unwind(0) ) /*0xf1c0000000000004*/
      {
unwind_state_0:
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: socket); /*0xf1c0000000000008*/
        __eh34_propagate_exception_into_caller(0, -1); /*0xf1c000000000000c*/
      }
      __eh34_exit_wind_state(0, -1); /*0xf1c0000000000010*/
      v49 = socket->_Rep; /*0x141107019*/
      if ( v49 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v49->_Uses, 0xFFFFFFFF) == 1 ) /*0x141107032*/
      {
        v49->_Destroy(this: v49); /*0x14110703a*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v49->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141107044*/
          v49->_Delete_this(this: v49); /*0x14110704c*/
      }
      return v48; /*0x14110704f*/
    }
  }
  else
  {
    this->lastUpdateTime = time; /*0x141106a26*/
    v13 = socket->_Rep; /*0x141106a2d*/
    if ( v13 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v13->_Uses, 0xFFFFFFFF) == 1 ) /*0x141106a46*/
    {
      ((void (__fastcall *)(std::_Ref_count_base *, _QWORD, RakNet::SystemAddress *, __int64))v13->_Destroy)( /*0x141106a4e*/
        a1: v13,
        a2: (time * (unsigned __int128)0x624DD2F1A9FBE77uLL) >> 64,
        a3: systemAddress,
        a4: MTUSize);
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v13->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141106a58*/
        v13->_Delete_this(this: v13); /*0x141106a60*/
    }
    return 1; /*0x141106a63*/
  }
}

// Address: 0x141107070 | Name: ?WriteToBitStreamFromInternalPacket@ReliabilityLayer@RakNet@@AEAAIPEAVBitStream@2@QEBUInternalPacket@2@_K@Z
__int64 __fastcall RakNet::ReliabilityLayer::WriteToBitStreamFromInternalPacket(
        RakNet::ReliabilityLayer *this,
        RakNet::BitStream *bitStream,
        const RakNet::InternalPacket *const internalPacket,
        unsigned __int64 curTime)
{
  unsigned int numberOfBitsUsed; // ebp
  PacketReliability reliability; // ecx
  unsigned __int8 v8; // al
  PacketReliability v9; // eax
  PacketReliability v10; // ecx
  bool isJoinData; // al
  unsigned __int8 tempChar; // [rsp+48h] [rbp+10h] BYREF
  unsigned __int16 s; // [rsp+50h] [rbp+18h] BYREF

  numberOfBitsUsed = bitStream->numberOfBitsUsed; /*0x14110707c*/
  bitStream->numberOfBitsUsed = numberOfBitsUsed - (((_BYTE)numberOfBitsUsed - 1) & 7) + 7; /*0x141107092*/
  reliability = internalPacket->reliability; /*0x141107095*/
  if ( reliability == UNRELIABLE_WITH_ACK_RECEIPT ) /*0x1411070a2*/
  {
    v8 = 0; /*0x1411070a4*/
  }
  else if ( reliability == RELIABLE_WITH_ACK_RECEIPT ) /*0x1411070ab*/
  {
    v8 = 2; /*0x1411070ad*/
  }
  else
  {
    v8 = internalPacket->reliability; /*0x1411070b4*/
    if ( reliability == RELIABLE_ORDERED_WITH_ACK_RECEIPT ) /*0x1411070b7*/
      v8 = 3; /*0x1411070b7*/
  }
  tempChar = v8; /*0x1411070be*/
  RakNet::BitStream::WriteBits(this: bitStream, inByteArray: &tempChar, numberOfBitsToWrite: 3u, rightAlignedBits: true); /*0x1411070ca*/
  if ( internalPacket->splitPacketCount != 0 ) /*0x1411070d6*/
    RakNet::BitStream::Write1(this: bitStream); /*0x1411070d8*/
  else
    RakNet::BitStream::Write0(this: bitStream); /*0x1411070df*/
  bitStream->numberOfBitsUsed = bitStream->numberOfBitsUsed /*0x1411070f7*/
                              - (((unsigned __int8)bitStream->numberOfBitsUsed - 1) & 7)
                              + 7;
  s = internalPacket->dataBitLength; /*0x141107101*/
  RakNet::BitStream::WriteAlignedVar16(this: bitStream, inByteArray: (const char *)&s); /*0x141107106*/
  v9 = internalPacket->reliability; /*0x14110710b*/
  if ( v9 == RELIABLE /*0x141107125*/
    || v9 == RELIABLE_SEQUENCED
    || v9 == RELIABLE_ORDERED
    || v9 == RELIABLE_WITH_ACK_RECEIPT
    || v9 == RELIABLE_ORDERED_WITH_ACK_RECEIPT )
  {
    RakNet::BitStream::Write<RakNet::uint24_t>(this: bitStream, inTemplateVar: &internalPacket->reliableMessageNumber); /*0x14110712d*/
  }
  bitStream->numberOfBitsUsed = bitStream->numberOfBitsUsed /*0x141107140*/
                              - (((unsigned __int8)bitStream->numberOfBitsUsed - 1) & 7)
                              + 7;
  v10 = internalPacket->reliability; /*0x141107143*/
  if ( (v10 == UNRELIABLE_SEQUENCED || v10 == RELIABLE_SEQUENCED) /*0x141107171*/
    && (RakNet::BitStream::Write<RakNet::uint24_t>(this: bitStream, inTemplateVar: &internalPacket->sequencingIndex),
        (v10 = internalPacket->reliability) == UNRELIABLE_SEQUENCED)
    || ((v10 - 3) & 0xFFFFFFFA) == 0 && v10 != NUMBER_OF_RELIABILITIES )
  {
    RakNet::BitStream::Write<RakNet::uint24_t>(this: bitStream, inTemplateVar: &internalPacket->orderingIndex); /*0x14110717a*/
    tempChar = internalPacket->orderingChannel; /*0x14110718b*/
    RakNet::BitStream::WriteAlignedVar8(this: bitStream, inByteArray: (const char *)&tempChar); /*0x14110718f*/
  }
  if ( internalPacket->splitPacketCount != 0 ) /*0x141107198*/
  {
    RakNet::BitStream::WriteAlignedVar32(this: bitStream, inByteArray: (const char *)&internalPacket->splitPacketCount); /*0x1411071a1*/
    RakNet::BitStream::WriteAlignedVar16(this: bitStream, inByteArray: (const char *)&internalPacket->splitPacketId); /*0x1411071ad*/
    RakNet::BitStream::WriteAlignedVar32(this: bitStream, inByteArray: (const char *)&internalPacket->splitPacketIndex); /*0x1411071b9*/
  }
  RakNet::BitStream::WriteAlignedBytes( /*0x1411071d1*/
    this: bitStream,
    inByteArray: internalPacket->data,
    numberOfBytesToWrite: (internalPacket->dataBitLength + 7) >> 3);
  isJoinData = internalPacket->isJoinData; /*0x1411071d6*/
  if ( isJoinData ) /*0x1411071dc*/
    bitStream->isJoinData = isJoinData; /*0x1411071de*/
  return bitStream->numberOfBitsUsed - numberOfBitsUsed; /*0x1411071e4*/
}

// Address: 0x141107200 | Name: ?addToResendBuffer@ReliabilityLayer@RakNet@@AEAAX_KH@Z
void __fastcall RakNet::ReliabilityLayer::addToResendBuffer(
        RakNet::ReliabilityLayer *this,
        unsigned __int64 time,
        int ruppLength)
{
  RakNet::InternalPacket *data; // rsi
  PacketReliability reliability; // ecx
  int v8; // edx
  unsigned int v9; // ecx
  unsigned int v10; // r15d
  bool v11; // bl
  unsigned int v12; // ebp
  int v13; // ecx
  unsigned int v14; // ebp
  int v15; // eax
  bool v16; // r15
  unsigned int val; // eax
  RakNet::InternalPacket **Myfirst; // r8
  __int64 v19; // rcx
  __int64 v20; // rax
  unsigned int unacknowledgedDataGrams; // eax
  RakNet::InternalPacket *resendLinkedListHead; // rax
  RakNet::InternalPacket *resendPrev; // rcx
  unsigned __int64 v24; // r14
  unsigned int sendReceiptSerial; // ebp
  unsigned int list_size; // edx
  unsigned int allocation_size; // eax
  signed int v28; // eax
  RakNet::ReliabilityLayer::UnreliableWithAckReceiptNode *v29; // rbx
  RakNet::ReliabilityLayer::UnreliableWithAckReceiptNode *listArray; // rcx
  unsigned int v31; // r8d
  __int64 v32; // rdx
  RakNet::ReliabilityLayer::UnreliableWithAckReceiptNode *v33; // rcx
  bool v34; // zf
  __int64 v35; // rcx
  unsigned int v36; // eax
  RakNet::InternalPacket **v37; // r8
  __int64 v38; // rcx
  signed int v39; // eax
  unsigned int v40; // [rsp+70h] [rbp+8h]
  char v41; // [rsp+88h] [rbp+20h] BYREF

  while ( this->outgoingPacketBuffer.heap.list_size != 0 ) /*0x141107224*/
  {
    if ( this->statistics.isLimitedByOutgoingBandwidthLimit ) /*0x141107230*/
      return; /*0x141107237*/
    data = this->outgoingPacketBuffer.heap.listArray->data; /*0x141107244*/
    if ( data->data == nullptr ) /*0x14110724d*/
    {
      DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::Pop( /*0x141107258*/
        this: &this->outgoingPacketBuffer,
        startingIndex: 0);
      --this->statistics.messageInSendBuffer[data->priority]; /*0x141107261*/
      this->statistics.bytesInSendBuffer[data->priority] = this->statistics.bytesInSendBuffer[data->priority] /*0x14110728a*/
                                                         - (double)((data->dataBitLength + 7) >> 3);
      RakNet::ReliabilityLayer::ReleaseToInternalPacketPool( /*0x141107299*/
        this,
        ip: (DataStructures::MemoryPool<RakNet::InternalPacket>::MemoryWithPage *)data);
      continue; /*0x14110729e*/
    }
    reliability = data->reliability; /*0x1411072a3*/
    v8 = 24; /*0x1411072a6*/
    if ( (unsigned int)(reliability - 2) <= 2 || (unsigned int)(reliability - 6) <= 1 ) /*0x1411072b9*/
      v8 = 48; /*0x1411072bb*/
    if ( (reliability == UNRELIABLE_SEQUENCED || reliability == RELIABLE_SEQUENCED) /*0x1411072df*/
      && (v8 += 24, reliability == UNRELIABLE_SEQUENCED)
      || ((reliability - 3) & 0xFFFFFFFA) == 0 && reliability != NUMBER_OF_RELIABILITIES )
    {
      v8 += 32; /*0x1411072e1*/
    }
    v9 = v8 + 80; /*0x1411072e4*/
    if ( (int)data->splitPacketCount <= 0 ) /*0x1411072eb*/
      v9 = v8; /*0x1411072eb*/
    data->headerLength = v9; /*0x1411072ee*/
    v10 = v9 + data->dataBitLength; /*0x1411072f5*/
    v11 = this->congestionManager->includeTimestampWithDatagrams(this: this->congestionManager); /*0x141107308*/
    v12 = this->congestionManager->GetMTU(this: this->congestionManager); /*0x14110731b*/
    v13 = -9; /*0x14110731d*/
    if ( v11 ) /*0x141107329*/
      v13 = -13; /*0x141107329*/
    v14 = v13 - ruppLength + v12; /*0x14110732f*/
    if ( this->rbxSessionCrypto._Ptr != nullptr /*0x141107339*/
      && RBX::Security::SessionCrypto::getEnabledForRaknet(this: this->rbxSessionCrypto._Ptr) )
    {
      v14 -= 18; /*0x141107342*/
    }
    if ( v10 + this->datagramSizeSoFar > 8 * v14 ) /*0x141107357*/
      return; /*0x141107357*/
    v15 = data->reliability; /*0x14110735d*/
    v16 = v15 != 5 && v15 > 1 && v15 < 8; /*0x141107374*/
    DataStructures::Heap<unsigned __int64,RakNet::InternalPacket *,0>::Pop( /*0x141107380*/
      this: &this->outgoingPacketBuffer,
      startingIndex: 0);
    --this->statistics.messageInSendBuffer[data->priority]; /*0x141107389*/
    this->statistics.bytesInSendBuffer[data->priority] = this->statistics.bytesInSendBuffer[data->priority] /*0x1411073b2*/
                                                       - (double)((data->dataBitLength + 7) >> 3);
    if ( v16 ) /*0x1411073be*/
    {
      data->messageNumberAssigned = true; /*0x1411073c4*/
      data->reliableMessageNumber.val = this->sendReliableMessageNumberIndex.val; /*0x1411073ce*/
      data->nextActionTime = time + this->congestionManager->GetRTOForRetransmission(this: this->congestionManager); /*0x1411073e3*/
      if ( DFFlag::RCCJoinTransmissionStats.value ) /*0x1411073ee*/
        data->nextActionTimeSetByNak = false; /*0x1411073f0*/
      val = data->reliableMessageNumber.val; /*0x1411073f4*/
      Myfirst = this->resendBuffer._Mypair._Myval2._Myfirst; /*0x1411073f6*/
      v19 = this->resendBuffer._Mypair._Myval2._Mylast - Myfirst; /*0x141107407*/
      if ( ((unsigned int)v19 & ((_DWORD)v19 - 1)) != 0 ) /*0x141107410*/
        v20 = val % (unsigned int)v19; /*0x14110741a*/
      else
        v20 = ((_DWORD)v19 - 1) & val; /*0x141107412*/
      Myfirst[v20] = data; /*0x14110741c*/
      if ( data->isJoinData ) /*0x141107420*/
      {
        ++this->statistics.ds.totalJoinPacketsPendingCount; /*0x141107426*/
        if ( DFFlag::RCCJoinTransmissionStats.value ) /*0x141107433*/
          ++this->statistics.ds.joinInternalSentCount; /*0x141107435*/
      }
      ++this->statistics.messagesInResendBuffer; /*0x14110743b*/
      this->statistics.bytesInResendBuffer += (unsigned __int64)(data->dataBitLength + 7) >> 3; /*0x14110744b*/
      this->unacknowledgedBytes += (data->dataBitLength + data->headerLength + 7) >> 3; /*0x14110745e*/
      unacknowledgedDataGrams = this->unacknowledgedDataGrams; /*0x141107464*/
      if ( unacknowledgedDataGrams < 0xFFFFFF ) /*0x14110746f*/
        this->unacknowledgedDataGrams = unacknowledgedDataGrams + 1; /*0x141107473*/
      resendLinkedListHead = this->resendLinkedListHead; /*0x141107479*/
      if ( resendLinkedListHead != nullptr ) /*0x141107483*/
      {
        data->resendNext = resendLinkedListHead; /*0x1411074a5*/
        resendPrev = this->resendLinkedListHead->resendPrev; /*0x1411074b0*/
        data->resendPrev = resendPrev; /*0x1411074b4*/
        resendPrev->resendNext = data; /*0x1411074b8*/
        this->resendLinkedListHead->resendPrev = data; /*0x1411074c3*/
      }
      else
      {
        data->resendNext = data; /*0x141107485*/
        data->resendPrev = data; /*0x141107489*/
        this->resendLinkedListHead = data; /*0x14110748d*/
      }
      ++this->sendReliableMessageNumberIndex.val; /*0x141107494*/
      HIBYTE(this->sendReliableMessageNumberIndex.val) = 0; /*0x14110749a*/
    }
    else if ( data->reliability == UNRELIABLE_WITH_ACK_RECEIPT ) /*0x1411074dd*/
    {
      v24 = this->congestionManager->GetRTOForRetransmission(this: this->congestionManager) + time; /*0x1411074f3*/
      sendReceiptSerial = data->sendReceiptSerial; /*0x1411074f7*/
      v40 = this->congestionManager->GetNextDatagramSequenceNumber(this: this->congestionManager, result: &v41)->val /*0x141107519*/
          + this->packetsToSendThisUpdateDatagramBoundaries.list_size;
      HIBYTE(v40) = 0; /*0x14110751d*/
      list_size = this->unreliableWithAckReceiptHistory.list_size; /*0x141107522*/
      allocation_size = this->unreliableWithAckReceiptHistory.allocation_size; /*0x141107528*/
      if ( list_size == allocation_size ) /*0x141107530*/
      {
        if ( allocation_size == 0 ) /*0x141107538*/
        {
          this->unreliableWithAckReceiptHistory.allocation_size = 16; /*0x14110753e*/
          v28 = 16; /*0x141107548*/
          goto LABEL_46; /*0x141107548*/
        }
        v34 = 2 * allocation_size == 0; /*0x1411075e6*/
        v28 = 2 * allocation_size; /*0x1411075e6*/
        this->unreliableWithAckReceiptHistory.allocation_size = v28; /*0x1411075e8*/
        if ( v34 ) /*0x1411075ee*/
        {
          v29 = nullptr; /*0x1411075f4*/
        }
        else
        {
LABEL_46:
          v29 = (RakNet::ReliabilityLayer::UnreliableWithAckReceiptNode *)operator new(size: saturated_mul(v28, 0x10u)); /*0x141107568*/
          list_size = this->unreliableWithAckReceiptHistory.list_size; /*0x141107578*/
        }
        listArray = this->unreliableWithAckReceiptHistory.listArray; /*0x14110757e*/
        if ( listArray != nullptr ) /*0x141107588*/
        {
          v31 = 0; /*0x14110758a*/
          if ( list_size != 0 ) /*0x14110758f*/
          {
            do /*0x1411075cf*/
            {
              v32 = v31; /*0x1411075a3*/
              v33 = this->unreliableWithAckReceiptHistory.listArray; /*0x1411075a6*/
              v29[v32].datagramNumber.val = v33[v31].datagramNumber.val; /*0x1411075b0*/
              v29[v32].sendReceiptSerial = v33[v31].sendReceiptSerial; /*0x1411075b7*/
              v29[v32].nextActionTime = v33[v31++].nextActionTime; /*0x1411075c0*/
            }
            while ( v31 < this->unreliableWithAckReceiptHistory.list_size ); /*0x1411075cf*/
            listArray = this->unreliableWithAckReceiptHistory.listArray; /*0x1411075d1*/
          }
          operator delete(ptr: listArray); /*0x1411075d8*/
        }
        this->unreliableWithAckReceiptHistory.listArray = v29; /*0x1411075dd*/
      }
      else
      {
        v29 = this->unreliableWithAckReceiptHistory.listArray; /*0x1411075f8*/
      }
      v35 = this->unreliableWithAckReceiptHistory.list_size; /*0x141107605*/
      v29[v35].datagramNumber.val = v40; /*0x14110760c*/
      v29[v35].sendReceiptSerial = sendReceiptSerial; /*0x14110760f*/
      v29[v35].nextActionTime = v24; /*0x141107613*/
      ++this->unreliableWithAckReceiptHistory.list_size; /*0x141107618*/
    }
    if ( DFFlag::TransportLibraryTest.value /*0x141107639*/
      && this->tLibTestClientStats.bytesToSend._Storage._Value != 0
      && this->tLibTestClientStats.startTime._Storage._Value == 0 )
    {
      _InterlockedExchange64( /*0x141107642*/
        (volatile __int64 *)&this->tLibTestClientStats.startTime,
        RakNet::GetTimeUS(isNetworkSynced: false));
    }
    RakNet::BPSTracker::Push1( /*0x14110765c*/
      this: &this->bpsMetrics[1],
      time,
      value1: (unsigned __int64)(data->dataBitLength + 7) >> 3);
    RakNet::ReliabilityLayer::PushPacket(this, time, internalPacket: data, isReliable: v16); /*0x14110766e*/
    ++data->timesSent; /*0x141107673*/
    if ( data->splitPacketCount != 0 ) /*0x14110767a*/
      ++this->statistics.numberOfSplitMessages; /*0x141107684*/
    else
      ++this->statistics.numberOfUnsplitMessages; /*0x14110767c*/
    v36 = this->sendReliableMessageNumberIndex.val; /*0x14110768a*/
    v37 = this->resendBuffer._Mypair._Myval2._Myfirst; /*0x141107690*/
    v38 = this->resendBuffer._Mypair._Myval2._Mylast - v37; /*0x1411076a1*/
    if ( ((unsigned int)v38 & ((_DWORD)v38 - 1)) != 0 ) /*0x1411076aa*/
      v39 = v36 % (unsigned int)v38; /*0x1411076b4*/
    else
      v39 = (v38 - 1) & v36; /*0x1411076ac*/
    if ( v37[v39] != nullptr ) /*0x1411076bd*/
      return; /*0x1411076bd*/
  }
}

// Address: 0x1411076f0 | Name: ?checkSendNak@ReliabilityLayer@RakNet@@AEAAXV?$shared_ptr@URakNetSocket@RakNet@@@std@@AEAUSystemAddress@2@_KAEAVBitStream@2@AEBV?$shared_ptr@VRupp@1Network@RBX@@@4@AEBU52@H@Z
void __fastcall RakNet::ReliabilityLayer::checkSendNak(
        RakNet::ReliabilityLayer *this,
        std::shared_ptr<RBX::File> *socket,
        RakNet::SystemAddress *systemAddress,
        unsigned __int64 time,
        RakNet::BitStream *updateBitStream,
        const std::shared_ptr<RBX::Network::Rupp::Rupp> *ruppHeader,
        const RakNet::SystemAddress *udmuxAddress,
        unsigned int ruppLength)
{
  RakNet::BitStream *v10; // rdi
  bool v11; // r15
  int numberOfBitsUsed; // esi
  int MaxDatagramSizeExcludingMessageHeaderBytes; // eax
  std::_Ref_count_base *Rep; // rcx
  std::_Ref_count_base *v15; // rbx
  std::shared_ptr<RBX::File> v16; // [rsp+50h] [rbp-31h] BYREF
  RakNet::DatagramHeaderFormat dhfNAK; // [rsp+60h] [rbp-21h] BYREF
  unsigned __int8 v18; // [rsp+D0h] [rbp+4Fh] BYREF
  std::shared_ptr<RBX::File> *paddingLocation; // [rsp+D8h] [rbp+57h]
  const RakNet::SystemAddress *v20; // [rsp+E0h] [rbp+5Fh]
  unsigned __int64 v21; // [rsp+E8h] [rbp+67h]

  v21 = time; /*0x1411076f0*/
  v20 = systemAddress; /*0x1411076f5*/
  paddingLocation = socket; /*0x1411076fa*/
  if ( this->NAKs.ranges.orderedList.list_size != 0 ) /*0x141107724*/
  {
    v10 = updateBitStream; /*0x14110772a*/
    __wind /*0xf1c0000000000010*/
    {
      RakNet::BitStream::Reset(this: updateBitStream); /*0x141107731*/
      if ( DFFlag::RuppHeaderFromClientEnabled3.value && ruppHeader->_Ptr != nullptr ) /*0x141107749*/
        RBX::Network::Rupp::Rupp::serialize(this: ruppHeader->_Ptr, b: v10); /*0x14110774e*/
      *(_WORD *)&dhfNAK.isJoinData = 0; /*0x141107753*/
      *(_WORD *)&dhfNAK.isACK = 256; /*0x141107759*/
      v11 = (this->commonCapabilities & 0x8000) != 0; /*0x14110777f*/
      this->congestionManager->includeTimestampWithDatagrams(this: this->congestionManager); /*0x14110778d*/
      RakNet::BitStream::Write1(this: v10); /*0x14110779a*/
      RakNet::BitStream::Write0(this: v10); /*0x14110788e*/
      RakNet::BitStream::Write1(this: v10); /*0x141107896*/
      if ( v11 ) /*0x14110789e*/
      {
        v10->numberOfBitsUsed = v10->numberOfBitsUsed - (((unsigned __int8)v10->numberOfBitsUsed - 1) & 7) + 7; /*0x1411078b2*/
        numberOfBitsUsed = v10->numberOfBitsUsed; /*0x141107990*/
        if ( RakNet::BitStream::IsNetworkOrder() ) /*0x141107993*/
        {
          RakNet::BitStream::WriteBits( /*0x1411079d6*/
            this: v10,
            inByteArray: (unsigned __int8 *)&dhfNAK.extraPadding,
            numberOfBitsToWrite: 0x10u,
            rightAlignedBits: true);
        }
        else
        {
          RBX::Network::NetworkStream::ReverseBytes( /*0x1411079aa*/
            inByteArray: (unsigned __int8 *)&dhfNAK.extraPadding,
            inOutByteArray: &v18,
            length: 2u);
          RakNet::BitStream::WriteBits(this: v10, inByteArray: &v18, numberOfBitsToWrite: 0x10u, rightAlignedBits: true); /*0x1411079bf*/
        }
      }
      else
      {
        numberOfBitsUsed = (int)paddingLocation; /*0x1411079dd*/
      }
      MaxDatagramSizeExcludingMessageHeaderBytes = RakNet::ReliabilityLayer::GetMaxDatagramSizeExcludingMessageHeaderBytes( /*0x1411079e9*/
                                                     this,
                                                     ruppLength);
      DataStructures::RangeList<RakNet::uint24_t>::Serialize( /*0x141107a01*/
        this: &this->NAKs,
        in: v10,
        maxBits: 8 * MaxDatagramSizeExcludingMessageHeaderBytes,
        clearSerialized: 1u);
      v16 = 0; /*0x141107a09*/
      Rep = socket->_Rep; /*0x141107a0e*/
      if ( Rep != nullptr ) /*0x141107a15*/
      {
        _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x141107a17*/
        Rep = socket->_Rep; /*0x141107a1b*/
      }
      v16._Ptr = socket->_Ptr; /*0x141107a22*/
      v16._Rep = Rep; /*0x141107a26*/
      RakNet::ReliabilityLayer::SendBitStream( /*0x141107a57*/
        this,
        socket: &v16,
        systemAddress: v20,
        bitStream: v10,
        currentTime: v21,
        ruppHeader,
        udmuxAddress,
        paddingLocation: numberOfBitsUsed);
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: paddingLocation); /*0xf1c0000000000008*/
    }
  }
  v15 = socket->_Rep; /*0x141107a5d*/
  if ( v15 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v15->_Uses, 0xFFFFFFFF) == 1 ) /*0x141107a75*/
  {
    v15->_Destroy(this: v15); /*0x141107a7d*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v15->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141107a87*/
      v15->_Delete_this(this: v15); /*0x141107a8f*/
  }
}

// Address: 0x141107c30 | Name: ?createDatagramsUpToBandwidth@ReliabilityLayer@RakNet@@AEAAX_K0AEAUDatagramHeaderFormat@2@HI@Z
void __fastcall RakNet::ReliabilityLayer::createDatagramsUpToBandwidth(
        RakNet::ReliabilityLayer *this,
        unsigned __int64 time,
        unsigned __int64 timeSinceLastTick,
        RakNet::DatagramHeaderFormat *dhf,
        int ruppLength,
        unsigned int bitsPerSecondLimit)
{
  RakNet::CCRakNetBase *congestionManager; // rcx
  int v11; // eax
  int v12; // edi
  int v13; // ecx
  unsigned int v14; // eax
  int v15; // eax
  int v16; // eax
  BOOL v17; // [rsp+20h] [rbp-40h]
  RakNet::TxBwInfluencers txBwInfluencers; // [rsp+30h] [rbp-30h] BYREF

  congestionManager = this->congestionManager; /*0x141107c56*/
  memset(&txBwInfluencers, 0, sizeof(txBwInfluencers)); /*0x141107c60*/
  v11 = congestionManager->GetTransmissionBandwidth( /*0x141107c9e*/
          this: congestionManager,
          a2: time,
          a3: timeSinceLastTick,
          a4: this->unacknowledgedBytes,
          a5: dhf->isContinuousSend,
          a6: &txBwInfluencers);
  v12 = v11; /*0x141107ca8*/
  if ( DFFlag::RakNetUseSlidingWindow4.value ) /*0x141107caa*/
  {
    this->allDatagramSizesSoFar = 0; /*0x141107cb0*/
    if ( DFFlag::RakNetReportTransmissionBw2.value ) /*0x141107cbe*/
    {
      v13 = v11; /*0x141107cc2*/
      if ( v11 < 0 ) /*0x141107cc7*/
        v13 = 0; /*0x141107cc7*/
      this->perSecTxBwData.txBwInfluencers.totalGetTxBwCount += txBwInfluencers.totalGetTxBwCount; /*0x141107ccb*/
      this->perSecTxBwData.txBwInfluencers.bwLimitedByAppCount += txBwInfluencers.bwLimitedByAppCount; /*0x141107cd4*/
      this->perSecTxBwData.txBwInfluencers.zeroTargetSpeedStartTimeCount += txBwInfluencers.zeroTargetSpeedStartTimeCount; /*0x141107cdd*/
      this->perSecTxBwData.txBwInfluencers.nonZeroTargetSpeedStartTimeCount += txBwInfluencers.nonZeroTargetSpeedStartTimeCount; /*0x141107ce6*/
      this->perSecTxBwData.txBwInfluencers.uncappedByteAllowanceFromTargetSpeed += txBwInfluencers.uncappedByteAllowanceFromTargetSpeed; /*0x141107cef*/
      this->perSecTxBwData.txBwInfluencers.bytesGivenByTargetSpeed += txBwInfluencers.bytesGivenByTargetSpeed; /*0x141107cf8*/
      this->perSecTxBwData.txBwInfluencers.bwCappedDueToTargetSpeedCount += txBwInfluencers.bwCappedDueToTargetSpeedCount; /*0x141107d01*/
      this->perSecTxBwData.txBwInfluencers.bwCappedDueTo2xTargetSpeedCount += txBwInfluencers.bwCappedDueTo2xTargetSpeedCount; /*0x141107d0a*/
      this->perSecTxBwData.txBwInfluencers.bwcappedDueToMaxBytesInFlightCount += txBwInfluencers.bwcappedDueToMaxBytesInFlightCount; /*0x141107d13*/
      this->perSecTxBwData.txBwInfluencers.bwCappedDueToMaxPacketsInFlightCount += txBwInfluencers.bwCappedDueToMaxPacketsInFlightCount; /*0x141107d1c*/
      this->perSecTxBwData.totalAvailableCapacity += v13; /*0x141107d22*/
      this->perSecTxBwData.txBwInfluencers.bwCappedDueToAllBytesInFlightLostCount += txBwInfluencers.bwCappedDueToAllBytesInFlightLostCount; /*0x141107d2b*/
    }
  }
  else
  {
    LOBYTE(v17) = dhf->isContinuousSend; /*0x141107d5e*/
    v11 = this->congestionManager->GetRetransmissionBandwidth( /*0x141107d62*/
            this: this->congestionManager,
            a2: time,
            a3: timeSinceLastTick,
            a4: this->unacknowledgedBytes,
            a5: v17,
            a6: &txBwInfluencers);
  }
  if ( v11 > 0 || v12 > 0 ) /*0x141107d6f*/
  {
    RakNet::ReliabilityLayer::fillToRetransmissionBandwidth(this, time, retransmissionBandwidth: v11, ruppLength); /*0x141107d86*/
    if ( !DFFlag::RakNetUseSlidingWindow4.value ) /*0x141107d92*/
      goto LABEL_22; /*0x141107d92*/
    v14 = this->allDatagramSizesSoFar + 7; /*0x141107d9a*/
    this->allDatagramSizesSoFar = 0; /*0x141107d9d*/
    v12 -= v14 >> 3; /*0x141107da7*/
  }
  else
  {
    this->statistics.isLimitedByCongestionControl = true; /*0x141107d71*/
  }
  if ( DFFlag::RakNetUseSlidingWindow4.value ) /*0x141107db0*/
  {
    if ( DFFlag::RakNetReportTransmissionBw2.value ) /*0x141107db9*/
    {
      v15 = v12; /*0x141107dbd*/
      if ( v12 < 0 ) /*0x141107dbf*/
        v15 = 0; /*0x141107dbf*/
      this->perSecTxBwData.availableCapacity += v15; /*0x141107dc3*/
    }
    else if ( DFFlag::RakNetComputeTxBw.value ) /*0x141107dd2*/
    {
      v16 = v12; /*0x141107dd6*/
      if ( v12 < 0 ) /*0x141107dd8*/
        v16 = 0; /*0x141107dd8*/
      this->perSecTxBwCounters_deprecated.availableCapacity += v16; /*0x141107ddc*/
    }
  }
LABEL_22:
  if ( (int)((this->allDatagramSizesSoFar + 7) >> 3) < v12 ) /*0x141107df0*/
  {
    this->allDatagramSizesSoFar = 0; /*0x141107dfc*/
    RakNet::ReliabilityLayer::fillToTransmissionBandwidth( /*0x141107e0b*/
      this,
      time,
      bitsPerSecondLimit,
      transmissionBandwidth: v12,
      ruppLength);
  }
}

// Address: 0x141107e30 | Name: ?fillSendData@ReliabilityLayer@RakNet@@AEAAXV?$shared_ptr@URakNetSocket@RakNet@@@std@@AEAUSystemAddress@2@_KIAEAVBitStream@2@AEBV?$shared_ptr@VRupp@1Network@RBX@@@4@AEBU52@2HAEAUDatagramHeaderFormat@2@@Z
void __fastcall RakNet::ReliabilityLayer::fillSendData(
        RakNet::ReliabilityLayer *this,
        std::shared_ptr<RBX::File> *socket,
        RakNet::SystemAddress *systemAddress,
        unsigned __int64 time,
        unsigned int bitsPerSecondLimit,
        RakNet::BitStream *updateBitStream,
        const std::shared_ptr<RBX::Network::Rupp::Rupp> *ruppHeader,
        const RakNet::SystemAddress *udmuxAddress,
        unsigned __int64 timeSinceLastTick,
        int ruppLength,
        RakNet::DatagramHeaderFormat *dhf)
{
  unsigned int allocation_size; // eax
  unsigned int v16; // eax
  unsigned int v17; // eax
  unsigned int v18; // eax
  std::_Ref_count_base *Rep; // rcx
  std::_Ref_count_base *v20; // rbx
  std::shared_ptr<RakNet::RakNetSocket> v21; // [rsp+40h] [rbp-28h] BYREF

  *(_WORD *)&dhf->isACK = 0; /*0x141107e61*/
  dhf->hasBAndAS = false; /*0x141107e67*/
  allocation_size = this->packetsToSendThisUpdate.allocation_size; /*0x141107e6b*/
  if ( allocation_size != 0 ) /*0x141107e76*/
  {
    if ( allocation_size > 0x200 ) /*0x141107e7d*/
    {
      operator delete(ptr: this->packetsToSendThisUpdate.listArray); /*0x141107e86*/
      this->packetsToSendThisUpdate.allocation_size = 0; /*0x141107e8b*/
      this->packetsToSendThisUpdate.listArray = nullptr; /*0x141107e92*/
    }
    this->packetsToSendThisUpdate.list_size = 0; /*0x141107e99*/
  }
  v16 = this->packetsToDeallocThisUpdate.allocation_size; /*0x141107ea0*/
  if ( v16 != 0 ) /*0x141107ea8*/
  {
    if ( v16 > 0x200 ) /*0x141107eaf*/
    {
      operator delete(ptr: this->packetsToDeallocThisUpdate.listArray); /*0x141107eb8*/
      this->packetsToDeallocThisUpdate.allocation_size = 0; /*0x141107ebd*/
      this->packetsToDeallocThisUpdate.listArray = nullptr; /*0x141107ec4*/
    }
    this->packetsToDeallocThisUpdate.list_size = 0; /*0x141107ecb*/
  }
  v17 = this->packetsToSendThisUpdateDatagramBoundaries.allocation_size; /*0x141107ed2*/
  if ( v17 != 0 ) /*0x141107eda*/
  {
    if ( v17 > 0x200 ) /*0x141107ee1*/
    {
      operator delete(ptr: this->packetsToSendThisUpdateDatagramBoundaries.listArray); /*0x141107eea*/
      this->packetsToSendThisUpdateDatagramBoundaries.allocation_size = 0; /*0x141107eef*/
      this->packetsToSendThisUpdateDatagramBoundaries.listArray = nullptr; /*0x141107ef6*/
    }
    this->packetsToSendThisUpdateDatagramBoundaries.list_size = 0; /*0x141107efd*/
  }
  v18 = this->datagramSizesInBytes.allocation_size; /*0x141107f04*/
  if ( v18 != 0 ) /*0x141107f0c*/
  {
    if ( v18 > 0x200 ) /*0x141107f13*/
    {
      operator delete(ptr: this->datagramSizesInBytes.listArray); /*0x141107f1c*/
      this->datagramSizesInBytes.allocation_size = 0; /*0x141107f21*/
      this->datagramSizesInBytes.listArray = nullptr; /*0x141107f28*/
    }
    this->datagramSizesInBytes.list_size = 0; /*0x141107f2f*/
  }
  this->datagramSizeSoFar = 0; /*0x141107f36*/
  __wind /*0xf1c0000000000010*/
  {
    RakNet::ReliabilityLayer::createDatagramsUpToBandwidth( /*0x141107f64*/
      this,
      time,
      timeSinceLastTick,
      dhf,
      ruppLength,
      bitsPerSecondLimit);
    v21 = 0; /*0x141107f6c*/
    Rep = socket->_Rep; /*0x141107f72*/
    if ( Rep != nullptr ) /*0x141107f79*/
    {
      _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x141107f7b*/
      Rep = socket->_Rep; /*0x141107f7f*/
    }
    v21._Ptr = (RakNet::RakNetSocket *)socket->_Ptr; /*0x141107f86*/
    v21._Rep = Rep; /*0x141107f8b*/
    RakNet::ReliabilityLayer::sendDatagrams( /*0x141107fc2*/
      this,
      socket: &v21,
      systemAddress,
      updateBitStream,
      ruppHeader,
      udmuxAddress,
      dhf);
    RakNet::ReliabilityLayer::ClearPacketsAndDatagrams(this); /*0x141107fca*/
    this->bandwidthExceededStatistic = this->outgoingPacketBuffer.heap.list_size != 0; /*0x141107fd9*/
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: socket); /*0xf1c0000000000008*/
  }
  v20 = socket->_Rep; /*0x141107fdf*/
  if ( v20 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v20->_Uses, 0xFFFFFFFF) == 1 ) /*0x141107ff7*/
  {
    v20->_Destroy(this: v20); /*0x141107fff*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v20->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141108009*/
      v20->_Delete_this(this: v20); /*0x141108011*/
  }
}

// Address: 0x141108030 | Name: ?fillToRetransmissionBandwidth@ReliabilityLayer@RakNet@@AEAAX_KHH@Z
void __fastcall RakNet::ReliabilityLayer::fillToRetransmissionBandwidth(
        RakNet::ReliabilityLayer *this,
        unsigned __int64 time,
        int retransmissionBandwidth,
        int ruppLength)
{
  RakNet::InternalPacket *resendLinkedListHead; // rsi
  char v8; // r12
  int v9; // r14d
  bool v10; // di
  unsigned int v11; // eax
  int v12; // ecx
  unsigned int v13; // ebp
  unsigned int datagramSizeSoFar; // edx
  RakNet::InternalPacket *v15; // rdx
  RakNet::InternalPacket *resendNext; // rax
  RakNet::InternalPacket *v17; // rax
  RakNet::InternalPacket *resendPrev; // rcx
  unsigned int v19; // edx
  unsigned int v20; // eax
  unsigned int v21; // esi
  signed int v22; // eax
  unsigned int *v23; // rax
  unsigned int *v24; // rdi
  unsigned int *v25; // rcx
  __int64 v26; // r8
  __int64 v27; // rdx
  bool v28; // zf
  unsigned int v29; // edx
  unsigned int v30; // eax
  unsigned int v31; // esi
  signed int v32; // eax
  unsigned int *v33; // rax
  unsigned int *v34; // rdi
  unsigned int *v35; // rcx
  __int64 v36; // r8
  __int64 v37; // rdx
  unsigned int list_size; // edx
  unsigned int allocation_size; // eax
  unsigned int v40; // esi
  signed int v41; // eax
  unsigned int *v42; // rax
  unsigned int *listArray; // rdi
  unsigned int *v44; // rcx
  __int64 v45; // r8
  __int64 v46; // rdx
  unsigned int v47; // edx
  unsigned int v48; // eax
  signed int v49; // eax
  unsigned int *v50; // rax
  __int64 v51; // r8
  __int64 v52; // rdx

  this->statistics.isLimitedByCongestionControl = false; /*0x14110803e*/
  this->allDatagramSizesSoFar = 0; /*0x141108048*/
  if ( retransmissionBandwidth <= 0 ) /*0x14110805b*/
    return; /*0x14110805b*/
  do /*0x141108589*/
  {
    resendLinkedListHead = this->resendLinkedListHead; /*0x141108080*/
    v8 = 0; /*0x141108087*/
    if ( resendLinkedListHead == nullptr ) /*0x14110808d*/
      return; /*0x14110808d*/
    while ( 1 ) /*0x141108093*/
    {
      if ( resendLinkedListHead->nextActionTime >= time ) /*0x141108097*/
      {
        if ( this->datagramSizeSoFar == 0 ) /*0x1411083cb*/
          goto LABEL_79; /*0x1411083cb*/
        list_size = this->packetsToSendThisUpdateDatagramBoundaries.list_size; /*0x1411083d1*/
        allocation_size = this->packetsToSendThisUpdateDatagramBoundaries.allocation_size; /*0x1411083d7*/
        v40 = this->packetsToSendThisUpdate.list_size; /*0x1411083dd*/
        if ( list_size != allocation_size ) /*0x1411083e5*/
        {
          listArray = this->packetsToSendThisUpdateDatagramBoundaries.listArray; /*0x141108484*/
          goto LABEL_65; /*0x141108484*/
        }
        if ( allocation_size != 0 ) /*0x1411083ed*/
        {
          v28 = 2 * allocation_size == 0; /*0x141108476*/
          v41 = 2 * allocation_size; /*0x141108476*/
          this->packetsToSendThisUpdateDatagramBoundaries.allocation_size = v41; /*0x141108478*/
          if ( v28 ) /*0x14110847e*/
          {
            listArray = nullptr; /*0x141108480*/
            goto LABEL_56; /*0x141108482*/
          }
        }
        else
        {
          this->packetsToSendThisUpdateDatagramBoundaries.allocation_size = 16; /*0x1411083f3*/
          v41 = 16; /*0x1411083fd*/
        }
        v42 = (unsigned int *)operator new(size: saturated_mul(v41, 4u)); /*0x14110841b*/
        list_size = this->packetsToSendThisUpdateDatagramBoundaries.list_size; /*0x141108420*/
        listArray = v42; /*0x141108426*/
LABEL_56:
        v44 = this->packetsToSendThisUpdateDatagramBoundaries.listArray; /*0x141108429*/
        if ( v44 != nullptr ) /*0x141108433*/
        {
          v45 = 0; /*0x141108435*/
          if ( list_size != 0 ) /*0x14110843a*/
          {
            do /*0x14110845f*/
            {
              v46 = v45; /*0x141108447*/
              v45 = (unsigned int)(v45 + 1); /*0x14110844f*/
              listArray[v46] = this->packetsToSendThisUpdateDatagramBoundaries.listArray[v46]; /*0x141108455*/
            }
            while ( (unsigned int)v45 < this->packetsToSendThisUpdateDatagramBoundaries.list_size ); /*0x14110845f*/
            v44 = this->packetsToSendThisUpdateDatagramBoundaries.listArray; /*0x141108461*/
          }
          operator delete(ptr: v44); /*0x141108468*/
        }
        this->packetsToSendThisUpdateDatagramBoundaries.listArray = listArray; /*0x14110846d*/
LABEL_65:
        listArray[this->packetsToSendThisUpdateDatagramBoundaries.list_size++] = v40; /*0x14110848b*/
        v47 = this->datagramSizesInBytes.list_size; /*0x1411084a0*/
        v48 = this->datagramSizesInBytes.allocation_size; /*0x1411084a9*/
        v31 = (this->datagramSizeSoFar + 7) >> 3; /*0x1411084af*/
        if ( v47 != v48 ) /*0x1411084b4*/
          goto LABEL_77; /*0x1411084b4*/
        if ( v48 != 0 ) /*0x1411084bc*/
        {
          v28 = 2 * v48 == 0; /*0x141108546*/
          v49 = 2 * v48; /*0x141108546*/
          this->datagramSizesInBytes.allocation_size = v49; /*0x141108548*/
          if ( v28 ) /*0x14110854e*/
          {
            v34 = nullptr; /*0x141108550*/
LABEL_69:
            v35 = this->datagramSizesInBytes.listArray; /*0x1411084f8*/
            if ( v35 != nullptr ) /*0x141108502*/
            {
              v51 = 0; /*0x141108504*/
              if ( v47 != 0 ) /*0x141108509*/
              {
                do /*0x14110852f*/
                {
                  v52 = v51; /*0x141108517*/
                  v51 = (unsigned int)(v51 + 1); /*0x14110851f*/
                  v34[v52] = this->datagramSizesInBytes.listArray[v52]; /*0x141108525*/
                }
                while ( (unsigned int)v51 < this->datagramSizesInBytes.list_size ); /*0x14110852f*/
LABEL_72:
                v35 = this->datagramSizesInBytes.listArray; /*0x141108531*/
              }
LABEL_73:
              operator delete(ptr: v35); /*0x141108538*/
            }
LABEL_74:
            this->datagramSizesInBytes.listArray = v34; /*0x14110853d*/
            goto LABEL_78; /*0x141108544*/
          }
        }
        else
        {
          this->datagramSizesInBytes.allocation_size = 16; /*0x1411084c2*/
          v49 = 16; /*0x1411084cc*/
        }
        v50 = (unsigned int *)operator new(size: saturated_mul(v49, 4u)); /*0x1411084ea*/
        v47 = this->datagramSizesInBytes.list_size; /*0x1411084ef*/
        v34 = v50; /*0x1411084f5*/
        goto LABEL_69; /*0x1411084f5*/
      }
      v9 = resendLinkedListHead->dataBitLength + resendLinkedListHead->headerLength; /*0x1411080a8*/
      v10 = this->congestionManager->includeTimestampWithDatagrams(this: this->congestionManager); /*0x1411080bc*/
      v11 = this->congestionManager->GetMTU(this: this->congestionManager); /*0x1411080c2*/
      v12 = -9; /*0x1411080cb*/
      if ( v10 ) /*0x1411080d7*/
        v12 = -13; /*0x1411080d7*/
      v13 = v12 - ruppLength + v11; /*0x1411080dd*/
      if ( this->rbxSessionCrypto._Ptr != nullptr /*0x1411080e7*/
        && RBX::Security::SessionCrypto::getEnabledForRaknet(this: this->rbxSessionCrypto._Ptr) )
      {
        v13 -= 18; /*0x1411080f0*/
      }
      datagramSizeSoFar = this->datagramSizeSoFar; /*0x1411080f3*/
      if ( datagramSizeSoFar + v9 > 8 * v13 ) /*0x141108106*/
        break; /*0x141108106*/
      v15 = this->resendLinkedListHead; /*0x14110810c*/
      v15->resendPrev->resendNext = v15->resendNext; /*0x141108122*/
      v15->resendNext->resendPrev = v15->resendPrev; /*0x14110812e*/
      if ( v15 == this->resendLinkedListHead ) /*0x141108147*/
      {
        resendNext = v15->resendNext; /*0x141108149*/
        this->resendLinkedListHead = resendNext; /*0x14110814d*/
        if ( resendNext == v15 ) /*0x141108157*/
          this->resendLinkedListHead = nullptr; /*0x141108159*/
      }
      RakNet::BPSTracker::Push1( /*0x14110817a*/
        this: &this->bpsMetrics[2],
        time,
        value1: (unsigned __int64)(resendLinkedListHead->dataBitLength + 7) >> 3);
      RakNet::ReliabilityLayer::PushPacket(this, time, internalPacket: resendLinkedListHead, isReliable: true); /*0x14110818b*/
      ++resendLinkedListHead->timesSent; /*0x141108190*/
      if ( DFFlag::RCCJoinTransmissionStats.value ) /*0x14110819a*/
      {
        if ( resendLinkedListHead->isJoinData ) /*0x14110819c*/
        {
          if ( resendLinkedListHead->nextActionTimeSetByNak ) /*0x1411081a2*/
            ++this->statistics.ds.joinInternalResentNakCount; /*0x1411081a8*/
          else
            ++this->statistics.ds.joinInternalResentRTOCount; /*0x1411081b0*/
        }
        resendLinkedListHead->nextActionTimeSetByNak = false; /*0x1411081b6*/
      }
      resendLinkedListHead->nextActionTime = time /*0x1411081d0*/
                                           + this->congestionManager->GetRTOForRetransmission(this: this->congestionManager);
      this->congestionManager->OnResend(this: this->congestionManager, a2: time); /*0x1411081de*/
      v8 = 1; /*0x1411081e5*/
      if ( resendLinkedListHead->splitPacketCount != 0 ) /*0x1411081e8*/
        ++this->statistics.numberOfSplitMessages; /*0x1411081f2*/
      else
        ++this->statistics.numberOfUnsplitMessages; /*0x1411081ea*/
      v17 = this->resendLinkedListHead; /*0x1411081f8*/
      if ( v17 != nullptr ) /*0x141108202*/
      {
        resendLinkedListHead->resendNext = v17; /*0x141108215*/
        resendPrev = this->resendLinkedListHead->resendPrev; /*0x141108220*/
        resendLinkedListHead->resendPrev = resendPrev; /*0x141108224*/
        resendPrev->resendNext = resendLinkedListHead; /*0x141108228*/
        this->resendLinkedListHead->resendPrev = resendLinkedListHead; /*0x141108233*/
      }
      else
      {
        resendLinkedListHead->resendNext = resendLinkedListHead; /*0x141108204*/
        resendLinkedListHead->resendPrev = resendLinkedListHead; /*0x141108208*/
        this->resendLinkedListHead = resendLinkedListHead; /*0x14110820c*/
      }
      resendLinkedListHead = this->resendLinkedListHead; /*0x141108237*/
      if ( resendLinkedListHead == nullptr ) /*0x141108241*/
        goto LABEL_80; /*0x141108241*/
    }
    if ( datagramSizeSoFar == 0 ) /*0x14110824e*/
      goto LABEL_79; /*0x14110824e*/
    v19 = this->packetsToSendThisUpdateDatagramBoundaries.list_size; /*0x141108254*/
    v20 = this->packetsToSendThisUpdateDatagramBoundaries.allocation_size; /*0x14110825a*/
    v21 = this->packetsToSendThisUpdate.list_size; /*0x141108260*/
    if ( v19 == v20 ) /*0x141108268*/
    {
      if ( v20 == 0 ) /*0x141108270*/
      {
        this->packetsToSendThisUpdateDatagramBoundaries.allocation_size = 16; /*0x141108276*/
        v22 = 16; /*0x141108280*/
        goto LABEL_31; /*0x141108280*/
      }
      v28 = 2 * v20 == 0; /*0x1411082f6*/
      v22 = 2 * v20; /*0x1411082f6*/
      this->packetsToSendThisUpdateDatagramBoundaries.allocation_size = v22; /*0x1411082f8*/
      if ( v28 ) /*0x1411082fe*/
      {
        v24 = nullptr; /*0x141108300*/
      }
      else
      {
LABEL_31:
        v23 = (unsigned int *)operator new(size: saturated_mul(v22, 4u)); /*0x14110829b*/
        v19 = this->packetsToSendThisUpdateDatagramBoundaries.list_size; /*0x1411082a3*/
        v24 = v23; /*0x1411082a9*/
      }
      v25 = this->packetsToSendThisUpdateDatagramBoundaries.listArray; /*0x1411082ac*/
      if ( v25 != nullptr ) /*0x1411082b6*/
      {
        v26 = 0; /*0x1411082b8*/
        if ( v19 != 0 ) /*0x1411082bd*/
        {
          do /*0x1411082df*/
          {
            v27 = v26; /*0x1411082c7*/
            v26 = (unsigned int)(v26 + 1); /*0x1411082cf*/
            v24[v27] = this->packetsToSendThisUpdateDatagramBoundaries.listArray[v27]; /*0x1411082d5*/
          }
          while ( (unsigned int)v26 < this->packetsToSendThisUpdateDatagramBoundaries.list_size ); /*0x1411082df*/
          v25 = this->packetsToSendThisUpdateDatagramBoundaries.listArray; /*0x1411082e1*/
        }
        operator delete(ptr: v25); /*0x1411082e8*/
      }
      this->packetsToSendThisUpdateDatagramBoundaries.listArray = v24; /*0x1411082ed*/
    }
    else
    {
      v24 = this->packetsToSendThisUpdateDatagramBoundaries.listArray; /*0x141108304*/
    }
    v24[this->packetsToSendThisUpdateDatagramBoundaries.list_size++] = v21; /*0x141108311*/
    v29 = this->datagramSizesInBytes.list_size; /*0x141108320*/
    v30 = this->datagramSizesInBytes.allocation_size; /*0x141108329*/
    v31 = (this->datagramSizeSoFar + 7) >> 3; /*0x14110832f*/
    if ( v29 == v30 ) /*0x141108334*/
    {
      if ( v30 == 0 ) /*0x14110833c*/
      {
        this->datagramSizesInBytes.allocation_size = 16; /*0x14110833e*/
        v32 = 16; /*0x141108348*/
        goto LABEL_44; /*0x141108348*/
      }
      v28 = 2 * v30 == 0; /*0x1411083b6*/
      v32 = 2 * v30; /*0x1411083b6*/
      this->datagramSizesInBytes.allocation_size = v32; /*0x1411083b8*/
      if ( v28 ) /*0x1411083be*/
      {
        v34 = nullptr; /*0x1411083c0*/
      }
      else
      {
LABEL_44:
        v33 = (unsigned int *)operator new(size: saturated_mul(v32, 4u)); /*0x141108363*/
        v29 = this->datagramSizesInBytes.list_size; /*0x14110836b*/
        v34 = v33; /*0x141108371*/
      }
      v35 = this->datagramSizesInBytes.listArray; /*0x141108374*/
      if ( v35 != nullptr ) /*0x14110837e*/
      {
        v36 = 0; /*0x141108384*/
        if ( v29 != 0 ) /*0x141108389*/
        {
          do /*0x1411083af*/
          {
            v37 = v36; /*0x141108397*/
            v36 = (unsigned int)(v36 + 1); /*0x14110839f*/
            v34[v37] = this->datagramSizesInBytes.listArray[v37]; /*0x1411083a5*/
          }
          while ( (unsigned int)v36 < this->datagramSizesInBytes.list_size ); /*0x1411083af*/
          goto LABEL_72; /*0x1411083af*/
        }
        goto LABEL_73; /*0x141108389*/
      }
      goto LABEL_74; /*0x14110837e*/
    }
LABEL_77:
    v34 = this->datagramSizesInBytes.listArray; /*0x141108554*/
LABEL_78:
    v34[this->datagramSizesInBytes.list_size++] = v31; /*0x14110855b*/
    this->datagramSizeSoFar = 0; /*0x14110856a*/
LABEL_79:
    if ( v8 == 0 ) /*0x141108577*/
      return; /*0x141108577*/
LABEL_80:
    ; /*0x141108579*/
  }
  while ( (int)((this->allDatagramSizesSoFar + 7) >> 3) < retransmissionBandwidth ); /*0x141108589*/
}

// Address: 0x1411085c0 | Name: ?fillToTransmissionBandwidth@ReliabilityLayer@RakNet@@AEAAX_KIHH@Z
void __fastcall RakNet::ReliabilityLayer::fillToTransmissionBandwidth(
        RakNet::ReliabilityLayer *this,
        unsigned __int64 time,
        unsigned int bitsPerSecondLimit,
        int transmissionBandwidth,
        int ruppLength)
{
  RakNet::InternalPacket **Myfirst; // r8
  unsigned int val; // eax
  __int64 v11; // rcx
  int v12; // edx
  int v13; // eax
  unsigned __int64 lastSec; // rdi
  bool v15; // al
  unsigned int list_size; // edx
  unsigned int allocation_size; // eax
  unsigned int v18; // esi
  signed int v19; // eax
  unsigned int *v20; // rax
  unsigned int *listArray; // rdi
  unsigned int *v22; // rcx
  unsigned int v23; // r8d
  __int64 v24; // rax
  bool v25; // zf
  unsigned int v26; // edx
  unsigned int v27; // eax
  unsigned int v28; // esi
  signed int v29; // eax
  unsigned int *v30; // rax
  unsigned int *v31; // rdi
  unsigned int *v32; // rcx
  unsigned int v33; // r8d
  __int64 v34; // rax

  while ( 1 )
  {
    Myfirst = this->resendBuffer._Mypair._Myval2._Myfirst; /*0x1411085f0*/
    val = this->sendReliableMessageNumberIndex.val; /*0x141108605*/
    v11 = this->resendBuffer._Mypair._Myval2._Mylast - Myfirst; /*0x14110860e*/
    v12 = (((_DWORD)v11 - 1) & (unsigned int)v11) != 0 ? val % (unsigned int)v11 : val & (v11 - 1);
    if ( Myfirst[v12] != nullptr || (int)((this->allDatagramSizesSoFar + 7) >> 3) >= transmissionBandwidth ) /*0x14110863d*/
      break; /*0x14110863d*/
    if ( FFlag::FixBPSTracker.value ) /*0x14110864a*/
    {
      if ( bitsPerSecondLimit == 0 ) /*0x14110864e*/
        goto LABEL_11; /*0x14110864e*/
      v13 = Mtx_lock_0(a1: (_Mtx_t)&this->bpsMetrics[1].dataQueueMutex); /*0x141108657*/
      if ( v13 != 0 ) /*0x14110865e*/
      {
        std::_Throw_C_error(a1: v13); /*0x141108899*/
        JUMPOUT(0x14110889ELL); /*0x14110889e*/
      }
      lastSec = this->bpsMetrics[1].lastSec; /*0x141108664*/
      Mtx_unlock_0(a1: (_Mtx_t)&this->bpsMetrics[1].dataQueueMutex); /*0x141108672*/
      if ( (unsigned __int64)(bitsPerSecondLimit + 7) >> 3 < lastSec ) /*0x141108681*/
        v15 = true; /*0x141108683*/
      else
LABEL_11:
        v15 = false; /*0x14110868e*/
    }
    else
    {
      v15 = bitsPerSecondLimit != 0 /*0x14110869b*/
         && (unsigned __int64)(bitsPerSecondLimit + 7) >> 3 < this->bpsMetrics[1].lastSec1._Storage._Value;
    }
    this->statistics.isLimitedByOutgoingBandwidthLimit = v15; /*0x1411086ba*/
    RakNet::ReliabilityLayer::addToResendBuffer(this, time, ruppLength); /*0x1411086c6*/
    if ( this->datagramSizeSoFar == 0 ) /*0x1411086d2*/
      break; /*0x1411086d2*/
    list_size = this->packetsToSendThisUpdateDatagramBoundaries.list_size; /*0x1411086d8*/
    allocation_size = this->packetsToSendThisUpdateDatagramBoundaries.allocation_size; /*0x1411086de*/
    v18 = this->packetsToSendThisUpdate.list_size; /*0x1411086e4*/
    if ( list_size != allocation_size ) /*0x1411086ec*/
    {
      listArray = this->packetsToSendThisUpdateDatagramBoundaries.listArray; /*0x141108788*/
      goto LABEL_30; /*0x141108788*/
    }
    if ( allocation_size != 0 ) /*0x1411086f4*/
    {
      v25 = 2 * allocation_size == 0; /*0x141108779*/
      v19 = 2 * allocation_size; /*0x141108779*/
      this->packetsToSendThisUpdateDatagramBoundaries.allocation_size = v19; /*0x14110877b*/
      if ( v25 ) /*0x141108781*/
      {
        listArray = nullptr; /*0x141108783*/
        goto LABEL_21; /*0x141108786*/
      }
    }
    else
    {
      this->packetsToSendThisUpdateDatagramBoundaries.allocation_size = 16; /*0x1411086fa*/
      v19 = 16; /*0x141108704*/
    }
    v20 = (unsigned int *)operator new(size: saturated_mul(v19, 4u)); /*0x14110871b*/
    list_size = this->packetsToSendThisUpdateDatagramBoundaries.list_size; /*0x141108720*/
    listArray = v20; /*0x141108726*/
LABEL_21:
    v22 = this->packetsToSendThisUpdateDatagramBoundaries.listArray; /*0x141108729*/
    if ( v22 != nullptr ) /*0x141108733*/
    {
      v23 = 0; /*0x141108735*/
      if ( list_size != 0 ) /*0x14110873a*/
      {
        do /*0x141108762*/
        {
          v24 = v23++; /*0x141108740*/
          listArray[v24] = this->packetsToSendThisUpdateDatagramBoundaries.listArray[v24]; /*0x141108758*/
        }
        while ( v23 < this->packetsToSendThisUpdateDatagramBoundaries.list_size ); /*0x141108762*/
        v22 = this->packetsToSendThisUpdateDatagramBoundaries.listArray; /*0x141108764*/
      }
      operator delete(ptr: v22); /*0x14110876b*/
    }
    this->packetsToSendThisUpdateDatagramBoundaries.listArray = listArray; /*0x141108770*/
LABEL_30:
    listArray[this->packetsToSendThisUpdateDatagramBoundaries.list_size++] = v18; /*0x14110878f*/
    v26 = this->datagramSizesInBytes.list_size; /*0x1411087a4*/
    v27 = this->datagramSizesInBytes.allocation_size; /*0x1411087ad*/
    v28 = (this->datagramSizeSoFar + 7) >> 3; /*0x1411087b3*/
    if ( v26 != v27 ) /*0x1411087b8*/
    {
      v31 = this->datagramSizesInBytes.listArray; /*0x141108858*/
      goto LABEL_43; /*0x141108858*/
    }
    if ( v27 != 0 ) /*0x1411087c0*/
    {
      v25 = 2 * v27 == 0; /*0x141108849*/
      v29 = 2 * v27; /*0x141108849*/
      this->datagramSizesInBytes.allocation_size = v29; /*0x14110884b*/
      if ( v25 ) /*0x141108851*/
      {
        v31 = nullptr; /*0x141108853*/
        goto LABEL_34; /*0x141108856*/
      }
    }
    else
    {
      this->datagramSizesInBytes.allocation_size = 16; /*0x1411087c6*/
      v29 = 16; /*0x1411087d0*/
    }
    v30 = (unsigned int *)operator new(size: saturated_mul(v29, 4u)); /*0x1411087ee*/
    v26 = this->datagramSizesInBytes.list_size; /*0x1411087f3*/
    v31 = v30; /*0x1411087f9*/
LABEL_34:
    v32 = this->datagramSizesInBytes.listArray; /*0x1411087fc*/
    if ( v32 != nullptr ) /*0x141108806*/
    {
      v33 = 0; /*0x141108808*/
      if ( v26 != 0 ) /*0x14110880d*/
      {
        do /*0x141108832*/
        {
          v34 = v33++; /*0x141108810*/
          v31[v34] = this->datagramSizesInBytes.listArray[v34]; /*0x141108828*/
        }
        while ( v33 < this->datagramSizesInBytes.list_size ); /*0x141108832*/
        v32 = this->datagramSizesInBytes.listArray; /*0x141108834*/
      }
      operator delete(ptr: v32); /*0x14110883b*/
    }
    this->datagramSizesInBytes.listArray = v31; /*0x141108840*/
LABEL_43:
    v31[this->datagramSizesInBytes.list_size++] = v28; /*0x14110885f*/
    this->datagramSizeSoFar = 0; /*0x14110886e*/
  }
}

// Address: 0x1411088a0 | Name: ?getAvaliableNetworkCapacityInBytesInNextMs@ReliabilityLayer@RakNet@@QEAAHM@Z
int __fastcall RakNet::ReliabilityLayer::getAvaliableNetworkCapacityInBytesInNextMs(
        RakNet::ReliabilityLayer *this,
        float ms)
{
  RakNet::CCRakNetBase *congestionManager; // r10
  signed __int64 v3; // r8

  congestionManager = this->congestionManager; /*0x1411088a4*/
  if ( congestionManager == nullptr ) /*0x1411088b1*/
    return 0; /*0x14110894d*/
  v3 = this->statistics.valueOverLastSecond[1]; /*0x1411088c1*/
  if ( v3 + this->statistics.valueOverLastSecond[2] != 0 && v3 < 0 ) /*0x1411088fb*/
    v3 = this->statistics.valueOverLastSecond[1] & 1; /*0x141108907*/
  return ((int (__fastcall *)(RakNet::CCRakNetBase *, int (__fastcall *)(RakNet::CCRakNetBase *, float, float, unsigned __int64, unsigned __int64), signed __int64, unsigned __int64, unsigned __int64))congestionManager->GetAvailableTransmissionCapacityBytesWithinWindow)( /*0x141108948*/
           a1: this->congestionManager,
           a2: congestionManager->GetAvailableTransmissionCapacityBytesWithinWindow,
           a3: v3,
           a4: this->statistics.bytesInResendBuffer,
           a5: this->statistics.valueOverLastSecond[0]);
}

// Address: 0x141108960 | Name: ?modifyForAvoidedPacketSizes@ReliabilityLayer@RakNet@@AEAAHPEAVBitStream@2@HH@Z
__int64 __fastcall RakNet::ReliabilityLayer::modifyForAvoidedPacketSizes(
        RakNet::ReliabilityLayer *this,
        RakNet::BitStream *bs,
        unsigned int mtu,
        unsigned int paddingLocation)
{
  unsigned int v8; // edi
  unsigned int v9; // eax
  int *Myfirst; // r8
  unsigned int v11; // r9d
  unsigned __int64 v12; // rax
  unsigned int v13; // eax
  unsigned int numberOfBitsUsed; // esi
  unsigned __int8 *p_inByteArray; // rdx
  unsigned __int8 inOutByteArray; // [rsp+48h] [rbp+10h] BYREF
  __int16 inByteArray; // [rsp+50h] [rbp+18h] BYREF

  v8 = 0; /*0x141108984*/
  if ( bs->GetNumberOfBytesUsed(this: bs) < mtu ) /*0x14110898b*/
  {
    do /*0x141108a04*/
    {
      v9 = bs->GetNumberOfBytesUsed(this: bs); /*0x141108996*/
      Myfirst = this->avoidedPacketSizes._Mypair._Myval2._Myfirst; /*0x1411089a0*/
      v11 = v9 + v8; /*0x1411089a7*/
      v12 = this->avoidedPacketSizes._Mypair._Myval2._Mylast - Myfirst; /*0x1411089b1*/
      while ( (__int64)v12 > 0 ) /*0x1411089b8*/
      {
        if ( Myfirst[v12 >> 1] >= v11 ) /*0x1411089ce*/
        {
          v12 >>= 1; /*0x1411089e3*/
        }
        else
        {
          Myfirst += (v12 >> 1) + 1; /*0x1411089d0*/
          v12 += -1LL - (v12 >> 1); /*0x1411089de*/
        }
      }
      if ( Myfirst == this->avoidedPacketSizes._Mypair._Myval2._Mylast ) /*0x1411089ee*/
        break; /*0x1411089ee*/
      if ( v11 < *Myfirst ) /*0x1411089f3*/
        break; /*0x1411089f3*/
      ++v8; /*0x1411089fb*/
    }
    while ( v8 + bs->GetNumberOfBytesUsed(this: bs) < mtu ); /*0x141108a04*/
  }
  v13 = bs->GetNumberOfBytesUsed(this: bs); /*0x141108a0c*/
  RakNet::BitStream::PadWithZeroToByteLength(this: bs, bytes: v8 + v13); /*0x141108a15*/
  numberOfBitsUsed = bs->numberOfBitsUsed; /*0x141108a1a*/
  RakNet::BitStream::SetWriteOffset(this: bs, offset: paddingLocation, eraseDataToCurrentOffset: false); /*0x141108a26*/
  inByteArray = v8; /*0x141108a2b*/
  if ( RakNet::BitStream::IsNetworkOrder() ) /*0x141108a30*/
  {
    p_inByteArray = (unsigned __int8 *)&inByteArray; /*0x141108a55*/
  }
  else
  {
    RBX::Network::NetworkStream::ReverseBytes((unsigned __int8 *)&inByteArray, &inOutByteArray, length: 2u); /*0x141108a49*/
    p_inByteArray = &inOutByteArray; /*0x141108a4e*/
  }
  RakNet::BitStream::WriteBits(this: bs, inByteArray: p_inByteArray, numberOfBitsToWrite: 0x10u, rightAlignedBits: true); /*0x141108a66*/
  RakNet::BitStream::SetWriteOffset(this: bs, offset: numberOfBitsUsed, eraseDataToCurrentOffset: false); /*0x141108a73*/
  return v8; /*0x141108a78*/
}

// Address: 0x141108d50 | Name: ?sendDatagrams@ReliabilityLayer@RakNet@@AEAAXV?$shared_ptr@URakNetSocket@RakNet@@@std@@AEAUSystemAddress@2@AEAVBitStream@2@AEBV?$shared_ptr@VRupp@1Network@RBX@@@4@AEBU52@AEAUDatagramHeaderFormat@2@@Z
void __fastcall RakNet::ReliabilityLayer::sendDatagrams(
        RakNet::ReliabilityLayer *this,
        std::shared_ptr<RBX::File> *socket,
        RakNet::SystemAddress *systemAddress,
        RakNet::BitStream *updateBitStream,
        const std::shared_ptr<RBX::Network::Rupp::Rupp> *ruppHeader,
        const RakNet::SystemAddress *udmuxAddress,
        RakNet::DatagramHeaderFormat *dhf)
{
  RakNet::BitStream *v7; // rdi
  unsigned __int64 *v8; // rsi
  __int64 v10; // r13
  RakNet::DatagramHeaderFormat *v11; // r14
  const std::shared_ptr<RBX::Network::Rupp::Rupp> *v12; // rsi
  unsigned int *listArray; // rdx
  unsigned int v14; // r12d
  unsigned int v15; // r15d
  __int64 isJoinData; // rdx
  __int64 v17; // r8
  __int64 v18; // r9
  bool v19; // cl
  bool v20; // si
  bool sendJoinDataBit; // di
  unsigned __int8 avoidPacketSizeCapable; // bp
  char v23; // al
  RakNet::BitStream *v24; // rsi
  unsigned __int64 v25; // rbp
  unsigned int tail; // ecx
  unsigned int head; // edx
  int v28; // ecx
  RakNet::CCRakNetBase *congestionManager; // rsi
  void (__fastcall *OnSendBytes_2)(RakNet::CCRakNetBase *, unsigned __int64, unsigned int); // rdi
  bool v31; // al
  __int64 v32; // r8
  unsigned __int64 Rep; // rcx
  unsigned int list_size; // ecx
  unsigned __int64 v35; // rax
  volatile signed __int32 *v36; // rbx
  bool writeResentBit; // [rsp+30h] [rbp-98h]
  unsigned int paddingLocation; // [rsp+40h] [rbp-88h] BYREF
  _BYTE v39[4]; // [rsp+44h] [rbp-84h] BYREF
  unsigned __int64 now[2]; // [rsp+48h] [rbp-80h] BYREF
  std::shared_ptr<RBX::File> *v41; // [rsp+58h] [rbp-70h]
  RakNet::ReliabilityLayer::DatagramHistoryNode input; // [rsp+60h] [rbp-68h] BYREF
  std::pair<RakNet::ReliabilityLayer::MessageNumberNode *,unsigned char> result; // [rsp+70h] [rbp-58h] BYREF
  RakNet::uint24_t datagramNumber; // [rsp+D0h] [rbp+8h] BYREF
  std::shared_ptr<RBX::File> *v45; // [rsp+D8h] [rbp+10h]
  const RakNet::SystemAddress *v46; // [rsp+E0h] [rbp+18h]
  RakNet::BitStream *b; // [rsp+E8h] [rbp+20h]

  b = updateBitStream; /*0x141108d50*/
  v46 = systemAddress; /*0x141108d55*/
  v45 = socket; /*0x141108d5a*/
  v7 = updateBitStream; /*0x141108d72*/
  v8 = (unsigned __int64 *)socket; /*0x141108d75*/
  v41 = socket; /*0x141108d78*/
  v10 = 0; /*0x141108d80*/
  if ( this->packetsToSendThisUpdateDatagramBoundaries.list_size != 0 ) /*0x141108d8a*/
  {
    v11 = dhf; /*0x141108d90*/
    do /*0x141109117*/
    {
      v12 = ruppHeader; /*0x141108da0*/
      if ( (_DWORD)v10 != 0 ) /*0x141108dab*/
        v11->isContinuousSend = true; /*0x141108dad*/
      __wind /*0xf1c0000000000010*/
      {
        v11->datagramNumber.val = this->congestionManager->GetAndIncrementNextDatagramSequenceNumber( /*0x141108dc6*/
                                    this: this->congestionManager,
                                    result: v39)->val;
        listArray = this->packetsToSendThisUpdateDatagramBoundaries.listArray; /*0x141108dca*/
        if ( (_DWORD)v10 != 0 ) /*0x141108dd4*/
        {
          v14 = listArray[(unsigned int)(v10 - 1)]; /*0x141108de2*/
          v15 = listArray[v10]; /*0x141108de6*/
        }
        else
        {
          v14 = 0; /*0x141108dd6*/
          v15 = *listArray; /*0x141108dd9*/
        }
        now[0] = RakNet::GetTimeUS(isNetworkSynced: false); /*0x141108df1*/
        if ( this->congestionManager->includeTimestampWithDatagrams(this: this->congestionManager) ) /*0x141108e00*/
          v11->sourceSystemTime = RakNet::GetTimeUS(isNetworkSynced: false); /*0x141108e11*/
        RakNet::BitStream::Reset(this: v7); /*0x141108e17*/
        if ( DFFlag::RuppHeaderFromClientEnabled3.value && v12->_Ptr != nullptr ) /*0x141108e2b*/
          RBX::Network::Rupp::Rupp::serialize(this: v12->_Ptr, b: v7); /*0x141108e30*/
        if ( DFFlag::RakNetResendDataBit.value ) /*0x141108e3c*/
        {
          v18 = v14; /*0x141108e3e*/
          if ( v14 < v15 ) /*0x141108e44*/
          {
            isJoinData = v11->isJoinData; /*0x141108e4d*/
            v17 = 8LL * v14; /*0x141108e52*/
            do /*0x141108e9d*/
            {
              if ( (_BYTE)isJoinData != 0 && v11->isResentData ) /*0x141108e64*/
                break; /*0x141108e69*/
              LOBYTE(isJoinData) = (*(RakNet::InternalPacket **)((char *)this->packetsToSendThisUpdate.listArray + v17))->isJoinData /*0x141108e76*/
                                 | isJoinData;
              v11->isJoinData = isJoinData; /*0x141108e79*/
              v11->isResentData |= (*(RakNet::InternalPacket **)((char *)this->packetsToSendThisUpdate.listArray + v17))->timesSent > 1u; /*0x141108e8f*/
              v18 = (unsigned int)(v18 + 1); /*0x141108e93*/
              v17 += 8; /*0x141108e96*/
            }
            while ( (unsigned int)v18 < v15 ); /*0x141108e9d*/
          }
        }
        else if ( (this->commonCapabilities & 0x200000) != 0 ) /*0x141108eac*/
        {
          v17 = v14; /*0x141108eae*/
          if ( v14 < v15 ) /*0x141108eb4*/
          {
            v19 = v11->isJoinData; /*0x141108eb9*/
            isJoinData = 8LL * v14; /*0x141108ebe*/
            do /*0x141108ee7*/
            {
              if ( v19 ) /*0x141108ec8*/
                break; /*0x141108ec8*/
              v19 = (*(RakNet::InternalPacket **)((char *)this->packetsToSendThisUpdate.listArray + isJoinData))->isJoinData; /*0x141108ed5*/
              v17 = (unsigned int)(v17 + 1); /*0x141108ed9*/
              isJoinData += 8; /*0x141108edc*/
              v11->isJoinData = v19; /*0x141108ee0*/
            }
            while ( (unsigned int)v17 < v15 ); /*0x141108ee7*/
          }
        }
        v20 = (this->commonCapabilities & 0x800000) != 0; /*0x141108ef7*/
        sendJoinDataBit = (this->commonCapabilities & 0x200000) != 0; /*0x141108f02*/
        avoidPacketSizeCapable = (this->commonCapabilities & 0x8000) != 0; /*0x141108f0a*/
        v23 = ((__int64 (__fastcall *)(RakNet::CCRakNetBase *, __int64, __int64, __int64))this->congestionManager->includeTimestampWithDatagrams)( /*0x141108f18*/
                a1: this->congestionManager,
                a2: isJoinData,
                a3: v17,
                a4: v18);
        writeResentBit = v20; /*0x141108f1e*/
        v24 = b; /*0x141108f36*/
        RakNet::DatagramHeaderFormat::Serialize( /*0x141108f44*/
          this: v11,
          b,
          includeTimestamp: v23,
          &paddingLocation,
          avoidPacketSizeCapable,
          sendJoinDataBit,
          writeResentBit);
        v25 = now[0]; /*0x141108f53*/
        RakNet::ReliabilityLayer::writeOutMessages( /*0x141108f6b*/
          this,
          &result,
          msgIndex: v14,
          msgTerm: v15,
          now: now[0],
          dhf: v11,
          updateBitStream: v24);
        if ( result.first == nullptr ) /*0x141108f76*/
        {
          if ( DFFlag::RakNetFixBwCollapse.value ) /*0x141108f83*/
          {
            RakNet::ReliabilityLayer::DropOldDatagramHistory(this); /*0x141108f88*/
            ++this->unreliableDatagramHistoryCount; /*0x141108f8d*/
          }
          else
          {
            tail = this->datagramHistory.tail; /*0x141108f95*/
            head = this->datagramHistory.head; /*0x141108f9b*/
            if ( head > tail ) /*0x141108fa3*/
              v28 = this->datagramHistory.allocation_size - head + tail; /*0x141108fb1*/
            else
              v28 = tail - head; /*0x141108fa5*/
            if ( v28 > FInt::RakNetDatagramMessageIdArrayLength ) /*0x141108fb9*/
            {
              datagramNumber.val = this->datagramHistoryPopCount.val; /*0x141108fc1*/
              RakNet::ReliabilityLayer::RemoveFromDatagramHistory(this, &datagramNumber); /*0x141108fd3*/
              if ( ++this->datagramHistory.head == this->datagramHistory.allocation_size ) /*0x141108fea*/
                this->datagramHistory.head = 0; /*0x141108fec*/
              ++this->datagramHistoryPopCount.val; /*0x141108ff6*/
              HIBYTE(this->datagramHistoryPopCount.val) = 0; /*0x141108ffc*/
            }
          }
          input.head = nullptr; /*0x141109003*/
          input.timeSent = v25; /*0x14110900c*/
          DataStructures::Queue<RakNet::ReliabilityLayer::DatagramHistoryNode>::Push( /*0x14110902a*/
            this: &this->datagramHistory,
            &input,
            file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
            line: 0x11E7u);
        }
        if ( v24->isJoinData ) /*0x14110902f*/
        {
          if ( result.second == 1 ) /*0x14110903a*/
            ++this->statistics.ds.totalJoinDataSentCount; /*0x14110903c*/
          else
            ++this->statistics.ds.totalJoinDataResentCount; /*0x141109044*/
        }
        congestionManager = this->congestionManager; /*0x14110904a*/
        OnSendBytes_2 = congestionManager->OnSendBytes_2; /*0x141109054*/
        v31 = congestionManager->includeTimestampWithDatagrams(this: congestionManager); /*0x14110905b*/
        v32 = 49; /*0x141109061*/
        if ( v31 ) /*0x14110906e*/
          v32 = 53; /*0x14110906e*/
        OnSendBytes_2(this: congestionManager, a2: v25, a3: v32); /*0x141109078*/
        *(_OWORD *)now = 0; /*0x14110907d*/
        v8 = (unsigned __int64 *)v41; /*0x141109083*/
        Rep = (unsigned __int64)v41->_Rep; /*0x141109088*/
        if ( Rep != 0 ) /*0x14110908f*/
        {
          _InterlockedIncrement((volatile signed __int32 *)(Rep + 8)); /*0x141109091*/
          Rep = v8[1]; /*0x141109095*/
        }
        now[0] = *v8; /*0x14110909c*/
        now[1] = Rep; /*0x1411090a1*/
        v7 = b; /*0x1411090cd*/
        RakNet::ReliabilityLayer::SendBitStream( /*0x1411090e8*/
          this,
          socket: (std::shared_ptr<RBX::File> *)now,
          systemAddress: v46,
          bitStream: b,
          currentTime: v25,
          ruppHeader,
          udmuxAddress,
          paddingLocation);
        list_size = this->outgoingPacketBuffer.heap.list_size; /*0x1411090ed*/
        this->bandwidthExceededStatistic = list_size != 0; /*0x1411090f8*/
        v35 = 0; /*0x1411090fe*/
        if ( list_size != 0 ) /*0x141109102*/
          v35 = v25; /*0x141109102*/
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: v45); /*0xf1c0000000000008*/
      }
      this->timeOfLastContinualSend = v35; /*0x141109106*/
      v10 = (unsigned int)(v10 + 1); /*0x14110910d*/
    }
    while ( (unsigned int)v10 < this->packetsToSendThisUpdateDatagramBoundaries.list_size ); /*0x141109117*/
  }
  v36 = (volatile signed __int32 *)v8[1]; /*0x14110911d*/
  if ( v36 != nullptr && _InterlockedExchangeAdd(v36 + 2, 0xFFFFFFFF) == 1 ) /*0x141109135*/
  {
    (**(void (__fastcall ***)(volatile signed __int32 *))v36)(a1: v36); /*0x14110913d*/
    if ( _InterlockedExchangeAdd(v36 + 3, 0xFFFFFFFF) == 1 ) /*0x141109147*/
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v36 + 8LL))(a1: v36); /*0x14110914f*/
  }
}

// Address: 0x141109170 | Name: ?writeOutMessages@ReliabilityLayer@RakNet@@AEAA?AU?$pair@PEAUMessageNumberNode@ReliabilityLayer@RakNet@@E@std@@II_KAEAUDatagramHeaderFormat@2@AEAVBitStream@2@@Z
std::pair<RakNet::ReliabilityLayer::MessageNumberNode *,unsigned char> *__fastcall RakNet::ReliabilityLayer::writeOutMessages(
        RakNet::ReliabilityLayer *this,
        std::pair<RakNet::ReliabilityLayer::MessageNumberNode *,unsigned char> *result,
        unsigned int msgIndex,
        unsigned int msgTerm,
        unsigned __int64 now,
        RakNet::DatagramHeaderFormat *dhf,
        RakNet::BitStream *updateBitStream)
{
  unsigned __int8 v7; // bl
  RakNet::ReliabilityLayer::MessageNumberNode *p_userMemory; // rsi
  unsigned __int64 v11; // r13
  __int64 v12; // r15
  __int64 v13; // r14
  RakNet::InternalPacket *v14; // rcx
  unsigned int val; // ebx
  unsigned int head; // edx
  unsigned int tail; // ecx
  int v18; // ecx
  DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>::MemoryWithPage *v19; // rax
  DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>::MemoryWithPage *v20; // rax
  RakNet::InternalPacket **listArray; // r10
  RakNet::InternalPacket *v22; // r8
  unsigned __int8 timesSent; // dl
  unsigned __int8 v24; // al
  __int64 v25; // rax
  RakNet::ReliabilityLayer::DatagramHistoryNode input; // [rsp+20h] [rbp-48h] BYREF
  unsigned __int8 v28; // [rsp+80h] [rbp+18h]
  RakNet::uint24_t datagramNumber; // [rsp+88h] [rbp+20h] BYREF

  v7 = 0; /*0x14110917a*/
  p_userMemory = nullptr; /*0x14110917c*/
  v28 = 0; /*0x14110917e*/
  if ( msgIndex < msgTerm ) /*0x14110918e*/
  {
    v11 = now; /*0x14110919c*/
    v12 = msgTerm - msgIndex; /*0x1411091b1*/
    v13 = msgIndex; /*0x1411091b9*/
    do /*0x14110935c*/
    {
      v14 = this->packetsToSendThisUpdate.listArray[v13]; /*0x1411091c8*/
      if ( v14->reliability > (unsigned int)UNRELIABLE_SEQUENCED ) /*0x1411091d0*/
      {
        val = v14->reliableMessageNumber.val; /*0x1411091d6*/
        if ( p_userMemory != nullptr ) /*0x1411091db*/
        {
          v20 = DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>::Allocate( /*0x1411092c6*/
                  this: &this->datagramHistoryMessagePool,
                  file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
                  line: 0x1217u);
          p_userMemory->next = &v20->userMemory; /*0x1411092cb*/
          v20->userMemory.messageNumber.val = val; /*0x1411092cf*/
          p_userMemory->next->next = nullptr; /*0x1411092d5*/
          p_userMemory = p_userMemory->next; /*0x1411092dd*/
        }
        else
        {
          if ( DFFlag::RakNetFixBwCollapse.value ) /*0x1411091e8*/
          {
            RakNet::ReliabilityLayer::DropOldDatagramHistory(this); /*0x1411091ed*/
          }
          else
          {
            head = this->datagramHistory.head; /*0x1411091f4*/
            tail = this->datagramHistory.tail; /*0x1411091fa*/
            if ( head > tail ) /*0x141109202*/
              v18 = this->datagramHistory.allocation_size - head + tail; /*0x141109210*/
            else
              v18 = tail - head; /*0x141109204*/
            if ( v18 > FInt::RakNetDatagramMessageIdArrayLength ) /*0x141109218*/
            {
              datagramNumber.val = this->datagramHistoryPopCount.val; /*0x14110922b*/
              RakNet::ReliabilityLayer::RemoveFromDatagramHistory(this, &datagramNumber); /*0x141109232*/
              if ( ++this->datagramHistory.head == this->datagramHistory.allocation_size ) /*0x141109249*/
                this->datagramHistory.head = 0; /*0x14110924b*/
              ++this->datagramHistoryPopCount.val; /*0x141109255*/
              HIBYTE(this->datagramHistoryPopCount.val) = 0; /*0x14110925b*/
            }
          }
          v19 = DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>::Allocate( /*0x141109276*/
                  this: &this->datagramHistoryMessagePool,
                  file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
                  line: 0x11FDu);
          input.head = &v19->userMemory; /*0x141109281*/
          input.timeSent = v11; /*0x14110928d*/
          p_userMemory = &v19->userMemory; /*0x141109297*/
          v19->userMemory.next = nullptr; /*0x1411092a1*/
          v19->userMemory.messageNumber.val = val; /*0x1411092a9*/
          DataStructures::Queue<RakNet::ReliabilityLayer::DatagramHistoryNode>::Push( /*0x1411092ab*/
            this: &this->datagramHistory,
            &input,
            file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp",
            line: 0x1200u);
        }
        v7 = v28; /*0x1411092e1*/
      }
      listArray = this->packetsToSendThisUpdate.listArray; /*0x1411092e9*/
      v22 = listArray[v13]; /*0x1411092f0*/
      if ( v22->isJoinData ) /*0x1411092f4*/
      {
        timesSent = v22->timesSent; /*0x1411092fb*/
        v24 = v7; /*0x141109306*/
        if ( v7 < timesSent ) /*0x141109309*/
          v24 = v22->timesSent; /*0x141109309*/
        v7 = v24; /*0x14110930f*/
        v28 = v24; /*0x141109312*/
        v25 = ((v22->headerLength + 7) >> 3) + ((v22->dataBitLength + 7) >> 3); /*0x141109326*/
        if ( timesSent == 1 ) /*0x14110932b*/
          this->statistics.ds.totalJoinDataSent += v25; /*0x14110932d*/
        else
          this->statistics.ds.totalJoinDataResent += v25; /*0x141109336*/
      }
      RakNet::ReliabilityLayer::WriteToBitStreamFromInternalPacket( /*0x14110934f*/
        this,
        bitStream: updateBitStream,
        internalPacket: listArray[v13++],
        curTime: v11);
      --v12; /*0x141109358*/
    }
    while ( v12 != 0 ); /*0x14110935c*/
  }
  result->first = p_userMemory; /*0x141109376*/
  result->second = v7; /*0x14110937d*/
  return result; /*0x141109382*/
}

// END ReliabilityLayer part 1/1, 55 functions
