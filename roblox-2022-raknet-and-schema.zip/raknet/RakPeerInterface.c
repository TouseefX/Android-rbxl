// RakPeerInterface -- 2022 Studio + full PDB
// tier 3, 1 functions


// Address: 0x1410b89b0 | Name: ??1RakPeerInterface@RakNet@@UEAA@XZ
void __fastcall RakNet::RakPeerInterface::~RakPeerInterface(RakNet::RakPeerInterface *this)
{
  this->__vftable = (RakNet::RakPeerInterface_vtbl *)RakNet::RakPeerInterface::`vftable'; /*0x1410b89b7*/
}

// END RakPeerInterface part 1/1, 1 functions
